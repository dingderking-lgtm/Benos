// The picture slots a compiled grammar site exposes, in the shape the platform's image binder uses.
// The engine never invents pictures: it says where each one goes, how big the frame is and whether
// the subject may be cropped, and the existing generation pipeline fills the slot.
import type { Issue } from './brand';
import type { CompiledSite } from './site';

export type GrammarBindingFrame = {
  frameId: string;
  pageKey: string;
  sectionId: string;
  index: number;
  purpose: 'figure' | 'media' | 'card-media' | 'cover';
  presentation: 'standard' | 'hero-cover';
  slot: { width: number; height: number; fit: 'cover'; focalPoint: 'center'; textSafeArea: 'none' | 'left' | 'bottom' };
  subjectPolicy: 'complete' | 'crop-safe';
  framePolicy: 'adapt' | 'fixed';
  imageId: string;
  src: string;
  native: { width: number; height: number };
  alt: string;
};

const clamp = (value: number, low: number, high: number) => Math.min(high, Math.max(low, value));

/** One frame per picture, in document order, with a slot measured from the frame's own ratio. */
export function bindingFrames(site: CompiledSite, options: { containerWidth?: number } = {}): { frames: GrammarBindingFrame[]; issues: Issue[] } {
  const frames: GrammarBindingFrame[] = [];
  const issues: Issue[] = [];
  const seen = new Set<string>();
  for (const page of site.pages) {
    for (const frame of page.frames) {
      if (seen.has(frame.frameId)) issues.push({ level: 'error', path: `${page.key}:${frame.frameId}`, message: 'two pictures claim the same frame id' });
      seen.add(frame.frameId);
      const [ratioWidth, ratioHeight] = frame.ratio.split(':').map(Number);
      const ratio = ratioWidth / ratioHeight;
      const width = clamp(frame.w, 320, options.containerWidth ?? 1360);
      const hero = frame.purpose === 'cover';
      frames.push({
        frameId: frame.frameId,
        pageKey: page.key,
        sectionId: frame.sectionId,
        index: frame.index,
        purpose: frame.purpose,
        presentation: hero ? 'hero-cover' : 'standard',
        slot: {
          width: Math.round(width),
          // A bad ratio falls back to the picture's own proportions rather than a broken frame.
          height: Math.round(width / (Number.isFinite(ratio) && ratio > 0 ? ratio : frame.w / frame.h)),
          fit: 'cover',
          focalPoint: 'center',
          textSafeArea: hero ? 'left' : 'none',
        },
        subjectPolicy: frame.fit === 'contain' ? 'complete' : 'crop-safe',
        // A cover runs edge to edge, so its frame keeps its height; everything else adapts.
        framePolicy: hero ? 'fixed' : 'adapt',
        imageId: frame.image,
        src: frame.src,
        native: { width: frame.w, height: frame.h },
        alt: frame.alt,
      });
    }
  }
  return { frames, issues };
}

/** Every picture on every page must be declared, or the CMS would ship a broken image. */
export function missingPictures(site: CompiledSite): Issue[] {
  const issues: Issue[] = [];
  for (const page of site.pages) {
    const html = page.body;
    for (const match of html.matchAll(/<img[^>]*?src="([^"]*)"/g)) {
      if (!match[1]) issues.push({ level: 'error', path: `${page.key}:img`, message: 'a picture has no source' });
    }
  }
  return issues;
}
