﻿// bnl-0 compiler: validates a page document and compiles it to one HTML fragment plus two
// stylesheets — the site-wide part (brand tokens and the shared rules) and the page's own
// instance rules. Ported from the layout-grammar experiment
// (.ui-work/layout-grammar/compile.mjs); the document schema, the checks and the produced
// markup are unchanged. What differs is the deliverable: a page body fragment scoped under one
// root class instead of a whole document, so the platform can put it into a CMS page template
// next to the site header and footer.
import {
  BUDGET, CJK, GUTTER, MOBILE_SIZE, SIZES, VIEW, resolveBrand, textWidth,
  type GrammarBrand, type Issue, type ResolvedBrand,
} from './brand';

export type GrammarElement = { t: string; [key: string]: any };
export type GrammarSection = { id: string; tone?: string; space?: string; gap?: number; body: GrammarElement[] };
export type GrammarImage = { src: string; alt?: string; w: number; h: number };
export type GrammarPage = {
  lang?: string; title?: string; brand?: GrammarBrand; sections?: GrammarSection[];
  images?: Record<string, GrammarImage>; links?: string[];
};
export type GrammarStats = {
  nodes: number; byType: Record<string, number>; sections: number; images: number; maxDepth: number;
  cssBytes: number; htmlBytes: number; instanceRules: number; imagesUnused: string[];
  /** Form references the page uses; each one must be declared in the site package. */
  forms: string[];
  /** Frames that wait for a generated picture. */
  pendingFrames: string[];
};
export type CompileOptions = {
  /** Rewrites an image path from the document to the one the page will use. */
  assetPath?: (src: string) => string;
  /** Images the site actually owns; when given it replaces the document's own list. */
  images?: Record<string, GrammarImage>;
  /** Links the site actually has (page paths). When given, hrefs are restricted to them and #section anchors. */
  links?: readonly string[];
  /** Page scope for the generated instance class names, so one page's rules never hit another's markup. */
  scope?: string;
};
/** One picture slot, in the shape the platform's image binder expects. */
export type GrammarFrame = {
  frameId: string;
  sectionId: string;
  index: number;
  image: string;
  src: string;
  w: number;
  h: number;
  alt: string;
  ratio: string;
  fit: string;
  purpose: 'figure' | 'media' | 'card-media' | 'cover';
};
export type CompileResult = {
  /** `<main class="bnl …">…</main>` — the page body, ready for a CMS page template. */
  body: string;
  /** Site-wide stylesheet: brand tokens plus every shared rule. Identical for every page of one site. */
  sharedCss: string;
  /** Page-only instance rules. */
  pageCss: string;
  css: string;
  rootClass: string;
  issues: Issue[];
  stats: GrammarStats;
  /** Every picture in the page, in document order, one frame each. */
  frames: GrammarFrame[];
  ok: boolean;
};

const BP: Record<string, number> = { xl: 1439, lg: 1150, md: 960, sm: 760 };
const esc = (value: unknown) => String(value).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]!));
const bytes = (text: string) => new TextEncoder().encode(text).length;

// ---------- node schema ----------
const TOKENS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
const RATIOS = ['4:3', '3:2', '16:9', '1:1', '3:4', '21:9'];
export const MAXES: Record<string, number> = { xs: 320, narrow: 410, medium: 560, normal: 650, wide: 960 };
type Check = ((value: any) => boolean) & { values?: readonly unknown[]; hint?: string };
const hinted = (fn: (value: any) => boolean, hint: string): Check => Object.assign(fn, { hint });
const tok: Check = hinted(v => TOKENS.includes(v), 'a spacing step from 0 to 9');
const tokOrPair: Check = hinted(v => tok(v) || (Array.isArray(v) && v.length === 2 && v.every(tok)), 'a spacing step from 0 to 9, or a pair [rowStep, colStep] of such steps');
const str = (max: number): Check => v => typeof v === 'string' && v.trim().length > 0 && v.length <= max;
const oneOf = (...values: readonly unknown[]): Check => Object.assign((v: any) => values.includes(v), { values });
const lines: Check = v => Array.isArray(v) && v.length >= 1 && v.length <= 3 && v.every(str(80));
const COMMON: Record<string, Check> = {
  t: () => true, narrowOrder: v => Number.isInteger(v) && v >= 1 && v <= 9, self: oneOf('start', 'center', 'end', 'stretch'), max: oneOf(...Object.keys(MAXES)),
};
const SCHEMA: Record<string, { req: string[]; props: Record<string, Check> }> = {
  stack: { req: ['children'], props: { gap: tok, align: oneOf('start', 'center', 'end', 'stretch'), justify: oneOf('start', 'center', 'end', 'between'), children: Array.isArray } },
  row: { req: ['children'], props: { gap: tokOrPair, align: oneOf('start', 'center', 'end', 'baseline', 'stretch'), justify: oneOf('start', 'center', 'end', 'between'), wrap: v => typeof v === 'boolean', collapse: oneOf('md', 'sm', 'none'), rule: oneOf('top', 'none'), children: Array.isArray } },
  grid: { req: ['cols', 'children'], props: { cols: hinted(v => (Number.isInteger(v) && v >= 2 && v <= 4) || (Array.isArray(v) && v.length >= 2 && v.length <= 4 && v.every((n: any) => typeof n === 'number' && n > 0 && n <= 12)), 'a number 2 to 4, or 2 to 4 weights such as [5,7]'), gap: tokOrPair, align: oneOf('start', 'center', 'end', 'stretch'), collapse: hinted(v => v === 'none' || (v && typeof v === 'object' && !Array.isArray(v) && Object.entries(v).every(([k, n]) => ['lg', 'md', 'sm'].includes(k) && Number.isInteger(n) && (n as number) >= 1 && (n as number) <= 4)), 'for a grid: leave it out for the default, or "none", or an object of column counts such as {"lg":2,"sm":1}'), children: Array.isArray } },
  card: { req: ['children'], props: { fill: oneOf('soft', 'strong', 'accent', 'surface', 'none'), border: v => typeof v === 'boolean', pad: tok, href: str(200), media: v => !!v && typeof v === 'object' && typeof v.image === 'string', children: Array.isArray } },
  figure: { req: [], props: { image: str(60), pending: v => v === true, ratio: oneOf(...RATIOS), fit: oneOf('cover', 'contain'), caption: str(200), stretch: v => typeof v === 'boolean' } },
  media: { req: ['children'], props: { image: str(60), pending: v => v === true, ratio: oneOf(...RATIOS), fit: oneOf('cover', 'contain'), caption: str(200), side: oneOf('left', 'right'), split: hinted(v => Array.isArray(v) && v.length === 2 && v.every((n: any) => typeof n === 'number' && n > 0 && n <= 12), 'two weights such as [1,1] or [7,5]'), collapse: oneOf('xl', 'lg', 'md'), narrow: oneOf('card', 'stack'), children: Array.isArray } },
  cover: { req: ['children'], props: { image: str(60), pending: v => v === true, height: oneOf('m', 'l', 'xl'), scrim: oneOf('left', 'bottom', 'full', 'none'), place: oneOf('bottom-left', 'center-left', 'center'), bleed: v => typeof v === 'boolean', children: Array.isArray } },
  kicker: { req: ['text'], props: { text: str(80) } },
  display: { req: ['lines'], props: { lines, size: oneOf('xl', 'l') } },
  title: { req: [], props: { lines, text: str(160), size: oneOf('xl', 'l', 'm', 's'), level: oneOf(2, 3) } },
  text: { req: ['text'], props: { text: str(700), role: oneOf('lead', 'body', 'small', 'caption', 'meta') } },
  number: { req: ['text'], props: { text: str(6) } },
  actions: { req: ['items'], props: { items: v => Array.isArray(v) && v.length >= 1 && v.length <= 2 } },
  link: { req: ['label', 'href'], props: { label: str(60), href: str(200) } },
  list: { req: ['items'], props: { items: v => Array.isArray(v) && v.length >= 2 && v.length <= 8 && v.every(str(200)), marker: oneOf('mark', 'number') } },
  faq: { req: ['items'], props: { items: v => Array.isArray(v) && v.length >= 2 && v.length <= 8 && v.every((i: any) => i && str(160)(i.q) && str(600)(i.a)) } },
  form: { req: [], props: { title: str(80), note: str(240), ref: str(40) } },
  rule: { req: [], props: {} },
};
export const ELEMENT_TYPES = Object.keys(SCHEMA);
const BLOCKS = new Set(['stack', 'row', 'grid', 'card', 'figure', 'media', 'cover', 'list', 'faq', 'rule', 'form']);
const TONES = ['paper', 'tint', 'dark', 'accent'], SPACES = ['hero', 'normal', 'band'];

type Ctx = { tone: string; depth: number; inCard: boolean; w: number; mf: number; ms: number; bleedSlot?: boolean };

export function compilePage(doc: GrammarPage | undefined, options: CompileOptions = {}): CompileResult {
  const issues: Issue[] = [];
  const err = (path: string, message: string) => issues.push({ level: 'error', path, message });
  const warn = (path: string, message: string) => issues.push({ level: 'warn', path, message });
  const theme = resolveBrand(doc?.brand, issues);
  const images = options.images ?? doc?.images ?? {};
  const allowed = options.links ? new Set(options.links) : Array.isArray(doc?.links) ? new Set(doc!.links) : null;
  const rules = new Map<string, string>(), used = new Map<string, number>();
  const stats: GrammarStats = { nodes: 0, byType: {}, sections: 0, images: 0, maxDepth: 0, cssBytes: 0, htmlBytes: 0, instanceRules: 0, imagesUnused: [], forms: [], pendingFrames: [] };
  const formRefs = new Set<string>();
  const pendingFrames = new Set<string>();
  const frames: GrammarFrame[] = [];
  let frameSection = '', frameCount = 0;
  const instance = (prefix: string, css: string) => { if (!rules.has(css)) rules.set(css, (options.scope ? 'bnl-' + options.scope + '-' : 'bnl-') + prefix + rules.size); return rules.get(css)!; };
  const px = (token: number) => (theme ? theme.scale[token - 1] ?? 0 : 0);
  const gapPx = (gap: any, fallback: number): [number, number] => { const g = gap ?? fallback; return Array.isArray(g) ? [px(g[0]), px(g[1])] : [px(g), px(g)]; };
  let displays = 0, firstImage = true;

  const budget = (path: string, kind: string, text: string) => { const [latin, cjk] = BUDGET[kind], limit = CJK.test(text) ? cjk : latin, n = [...text].length; if (n > limit) warn(path, `${kind} text is ${n} characters; keep it within ${limit}`); };
  const href = (path: string, value: string) => {
    // Two shapes are legal: a section of a page, and a path that exists in this site.
    const anchor = /^([^#]*)#([a-z][\w-]*)$/i.exec(value);
    const ok = anchor
      ? (anchor[1] === '' || !allowed || allowed.has(anchor[1]))
      : !allowed || allowed.has(value);
    if (!ok) err(path, `href ${JSON.stringify(value)} is not one of the allowed links`);
    return esc(value);
  };
  const img = (path: string, id: string | undefined, frame: { purpose: GrammarFrame['purpose']; ratio?: string; fit?: string; pending?: boolean }) => {
    if (!id) {
      // A pending slot: the frame is reserved now and a generated picture fills it later.
      const ratio = frame.ratio || '4:3', [rw, rh] = ratio.split(':').map(Number);
      const width = 1600, height = Math.round(1600 * rh / rw);
      const frameId = 'bnf-image-' + (options.scope ? options.scope + '-' : '') + (frameSection || 'page') + '-' + (++frameCount);
      frames.push({ frameId, sectionId: frameSection, index: frameCount, image: '', src: '', w: width, h: height, alt: '', ratio, fit: frame.fit || 'cover', purpose: frame.purpose });
      pendingFrames.add(frameId);
      return `<img id="${frameId}" alt="" width="${width}" height="${height}" decoding="async" loading="lazy">`;
    }
    const meta = images[id];
    if (!meta) { err(path, `unknown image ${JSON.stringify(id)}`); return ''; }
    used.set(id, (used.get(id) || 0) + 1); stats.images++;
    const eager = firstImage; firstImage = false;
    const src = options.assetPath ? options.assetPath(meta.src) : meta.src;
    // The page scope keeps frame ids unique across a whole site, while staying stable per page.
    const frameId = 'bnf-image-' + (options.scope ? options.scope + '-' : '') + (frameSection || 'page') + '-' + (++frameCount);
    frames.push({ frameId, sectionId: frameSection, index: frameCount, image: id, src, w: meta.w, h: meta.h, alt: meta.alt || '', ratio: frame.ratio || '4:3', fit: frame.fit || 'contain', purpose: frame.purpose });
    return `<img id="${frameId}" src="${esc(src)}" alt="${esc(meta.alt || '')}" width="${meta.w}" height="${meta.h}" decoding="async" loading="${eager ? 'eager' : 'lazy'}">`;
  };
  const ratioClass = (r: string | undefined) => 'bnl-ar-' + (r || '4:3').replace(':', 'x');
  // A picture shown in a frame far from its own proportions is either cropped hard or letterboxed;
  // the brief's pictures are known, so the compiler can say so instead of letting it slide.
  const checkRatio = (path: string, id: string, ratio: string | undefined, fit: string | undefined) => {
    const meta = images[id];
    if (!meta || !meta.w || !meta.h) return;
    const [rw, rh] = String(ratio || '4:3').split(':').map(Number);
    const want = meta.w / meta.h, frame = rw / rh, off = Math.max(want / frame, frame / want);
    if (off > 1.45 && fit !== 'cover') warn(path + '.ratio', `this picture is ${meta.w}x${meta.h} (${want.toFixed(2)}:1) but the frame is ${ratio || '4:3'} (${frame.toFixed(2)}:1); pick a closer ratio or set fit "cover"`);
  };
  const cjk = (text: string) => (CJK.test(text) ? ' bnl-cjk' : '');
  const common = (node: GrammarElement) => (node.max ? ' bnl-mx-' + node.max : '') + (node.self ? ' bnl-self-' + node.self : '');
  // Authored lines must fit on a wide screen (checked here) and are kept whole on phones: the
  // compiler knows how wide the longest line is in ems and caps the phone type size so it still fits.
  const fitLines = (path: string, role: 'display' | 'title', size: string, list: string[], ctx: Ctx, hard: boolean) => {
    const [font, letter, maxW] = SIZES[role][size], fontPx = font * (theme?.typeScale || 1), avail = Math.min(ctx.w, maxW || Infinity);
    list.forEach((line, i) => {
      const w = textWidth(line, fontPx, CJK.test(line) ? -.01 * fontPx : letter * (theme?.tracking ?? 1));
      if (w > avail * 1.03) (hard ? err : warn)(`${path}.lines[${i}]`, `this line needs about ${Math.round(w)}px at ${Math.round(fontPx)}px type but the column is ${Math.round(avail)}px wide; shorten it to about ${Math.floor([...line].length * avail / w)} characters or give the column more width`);
    });
    const em = Math.max(...list.map(line => textWidth(line, 1, CJK.test(line) ? -.01 : letter * (theme?.tracking ?? 1) / font))) * 1.06;
    // Only the page's one display heading is resized, and by at most a fifth: section titles keep one
    // size across the page (the type scale matters more there) and simply wrap.
    if (role !== 'display') return '';
    return ' ' + instance('f', `@760{font-size:max(calc(.8*${MOBILE_SIZE[role][size]}),min(${MOBILE_SIZE[role][size]},calc((${+(ctx.mf * 100).toFixed(2)}vw - ${+ctx.ms.toFixed(1)}px)/${em.toFixed(3)})))}`);
  };

  // The CMS drops `text-wrap`, so a balanced break has to exist in the markup. The narrowest
  // measure that still keeps the count of lines is the balanced one; those lines become spans.
  const breakLines = (text: string, fontPx: number, letterPx: number, avail: number): string[] => {
    const words = String(text).split(/\s+/).filter(Boolean);
    if (words.length < 4) return [];
    const width = (value: string) => textWidth(value, fontPx, letterPx);
    const fill = (limit: number) => {
      const lines: string[] = [];
      let current = '';
      for (const word of words) {
        const candidate = current ? current + ' ' + word : word;
        if (current && width(candidate) > limit) { lines.push(current); current = word; } else current = candidate;
      }
      if (current) lines.push(current);
      return lines;
    };
    const count = fill(avail).length;
    if (count < 2 || count > 4) return [];
    let low = Math.max(...words.map(width)), high = avail;
    for (let i = 0; i < 24 && high - low > .5; i++) { const mid = (low + high) / 2; if (fill(mid).length <= count) high = mid; else low = mid; }
    const lines = fill(high);
    // A last line holding one short word reads as an accident; ask for a new sentence instead.
    const stranded = lines.length > 1 && width(lines[lines.length - 1]) < width(lines[0]) * .34;
    return stranded ? [] : lines;
  };


  // A clause is one inline-block, so a CJK sentence breaks between clauses, never inside one.
  const CLAUSE = /[\u2E80-\u9FFF\uF900-\uFAFF\uFF00-\uFFEF]/;
  const HAN_CLASS = '[\u2E80-\u9FFF\uF900-\uFAFF\uFF00-\uFFEF]';
  const TAIL = new RegExp('(' + HAN_CLASS + '{3})([，。！？；：、…!?;:.”’」』）】》〉]*)$', 'u');
  // Three characters plus their punctuation travel as one box: a line can no longer end on one
  // or two characters, and an over-wide box still wraps inside itself.
  const tailGlue = (text: string): string => {
    const match = text.match(TAIL);
    if (!match || match.index === undefined) return esc(text);
    return esc(text.slice(0, match.index)) + '<span class="bnl-t-tail">' + esc(match[0]) + '</span>';
  };
  const withPhrases = (text: string): string => {
    if (!CLAUSE.test(text)) {
      const words = String(text).split(' ');
      if (words.length < 4) return esc(text);
      const tail = words.slice(-2).join(' ');
      return esc(words.slice(0, -2).join(' ')) + ' <span class="bnl-t-glue">' + esc(tail) + '</span>';
    }
    const phrases = String(text).match(/.+?(?:[，。！？；：、]+[”’」』）】》〉]*|$)/gs) ?? [];
    if (phrases.length < 2 || phrases.join('') !== text || phrases.some(phrase => !/[\p{L}\p{N}]/u.test(phrase))) return tailGlue(text);
    // A one- or two-word closing clause reads as a mistake when it sits alone on the last line.
    const last = phrases[phrases.length - 1];
    if ([...last].length <= 6 && phrases.length > 1) phrases.splice(phrases.length - 2, 2, phrases[phrases.length - 2] + last);
    return phrases.map(phrase => '<span class="bnl-t-phrase">' + tailGlue(phrase) + '</span>').join('');
  };

  function renderChildren(children: GrammarElement[], ctx: Ctx, path: string) {
    return (children || []).map((child, i) => render(child, { ...ctx, depth: ctx.depth + 1 }, `${path}[${i}]`)).join('');
  }
  function render(node: GrammarElement, ctx: Ctx, path: string): string {
    if (!node || typeof node !== 'object' || !SCHEMA[node.t]) { err(path, `unknown element type ${JSON.stringify(node?.t)}; use one of ${ELEMENT_TYPES.join(', ')}`); return ''; }
    const schema = SCHEMA[node.t];
    stats.nodes++; stats.byType[node.t] = (stats.byType[node.t] || 0) + 1; stats.maxDepth = Math.max(stats.maxDepth, ctx.depth);
    if (ctx.depth > 8) { err(path, 'nested too deeply (limit 8)'); return ''; }
    for (const key of schema.req) if (node[key] === undefined) { err(path, `${node.t} needs "${key}"`); return ''; }
    for (const [key, value] of Object.entries(node)) {
      const check = schema.props[key] || COMMON[key];
      if (!check) { err(`${path}.${key}`, `${node.t} has no property "${key}"; allowed: ${[...Object.keys(schema.props), 'max', 'self', 'narrowOrder'].join(', ')}`); return ''; }
      if (!check(value)) { err(`${path}.${key}`, `invalid value ${JSON.stringify(value).slice(0, 80)}${check.values ? '; use one of ' + check.values.join(' | ') : check.hint ? '; use ' + check.hint : ''}`); return ''; }
    }
    const order = node.narrowOrder ? ' bnl-o' + node.narrowOrder : '', blk = BLOCKS.has(node.t) ? ' bnl-blk' : '';
    switch (node.t) {
      case 'stack': {
        const cls = 'bnl-flow' + (node.gap !== undefined ? ' bnl-gap-' + node.gap : '') + (node.align ? ' bnl-al-' + node.align : '') + (node.justify ? ' bnl-jc-' + node.justify : '');
        return `<div class="${cls}${blk}${common(node)}${order}">${renderChildren(node.children, { ...ctx, w: Math.min(ctx.w, MAXES[node.max] || Infinity) }, path + '.children')}</div>`;
      }
      case 'row': {
        const [rg, cg] = gapPx(node.gap, 5), collapse = node.collapse || 'md', n = node.children.length;
        const fixed = node.children.reduce((sum: number, c: GrammarElement) => sum + (MAXES[c.max] || 0), 0), flexible = node.children.filter((c: GrammarElement) => !MAXES[c.max]).length || 1;
        const share = Math.max(200, (ctx.w - fixed - cg * (n - 1)) / flexible);
        const css = `{justify-content:${({ start: 'flex-start', center: 'center', end: 'flex-end', between: 'space-between' } as Record<string, string>)[node.justify || 'start']};align-items:${({ start: 'flex-start', center: 'center', end: 'flex-end', baseline: 'baseline', stretch: 'stretch' } as Record<string, string>)[node.align || 'start']};gap:${rg}px ${cg}px${node.wrap ? ';flex-wrap:wrap' : ''}${node.rule === 'top' ? ';padding-top:23px;border-top:1px solid var(--ln)' : ''}}`;
        const cls = instance('r', css + (collapse === 'none' ? '' : `@${BP[collapse]}{flex-direction:column;align-items:flex-start;gap:${Math.min(rg, 24) || 14}px}`));
        const phone = collapse === 'none' && n > 1 ? { mf: ctx.mf / n, ms: ctx.ms / n + cg * (n - 1) / n } : {};
        return `<div class="bnl-l-row ${cls}${blk}${common(node)}${order}">${node.children.map((c: GrammarElement, i: number) => render(c, { ...ctx, ...phone, depth: ctx.depth + 1, w: MAXES[c.max] || share }, `${path}.children[${i}]`)).join('')}</div>`;
      }
      case 'grid': {
        const weights: number[] = Array.isArray(node.cols) ? node.cols : Array(node.cols).fill(1), n = weights.length, total = weights.reduce((a, b) => a + b, 0), [rg, cg] = gapPx(node.gap, 5);
        if (node.children.length < 2) warn(path, 'a grid with fewer than two children is just a container');
        const collapse: Record<string, number> = node.collapse === 'none' ? {} : node.collapse || (n === 2 ? { md: 1 } : n === 3 ? { lg: 2, sm: 1 } : { lg: 2, sm: 1 });
        let css = `{grid-template-columns:${weights.map(w => `minmax(0,${w}fr)`).join(' ')};gap:${rg}px ${cg}px;align-items:${node.align || 'stretch'}}`;
        const points = Object.entries(collapse).sort((a, b) => BP[b[0]] - BP[a[0]]);
        points.forEach(([bp, count], i) => {
          css += `@${BP[bp]}{grid-template-columns:repeat(${count},minmax(0,1fr))${count === 1 ? `;gap:${Math.min(rg || cg, 34) || 24}px` : `;gap:${Math.min(rg, 24)}px ${Math.min(cg, 24)}px`}}`;
          if (i === 0) for (const k of new Set(node.children.map((c: GrammarElement) => c?.narrowOrder).filter(Boolean))) css += `@${BP[bp]}>.bnl-o${k}{order:${k}}`;
        });
        const cls = instance('g', css), inner = (ctx.w - cg * (n - 1));
        // How many columns survive on a phone decides how much width a child has there.
        const kept = node.collapse === 'none' ? n : collapse.sm ?? collapse.md ?? collapse.lg ?? n, phoneGap = Math.min(cg, 24);
        const phone = kept > 1 ? { mf: ctx.mf / kept, ms: ctx.ms / kept + phoneGap * (kept - 1) / kept } : {};
        return `<div class="bnl-l-grid ${cls}${blk}${common(node)}${order}">${node.children.map((c: GrammarElement, i: number) => render(c, { ...ctx, ...phone, depth: ctx.depth + 1, w: inner * weights[i % n] / total }, `${path}.children[${i}]`)).join('')}</div>`;
      }
      case 'card': {
        const fill = node.fill || 'soft', pad = node.pad ?? 5, clickable = !!node.href;
        if (clickable && JSON.stringify(node.children).match(/"t":"(link|actions)"/)) { err(path, 'a card with href is itself a link, so it cannot contain link or actions elements'); return ''; }
        if (node.media?.ratio) checkRatio(path + '.media', node.media.image, node.media.ratio, node.media.fit);
        const media = node.media ? `<div class="bnl-l-card-media ${ratioClass(node.media.ratio || '3:2')}${node.media.fit === 'contain' ? ' bnl-fit-contain' : ''}">${img(path + '.media.image', node.media.image, { purpose: 'card-media', ratio: node.media.ratio || '3:2', fit: node.media.fit || 'cover' })}</div>` : '';
        if (node.media && node.media.ratio && !RATIOS.includes(node.media.ratio)) err(path + '.media.ratio', 'use one of ' + RATIOS.join(' | '));
        const phonePad = pad >= 8 ? px(6) : pad >= 6 ? px(5) : px(pad);
        const body = renderChildren(node.children, { ...ctx, w: ctx.w - 2 * px(pad), ms: ctx.ms + 2 * phonePad, inCard: true, tone: fill === 'accent' ? 'accent' : ctx.tone }, path + '.children');
        const numbered = node.children[0]?.t === 'number' ? ' bnl-numbered' : '', tag = clickable ? 'a' : 'div';
        return `<${tag} class="bnl-l-card bnl-fill-${fill}${node.border ? ' bnl-line' : ''}${media ? ' bnl-has-media' : ''}${blk}${common(node)}${order}"${clickable ? ` href="${href(path + '.href', node.href)}"` : ''}>${media}<div class="bnl-l-card-body bnl-flow bnl-pad-${pad}${numbered}">${body}</div></${tag}>`;
      }
      case 'figure': {
        if (!node.image && !node.pending) { err(path, 'a figure needs "image", or "pending": true to have one generated'); return ''; }
        if (node.caption) budget(path + '.caption', 'caption', node.caption);
        checkRatio(path, node.image, node.ratio, node.fit);
        return `<figure class="bnl-l-fig ${ratioClass(node.ratio)}${node.fit === 'cover' ? ' bnl-fit-cover' : ''}${node.stretch ? ' bnl-stretch' : ''}${blk}${common(node)}${order}">${img(path + '.image', node.image, { purpose: 'figure', ratio: node.ratio, fit: node.fit })}${node.caption ? `<figcaption>${esc(node.caption)}</figcaption>` : ''}</figure>`;
      }
      case 'media': {
        if (!node.image && !node.pending) { err(path, 'a media element needs "image", or "pending": true to have one generated'); return ''; }
        const split = node.split || [1, 1], bp = BP[node.collapse || 'md'], narrow = node.narrow || 'stack', side = node.side || 'left';
        checkRatio(path, node.image, node.ratio, node.fit);
        let css = `{grid-template-columns:minmax(0,${side === 'left' ? split[0] : split[1]}fr) minmax(0,${side === 'left' ? split[1] : split[0]}fr)}`;
        css += narrow === 'card'
          ? `@${bp}{grid-template-columns:minmax(0,1fr);grid-template-rows:auto 1fr;gap:0;align-items:stretch;overflow:hidden;border:1px solid var(--ln);border-radius:var(--r-card);background:var(--media-card)}@${bp}>.bnl-l-fig{order:0;border:0;border-radius:0}@${bp}>.bnl-l-fig img{border-radius:0}@${bp}>.bnl-l-media-body{display:flex;flex-direction:column;padding:24px}`
          : `@${bp}{grid-template-columns:minmax(0,1fr);gap:24px}@${bp}>.bnl-l-fig{order:0}`;
        const cls = instance('m', css), w = (ctx.w - 24) * split[1] / (split[0] + split[1]);
        if (node.caption) budget(path + '.caption', 'caption', node.caption);
        return `<div class="bnl-l-media bnl-side-${side} ${cls}${blk}${common(node)}${order}"><figure class="bnl-l-fig ${ratioClass(node.ratio)}${node.fit === 'cover' ? ' bnl-fit-cover' : ''}">${img(path + '.image', node.image, { purpose: 'media', ratio: node.ratio, fit: node.fit })}${node.caption ? `<figcaption>${esc(node.caption)}</figcaption>` : ''}</figure><div class="bnl-l-media-body bnl-flow">${renderChildren(node.children, { ...ctx, w, ms: ctx.ms + (narrow === 'card' ? 48 : 0) }, path + '.children')}</div></div>`;
      }
      case 'cover': {
        if (!node.image && !node.pending) { err(path, 'a cover needs "image", or "pending": true to have one generated'); return ''; }
        if (node.bleed && !ctx.bleedSlot) { err(path, 'a bleed cover must be the first element of its section body'); return ''; }
        const body = renderChildren(node.children, { ...ctx, w: Math.min(ctx.w - 128, 680), ms: ctx.ms + 40, tone: 'cover' }, path + '.children');
        return `<div class="bnl-l-cover bnl-h-${node.height || 'l'} bnl-scrim-${node.scrim || 'left'} bnl-place-${node.place || 'bottom-left'}${node.bleed ? ' bnl-bleed' : ''}${blk}${order}">${img(path + '.image', node.image, { purpose: 'cover', ratio: node.ratio, fit: 'cover' })}<div class="bnl-l-cover-in"><div class="bnl-l-cover-body bnl-flow">${body}</div></div></div>`;
      }
      case 'kicker': budget(path, 'kicker', node.text); return `<span class="bnl-t-kicker${cjk(node.text)}${order}">${esc(node.text)}</span>`;
      case 'display': {
        displays++; const size = node.size || 'l';
        const fit = fitLines(path, 'display', size, node.lines, ctx, true);
        return `<h1 class="bnl-t-display bnl-sz-${size}${cjk(node.lines.join(''))}${fit}${common(node)}${order}">${node.lines.map((line: string) => `<span class="bnl-t-line">${esc(line)}</span>`).join(' ')}</h1>`;
      }
      case 'title': {
        if (!node.lines && !node.text) { err(path, 'title needs "lines" or "text"'); return ''; }
        const size = node.size || (ctx.inCard ? 's' : 'l'), level = node.level || (size === 's' || size === 'm' || ctx.inCard ? 3 : 2), all = node.lines ? node.lines.join('') : node.text;
        let fit = '', computed: string[] = [];
        if (node.lines) fit = fitLines(path, 'title', size, node.lines, ctx, false);
        else {
          const [font, letter, maxW] = SIZES.title[size], fontPx = font * (theme?.typeScale || 1), avail = Math.min(ctx.w, maxW || Infinity);
          const est = textWidth(node.text, fontPx) / avail;
          if (est > 3.2) warn(path, `this title would run to about ${Math.ceil(est)} lines here; shorten it or use explicit "lines"`);
          computed = breakLines(node.text, fontPx, CJK.test(node.text) ? -.01 * fontPx : letter * (theme?.tracking ?? 1), avail);
          if (est > 1.02 && computed.length === 0) warn(path, 'this title would wrap and leave a very short last line; rephrase it or set explicit "lines"');
          if (ctx.inCard) budget(path, 'cardTitle', node.text);
        }
        const inner = node.lines
          ? node.lines.map((line: string) => `<span class="bnl-t-line">${esc(line)}</span>`).join(' ')
          : computed.length > 1 ? computed.map((line: string) => `<span class="bnl-t-line bnl-t-soft">${esc(line)}</span>`).join(' ') : withPhrases(node.text);
        return `<h${level} class="bnl-t-title bnl-sz-${size}${cjk(all)}${fit}${common(node)}${order}">${inner}</h${level}>`;
      }
      case 'text': { const role = node.role || 'body'; budget(path, role, node.text); if (ctx.w < 150 && [...node.text].length > 16) warn(path, `this text sits in a column only about ${Math.round(ctx.w)}px wide; it will run to many short lines`); return role === 'meta' ? `<span class="bnl-t-meta${common(node)}${order}">${esc(node.text)}</span>` : `<p class="bnl-t-${role}${common(node)}${order}">${withPhrases(node.text)}</p>`; }
      case 'number': { const need = textWidth(node.text, 30) + 4; if (ctx.w < need) err(path, `the column holding this numeral is about ${Math.round(ctx.w)}px wide but the numeral needs ${Math.round(need)}px; give that column more weight or put the numeral above the text`); return `<span class="bnl-t-number${order}" aria-hidden="true">${esc(node.text)}</span>`; }
      case 'actions': {
        const items = node.items.map((item: any, i: number) => {
          const p = `${path}.items[${i}]`;
          if (!item || !str(60)(item.label) || !str(200)(item.href) || !['primary', 'link'].includes(item.kind)) { err(p, 'each action needs label, href and kind (primary | link)'); return ''; }
          budget(p, item.kind === 'primary' ? 'button' : 'link', item.label);
          return `<a class="${item.kind === 'primary' ? 'bnl-l-btn' : 'bnl-l-link'}" href="${href(p + '.href', item.href)}">${esc(item.label)}<i class="bnl-l-ico" aria-hidden="true"></i></a>`;
        });
        if (node.items.filter((i: any) => i?.kind === 'primary').length > 1) warn(path, 'two primary buttons compete; make the second one a link');
        return `<div class="bnl-l-actions${order}">${items.join('')}</div>`;
      }
      case 'link': budget(path, 'link', node.label); return `<a class="bnl-l-link${order}" href="${href(path + '.href', node.href)}">${esc(node.label)}<i class="bnl-l-ico" aria-hidden="true"></i></a>`;
      case 'list': {
        node.items.forEach((item: string, i: number) => budget(`${path}.items[${i}]`, 'listItem', item));
        const numbered = node.marker === 'number';
        const items = node.items.map((item: string, i: number) => (numbered ? `<li><span class="bnl-l-num">${String(i + 1).padStart(2, '0')}</span>${esc(item)}</li>` : `<li>${esc(item)}</li>`)).join('');
        return `<${numbered ? 'ol' : 'ul'} class="bnl-l-list${numbered ? ' bnl-numbered' : ''}${blk}${common(node)}${order}">${items}</${numbered ? 'ol' : 'ul'}>`;
      }
      case 'faq': node.items.forEach((item: any, i: number) => { budget(`${path}.items[${i}].q`, 'question', item.q); budget(`${path}.items[${i}].a`, 'answer', item.a); }); return `<div class="bnl-l-faq${blk}${common(node)}${order}">${node.items.map((item: any) => `<details><summary>${esc(item.q)}</summary><p>${esc(item.a)}</p></details>`).join('')}</div>`;
      case 'form': {
        if (node.title) budget(path + '.title', 'cardTitle', node.title);
        const ref = String(node.ref || 'contact');
        if (!/^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/.test(ref)) { err(path + '.ref', 'the form reference needs letters, digits, hyphens or underscores'); return ''; }
        formRefs.add(ref);
        // The CMS replaces this node with the site's native inquiry form.
        return `<div class="bnl-l-form${blk}${common(node)}${order}">${node.title ? `<h3 class="bnl-t-title bnl-sz-s">${esc(node.title)}</h3>` : ''}${node.note ? `<p class="bnl-t-small">${esc(node.note)}</p>` : ''}<div class="bnl-form-slot" data-aacms="form" data-form="${esc(ref)}"></div></div>`;
      }
      case 'rule': return `<hr class="bnl-l-rule${blk}${order}">`;
    }
    return '';
  }

  let body = '';
  const sections = Array.isArray(doc?.sections) ? doc!.sections : [];
  if (!theme) err('brand', 'the brand system is invalid, so nothing was compiled');
  if (sections.length < 3 || sections.length > 10) err('sections', `a page has 3 to 10 sections (got ${sections.length})`);
  const ids = new Set<string>();
  if (theme) sections.forEach((section, i) => {
    const path = `sections[${i}]`;
    if (!section || !/^[a-z][a-z0-9-]{0,23}$/.test(String(section.id))) { err(path + '.id', 'needs an id of lowercase letters, digits and hyphens'); return; }
    if (ids.has(section.id)) err(path + '.id', 'duplicate section id'); ids.add(section.id);
    for (const key of Object.keys(section)) if (!['id', 'tone', 'space', 'gap', 'body'].includes(key)) err(`${path}.${key}`, 'a section has only id, tone, space, gap and body');
    if (section.gap !== undefined && !tok(section.gap)) { err(path + '.gap', 'use a spacing step 0 to 9'); return; }
    const tone = section.tone || 'paper', space = section.space || 'normal';
    if (!TONES.includes(tone)) { err(path + '.tone', 'use one of ' + TONES.join(' | ')); return; }
    if (!SPACES.includes(space)) { err(path + '.space', 'use one of ' + SPACES.join(' | ')); return; }
    if (!Array.isArray(section.body) || !section.body.length) { err(path + '.body', 'needs at least one element'); return; }
    stats.sections++;
    frameSection = section.id; frameCount = 0;
    const ctx: Ctx = { tone, depth: 1, inCard: false, w: Math.min(theme.container, VIEW - 2 * GUTTER), mf: 1, ms: 40 };
    let nodes = section.body, lead = '';
    if (nodes[0]?.t === 'cover' && nodes[0].bleed) { lead = render(nodes[0], { ...ctx, w: VIEW - 2 * GUTTER, bleedSlot: true }, `${path}.body[0]`); nodes = nodes.slice(1); }
    const rest = nodes.map((node, k) => render(node, { ...ctx, depth: 2 }, `${path}.body[${k + (lead ? 1 : 0)}]`)).join('');
    body += `<section class="bnl-l-sec bnl-tone-${tone} bnl-space-${space}${lead ? (rest ? ' bnl-has-bleed' : ' bnl-only-bleed') : ''}" id="${esc(section.id)}">${lead}${rest ? `<div class="bnl-l-wrap bnl-flow${section.gap !== undefined ? ' bnl-gap-' + section.gap : ''}">${rest}</div>` : ''}</section>`;
  });
  if (theme && displays !== 1) err('sections', `a page has exactly one display heading (found ${displays})`);
  // Page-level composition checks.
  const tones = sections.map(s => s?.tone || 'paper');
  tones.forEach((tone, i) => { if (i >= 2 && tone === tones[i - 1] && tone === tones[i - 2]) warn(`sections[${i}].tone`, 'three sections in a row share one tone; vary the rhythm'); });
  if (tones.filter(t => t === 'dark' || t === 'accent').length > 3) warn('sections', 'more than three dark or accent sections; they stop reading as emphasis');
  for (const [id, count] of used) if (count > 1) warn('images.' + id, `image used ${count} times; each picture should appear once`);

  const sharedCss = theme ? buildSharedCss(theme) : '';
  const pageCss = theme ? buildInstanceCss(rules) : '';
  const css = sharedCss + pageCss;
  const rootClass = theme ? theme.rootClass : 'bnl';
  const main = `<main class="${rootClass}">${body}</main>`;
  stats.instanceRules = rules.size;
  stats.cssBytes = bytes(css);
  stats.htmlBytes = bytes(main);
  stats.imagesUnused = Object.keys(images).filter(id => !used.has(id));
  stats.forms = [...formRefs].sort();
  stats.pendingFrames = [...pendingFrames].sort();
  return { body: main, sharedCss, pageCss, css, rootClass, issues, stats, frames, ok: !issues.some(i => i.level === 'error') };
}

function buildSharedCss(theme: ResolvedBrand) {
  return `.bnl{${Object.entries(theme.vars).map(([k, v]) => `--${k}:${v}`).join(';')}}` + BASE_CSS + NARROW_CSS;
}
/** Instance rules carry one extra class, so a specific element always outranks the shared rules.
 * "{…}" is the element itself, "@960{…}" a width limit, "@960>.x{…}" a child inside it. */
function buildInstanceCss(rules: Map<string, string>) {
  let css = '';
  const byWidth = new Map<string, string>();
  for (const [text, cls] of rules) {
    for (const part of text.match(/(?:@\d+(?:>[^{]+)?)?\{[^}]*\}/g) || []) {
      const m = /^(?:@(\d+)(>[^{]+)?)?(\{[^}]*\})$/.exec(part)!;
      if (!m[1]) css += `.bnl .${cls}${m[3]}`;
      else { if (!byWidth.has(m[1])) byWidth.set(m[1], ''); byWidth.set(m[1], byWidth.get(m[1])! + `.bnl .${cls}${m[2] || ''}${m[3]}`); }
    }
  }
  for (const width of [...byWidth.keys()].sort((a, b) => Number(b) - Number(a))) css += `@media(max-width:${width}px){${byWidth.get(width)}}`;
  return css;
}

// Box sizing and the page ground are scoped to the root class: a CMS page template shares the
// document with the site header, and nothing here may reach outside its own subtree.
const BASE_CSS = `
.bnl,.bnl *,.bnl *::before,.bnl *::after{box-sizing:border-box}
.bnl{font-family:var(--f-body);font-size:18px;line-height:1.65;font-weight:400;color:var(--ink);background:var(--paper);overflow-wrap:break-word}
:where(.bnl) :is(h1,h2,h3,p,figure,ul,ol){margin:0;padding:0;font-weight:inherit}
:where(.bnl) a{color:inherit;text-decoration:none}
:where(.bnl) img{display:block;max-width:100%;height:auto}
.bnl :is(a,summary):focus-visible{outline:3px solid var(--accent);outline-offset:4px}
.bnl-l-sec{--bg:var(--paper);--fg:var(--ink);--cp:var(--copy);--ln:var(--line);--card:var(--card-soft);--card2:var(--card-strong);--surf:var(--surface);--kick:var(--kicker);--cap:var(--caption);--lnk:var(--link);--lnkln:var(--link-line);--num:var(--number);--figbg:var(--fig-bg);--btn-bg:var(--accent);--btn-fg:var(--accent-ink);--btn-hv:var(--accent-hover);background:var(--bg);color:var(--fg);padding-block:var(--sec-pad)}
.bnl-tone-tint{--bg:var(--tint)}
.bnl-tone-dark{--bg:var(--dark);--fg:var(--dark-ink);--cp:var(--dark-copy);--ln:var(--dark-line);--card:var(--dark-card);--card2:var(--dark-card);--surf:var(--dark-card);--kick:var(--dark-kicker);--cap:var(--dark-copy);--lnk:var(--dark-ink);--lnkln:var(--dark-link-line);--num:var(--mark);--figbg:var(--dark-card)}
.bnl-tone-accent{--bg:var(--accent);--fg:var(--accent-ink);--cp:var(--accent-ink);--ln:var(--accent-line);--card:var(--accent-deep);--card2:var(--accent-deep);--surf:var(--accent-deep);--kick:var(--accent-ink);--cap:var(--accent-ink);--lnk:var(--accent-ink);--lnkln:var(--accent-ink);--num:var(--accent-ink);--figbg:var(--accent-deep);--btn-bg:var(--accent-ink);--btn-fg:var(--accent);--btn-hv:var(--accent-tint)}
.bnl-space-hero{padding:44px 0 28px}
.bnl-space-band{padding-block:74px}
.bnl-l-sec.bnl-has-bleed{padding-top:0}.bnl-l-sec.bnl-has-bleed>.bnl-l-wrap{margin-top:var(--r-block)}.bnl-l-sec.bnl-only-bleed{padding:0}
.bnl-l-wrap{width:calc(100% - 80px);max-width:var(--container);margin-inline:auto}
.bnl-flow{display:flex;flex-direction:column;align-items:flex-start;min-width:0}
.bnl-flow>*{max-width:100%}
.bnl-flow>.bnl-blk{align-self:stretch}
.bnl-flow>*+*{margin-top:var(--r-default)}
.bnl-flow>*+.bnl-t-lead{margin-top:var(--r-lead)}
.bnl-flow>*+.bnl-t-body{margin-top:var(--r-body)}
.bnl-flow>.bnl-t-body+.bnl-t-body{margin-top:var(--r-para)}
.bnl-flow>*+.bnl-l-actions{margin-top:var(--r-actions)}
.bnl-flow>*+.bnl-l-link{margin-top:var(--r-link)}
.bnl-flow>*+.bnl-t-caption{margin-top:var(--r-caption)}
.bnl-flow>*+.bnl-blk{margin-top:var(--r-block)}
.bnl-flow>.bnl-t-number+*{margin-top:var(--r-number)}
.bnl-flow>.bnl-t-meta+*{margin-top:var(--r-meta)}
.bnl-flow>.bnl-t-kicker+*{margin-top:var(--r-kicker)}
.bnl-flow.bnl-gap-0>*+*{margin-top:0}.bnl-flow.bnl-gap-1>*+*{margin-top:var(--s1)}.bnl-flow.bnl-gap-2>*+*{margin-top:var(--s2)}.bnl-flow.bnl-gap-3>*+*{margin-top:var(--s3)}.bnl-flow.bnl-gap-4>*+*{margin-top:var(--s4)}.bnl-flow.bnl-gap-5>*+*{margin-top:var(--s5)}.bnl-flow.bnl-gap-6>*+*{margin-top:var(--s6)}.bnl-flow.bnl-gap-7>*+*{margin-top:var(--s7)}.bnl-flow.bnl-gap-8>*+*{margin-top:var(--s8)}.bnl-flow.bnl-gap-9>*+*{margin-top:var(--s9)}
.bnl-flow.bnl-al-center{align-items:center;text-align:center}.bnl-flow.bnl-al-end{align-items:flex-end;text-align:right}.bnl-flow.bnl-al-stretch{align-items:stretch}
.bnl-flow.bnl-jc-center{justify-content:center}.bnl-flow.bnl-jc-end{justify-content:flex-end}.bnl-flow.bnl-jc-between{justify-content:space-between}
.bnl-self-start{align-self:start;justify-self:start}.bnl-self-center{align-self:center;justify-self:center}.bnl-self-end{justify-self:end}.bnl-self-stretch{align-self:stretch}
.bnl-l-row{display:flex;min-width:0}.bnl-l-row>*{min-width:0}.bnl-l-row>:is(.bnl-t-kicker,.bnl-t-meta,.bnl-l-btn,.bnl-l-link){flex:none}
.bnl-l-grid{display:grid;min-width:0}.bnl-l-grid>*{min-width:0}
.bnl-t-kicker{display:block;font-size:12px;line-height:1.6;letter-spacing:1.1px;text-transform:uppercase;color:var(--kick)}
.bnl-k-square .bnl-t-kicker::before{content:"";display:inline-block;width:6px;height:6px;margin-right:9px;background:var(--mark);vertical-align:middle}
.bnl-k-dot .bnl-t-kicker::before{content:"";display:inline-block;width:7px;height:7px;margin-right:9px;border-radius:50%;background:var(--mark);vertical-align:middle}
.bnl-k-line .bnl-t-kicker::before{content:"";display:inline-block;width:28px;height:1px;margin-right:12px;background:currentColor;vertical-align:middle}
.bnl-t-display,.bnl-t-title{font-family:var(--f-head);font-weight:var(--fw-head);color:var(--fg)}
.bnl-t-display.bnl-sz-xl{font-size:calc(var(--ts)*clamp(48px,5.2vw,76px));line-height:1.04;letter-spacing:calc(var(--tk)*-3.6px)}
.bnl-t-display.bnl-sz-l{font-size:calc(var(--ts)*clamp(40px,4.2vw,60px));line-height:1.14;letter-spacing:calc(var(--tk)*-.035em);max-width:620px}
.bnl-t-title.bnl-sz-xl{font-size:calc(var(--ts)*clamp(42px,5.1vw,72px));line-height:1.12;letter-spacing:calc(var(--tk)*-2.6px);max-width:850px}
.bnl-t-title.bnl-sz-l{font-size:calc(var(--ts)*clamp(34px,3.8vw,54px));line-height:1.12;letter-spacing:calc(var(--tk)*-1.8px);max-width:760px}
.bnl-t-title.bnl-sz-m{font-size:calc(var(--ts)*30px);line-height:1.15;letter-spacing:calc(var(--tk)*-.8px)}
.bnl-t-title.bnl-sz-s{font-size:calc(var(--ts)*26px);line-height:1.25;letter-spacing:calc(var(--tk)*-.6px)}
.bnl-t-line{display:block}
.bnl-t-phrase{display:inline-block;max-width:100%;white-space:normal;word-break:normal;overflow-wrap:anywhere;vertical-align:top}
.bnl-t-glue{white-space:nowrap;max-width:100%}
.bnl-t-tail{display:inline-block;max-width:100%;white-space:normal;word-break:normal;overflow-wrap:anywhere;vertical-align:top}
.bnl-t-lead{font-size:20px;line-height:1.65;max-width:650px;color:var(--cp)}
.bnl-t-body{color:var(--cp)}
.bnl-t-small{font-size:16px;color:var(--cp)}
.bnl-t-caption{font-size:12px;line-height:1.5;letter-spacing:.35px;color:var(--cap)}
.bnl-t-meta{display:block;font-size:12px;letter-spacing:.6px;color:var(--kick)}
.bnl-t-number{display:block;flex:none;font-size:30px;line-height:1;white-space:nowrap;color:var(--num)}
.bnl-cjk.bnl-t-display,.bnl-cjk.bnl-t-title{letter-spacing:-.01em}.bnl-cjk.bnl-t-display.bnl-sz-xl{line-height:1.16}.bnl-cjk.bnl-t-display.bnl-sz-l{line-height:1.24}.bnl-cjk.bnl-t-title.bnl-sz-xl,.bnl-cjk.bnl-t-title.bnl-sz-l{line-height:1.26}.bnl-cjk.bnl-t-title.bnl-sz-m,.bnl-cjk.bnl-t-title.bnl-sz-s{line-height:1.36}
.bnl-cjk.bnl-t-kicker{font-size:13px;letter-spacing:.12em}
.bnl-l-actions{display:flex;flex-wrap:wrap;align-items:center;gap:12px 14px}
.bnl-l-btn{display:inline-flex;align-items:center;justify-content:center;gap:18px;min-height:52px;padding:12px 23px;border:1px solid transparent;border-radius:var(--r-btn);background:var(--btn-bg);color:var(--btn-fg);line-height:1.5;text-align:center;transition:background-color .18s}
.bnl-l-btn:hover{background:var(--btn-hv)}
.bnl-l-link{display:inline-flex;align-items:center;justify-content:space-between;gap:20px;min-height:48px;max-width:100%;padding-block:10px;border-bottom:1px solid var(--lnkln);color:var(--lnk)}
.bnl-l-link:hover{border-bottom-color:currentColor}
.bnl-l-ico{position:relative;flex:none;width:20px;height:20px}
.bnl-l-ico::before{content:"";box-sizing:border-box;position:absolute;right:3.55px;top:3.55px;width:12.3px;height:12.3px;border:solid currentColor;border-width:1.25px 1.25px 0 0}
.bnl-l-ico::after{content:"";position:absolute;left:1.75px;top:9.38px;width:16.5px;height:1.25px;background:currentColor;transform:rotate(-45deg)}
.bnl-lk-arrow .bnl-l-link{gap:10px;min-height:44px;border-bottom:0}
.bnl-lk-plain .bnl-l-link{min-height:44px;border-bottom:0;text-decoration:underline;text-underline-offset:6px;text-decoration-thickness:1px}.bnl-lk-plain .bnl-l-link .bnl-l-ico{display:none}
.bnl-l-fig{margin:0;min-width:0;overflow:hidden;background:var(--figbg);border:1px solid var(--ln);border-radius:var(--r-fig)}
.bnl-l-fig img{width:100%;height:auto;object-fit:contain}
.bnl-l-fig.bnl-fit-cover img{object-fit:cover}
.bnl-l-fig figcaption{display:block;padding:13px 18px;font-size:12px;line-height:1.5;letter-spacing:.35px;color:var(--cap)}
.bnl-l-fig.bnl-stretch{display:flex;flex-direction:column;height:100%}.bnl-l-fig.bnl-stretch figcaption{margin-top:auto}
.bnl-ar-4x3 img{aspect-ratio:4/3}.bnl-ar-3x2 img{aspect-ratio:3/2}.bnl-ar-16x9 img{aspect-ratio:16/9}.bnl-ar-1x1 img{aspect-ratio:1}.bnl-ar-3x4 img{aspect-ratio:3/4}.bnl-ar-21x9 img{aspect-ratio:21/9}
.bnl-fg-plain .bnl-l-fig{overflow:visible;border:0;background:transparent}.bnl-fg-plain .bnl-l-fig img{border-radius:var(--r-fig)}.bnl-fg-plain .bnl-l-fig figcaption{padding:12px 0 0}
.bnl-fg-edge .bnl-l-fig{border:0;border-radius:0;background:transparent}.bnl-fg-edge .bnl-l-fig figcaption{padding:10px 0 0}
.bnl-l-card{display:flex;flex-direction:column;min-width:0;overflow:hidden;border-radius:var(--r-card);color:inherit}
.bnl-l-card.bnl-has-media{border-radius:var(--r-fig)}
.bnl-fill-soft{background:var(--card)}.bnl-fill-strong{background:var(--card2)}.bnl-fill-surface{background:var(--surf)}
.bnl-fill-accent{--fg:var(--accent-ink);--cp:var(--accent-copy);--kick:var(--accent-kicker);--cap:var(--accent-copy);--lnk:var(--accent-ink);--lnkln:var(--accent-ink);--num:var(--accent-ink);--ln:var(--accent-line);background:var(--accent-deep);color:var(--accent-ink)}
.bnl-l-card.bnl-line{border:1px solid var(--ln)}
.bnl-cd-outline .bnl-l-card.bnl-fill-soft,.bnl-cd-outline .bnl-l-card.bnl-fill-strong{border:1px solid var(--ln);background:transparent}
.bnl-l-card-body{flex:1;padding:var(--bnl-pad,24px)}
.bnl-pad-0{--bnl-pad:0px}.bnl-pad-1{--bnl-pad:var(--s1)}.bnl-pad-2{--bnl-pad:var(--s2)}.bnl-pad-3{--bnl-pad:var(--s3)}.bnl-pad-4{--bnl-pad:var(--s4)}.bnl-pad-5{--bnl-pad:var(--s5)}.bnl-pad-6{--bnl-pad:var(--s6)}.bnl-pad-7{--bnl-pad:var(--s7)}.bnl-pad-8{--bnl-pad:var(--s8)}.bnl-pad-9{--bnl-pad:var(--s9)}
.bnl-l-card-body>.bnl-l-link:last-child{margin-top:auto;padding-top:24px}
.bnl-l-card-media{position:relative;display:block;overflow:hidden;background:var(--media-bg)}
.bnl-l-card-media.bnl-ar-4x3{aspect-ratio:4/3}.bnl-l-card-media.bnl-ar-3x2{aspect-ratio:3/2}.bnl-l-card-media.bnl-ar-16x9{aspect-ratio:16/9}.bnl-l-card-media.bnl-ar-1x1{aspect-ratio:1}.bnl-l-card-media.bnl-ar-3x4{aspect-ratio:3/4}.bnl-l-card-media.bnl-ar-21x9{aspect-ratio:21/9}
.bnl-l-card-media img{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover}
.bnl-l-card-media.bnl-fit-contain img{object-fit:contain}
.bnl-l-media{display:grid;gap:24px;align-items:center;min-width:0}
.bnl-l-media.bnl-side-right>.bnl-l-fig{order:2}
.bnl-l-media-body{min-width:0}
.bnl-l-media-body>.bnl-l-link:last-child{margin-top:auto}
.bnl-l-cover{--btn-bg:var(--cover-btn-bg);--btn-fg:var(--cover-btn-fg);--btn-hv:var(--cover-btn-hv);--fg:#ffffff;--cp:rgb(255 255 255/.9);--kick:#ffffff;--cap:rgb(255 255 255/.82);--lnk:#ffffff;--lnkln:rgb(255 255 255/.62);--ln:rgb(255 255 255/.32);position:relative;display:flex;min-height:var(--cv-h,600px);overflow:hidden;border-radius:var(--r-fig);isolation:isolate;color:#ffffff}
.bnl-l-cover>img{position:absolute;top:0;left:0;z-index:-2;width:100%;height:100%;object-fit:cover}
.bnl-l-cover::before{content:"";position:absolute;top:0;right:0;bottom:0;left:0;z-index:-1}
.bnl-scrim-left::before{background:linear-gradient(90deg,rgb(0 0 0/.74),rgb(0 0 0/.42) 44%,rgb(0 0 0/0) 76%)}
.bnl-scrim-bottom::before{background:linear-gradient(0deg,rgb(0 0 0/.76),rgb(0 0 0/.34) 44%,rgb(0 0 0/0) 74%)}
.bnl-scrim-full::before{background:rgb(0 0 0/.46)}
.bnl-h-m{--cv-h:440px}.bnl-h-l{--cv-h:600px}.bnl-h-xl{--cv-h:760px}
.bnl-l-cover.bnl-bleed{border-radius:0}
.bnl-l-cover-in{display:flex;width:100%;padding:clamp(24px,4.5vw,64px)}
.bnl-l-cover.bnl-bleed .bnl-l-cover-in{width:calc(100% - 80px);max-width:var(--container);margin-inline:auto;padding-inline:0}
.bnl-place-bottom-left .bnl-l-cover-in{align-items:flex-end;justify-content:flex-start}
.bnl-place-center-left .bnl-l-cover-in{align-items:center;justify-content:flex-start}
.bnl-place-center .bnl-l-cover-in{align-items:center;justify-content:center}
.bnl-l-cover-body{max-width:680px}
.bnl-place-center .bnl-l-cover-body{align-items:center;text-align:center}
.bnl-l-list{display:grid;gap:12px;list-style:none;color:var(--cp)}
.bnl-l-list li{display:grid;grid-template-columns:auto minmax(0,1fr);column-gap:14px}
.bnl-l-list li::before{content:"";width:6px;height:6px;margin-top:.62em;background:var(--mark)}
.bnl-l-list.bnl-numbered li::before{display:none}.bnl-l-num{display:block;line-height:1.6;color:var(--num)}
.bnl-l-faq{border-top:1px solid var(--ln)}
.bnl-l-faq details{border-bottom:1px solid var(--ln)}
.bnl-l-faq summary{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:22px 0;font-size:20px;line-height:1.4;cursor:pointer;list-style:none}
.bnl-l-faq summary::-webkit-details-marker{display:none}
.bnl-l-faq summary::after{content:"+";flex:none;font-size:24px;line-height:1;color:var(--kick)}
.bnl-l-faq details[open] summary::after{content:"−"}
.bnl-l-faq p{max-width:760px;padding:0 0 24px;color:var(--cp)}
.bnl-l-rule{width:100%;height:0;margin:0;border:0;border-top:1px solid var(--ln)}
.bnl-l-form{display:flex;flex-direction:column;gap:16px;padding:24px;border:1px solid var(--ln);border-radius:var(--r-card);background:var(--card)}
.bnl-l-form .bnl-t-title,.bnl-l-form .bnl-t-small{margin:0}
.bnl-form-slot{min-height:160px}

.bnl-mx-xs{max-width:320px}.bnl-mx-narrow{max-width:410px}.bnl-mx-medium{max-width:560px}.bnl-mx-normal{max-width:650px}.bnl-mx-wide{max-width:960px}
`.replace(/\n/g, '');

const NARROW_CSS = `
@media(max-width:960px){.bnl-t-display.bnl-sz-l{font-size:calc(var(--ts)*clamp(44px,6.2vw,54px))}.bnl-l-fig{width:100%;max-width:760px;margin-inline:auto}.bnl-h-xl{--cv-h:620px}}
@media(max-width:760px){
.bnl{font-size:16px;--r-kicker:20px}
.bnl-l-wrap{width:calc(100% - 40px)}
.bnl-l-sec{padding-block:var(--sec-pad-sm)}
.bnl-space-hero{padding:30px 0 28px}.bnl-space-band{padding-block:60px}
.bnl-l-sec.bnl-has-bleed{padding-top:0}.bnl-l-sec.bnl-only-bleed{padding:0}
.bnl-t-display.bnl-sz-xl{font-size:calc(var(--ts)*48px);letter-spacing:calc(var(--tk)*-2.2px)}
.bnl-t-display.bnl-sz-l{font-size:calc(var(--ts)*clamp(34px,9vw,44px))}
.bnl-t-title.bnl-sz-xl{font-size:calc(var(--ts)*46px);letter-spacing:calc(var(--tk)*-2px)}
.bnl-t-title.bnl-sz-l{font-size:calc(var(--ts)*36px);letter-spacing:calc(var(--tk)*-1.3px)}
.bnl-t-title.bnl-sz-m{font-size:calc(var(--ts)*27px)}
.bnl-t-title.bnl-sz-s{font-size:calc(var(--ts)*24px)}
.bnl-cjk.bnl-t-display,.bnl-cjk.bnl-t-title{letter-spacing:-.01em}
.bnl-t-kicker{font-size:11px;letter-spacing:.7px}.bnl-cjk.bnl-t-kicker{font-size:12px}
.bnl-t-lead{font-size:18px}
.bnl-l-fig figcaption{padding:12px 15px;font-size:11px}
.bnl-t-soft{display:inline}
.bnl-l-faq summary{font-size:18px}
.bnl-l-cover-in{padding:24px 20px}.bnl-l-cover.bnl-bleed .bnl-l-cover-in{width:calc(100% - 40px)}
.bnl-h-m{--cv-h:380px}.bnl-h-l{--cv-h:500px}.bnl-h-xl{--cv-h:560px}
.bnl-l-cover.bnl-scrim-left::before{background:linear-gradient(0deg,rgb(0 0 0/.78),rgb(0 0 0/.4) 50%,rgb(0 0 0/.08))}
.bnl-self-end{justify-self:start}.bnl-mx-xs{max-width:100%}
.bnl-pad-6,.bnl-pad-7{--bnl-pad:var(--s5)}.bnl-pad-8,.bnl-pad-9{--bnl-pad:var(--s6)}
.bnl-l-card-body.bnl-numbered{display:grid;grid-template-columns:40px minmax(0,1fr);column-gap:16px;align-items:start}
.bnl-l-card-body.bnl-numbered>*{grid-column:1/-1}
.bnl-l-card-body.bnl-numbered>.bnl-t-number{grid-column:1;margin:0}
.bnl-l-card-body.bnl-numbered>.bnl-t-number+*{grid-column:2;margin-top:0}
}
@media(max-width:360px){.bnl-l-wrap{width:calc(100% - 32px)}.bnl-l-btn{padding-inline:19px}}
@media(prefers-reduced-motion:reduce){.bnl *{transition:none}}
`.replace(/\n/g, '');