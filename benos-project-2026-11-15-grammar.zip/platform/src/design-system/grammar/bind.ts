// Writes generated pictures into the frames the compiled pages asked for. The page keeps its layout:
// only the <img> of that frame receives the real asset, its source and its true pixel size.
import type { GrammarManifestAsset } from './manifest';

export type GrammarImageBinding = { frameId: string; src: string; width: number; height: number; asset: GrammarManifestAsset };
export type GrammarBindingResult = { manifest: Record<string, unknown>; bound: string[]; missing: string[] };

const escapeExpression = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, ch => '\\' + ch);

/** Every binding is applied to the templates that carry that frame id, and declared in the package. */
export function bindGrammarImages(manifest: Record<string, unknown>, bindings: readonly GrammarImageBinding[]): GrammarBindingResult {
  const next = JSON.parse(JSON.stringify(manifest)) as Record<string, any>;
  const bound: string[] = [], missing: string[] = [];
  const assets: any[] = Array.isArray(next.assets) ? next.assets : [];
  for (const binding of bindings) {
    const pattern = new RegExp('<img id="' + escapeExpression(binding.frameId) + '"[^>]*>');
    let placed = false;
    for (const template of next.templates ?? []) {
      const html = String(template?.document?.html ?? '');
      if (!pattern.test(html)) continue;
      template.document.html = html.replace(pattern, (tag: string) => {
        // A pending frame carries no src yet, so the source is inserted when it is absent.
        const withSource = tag.includes(' src="')
          ? tag.replace(/\ssrc="[^"]*"/, ' src="' + binding.src + '"')
          : tag.replace(' id="' + binding.frameId + '"', ' id="' + binding.frameId + '" src="' + binding.src + '"');
        return withSource
          .replace(/\swidth="[^"]*"/, ' width="' + binding.width + '"')
          .replace(/\sheight="[^"]*"/, ' height="' + binding.height + '"');
      });
      placed = true;
    }
    if (!placed) { missing.push(binding.frameId); continue; }
    bound.push(binding.frameId);
    if (!assets.some(asset => asset?.path === binding.asset.path)) assets.push(binding.asset);
  }
  next.assets = assets;
  return { manifest: next, bound, missing };
}
