// The grammar's identity at runtime: the exact compiler, spec and exemplar bytes baked in by
// scripts/design-grammar-identity.mjs. An approval names these digests, so editing the compiler
// invalidates the approval instead of silently changing what a customer's site is built from.
import identity from './source-identity.json';

export type GrammarIdentity = {
  version: string;
  compiler: string;
  spec: string;
  exemplar: string;
  digest: string;
  files: Record<string, string>;
};
export const GRAMMAR_IDENTITY = identity as unknown as GrammarIdentity;
