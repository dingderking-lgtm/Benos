﻿// Turns a compiled bnl-0 site into the AACMS site package the platform ships: header and footer
// templates, one template per page, a navigation menu, and the site-wide stylesheet. The manifest is
// checked against the platform's own contract (modules/template-contract.ts) before it is returned.
import { validateSiteManifest } from '../../modules/template-contract';
import type { Issue } from './brand';
import type { GrammarSite } from './site';
import { compileSite } from './site';

export type GrammarManifestAsset = { path: string; file: string; sha256: string; size: number; media_id?: number };
export type GrammarManifestOptions = {
  name: string;
  slug: string;
  /** Picture files the site owns. The images the pages refer to must be declared here. */
  assets?: GrammarManifestAsset[];
  /** Fixed for reproducible output; the caller decides what date a package carries. */
  createdAt?: string;
  /** A blog is optional: when enabled the package carries the archive and article shells the CMS needs. */
  blog?: { enabled: boolean; title?: string; basePath?: string; description?: string };
  menuName?: string;
};

const escape = (value: unknown) => String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]!));
/** '/about' -> 'about'; '/' -> 'home'. */
const pageKey = (path: string) => (path === '/' ? 'home' : path.slice(1).replace(/[^a-z0-9]+/gi, '-').toLowerCase());
const slugOf = (path: string) => (path === '/' ? 'home' : path.slice(1));

/** The header and footer are real templates of the package, styled from the same brand tokens as the
 *  pages. Navigation is a CMS menu (data-aacms-menu), so the CMS can re-point links on import. */
function chrome(site: GrammarSite, options: GrammarManifestOptions) {
  const links = site.pages.map(page => ({ label: page.title, url: page.path }));
  const nav = `<nav class="bnl-nav" data-aacms="site-navigation" data-aacms-menu="1"><ul class="bnl-nav-list">${links.map(link => `<li><a href="${escape(link.url)}">${escape(link.label)}</a></li>`).join('')}</ul></nav>`;
  const header = `<header class="bnl-site-header"><div class="bnl-chrome-frame"><a class="bnl-site-mark" href="/">${escape(options.name)}</a>${nav}</div></header>`;
  const footer = `<footer class="bnl-site-footer"><div class="bnl-chrome-frame"><p class="bnl-footer-line">${escape(options.name)}</p>${nav}</div></footer>`;
  const css = '.bnl-site-header,.bnl-site-footer{box-sizing:border-box;background:var(--paper);color:var(--ink);font-family:var(--f-body);font-size:16px;line-height:1.6}'
    + '.bnl-site-header{border-bottom:1px solid var(--line)}.bnl-site-footer{border-top:1px solid var(--line);margin-top:0}'
    + '.bnl-chrome-frame{display:flex;align-items:center;justify-content:space-between;gap:24px;width:100%;max-width:var(--container);margin-inline:auto;padding:18px 20px}'
    + '.bnl-site-mark{color:var(--ink);font-family:var(--f-head);font-weight:600;text-decoration:none;letter-spacing:-.01em}'
    + '.bnl-nav-list{display:flex;flex-wrap:wrap;gap:22px;list-style:none;margin:0;padding:0}'
    + '.bnl-nav-list a{color:var(--copy);text-decoration:none}.bnl-footer-line{margin:0;color:var(--copy)}'
    + '@media(max-width:760px){.bnl-chrome-frame{flex-wrap:wrap;gap:12px;padding:14px 20px}.bnl-nav-list{gap:16px}}';
  return { header, footer, css };
}

export type GrammarManifestResult = {
  manifest: Record<string, unknown> | null;
  /** Issues from the grammar compile and from the platform's manifest contract. */
  issues: Issue[];
  ok: boolean;
  pages: { key: string; path: string; templateId: number; frames: string[] }[];
};

/** Builds the package and validates it with `validateSiteManifest` — the same check a real import runs. */
export function compileGrammarManifest(site: GrammarSite, options: GrammarManifestOptions): GrammarManifestResult {
  const issues: Issue[] = [];
  const err = (path: string, message: string) => issues.push({ level: 'error', path, message });
  const compiled = compileSite(site);
  issues.push(...compiled.issues);
  if (compiled.pages.length < 2) err('pages', 'a CMS package needs at least two pages (a home page and one more)');
  if (!compiled.ok) return { manifest: null, issues, ok: false, pages: [] };

  const parts = chrome(site, options);
  const blog = options.blog?.enabled ? { enabled: true, title: options.blog.title ?? 'Blog', basePath: options.blog.basePath ?? 'blog', description: options.blog.description ?? '' } : null;
  const pages: { key: string; path: string; templateId: number; frames: string[] }[] = [];
  const templates: Record<string, unknown>[] = [
    { id: 1, name: 'Header', type: 'header', document: { version: 1, html: parts.header, css: '' } },
    { id: 2, name: 'Footer', type: 'footer', document: { version: 1, html: parts.footer, css: '' } },
  ];
  // The CMS renders the article list and the article body itself; these two shells only carry the
  // native content slot, so a grammar site can sell content without inventing a content model.
  if (blog) {
    const slot = '<div class="bnl-blog-slot" data-aacms="page-content"></div>';
    templates.push(
      { id: 900, name: 'Blog index', type: 'archive', document: { version: 1, html: '<main class="bnl bnl-blog"><section class="bnl-l-sec bnl-tone-paper"><div class="bnl-l-wrap bnl-flow"><h1 class="bnl-t-title bnl-sz-l">' + escape(blog.title) + '</h1>' + slot + '</div></section></main>', css: '' } },
      { id: 901, name: 'Blog article', type: 'single', document: { version: 1, html: '<main class="bnl bnl-blog"><section class="bnl-l-sec bnl-tone-paper"><div class="bnl-l-wrap bnl-flow">' + slot + '</div></section></main>', css: '' } },
    );
  }
  compiled.pages.forEach((page, index) => {
    const templateId = index + 3;
    templates.push({ id: templateId, name: page.title, type: 'page', document: { version: 1, html: page.body, css: page.css } });
    pages.push({ key: pageKey(page.path), path: page.path, templateId, frames: page.frames.map(frame => frame.frameId) });
  });
  // Every form slot a page carries needs a definition in the package, or the CMS has nothing to render.
  const formRefs = [...new Set(compiled.pages.flatMap(page => page.stats.forms))].sort();
  const formDefinitions = formRefs.map(ref => ({
    ref, name: 'Inquiry',
    definition: {
      schema_version: 1,
      fields: [
        { id: 'name', type: 'text', label: 'Name', required: true, step: 1 },
        { id: 'email', type: 'email', label: 'Email', required: true, step: 1 },
        { id: 'phone', type: 'tel', label: 'Phone', step: 1 },
        { id: 'message', type: 'textarea', label: 'What do you need?', required: true, step: 1 },
      ],
    },
  }));
  const brand = site.brand;
  const manifest = {
    format: 'aacms-site-package',
    version: 1,
    created_at: options.createdAt ?? '1970-01-01T00:00:00.000Z',
    root_id: pages[0].templateId,
    templates,
    assets: options.assets ?? [],
    forms: formRefs.map(ref => ({ ref })),
    menus: [{ id: 1, name: options.menuName ?? 'Main', items: site.pages.map((page, index) => ({ id: `m${index + 1}`, type: 'custom', label: page.title, url: page.path, parent_id: null })) }],
    site: {
      name: options.name,
      slug: options.slug,
      version: '1.0.0',
      home: pages[0].key,
      header_template_id: 1,
      footer_template_id: 2,
      navigation_menu_id: 1,
      ...(formDefinitions.length ? { forms: formDefinitions } : {}),
      ...(blog ? { blog: { enabled: true, title: blog.title, base_path: blog.basePath, description: blog.description, page_size: 9, language: 'zh-CN', archive_template_id: 900, single_template_id: 901 } } : {}),
      pages: pages.map(page => ({ key: page.key, title: site.pages.find(entry => pageKey(entry.path) === page.key)!.title, slug: slugOf(page.path), type: 'page', template_id: page.templateId, seo: {} })),
      theme: { global_css: compiled.sharedCss + parts.css, brand_color: brand.colors.accent, brand_background: brand.colors.paper, container_width: brand.space.container, font_family: 'system' },
      settings: {},
    },
  };
  // The platform's own importer check decides whether this package may ship.
  const validation = validateSiteManifest(manifest);
  for (const issue of validation.issues) issues.push({ level: issue.severity === 'warning' ? 'warn' : 'error', path: issue.path, message: `${issue.code}: ${issue.message}` });
  const ok = validation.valid && !issues.some(issue => issue.level === 'error');
  return { manifest: ok ? manifest : null, issues, ok, pages };
}
