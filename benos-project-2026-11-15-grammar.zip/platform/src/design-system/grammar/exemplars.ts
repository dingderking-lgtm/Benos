// The ARKPM home page in bnl-0: the platform's quality reference, converted from the master kit's
// template. The kit's five ported sections are frozen here as an exemplar — the grammar line does not
// add new block-library entries, and this file is what a generated page is measured against.
// Pictures and links are supplied by the caller, as for any other document.
export const ARKPM_HOME_EXEMPLAR = {
  "version": "bnl-0",
  "lang": "en",
  "title": "ARKPM home (layout grammar)",
  "brand": {
    "colors": {
      "paper": "#f7f7f4",
      "tint": "#eef0ed",
      "ink": "#252a2e",
      "copy": "#5c6267",
      "line": "#d8dddc",
      "accent": "#265bff",
      "accentInk": "#ffffff",
      "mark": "#e57842",
      "dark": "#252a2e",
      "darkInk": "#f6f7f5"
    },
    "type": {
      "head": "grotesk",
      "body": "grotesk",
      "weight": 400,
      "tracking": "tight",
      "scale": "regular"
    },
    "shape": {
      "radius": "large",
      "button": "pill"
    },
    "styles": {
      "kicker": "square",
      "link": "underline",
      "card": "soft",
      "figure": "framed"
    },
    "space": {
      "container": 1360,
      "density": "regular"
    }
  },
  "sections": [
    {
      "id": "hero",
      "tone": "paper",
      "space": "hero",
      "gap": 8,
      "body": [
        {
          "t": "grid",
          "cols": [
            1,
            1
          ],
          "gap": [
            5,
            9
          ],
          "align": "stretch",
          "children": [
            {
              "t": "stack",
              "justify": "center",
              "children": [
                {
                  "t": "kicker",
                  "text": "ARKPM · A JianTai subsidiary"
                },
                {
                  "t": "display",
                  "size": "l",
                  "lines": [
                    "Engineering the",
                    "next life of plastics."
                  ]
                },
                {
                  "t": "text",
                  "role": "lead",
                  "max": "medium",
                  "text": "ARKPM is the machinery brand of Ark Plastics Machinery Co., Ltd., a JianTai subsidiary. We develop customized recycling and extrusion lines around your material and product."
                },
                {
                  "t": "actions",
                  "items": [
                    {
                      "label": "Discover ARKPM",
                      "href": "/about",
                      "kind": "primary"
                    },
                    {
                      "label": "Explore our machines",
                      "href": "/products",
                      "kind": "link"
                    }
                  ]
                }
              ]
            },
            {
              "t": "figure",
              "image": "hero",
              "ratio": "4:3",
              "caption": "New forms. Renewed possibilities. A material concept.",
              "stretch": true
            },
            {
              "t": "grid",
              "cols": 2,
              "gap": 3,
              "collapse": "none",
              "narrowOrder": 4,
              "children": [
                {
                  "t": "card",
                  "fill": "strong",
                  "pad": 5,
                  "href": "/plastic-recycling-machines",
                  "children": [
                    {
                      "t": "kicker",
                      "text": "01 / Recovery"
                    },
                    {
                      "t": "title",
                      "size": "m",
                      "lines": [
                        "Recycling",
                        "machines."
                      ]
                    },
                    {
                      "t": "text",
                      "text": "Build a route from prepared scrap to usable pellets."
                    }
                  ]
                },
                {
                  "t": "card",
                  "fill": "accent",
                  "pad": 5,
                  "href": "/custom-extrusion-lines",
                  "children": [
                    {
                      "t": "kicker",
                      "text": "02 / Formation"
                    },
                    {
                      "t": "title",
                      "size": "m",
                      "lines": [
                        "Custom",
                        "extrusion."
                      ]
                    },
                    {
                      "t": "text",
                      "text": "Turn a product brief into a connected production line."
                    }
                  ]
                }
              ]
            },
            {
              "t": "card",
              "fill": "soft",
              "pad": 5,
              "narrowOrder": 3,
              "children": [
                {
                  "t": "title",
                  "size": "s",
                  "text": "One material. Your possibilities."
                },
                {
                  "t": "text",
                  "text": "From a defined waste stream to a new product profile, the right line begins with the right questions."
                },
                {
                  "t": "link",
                  "label": "Our approach to customization",
                  "href": "/about#approach"
                }
              ]
            }
          ]
        },
        {
          "t": "row",
          "justify": "between",
          "gap": 5,
          "collapse": "sm",
          "rule": "top",
          "children": [
            {
              "t": "text",
              "role": "small",
              "text": "A focused brand within JianTai plastic machinery company"
            },
            {
              "t": "text",
              "role": "small",
              "text": "All product families · Custom configuration"
            }
          ]
        }
      ]
    },
    {
      "id": "purpose",
      "tone": "tint",
      "body": [
        {
          "t": "grid",
          "cols": [
            1,
            1
          ],
          "gap": 8,
          "align": "center",
          "children": [
            {
              "t": "stack",
              "children": [
                {
                  "t": "kicker",
                  "text": "A clear purpose"
                },
                {
                  "t": "title",
                  "size": "l",
                  "lines": [
                    "Better-defined projects.",
                    "More considered machinery."
                  ]
                }
              ]
            },
            {
              "t": "stack",
              "children": [
                {
                  "t": "text",
                  "text": "ARKPM is the brand of Ark Plastics Machinery Co., Ltd., a subsidiary of JianTai plastic machinery company. We develop plastic recycling machines and customized extrusion lines around your process."
                },
                {
                  "t": "text",
                  "text": "Our role is to connect the material question with the equipment decision. We help turn a production ambition into a clear brief: what enters the line, what leaves it, and what needs to happen in between."
                },
                {
                  "t": "link",
                  "label": "Meet the company",
                  "href": "/about"
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "disciplines",
      "tone": "paper",
      "body": [
        {
          "t": "row",
          "justify": "between",
          "align": "end",
          "gap": [
            6,
            9
          ],
          "collapse": "md",
          "children": [
            {
              "t": "stack",
              "children": [
                {
                  "t": "kicker",
                  "text": "Two connected disciplines"
                },
                {
                  "t": "title",
                  "size": "l",
                  "lines": [
                    "Recover value.",
                    "Create what comes next."
                  ]
                }
              ]
            },
            {
              "t": "text",
              "max": "narrow",
              "text": "Recycling and extrusion share a practical starting point: understand the material, then design the process around it."
            }
          ]
        },
        {
          "t": "grid",
          "cols": 2,
          "gap": 7,
          "align": "start",
          "collapse": {
            "sm": 1
          },
          "children": [
            {
              "t": "media",
              "image": "recycling",
              "ratio": "4:3",
              "caption": "Recycling concept: prepared plastic to pellets.",
              "side": "left",
              "split": [
                0.85,
                1.15
              ],
              "collapse": "xl",
              "narrow": "card",
              "children": [
                {
                  "t": "title",
                  "size": "s",
                  "text": "Plastic recycling machines"
                },
                {
                  "t": "text",
                  "text": "Film scrap, rigid regrind and defined melt-treatment duties each call for a distinct configuration. Explore a process built around the incoming material and its next use."
                },
                {
                  "t": "link",
                  "label": "Explore recycling systems",
                  "href": "/plastic-recycling-machines"
                }
              ]
            },
            {
              "t": "media",
              "image": "extrusion",
              "ratio": "4:3",
              "caption": "Extrusion concept: tooling, shaping and downstream handling.",
              "side": "left",
              "split": [
                0.85,
                1.15
              ],
              "collapse": "xl",
              "narrow": "card",
              "children": [
                {
                  "t": "title",
                  "size": "s",
                  "text": "Custom plastic extrusion lines"
                },
                {
                  "t": "text",
                  "text": "Pipe, profile and tubing lines are developed around geometry, material and downstream handling. Every stage should support the product you intend to make."
                },
                {
                  "t": "link",
                  "label": "Explore extrusion systems",
                  "href": "/custom-extrusion-lines"
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "approach",
      "tone": "dark",
      "body": [
        {
          "t": "row",
          "justify": "between",
          "align": "end",
          "gap": [
            6,
            9
          ],
          "collapse": "md",
          "children": [
            {
              "t": "stack",
              "children": [
                {
                  "t": "kicker",
                  "text": "The ARKPM approach"
                },
                {
                  "t": "title",
                  "size": "l",
                  "lines": [
                    "A line is only as considered",
                    "as the brief behind it."
                  ]
                }
              ]
            },
            {
              "t": "text",
              "max": "narrow",
              "text": "Customization is a sequence of engineering decisions. We make the material, process and site requirements part of the same conversation."
            }
          ]
        },
        {
          "t": "grid",
          "cols": 4,
          "gap": 4,
          "children": [
            {
              "t": "card",
              "fill": "soft",
              "border": true,
              "pad": 6,
              "children": [
                {
                  "t": "number",
                  "text": "01"
                },
                {
                  "t": "title",
                  "size": "s",
                  "text": "Understand the material"
                },
                {
                  "t": "text",
                  "text": "Start with representative samples, your product requirements and the conditions in which the line will operate."
                }
              ]
            },
            {
              "t": "card",
              "fill": "soft",
              "border": true,
              "pad": 6,
              "children": [
                {
                  "t": "number",
                  "text": "02"
                },
                {
                  "t": "title",
                  "size": "s",
                  "text": "Define the system"
                },
                {
                  "t": "text",
                  "text": "Connect feeding, processing and downstream stages in a proposal with clear interfaces and responsibilities."
                }
              ]
            },
            {
              "t": "card",
              "fill": "soft",
              "border": true,
              "pad": 6,
              "children": [
                {
                  "t": "number",
                  "text": "03"
                },
                {
                  "t": "title",
                  "size": "s",
                  "text": "Make it project-specific"
                },
                {
                  "t": "text",
                  "text": "Review layout, controls, utilities and access so the configuration fits the way your plant needs to work."
                }
              ]
            },
            {
              "t": "card",
              "fill": "soft",
              "border": true,
              "pad": 6,
              "children": [
                {
                  "t": "number",
                  "text": "04"
                },
                {
                  "t": "title",
                  "size": "s",
                  "text": "Agree the evidence"
                },
                {
                  "t": "text",
                  "text": "Set the checks, documentation and acceptance criteria that will guide the project from proposal to evaluation."
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "manufacturing",
      "tone": "tint",
      "body": [
        {
          "t": "row",
          "justify": "between",
          "align": "end",
          "gap": [
            6,
            9
          ],
          "collapse": "md",
          "children": [
            {
              "t": "stack",
              "children": [
                {
                  "t": "kicker",
                  "text": "The manufacturing behind ARKPM"
                },
                {
                  "t": "title",
                  "size": "l",
                  "lines": [
                    "Backed by JianTai.",
                    "Built around your process."
                  ]
                }
              ]
            },
            {
              "t": "text",
              "max": "narrow",
              "text": "ARKPM builds on the manufacturing foundation of its parent company, JianTai plastic machinery company. Our customized recycling and extrusion lines begin with your material, product and production requirements."
            }
          ]
        },
        {
          "t": "grid",
          "cols": 3,
          "gap": 5,
          "children": [
            {
              "t": "card",
              "fill": "surface",
              "border": true,
              "pad": 6,
              "media": {
                "image": "premises",
                "ratio": "4:3",
                "fit": "contain"
              },
              "children": [
                {
                  "t": "title",
                  "size": "m",
                  "text": "JianTai premises"
                },
                {
                  "t": "text",
                  "text": "The manufacturing setting behind our parent company’s plastics-machinery operations."
                }
              ]
            },
            {
              "t": "card",
              "fill": "surface",
              "border": true,
              "pad": 6,
              "media": {
                "image": "workshop",
                "ratio": "4:3",
                "fit": "contain"
              },
              "children": [
                {
                  "t": "title",
                  "size": "m",
                  "text": "Inside the workshop"
                },
                {
                  "t": "text",
                  "text": "Recycling and extrusion equipment, brought into a clearer view."
                }
              ]
            },
            {
              "t": "card",
              "fill": "surface",
              "border": true,
              "pad": 6,
              "media": {
                "image": "shipment",
                "ratio": "4:3",
                "fit": "contain"
              },
              "children": [
                {
                  "t": "title",
                  "size": "m",
                  "text": "Preparation for shipment"
                },
                {
                  "t": "text",
                  "text": "A closer look at equipment prepared for transport."
                }
              ]
            }
          ]
        },
        {
          "t": "text",
          "role": "caption",
          "max": "wide",
          "text": "AI-enhanced manufacturing visuals based on JianTai source photographs. Equipment appearance is illustrative; the agreed specification defines your configuration."
        },
        {
          "t": "actions",
          "items": [
            {
              "label": "Discuss your project",
              "href": "/contact",
              "kind": "primary"
            },
            {
              "label": "Plan in-house scrap recycling",
              "href": "/solutions/in-house-plastic-scrap-recycling",
              "kind": "link"
            }
          ]
        }
      ]
    },
    {
      "id": "insights",
      "tone": "tint",
      "body": [
        {
          "t": "row",
          "justify": "between",
          "align": "end",
          "gap": [
            6,
            9
          ],
          "collapse": "md",
          "children": [
            {
              "t": "stack",
              "children": [
                {
                  "t": "kicker",
                  "text": "Engineering insights"
                },
                {
                  "t": "title",
                  "size": "l",
                  "text": "Clarity before commitment."
                }
              ]
            },
            {
              "t": "text",
              "max": "narrow",
              "text": "Practical guides for a better machinery brief, a clearer proposal and a more useful technical conversation."
            }
          ]
        },
        {
          "t": "grid",
          "cols": 3,
          "gap": 5,
          "children": [
            {
              "t": "card",
              "fill": "surface",
              "border": true,
              "pad": 6,
              "media": {
                "image": "guide1",
                "ratio": "3:2"
              },
              "children": [
                {
                  "t": "text",
                  "role": "meta",
                  "text": "Cost & buying guide · 6 min read"
                },
                {
                  "t": "title",
                  "size": "s",
                  "text": "Plastic recycling machine cost: a quote and buying guide"
                },
                {
                  "t": "text",
                  "text": "Understand what changes a recycling machine price, separate equipment cost from plant costs, and compare proposals against the same feedstock and supply scope."
                },
                {
                  "t": "link",
                  "label": "Read the guide",
                  "href": "/insights/machine-specification-checklist"
                }
              ]
            },
            {
              "t": "card",
              "fill": "surface",
              "border": true,
              "pad": 6,
              "media": {
                "image": "guide2",
                "ratio": "3:2"
              },
              "children": [
                {
                  "t": "text",
                  "role": "meta",
                  "text": "Cost & project planning · 6 min read"
                },
                {
                  "t": "title",
                  "size": "s",
                  "text": "Plastic extrusion machine cost: plan a complete line quotation"
                },
                {
                  "t": "text",
                  "text": "Compare an extruder price with a complete production-line quotation, then define the tooling, downstream equipment, utilities and trial work your project needs."
                },
                {
                  "t": "link",
                  "label": "Read the guide",
                  "href": "/insights/custom-extrusion-project-brief"
                }
              ]
            },
            {
              "t": "card",
              "fill": "surface",
              "border": true,
              "pad": 6,
              "media": {
                "image": "guide3",
                "ratio": "3:2"
              },
              "children": [
                {
                  "t": "text",
                  "role": "meta",
                  "text": "Plant planning · 5 min read"
                },
                {
                  "t": "title",
                  "size": "s",
                  "text": "Plastic recycling plant setup: layout and utility planning"
                },
                {
                  "t": "text",
                  "text": "Prepare a recycling plant layout that includes feedstock storage, process interfaces, service access and utilities before approving equipment positions."
                },
                {
                  "t": "link",
                  "label": "Read the guide",
                  "href": "/insights/factory-line-layout"
                }
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "next",
      "tone": "accent",
      "space": "band",
      "body": [
        {
          "t": "grid",
          "cols": [
            1,
            0.5
          ],
          "gap": 9,
          "align": "center",
          "collapse": {
            "sm": 1
          },
          "children": [
            {
              "t": "title",
              "size": "xl",
              "text": "Your next production chapter starts here."
            },
            {
              "t": "stack",
              "self": "end",
              "max": "xs",
              "gap": 4,
              "children": [
                {
                  "t": "text",
                  "text": "Tell us about your material, your product and the way you want to work. We will help shape a considered project brief."
                },
                {
                  "t": "actions",
                  "items": [
                    {
                      "label": "Discuss your project",
                      "href": "/contact",
                      "kind": "primary"
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }
  ]
} as const;
