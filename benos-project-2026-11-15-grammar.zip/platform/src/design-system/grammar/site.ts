﻿// Site-level assembly for bnl-0: one brand system, several pages, real links between them.
// A site shares the brand and therefore the site-wide stylesheet; each page only adds its own
// instance rules. Instance class names carry the page key, so two pages cannot collide.
import { compilePage, type CompileResult, type GrammarFrame, type GrammarImage, type GrammarSection } from './compile';
import type { GrammarBrand, Issue } from './brand';

export type GrammarSitePage = { key: string; path: string; title: string; sections: GrammarSection[] };
export type GrammarSite = {
  lang?: string;
  brand: GrammarBrand;
  pages: GrammarSitePage[];
  images?: Record<string, GrammarImage>;
};
export type CompiledSitePage = {
  key: string; path: string; title: string; body: string; css: string; ok: boolean;
  issues: Issue[]; stats: CompileResult['stats']; frames: GrammarFrame[];
};
export type CompiledSite = {
  pages: CompiledSitePage[];
  /** Brand tokens and every shared rule; identical for all pages, so a CMS can carry it once. */
  sharedCss: string;
  ok: boolean;
  issues: Issue[];
};

const PATH = /^\/(?:[a-z0-9][a-z0-9-]{0,62})?$/;
const KEY = /^[a-z][a-z0-9-]{0,31}$/;
/** A site is one brand and a set of pages that link to each other by path. */
export function compileSite(site: GrammarSite, options: { assetPath?: (src: string) => string; maxPages?: number } = {}): CompiledSite {
  const issues: Issue[] = [];
  const err = (path: string, message: string) => issues.push({ level: 'error', path, message });
  const pages = Array.isArray(site?.pages) ? site.pages : [];
  const limit = options.maxPages ?? 12;
  if (!pages.length) err('pages', 'a site needs at least one page');
  if (pages.length > limit) err('pages', `a site has at most ${limit} pages (got ${pages.length})`);
  const keys = new Set<string>(), paths = new Set<string>();
  pages.forEach((page, index) => {
    if (!page || !KEY.test(String(page.key))) err(`pages[${index}].key`, 'needs lowercase letters, digits and hyphens');
    else if (keys.has(page.key)) err(`pages[${index}].key`, `duplicate page key ${page.key}`);
    else keys.add(page.key);
    if (!PATH.test(String(page.path))) err(`pages[${index}].path`, 'needs a site path such as "/" or "/about"');
    else if (paths.has(page.path)) err(`pages[${index}].path`, `duplicate page path ${page.path}`);
    else paths.add(page.path);
  });
  if (!paths.has('/')) err('pages', 'one page must live at "/"');
  const links = [...paths].sort();
  const shared = new Set<string>();
  const compiled: CompiledSitePage[] = [];
  for (const page of pages) {
    const result = compilePage(
      { lang: site.lang, title: page.title, brand: site.brand, sections: page.sections, images: site.images },
      { assetPath: options.assetPath, images: site.images, links, scope: page.key.replace(/[^a-z0-9]/g, '') || 'p' },
    );
    shared.add(result.sharedCss);
    for (const issue of result.issues) issues.push({ ...issue, path: `${page.key}:${issue.path}` });
    compiled.push({ key: page.key, path: page.path, title: page.title, body: result.body, css: result.pageCss, ok: result.ok, issues: result.issues, stats: result.stats, frames: result.frames });
  }
  if (shared.size > 1) err('brand', 'every page of a site must use the same brand system');
  const sharedCss = shared.size === 1 ? [...shared][0] : '';
  // The CMS stores a template's CSS twice and one page must stay under 45 KB (v2/render.ts:203).
  for (const page of compiled) if (page.stats.cssBytes > 45_000) err(`${page.key}:css`, `this page needs ${page.stats.cssBytes} bytes of CSS; the platform allows 45,000`);
  return { pages: compiled, sharedCss, ok: !issues.some(issue => issue.level === 'error'), issues };
}