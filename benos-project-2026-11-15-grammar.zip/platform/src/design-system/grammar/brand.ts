﻿// bnl-0 brand system: ten colours, two typefaces, a shape and a few style switches
// resolve into CSS custom properties, a spacing scale and a root class.
// Ported from the layout-grammar experiment (.ui-work/layout-grammar/compile.mjs);
// behaviour is unchanged, only the deliverable (page fragment + CSS) and the CSS
// scoping rules differ. See ./compile.ts.
export const GRAMMAR_VERSION = 'bnl-0';
export const VIEW = 1680;
export const GUTTER = 40;

export type Issue = { level: 'error' | 'warn'; path: string; message: string };
export type ColourKey = 'paper' | 'tint' | 'ink' | 'copy' | 'line' | 'accent' | 'accentInk' | 'mark' | 'dark' | 'darkInk';
export type GrammarBrand = {
  colors: Record<ColourKey, string>;
  type: { head: string; body: string; weight: number; tracking: string; scale: string };
  shape: { radius: string; button: string };
  styles: { kicker: string; link: string; card: string; figure: string };
  space: { container: number; density: string };
  overrides?: Record<string, string>;
  scale?: number[];
  wrap?: string;
};
export type ResolvedBrand = {
  brand: GrammarBrand;
  vars: Record<string, string | number>;
  scale: number[];
  container: number;
  typeScale: number;
  tracking: number;
  rootClass: string;
};

const hex = (value: string): [number, number, number] => {
  const match = /^#([0-9a-f]{6})$/i.exec(String(value));
  if (!match) throw new Error('BAD_COLOUR ' + value);
  const n = parseInt(match[1], 16);
  return [n >> 16, (n >> 8) & 255, n & 255];
};
const toHex = (values: number[]) => '#' + values.map(x => Math.round(Math.max(0, Math.min(255, x))).toString(16).padStart(2, '0')).join('');
export const mix = (a: string, b: string, t: number) => {
  const x = hex(a), y = hex(b);
  return toHex(x.map((v, i) => v + (y[i] - v) * t));
};
const lum = (value: string) => {
  const [r, g, b] = hex(value).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; });
  return .2126 * r + .7152 * g + .0722 * b;
};
export const contrast = (a: string, b: string) => {
  const x = lum(a), y = lum(b);
  return (Math.max(x, y) + .05) / (Math.min(x, y) + .05);
};
const ensure = (colour: string, background: string, min: number, toward: string) => {
  let value = colour;
  for (let i = 0; i < 20 && contrast(value, background) < min; i++) value = mix(value, toward, .12);
  return value;
};

const FONTS: Record<string, string> = {
  grotesk: 'Arial,Helvetica,"PingFang SC","Microsoft YaHei",sans-serif',
  humanist: '"Segoe UI",system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif',
  serif: 'Georgia,"Times New Roman","Songti SC","SimSun",serif',
};
const DENSITY: Record<string, { scale: number[]; sec: string; secSm: string; block: number }> = {
  compact: { scale: [6, 8, 12, 16, 20, 24, 32, 40, 56], sec: 'clamp(48px,5.5vw,80px)', secSm: '48px', block: 30 },
  regular: { scale: [8, 12, 16, 20, 24, 32, 40, 48, 64], sec: 'clamp(64px,7vw,104px)', secSm: '62px', block: 38 },
  airy: { scale: [8, 12, 16, 24, 32, 40, 48, 64, 88], sec: 'clamp(80px,9vw,136px)', secSm: '72px', block: 48 },
};
const RADIUS: Record<string, [number, number]> = { none: [0, 0], small: [4, 4], medium: [12, 14], large: [22, 24] };
const BUTTON: Record<string, number> = { pill: 40, soft: 10, square: 2 };
const TYPE_SCALE: Record<string, number> = { compact: .92, regular: 1, large: 1.08 };
const TRACKING: Record<string, number> = { tight: 1, normal: .45, open: 0 };
const BRAND_ENUMS: Record<string, readonly (string | number)[]> = {
  'type.head': Object.keys(FONTS), 'type.body': Object.keys(FONTS), 'type.weight': [400, 500, 600, 700], 'type.tracking': Object.keys(TRACKING), 'type.scale': Object.keys(TYPE_SCALE),
  'shape.radius': Object.keys(RADIUS), 'shape.button': Object.keys(BUTTON),
  'styles.kicker': ['square', 'line', 'dot', 'plain'], 'styles.link': ['underline', 'arrow', 'plain'], 'styles.card': ['soft', 'outline'], 'styles.figure': ['framed', 'plain', 'edge'],
  'space.container': [1120, 1200, 1280, 1360], 'space.density': Object.keys(DENSITY),
};
export const BRAND_COLOUR_KEYS: readonly ColourKey[] = ['paper', 'tint', 'ink', 'copy', 'line', 'accent', 'accentInk', 'mark', 'dark', 'darkInk'];
export const BRAND_CHOICES = BRAND_ENUMS;

/** Validates the brand system and derives every colour the page needs from the ten authored ones. */
export function resolveBrand(brand: GrammarBrand | undefined, issues: Issue[]): ResolvedBrand | null {
  const err = (path: string, message: string) => issues.push({ level: 'error', path: 'brand.' + path, message });
  const warn = (path: string, message: string) => issues.push({ level: 'warn', path: 'brand.' + path, message });
  const b = (brand || {}) as Record<string, any>;
  for (const group of ['colors', 'type', 'shape', 'styles', 'space']) if (!b[group] || typeof b[group] !== 'object') { err(group, 'missing'); return null; }
  for (const key of BRAND_COLOUR_KEYS) if (!/^#[0-9a-f]{6}$/i.test(String(b.colors[key]))) err('colors.' + key, 'must be a 6-digit hex colour');
  for (const [path, allowed] of Object.entries(BRAND_ENUMS)) { const [g, k] = path.split('.'); if (!allowed.includes(b[g][k])) err(path, `must be one of ${allowed.join(' | ')} (got ${JSON.stringify(b[g][k])})`); }
  if (issues.some(i => i.level === 'error' && i.path.startsWith('brand.'))) return null;
  const c = b.colors as Record<ColourKey, string>, o = (b.overrides || {}) as Record<string, string>, light = lum(c.paper) > .4, black = '#000000';
  const d: Record<string, string> = {
    surface: light ? '#ffffff' : mix(c.paper, c.ink, .08), cardSoft: mix(c.tint, c.paper, .15), cardStrong: mix(c.tint, c.ink, .04), figBg: mix(c.paper, c.ink, .035), mediaBg: mix(c.tint, c.ink, .02), mediaCard: mix(c.paper, c.tint, .2),
    accentDeep: mix(c.accent, black, .12), accentHover: mix(c.accent, black, .22), accentTint: mix(c.accentInk, c.accent, .08), accentCopy: mix(c.accentInk, c.accent, .1), accentKicker: mix(c.accentInk, c.accent, .12), accentLine: mix(c.accent, c.accentInk, .35),
    link: ensure(mix(c.accent, c.ink, .15), c.paper, 4.5, c.ink), linkLine: mix(c.line, c.ink, .22), kicker: mix(c.copy, c.ink, .1), caption: c.copy, number: ensure(mix(c.mark, black, .25), c.paper, 4.5, c.ink),
    darkCopy: mix(c.darkInk, c.dark, .14), darkCard: mix(c.dark, c.darkInk, .06), darkLine: mix(c.dark, c.darkInk, .2), darkKicker: mix(c.darkInk, c.dark, .08), darkLinkLine: mix(c.dark, c.darkInk, .45),
    ...o,
  };
  // Readability is checked, not assumed.
  const pairs: Array<[ColourKey, string, ColourKey, string, number]> = [['ink', c.ink, 'paper', c.paper, 7], ['copy', c.copy, 'paper', c.paper, 4.5], ['copy', c.copy, 'tint', c.tint, 4.5], ['accentInk', c.accentInk, 'accent', c.accent, 4.5], ['darkInk', c.darkInk, 'dark', c.dark, 7], ['ink', c.ink, 'tint', c.tint, 7]];
  for (const [fn, foreground, bn, background, min] of pairs) { const ratio = contrast(foreground, background); if (ratio < 4.5 && min >= 4.5) err('colors.' + fn, `contrast of ${fn} on ${bn} is ${ratio.toFixed(2)}; needs at least 4.5`); else if (ratio < min) warn('colors.' + fn, `contrast of ${fn} on ${bn} is ${ratio.toFixed(2)}; ${min} is the target`); }
  if (contrast(c.paper, c.tint) > 1.35) warn('colors.tint', 'tint is far from paper; alternating sections will look striped');
  const density = DENSITY[b.space.density], scale = Array.isArray(b.scale) && b.scale.length === 9 ? b.scale as number[] : density.scale;
  const [rCard, rFig] = RADIUS[b.shape.radius];
  const vars: Record<string, string | number> = {
    paper: c.paper, tint: c.tint, ink: c.ink, copy: c.copy, line: c.line, accent: c.accent, 'accent-ink': c.accentInk, mark: c.mark, dark: c.dark, 'dark-ink': c.darkInk,
    surface: d.surface, 'card-soft': d.cardSoft, 'card-strong': d.cardStrong, 'fig-bg': d.figBg, 'media-bg': d.mediaBg, 'media-card': d.mediaCard,
    'cover-btn-bg': contrast(c.accent, '#141414') >= 3 ? c.accent : '#ffffff', 'cover-btn-fg': contrast(c.accent, '#141414') >= 3 ? c.accentInk : '#16181b', 'cover-btn-hv': contrast(c.accent, '#141414') >= 3 ? d.accentHover : '#e6e8eb',
    'accent-deep': d.accentDeep, 'accent-hover': d.accentHover, 'accent-tint': d.accentTint, 'accent-copy': d.accentCopy, 'accent-kicker': d.accentKicker, 'accent-line': d.accentLine,
    link: d.link, 'link-line': d.linkLine, kicker: d.kicker, caption: d.caption, number: d.number,
    'dark-copy': d.darkCopy, 'dark-card': d.darkCard, 'dark-line': d.darkLine, 'dark-kicker': d.darkKicker, 'dark-link-line': d.darkLinkLine,
    'f-head': FONTS[b.type.head], 'f-body': FONTS[b.type.body], 'fw-head': b.type.weight, ts: TYPE_SCALE[b.type.scale], tk: TRACKING[b.type.tracking],
    'r-card': rCard + 'px', 'r-fig': rFig + 'px', 'r-btn': BUTTON[b.shape.button] + 'px', container: b.space.container + 'px',
    'sec-pad': density.sec, 'sec-pad-sm': density.secSm,
    'r-default': '16px', 'r-kicker': '22px', 'r-lead': '24px', 'r-body': '16px', 'r-para': '20px', 'r-actions': '30px', 'r-link': '26px', 'r-caption': '18px', 'r-number': '25px', 'r-meta': '12px', 'r-block': density.block + 'px',
    ...Object.fromEntries(scale.map((px, i) => ['s' + (i + 1), px + 'px'])),
  };
  return { brand: b as GrammarBrand, vars, scale, container: b.space.container, typeScale: TYPE_SCALE[b.type.scale], tracking: TRACKING[b.type.tracking],
    rootClass: `bnl bnl-k-${b.styles.kicker} bnl-lk-${b.styles.link} bnl-cd-${b.styles.card} bnl-fg-${b.styles.figure}` };
}

// ---------- copy fitting (an estimate; the browser check measures the real thing) ----------
export const CJK = /[\u2E80-\u9FFF\uF900-\uFAFF\uFF00-\uFFEF]/;
const NARROW = new Set('iljtfrI.,:;!|\'"()[]/'.split(''));
const WIDE = new Set('mwMW@%'.split(''));
export function textWidth(text: string, fontPx: number, letterPx = 0) {
  let em = 0;
  for (const ch of String(text)) em += CJK.test(ch) ? 1 : ch === ' ' ? .28 : NARROW.has(ch) ? .3 : WIDE.has(ch) ? .85 : /[A-Z]/.test(ch) ? .68 : /[0-9]/.test(ch) ? .56 : .52;
  return em * fontPx + letterPx * [...String(text)].length;
}
export const SIZES: Record<string, Record<string, [number, number, number | null]>> = {
  display: { xl: [76, -3.6, null], l: [60, -2.1, 620] },
  title: { xl: [72, -2.6, 850], l: [54, -1.8, 760], m: [30, -.8, null], s: [26, -.6, null] },
};
export const MOBILE_SIZE: Record<string, Record<string, string>> = {
  display: { xl: 'calc(var(--ts)*48px)', l: 'calc(var(--ts)*clamp(34px,9vw,44px))' },
  title: { xl: 'calc(var(--ts)*46px)', l: 'calc(var(--ts)*36px)', m: 'calc(var(--ts)*27px)', s: 'calc(var(--ts)*24px)' },
};
export const BUDGET: Record<string, [number, number]> = { kicker: [48, 22], lead: [260, 120], body: [460, 220], small: [200, 90], caption: [200, 90], meta: [70, 30], button: [28, 10], link: [44, 18], cardTitle: [90, 32], listItem: [140, 60], question: [110, 44], answer: [420, 200] };
