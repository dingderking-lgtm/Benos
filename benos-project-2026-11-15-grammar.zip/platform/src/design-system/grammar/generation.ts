﻿// The model's side of the grammar engine: a frozen plan, one tool, and a submission compiler.
// Review-only, like v2's generation path: it never calls a model, reserves money, publishes or
// charges. The plan fixes what the model may write (pages, pictures, links); the submission is
// compiled by ./site.ts and comes back with the exact issues a repair round has to fix.
import { z } from 'zod';
import { sha256 } from '../../lib/crypto';
import { GRAMMAR_VERSION } from './brand';
import { compileSite, type CompiledSite, type GrammarSitePage } from './site';
import { GRAMMAR_SPEC } from './spec';
import { DIRECTIONS, INDUSTRY_PALETTES, isDirection, isIndustry, paletteTokens, type DirectionId, type IndustryId } from './palettes';
import type { GrammarBrand, Issue } from './brand';

export const GRAMMAR_GENERATION_VERSION = 'bnl-generation-1' as const;
export const GRAMMAR_TOOL_NAME = 'compose_site_grammar';

export const grammarGenerationRequestSchema = z.object({
  request: z.string().trim().min(1).max(20000),
  seed: z.string().min(1).max(80).default('review'),
  pageCount: z.number().int().min(1).max(12).default(3),
  images: z.array(z.object({ id: z.string().min(1).max(60), width: z.number().int().positive(), height: z.number().int().positive(), alt: z.string().max(200).default(''), src: z.string().min(1).max(400) })).max(60).default([]),
  /** Fixed by the caller, so a stored plan replays byte for byte. */
  createdAt: z.string().min(10).max(40).default('1970-01-01T00:00:00.000Z'),
}).strict();
export type GrammarGenerationRequest = z.input<typeof grammarGenerationRequestSchema>;

const pageSchema = z.object({ key: z.string().regex(/^[a-z][a-z0-9-]{0,31}$/), path: z.string().regex(/^\/(?:[a-z0-9][a-z0-9-]{0,62})?$/), title: z.string().min(1).max(120), purpose: z.string().min(1).max(300) }).strict();

export type GrammarPlanPage = z.infer<typeof pageSchema>;
export type GrammarPlan = {
  version: typeof GRAMMAR_GENERATION_VERSION;
  grammarVersion: string;
  spec: string;
  pages: GrammarPlanPage[];
  images: Array<{ id: string; src: string; w: number; h: number; alt: string }>;
  links: string[];
  /** The colours the model may choose from. It picks one; it never authors a hex value. */
  palettes: Array<{ id: IndustryId; label: string; zh: string; intent: string; directions: Array<{ id: DirectionId; label: string; zh: string; intent: string }> }>;
  planHash: string;
  reviewOnly: true;
  productionEnabled: false;
};

const DEFAULT_DUTIES = ['first impression and what the company offers', 'what the offers are, in detail', 'how working together goes, step by step', 'proof: a picture-led case or gallery', 'questions customers ask', 'one clear next step'];

/** Freezes one plan: the pages and their duties, the pictures that exist, the links that are real. */
export async function prepareGrammarGeneration(raw: GrammarGenerationRequest): Promise<GrammarPlan> {
  const input = grammarGenerationRequestSchema.parse(raw);
  const pages: GrammarPlanPage[] = Array.from({ length: input.pageCount }, (_, index) => ({
    key: index === 0 ? 'home' : `page-${index + 1}`,
    path: index === 0 ? '/' : `/page-${index + 1}`,
    title: index === 0 ? 'Home' : `Page ${index + 1}`,
    purpose: DEFAULT_DUTIES[index % DEFAULT_DUTIES.length],
  }));
  const images = input.images.map(image => ({ id: image.id, src: image.src, w: image.width, h: image.height, alt: image.alt }));
  const payload = {
    version: GRAMMAR_GENERATION_VERSION, grammarVersion: GRAMMAR_VERSION, spec: GRAMMAR_SPEC, pages, images, createdAt: input.createdAt,
    palettes: INDUSTRY_PALETTES.map(palette => ({ id: palette.id, label: palette.label, zh: palette.zh, intent: palette.intent, directions: DIRECTIONS.map(direction => ({ ...direction })) })),
    links: pages.map(page => page.path).sort(), reviewOnly: true as const, productionEnabled: false as const,
  };
  return { ...payload, planHash: await sha256(JSON.stringify(payload)) };
}

export const grammarSubmissionSchema = z.object({
  planHash: z.string().regex(/^[a-f0-9]{64}$/),
  /** The palette this site uses. Colours come from the palette engine, not from the model. */
  palette: z.object({ industry: z.string().min(1).max(40), direction: z.string().min(1).max(20) }).strict(),
  pages: z.array(z.object({ key: z.string().regex(/^[a-z][a-z0-9-]{0,31}$/), title: z.string().max(120).optional(), sections: z.array(z.record(z.string(), z.unknown())) }).strict()).min(1).max(12),
  /** Picture slots the page wants illustrated, addressed the way the page is written. */
  images: z.array(z.object({
    page: z.string().regex(/^[a-z][a-z0-9-]{0,31}$/),
    section: z.string().regex(/^[a-z][a-z0-9-]{0,23}$/),
    index: z.number().int().min(1).max(6).default(1),
    purpose: z.string().trim().min(2).max(120),
    prompt: z.string().trim().min(10).max(1500),
  }).strict()).max(6).default([]),
}).strict();
export type GrammarSubmission = z.input<typeof grammarSubmissionSchema>;

/** The tool handed to the model. The grammar itself travels in the plan, not in the schema. */
export function grammarTool(plan: GrammarPlan) {
  return {
    type: 'function' as const,
    name: GRAMMAR_TOOL_NAME,
    description: 'Compose a website as one brand system plus a tree of layout and text elements per page, following the grammar in the plan. Write every page of the plan and use only the plan\'s pictures and links. Do not invent figures, clients, awards or addresses. This tool does not generate images, publish, approve or charge.',
    parameters: {
      type: 'object', additionalProperties: false,
      properties: {
        planHash: { type: 'string', const: plan.planHash },
        palette: {
          type: 'object', additionalProperties: false,
          description: 'Choose one industry and one direction from the plan. The platform derives every colour from it; do not send hex values.',
          properties: { industry: { type: 'string', enum: plan.palettes.map(palette => palette.id) }, direction: { type: 'string', enum: DIRECTIONS.map(direction => direction.id) } },
          required: ['industry', 'direction'],
        },
        images: {
          type: 'array', maxItems: 6,
          description: 'Pictures to generate for slots of the pages you wrote. Address a slot by page, section and its 1-based position inside that section (the order figures appear). Describe subject, light and composition; no text, logos or watermarks.',
          items: { type: 'object', additionalProperties: false, properties: { page: { type: 'string' }, section: { type: 'string' }, index: { type: 'integer', minimum: 1, maximum: 6 }, purpose: { type: 'string' }, prompt: { type: 'string' } }, required: ['page', 'section', 'purpose', 'prompt'] },
        },
        pages: {
          type: 'array', minItems: plan.pages.length, maxItems: plan.pages.length,
          items: {
            type: 'object', additionalProperties: false,
            properties: {
              key: { type: 'string', enum: plan.pages.map(page => page.key) },
              title: { type: 'string' },
              sections: { type: 'array', minItems: 3, maxItems: 10, items: { type: 'object', additionalProperties: true, description: 'One section: id, tone, space, body[].' } },
            },
            required: ['key', 'sections'],
          },
        },
      },
      required: ['planHash', 'palette', 'pages'],
    },
  };
}

export type GrammarSubmissionResult = {
  version: 'bnl-site-review-1';
  planHash: string;
  ok: boolean;
  issues: Issue[];
  site: CompiledSite | null;
  stats: { pages: number; sections: number; nodes: number; cssBytes: number; htmlBytes: number };
  reviewOnly: true;
  customerExportReady: false;
};

/** Validates the plan is the one this task froze, then compiles every page the model wrote. */
export async function compileGrammarSubmission(
  plan: GrammarPlan,
  raw: unknown,
  options: { assetPath?: (src: string) => string } = {},
): Promise<GrammarSubmissionResult> {
  const { planHash, ...payload } = plan;
  const issues: Issue[] = [];
  const fail = (path: string, message: string): GrammarSubmissionResult => ({
    version: 'bnl-site-review-1', planHash, ok: false, issues: [...issues, { level: 'error', path, message }], site: null,
    stats: { pages: 0, sections: 0, nodes: 0, cssBytes: 0, htmlBytes: 0 }, reviewOnly: true, customerExportReady: false,
  });
  if (await sha256(JSON.stringify(payload)) !== planHash) return fail('plan', 'the plan changed after it was frozen');
  const parsed = grammarSubmissionSchema.safeParse(raw);
  if (!parsed.success) return fail('submission', 'the submission does not match the tool schema: ' + parsed.error.issues.slice(0, 4).map(issue => `${issue.path.join('.')} ${issue.message}`).join('; '));
  const submission = parsed.data;
  if (submission.planHash !== planHash) return fail('planHash', 'this is not the plan this task froze');
  if (new Set(submission.pages.map(page => page.key)).size !== submission.pages.length) return fail('pages', 'a page key appears twice');
  for (const planned of plan.pages) if (!submission.pages.some(page => page.key === planned.key)) return fail('pages', `page ${planned.key} is missing; every planned page has to be written`);

  if (!isIndustry(submission.palette.industry)) return fail('palette.industry', 'this industry is not in the plan');
  if (!isDirection(submission.palette.direction)) return fail('palette.direction', 'this direction is not in the plan');
  const tokens = paletteTokens(submission.palette.industry, submission.palette.direction);
  const images = Object.fromEntries(plan.images.map(image => [image.id, { src: image.src, w: image.w, h: image.h, alt: image.alt }]));
  const pages: GrammarSitePage[] = submission.pages.map(page => {
    const planned = plan.pages.find(entry => entry.key === page.key)!;
    return { key: page.key, path: planned.path, title: page.title || planned.title, sections: page.sections as GrammarSitePage['sections'] };
  });
  const site = compileSite({ brand: tokens.brand as unknown as GrammarBrand, pages, images }, { assetPath: options.assetPath });
  const totals = site.pages.reduce((sum, page) => ({ sections: sum.sections + page.stats.sections, nodes: sum.nodes + page.stats.nodes, cssBytes: Math.max(sum.cssBytes, page.stats.cssBytes), htmlBytes: sum.htmlBytes + page.stats.htmlBytes }), { sections: 0, nodes: 0, cssBytes: 0, htmlBytes: 0 });
  return {
    version: 'bnl-site-review-1', planHash, ok: site.ok, issues: [...issues, ...site.issues], site,
    stats: { pages: site.pages.length, ...totals }, reviewOnly: true, customerExportReady: false,
  };
}

/** The issues a repair round has to fix, as one short list the model can act on. */
export function grammarRepairBrief(issues: readonly Issue[]): string {
  const errors = issues.filter(issue => issue.level === 'error');
  const warnings = issues.filter(issue => issue.level === 'warn');
  const head = errors.length ? `${errors.length} error(s) must be fixed before this page can be built:` : 'No errors; these warnings are worth fixing:';
  const lines = [...errors, ...warnings].slice(0, 40).map(issue => `- ${issue.path}: ${issue.message}`);
  return [head, ...lines].join('\n');
}
