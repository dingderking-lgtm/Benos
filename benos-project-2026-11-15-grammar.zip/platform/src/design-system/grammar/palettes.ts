// The platform's colour system. A page never invents colours: it picks an industry and a direction, and
// this file derives every token from the approved palette — the ten colours the grammar needs, the
// 50–950 ramps, the light and dark surfaces, and the semantic pairings. Contrast is checked here, so a
// palette that cannot be read is refused before it reaches a page.
import type { GrammarBrand } from './brand';

export type PaletteRole = 'primary' | 'secondary' | 'accent' | 'background' | 'surface' | 'text' | 'muted' | 'border';
export type PaletteBase = Record<PaletteRole, string>;
export type DirectionId = 'professional' | 'editorial' | 'contrast';
export type IndustryId =
  | 'ai-saas' | 'finance' | 'health' | 'food' | 'education' | 'luxury' | 'beauty'
  | 'environment' | 'industrial' | 'property' | 'travel' | 'legal' | 'gaming';

const hex = (value: string) => {
  const match = /^#([0-9a-f]{6})$/i.exec(value);
  if (!match) throw new Error('BAD_PALETTE_COLOUR ' + value);
  const n = parseInt(match[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255] as [number, number, number];
};
const toHex = (rgb: number[]) => '#' + rgb.map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');
export const mix = (a: string, b: string, t: number) => { const x = hex(a), y = hex(b); return toHex(x.map((v, i) => v + (y[i] - v) * t)); };
const lum = (value: string) => { const [r, g, b] = hex(value).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }); return .2126 * r + .7152 * g + .0722 * b; };
export const contrast = (a: string, b: string) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
/** White or near-black, whichever is readable on the colour. */
const readableOn = (colour: string) => (contrast(colour, '#ffffff') >= 4.5 ? '#ffffff' : '#111318');
/** A neutral step away from the ground, so surfaces differ without adding hue. */
const step = (colour: string, toward: string, amount: number) => mix(colour, toward, amount);

export type IndustryPalette = {
  id: IndustryId;
  label: string;
  zh: string;
  /** What this industry must look like, in the words the model reads. */
  intent: string;
  base: PaletteBase;
};

/** The thirteen industries, each with the base scheme the owner approved. */
export const INDUSTRY_PALETTES: readonly IndustryPalette[] = [
  { id: 'ai-saas', label: 'AI, SaaS, technology', zh: 'AI 与科技', intent: 'innovative, intelligent, efficient', base: { primary: '#635BFF', secondary: '#8B7CFF', accent: '#22D3EE', background: '#F8FAFC', surface: '#FFFFFF', text: '#111827', muted: '#667085', border: '#E5E7EB' } },
  { id: 'finance', label: 'Finance, banking, insurance', zh: '金融与保险', intent: 'trustworthy, safe, stable', base: { primary: '#163A70', secondary: '#2563A6', accent: '#0F766E', background: '#F4F7FB', surface: '#FFFFFF', text: '#17243A', muted: '#66758A', border: '#DCE4EE' } },
  { id: 'health', label: 'Healthcare, biotech', zh: '医疗与健康', intent: 'healthy, hygienic, professional', base: { primary: '#168B83', secondary: '#2878A8', accent: '#8CCDB5', background: '#F3FAF8', surface: '#FFFFFF', text: '#18332F', muted: '#70847F', border: '#DCEBE6' } },
  { id: 'food', label: 'Food, restaurant, drinks', zh: '食品与餐饮', intent: 'appetising, warm, lively', base: { primary: '#C2410C', secondary: '#F97316', accent: '#F5B942', background: '#FFF8ED', surface: '#FFFFFF', text: '#35251C', muted: '#857267', border: '#F0DFCC' } },
  { id: 'education', label: 'Education, online learning', zh: '教育与培训', intent: 'knowledgeable, growing, positive', base: { primary: '#2563EB', secondary: '#0D9488', accent: '#FACC15', background: '#F7FAFF', surface: '#FFFFFF', text: '#172554', muted: '#64748B', border: '#E1E9F5' } },
  { id: 'luxury', label: 'Luxury, jewellery, watches', zh: '奢侈品与珠宝', intent: 'rare, refined, restrained', base: { primary: '#181818', secondary: '#36302B', accent: '#B69A72', background: '#F7F4EE', surface: '#FFFFFF', text: '#1C1C1C', muted: '#77716A', border: '#E6E0D6' } },
  { id: 'beauty', label: 'Beauty, skincare, fashion', zh: '美妆与时尚', intent: 'delicate, soft, elegant', base: { primary: '#A65D72', secondary: '#D9A8AF', accent: '#C9A77C', background: '#FBF7F5', surface: '#FFFFFF', text: '#34282B', muted: '#88777A', border: '#EFE3E1' } },
  { id: 'environment', label: 'Environment, agriculture, energy', zh: '环保与农业', intent: 'natural, sustainable, responsible', base: { primary: '#286044', secondary: '#71977B', accent: '#BD8657', background: '#F5F6EF', surface: '#FFFFFF', text: '#20382B', muted: '#778477', border: '#DDE5D9' } },
  { id: 'industrial', label: 'Industry, machinery, manufacturing', zh: '工业与机械', intent: 'reliable, sturdy, precise', base: { primary: '#183B64', secondary: '#536779', accent: '#F28C28', background: '#F3F5F7', surface: '#FFFFFF', text: '#17212B', muted: '#687785', border: '#DCE2E8' } },
  { id: 'property', label: 'Property, architecture, interiors', zh: '地产与建筑', intent: 'spatial, built, stable', base: { primary: '#263B50', secondary: '#7A858A', accent: '#A96E51', background: '#F5F1EA', surface: '#FFFFFF', text: '#252D34', muted: '#777D7F', border: '#E4DDD2' } },
  { id: 'travel', label: 'Travel, hotel, resort', zh: '旅游与酒店', intent: 'free, relaxed, natural', base: { primary: '#147D82', secondary: '#1E5D78', accent: '#F28C75', background: '#F8F4EB', surface: '#FFFFFF', text: '#243A40', muted: '#788A8B', border: '#E5E2D8' } },
  { id: 'legal', label: 'Legal, consulting, business services', zh: '法律与企业服务', intent: 'authoritative, reasoned, professional', base: { primary: '#182C49', secondary: '#46566C', accent: '#A58B62', background: '#F6F6F3', surface: '#FFFFFF', text: '#202832', muted: '#727B86', border: '#E1E4E7' } },
  { id: 'gaming', label: 'Games, entertainment, esports', zh: '游戏与娱乐', intent: 'immersive, bold, futuristic', base: { primary: '#8B5CF6', secondary: '#00C8F0', accent: '#FF4D8D', background: '#0B1020', surface: '#171D30', text: '#F4F5FA', muted: '#9AA4B5', border: '#2A3348' } },
] as const;

export const DIRECTIONS: readonly { id: DirectionId; label: string; zh: string; intent: string }[] = [
  { id: 'professional', label: 'Professional', zh: '专业可靠', intent: 'neutral ground, one brand colour used for actions, quiet everything else' },
  { id: 'editorial', label: 'Editorial', zh: '克制编辑', intent: 'warmer paper, the second colour leads, brand colour only on actions' },
  { id: 'contrast', label: 'Contrast', zh: '深浅对比', intent: 'dark ground with light type, brand colour used sparingly as the only loud thing' },
] as const;

/** A 50–950 ramp of one colour: lighter steps toward white, darker steps toward black. */
export function ramp(colour: string): Record<string, string> {
  const steps = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950];
  const out: Record<string, string> = {};
  for (const value of steps) {
    if (value === 500) out[value] = colour;
    else if (value < 500) out[value] = step(colour, '#ffffff', (500 - value) / 500 * .92);
    else out[value] = step(colour, '#0b0d10', (value - 500) / 450 * .86);
  }
  return out;
}

export type PaletteTokens = {
  industry: IndustryId;
  direction: DirectionId;
  roles: PaletteBase;
  ramps: Record<'primary' | 'secondary' | 'accent' | 'neutral', Record<string, string>>;
  light: { background: string; surface: string; surfaceSecondary: string; surfaceTertiary: string; border: string; borderStrong: string; text: string; textSecondary: string; textMuted: string; focus: string };
  dark: { background: string; surface: string; surfaceSecondary: string; surfaceTertiary: string; border: string; borderStrong: string; text: string; textSecondary: string; textMuted: string; focus: string };
  semantic: { success: string; warning: string; error: string; info: string };
  states: { primaryHover: string; primaryActive: string; primarySoft: string };
  /** The ten colours the grammar compiles with. */
  brand: GrammarBrand;
};

const NEUTRAL: Record<string, string> = { 0: '#ffffff', 50: '#f8fafc', 100: '#f1f5f9', 200: '#e2e8f0', 300: '#cbd5e1', 400: '#94a3b8', 500: '#64748b', 600: '#475569', 700: '#334155', 800: '#1e293b', 900: '#0f172a', 950: '#0b1120' };

/** Derives every token for one industry in one direction. Nothing here is random. */
export function paletteTokens(industry: IndustryId, direction: DirectionId = 'professional'): PaletteTokens {
  const entry = INDUSTRY_PALETTES.find(palette => palette.id === industry);
  if (!entry) throw new Error('PALETTE_UNKNOWN ' + industry);
  const base = entry.base;
  const darkGround = mix(base.background, '#0b0f14', .92);
  const lightGround = base.background;
  // The direction moves the ground and the emphasis, never the brand hue.
  const ground = direction === 'contrast' ? darkGround : direction === 'editorial' ? mix(base.background, base.primary, .035) : lightGround;
  const chosen = direction === 'editorial' ? mix(base.primary, base.secondary, .35) : base.primary;
  // Nudge a few percent darker only when white type on it would fail; the hue never changes.
  const primary = (() => { let value = chosen; for (let index = 0; index < 24 && contrast('#ffffff', value) < 4.5; index++) value = mix(value, '#000000', .06); return value; })();
  const isDarkGround = lum(ground) < .35;
  const text = isDarkGround ? '#f4f6f8' : base.text;
  // Secondary text must read on the page and on the tinted ground it sits on, not just in theory.
  const tintedGround = isDarkGround ? mix(ground, '#ffffff', .05) : step(ground, base.text, .045);
  const nudge = (colour: string, toward: string, backgrounds: string[], minimum: number) => {
    let value = colour;
    for (let index = 0; index < 26; index++) {
      if (backgrounds.every(background => contrast(value, background) >= minimum)) return value;
      value = mix(value, toward, .1);
    }
    return value;
  };
  /** Text that has to read on a light ground moves toward the palette's ink. */
  const readable = (colour: string, backgrounds: string[], minimum: number) => nudge(colour, base.text, backgrounds, minimum);
  /** Text on the dark ground moves toward white. */
  const readableOnDark = (colour: string, backgrounds: string[], minimum: number) => nudge(colour, '#ffffff', backgrounds, minimum);
  const textSecondary = readable(isDarkGround ? mix('#f4f6f8', ground, .28) : base.muted, [ground, tintedGround], 4.6);
  const surface = isDarkGround ? mix(ground, '#ffffff', .07) : base.surface;
  const primaryRamp = ramp(primary);
  const tokens: PaletteTokens = {
    industry, direction,
    roles: { ...base, primary, background: ground, text },
    ramps: { primary: primaryRamp, secondary: ramp(base.secondary), accent: ramp(base.accent), neutral: NEUTRAL },
    light: {
      background: lightGround, surface: base.surface, surfaceSecondary: step(base.background, base.text, .05), surfaceTertiary: step(base.background, base.text, .09),
      border: base.border, borderStrong: step(base.border, base.text, .18), text: base.text,
      textSecondary: readable(step(base.muted, base.text, .18), [base.background, base.surface], 4.6),
      textMuted: readable(base.muted, [base.background, base.surface], 4.5), focus: primary,
    },
    dark: {
      background: darkGround, surface: mix(darkGround, '#ffffff', .07), surfaceSecondary: mix(darkGround, '#ffffff', .13), surfaceTertiary: mix(darkGround, '#ffffff', .19),
      border: mix(darkGround, '#ffffff', .22), borderStrong: mix(darkGround, '#ffffff', .34), text: '#f4f6f8',
      textSecondary: readableOnDark(mix('#f4f6f8', darkGround, .3), [darkGround], 4.6),
      textMuted: readableOnDark(mix('#f4f6f8', darkGround, .45), [darkGround], 4.5), focus: mix(primary, '#ffffff', .35),
    },
    semantic: {
      success: direction === 'contrast' ? '#4ade80' : '#15803d',
      warning: direction === 'contrast' ? '#fbbf24' : '#b45309',
      error: direction === 'contrast' ? '#f87171' : '#b91c1c',
      info: direction === 'contrast' ? '#7dd3fc' : '#1d4ed8',
    },
    states: { primaryHover: primaryRamp[700], primaryActive: primaryRamp[800], primarySoft: primaryRamp[50] },
    // A brand system that the grammar's own contrast rules accept.
    brand: {
      colors: {
        paper: ground,
        tint: tintedGround,
        ink: text,
        copy: textSecondary,
        line: isDarkGround ? mix(ground, '#ffffff', .2) : base.border,
        accent: primary,
        accentInk: readableOn(primary),
        mark: readableOn(base.accent) === '#ffffff' ? base.accent : mix(base.accent, base.text, .45),
        dark: darkGround,
        darkInk: '#f4f6f8',
      },
      type: { head: 'grotesk', body: 'humanist', weight: 600, tracking: 'tight', scale: 'regular' },
      shape: { radius: direction === 'editorial' ? 'medium' : 'large', button: direction === 'contrast' ? 'soft' : 'pill' },
      styles: { kicker: direction === 'editorial' ? 'line' : 'square', link: 'underline', card: direction === 'editorial' ? 'outline' : 'soft', figure: direction === 'editorial' ? 'plain' : 'framed' },
      space: { container: direction === 'editorial' ? 1200 : 1280, density: direction === 'contrast' ? 'airy' : 'regular' },
    },
  };
  return tokens;
}

export type ContrastCheck = { pair: string; ratio: number; required: number; ok: boolean };
/** The rules the owner wrote down: body text 4.5:1, large text and controls 3:1, and no unreadable pairing. */
export function contrastReport(tokens: PaletteTokens): ContrastCheck[] {
  const pairs: Array<[string, string, string, number]> = [
    ['body text on the page', tokens.light.text, tokens.light.background, 7],
    ['muted text on the page', tokens.light.textMuted, tokens.light.background, 4.5],
    ['button text on the brand colour', readableOn(tokens.roles.primary), tokens.roles.primary, 4.5],
    ['body text on a card', tokens.light.text, tokens.light.surface, 7],
    ['borders against the page', tokens.light.border, tokens.light.background, 1.15],
    ['light type on the dark ground', tokens.dark.text, tokens.dark.background, 7],
  ];
  return pairs.map(([pair, a, b, required]) => ({ pair, ratio: Number(contrast(a, b).toFixed(2)), required, ok: contrast(a, b) >= required }));
}

export function paletteById(industry: IndustryId) { return INDUSTRY_PALETTES.find(palette => palette.id === industry); }
export function isIndustry(value: unknown): value is IndustryId { return INDUSTRY_PALETTES.some(palette => palette.id === value); }
export function isDirection(value: unknown): value is DirectionId { return DIRECTIONS.some(entry => entry.id === value); }
