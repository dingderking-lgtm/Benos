/**
 * Local HTML/CSS adaptations of the pinned public sources listed in provenance.ts.
 * BoardUI, Bencho, BeUI, Watermelon UI and Libraries.dev portions: MIT.
 * HeroUI card slots/styles: Apache-2.0. The original licenses and modification
 * notices travel with the compiler receipt; see getV2Notices().
 *
 * Modified by Benos on 2026-11-14: replace React/Tailwind/Motion with escaped
 * native markup and scoped CSS; remove demo assets, fonts, animation drivers,
 * fake forms and callbacks. Native links/details retain their real behavior.
 */
import { patternHrefSchema } from '../../contracts/section-patterns';
import type { V2SourceId } from './provenance';
import sourceIdentity from './source-identity.json';

export const ADAPTED_PRIMITIVES_VERSION = 'bnx-adapt-1' as const;
const sourceOrder: readonly V2SourceId[] = ['boardui', 'bencho', 'beui', 'watermelon-ui', 'libraries-dev', 'heroui-open'];
function text(value: string, max: number): string {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(value)) throw new Error('BNX_ADAPTER_TEXT_INVALID');
  return value;
}
function escape(value: string) { return value.replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]!)); }
function optional(value: string | undefined, max: number) { return value === undefined ? '' : escape(text(value, max)); }
function href(value: string) { return escape(patternHrefSchema.parse(value)); }
function integer(value: number, min: number, max: number) { if (!Number.isInteger(value) || value < min || value > max) throw new Error('BNX_ADAPTER_SIZE_INVALID'); return value; }

/** BoardUI ButtonLink: label slot + trailing decorative icon + variants/state styles. */
export function renderAdaptedAction(input: { label: string; href: string; kind?: 'primary' | 'secondary' }): string {
  const kind = input.kind ?? 'primary';
  if (kind !== 'primary' && kind !== 'secondary') throw new Error('BNX_ADAPTER_BUTTON_KIND');
  return `<a class="bnx-button bnx-ap-button${kind === 'secondary' ? ' bnx-button-secondary bnx-ap-button-secondary' : ''}" href="${href(input.href)}"><span class="bnx-ap-button-label">${escape(text(input.label, 32))}</span><span class="bnx-ap-button-icon" aria-hidden="true">↗</span></a>`;
}

/** Bencho Aspect SHAPES retain nearly equal area across the three crop formats. */
export const BENCHO_ASPECT_SHAPES = Object.freeze({
  landscape: Object.freeze({ width: 276, height: 207 }),
  square: Object.freeze({ width: 239, height: 239 }),
  portrait: Object.freeze({ width: 207, height: 276 }),
});
export function adaptedAspectGeometry(input: { width: number; height: number; format?: 'native' | 'landscape' | 'square' | 'portrait' }) {
  const nativeWidth = integer(input.width, 1, 32768), nativeHeight = integer(input.height, 1, 32768), format = input.format ?? 'native';
  if (!['native', 'landscape', 'square', 'portrait'].includes(format)) throw new Error('BNX_ADAPTER_ASPECT_FORMAT');
  const shape = format === 'native' ? { width: nativeWidth, height: nativeHeight } : BENCHO_ASPECT_SHAPES[format];
  const scale = format === 'native' ? 1 : Math.max(nativeWidth, nativeHeight) / 276;
  const width = Math.max(1, Math.round(shape.width * scale)), height = Math.max(1, Math.round(shape.height * scale));
  return { width, height, ratio: width / height, className: `bnx-ap-aspect${format === 'native' ? ' bnx-ap-aspect-native' : ''}`, style: `--bnx-ratio:${width}/${height};`, format };
}

/** BeUI BouncyAccordion row anatomy, translated to native disclosure semantics. */
export function renderAdaptedFaq(questions: readonly { question: string; answer: string }[]): string {
  if (!Array.isArray(questions) || questions.length > 8) throw new Error('BNX_ADAPTER_FAQ_CAPACITY');
  return `<div class="bnx-questions bnx-ap-faq">${questions.map(item => `<details class="bnx-question bnx-ap-faq-item"><summary><span class="bnx-ap-faq-title">${escape(text(item.question, 150))}</span><span class="bnx-ap-faq-chevron" aria-hidden="true">⌄</span></summary><div class="bnx-answer bnx-ap-faq-content">${escape(text(item.answer, 700))}</div></details>`).join('')}</div>`;
}

/** Watermelon Footer1 linkGroups → grouped native nav. Newsletter form omitted. */
export function renderAdaptedFooterGroups(groups: readonly { title: string; links: readonly { label: string; href: string }[] }[], label: string): string {
  if (!Array.isArray(groups) || groups.length > 4) throw new Error('BNX_ADAPTER_FOOTER_CAPACITY');
  if (!groups.length) return '';
  return `<nav class="bnx-footer-nav bnx-ap-footer-groups" aria-label="${escape(text(label, 120))}">${groups.map(group => {
    if (!Array.isArray(group.links) || !group.links.length || group.links.length > 6) throw new Error('BNX_ADAPTER_FOOTER_LINK_CAPACITY');
    return `<div class="bnx-footer-column bnx-ap-footer-group"><h3>${escape(text(group.title, 48))}</h3><ul>${group.links.map((link: { label: string; href: string }) => `<li><a href="${href(link.href)}">${escape(text(link.label, 60))}</a></li>`).join('')}</ul></div>`;
  }).join('')}</nav>`;
}

/** HeroUI card slots and variants; @apply utilities become local scoped CSS. */
export function renderAdaptedCard(input: { title: string; text: string; label?: string; value?: string; href?: string; footer?: string; index?: number; glyph?: boolean; icon?: string; variant?: 'default' | 'secondary' | 'transparent' }): string {
  const variant = input.variant ?? 'default';
  if (!['default', 'secondary', 'transparent'].includes(variant)) throw new Error('BNX_ADAPTER_CARD_VARIANT');
  const title = escape(text(input.title, 90));
  const linkedTitle = input.href === undefined ? title : `<a href="${href(input.href)}">${title} <span aria-hidden="true">↗</span></a>`;
  return `<article class="bnx-feature-card bnx-ap-card bnx-ap-card-${variant}"><div class="bnx-ap-card-header">${input.glyph ? `<span class="bnx-glyph bnx-icon-${/^[a-z]{3,10}$/.test(input.icon ?? '') ? input.icon : 'check'}" aria-hidden="true">${input.icon === 'number' && input.index !== undefined ? String(integer(input.index, 1, 99)).padStart(2, '0') : ''}</span>` : ''}${input.index === undefined || input.glyph ? '' : `<span class="bnx-number" aria-hidden="true">${String(integer(input.index, 1, 99)).padStart(2, '0')}</span>`}${input.label === undefined ? '' : `<p class="bnx-item-label">${optional(input.label, 32)}</p>`}<h3 class="bnx-subtitle bnx-ap-card-title">${linkedTitle}</h3></div><div class="bnx-ap-card-content">${input.value === undefined ? '' : `<p class="bnx-item-value">${optional(input.value, 48)}</p>`}<p class="bnx-copy bnx-ap-card-description">${escape(text(input.text, 420))}</p></div>${input.footer === undefined ? '' : `<div class="bnx-ap-card-footer">${optional(input.footer, 180)}</div>`}</article>`;
}

function hex(value: string) { if (typeof value !== 'string' || !/^#[a-fA-F0-9]{6}$/.test(value)) throw new Error('BNX_ADAPTER_COLOR_INVALID'); return value; }
/** Libraries.dev getSmallColorGradients + innerRadius calculation, made static.
 * Uses a token-derived palette; no pulse driver, masking, custom-property
 * animation, uploaded asset, WebGL or model is required. */
export function adaptedAccentStyle(input: { accent: string; surface: string; radius?: number; borderWidth?: number }) {
  const accent = hex(input.accent), surface = hex(input.surface), radius = integer(input.radius ?? 16, 0, 48), borderWidth = integer(input.borderWidth ?? 1, 1, 4);
  const innerRadius = Math.max(0, radius - borderWidth);
  const palette = [
    { color: accent, pos: '2% 68%', size: '9px 18px' },
    { color: accent, pos: '72% -3%', size: '59px 9px' },
    { color: accent, pos: '74% 100%', size: '42px 7px' },
    { color: accent, pos: '100% 27%', size: '10px 17px' },
  ];
  const gradient = palette.map(c => `radial-gradient(ellipse ${c.size} at ${c.pos}, ${c.color}, transparent)`).join(',\n    ');
  return { className: 'bnx-ap-accent', style: `--bnx-ap-accent-gradient:${gradient};--bnx-ap-accent-surface:${surface};--bnx-ap-accent-color:${accent};--bnx-ap-accent-radius:${radius}px;--bnx-ap-accent-inner-radius:${innerRadius}px;--bnx-ap-accent-width:${borderWidth}px;`, gradient, innerRadius };
}

const CSS: Readonly<Record<V2SourceId, string>> = Object.freeze({
  boardui: `.bnx-section .bnx-ap-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:52px;max-width:100%;padding:12px 24px;border:1px solid transparent;border-radius:var(--bnx-control-radius,10px);background:var(--bnx-accent);color:var(--bnx-accent-text);font:inherit;font-weight:600;white-space:normal;cursor:pointer;text-decoration:none;box-shadow:0 1px 2px #00000014;transition:transform .16s ease,box-shadow .16s ease}.bnx-section .bnx-ap-button-label{display:inline-flex;align-items:center;justify-content:center;min-width:0;padding:0 4px;overflow-wrap:anywhere}.bnx-section .bnx-ap-button-icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:20px;height:20px;transition:transform .16s ease}.bnx-section .bnx-ap-button:hover .bnx-ap-button-icon{transform:translate(2px,-2px)}.bnx-section .bnx-ap-button-secondary{background:var(--bnx-surface);border-color:var(--bnx-border);color:var(--bnx-text);box-shadow:none}.bnx-section .bnx-ap-button:hover{transform:translateY(-2px);box-shadow:0 12px 24px -14px #00000066;text-decoration:none}.bnx-section .bnx-ap-button:active{box-shadow:none}.bnx-section .bnx-ap-button:focus-visible{outline:3px solid var(--bnx-text);outline-offset:4px;box-shadow:0 0 0 2px var(--bnx-background)}`,
  bencho: `.bnx-ap-aspect{display:grid;align-items:center;justify-items:center;width:100%;min-width:0;aspect-ratio:var(--bnx-ratio);overflow:hidden;background:var(--bnx-raised);border-radius:var(--bnx-media-radius)}.bnx-ap-aspect>img{display:block;width:100%;height:100%;object-fit:cover;object-position:var(--bnx-position,50% 50%)}.bnx-ap-aspect-native>img{height:auto;object-fit:contain}`,
  beui: `.bnx-ap-faq{width:100%}.bnx-section .bnx-ap-faq-item{overflow:hidden;background:var(--bnx-surface);color:var(--bnx-text);border:1px solid var(--bnx-border);border-radius:var(--bnx-panel-radius,28px);margin:0 0 12px}.bnx-section .bnx-ap-faq-item>summary{display:flex;align-items:center;gap:16px;min-height:54px;padding:12px 16px;list-style:none;cursor:pointer;text-align:start;background:transparent}.bnx-ap-faq-item>summary::-webkit-details-marker{display:none}.bnx-ap-faq-item>summary::after{display:none}.bnx-ap-faq-title{flex:1;min-width:0;font-size:var(--bnx-label);font-weight:600;overflow-wrap:anywhere}.bnx-ap-faq-chevron{display:grid;align-items:center;justify-items:center;flex-shrink:0;width:24px;height:24px;color:var(--bnx-muted)}.bnx-ap-faq-item[open] .bnx-ap-faq-chevron{transform:rotate(180deg)}.bnx-section .bnx-ap-faq-content{padding:0 16px 16px;font-size:var(--bnx-body);line-height:1.6;color:var(--bnx-muted);overflow-wrap:anywhere}.bnx-section .bnx-ap-faq-item>summary:focus-visible{outline:3px solid var(--bnx-accent);outline-offset:-4px}`,
  'watermelon-ui': `.bnx-section .bnx-ap-footer-groups{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:32px;min-width:0;flex:1}.bnx-ap-footer-group{min-width:0}.bnx-section .bnx-ap-footer-group h3{margin:0 0 16px;font-size:var(--bnx-label);font-weight:600;line-height:1.4}.bnx-section .bnx-ap-footer-group ul{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:8px}.bnx-section .bnx-ap-footer-group a{display:inline-flex;align-items:center;min-height:44px;max-width:100%;color:var(--bnx-muted);font-size:var(--bnx-small);line-height:1.5;overflow-wrap:anywhere}.bnx-section .bnx-ap-footer-group a:hover{color:var(--bnx-text)}@media(min-width:768px){.bnx-section .bnx-ap-footer-groups{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(min-width:1200px){.bnx-section .bnx-ap-footer-groups{grid-template-columns:repeat(4,minmax(0,1fr))}}`,
  'libraries-dev': `.bnx-section .bnx-ap-accent{border:var(--bnx-ap-accent-width,1px) solid transparent;border-radius:var(--bnx-ap-accent-radius,16px);background-color:var(--bnx-border);background-image:linear-gradient(var(--bnx-ap-accent-surface,var(--bnx-surface)),var(--bnx-ap-accent-surface,var(--bnx-surface))),var(--bnx-ap-accent-gradient);background-origin:padding-box,border-box;background-clip:padding-box,border-box;box-shadow:0 1px 2px #00000014}`,
  'heroui-open': `.bnx-section .bnx-ap-card{position:relative;display:flex;flex-direction:column;gap:12px;overflow:visible;padding:32px;border-radius:min(32px,var(--bnx-panel-radius));min-width:0}.bnx-ap-card-header{display:flex;flex-direction:column;gap:12px}.bnx-ap-card-content{display:flex;flex:1;flex-direction:column;gap:4px}.bnx-ap-card-footer{display:flex;flex-direction:row;align-items:center;font-size:var(--bnx-small);color:var(--bnx-muted)}.bnx-ap-card-default{background:var(--bnx-surface)}.bnx-ap-card-secondary{background:var(--bnx-raised)}.bnx-section .bnx-ap-card-transparent{border:none;background:transparent;box-shadow:none}.bnx-ap-card-title{font-weight:600}.bnx-ap-card-description{line-height:1.65;color:var(--bnx-muted)}`,
});
const helpers: Readonly<Record<V2SourceId, readonly Function[]>> = Object.freeze({
  boardui: [renderAdaptedAction], bencho: [adaptedAspectGeometry], beui: [renderAdaptedFaq],
  'watermelon-ui': [renderAdaptedFooterGroups], 'libraries-dev': [hex, adaptedAccentStyle], 'heroui-open': [renderAdaptedCard],
});
function ids(values: readonly string[]) { const requested = new Set(values); if ([...requested].some(id => !sourceOrder.includes(id as V2SourceId))) throw new Error('BNX_ADAPTER_SOURCE_UNKNOWN'); return sourceOrder.filter(id => requested.has(id)); }
export function getAdaptedPrimitiveCss(sourceIds: readonly string[]) { return ids(sourceIds).map(id => CSS[id]).join('\n'); }
export function adaptedPrimitivesFingerprint(sourceIds: readonly string[]) {
  const selected = ids(sourceIds);
  return JSON.stringify({sourceIdentity,version: ADAPTED_PRIMITIVES_VERSION, shapes: selected.includes('bencho') ? BENCHO_ASPECT_SHAPES : null, sources: selected, css: getAdaptedPrimitiveCss(selected) });
}
export function hasImplementedV2Adapter(sourceId: string) { return sourceOrder.includes(sourceId as V2SourceId) && helpers[sourceId as V2SourceId].every(fn => typeof fn === 'function') && !!CSS[sourceId as V2SourceId]; }
const patternSources: Readonly<Record<string, readonly V2SourceId[]>> = Object.freeze({
  'hero-cover': ['boardui', 'bencho'], 'hero-stage': ['boardui', 'bencho'], 'media-story': ['boardui', 'bencho'], 'media-mosaic': ['boardui', 'bencho'],
  features: ['boardui', 'heroui-open'], process: ['boardui'], faq: ['boardui', 'beui'], footer: ['boardui', 'watermelon-ui'], action: ['boardui', 'libraries-dev'], banner: ['boardui', 'bencho'], manifesto: ['boardui'], contact: ['boardui'], 'hero-kit': ['boardui'], 'kit-statement': ['boardui'], 'kit-duo': ['boardui'], 'kit-steps': ['boardui'], 'kit-cta': ['boardui'],
});
export function getAdaptedSourceIdsForPattern(patternId: string): V2SourceId[] {
  const sources = patternSources[patternId]; if (!sources) throw new Error('BNX_PATTERN_UNKNOWN'); return [...sources];
}
