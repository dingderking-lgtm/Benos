import { z } from 'zod';
import { patternContentSchema, patternMediaSchema } from '../../contracts/section-patterns';
import sourceIdentity from './source-identity.json';

/** A separate namespace: importing this module never changes the bns-1 contract. */
export const BNX_VERSION = 'bnx-1' as const;
export const BNX_SCHEMA_VERSION = 'bnx-schema-1' as const;
export const WEBSITE_TOKEN_VERSION = 'bnx-tokens-1' as const;
export const V2_PRESETS = ['calm-paper', 'bold-signal', 'deep-studio'] as const;
export const V2_PATTERN_IDS = ['hero-cover', 'hero-stage', 'media-story', 'media-mosaic', 'features', 'process', 'faq', 'footer', 'action', 'banner', 'manifesto', 'contact', 'hero-kit', 'kit-statement', 'kit-duo', 'kit-steps', 'kit-cta'] as const;
export type V2Preset = typeof V2_PRESETS[number];
export type V2PatternId = typeof V2_PATTERN_IDS[number];
export type V2Role = 'hero' | 'media' | 'features' | 'process' | 'faq' | 'footer' | 'action' | 'contact';
export type V2Range = readonly [number, number];
export type V2Capacity = { items: V2Range; questions: V2Range; media: V2Range; actions: V2Range; navigation: V2Range; contact: V2Range };
export type V2VariantDefinition = { id: string; label: string; layoutKey: string; capacity: V2Capacity; preferredMedia: V2Range; completeSubjects: boolean };
export type V2PatternDefinition = { id: V2PatternId; label: string; role: V2Role; revision: number; description: string; sourceIds: readonly string[]; variants: readonly V2VariantDefinition[] };

const capacity = (items: V2Range = [0, 0], media: V2Range = [0, 0], extra: Partial<V2Capacity> = {}): V2Capacity => ({ items, media, questions: [0, 0], actions: [0, 2], navigation: [0, 0], contact: [0, 0], ...extra });
const variant = (id: string, label: string, layoutKey: string, limits: V2Capacity, preferredMedia: V2Range = [0, 0], completeSubjects = true): V2VariantDefinition => ({ id, label, layoutKey, capacity: limits, preferredMedia, completeSubjects });
/** Frozen definitions are also the validation rules. Media may be absent; no fabricated image is required. */
export const V2_PATTERN_DEFINITIONS: readonly V2PatternDefinition[] = deepFreeze([
  { id: 'hero-cover', label: '场景封面', role: 'hero', revision: 1, description: '可裁切场景与独立文字面，手机保留图文阅读顺序。', sourceIds: ['boardui', 'bencho'], variants: [
    variant('scene', '场景与文字面', 'cover-panel', capacity([0, 3], [0, 1]), [1, 1], false),
    variant('editorial', '编辑式封面', 'cover-editorial', capacity([0, 3], [0, 1]), [1, 1], false),
  ] },
  { id: 'hero-stage', label: '品牌与视觉舞台', role: 'hero', revision: 1, description: '主张、行动与完整主体图片形成紧密关系。', sourceIds: ['boardui', 'bencho'], variants: [
    variant('split', '并列舞台', 'copy-media-split', capacity([0, 3], [0, 1]), [1, 1]),
    variant('centered', '居中宽幅舞台', 'centered-wide-stage', capacity([0, 3], [0, 1]), [1, 1]),
    variant('showcase', '底板展台', 'stage-panel', capacity([0, 3], [0, 1]), [1, 1]),
    variant('reverse', '图左文右舞台', 'copy-media-reverse', capacity([0, 3], [0, 1]), [1, 1]),
  ] },
  { id: 'media-story', label: '图文叙事', role: 'media', revision: 1, description: '图像与说明按内容关系成组。', sourceIds: ['boardui', 'bencho'], variants: [
    variant('alternating', '交替图文', 'alternating-story', capacity([2, 4], [0, 4]), [2, 4]),
    variant('lead-list', '主图与说明列表', 'lead-media-list', capacity([3, 5], [0, 1]), [1, 1]),
    variant('spotlight', '宽幅主图与浮动说明卡', 'spotlight-card', capacity([0, 3], [0, 1]), [1, 1]),
  ] },
  { id: 'media-mosaic', label: '有主次的图像组', role: 'media', revision: 1, description: '区分主景和细节；缺图明确退化成连续内容。', sourceIds: ['boardui', 'bencho'], variants: [
    variant('dominant', '主景与双细节', 'dominant-pair', capacity([0, 3], [0, 3]), [3, 3]),
    variant('bento', '四格拼贴', 'weighted-mosaic', capacity([0, 4], [0, 4]), [4, 4]),
    variant('cards', '图文目录卡片', 'catalogue-cards', capacity([2, 4], [0, 4]), [3, 3]),
  ] },
  { id: 'features', label: '特性与选择依据', role: 'features', revision: 1, description: '语义要点共用清晰的阅读层级。', sourceIds: ['boardui', 'heroui-open'], variants: [
    variant('grid', '特性网格', 'feature-grid', capacity([3, 6])),
    variant('ledger', '编号条目', 'feature-ledger', capacity([3, 6])),
    variant('band', '深色要点带', 'feature-band', capacity([3, 4])),
    variant('statement', '大标题主张与要点', 'feature-statement', capacity([2, 4])),
  ] },
  { id: 'process', label: '步骤与路径', role: 'process', revision: 1, description: '使用有序列表表达行动顺序，不依赖脚本动画。', sourceIds: ['boardui'], variants: [
    variant('steps', '横向步骤', 'process-steps', capacity([3, 5])),
    variant('timeline', '纵向时间线', 'process-timeline', capacity([3, 5])),
    variant('cards', '大数字步骤卡', 'process-cards', capacity([3, 4])),
  ] },
  { id: 'faq', label: '常见问答', role: 'faq', revision: 1, description: '原生 details 交互，可键盘展开并在无脚本时使用。', sourceIds: ['boardui', 'beui'], variants: [
    variant('split', '标题与问答并列', 'faq-split', capacity([0, 0], [0, 0], { questions: [3, 8] })),
    variant('centered', '集中问答', 'faq-centered', capacity([0, 0], [0, 0], { questions: [3, 8] })),
  ] },
  { id: 'footer', label: '品牌落款与目录', role: 'footer', revision: 1, description: '共享页脚位置与真实的导航、联系资料。', sourceIds: ['boardui', 'watermelon-ui'], variants: [
    variant('directory', '品牌与目录', 'footer-directory', capacity([0, 0], [0, 0], { navigation: [0, 4], contact: [0, 3] })),
    variant('compact', '紧凑落款', 'footer-compact', capacity([0, 0], [0, 0], { navigation: [0, 2], contact: [0, 3] })),
  ] },
  { id: 'banner', label: '整屏图片带', role: 'media', revision: 1, description: '一张图占满整行，文字压在图上或与图对开；用于需要气势的主题画面。', sourceIds: ['boardui', 'bencho'], variants: [
    variant('fullbleed', '全幅大图与压图标题', 'banner-fullbleed', capacity([0, 0], [0, 1]), [1, 1]),
    variant('split', '半幅出血图与主张', 'banner-split', capacity([0, 3], [0, 1]), [1, 1]),
  ] },
  { id: 'manifesto', label: '大字宣言', role: 'features', revision: 1, description: '以超大字排版承载一句品牌主张或几个关键词，不依赖卡片。', sourceIds: ['boardui'], variants: [
    variant('center', '居中宣言', 'manifesto-center', capacity([0, 3])),
    variant('index', '大字条目', 'manifesto-index', capacity([3, 5])),
  ] },
  { id: 'contact', label: '联系方式与询盘', role: 'contact', revision: 1, description: '客户确认过的联系方式；可带 CMS 原生询盘表单，导入后即可收集信息。', sourceIds: ['boardui'], variants: [
    variant('form', '联系方式与询盘表单', 'contact-form', capacity([0, 4], [0, 0], { contact: [0, 3], actions: [0, 1] })),
    variant('details', '联系方式与说明', 'contact-details', capacity([0, 4], [0, 0], { contact: [0, 3], actions: [0, 2] })),
  ] },
  // Template-derived kit (kit.ts): ported from the platform's own starter template, not generic blocks.
  { id: 'hero-kit', label: '母版首屏', role: 'hero', revision: 1, description: '主张与带说明的配图并排，下方是入口卡和一张说明卡。items 前两项是入口卡（label 小标、title、text、href），第三项是说明卡（title、text、href、linkLabel）；body 是底部一行说明，可用 | 分成左右两段；media 可带 caption。', sourceIds: ['boardui'], variants: [
    variant('routes', '主张、配图与入口卡', 'kit-hero-routes', capacity([0, 3], [0, 1]), [1, 1]),
  ] },
  { id: 'kit-statement', label: '母版主张', role: 'features', revision: 1, description: '左侧小标与两行主张，右侧一到两段说明（lead、body）和一个文字链接（actions 第一项）。', sourceIds: ['boardui'], variants: [
    variant('split', '左主张右说明', 'kit-statement-split', capacity([0, 0], [0, 0], { actions: [0, 1] })),
  ] },
  { id: 'kit-duo', label: '母版图文卡', role: 'media', revision: 1, description: '每项一张带说明的配图、标题、一段说明和文字链接（href、linkLabel）；media 与 items 按顺序一一对应，media 可带 caption。', sourceIds: ['boardui'], variants: [
    variant('cards', '带说明的图文卡', 'kit-duo-cards', capacity([2, 4], [0, 4]), [2, 2]),
  ] },
  { id: 'kit-steps', label: '母版编号流程', role: 'process', revision: 1, description: '编号卡片排成一行，每张一个步骤标题和一段说明。', sourceIds: ['boardui'], variants: [
    variant('flow', '编号卡片流程', 'kit-steps-flow', capacity([3, 4])),
  ] },
  { id: 'kit-cta', label: '母版行动带', role: 'action', revision: 1, description: '整行主色带：左侧大标题，右侧一句说明和反白按钮。', sourceIds: ['boardui'], variants: [
    variant('band', '整行行动带', 'kit-cta-band', capacity([0, 0], [0, 0], { actions: [1, 2] })),
  ] },
  { id: 'action', label: '清晰的下一步', role: 'action', revision: 1, description: '主行动明确，支持一个必要的次行动。', sourceIds: ['boardui', 'libraries-dev'], variants: [
    variant('band', '行动带', 'action-band', capacity([0, 3], [0, 0], { actions: [1, 2] })),
    variant('split', '文案与行动并列', 'action-split', capacity([0, 3], [0, 0], { actions: [1, 2] })),
    variant('centered', '深色居中行动', 'action-centered', capacity([0, 0], [0, 0], { actions: [1, 2] })),
  ] },
]);

export function deepFreeze<T>(value: T): T {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze(child);
  }
  return value;
}

export const websiteTokenSnapshotSchema = z.object({
  version: z.literal(WEBSITE_TOKEN_VERSION), preset: z.enum(V2_PRESETS),
  colors: z.object(Object.fromEntries(['background', 'surface', 'raised', 'text', 'muted', 'accent', 'accentText', 'border', 'dark', 'darkText'].map(k => [k, z.string().regex(/^#[a-fA-F0-9]{6}$/)])) as Record<'background'|'surface'|'raised'|'text'|'muted'|'accent'|'accentText'|'border'|'dark'|'darkText', z.ZodString>).strict(),
  type: z.object({ display: z.number().int().min(36).max(96), title: z.number().int().min(24).max(56), subtitle: z.number().int().min(20).max(32), body: z.number().int().min(16).max(20), label: z.number().int().min(14).max(20), small: z.number().int().min(14).max(18) }).strict(),
  space: z.object({ section: z.number().int().min(48).max(144), sectionMobile: z.number().int().min(32).max(80), group: z.number().int().min(16).max(48), container: z.number().int().min(960).max(1920), gutter: z.number().int().min(16).max(40) }).strict(),
  radius: z.object({ control: z.number().int().min(0).max(32), media: z.number().int().min(0).max(48), panel: z.number().int().min(0).max(48) }).strict(),
  motion: z.object({ durationMs: z.number().int().min(0).max(250) }).strict(),
}).strict();
export type WebsiteTokenSnapshot = z.output<typeof websiteTokenSnapshotSchema>;
const TOKEN_PRESETS: Record<V2Preset, WebsiteTokenSnapshot> = deepFreeze({
  'calm-paper': { version: WEBSITE_TOKEN_VERSION, preset: 'calm-paper', colors: { background: '#f6f4ef', surface: '#ffffff', raised: '#ede8de', text: '#252a2d', muted: '#555c60', accent: '#245f4b', accentText: '#ffffff', border: '#d6d4ce', dark: '#203c32', darkText: '#ffffff' }, type: { display: 60, title: 48, subtitle: 24, body: 16, label: 16, small: 14 }, space: { section: 96, sectionMobile: 64, group: 24, container: 1680, gutter: 32 }, radius: { control: 24, media: 16, panel: 24 }, motion: { durationMs: 160 } },
  'bold-signal': { version: WEBSITE_TOKEN_VERSION, preset: 'bold-signal', colors: { background: '#f6f3ff', surface: '#ffffff', raised: '#e6dcff', text: '#231a36', muted: '#61556e', accent: '#6535d1', accentText: '#ffffff', border: '#cdbce9', dark: '#24143c', darkText: '#ffffff' }, type: { display: 60, title: 48, subtitle: 24, body: 16, label: 16, small: 14 }, space: { section: 96, sectionMobile: 64, group: 24, container: 1680, gutter: 32 }, radius: { control: 6, media: 8, panel: 12 }, motion: { durationMs: 160 } },
  'deep-studio': { version: WEBSITE_TOKEN_VERSION, preset: 'deep-studio', colors: { background: '#111b26', surface: '#192736', raised: '#223447', text: '#f3f6fa', muted: '#bec9d7', accent: '#a9d6ec', accentText: '#102534', border: '#46596d', dark: '#0c131c', darkText: '#f3f6fa' }, type: { display: 60, title: 48, subtitle: 24, body: 16, label: 16, small: 14 }, space: { section: 96, sectionMobile: 64, group: 24, container: 1680, gutter: 32 }, radius: { control: 12, media: 16, panel: 24 }, motion: { durationMs: 160 } },
});
/** New mutable copy for a workflow snapshot; the registry itself cannot be mutated by a caller. */
export function createWebsiteTokenSnapshot(preset: V2Preset): WebsiteTokenSnapshot {
  return websiteTokenSnapshotSchema.parse(TOKEN_PRESETS[z.enum(V2_PRESETS).parse(preset)]);
}

function definition(patternId: string, variantId: string) {
  const family = V2_PATTERN_DEFINITIONS.find(f => f.id === patternId);
  const variant = family?.variants.find(v => v.id === variantId);
  return family && variant ? { family, variant } : undefined;
}
export function validateV2Section(input: { patternId: V2PatternId; variantId: string; content: z.output<typeof patternContentSchema>; media: z.output<typeof patternMediaSchema>[] }, ctx: z.RefinementCtx) {
  const match = definition(input.patternId, input.variantId);
  if (!match) { ctx.addIssue({ code: 'custom', path: ['variantId'], message: 'BNX_VARIANT_UNKNOWN' }); return; }
  for (const key of ['items', 'questions', 'actions', 'navigation', 'contact', 'media'] as const) {
    const count = key === 'media' ? input.media.length : input.content[key].length;
    const [min, max] = match.variant.capacity[key];
    if (count < min || count > max) ctx.addIssue({ code: 'custom', path: key === 'media' ? ['media'] : ['content', key], message: `BNX_CAPACITY_${key.toUpperCase()}: ${min}..${max}` });
  }
  if (new Set(input.media.map(m => m.id)).size !== input.media.length) ctx.addIssue({ code: 'custom', path: ['media'], message: 'BNX_MEDIA_IDS_DUPLICATE' });
  if (!match.variant.completeSubjects && input.media.some(m => m.kind !== 'missing' && m.subjectPolicy === 'complete')) ctx.addIssue({ code: 'custom', path: ['media'], message: 'BNX_COVER_REQUIRES_CROP_SAFE' });
  if (((match.family.id === 'media-story' && match.variant.id === 'alternating') || (match.family.id === 'media-mosaic' && match.variant.id === 'cards') || match.family.id === 'kit-duo') && input.media.length > input.content.items.length) ctx.addIssue({ code: 'custom', path: ['media'], message: 'BNX_MEDIA_WITHOUT_STORY_ITEM' });
  if (input.patternId !== 'footer' && (input.content.copyright || input.content.imageAttribution)) ctx.addIssue({ code: 'custom', path: ['content'], message: 'BNX_FOOTER_CONTENT_OUTSIDE_FOOTER' });
}

export const v2SectionSchema = z.object({
  id: z.string().regex(/^[a-z][a-z0-9-]{0,23}$/), patternId: z.enum(V2_PATTERN_IDS), variantId: z.string().min(1).max(32),
  preset: z.enum(V2_PRESETS), content: patternContentSchema, media: z.array(patternMediaSchema).max(4).default([]),
}).strict().superRefine(validateV2Section);
export type V2SectionInput = z.input<typeof v2SectionSchema>;
export type ResolvedV2Section = z.output<typeof v2SectionSchema>;

export function validateV2Page(input: { preset: V2Preset; sections: ResolvedV2Section[] }, ctx: z.RefinementCtx) {
  if (new Set(input.sections.map(s => s.id)).size !== input.sections.length) ctx.addIssue({ code: 'custom', path: ['sections'], message: 'BNX_SECTION_IDS_DUPLICATE' });
  if (input.sections.some(s => s.preset !== input.preset)) ctx.addIssue({ code: 'custom', path: ['sections'], message: 'BNX_ONE_WEBSITE_PRESET' });
  const frames = input.sections.flatMap(s => s.media.map(m => `${s.id}-${m.id}`));
  if (new Set(frames).size !== frames.length) ctx.addIssue({ code: 'custom', path: ['sections'], message: 'BNX_FRAME_IDS_DUPLICATE' });
  const heroes = input.sections.filter(s => s.patternId.startsWith('hero-'));
  if (heroes.length > 1 || (heroes.length && input.sections[0] !== heroes[0])) ctx.addIssue({ code: 'custom', path: ['sections'], message: 'BNX_HERO_MUST_BE_FIRST_AND_UNIQUE' });
  const footers = input.sections.filter(s => s.patternId === 'footer');
  if (footers.length > 1 || (footers.length && input.sections.at(-1) !== footers[0])) ctx.addIssue({ code: 'custom', path: ['sections'], message: 'BNX_FOOTER_MUST_BE_LAST_AND_UNIQUE' });
}
export const v2PageSchema = z.object({ version: z.literal('bnx-compose-1'), preset: z.enum(V2_PRESETS), sections: z.array(v2SectionSchema).min(1).max(12) }).strict().superRefine(validateV2Page);
export type V2PageInput = z.input<typeof v2PageSchema>;
export type ResolvedV2Page = z.output<typeof v2PageSchema>;
export function parseV2Page(raw: unknown): ResolvedV2Page { return v2PageSchema.parse(raw); }
/** Structural JSON schema; runtime parsing above still enforces semantic refinements. */
export const v2PageJsonSchema = z.toJSONSchema(v2PageSchema);
export function v2ContractFingerprint() { return JSON.stringify({sourceIdentity,scope:'bnx-validation'}); }
