import { deepFreeze } from './contracts';
import { ADAPTED_PRIMITIVES_VERSION, hasImplementedV2Adapter } from './adapted-primitives';

export const V2_SOURCE_IDS = ["boardui","bencho","beui","watermelon-ui","libraries-dev","heroui-open"] as const;
export type V2SourceId = typeof V2_SOURCE_IDS[number];
export type V2Notice = { sourceId: V2SourceId; spdx: 'MIT' | 'Apache-2.0'; path: string; sha256: string; text: string; url: string };
export type V2Adaptation = { id:string; sourceId:V2SourceId; version:typeof ADAPTED_PRIMITIVES_VERSION; targetFile:string; targetExports:readonly string[]; sourceFiles:readonly {path:string;sha256:string;regions:readonly {startLine:number;endLine:number;excerpt:string;transformation:string}[]}[]; retained:readonly string[]; changed:readonly string[]; removedDependencies:readonly string[]; runtimePackages:readonly string[]; modificationNotice:V2Notice };
export type V2Source = { id: V2SourceId; name: string; repository: string; commit: string; license: 'MIT' | 'Apache-2.0'; files: readonly {path: string; sha256: string}[]; notices: readonly V2Notice[]; relationship: 'behavior-visual-reference' | 'adapted-source' | 'copied-source'; copiedFiles: readonly string[]; adaptedFiles: readonly string[]; runtimePackages: readonly string[]; dependencyReview: 'pending' | 'local-adapters-only'; adaptations?: readonly V2Adaptation[]; adapterReady?: true; localRuntimeFiles?: readonly string[]; reviewOnly: true; customerExportReady: false; excluded: readonly string[] };

/** Public source snapshots from the audited 2026-11-14 collection. All files are collected reference files, not claims of copied or executed code. This is not production licensing approval. */
const SOURCES: readonly V2Source[] = deepFreeze([
  {
    "id": "boardui",
    "name": "BoardUI public",
    "repository": "https://github.com/BoardUI/boardui",
    "commit": "ec5c5eb3e29c2441be63b9422cd54f411ef23466",
    "license": "MIT",
    "files": [
      {
        "path": "styles/theme.css",
        "sha256": "3c7fcc7710b0f44be0d86bc8e822e88f737d0269d207e9e2f4d2e73fd6da8f34"
      },
      {
        "path": "styles/typography.css",
        "sha256": "dfd4e9b446998d063efe96a47fc31fd2492639bf641d0da1b60645fe4dcc32a1"
      },
      {
        "path": "styles/globals.css",
        "sha256": "61eb0d742c68f3fe7914626d1a31f97a9e242f084191098bbc27379b5d683183"
      },
      {
        "path": "utils/cx.ts",
        "sha256": "db35ea5afa8b2e0fd51319bc49288c4df7c98ec53440b43903636a32e3319d9d"
      },
      {
        "path": "components/base/buttons/button.tsx",
        "sha256": "b147c988c73dd8c226ab6ede3d7019eac9a7125191bbd646fcdd25bea803ca41"
      },
      {
        "path": "components/foundations/direction/direction.tsx",
        "sha256": "7bfab075a6d5fe3a2b3f3b810ba2ab4e870f50029a41d8c4b0bee9bfd4a43756"
      },
      {
        "path": "components/application/agent-thinking/agent-thinking.tsx",
        "sha256": "3f5fd82e603d49a8d3f9862dacd12fda874aa43fb958f3784425aa52b62f7d90"
      },
      {
        "path": "utils/directional-icon.ts",
        "sha256": "02692ff42abfea0e3ddf0ca79cd1f816cdce65f923efb0d61d2f3663a9202c47"
      },
      {
        "path": "components/foundations/template-copy/template-copy.tsx",
        "sha256": "1db60e15c1a5d6a710a08d249e05e3853521f604e8dcf5757c1ad4a75bad011f"
      }
    ],
    "notices": [
      {
        "sourceId": "boardui",
        "spdx": "MIT",
        "path": "LICENSE",
        "sha256": "7a28c78354f8f88d8773f72bf37fb9c037817f8abd2fa5a63694d6c946a5ce80",
        "text": "MIT License\n\nCopyright (c) 2026 Mertcan Dundar Esmergul (BoardUI)\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.\n",
        "url": "https://github.com/BoardUI/boardui/blob/ec5c5eb3e29c2441be63b9422cd54f411ef23466/LICENSE"
      }
    ],
    "relationship": "behavior-visual-reference",
    "copiedFiles": [],
    "adaptedFiles": [],
    "runtimePackages": [],
    "dependencyReview": "pending",
    "reviewOnly": true,
    "customerExportReady": false,
    "excluded": [
      "Pro and purchased source",
      "Sample photos and brand assets",
      "Model weights and model packages",
      "Unreviewed transitive dependencies"
    ]
  },
  {
    "id": "bencho",
    "name": "Bencho",
    "repository": "https://github.com/cabralorenzo/bencho",
    "commit": "c65992417427bb09e661674ffa800bef29adef49",
    "license": "MIT",
    "files": [
      {
        "path": "tokens.css",
        "sha256": "abb75ad433a1b7ec6f0136b603c279b5c9e53afa067c0b5f9cd10c95529d0f1a"
      },
      {
        "path": "blocks/aspect/Aspect.tsx",
        "sha256": "f6eb1a097028c6a7851e3c8762e58ba83040f1132789845a941605f6b94317ce"
      },
      {
        "path": "blocks/aspect/Aspect.css",
        "sha256": "d4302ac71bbfe9fe9ba774b6002d19290717cc2a70ab7c008bba32888df236b6"
      },
      {
        "path": "blocks/image-compare/Compare.tsx",
        "sha256": "8ff1dbf4f0c707a08c54b460b2052c54dc4494b19a04be40b4d776f0cd7c032d"
      },
      {
        "path": "blocks/image-compare/Compare.css",
        "sha256": "9cb77f08edc237348eb10360e33f02064b0d015a36c255f301d52cb2cc1d0221"
      },
      {
        "path": "blocks/image-accordion/Accordion.tsx",
        "sha256": "08253c004d597fbeb8b0ded4c3f39178e2d8f62e5ea08c6463d2ee5f9b5b1339"
      },
      {
        "path": "blocks/image-accordion/Accordion.css",
        "sha256": "616f5495c0648d1d2d9892aa7c5f0e49ad2d4ddb7a6f343758dfcc95148d7c56"
      }
    ],
    "notices": [
      {
        "sourceId": "bencho",
        "spdx": "MIT",
        "path": "LICENSE",
        "sha256": "9f9d2eedd3383d018e343db1205e9b41f07fa49632050482fb40cc1a03dd64fe",
        "text": "MIT License\n\nCopyright (c) 2026 Lorenzo Cabra\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.\n\n---\n\nNot covered by this licence: the Bencho name and the goat mark, and the\nphotographs shown on bencho.dev (none are included here). Third-party\nmaterial keeps its own licence; see THIRD_PARTY.md.\n",
        "url": "https://github.com/cabralorenzo/bencho/blob/c65992417427bb09e661674ffa800bef29adef49/LICENSE"
      },
      {
        "sourceId": "bencho",
        "spdx": "MIT",
        "path": "THIRD_PARTY.md",
        "sha256": "5a06fa88b258e8f876f93d900fda3b7efd8a17908fbdab5f557eb2f3f1eef969",
        "text": "# Third-party notices\n\n## cuelume\n\nThe sounds **Beacon** (`beacon`) and **Plop** (`plop`) in `sounds/sounds.ts` are rebuilt from the recipes of [cuelume](https://cuelume.dev) by Daniel Belyi.\n\n```\nMIT License\n\nCopyright (c) 2026 Daniel Belyi\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.\n```\n\n## Packages\n\nThe blocks use [framer-motion](https://github.com/motiondivision/motion), [lucide-react](https://github.com/lucide-icons/lucide) and [liquid-gooey](https://www.npmjs.com/package/liquid-gooey), each under its own licence.\n",
        "url": "https://github.com/cabralorenzo/bencho/blob/c65992417427bb09e661674ffa800bef29adef49/THIRD_PARTY.md"
      }
    ],
    "relationship": "behavior-visual-reference",
    "copiedFiles": [],
    "adaptedFiles": [],
    "runtimePackages": [],
    "dependencyReview": "pending",
    "reviewOnly": true,
    "customerExportReady": false,
    "excluded": [
      "Pro and purchased source",
      "Sample photos and brand assets",
      "Model weights and model packages",
      "Unreviewed transitive dependencies"
    ]
  },
  {
    "id": "beui",
    "name": "BeUI",
    "repository": "https://github.com/starc007/ui-components",
    "commit": "c4b58a94a38d04e33d53da569a2bb288a002a467",
    "license": "MIT",
    "files": [
      {
        "path": "components/motion/before-after-slider.tsx",
        "sha256": "b99bc8ef017c6a769389b64bb8833f6a26cf795581ae6c4cbe4e4e847e1ca279"
      },
      {
        "path": "components/motion/aspect-ratio.tsx",
        "sha256": "8301eb7c28ea5cc9feb05c4269cca80a5ac56dda7b7bd5056e514245a742b021"
      },
      {
        "path": "components/motion/timeline.tsx",
        "sha256": "8f3ff61f55a0d4850675c4bbb20aa13ba21cbb8b6b8ad3a85da86e8cea03d6ae"
      },
      {
        "path": "components/motion/bouncy-accordion.tsx",
        "sha256": "1a1ae4714ff6aa4170b49852e753d4cfc58c425aa3e1853558bf5f9a6b9ec554"
      },
      {
        "path": "tests/before-after-slider.a11y.test.tsx",
        "sha256": "9934212abfdc69eac714f13025376ed779fed2382e92ee83b1ffd2b2c1003fd0"
      },
      {
        "path": "tests/aspect-ratio.a11y.test.tsx",
        "sha256": "8b3ca15977c118e87b518e772619e72effc893e8ea795e0c2ac1d8f125b8bf0c"
      },
      {
        "path": "components/motion/sortable-list.tsx",
        "sha256": "2e590df216b46aaf2894e64f232f1f8a146275996b12a0bdce6e3a02e3bf6deb"
      },
      {
        "path": "lib/ease.ts",
        "sha256": "cde4ce91ec645335cfa8297d6094c90b6e62ee6a1a021fe2ac0a6ece673c2a8f"
      },
      {
        "path": "lib/hooks/use-hover-capable.ts",
        "sha256": "b5b9397bfa03859e04673c8f1817cf13ff55d2a9688955d6e0459ae70db90d06"
      },
      {
        "path": "lib/i18n.tsx",
        "sha256": "5431651a737b19a53b2777fe214c6c6177ae7877919d94750c6c594565946dba"
      },
      {
        "path": "lib/touch.ts",
        "sha256": "f2a15c243c86c8bd1abb6e2e65a423b3a4c45cc1d797ebd83997f21cd1beadb9"
      },
      {
        "path": "lib/utils.ts",
        "sha256": "7c8c3dfc0cdd370d44932828eb067ef771c8fe7996693221d5d4b90af6d54f2d"
      }
    ],
    "notices": [
      {
        "sourceId": "beui",
        "spdx": "MIT",
        "path": "LICENSE",
        "sha256": "9e27b491d5691a1bd95708e79de23beb2962f33fe6c1ee31ab639f43009a0b20",
        "text": "MIT License\n\nCopyright (c) 2026 Saurabh Chauhan\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.\n",
        "url": "https://github.com/starc007/ui-components/blob/c4b58a94a38d04e33d53da569a2bb288a002a467/LICENSE"
      }
    ],
    "relationship": "behavior-visual-reference",
    "copiedFiles": [],
    "adaptedFiles": [],
    "runtimePackages": [],
    "dependencyReview": "pending",
    "reviewOnly": true,
    "customerExportReady": false,
    "excluded": [
      "Pro and purchased source",
      "Sample photos and brand assets",
      "Model weights and model packages",
      "Unreviewed transitive dependencies"
    ]
  },
  {
    "id": "watermelon-ui",
    "name": "Watermelon UI",
    "repository": "https://github.com/WatermelonCorp/watermelon-platform",
    "commit": "dcaf556f3ac4924d1f9e7b31118ce8e2febc93c2",
    "license": "MIT",
    "files": [
      {
        "path": "src/data/contents/blocks/hero/hero-1/index.tsx",
        "sha256": "7580f82f057e14d1b3135db173b3dd7c6fd95ed728b4ebd7ade8811f5df9c700"
      },
      {
        "path": "src/data/contents/blocks/footer/footer-1/index.tsx",
        "sha256": "e89b1a71860ff54dc769fc33d7eb4c73b51db5c774d84101bb9e0d9e911bcfe3"
      },
      {
        "path": "src/components/ui/accordion.tsx",
        "sha256": "b0cf5f16b1007da2690758036ae846a795b21cd3bff6baac4060ba8da5383b94"
      },
      {
        "path": "src/components/ui/button.tsx",
        "sha256": "b30646ff985d5b85a60a62eefb3e63e488b49a536fab66a75be1b8b2ad6969ee"
      },
      {
        "path": "src/lib/utils.ts",
        "sha256": "7dc23d640d1cd4b716abd100b4ef57279bb15406ab860c6717c742b9512db019"
      },
      {
        "path": "src/data/contents/blocks/hero/hero-12/index.tsx",
        "sha256": "0d753806b0475b890d2510eedb4eaeda7e5fefa1168a8582bce982990edc303f"
      },
      {
        "path": "src/data/contents/blocks/footer/footer-7/index.tsx",
        "sha256": "d8e157e8558585451ec5da3b0f96eb4849dcf7c39a19d138e373c2ce2a7472d7"
      },
      {
        "path": "src/data/contents/blocks/faq/faq-1/index.tsx",
        "sha256": "05fd967b7357c07e354a35e199cc0bff10d503a2165e24ecc1ea6714a471e13f"
      },
      {
        "path": "src/data/contents/blocks/feature/feature-2/index.tsx",
        "sha256": "ffcb6a7dfd179d5610c571794c5f9bd550b7e693b0ccb8079a93fa44e9009bcb"
      },
      {
        "path": "src/assets/logo-icon.tsx",
        "sha256": "eba19abd2fb918acf9d86d454cf9b0aa4da849091716a6f2745460a483d0a918"
      },
      {
        "path": "src/components/base-ui/input.tsx",
        "sha256": "c4902a8c4967875e30d9f1198175f4f5348a0cdd17e21b5e3d7c9e81d2996ed9"
      },
      {
        "path": "src/components/base-ui/button.tsx",
        "sha256": "8ce26e1867edeb6c7bf6ead440962a609607b05f716a12e69046a5333129e512"
      },
      {
        "path": "src/components/base-ui/accordion.tsx",
        "sha256": "c76de63e9713bd5b773d07d84223990654de9148cfa8ee56e0c61738ae0dcc30"
      },
      {
        "path": "src/components/base-ui/card.tsx",
        "sha256": "12f50f5a0f22974236da15cf0402d046442f72d9e0191775adcd2238aeb96267"
      },
      {
        "path": "src/lib/hugeicons.ts",
        "sha256": "76ae39dd827175c1d596e67fb857a610b6a6a06246e165ed8351646fc8696756"
      }
    ],
    "notices": [
      {
        "sourceId": "watermelon-ui",
        "spdx": "MIT",
        "path": "LICENSE",
        "sha256": "53acf7b74b1e84b858c3340dbc2bcb809491eea857986132873041166ffcdfe0",
        "text": "MIT License\n\nCopyright (c) 2026 Watermelon Platform Contributors\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.\n",
        "url": "https://github.com/WatermelonCorp/watermelon-platform/blob/dcaf556f3ac4924d1f9e7b31118ce8e2febc93c2/LICENSE"
      }
    ],
    "relationship": "behavior-visual-reference",
    "copiedFiles": [],
    "adaptedFiles": [],
    "runtimePackages": [],
    "dependencyReview": "pending",
    "reviewOnly": true,
    "customerExportReady": false,
    "excluded": [
      "Pro and purchased source",
      "Sample photos and brand assets",
      "Model weights and model packages",
      "Unreviewed transitive dependencies"
    ]
  },
  {
    "id": "libraries-dev",
    "name": "Libraries.dev public UI",
    "repository": "https://github.com/Jakubantalik/Libraries.dev",
    "commit": "387b049ca8fe97b5d72999b5bf61a19ab1ccff81",
    "license": "MIT",
    "files": [
      {
        "path": "packages/border-beam/src/BorderBeam.tsx",
        "sha256": "691c54d304b3b8b183e8041d97ec9c230586bab4eda9c5d0f765c28da75020f3"
      },
      {
        "path": "packages/thinking-orbs/src/ThinkingOrb.tsx",
        "sha256": "1c0bdc43869d2758919876f603b19f254e062c275e3869575d6660ec4f2f1bd0"
      },
      {
        "path": "packages/border-beam/src/index.ts",
        "sha256": "4622c3af7f6a70042f78d8050baf01741e500f302a317707f8eb23f719513e96"
      },
      {
        "path": "packages/border-beam/src/pulseDriver.ts",
        "sha256": "d94e8b5d374dbe944d1986ead4329fcd5dac255e648a99946f48dfdadb4e22d1"
      },
      {
        "path": "packages/border-beam/src/styles.ts",
        "sha256": "73008f1f26bc562043a15c15d0efb27cf8359950a8049e1ad5b4cb8682f970d1"
      },
      {
        "path": "packages/border-beam/src/types.ts",
        "sha256": "6af0f7e587fce97540d4d2bfd472ea0dbce28f8cfcdfb9eb7fa20098c1e1ac0c"
      },
      {
        "path": "packages/thinking-orbs/src/engine/braid.ts",
        "sha256": "a0d09442a9162dfa2f16fafb8dc435b88edb0bc9e7011ea6bc558be586ae938b"
      },
      {
        "path": "packages/thinking-orbs/src/engine/core.ts",
        "sha256": "05aa3d5f24c1c35e5fcfd6c804204f0cab3ca7909a6e9089dee3673cbe28e1cc"
      },
      {
        "path": "packages/thinking-orbs/src/engine/index.ts",
        "sha256": "8d3004c6cb6bb8a7923a6c6c600294e697269bbecda688b565d51afc3e6a4275"
      },
      {
        "path": "packages/thinking-orbs/src/engine/lattice.ts",
        "sha256": "785e03ee9dc7ddc955952f666c8b269351571dffc96fb0ddc4050e5718444397"
      },
      {
        "path": "packages/thinking-orbs/src/engine/morph.ts",
        "sha256": "d341cb6d9dc6e681c3965a46b7200b211c37136b439d3d86dfc88fd85e9c12d4"
      },
      {
        "path": "packages/thinking-orbs/src/engine/orbits.ts",
        "sha256": "27f974f2d9e0e1614055882673217b4db230bf8e4b88dc5ac21b298a924dfb65"
      },
      {
        "path": "packages/thinking-orbs/src/engine/profiles.ts",
        "sha256": "a092bef089437cc7fce681ca6f9af24a831191d77e91814ad6b66cbb1d8fab01"
      },
      {
        "path": "packages/thinking-orbs/src/engine/registry.ts",
        "sha256": "fb36d8815f598e69535bb86af576260c375bf1dcf4d54c0d6a31e68f42a13c49"
      },
      {
        "path": "packages/thinking-orbs/src/engine/ribbon.ts",
        "sha256": "a79cc262b42f3f12f5d4a108e7cf9710938d5fb1f6166c9fa789f02d4e0679c4"
      },
      {
        "path": "packages/thinking-orbs/src/engine/types.ts",
        "sha256": "33dc880d34da6c68adf0d03e484f42f43e97783b764991f21b8a6e386c2d7972"
      },
      {
        "path": "packages/thinking-orbs/src/engine/web.ts",
        "sha256": "1dc2e38e9d01298ebf32744a3569f4e3234ba4af61cc64c5089511f7a9b7369d"
      },
      {
        "path": "packages/thinking-orbs/src/gravity.ts",
        "sha256": "a6fb8aa9174be72ae528fbfed6ae103de4ee0bf57f3b35f32012b7cb5f5d82c2"
      },
      {
        "path": "packages/thinking-orbs/src/index.ts",
        "sha256": "6a6d1da12c5a82e33684b168590be596055921bbb43145702ee86cc50467cab8"
      },
      {
        "path": "packages/thinking-orbs/src/presets.ts",
        "sha256": "a06ab0dea139a735ef9ac212965dc86dc7be60bc3bfd9e3cd9e93b9701faae31"
      },
      {
        "path": "packages/thinking-orbs/src/theme.ts",
        "sha256": "f8650dcef8796ac92260f62cf3f4739763512012de288a541c0b15b127726a1b"
      },
      {
        "path": "packages/thinking-orbs/src/types.ts",
        "sha256": "de765f265d968db035ae50bafc3c3cd0b9dedb9406ec26ed4b7e85a5c490a63e"
      }
    ],
    "notices": [
      {
        "sourceId": "libraries-dev",
        "spdx": "MIT",
        "path": "LICENSE",
        "sha256": "915a283980628a0ca9e7b423ebafc6f3a0fa1e630ff17d34e59034808d92011c",
        "text": "MIT License\n\nCopyright (c) 2026 Jakub Antalik\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the \"Software\"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.\n",
        "url": "https://github.com/Jakubantalik/Libraries.dev/blob/387b049ca8fe97b5d72999b5bf61a19ab1ccff81/LICENSE"
      }
    ],
    "relationship": "behavior-visual-reference",
    "copiedFiles": [],
    "adaptedFiles": [],
    "runtimePackages": [],
    "dependencyReview": "pending",
    "reviewOnly": true,
    "customerExportReady": false,
    "excluded": [
      "Pro and purchased source",
      "Sample photos and brand assets",
      "Model weights and model packages",
      "Unreviewed transitive dependencies"
    ]
  },
  {
    "id": "heroui-open",
    "name": "HeroUI Open v3 (not Pro)",
    "repository": "https://github.com/heroui-inc/heroui",
    "commit": "05962629748a6bfa2ba43aeb37d81345825f155e",
    "license": "Apache-2.0",
    "files": [
      {
        "path": "packages/react/src/components/accordion/accordion.tsx",
        "sha256": "945d0d1a9d9e42f863caaff54fba52aa635b5c47497cde03b0a01af4714c8139"
      },
      {
        "path": "packages/react/src/components/accordion/index.ts",
        "sha256": "25d95d55805f6aa72c05c6ddfdbc62caed41ee736c1a838a76bba62e8b6933b0"
      },
      {
        "path": "packages/react/src/components/button/button.tsx",
        "sha256": "48aff16fae97de883dbed8dfb82277e002e8b24584d022ece17dcc29c5fc69ee"
      },
      {
        "path": "packages/react/src/components/button/index.ts",
        "sha256": "75c627689b7db871eef82c1a7b7e784e8daabf4307b69c511116143e891ef478"
      },
      {
        "path": "packages/react/src/components/card/card.tsx",
        "sha256": "5a2759eb9ad4ee1894e1354c4c74e6c935ff60f3a5e2e6ec9691a1cf7f0977c7"
      },
      {
        "path": "packages/react/src/components/card/index.ts",
        "sha256": "ed75e73d53345e675e0b1d309fc9bbd86043415e99e6763b45e57f1b170107d4"
      },
      {
        "path": "packages/react/src/components/modal/index.ts",
        "sha256": "d599e19c1800fef8f892d58b6d47567b103d1388d668b5feac27ce8a6208a9df"
      },
      {
        "path": "packages/react/src/components/modal/modal.tsx",
        "sha256": "e516ced500e46a9557dc798591ba50927f87c0688cbf8447d34c542e3747c1e8"
      },
      {
        "path": "packages/react/src/components/popover/index.ts",
        "sha256": "4738ccbb1c65cac8edc5af4fc66a4e1dcae05198c27456b1b77ad25431c38ee2"
      },
      {
        "path": "packages/react/src/components/popover/popover.tsx",
        "sha256": "fdea8c3472630fea7f895e86ba047c6680b9738b9027a58cd5d8b025fa1d3cc3"
      },
      {
        "path": "packages/react/src/components/tabs/index.ts",
        "sha256": "090727f7b925928aa4a01c9c5b774797fea370ce0fe8fdab8c205fe48b43293c"
      },
      {
        "path": "packages/react/src/components/tabs/tabs.tsx",
        "sha256": "8e35b89fce7b8769c481706538c7e6737ea177e0d49193622b67d757144fd336"
      },
      {
        "path": "packages/styles/components/accordion.css",
        "sha256": "db7b4b87f13a08606eed280a4f6178112b0266d26b08f4b81281ce72f5855ea5"
      },
      {
        "path": "packages/styles/components/button.css",
        "sha256": "a2bd37d460655889cbf6f492fb083e7e632201c7ab819c9b2533335a5ecc248c"
      },
      {
        "path": "packages/styles/components/card.css",
        "sha256": "da156ad4192d4dd969a0a41ea0ee3be5474829113c4dfbbe6527d4fbeda203d8"
      },
      {
        "path": "packages/styles/components/modal.css",
        "sha256": "cf36ed155007a018b911d4deae0bbaebb7ede559e803e039fd93c89a5f18fc60"
      },
      {
        "path": "packages/styles/components/popover.css",
        "sha256": "340bd0df719961919cdf75f84c381508284bd12493b97766914b837df76d4805"
      },
      {
        "path": "packages/styles/components/tabs.css",
        "sha256": "7b135099c199e370a2e85c679ed18fde2167c2c38ad50f130e2a33696cd5a56d"
      },
      {
        "path": "packages/styles/src/components/accordion/accordion.styles.ts",
        "sha256": "62b37e31d4aa2845a679c4debb6ca7de50d9acfc8253f3def6310c906a3324b6"
      },
      {
        "path": "packages/styles/src/components/button/button.styles.ts",
        "sha256": "2340b0b95db0688e13089295ce979eee8eec3a69ccf538da06cf0a7d9ac4b8e9"
      },
      {
        "path": "packages/styles/src/components/card/card.styles.ts",
        "sha256": "6e435f3305f58365ce944df2066886a321a15190482d8cf2065e09d929a2f904"
      },
      {
        "path": "packages/styles/src/components/modal/modal.styles.ts",
        "sha256": "ce328c3046a7d60d7812c7880fd966fb1e08cd64e13b133baa4b9359e0a4c75c"
      },
      {
        "path": "packages/styles/src/components/popover/popover.styles.ts",
        "sha256": "e399a0898d641d04cc4038ebc1217be3f6afc296fa720424a6331b65f5c0670f"
      },
      {
        "path": "packages/styles/src/components/tabs/tabs.styles.ts",
        "sha256": "c052f62e55843d46b0ee21d5a691d1ec40b7f9afded098f8c9f6cca12a6ceecd"
      },
      {
        "path": "packages/styles/themes/default/variables.css",
        "sha256": "80efc8752b6e15c2acf285756bfeb26290749005335092fee643ed9ba9084f4c"
      },
      {
        "path": "packages/styles/themes/shared/theme.css",
        "sha256": "70ea884b09e73a7bfa4f72eac91ad43b340c2c94fb06dcc889178472f0711f71"
      }
    ],
    "notices": [
      {
        "sourceId": "heroui-open",
        "spdx": "Apache-2.0",
        "path": "LICENSE",
        "sha256": "bd087c1ebd511adbab74705ec2b31d63d175e8d422f58c1af54754da02b1d329",
        "text": "                                 Apache License\n                           Version 2.0, January 2004\n                        http://www.apache.org/licenses/\n\n   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION\n\n   1. Definitions.\n\n      \"License\" shall mean the terms and conditions for use, reproduction,\n      and distribution as defined by Sections 1 through 9 of this document.\n\n      \"Licensor\" shall mean the copyright owner or entity authorized by\n      the copyright owner that is granting the License.\n\n      \"Legal Entity\" shall mean the union of the acting entity and all\n      other entities that control, are controlled by, or are under common\n      control with that entity. For the purposes of this definition,\n      \"control\" means (i) the power, direct or indirect, to cause the\n      direction or management of such entity, whether by contract or\n      otherwise, or (ii) ownership of fifty percent (50%) or more of the\n      outstanding shares, or (iii) beneficial ownership of such entity.\n\n      \"You\" (or \"Your\") shall mean an individual or Legal Entity\n      exercising permissions granted by this License.\n\n      \"Source\" form shall mean the preferred form for making modifications,\n      including but not limited to software source code, documentation\n      source, and configuration files.\n\n      \"Object\" form shall mean any form resulting from mechanical\n      transformation or translation of a Source form, including but\n      not limited to compiled object code, generated documentation,\n      and conversions to other media types.\n\n      \"Work\" shall mean the work of authorship, whether in Source or\n      Object form, made available under the License, as indicated by a\n      copyright notice that is included in or attached to the work\n      (an example is provided in the Appendix below).\n\n      \"Derivative Works\" shall mean any work, whether in Source or Object\n      form, that is based on (or derived from) the Work and for which the\n      editorial revisions, annotations, elaborations, or other modifications\n      represent, as a whole, an original work of authorship. For the purposes\n      of this License, Derivative Works shall not include works that remain\n      separable from, or merely link (or bind by name) to the interfaces of,\n      the Work and Derivative Works thereof.\n\n      \"Contribution\" shall mean any work of authorship, including\n      the original version of the Work and any modifications or additions\n      to that Work or Derivative Works thereof, that is intentionally\n      submitted to the Licensor for inclusion in the Work by the copyright owner\n      or by an individual or Legal Entity authorized to submit on behalf of\n      the copyright owner. For the purposes of this definition, \"submitted\"\n      means any form of electronic, verbal, or written communication sent\n      to the Licensor or its representatives, including but not limited to\n      communication on electronic mailing lists, source code control systems,\n      and issue tracking systems that are managed by, or on behalf of, the\n      Licensor for the purpose of discussing and improving the Work, but\n      excluding communication that is conspicuously marked or otherwise\n      designated in writing by the copyright owner as \"Not a Contribution.\"\n\n      \"Contributor\" shall mean Licensor and any individual or Legal Entity\n      on behalf of whom a Contribution has been received by the Licensor and\n      subsequently incorporated within the Work.\n\n   2. Grant of Copyright License. Subject to the terms and conditions of\n      this License, each Contributor hereby grants to You a perpetual,\n      worldwide, non-exclusive, no-charge, royalty-free, irrevocable\n      copyright license to reproduce, prepare Derivative Works of,\n      publicly display, publicly perform, sublicense, and distribute the\n      Work and such Derivative Works in Source or Object form.\n\n   3. Grant of Patent License. Subject to the terms and conditions of\n      this License, each Contributor hereby grants to You a perpetual,\n      worldwide, non-exclusive, no-charge, royalty-free, irrevocable\n      (except as stated in this section) patent license to make, have made,\n      use, offer to sell, sell, import, and otherwise transfer the Work,\n      where such license applies only to those patent claims licensable\n      by such Contributor that are necessarily infringed by their\n      Contribution(s) alone or by combination of their Contribution(s)\n      with the Work to which such Contribution(s) was submitted. If You\n      institute patent litigation against any entity (including a\n      cross-claim or counterclaim in a lawsuit) alleging that the Work\n      or a Contribution incorporated within the Work constitutes direct\n      or contributory patent infringement, then any patent licenses\n      granted to You under this License for that Work shall terminate\n      as of the date such litigation is filed.\n\n   4. Redistribution. You may reproduce and distribute copies of the\n      Work or Derivative Works thereof in any medium, with or without\n      modifications, and in Source or Object form, provided that You\n      meet the following conditions:\n\n      (a) You must give any other recipients of the Work or\n          Derivative Works a copy of this License; and\n\n      (b) You must cause any modified files to carry prominent notices\n          stating that You changed the files; and\n\n      (c) You must retain, in the Source form of any Derivative Works\n          that You distribute, all copyright, patent, trademark, and\n          attribution notices from the Source form of the Work,\n          excluding those notices that do not pertain to any part of\n          the Derivative Works; and\n\n      (d) If the Work includes a \"NOTICE\" text file as part of its\n          distribution, then any Derivative Works that You distribute must\n          include a readable copy of the attribution notices contained\n          within such NOTICE file, excluding any notices that do not\n          pertain to any part of the Derivative Works, in at least one\n          of the following places: within a NOTICE text file distributed\n          as part of the Derivative Works; within the Source form or\n          documentation, if provided along with the Derivative Works; or,\n          within a display generated by the Derivative Works, if and\n          wherever such third-party notices normally appear. The contents\n          of the NOTICE file are for informational purposes only and\n          do not modify the License. You may add Your own attribution\n          notices within Derivative Works that You distribute, alongside\n          or as an addendum to the NOTICE text from the Work, provided\n          that such additional attribution notices cannot be construed\n          as modifying the License.\n\n      You may add Your own copyright statement to Your modifications and\n      may provide additional or different license terms and conditions\n      for use, reproduction, or distribution of Your modifications, or\n      for any such Derivative Works as a whole, provided Your use,\n      reproduction, and distribution of the Work otherwise complies with\n      the conditions stated in this License.\n\n   5. Submission of Contributions. Unless You explicitly state otherwise,\n      any Contribution intentionally submitted for inclusion in the Work\n      by You to the Licensor shall be under the terms and conditions of\n      this License, without any additional terms or conditions.\n      Notwithstanding the above, nothing herein shall supersede or modify\n      the terms of any separate license agreement you may have executed\n      with Licensor regarding such Contributions.\n\n   6. Trademarks. This License does not grant permission to use the trade\n      names, trademarks, service marks, or product names of the Licensor,\n      except as required for reasonable and customary use in describing the\n      origin of the Work and reproducing the content of the NOTICE file.\n\n   7. Disclaimer of Warranty. Unless required by applicable law or\n      agreed to in writing, Licensor provides the Work (and each\n      Contributor provides its Contributions) on an \"AS IS\" BASIS,\n      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or\n      implied, including, without limitation, any warranties or conditions\n      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A\n      PARTICULAR PURPOSE. You are solely responsible for determining the\n      appropriateness of using or redistributing the Work and assume any\n      risks associated with Your exercise of permissions under this License.\n\n   8. Limitation of Liability. In no event and under no legal theory,\n      whether in tort (including negligence), contract, or otherwise,\n      unless required by applicable law (such as deliberate and grossly\n      negligent acts) or agreed to in writing, shall any Contributor be\n      liable to You for damages, including any direct, indirect, special,\n      incidental, or consequential damages of any character arising as a\n      result of this License or out of the use or inability to use the\n      Work (including but not limited to damages for loss of goodwill,\n      work stoppage, computer failure or malfunction, or any and all\n      other commercial damages or losses), even if such Contributor\n      has been advised of the possibility of such damages.\n\n   9. Accepting Warranty or Additional Liability. While redistributing\n      the Work or Derivative Works thereof, You may choose to offer,\n      and charge a fee for, acceptance of support, warranty, indemnity,\n      or other liability obligations and/or rights consistent with this\n      License. However, in accepting such obligations, You may act only\n      on Your own behalf and on Your sole responsibility, not on behalf\n      of any other Contributor, and only if You agree to indemnify,\n      defend, and hold each Contributor harmless for any liability\n      incurred by, or claims asserted against, such Contributor by reason\n      of your accepting any such warranty or additional liability.\n\n   END OF TERMS AND CONDITIONS\n\n   APPENDIX: How to apply the Apache License to your work.\n\n      To apply the Apache License to your work, attach the following\n      boilerplate notice, with the fields enclosed by brackets \"[]\"\n      replaced with your own identifying information. (Don't include\n      the brackets!)  The text should be enclosed in the appropriate\n      comment syntax for the file format. Please also get an approval\n      from the project maintainers before using the Apache License.\n\n   Copyright 2025 NextUI Inc.\n\n   Licensed under the Apache License, Version 2.0 (the \"License\");\n   you may not use this file except in compliance with the License.\n   You may obtain a copy of the License at\n\n       http://www.apache.org/licenses/LICENSE-2.0\n\n   Unless required by applicable law or agreed to in writing, software\n   distributed under the License is distributed on an \"AS IS\" BASIS,\n   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\n   See the License for the specific language governing permissions and\n   limitations under the License.\n",
        "url": "https://github.com/heroui-inc/heroui/blob/05962629748a6bfa2ba43aeb37d81345825f155e/LICENSE"
      }
    ],
    "relationship": "behavior-visual-reference",
    "copiedFiles": [],
    "adaptedFiles": [],
    "runtimePackages": [],
    "dependencyReview": "pending",
    "reviewOnly": true,
    "customerExportReady": false,
    "excluded": [
      "Pro and purchased source",
      "Sample photos and brand assets",
      "Model weights and model packages",
      "Unreviewed transitive dependencies"
    ]
  }
]);

const ADAPTATIONS: readonly V2Adaptation[] = deepFreeze([
  {
    "id": "boardui-link-button",
    "sourceId": "boardui",
    "version": "bnx-adapt-1",
    "targetFile": "platform/src/design-system/v2/adapted-primitives.ts",
    "targetExports": [
      "renderAdaptedAction"
    ],
    "sourceFiles": [
      {
        "path": "components/base/buttons/button.tsx",
        "sha256": "b147c988c73dd8c226ab6ede3d7019eac9a7125191bbd646fcdd25bea803ca41",
        "regions": [
          {
            "startLine": 77,
            "endLine": 94,
            "excerpt": "const styles = sortCx({\n  base: [\n    \"inline-flex items-center justify-center gap-0.5 whitespace-nowrap overflow-hidden\",\n    \"font-sans select-none cursor-pointer\",\n    \"button-press-motion\",\n    \"outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-border-focus-ring\",\n    \"disabled:cursor-not-allowed aria-disabled:cursor-not-allowed\",\n  ].join(\" \"),\n\n  // Base shape per size (used when label is present OR medium icon-only).\n  size: {\n    medium: \"h-9 rounded-2lg p-2 text-body-medium\",\n    small:  \"h-8 rounded-lg px-2 py-1.5 text-body-medium\",\n    xs:     \"h-6 rounded-sm px-2 text-caption-1-semibold\",\n  },\n\n  // Icon-only override:\n  //   Medium → keep p-2; w expands from content (8+20+8 = 36) → square.",
            "transformation": "Translate inline-flex, label/icon positioning, focus and variant state utilities to scoped CSS; touch height raised to 44px."
          },
          {
            "startLine": 182,
            "endLine": 218,
            "excerpt": "export function ButtonLink({\n  variant = \"primary\",\n  size = \"medium\",\n  iconOnly = false,\n  leadingIcon: Leading,\n  trailingIcon: Trailing,\n  children,\n  className,\n  ref,\n  ...props\n}: ButtonLinkProps) {\n  return (\n    <a\n      ref={ref}\n      className={cx(\n        styles.base,\n        styles.size[size],\n        styles.variant[variant],\n        iconOnly && styles.iconOnlySize[size],\n        className,\n      )}\n      {...props}\n    >\n      {Leading ? <Leading className={cx(styles.icon[size], directionalIconClass(Leading))} aria-hidden /> : null}\n      {!iconOnly && children !== undefined && children !== null && (\n        <span className={styles.label[size]}>{children}</span>\n      )}\n      {!iconOnly && Trailing ? (\n        <Trailing className={cx(styles.icon[size], directionalIconClass(Trailing))} aria-hidden />\n      ) : null}\n    </a>\n  );\n}\n\n/** Style maps, exported for advanced composition and the dev Design Tuner. */\nexport const buttonStyles = styles;\n",
            "transformation": "Port navigational anchor and separate label/decorative trailing icon slots; escape content and validate href."
          }
        ]
      }
    ],
    "retained": [
      "ButtonLink anchor and label/icon slots",
      "primary/secondary backgrounds, borders, hover/focus/pressed states"
    ],
    "changed": [
      "React props/ref and class combiners removed",
      "Tailwind values converted to local BNX tokens",
      "labels wrap on narrow widths instead of nowrap",
      "icon-only and disabled application controls omitted; only real navigation links emitted"
    ],
    "removedDependencies": [
      "React",
      "cx/sortCx utility imports",
      "directional-icon helper",
      "Remix icon components",
      "Tailwind runtime/build dependency"
    ],
    "runtimePackages": [],
    "modificationNotice": {
      "sourceId": "boardui",
      "spdx": "MIT",
      "path": "BENOS-MODIFICATIONS-boardui.txt",
      "sha256": "0199fddbd592980c786291fc21c410475176133df1ba331519da29ebf3985d3e",
      "text": "Benos modification notice — boardui\nAdaptation: boardui-link-button; local version bnx-adapt-1; modified 2026-11-14.\nPinned original: https://github.com/BoardUI/boardui at ec5c5eb3e29c2441be63b9422cd54f411ef23466.\nOriginal license: MIT. Original copyright and license text are preserved as separate notices.\nOriginal files: components/base/buttons/button.tsx (SHA256 b147c988c73dd8c226ab6ede3d7019eac9a7125191bbd646fcdd25bea803ca41).\nRetained source structure or calculations: ButtonLink anchor and label/icon slots; primary/secondary backgrounds, borders, hover/focus/pressed states.\nChanges made by Benos: React props/ref and class combiners removed; Tailwind values converted to local BNX tokens; labels wrap on narrow widths instead of nowrap; icon-only and disabled application controls omitted; only real navigation links emitted.\nRemoved upstream dependencies: React, cx/sortCx utility imports, directional-icon helper, Remix icon components, Tailwind runtime/build dependency.\nThis adaptation uses only escaped native HTML and local scoped CSS. No upstream React runtime, JavaScript widget driver, font, demo photo, logo, Pro component, model, or remote asset is shipped by this adaptation.\nScope: only the listed adapted fragments, not a claim that the entire upstream library has been ported or that its behavior is identical. Native browser behavior replaces scripted controls where documented.\nTarget: platform/src/design-system/v2/adapted-primitives.ts; exports renderAdaptedAction.\n",
      "url": "https://github.com/BoardUI/boardui/tree/ec5c5eb3e29c2441be63b9422cd54f411ef23466"
    }
  },
  {
    "id": "bencho-aspect-frame",
    "sourceId": "bencho",
    "version": "bnx-adapt-1",
    "targetFile": "platform/src/design-system/v2/adapted-primitives.ts",
    "targetExports": [
      "adaptedAspectGeometry"
    ],
    "sourceFiles": [
      {
        "path": "blocks/aspect/Aspect.tsx",
        "sha256": "f6eb1a097028c6a7851e3c8762e58ba83040f1132789845a941605f6b94317ce",
        "regions": [
          {
            "startLine": 64,
            "endLine": 68,
            "excerpt": "const SHAPES = [\n  { id: \"land\", w: 276, h: 207, label: \"Landscape, 4 by 3\" },\n  { id: \"square\", w: 239, h: 239, label: \"Square, 1 by 1\" },\n  { id: \"tall\", w: 207, h: 276, label: \"Portrait, 3 by 4\" },\n] as const;",
            "transformation": "Retain 276x207 / 239x239 / 207x276 equal-area shapes; scale numerically on the server."
          }
        ]
      },
      {
        "path": "blocks/aspect/Aspect.css",
        "sha256": "d4302ac71bbfe9fe9ba774b6002d19290717cc2a70ab7c008bba32888df236b6",
        "regions": [
          {
            "startLine": 22,
            "endLine": 26,
            "excerpt": ".asp-stage {\n  display: grid;\n  place-items: center;\n  width: 100%;}\n",
            "transformation": "Keep centered grid and full-width stage; expand place-items into sanitizer-supported align-items and justify-items."
          },
          {
            "startLine": 27,
            "endLine": 33,
            "excerpt": ".asp-pic {\n  background-color: var(--surface-2);\n  background-size: cover;\n  background-position: center;\n  /* `cover` and a frame that moves: the picture stays\n     undistorted and the CROP changes, which is what a format\n     switch actually is. Contain would letterbox and fit would",
            "transformation": "Map background cover positioning to actual img object-fit, plus a native aspect-preserving branch for complete subjects."
          }
        ]
      }
    ],
    "retained": [
      "equal-area landscape/square/portrait dimensions",
      "centered non-distorting picture stage"
    ],
    "changed": [
      "static server-derived geometry instead of client crop-switcher state",
      "native/complete format keeps exact original dimensions",
      "demo sheep/photo, SVG controls, morph transition and tab radio controller removed",
      "all frame values bounded and tokenized"
    ],
    "removedDependencies": [
      "React useState/useRef",
      "demo photo/data SVG",
      "interactive crop keyboard controller",
      "motion timing utilities"
    ],
    "runtimePackages": [],
    "modificationNotice": {
      "sourceId": "bencho",
      "spdx": "MIT",
      "path": "BENOS-MODIFICATIONS-bencho.txt",
      "sha256": "f9371e16a058e0a11d87dd43ed0b1b2004bb5e565d81e48c8c6b5f3bb0ac4f1f",
      "text": "Benos modification notice — bencho\nAdaptation: bencho-aspect-frame; local version bnx-adapt-1; modified 2026-11-14.\nPinned original: https://github.com/cabralorenzo/bencho at c65992417427bb09e661674ffa800bef29adef49.\nOriginal license: MIT. Original copyright and license text are preserved as separate notices.\nOriginal files: blocks/aspect/Aspect.tsx (SHA256 f6eb1a097028c6a7851e3c8762e58ba83040f1132789845a941605f6b94317ce); blocks/aspect/Aspect.css (SHA256 d4302ac71bbfe9fe9ba774b6002d19290717cc2a70ab7c008bba32888df236b6).\nRetained source structure or calculations: equal-area landscape/square/portrait dimensions; centered non-distorting picture stage.\nChanges made by Benos: static server-derived geometry instead of client crop-switcher state; native/complete format keeps exact original dimensions; demo sheep/photo, SVG controls, morph transition and tab radio controller removed; all frame values bounded and tokenized.\nRemoved upstream dependencies: React useState/useRef, demo photo/data SVG, interactive crop keyboard controller, motion timing utilities.\nThis adaptation uses only escaped native HTML and local scoped CSS. No upstream React runtime, JavaScript widget driver, font, demo photo, logo, Pro component, model, or remote asset is shipped by this adaptation.\nScope: only the listed adapted fragments, not a claim that the entire upstream library has been ported or that its behavior is identical. Native browser behavior replaces scripted controls where documented.\nTarget: platform/src/design-system/v2/adapted-primitives.ts; exports adaptedAspectGeometry.\n",
      "url": "https://github.com/cabralorenzo/bencho/tree/c65992417427bb09e661674ffa800bef29adef49"
    }
  },
  {
    "id": "beui-native-accordion",
    "sourceId": "beui",
    "version": "bnx-adapt-1",
    "targetFile": "platform/src/design-system/v2/adapted-primitives.ts",
    "targetExports": [
      "renderAdaptedFaq"
    ],
    "sourceFiles": [
      {
        "path": "components/motion/bouncy-accordion.tsx",
        "sha256": "1a1ae4714ff6aa4170b49852e753d4cfc58c425aa3e1853558bf5f9a6b9ec554",
        "regions": [
          {
            "startLine": 185,
            "endLine": 189,
            "excerpt": "            \"flex min-h-[54px] w-full items-center gap-4 px-5 text-left outline-none transition-colors\",\n            \"focus-visible:bg-muted/25\",\n            \"disabled:pointer-events-none\",\n            classNames?.trigger,\n          )}",
            "transformation": "Translate trigger geometry into native summary with 54px minimum touch target and visible keyboard focus."
          },
          {
            "startLine": 209,
            "endLine": 220,
            "excerpt": "          <motion.span\n            aria-hidden\n            animate={{ rotate: open ? 180 : 0 }}\n            transition={reduce ? { duration: 0 } : CHEVRON_TRANSITION}\n            className={cn(\n              \"grid h-6 w-6 shrink-0 place-items-center text-muted-foreground\",\n              classNames?.chevron,\n            )}\n          >\n            <ChevronDown className=\"h-4 w-4\" />\n          </motion.span>\n        </button>",
            "transformation": "Retain trailing decorative chevron and open-state rotation as CSS [open]."
          },
          {
            "startLine": 245,
            "endLine": 256,
            "excerpt": "            className=\"px-5 pb-5\"\n          >\n            <div\n              className={cn(\n                \"text-[15px] leading-6 text-muted-foreground\",\n                classNames?.description,\n              )}\n            >\n              {item.description}\n            </div>\n          </motion.div>\n        </motion.section>",
            "transformation": "Retain inset answer layout; remove measured height and replace button/controlled region with details."
          }
        ]
      }
    ],
    "retained": [
      "trigger/title/chevron/content hierarchy",
      "54px trigger and 20px answer inset",
      "explicit open-state chevron"
    ],
    "changed": [
      "button/aria-expanded and controlled region become details/summary",
      "questions wrap rather than truncate",
      "ResizeObserver, spring height projection and opacity driver removed",
      "native multi-open disclosures replace the original single controlled item"
    ],
    "removedDependencies": [
      "React hooks",
      "motion/react",
      "lucide-react",
      "cn utility",
      "EASE_OUT"
    ],
    "runtimePackages": [],
    "modificationNotice": {
      "sourceId": "beui",
      "spdx": "MIT",
      "path": "BENOS-MODIFICATIONS-beui.txt",
      "sha256": "d994f96913f3c9bf4ac6beb2683be891257fe96c546b505dc866845acd970061",
      "text": "Benos modification notice — beui\nAdaptation: beui-native-accordion; local version bnx-adapt-1; modified 2026-11-14.\nPinned original: https://github.com/starc007/ui-components at c4b58a94a38d04e33d53da569a2bb288a002a467.\nOriginal license: MIT. Original copyright and license text are preserved as separate notices.\nOriginal files: components/motion/bouncy-accordion.tsx (SHA256 1a1ae4714ff6aa4170b49852e753d4cfc58c425aa3e1853558bf5f9a6b9ec554).\nRetained source structure or calculations: trigger/title/chevron/content hierarchy; 54px trigger and 20px answer inset; explicit open-state chevron.\nChanges made by Benos: button/aria-expanded and controlled region become details/summary; questions wrap rather than truncate; ResizeObserver, spring height projection and opacity driver removed; native multi-open disclosures replace the original single controlled item.\nRemoved upstream dependencies: React hooks, motion/react, lucide-react, cn utility, EASE_OUT.\nThis adaptation uses only escaped native HTML and local scoped CSS. No upstream React runtime, JavaScript widget driver, font, demo photo, logo, Pro component, model, or remote asset is shipped by this adaptation.\nScope: only the listed adapted fragments, not a claim that the entire upstream library has been ported or that its behavior is identical. Native browser behavior replaces scripted controls where documented.\nTarget: platform/src/design-system/v2/adapted-primitives.ts; exports renderAdaptedFaq.\n",
      "url": "https://github.com/starc007/ui-components/tree/c4b58a94a38d04e33d53da569a2bb288a002a467"
    }
  },
  {
    "id": "watermelon-footer-groups",
    "sourceId": "watermelon-ui",
    "version": "bnx-adapt-1",
    "targetFile": "platform/src/design-system/v2/adapted-primitives.ts",
    "targetExports": [
      "renderAdaptedFooterGroups"
    ],
    "sourceFiles": [
      {
        "path": "src/data/contents/blocks/footer/footer-1/index.tsx",
        "sha256": "e89b1a71860ff54dc769fc33d7eb4c73b51db5c774d84101bb9e0d9e911bcfe3",
        "regions": [
          {
            "startLine": 71,
            "endLine": 95,
            "excerpt": "          <div className=\"grid flex-1 grid-cols-2 gap-8 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:gap-8\">\n            {linkGroups.map((group, idx) => (\n              <div key={idx} className=\"space-y-5\">\n                <h4 className=\"text-foreground text-sm font-medium\">\n                  {group.title}\n                </h4>\n                <ul className=\"space-y-4\">\n                  {group.links.map((link, linkIdx) => (\n                    <li key={linkIdx}>\n                      <a\n                        href={link.href}\n                        className=\"text-muted-foreground hover:text-foreground text-sm transition-colors\"\n                      >\n                        {link.label}\n                      </a>\n                    </li>\n                  ))}\n                </ul>\n              </div>\n            ))}\n          </div>\n        </div>\n\n\n        <div className=\"mt-16 flex items-center justify-center border-t pt-8\">",
            "transformation": "Port linkGroups heading/list/anchor tree and responsive grid; use semantic nav and safe validated links."
          }
        ]
      }
    ],
    "retained": [
      "grouped directory map",
      "heading/list/anchor nesting",
      "responsive multi-column grid and muted/hover link states"
    ],
    "changed": [
      "React map output converted to escaped native markup",
      "newsletter form/Input/Button removed because no real submission binding was supplied",
      "logo/brand/demo text removed",
      "max 4 groups and 6 links; 44px links and safe URL validation"
    ],
    "removedDependencies": [
      "React",
      "Input component",
      "Button component",
      "Tailwind build dependency"
    ],
    "runtimePackages": [],
    "modificationNotice": {
      "sourceId": "watermelon-ui",
      "spdx": "MIT",
      "path": "BENOS-MODIFICATIONS-watermelon-ui.txt",
      "sha256": "c6554fe7254ad4827f67e7d7324e827617af7d74561e84e3f6b4158ae716c504",
      "text": "Benos modification notice — watermelon-ui\nAdaptation: watermelon-footer-groups; local version bnx-adapt-1; modified 2026-11-14.\nPinned original: https://github.com/WatermelonCorp/watermelon-platform at dcaf556f3ac4924d1f9e7b31118ce8e2febc93c2.\nOriginal license: MIT. Original copyright and license text are preserved as separate notices.\nOriginal files: src/data/contents/blocks/footer/footer-1/index.tsx (SHA256 e89b1a71860ff54dc769fc33d7eb4c73b51db5c774d84101bb9e0d9e911bcfe3).\nRetained source structure or calculations: grouped directory map; heading/list/anchor nesting; responsive multi-column grid and muted/hover link states.\nChanges made by Benos: React map output converted to escaped native markup; newsletter form/Input/Button removed because no real submission binding was supplied; logo/brand/demo text removed; max 4 groups and 6 links; 44px links and safe URL validation.\nRemoved upstream dependencies: React, Input component, Button component, Tailwind build dependency.\nThis adaptation uses only escaped native HTML and local scoped CSS. No upstream React runtime, JavaScript widget driver, font, demo photo, logo, Pro component, model, or remote asset is shipped by this adaptation.\nScope: only the listed adapted fragments, not a claim that the entire upstream library has been ported or that its behavior is identical. Native browser behavior replaces scripted controls where documented.\nTarget: platform/src/design-system/v2/adapted-primitives.ts; exports renderAdaptedFooterGroups.\n",
      "url": "https://github.com/WatermelonCorp/watermelon-platform/tree/dcaf556f3ac4924d1f9e7b31118ce8e2febc93c2"
    }
  },
  {
    "id": "libraries-static-border-gradient",
    "sourceId": "libraries-dev",
    "version": "bnx-adapt-1",
    "targetFile": "platform/src/design-system/v2/adapted-primitives.ts",
    "targetExports": [
      "adaptedAccentStyle"
    ],
    "sourceFiles": [
      {
        "path": "packages/border-beam/src/styles.ts",
        "sha256": "73008f1f26bc562043a15c15d0efb27cf8359950a8049e1ad5b4cb8682f970d1",
        "regions": [
          {
            "startLine": 446,
            "endLine": 451,
            "excerpt": "function getSmallColorGradients(colorVariant: BorderBeamColorVariant): string {\n  const palette = smallColorPalettes[colorVariant];\n  return palette.border\n    .map(c => `radial-gradient(ellipse ${c.size} at ${c.pos}, ${c.color}, transparent)`)\n    .join(',\\n    ');\n}",
            "transformation": "Retain radial-gradient map/join construction, using validated theme hex colors."
          },
          {
            "startLine": 267,
            "endLine": 278,
            "excerpt": "export const smallColorPalettes = {\n  colorful: {\n    border: [\n      { color: 'rgb(50, 200, 80)', pos: '2% 68%', size: '9px 18px' },\n      { color: 'rgb(30, 185, 170)', pos: '2% 68%', size: '4px 8px' },\n      { color: 'rgb(255, 120, 40)', pos: '72% -3%', size: '59px 9px' },\n      { color: 'rgb(100, 70, 255)', pos: '74% 100%', size: '42px 7px' },\n      { color: 'rgb(240, 50, 180)', pos: '100% 27%', size: '10px 17px' },\n      { color: 'rgb(180, 40, 240)', pos: '100% 27%', size: '10px 18px' },\n      { color: 'rgb(40, 140, 255)', pos: '100% 27%', size: '5px 10px' },\n      { color: 'rgb(255, 50, 100)', pos: '100% 27%', size: '11px 12px' },\n    ],",
            "transformation": "Reuse four public compact border ellipse positions/sizes; replace the multicolor demo palette with one site accent."
          },
          {
            "startLine": 1448,
            "endLine": 1448,
            "excerpt": "  const innerRadius = Math.max(0, borderRadius - borderWidth);",
            "transformation": "Retain bounded inner-radius calculation for border geometry."
          }
        ]
      }
    ],
    "retained": [
      "radial-gradient ellipse builder",
      "compact edge ellipse positions and dimensions",
      "innerRadius = max(0, outerRadius - borderWidth)"
    ],
    "changed": [
      "freeze the beam as a static decorative edge",
      "remove dynamic IDs, drivers, masks, pulse, hue animation and filters",
      "site tokens supply colors; no arbitrary CSS accepted",
      "text remains on an opaque surface using background clipping"
    ],
    "removedDependencies": [
      "React BorderBeam wrapper",
      "pulse driver",
      "animation/custom property driver",
      "native/WebGL ports",
      "models and remote assets"
    ],
    "runtimePackages": [],
    "modificationNotice": {
      "sourceId": "libraries-dev",
      "spdx": "MIT",
      "path": "BENOS-MODIFICATIONS-libraries-dev.txt",
      "sha256": "43bd4b30e03e5559c674dbee65869b0b2a53c86e55fcb5105ba6388fed12268c",
      "text": "Benos modification notice — libraries-dev\nAdaptation: libraries-static-border-gradient; local version bnx-adapt-1; modified 2026-11-14.\nPinned original: https://github.com/Jakubantalik/Libraries.dev at 387b049ca8fe97b5d72999b5bf61a19ab1ccff81.\nOriginal license: MIT. Original copyright and license text are preserved as separate notices.\nOriginal files: packages/border-beam/src/styles.ts (SHA256 73008f1f26bc562043a15c15d0efb27cf8359950a8049e1ad5b4cb8682f970d1).\nRetained source structure or calculations: radial-gradient ellipse builder; compact edge ellipse positions and dimensions; innerRadius = max(0, outerRadius - borderWidth).\nChanges made by Benos: freeze the beam as a static decorative edge; remove dynamic IDs, drivers, masks, pulse, hue animation and filters; site tokens supply colors; no arbitrary CSS accepted; text remains on an opaque surface using background clipping.\nRemoved upstream dependencies: React BorderBeam wrapper, pulse driver, animation/custom property driver, native/WebGL ports, models and remote assets.\nThis adaptation uses only escaped native HTML and local scoped CSS. No upstream React runtime, JavaScript widget driver, font, demo photo, logo, Pro component, model, or remote asset is shipped by this adaptation.\nScope: only the listed adapted fragments, not a claim that the entire upstream library has been ported or that its behavior is identical. Native browser behavior replaces scripted controls where documented.\nTarget: platform/src/design-system/v2/adapted-primitives.ts; exports adaptedAccentStyle.\n",
      "url": "https://github.com/Jakubantalik/Libraries.dev/tree/387b049ca8fe97b5d72999b5bf61a19ab1ccff81"
    }
  },
  {
    "id": "heroui-native-card",
    "sourceId": "heroui-open",
    "version": "bnx-adapt-1",
    "targetFile": "platform/src/design-system/v2/adapted-primitives.ts",
    "targetExports": [
      "renderAdaptedCard"
    ],
    "sourceFiles": [
      {
        "path": "packages/styles/components/card.css",
        "sha256": "da156ad4192d4dd969a0a41ea0ee3be5474829113c4dfbbe6527d4fbeda203d8",
        "regions": [
          {
            "startLine": 4,
            "endLine": 9,
            "excerpt": ".card {\n  @apply relative flex flex-col gap-3 overflow-visible p-4;\n  @apply shadow-surface;\n  border-radius: min(32px, var(--radius-3xl));\n}\n",
            "transformation": "Expand @apply into native relative flex-column card with gap, surface shadow and capped radius."
          },
          {
            "startLine": 11,
            "endLine": 34,
            "excerpt": ".card__header {\n  @apply flex flex-col;\n}\n\n/* Element - title */\n.card__title {\n  @apply text-sm leading-6 font-medium text-foreground;\n}\n\n/* Element - description */\n.card__description {\n  @apply text-sm leading-5 text-muted;\n}\n\n/* Element - content */\n.card__content {\n  @apply flex flex-1 flex-col gap-1;\n}\n\n/* Element - footer */\n.card__footer {\n  @apply flex flex-row items-center;\n}\n",
            "transformation": "Retain header/content/footer slots, flex content growth and footer alignment; use div slots inside article."
          },
          {
            "startLine": 37,
            "endLine": 52,
            "excerpt": ".card--transparent {\n  @apply border-none bg-transparent shadow-none;\n}\n\n.card--default {\n  @apply bg-surface;\n}\n\n.card--secondary {\n  @apply bg-surface-secondary;\n}\n\n.card--tertiary {\n  @apply bg-surface-tertiary;\n}\n",
            "transformation": "Retain transparent/default/secondary surface variants via Benos tokens."
          }
        ]
      },
      {
        "path": "packages/styles/src/components/card/card.styles.ts",
        "sha256": "6e435f3305f58365ce944df2066886a321a15190482d8cf2065e09d929a2f904",
        "regions": [
          {
            "startLine": 9,
            "endLine": 17,
            "excerpt": "  slots: {\n    base: \"card\",\n    content: \"card__content\",\n    description: \"card__description\",\n    footer: \"card__footer\",\n    header: \"card__header\",\n    title: \"card__title\",\n  },\n  variants: {",
            "transformation": "Retain stable base/header/title/description/content/footer slot names in the adapted class map."
          }
        ]
      }
    ],
    "retained": [
      "card slot hierarchy",
      "flex-column/gap/content-grow/footer alignment",
      "surface variants and capped radius"
    ],
    "changed": [
      "Tailwind @apply/tv removed and expanded into scoped declarations",
      "text size and colors inherit Benos tokens",
      "native article/div markup escapes all content",
      "tertiary variant and React compound-component APIs omitted",
      "Apache change notice added for adapted files"
    ],
    "removedDependencies": [
      "tailwind-variants",
      "Tailwind compiler",
      "React compound component runtime"
    ],
    "runtimePackages": [],
    "modificationNotice": {
      "sourceId": "heroui-open",
      "spdx": "Apache-2.0",
      "path": "BENOS-MODIFICATIONS-heroui-open.txt",
      "sha256": "651e3e599e7c13d622be0fb87adca20ce9d71b8227a7d777b26d6ad0e61314f1",
      "text": "Benos modification notice — heroui-open\nAdaptation: heroui-native-card; local version bnx-adapt-1; modified 2026-11-14.\nPinned original: https://github.com/heroui-inc/heroui at 05962629748a6bfa2ba43aeb37d81345825f155e.\nOriginal license: Apache-2.0. Original copyright and license text are preserved as separate notices.\nOriginal files: packages/styles/components/card.css (SHA256 da156ad4192d4dd969a0a41ea0ee3be5474829113c4dfbbe6527d4fbeda203d8); packages/styles/src/components/card/card.styles.ts (SHA256 6e435f3305f58365ce944df2066886a321a15190482d8cf2065e09d929a2f904).\nRetained source structure or calculations: card slot hierarchy; flex-column/gap/content-grow/footer alignment; surface variants and capped radius.\nChanges made by Benos: Tailwind @apply/tv removed and expanded into scoped declarations; text size and colors inherit Benos tokens; native article/div markup escapes all content; tertiary variant and React compound-component APIs omitted; Apache change notice added for adapted files.\nRemoved upstream dependencies: tailwind-variants, Tailwind compiler, React compound component runtime.\nThis adaptation uses only escaped native HTML and local scoped CSS. No upstream React runtime, JavaScript widget driver, font, demo photo, logo, Pro component, model, or remote asset is shipped by this adaptation.\nScope: only the listed adapted fragments, not a claim that the entire upstream library has been ported or that its behavior is identical. Native browser behavior replaces scripted controls where documented.\nTarget: platform/src/design-system/v2/adapted-primitives.ts; exports renderAdaptedCard.\n",
      "url": "https://github.com/heroui-inc/heroui/tree/05962629748a6bfa2ba43aeb37d81345825f155e"
    }
  }
]);

export function getV2Adaptations(sourceIds: readonly string[] = V2_SOURCE_IDS): V2Adaptation[] {
  return [...new Set(sourceIds)].map(id => { const record = ADAPTATIONS.find(item => item.sourceId === id); if (!record) throw new Error('BNX_SOURCE_UNKNOWN'); return structuredClone(record); });
}
export function getV2Sources(sourceIds: readonly string[] = V2_SOURCE_IDS): V2Source[] {
  return [...new Set(sourceIds)].map(id => {
    const source = SOURCES.find(item => item.id === id), adaptation = ADAPTATIONS.find(item => item.sourceId === id);
    if (!source || !adaptation) throw new Error('BNX_SOURCE_UNKNOWN');
    return { ...structuredClone(source), relationship: 'adapted-source', files: adaptation.sourceFiles.map(file => ({path:file.path,sha256:file.sha256})), copiedFiles: [], adaptedFiles: adaptation.sourceFiles.map(file => file.path), runtimePackages: [], dependencyReview: 'local-adapters-only', adaptations: [structuredClone(adaptation)], adapterReady: true, localRuntimeFiles: [adaptation.targetFile] };
  });
}
export function getV2Notices(sourceIds: readonly string[] = V2_SOURCE_IDS): V2Notice[] {
  return getV2Sources(sourceIds).flatMap(source => [...source.notices.map(notice => ({...notice})), ...source.adaptations!.map(adaptation => ({...adaptation.modificationNotice}))]);
}
/** This checks server-owned local adaptations, not customer approval or a client readiness boolean. */
export function assertV2SourceAdaptersReady(sourceIds: readonly string[]): void {
  if (!sourceIds.length) throw new Error('BNX_SOURCE_ADAPTERS_REQUIRED');
  for (const source of getV2Sources(sourceIds)) {
    if (!hasImplementedV2Adapter(source.id) || source.relationship !== 'adapted-source' || !source.adaptations?.length || source.runtimePackages.length || source.adaptations.some(a => a.version !== ADAPTED_PRIMITIVES_VERSION || !a.sourceFiles.length || !a.targetExports.length || a.targetFile !== 'platform/src/design-system/v2/adapted-primitives.ts') || !source.notices.some(n => n.sourceId === source.id && n.spdx === source.license && /^[a-f0-9]{64}$/.test(n.sha256) && n.text.length > 500)) throw new Error('BNX_SOURCE_ADAPTER_NOT_READY');
  }
}
/** Historical broad package guard: only exact approved artifacts of the local adapters can be exported by the production wrapper. */
export function assertV2CustomerExportReady(): never { throw new Error('BNX_CUSTOMER_EXPORT_NOT_READY'); }
