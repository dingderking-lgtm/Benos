import { BNX_VERSION, V2_PRESETS, V2_PATTERN_DEFINITIONS, createWebsiteTokenSnapshot, v2SectionSchema, v2PageSchema, type V2SectionInput, type ResolvedV2Section, type V2PageInput, type V2Preset, type V2PatternId } from './contracts';
import { createV2Artifact, findV2Pattern, assertV2ProductionReady, type V2Artifact, type V2TrustedReview } from './registry';
import { getV2Sources, getV2Notices } from './provenance';
import { V2_STYLE_VERSION, v2Styles, v2ArtCss, V2_DIRECTIONS, type V2Art } from './styles';
import { renderAdaptedAction, adaptedAspectGeometry, renderAdaptedFaq, renderAdaptedFooterGroups, renderAdaptedCard, adaptedAccentStyle, getAdaptedPrimitiveCss, adaptedPrimitivesFingerprint, getAdaptedSourceIdsForPattern } from './adapted-primitives';
import { KIT_MEDIA_GEOMETRY, isKitPattern, kitUsesCjk, renderKitSection } from './kit';
import sourceIdentity from './source-identity.json';

export const V2_RENDERER_VERSION = 'bnx-render-2' as const;
/** The compiler, not the model, owns page rhythm: each layout has a home tone
 * and a heading arrangement, so neighbouring sections do not read as one flat
 * sheet and section heads are not all "title left, text right". */
export type V2Tone='base'|'soft'|'dark';
type HeadLayout='stack'|'center'|'split';
const LAYOUTS:Record<string,{tone:V2Tone;head:HeadLayout}>={
 'media-story/alternating':{tone:'base',head:'split'},'media-story/lead-list':{tone:'soft',head:'stack'},'media-story/spotlight':{tone:'base',head:'stack'},
 'media-mosaic/dominant':{tone:'dark',head:'split'},'media-mosaic/bento':{tone:'base',head:'center'},'media-mosaic/cards':{tone:'soft',head:'split'},
 'features/grid':{tone:'soft',head:'center'},'features/ledger':{tone:'base',head:'split'},'features/band':{tone:'dark',head:'stack'},'features/statement':{tone:'base',head:'stack'},
 'process/steps':{tone:'base',head:'center'},'process/timeline':{tone:'soft',head:'stack'},'process/cards':{tone:'dark',head:'split'},
 'faq/split':{tone:'base',head:'stack'},'faq/centered':{tone:'soft',head:'center'},
 'manifesto/center':{tone:'dark',head:'center'},'manifesto/index':{tone:'base',head:'split'},
 'kit-statement/split':{tone:'soft',head:'stack'},'kit-steps/flow':{tone:'dark',head:'split'},
 'action/band':{tone:'base',head:'stack'},'action/split':{tone:'soft',head:'stack'},'action/centered':{tone:'dark',head:'center'},
};
export function v2SectionLayout(patternId:string,variantId:string){return LAYOUTS[patternId+'/'+variantId]??{tone:'base' as V2Tone,head:'stack' as HeadLayout};}
export type V2OwnedAsset={path:string;width:number;height:number;source:'uploaded'|'generated'|'licensed';sha256?:string};
/** Production rows are supplied by the server review ledger, never model data. */
export type V2RenderContext=({mode:'review'}|{mode:'production';approvedSnapshot:readonly V2TrustedReview[]})&{ownedAssets?:readonly V2OwnedAsset[];verifiedFactRefs?:readonly string[];art?:V2Art;artCss?:boolean;kit?:boolean};
export type V2RenderIssue={code:string;sectionId:string;message:string;severity:'warning'|'error'};
export type V2MediaFrame={id:string;frameId:string;sectionId:string;purpose:string;alt:string;prompt?:string;source:'owned'|'planned';assetPath?:string;presentation:'standard'|'hero-cover';slot:{width:number;height:number;fit:'cover';focalPoint:'center'|'left'|'right'|'top'|'bottom';textSafeArea:'none'|'left'|'right'|'top'|'bottom'};subjectPolicy:'complete'|'crop-safe';framePolicy:'adapt'|'fixed'};
type MediaResult={html:string[];frames:V2MediaFrame[];assets:V2OwnedAsset[];issues:V2RenderIssue[]};
export type V2RenderedSection={html:string;css:string;frames:V2MediaFrame[];assets:V2OwnedAsset[];issues:V2RenderIssue[];artifact:V2Artifact;receipt:{sectionId:string;patternId:string;variantId:string;preset:V2Preset;degraded:boolean;compiledHash:string};sourceRefs:ReturnType<typeof getV2Sources>;notices:ReturnType<typeof getV2Notices>;reviewOnly:boolean;customerExportReady:boolean};

const escapeHtml=(value:string)=>value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const paragraph=(value:string|undefined,cls='bnx-copy')=>value?`<p class="${cls}">${escapeHtml(value)}</p>`:'';
const focalPosition={center:'50% 50%',left:'0% 50%',right:'100% 50%',top:'50% 0%',bottom:'50% 100%'};
const wrap=(content:string,cls='')=>`<div class="bnx-wrap${cls?' '+cls:''}">${content}</div>`;
function actions(input:ResolvedV2Section){return input.content.actions.length?`<div class="bnx-actions">${input.content.actions.map(renderAdaptedAction).join('')}</div>`:'';}
/** A small CJK suffix travels as one inline box when a long clause wraps. It is
 * still width-bounded, so unusually narrow containers retain a safe fallback. */
function headingTail(value:string){
 const tail=value.match(/([\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]{3})([，。！？；：、…!?;:.”’」』）】》〉\s]*)$/u);
 if(!tail)return escapeHtml(value);
 return escapeHtml(value.slice(0,tail.index))+`<span class="bnx-heading-tail">${escapeHtml(tail[0])}</span>`;
}
/** Keep authored CJK clauses together without relying on CSS text-wrap, which the
 * pinned CMS strips. An over-wide clause can still wrap inside its bounded span. */
function headingText(value:string){
 if(!/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u.test(value))return escapeHtml(value);
 const phrases=value.match(/.+?(?:[，。！？；：]+[”’」』）】》〉]*|$)/gs)||[];
 if(phrases.length<2||phrases.join('')!==value||phrases.some(phrase=>!/[\p{L}\p{N}]/u.test(phrase)))return headingTail(value);
 return phrases.map(phrase=>`<span class="bnx-heading-phrase">${headingTail(phrase)}</span>`).join('');
}
function heading(input:ResolvedV2Section,{hero=false,center=false,withActions=false,body=true,split=false}:{hero?:boolean;center?:boolean;withActions?:boolean;body?:boolean;split?:boolean}={}){
 const c=input.content,tag=hero?'h1':'h2',main=`${paragraph(c.eyebrow,'bnx-kicker')}<${tag} class="${hero?'bnx-display':'bnx-title'}">${headingText(c.title)}</${tag}>`,side=`${paragraph(c.lead,'bnx-lead')}${body?paragraph(c.body,'bnx-copy'):''}${withActions?actions(input):''}`;
 // A split head needs something to stand opposite the title.
 if(split&&side)return `<div class="bnx-heading bnx-heading-split"><div class="bnx-heading-main">${main}</div><div class="bnx-heading-side">${side}</div></div>`;
 return `<div class="bnx-heading${center?' bnx-heading-center':''}">${main}${side}</div>`;
}
/** Section head in the arrangement owned by this layout. */
function sectionHead(input:ResolvedV2Section){const head=v2SectionLayout(input.patternId,input.variantId).head;return `<div class="bnx-section-head">${heading(input,{withActions:true,center:head==='center',split:head==='split'})}</div>`;}
/** One link per card: the title is the link and the arrow is decoration, so a card never repeats its own name as "more". */
function cardTitle(item:ResolvedV2Section['content']['items'][number]){return item.href?`<h3 class="bnx-subtitle bnx-media-card-title"><a href="${escapeHtml(item.href)}">${escapeHtml(item.title)}</a><span class="bnx-media-card-arrow" aria-hidden="true">→</span></h3>`:`<h3 class="bnx-subtitle">${escapeHtml(item.title)}</h3>`;}
function itemTitle(item:ResolvedV2Section['content']['items'][number]){return `<h3 class="bnx-subtitle">${item.href?`<a href="${escapeHtml(item.href)}">${escapeHtml(item.title)} <span aria-hidden="true">↗</span></a>`:escapeHtml(item.title)}</h3>`;}
function itemBody(item:ResolvedV2Section['content']['items'][number]){return `${paragraph(item.label,'bnx-item-label')}${paragraph(item.value,'bnx-item-value')}${itemTitle(item)}${paragraph(item.text)}`;}
function itemGrid(input:ResolvedV2Section){return input.content.items.length?`<div class="bnx-text-grid bnx-section-body">${input.content.items.map(item=>`<article class="bnx-item">${itemBody(item)}</article>`).join('')}</div>`:'';}
function mediaGeometry(input:ResolvedV2Section,index:number,asset?:V2OwnedAsset):[number,number]{
 const complete=input.media[index].subjectPolicy==='complete'&&!fillsWidth(input);
 const native=asset??{width:1536,height:1024};
 // The image binder caps a frame at its slot width, so a full-width picture needs a slot as wide as the page.
 const kit=KIT_MEDIA_GEOMETRY[input.patternId];if(kit)return[kit[0],kit[1]];
 if(input.patternId==='media-story'&&input.variantId==='spotlight')return[1680,840];
 if(input.patternId==='hero-stage'&&input.variantId==='centered')return[1680,840];
 if(input.patternId==='banner')return input.variantId==='split'?[960,960]:[1920,800];
 const format=complete?'native':input.patternId==='media-mosaic'&&input.variantId!=='cards'&&index===0?(input.variantId==='bento'?'square':'portrait'):'landscape';
 const geometry=adaptedAspectGeometry({...native,format});return[geometry.width,geometry.height];
}
/** Layouts whose picture spans the content width (or half the page) always fill their frame;
 * a "complete subject" there would shrink to a floating picture of a different width. */
function fillsWidth(input:ResolvedV2Section){return input.patternId==='banner'||input.patternId==='hero-cover'||(input.patternId==='hero-stage'&&input.variantId==='centered')||(input.patternId==='media-story'&&input.variantId==='spotlight')||isKitPattern(input.patternId);}
const ICON_CYCLE=['check','layers','chart','search','grid','clock','target','chat','arrow','plus'] as const;
function prepareMedia(input:ResolvedV2Section,ctx:V2RenderContext):MediaResult{
 const frames:V2MediaFrame[]=[],assets:V2OwnedAsset[]=[],issues:V2RenderIssue[]=[],html:string[]=[];
 for(let i=0;i<input.media.length;i++){
  const m=input.media[i];
  if(m.kind==='missing'){html.push('');issues.push({code:'BNX_IMAGE_UNAVAILABLE',sectionId:input.id,severity:'warning',message:`图片 ${m.id} 不可用，保留对应文字。`});continue;}
  const asset=m.kind==='owned'?ctx.ownedAssets?.find(a=>a.path===m.assetPath):undefined;
  if(m.kind==='owned'&&(!asset||!Number.isInteger(asset.width)||!Number.isInteger(asset.height)||asset.width<1||asset.height<1||asset.width>32768||asset.height>32768))throw new Error('BNX_ASSET_NOT_VERIFIED');
  if(asset&&(!/^\/(?!\/)/.test(asset.path)||/[\s<>"'`\\\x00-\x1f]/.test(asset.path)||asset.path.split(/[?#]/,1)[0].split('/').includes('..')))throw new Error('BNX_ASSET_PATH_INVALID');
  const[width,height]=mediaGeometry(input,i,asset),id=`${input.id}-${m.id}`,cover=input.patternId==='hero-cover',natural=m.subjectPolicy==='complete'&&!fillsWidth(input);
  const frame:V2MediaFrame={id,frameId:`bnf-image-${id}`,sectionId:input.id,purpose:m.purpose,alt:m.alt,...(m.prompt?{prompt:m.prompt}:{}),source:m.kind,...(asset?{assetPath:asset.path}:{}),presentation:cover?'hero-cover':'standard',slot:{width,height,fit:'cover',focalPoint:m.focalPoint,textSafeArea:m.textSafeArea},subjectPolicy:natural?'complete':'crop-safe',framePolicy:natural?'adapt':'fixed'};
  frames.push(frame);if(asset)assets.push(asset);
  if(!asset)issues.push({code:'BNX_IMAGE_PLANNED',sectionId:input.id,severity:'warning',message:`图片 ${m.id} 尚未生成；当前只展示图框计划，不能作为已完成图片。`});
  html.push(`<div id="${frame.frameId}" class="bnx-media bnx-ap-aspect${natural?' bnx-media-complete bnx-ap-aspect-native':''}${cover?' bnx-cover-media':''}${!asset?' bnx-media-planned':''}" style="--bnx-ratio:${width}/${height};--bnx-position:${focalPosition[m.focalPoint]}">${asset?`<img src="${escapeHtml(asset.path)}" width="${asset.width}" height="${asset.height}" alt="${escapeHtml(m.alt)}" loading="${input.patternId.startsWith('hero-')?'eager':'lazy'}" decoding="async">`:''}</div>`);
 }
 return{html,frames,assets,issues};
}
function figure(input:ResolvedV2Section,media:string|undefined,index:number,{caption=true,focusable=false}:{caption?:boolean;focusable?:boolean}={}){
 if(!media)return'';const item=input.content.items[index];
 return `<figure class="bnx-figure"${focusable?` tabindex="0" aria-label="${escapeHtml(item?.title||input.media[index].alt)}"`:''}>${media}${caption&&item?`<figcaption class="bnx-caption"><div>${paragraph(item.label,'bnx-item-label')}${paragraph(item.value,'bnx-item-value')}<strong>${item.href?`<a href="${escapeHtml(item.href)}">${escapeHtml(item.title)} ↗</a>`:escapeHtml(item.title)}</strong></div><span>${escapeHtml(item.text)}</span></figcaption>`:''}</figure>`;
}
function renderHeroStage(input:ResolvedV2Section,media:MediaResult){
 const image=media.html[0],center=input.variantId==='centered';
 const details=input.content.items.length?`<div class="bnx-stage-detail">${input.content.items.map(item=>`<div>${paragraph(item.label,'bnx-item-label')}${paragraph(item.value,'bnx-item-value')}<strong>${item.href?`<a href="${escapeHtml(item.href)}">${escapeHtml(item.title)} ↗</a>`:escapeHtml(item.title)}</strong>${paragraph(item.text,'bnx-small')}</div>`).join('')}</div>`:'';
 return wrap(`<div class="${center?'bnx-stage-centered':'bnx-stage-layout'}${input.variantId==='showcase'?' bnx-stage-showcase':input.variantId==='reverse'?' bnx-stage-reverse':''}${!image?' bnx-stage-no-media':''}">${heading(input,{hero:true,center,withActions:true})}${image?`<div class="bnx-stage-frame"><div class="bnx-stage-visual">${image}${details}</div></div>`:itemGrid(input)}</div>`);
}
function renderHeroCover(input:ResolvedV2Section,media:MediaResult){
 return(media.html[0]||'')+wrap(`<div class="bnx-cover-panel">${heading(input,{hero:true,withActions:true})}${itemGrid(input)}</div>`,'bnx-cover-content');
}
function renderMediaStory(input:ResolvedV2Section,media:MediaResult){
 const head=sectionHead(input);
 if(input.variantId==='spotlight'){
  const strip=input.content.items.length?`<div class="bnx-spot-strip">${input.content.items.map(item=>`<article class="bnx-item">${itemBody(item)}</article>`).join('')}</div>`:'';
  return wrap(`<div class="bnx-spot${media.html[0]?'':' bnx-spot-plain'}">${figure(input,media.html[0],0,{caption:false})}<div class="bnx-spot-card">${heading(input,{withActions:true})}</div></div>`+strip);
 }
 if(input.variantId==='lead-list')return wrap(head+`<div class="${media.html[0]?'bnx-story-lead':'bnx-story-text-only'}">${figure(input,media.html[0],0,{caption:false})}<ul class="bnx-story-list">${input.content.items.map(item=>`<li><span class="bnx-story-mark" aria-hidden="true"></span><div class="bnx-item">${itemBody(item)}</div></li>`).join('')}</ul></div>`);
 return wrap(head+`<div class="bnx-story-rows">${input.content.items.map((item,i)=>`<article class="bnx-story-row${media.html[i]?'':' bnx-story-text-only'}">${figure(input,media.html[i],i,{caption:false})}<div class="bnx-story-copy">${itemBody(item)}</div></article>`).join('')}</div>`);
}
function renderMediaMosaic(input:ResolvedV2Section,media:MediaResult){
 const head=sectionHead(input),live=media.html.filter(Boolean).length,wanted=input.variantId==='bento'?4:3;
 // Catalogue cards: every item is a complete card; a missing picture leaves a text card, never a hole.
 if(input.variantId==='cards')return wrap(head+`<div class="bnx-card-grid bnx-card-count-${input.content.items.length}">${input.content.items.map((item,i)=>`<article class="bnx-media-card">${media.html[i]||''}<div class="bnx-media-card-body">${paragraph(item.label,'bnx-item-label')}${paragraph(item.value,'bnx-item-value')}${cardTitle(item)}${paragraph(item.text)}</div></article>`).join('')}</div>`);
 if(!live)return wrap(head+itemGrid(input));
 if(live!==wanted){media.issues.push({code:'BNX_COMPOSITION_DEGRADED',sectionId:input.id,severity:'warning',message:'图片不足，改为连续图文阅读序列；不挤压剩余图片或留下空格。'});return wrap(head+`<div class="bnx-media-rail" role="region" aria-label="${escapeHtml(input.content.title)}" tabindex="0">${media.html.map((m,i)=>figure(input,m,i,{focusable:true})).join('')}</div>`+input.content.items.map((item,i)=>!media.html[i]?`<article class="bnx-item bnx-section-body">${itemBody(item)}</article>`:'').join(''));}
 const natural=input.media.some(m=>m.subjectPolicy==='complete');
 return wrap(head+`<div class="bnx-mosaic-grid${input.variantId==='bento'?' bnx-mosaic-bento':''}${natural?' bnx-mosaic-natural':''}">${media.html.map((m,i)=>figure(input,m,i)).join('')}</div>`);
}
function renderFeatures(input:ResolvedV2Section){
 const head=sectionHead(input);
 if(input.variantId==='band')return wrap(`<div class="bnx-band">${heading(input,{withActions:true})}<div class="bnx-band-list${input.content.items.length%2?' bnx-band-odd':''}">${input.content.items.map(item=>`<article class="bnx-item">${itemBody(item)}</article>`).join('')}</div></div>`);
 if(input.variantId==='statement')return wrap(`<div class="bnx-statement">${heading(input,{withActions:true})}<div class="bnx-statement-list">${input.content.items.map(item=>`<article class="bnx-item">${itemBody(item)}</article>`).join('')}</div></div>`);
 if(input.variantId==='ledger')return wrap(head+`<div class="bnx-ledger">${input.content.items.map((item,i)=>`<article class="bnx-ledger-row"><span class="bnx-number" aria-hidden="true">${String(i+1).padStart(2,'0')}</span><div>${paragraph(item.label,'bnx-item-label')}${itemTitle(item)}</div><div>${paragraph(item.value,'bnx-item-value')}${paragraph(item.text)}</div></article>`).join('')}</div>`);
 return wrap(head+`<div class="bnx-feature-grid bnx-feature-count-${input.content.items.length}">${input.content.items.map((item,i)=>renderAdaptedCard({...item,glyph:true,index:i+1,icon:item.icon==='circle'?'target':item.icon??ICON_CYCLE[i%ICON_CYCLE.length],variant:'default'})).join('')}</div>`);
}
function renderProcess(input:ResolvedV2Section){
 const number=(i:number)=>`<span class="bnx-number" aria-hidden="true">${String(i+1).padStart(2,'0')}</span>`,count=`bnx-step-count-${input.content.items.length}`;
 if(input.variantId==='cards')return wrap(sectionHead(input)+`<ol class="bnx-step-cards ${count}">${input.content.items.map((item,i)=>`<li class="bnx-step-card">${number(i)}${paragraph(item.label,'bnx-item-label')}${itemTitle(item)}${paragraph(item.value,'bnx-item-value')}${paragraph(item.text)}</li>`).join('')}</ol>`);
 if(input.variantId==='timeline')return wrap(`<div class="bnx-aside">${heading(input,{withActions:true})}<ol class="bnx-timeline ${count}">${input.content.items.map((item,i)=>`<li class="bnx-step"><div class="bnx-step-top">${number(i)}</div><div class="bnx-step-body">${paragraph(item.label,'bnx-item-label')}${itemTitle(item)}${paragraph(item.value,'bnx-item-value')}${paragraph(item.text)}</div></li>`).join('')}</ol></div>`);
 return wrap(sectionHead(input)+`<ol class="${input.variantId==='timeline'?'bnx-timeline':'bnx-steps'} bnx-step-count-${input.content.items.length}">${input.content.items.map((item,i)=>`<li class="bnx-step"><div class="bnx-step-top"><span class="bnx-number" aria-hidden="true">${String(i+1).padStart(2,'0')}</span></div><div>${paragraph(item.label,'bnx-item-label')}${itemTitle(item)}</div><div>${paragraph(item.value,'bnx-item-value')}${paragraph(item.text)}</div></li>`).join('')}</ol>`);
}
/** The picture bleeds to the page edge; text is the only thing inside the container. */
function renderBanner(input:ResolvedV2Section,media:MediaResult){
 if(input.variantId==='split')return `<div class="bnx-banner-half${media.html[0]?'':' bnx-banner-plain'}">${media.html[0]||''}<div class="bnx-banner-text">${heading(input,{withActions:true})}${input.content.items.length?`<div class="bnx-banner-points">${input.content.items.map(item=>`<article class="bnx-item">${itemBody(item)}</article>`).join('')}</div>`:''}</div></div>`;
 return(media.html[0]||'')+wrap(`<div class="bnx-banner-copy">${heading(input,{withActions:true})}</div>`,'bnx-banner-content');
}
function renderManifesto(input:ResolvedV2Section){
 if(input.variantId==='index')return wrap(sectionHead(input)+`<ol class="bnx-index">${input.content.items.map((item,i)=>`<li class="bnx-index-row"><span class="bnx-index-no" aria-hidden="true">${String(i+1).padStart(2,'0')}</span><h3 class="bnx-index-title">${item.href?`<a href="${escapeHtml(item.href)}">${escapeHtml(item.title)}</a>`:escapeHtml(item.title)}</h3><div class="bnx-index-text">${paragraph(item.label,'bnx-item-label')}${paragraph(item.text)}</div></li>`).join('')}</ol>`);
 return wrap(heading(input,{center:true,withActions:true})+(input.content.items.length?`<div class="bnx-manifesto-points">${input.content.items.map(item=>`<article class="bnx-item">${itemBody(item)}</article>`).join('')}</div>`:''));
}
/** The enquiry form is the CMS's own component: on import the CMS replaces the children of the
 * mount with a working form (FormService). The children here only show its shape in a preview. */
export const V2_INQUIRY_FORM_REF='inquiry';
export function v2InquiryFields(chinese:boolean){return chinese?[['name','text','称呼'],['email','email','邮箱'],['phone','tel','电话'],['message','textarea','需求说明']] as const:[['name','text','Name'],['email','email','Email'],['phone','tel','Phone'],['message','textarea','How can we help?']] as const;}
function renderContact(input:ResolvedV2Section){
 const c=input.content,chinese=/[\p{Script=Han}]/u.test(c.title);
 const rows=[...c.contact.map(a=>`<div class="bnx-contact-row"><dt>${escapeHtml(a.href.startsWith('tel:')?(chinese?'电话':'Phone'):a.href.startsWith('mailto:')?(chinese?'邮箱':'Email'):(chinese?'联系':'Contact'))}</dt><dd><a href="${escapeHtml(a.href)}">${escapeHtml(a.label)}</a></dd></div>`),...c.items.map(item=>`<div class="bnx-contact-row"><dt>${escapeHtml(item.title)}</dt><dd>${escapeHtml(item.text)}</dd></div>`)].join('');
 const info=`<div class="bnx-contact-info">${heading(input,{hero:true,withActions:true})}${rows?`<dl class="bnx-contact-list">${rows}</dl>`:''}</div>`;
 if(input.variantId!=='form')return wrap(`<div class="bnx-contact-layout bnx-contact-plain">${info}</div>`);
 const mock=v2InquiryFields(chinese).map(([,type,label])=>`<div class="bnx-form-field${type==='textarea'?' bnx-form-area':''}"><span>${escapeHtml(label)}</span><i></i></div>`).join('')+`<div class="bnx-form-submit">${chinese?'提交':'Send'}</div>`;
 return wrap(`<div class="bnx-contact-layout">${info}<div class="bnx-contact-card"><div data-aacms="form" data-form="${V2_INQUIRY_FORM_REF}"><div class="bnx-form-mock" aria-hidden="true">${mock}</div></div></div></div>`);
}
function renderFaq(input:ResolvedV2Section){return wrap(heading(input,{center:input.variantId==='centered',withActions:true})+renderAdaptedFaq(input.content.questions),`bnx-faq-layout${input.variantId==='centered'?' bnx-faq-centered':''}`);}
function renderAction(input:ResolvedV2Section){
 if(input.variantId==='centered')return wrap(`<div class="bnx-action-center">${heading(input,{center:true,withActions:true})}</div>`);
 const split=input.variantId==='split',tokens=createWebsiteTokenSnapshot(input.preset),accent=adaptedAccentStyle({accent:tokens.colors.accent,surface:split?tokens.colors.surface:tokens.colors.accent,radius:tokens.radius.panel});
 return wrap(`<div class="bnx-action-panel ${accent.className}${split?' bnx-action-split':''}" style="${escapeHtml(accent.style)}"><div>${heading(input)}${itemGrid(input)}</div><div class="bnx-action-side">${actions(input)}</div></div>`);
}
function renderFooter(input:ResolvedV2Section){const c=input.content;return wrap(`<div class="bnx-footer-top"><div class="bnx-footer-lead">${heading(input,{withActions:true})}${c.contact.length?`<div class="bnx-footer-contact">${c.contact.map(a=>`<a href="${escapeHtml(a.href)}">${escapeHtml(a.label)}</a>`).join('')}</div>`:''}</div>${renderAdaptedFooterGroups(c.navigation,c.title)}</div>${c.copyright||c.imageAttribution?`<div class="bnx-footer-bottom">${paragraph(c.copyright,'')}${paragraph(c.imageAttribution,'')}</div>`:''}`);}
const renderers:Record<V2PatternId,(input:ResolvedV2Section,media:MediaResult)=>string>={'hero-stage':renderHeroStage,'hero-cover':renderHeroCover,'media-story':renderMediaStory,'media-mosaic':renderMediaMosaic,features:renderFeatures,process:renderProcess,faq:renderFaq,action:renderAction,footer:renderFooter,banner:renderBanner,manifesto:renderManifesto,contact:renderContact,
 ...Object.fromEntries(['hero-kit','kit-statement','kit-duo','kit-steps','kit-cta'].map(id=>[id,(input:ResolvedV2Section,media:MediaResult)=>renderKitSection(input,media.html,{escapeHtml,headingText})])) as Record<'hero-kit'|'kit-statement'|'kit-duo'|'kit-steps'|'kit-cta',(input:ResolvedV2Section,media:MediaResult)=>string>};

/** Build-verified raw source identity is stable across tsx and Wrangler. Never
 * hash Function.toString(): bundlers rewrite functions without changing output.
 * Conservatively invalidate all v2 approvals when any owned source changes. */
export function v2RendererFingerprint(patternId:V2PatternId):string{return JSON.stringify({sourceIdentity,patternId,focalPosition,styleVersion:V2_STYLE_VERSION,layouts:LAYOUTS})+adaptedPrimitivesFingerprint(getAdaptedSourceIdsForPattern(patternId));}
function renderStyles(preset:V2Preset,ids:readonly V2PatternId[]){return v2Styles(createWebsiteTokenSnapshot(preset),ids)+getAdaptedPrimitiveCss([...new Set(ids.flatMap(getAdaptedSourceIdsForPattern))]);}
const artifactCache=new Map<string,Promise<V2Artifact>>();
function artifactFor(patternId:V2PatternId,variantId:string,preset:V2Preset){const key=`${patternId}/${variantId}/${preset}`;let result=artifactCache.get(key);if(!result){result=createV2Artifact({patternId,variantId,preset,rendererVersion:V2_RENDERER_VERSION,rendererFingerprint:v2RendererFingerprint(patternId),css:renderStyles(preset,[patternId])});artifactCache.set(key,result);}return result;}

export async function renderV2Section(raw:V2SectionInput,ctx:V2RenderContext,layout?:{tone?:V2Tone}):Promise<V2RenderedSection>{
 if(ctx.mode!=='review'&&ctx.mode!=='production')throw new Error('BNX_CUSTOMER_EXPORT_NOT_READY');
 const input=v2SectionSchema.parse(raw),{family,variant}=findV2Pattern(input.patternId,input.variantId),facts=new Set(ctx.verifiedFactRefs||[]);
 const artifact=await artifactFor(input.patternId,input.variantId,input.preset);
 if(ctx.mode==='production')assertV2ProductionReady(artifact,ctx.approvedSnapshot);
 if(input.content.contact.some(x=>!facts.has(x.factRef)))throw new Error('BNX_CONTACT_NOT_VERIFIED');
 if(input.content.items.some(x=>x.factRef&&!facts.has(x.factRef)))throw new Error('BNX_ITEM_FACT_NOT_VERIFIED');
 if(input.content.items.some(x=>x.value&&!x.factRef))throw new Error('BNX_VALUE_REQUIRES_VERIFIED_FACT');
 const media=prepareMedia(input,ctx),live=media.html.filter(Boolean).length;
 if(live<variant.preferredMedia[0])media.issues.push({code:'BNX_MEDIA_BELOW_PREFERENCE',sectionId:input.id,severity:'warning',message:'现有图片少于此构图的建议数量，使用内容完整的降级布局。'});
 const content=renderers[input.patternId](input,media),cover=input.patternId==='hero-cover',tag=input.patternId==='footer'?'footer':'section';
 const tone=layout?.tone??v2SectionLayout(input.patternId,input.variantId).tone,toned=!cover&&input.patternId!=='footer'&&input.patternId!=='banner'&&!input.patternId.startsWith('hero-');
 const direction=ctx.art&&V2_DIRECTIONS.includes(ctx.art.direction)&&ctx.art.direction!=='studio'?` bnx-dir-${ctx.art.direction}`:'';
 const kitClass=isKitPattern(input.patternId)?' bnk'+(kitUsesCjk(input)?' bnk-cjk':''):'';
 const modifiers=kitClass+direction+(toned&&tone!=='base'?` bnx-tone-${tone}`:'')+(input.patternId==='action'&&input.variantId==='centered'?' bnx-action-centered':'')+(input.patternId==='banner'?` bnx-banner-${input.variantId==='split'?'split':'bleed'}`:'')+(input.patternId==='manifesto'?` bnx-manifesto-${input.variantId}`:'')+(cover?` bnx-cover-${input.variantId} bnx-cover-${input.media[0]?.textSafeArea||'none'}${!live?' bnx-cover-no-media':''}`:input.patternId==='footer'?` bnx-footer-${input.variantId}${!input.content.navigation.length?' bnx-footer-no-nav':''}`:'');
 const html=`<${tag} id="${input.id}" class="bnx-section bnx-${input.patternId} bnx-preset-${input.preset}${modifiers}">${content}</${tag}>`,css=renderStyles(input.preset,[input.patternId]);
 return{html,css,frames:media.frames,assets:media.assets,issues:media.issues,artifact,receipt:{sectionId:input.id,patternId:input.patternId,variantId:input.variantId,preset:input.preset,degraded:media.issues.length>0,compiledHash:artifact.artifactHash},sourceRefs:getV2Sources(family.sourceIds),notices:getV2Notices(family.sourceIds),reviewOnly:ctx.mode==='review',customerExportReady:ctx.mode==='production'};
}

export async function compileV2Page(raw:V2PageInput,ctx:V2RenderContext){
 const input=v2PageSchema.parse(raw);let previousTone:V2Tone='base';
 const tones=input.sections.map(section=>{const own=section.patternId.startsWith('hero-')||section.patternId==='footer'||section.patternId==='banner'?'base':v2SectionLayout(section.patternId,section.variantId).tone,tone:V2Tone=own!=='base'&&own===previousTone?(own==='dark'?'soft':'base'):own;previousTone=section.patternId==='hero-cover'||(section.patternId==='banner'&&section.variantId==='fullbleed')?'dark':tone;return tone;});
 const sections=await Promise.all(input.sections.map((section,index)=>renderV2Section(section,ctx,{tone:tones[index]}))),ids=input.sections.map(s=>s.patternId),css=renderStyles(input.preset,ids)+(ctx.art&&ctx.artCss!==false?v2ArtCss(input.preset,ctx.art,ctx.kit??ids.some(isKitPattern)):''),sourceIds=[...new Set(ids.flatMap(id=>V2_PATTERN_DEFINITIONS.find(f=>f.id===id)!.sourceIds))];
 if(new TextEncoder().encode(css).length>45000)throw new Error('BNX_CSS_BUDGET_EXCEEDED');
 return{version:BNX_VERSION,html:sections.map(s=>s.html).join('\n'),css,frames:sections.flatMap(s=>s.frames),assets:[...new Map(sections.flatMap(s=>s.assets).map(a=>[a.path,a])).values()],issues:sections.flatMap(s=>s.issues),receipts:sections.map(s=>s.receipt),artifacts:sections.map(s=>s.artifact),sourceRefs:getV2Sources(sourceIds),notices:getV2Notices(sourceIds),tokens:createWebsiteTokenSnapshot(input.preset),reviewOnly:ctx.mode==='review',customerExportReady:ctx.mode==='production'};
}

export async function getV2Catalog(){return{version:BNX_VERSION,rendererVersion:V2_RENDERER_VERSION,presets:[...V2_PRESETS],patterns:await Promise.all(V2_PATTERN_DEFINITIONS.map(async family=>({...family,variants:await Promise.all(family.variants.map(async variant=>({...variant,artifacts:await Promise.all(V2_PRESETS.map(preset=>artifactFor(family.id,variant.id,preset)))})))}))),reviewOnly:true as const,customerExportReady:false as const};}
