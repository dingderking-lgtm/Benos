/**
 * Template-derived sections ("kit"). Unlike the generic bnx patterns, the markup and CSS here are
 * ported section by section from the platform's own starter template "工业设备企业站" (arkpm), which
 * is the quality reference for generated sites: a 1360px measure, regular-weight display type,
 * small upper-case labels with a square mark, captioned figures, soft cards and underlined links.
 * Hard-coded template colours are replaced by the bnx colour variables so a model-chosen palette
 * recolours every section; sizes, spacing and radii are the template's own and deliberately do not
 * follow the generic bnx scale.
 *
 * Buttons and links reuse the BoardUI-adapted action primitive (escaped label, validated href,
 * trailing icon slot) and are restyled here. The kit never emits inline styles or `!important`.
 */
import type { z } from 'zod';
import type { patternContentSchema, patternMediaSchema } from '../../contracts/section-patterns';
import { renderAdaptedAction } from './adapted-primitives';

export const KIT_VERSION = 'bnk-1' as const;
export const KIT_PATTERN_IDS = ['hero-kit', 'kit-statement', 'kit-duo', 'kit-steps', 'kit-cta'] as const;
export type KitPatternId = typeof KIT_PATTERN_IDS[number];
export const isKitPattern = (id: string): id is KitPatternId => (KIT_PATTERN_IDS as readonly string[]).includes(id);
/** Slot width/height of a kit picture; every kit figure is the template's 4:3. */
export const KIT_MEDIA_GEOMETRY: Readonly<Record<string, readonly [number, number]>> = Object.freeze({ 'hero-kit': [1200, 900], 'kit-duo': [800, 600] });

type Content = z.output<typeof patternContentSchema>;
type Media = z.output<typeof patternMediaSchema>;
export type KitSection = { id: string; patternId: string; variantId: string; content: Content; media: Media[] };
export type KitHelpers = { escapeHtml: (value: string) => string; headingText: (value: string) => string };

const CJK = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u;
/** Template tracking is tuned for Latin display type; full-width scripts need looser tracking and leading. */
export const kitUsesCjk = (section: KitSection) => CJK.test(section.content.title);

/** The template sets a display heading as deliberate lines: one sentence per line, or one long
 * sentence broken near its middle. A line is a block box on wide screens and flows inline on narrow
 * ones (.bnk-line), so an authored break never stacks on top of natural wrapping. `perLine` is
 * roughly how many Latin characters the heading's column holds at its display size. */
function kitHeading(value: string, h: KitHelpers, perLine: number): string {
  if (CJK.test(value)) return h.headingText(value);
  const text = value.trim().replace(/\s+/g, ' ');
  const sentences = text.split(/(?<=[.!?])\s+(?=\p{Lu})/u);
  let lines = sentences.length >= 2 && sentences.length <= 3 && sentences.every(part => part.length >= 8 && part.length <= perLine * 1.15) ? sentences : [];
  if (!lines.length && text.length > perLine && text.length <= perLine * 2) {
    const middle = text.length / 2; let cut = -1;
    for (let i = text.indexOf(' '); i !== -1; i = text.indexOf(' ', i + 1)) if (cut === -1 || Math.abs(i - middle) < Math.abs(cut - middle)) cut = i;
    if (cut > 0) lines = [text.slice(0, cut), text.slice(cut + 1)];
  }
  return lines.length ? lines.map(line => `<span class="bnk-line">${h.escapeHtml(line)}</span>`).join(' ') : h.escapeHtml(text);
}

export function renderKitSection(section: KitSection, mediaHtml: readonly string[], h: KitHelpers): string {
  const c = section.content, e = h.escapeHtml;
  const kicker = (value?: string) => value ? `<span class="bnk-kicker">${e(value)}</span>` : '';
  const text = (value: string | undefined, cls = '') => value ? `<p${cls ? ` class="${cls}"` : ''}>${e(value)}</p>` : '';
  const link = (label: string, href: string) => `<div class="bnk-linkrow">${renderAdaptedAction({ label, href, kind: 'secondary' })}</div>`;
  const actions = () => c.actions.length ? `<div class="bnk-actions">${c.actions.map((action, index) => renderAdaptedAction({ label: action.label, href: action.href, kind: index === 0 ? 'primary' : 'secondary' })).join('')}</div>` : '';
  const figure = (index: number) => mediaHtml[index] ? `<figure class="bnk-figure">${mediaHtml[index]}${section.media[index]?.caption ? `<figcaption class="bnk-caption">${e(section.media[index].caption!)}</figcaption>` : ''}</figure>` : '';
  const head = () => `<div class="bnk-section-head"><div>${kicker(c.eyebrow)}<h2>${kitHeading(c.title, h, 30)}</h2></div>${text(c.lead)}</div>`;
  const two = (value: number) => String(value).padStart(2, '0');

  if (section.patternId === 'hero-kit') {
    const routes = c.items.slice(0, 2), note = c.items[2], image = figure(0), [lineLeft, lineRight] = (c.body || '').split('|').map(part => part.trim());
    const routeCards = routes.map((item, index) => {
      const inner = `<span class="bnk-kicker">${e(item.label || two(index + 1))}</span><span class="bnk-route-title" role="heading" aria-level="2">${kitHeading(item.title, h, 12)}</span><span class="bnk-route-text">${e(item.text)}</span>`;
      return item.href ? `<a class="bnk-route" href="${e(item.href)}">${inner}</a>` : `<div class="bnk-route">${inner}</div>`;
    }).join('');
    const top = `<div class="bnk-home-top${image ? '' : ' bnk-home-one'}"><div class="bnk-home-intro">${kicker(c.eyebrow)}<h1 class="bnk-home-title">${kitHeading(c.title, h, 22)}</h1>${text(c.lead, 'bnk-lead')}${actions()}</div>${image ? `<div class="bnk-home-image">${image}</div>` : ''}</div>`;
    const lower = [routes.length ? `<div class="bnk-routes bnk-routes-${routes.length}">${routeCards}</div>` : '', note ? `<div class="bnk-note"><h2>${e(note.title)}</h2>${text(note.text)}${note.href ? link(note.linkLabel || note.title, note.href) : ''}</div>` : ''].filter(Boolean);
    const bottom = lower.length ? `<div class="bnk-home-bottom${lower.length === 1 ? ' bnk-home-one' : ''}">${lower.join('')}</div>` : '';
    const line = lineLeft ? `<div class="bnk-brand-line"><span>${e(lineLeft)}</span>${lineRight ? `<span>${e(lineRight)}</span>` : ''}</div>` : '';
    return `<div class="bnk-wrap">${top}${bottom}${line}</div>`;
  }
  if (section.patternId === 'kit-statement') {
    const action = c.actions[0];
    return `<div class="bnk-wrap"><div class="bnk-split"><div>${kicker(c.eyebrow)}<h2>${kitHeading(c.title, h, 27)}</h2></div><div class="bnk-copy">${text(c.lead)}${text(c.body)}${action ? link(action.label, action.href) : ''}</div></div></div>`;
  }
  if (section.patternId === 'kit-duo') {
    const cards = c.items.map((item, index) => { const image = figure(index);
      return `<article class="bnk-duo-card${image ? '' : ' bnk-duo-text'}">${image}<div class="bnk-duo-content"><h3>${e(item.title)}</h3>${text(item.text)}${item.href ? link(item.linkLabel || item.title, item.href) : ''}</div></article>`; }).join('');
    return `<div class="bnk-wrap">${head()}<div class="bnk-duo">${cards}</div></div>`;
  }
  if (section.patternId === 'kit-steps') {
    const cards = c.items.map((item, index) => `<li class="bnk-soft-card"><span class="bnk-number" aria-hidden="true">${two(index + 1)}</span><h3>${e(item.title)}</h3>${text(item.text)}</li>`).join('');
    return `<div class="bnk-wrap">${head()}<ol class="bnk-flow bnk-flow-${c.items.length}">${cards}</ol></div>`;
  }
  if (section.patternId === 'kit-cta') return `<div class="bnk-wrap bnk-cta-inner"><h2>${kitHeading(c.title, h, 25)}</h2><div>${text(c.lead)}${actions()}</div></div>`;
  throw new Error('BNX_PATTERN_UNKNOWN');
}

/** Shared by every kit section; included once per stylesheet. */
export const KIT_BASE_CSS = `
.bnx-section.bnk{padding:clamp(64px,7vw,104px) 0;font-family:var(--bnf-body,Arial,Helvetica,"PingFang SC","Microsoft YaHei",sans-serif);font-size:18px;line-height:1.65;background:var(--bnx-background);color:var(--bnx-text);--bnk-card:var(--bnx-raised)}
.bnx-section.bnk.bnx-tone-dark{--bnk-card:var(--bnx-surface)}
.bnx-section.bnk :is(h1,h2,h3){font-family:var(--bnf-heading,var(--bnf-body,Arial,Helvetica,"PingFang SC","Microsoft YaHei",sans-serif));font-weight:400}
.bnx-section.bnk h1{font-size:clamp(48px,5.2vw,76px);line-height:1.04;letter-spacing:-3.6px}
.bnx-section.bnk h2{font-size:clamp(34px,3.8vw,54px);line-height:1.12;letter-spacing:-1.8px}
.bnx-section.bnk h3{font-size:27px;line-height:1.25;letter-spacing:-.6px}
.bnx-section.bnk p{color:var(--bnx-copy)}
.bnx-section.bnk a:hover{text-decoration:none}
.bnx-section.bnk.bnk-cjk :is(h1,h2,h3){letter-spacing:-.01em}.bnx-section.bnk.bnk-cjk h1{line-height:1.16}.bnx-section.bnk.bnk-cjk h2{line-height:1.22}.bnx-section.bnk.bnk-cjk .bnk-kicker{font-size:13px;letter-spacing:.12em}
.bnk-wrap{width:calc(100% - 80px);max-width:1360px;margin-inline:auto;min-width:0}
.bnk-kicker{display:block;margin-bottom:22px;font-size:12px;line-height:1.6;letter-spacing:1.1px;text-transform:uppercase;color:var(--bnx-copy)}
.bnk-kicker::before{content:"";display:inline-block;width:6px;height:6px;margin-right:9px;background:var(--bnx-accent-2);vertical-align:middle}
.bnk-line{display:block}
.bnk-lead{font-size:20px;line-height:1.65;max-width:650px}
.bnk-actions{display:flex;flex-wrap:wrap;align-items:center;gap:12px;margin-top:30px}
.bnx-section.bnk .bnx-ap-button{gap:18px;min-height:52px;padding:12px 23px;border:1px solid transparent;border-radius:40px;background:var(--bnx-accent);color:var(--bnx-accent-text);font-weight:400;line-height:1.65;box-shadow:none;transition:background-color .18s}
.bnx-section.bnk .bnx-ap-button:hover{transform:none;box-shadow:none;background:var(--bnx-accent-hover)}
.bnx-section.bnk .bnx-ap-button-label{padding:0}
.bnx-section.bnk .bnx-ap-button-icon{position:relative;font-size:0}
.bnx-section.bnk .bnx-ap-button:hover .bnx-ap-button-icon{transform:none}
.bnx-section.bnk .bnx-ap-button-icon::before{content:"";box-sizing:border-box;position:absolute;right:3.55px;top:3.55px;width:12.3px;height:12.3px;border:solid currentColor;border-width:1.25px 1.25px 0 0;border-top-right-radius:.6px}
.bnx-section.bnk .bnx-ap-button-icon::after{content:"";position:absolute;left:1.75px;top:9.38px;width:16.5px;height:1.25px;border-radius:1px;background:currentColor;transform:rotate(-45deg)}
.bnx-section.bnk .bnx-ap-button-secondary{justify-content:space-between;gap:20px;min-height:48px;max-width:100%;padding:10px 0;border:0;border-bottom:1px solid var(--bnx-line-strong);border-radius:0;background:transparent;color:var(--bnx-accent-ink)}
.bnx-section.bnk .bnx-ap-button-secondary:hover{background:transparent;border-bottom-color:currentColor}
.bnk-figure{margin:0;min-width:0;overflow:hidden;border:1px solid var(--bnx-border);border-radius:24px;background:var(--bnk-card)}
.bnk-figure .bnx-media{border-radius:0;background:transparent}
.bnk-caption{display:block;padding:13px 18px;font-size:12px;line-height:1.5;letter-spacing:.35px;color:var(--bnx-copy)}
.bnk-section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:32px 64px;margin-bottom:38px}
.bnk-section-head>div{min-width:0}.bnk-section-head>p{max-width:410px}.bnk-section-head h2{max-width:760px}.bnk-section-head .bnk-kicker{margin-bottom:18px}
.bnk-copy>p+p{margin-top:20px}.bnk-copy .bnk-linkrow{margin-top:26px}
@media(max-width:960px){.bnk-section-head{align-items:flex-start;flex-direction:column;gap:24px}.bnk-section-head>p{max-width:700px}.bnk-figure{width:100%;max-width:760px;margin-inline:auto}}
@media(max-width:760px){.bnk-line{display:inline}.bnx-section.bnk{padding:62px 0;font-size:16px}.bnk-wrap{width:calc(100% - 40px)}.bnx-section.bnk h1{font-size:48px;letter-spacing:-2.2px}.bnx-section.bnk h2{font-size:36px;letter-spacing:-1.3px}.bnx-section.bnk h3{font-size:25px}.bnk-kicker{font-size:11px;letter-spacing:.7px;margin-bottom:20px}.bnk-lead{font-size:18px}.bnk-caption{font-size:11px;padding:12px 15px}}
@media(max-width:360px){.bnk-wrap{width:calc(100% - 32px)}.bnx-section.bnk .bnx-ap-button:not(.bnx-ap-button-secondary){padding-left:19px;padding-right:19px}}
`;

export const KIT_PATTERN_CSS: Readonly<Record<KitPatternId, string>> = Object.freeze({
  'hero-kit': `
.bnx-section.bnx-hero-kit{padding:44px 0 28px}
.bnk-home-top,.bnk-home-bottom{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:24px 64px;align-items:stretch}
.bnk-home-bottom{margin-top:24px}.bnk-home-one{grid-template-columns:minmax(0,1fr)}
.bnk-home-intro{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;min-width:0}
.bnx-section.bnk .bnk-home-title{font-size:clamp(40px,4.2vw,60px);line-height:1.14;letter-spacing:-.035em;max-width:620px}
.bnk-home-intro>.bnk-kicker{margin-bottom:20px}.bnk-home-intro .bnk-lead{max-width:560px;margin-top:24px}
.bnk-home-image{min-width:0}.bnk-home-image .bnk-figure{display:flex;flex-direction:column;height:100%}.bnk-home-image .bnk-caption{margin-top:auto}
.bnk-note{display:flex;flex-direction:column;align-items:flex-start;min-width:0;padding:25px;border-radius:22px;background:var(--bnk-card)}
.bnx-section.bnk .bnk-note h2{font-size:25px;line-height:1.12;letter-spacing:-.6px}.bnk-note p{margin-top:12px}.bnk-note .bnk-linkrow{margin-top:auto;padding-top:14px}
.bnk-routes{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.bnk-routes-1{grid-template-columns:minmax(0,1fr)}
.bnk-route{display:block;min-width:0;padding:25px;border-radius:22px;background:var(--bnx-card-strong);color:var(--bnx-text)}
.bnk-route:last-child{background:var(--bnx-accent-deep);color:var(--bnx-accent-text)}
.bnk-route .bnk-kicker{font-size:11px;margin-bottom:26px}.bnk-route:last-child .bnk-kicker{color:inherit;opacity:.88}.bnk-route:last-child .bnk-kicker::before{background:var(--bnx-accent-2-on)}
.bnk-route-title{display:block;font-size:30px;line-height:1.15;letter-spacing:-.8px}
.bnk-route-text{display:block;margin-top:16px;font-size:18px;line-height:1.5;color:var(--bnx-copy)}.bnk-route:last-child .bnk-route-text{color:inherit;opacity:.9}
.bnk-brand-line{display:flex;justify-content:space-between;gap:24px;margin-top:44px;padding-top:23px;border-top:1px solid var(--bnx-border);font-size:16px;color:var(--bnx-copy)}
@media(max-width:1150px){.bnk-home-top,.bnk-home-bottom{gap:24px 40px}}
@media(max-width:960px){.bnk-home-top,.bnk-home-bottom{grid-template-columns:minmax(0,1fr);max-width:720px;margin-left:auto;margin-right:auto}.bnk-note{order:-1}.bnx-section.bnk .bnk-home-title{font-size:clamp(44px,6.2vw,54px)}}
@media(max-width:760px){.bnx-section.bnx-hero-kit{padding-top:30px}.bnx-section.bnk .bnk-home-title{font-size:clamp(34px,9vw,44px)}.bnk-home-intro .bnk-lead{margin-top:22px}.bnk-route{padding:21px 18px}.bnk-route-title{font-size:27px}.bnk-route-text{font-size:16px}.bnk-route .bnk-kicker{font-size:10px;margin-bottom:22px}.bnk-routes{gap:12px}.bnk-note{padding:23px}.bnx-section.bnk .bnk-note h2{font-size:24px;letter-spacing:-1.3px}.bnk-brand-line{flex-direction:column;gap:14px;margin-top:30px;padding-top:22px}}
@media(max-width:360px){.bnk-routes{gap:10px}.bnk-route{padding:20px 15px}.bnk-route-title{font-size:25px}}
`,
  'kit-statement': `
.bnk-split{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:48px;align-items:center}.bnk-split>div{min-width:0}
@media(max-width:960px){.bnk-split{grid-template-columns:minmax(0,1fr);gap:34px}}
`,
  'kit-duo': `
.bnk-duo{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:40px;align-items:start}
.bnk-duo-card{display:grid;grid-template-columns:minmax(0,.85fr) minmax(0,1.15fr);gap:24px;align-items:center;min-width:0}.bnk-duo-card.bnk-duo-text{grid-template-columns:minmax(0,1fr)}
.bnk-duo .bnk-figure{width:100%;margin:0}.bnk-duo-content{min-width:0}
.bnx-section.bnk .bnk-duo h3{margin:0 0 14px;font-size:26px}.bnk-duo .bnk-linkrow{margin-top:18px}
.bnk-duo .bnk-caption{display:flex;align-items:center;min-height:57px;padding:12px 14px;font-size:11px}
@media(max-width:1439px){.bnk-duo{gap:24px;align-items:stretch;max-width:960px;margin-left:auto;margin-right:auto}.bnk-duo-card,.bnk-duo-card.bnk-duo-text{grid-template-columns:minmax(0,1fr);grid-template-rows:auto 1fr;gap:0;align-items:stretch;overflow:hidden;border:1px solid var(--bnx-border);border-radius:22px;background:var(--bnx-background)}.bnk-duo-card.bnk-duo-text{grid-template-rows:1fr}.bnk-duo .bnk-figure{max-width:none;border:0;border-radius:0}.bnk-duo .bnk-caption{min-height:60px;padding:12px 22px;font-size:12px;letter-spacing:0}.bnk-duo-content{display:flex;flex-direction:column;align-items:flex-start;padding:24px}.bnk-duo-content>p{margin:0 0 20px}.bnk-duo .bnk-linkrow{width:100%;margin-top:auto}.bnx-section.bnk .bnk-duo .bnx-ap-button-secondary{width:100%;gap:12px;line-height:1.5}}
@media(max-width:1023px){.bnx-section.bnk .bnk-duo h3{min-height:2.5em}}
@media(max-width:719px){.bnk-duo{grid-template-columns:minmax(0,1fr);gap:28px;max-width:520px}.bnk-duo-content{padding:22px}.bnk-duo .bnk-caption{min-height:0;padding:13px 22px}.bnx-section.bnk .bnk-duo h3{font-size:25px;min-height:0}}
@media(max-width:360px){.bnk-duo-content{padding:20px 18px}.bnk-duo .bnk-caption{padding-left:18px;padding-right:18px}.bnx-section.bnk .bnk-duo h3{font-size:24px}}
`,
  'kit-steps': `
.bnk-flow{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px;margin:0;padding:0;list-style:none}.bnk-flow-3{grid-template-columns:repeat(3,minmax(0,1fr))}
.bnk-soft-card{min-width:0;padding:28px;border:1px solid var(--bnx-border);border-radius:22px;background:var(--bnk-card)}
.bnx-section.bnk .bnk-soft-card h3{font-size:24px}.bnk-soft-card p{margin-top:16px;font-size:18px}
.bnk-number{display:block;margin-bottom:25px;font-size:30px;line-height:1;color:var(--bnx-accent-2-ink)}
@media(max-width:1150px){.bnk-flow,.bnk-flow-3{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:760px){.bnk-flow,.bnk-flow-3{grid-template-columns:minmax(0,1fr);gap:16px}.bnk-flow .bnk-soft-card{display:grid;grid-template-columns:40px minmax(0,1fr);gap:16px;padding:24px}.bnk-flow .bnk-number{margin:0}.bnk-flow p{grid-column:1/-1;margin:0;font-size:16px}}
`,
  'kit-cta': `
.bnx-section.bnx-kit-cta{padding:74px 0;background:var(--bnx-accent);color:var(--bnx-accent-text)}
.bnk-cta-inner{display:grid;grid-template-columns:minmax(0,1fr) minmax(250px,.5fr);gap:64px;align-items:center}.bnk-cta-inner>div:last-child{justify-self:end;max-width:320px}
.bnx-section.bnx-kit-cta h2{font-size:clamp(42px,5.1vw,72px);letter-spacing:-2.6px;max-width:850px}.bnx-section.bnx-kit-cta p{margin-top:22px;color:inherit}
.bnk-cta-inner .bnk-actions{margin-top:22px}
.bnx-section.bnx-kit-cta .bnx-ap-button{background:var(--bnx-accent-text);color:var(--bnx-accent)}.bnx-section.bnx-kit-cta .bnx-ap-button:hover{background:var(--bnx-tint)}
.bnx-section.bnx-kit-cta .bnx-ap-button-secondary,.bnx-section.bnx-kit-cta .bnx-ap-button-secondary:hover{background:transparent;color:inherit;border-bottom-color:currentColor}
@media(max-width:960px){.bnk-cta-inner{gap:34px;grid-template-columns:minmax(0,1fr) minmax(220px,.5fr)}}
@media(max-width:760px){.bnx-section.bnx-kit-cta{padding:60px 0}.bnk-cta-inner{grid-template-columns:minmax(0,1fr);gap:26px}.bnk-cta-inner>div:last-child{justify-self:start;max-width:100%}.bnx-section.bnx-kit-cta p{margin-top:0}.bnx-section.bnx-kit-cta h2{font-size:46px;letter-spacing:-2px}}
@media(max-width:360px){.bnx-section.bnx-kit-cta h2{font-size:42px}}
`,
});
