import { z } from 'zod';
import { createDesignBrief } from '../../contracts/design-brief';
import { createSitePlan, type SitePlan } from '../../contracts/site-plan';
import { sha256 } from '../../lib/crypto';
import { BNX_VERSION, V2_PATTERN_DEFINITIONS, V2_PRESETS, createWebsiteTokenSnapshot, deepFreeze, v2PageJsonSchema, v2PageSchema, type V2Role, type V2Preset } from './contracts';
import { compileV2Page, getV2Catalog } from './render';
import { isKitPattern } from './kit';

/** A site must be all kit or all generic: the two families differ in measure, weight and spacing.
 * Until the kit has a section for every duty, generation plans only the generic patterns. */
const GENERATION_PATTERNS = V2_PATTERN_DEFINITIONS.filter(family => !isKitPattern(family.id));

/** Provider-independent review path. It does not call a model, reserve money,
 * approve a pattern, or create a publishable customer manifest. */
export const v2GenerationRequestSchema = z.object({
  request: z.string().trim().min(1).max(20000), seed: z.string().min(1).max(80).default('review'),
  preset: z.enum(V2_PRESETS).optional(), previousSignature: z.string().regex(/^[a-f0-9]{64}$/).optional(),
  availableImageCount: z.number().int().min(0).max(10000).default(0),
}).strict();
export type V2GenerationRequest = z.input<typeof v2GenerationRequestSchema>;
type Choice = { patternId: typeof V2_PATTERN_DEFINITIONS[number]['id']; variantId: string; layoutKey: string };
const fail = (code: string): never => { throw new Error(code); };
function roleFor(id: string): V2Role {
  if (id === 'contact') return 'contact';
  if (/^(orientation|introduction|hero|overview)$/.test(id)) return 'hero';
  if (/^(action|contact|next)$/.test(id)) return 'action';
  if (/faq|questions/.test(id)) return 'faq';
  if (/process|programme|format|method|steps/.test(id)) return 'process';
  if (/gallery|offering|details|space|example|experience|applications|products|portfolio|catalog|collection|showcase|cases|works|rooms|menu/.test(id)) return 'media';
  return 'features';
}
const choicesFor = (role: V2Role, completeSubjects: boolean): Choice[] => GENERATION_PATTERNS
  .filter(f => f.role === role).flatMap(f => f.variants.filter(v => role !== 'hero' || !completeSubjects || v.completeSubjects)
    .map(v => ({ patternId: f.id, variantId: v.id, layoutKey: v.layoutKey })));

async function compilerSnapshot(preset: V2Preset) {
  const catalog = await getV2Catalog();
  return catalog.patterns.filter(family => !isKitPattern(family.id)).flatMap(family => family.variants.map(variant => {
    const artifact = variant.artifacts.find(value => value.preset === preset)!;
    return { patternId: family.id, variantId: variant.id, revision: family.revision, artifactHash: artifact.artifactHash };
  }));
}

export async function prepareV2Generation(raw: V2GenerationRequest, trusted: { sitePlan?: SitePlan } = {}) {
  const input = v2GenerationRequestSchema.parse(raw);
  const brief = createDesignBrief({ request: input.request, hasExistingSite: false, scope: 'site' });
  if (!brief) return fail('BNX_BRIEF_UNAVAILABLE');
  const sitePlan = trusted.sitePlan ?? createSitePlan({ request: input.request, brief, availableImageCount: input.availableImageCount });
  if (!sitePlan) return fail('BNX_SITE_PLAN_UNAVAILABLE');
  const salt = await sha256(input.request + '\n' + input.seed);
  const ordinal = parseInt(salt.slice(0, 8), 16);
  // Industry determines information and subject protection, not a compulsory palette.
  const preset: V2Preset = input.preset ?? V2_PRESETS[ordinal % V2_PRESETS.length];
  const completeSubjects = brief.inference.siteKind === 'industrial-b2b' || brief.inference.siteKind === 'brand-commerce' || brief.inference.subtype === 'hardware';
  // Same request, different site: the task seed (never an earlier result) draws the
  // order of the middle sections and a small, different set of layouts for each one.
  // Without this every "car brand" task met the same eight duties with the same full
  // menu and the model converged on one skeleton.
  let state = ordinal || 1;
  const random = () => { state ^= state << 13; state >>>= 0; state ^= state >>> 17; state ^= state << 5; state >>>= 0; return state / 4294967296; };
  const shuffle = <T,>(values: readonly T[]): T[] => { const out = [...values]; for (let i = out.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [out[i], out[j]] = [out[j], out[i]]; } return out; };
  const drawn = sitePlan.pages.map(page => {
    // A contact page opens with the contact details themselves, not a picture hero.
    const roles = page.roles.map((responsibility, index) => ({ responsibility, role: responsibility.id === 'contact' ? 'contact' as V2Role : index === 0 ? 'hero' as V2Role : roleFor(responsibility.id) }));
    const movable = roles.map((entry, index) => index > 0 && entry.role !== 'faq' && entry.role !== 'action' ? index : -1).filter(index => index >= 0);
    const order = shuffle(movable), arranged = [...roles]; movable.forEach((slot, i) => { arranged[slot] = roles[order[i]]; });
    return arranged.map(entry => { const product = brief.inference.siteKind === 'industrial-b2b' || brief.inference.subtype === 'hardware';
      const all = shuffle(choicesFor(entry.role, product)).filter(choice => !product || !['centered-wide-stage', 'spotlight-card', 'banner-fullbleed'].includes(choice.layoutKey)); return { ...entry, choices: all.slice(0, Math.max(2, Math.ceil(all.length / 3))) }; });
  });
  const makePages = (rotation: number) => sitePlan.pages.map((page, pageIndex) => {
    let previousLayout = '';
    const sections = drawn[pageIndex].map(({ responsibility, role, choices }, index) => {
      const start = (ordinal + index + pageIndex * 3 + rotation) % choices.length;
      const ordered = [...choices.slice(start), ...choices.slice(0, start)];
      const recommended = ordered.find(choice => choice.layoutKey !== previousLayout) ?? ordered[0];
      previousLayout = recommended.layoutKey;
      return { id: `p${pageIndex + 1}-${responsibility.id.slice(0, 16)}`, responsibility: responsibility.id, purpose: responsibility.purpose, role,
        choices, recommended, missingContent: responsibility.fallback ?? brief.missingFactsPolicy };
    });
    return { key: page.key, title: page.title, purpose: page.purpose, sectionRange: page.sectionRange, visual: page.visual, sections };
  });
  let pages = makePages(0);
  const signatureFor = (value: typeof pages) => sha256(JSON.stringify(value.map(p => [p.key, p.sections.map(s => s.recommended.layoutKey)])));
  let signature = await signatureFor(pages);
  for (let rotation = 1; signature === input.previousSignature && rotation <= 8; rotation++) { pages = makePages(rotation); signature = await signatureFor(pages); }
  const catalog = GENERATION_PATTERNS.map(f => ({ id: f.id, revision: f.revision, role: f.role, variants: f.variants.map(v => ({ id: v.id, layoutKey: v.layoutKey, capacity: v.capacity, preferredMedia: v.preferredMedia, completeSubjects: v.completeSubjects })) }));
  const payload = { version: 'bnx-generation-review-1' as const, designSystemVersion: BNX_VERSION, request: input.request,
    preset, tokens: createWebsiteTokenSnapshot(preset), siteKind: brief.inference.siteKind, pages, catalog,
    signature, catalogHash: await sha256(JSON.stringify(catalog)), compilerSnapshot: await compilerSnapshot(preset), imageBudget: sitePlan.imageBudget,
    uploadedImagesOnly: /(?:只(?:能)?(?:用|使用)|仅(?:能)?(?:用|使用)|必须使用)\s*(?:(?:我(?:们)?|用户)的?)?\s*上传|\bonly (?:use )?(?:(?:my|our|user) )?uploaded (?:images?|photos?)\b/i.test(input.request),
    exceptions: sitePlan.exceptions, factsPolicy: brief.missingFactsPolicy,
    typographyPolicy: 'Preserve the user heading/body and node font overrides. Components inherit --bnf-heading / --bnf-body.',
    outputTokenLimit: 24000, reviewOnly: true as const, productionEnabled: false as const, customerExportReady: false as const };
  return deepFreeze({ ...payload, planHash: await sha256(JSON.stringify(payload)) });
}
export type V2GenerationPlan = Awaited<ReturnType<typeof prepareV2Generation>>;

export const v2GenerationSubmissionSchema = z.object({
  planHash: z.string().regex(/^[a-f0-9]{64}$/),
  pages: z.array(z.object({ key: z.string().regex(/^[a-z][a-z0-9-]{0,63}$/), composition: v2PageSchema }).strict()).min(1).max(12),
}).strict();

export function v2GenerationTool(plan: V2GenerationPlan) {
  return { type: 'function' as const, name: 'compose_design_preview', description: 'Review-only structural website composition. Fill visitor responsibilities with factual content. Choose from the frozen per-section choices and preserve IDs. Submit every planned page using one website preset. No arbitrary HTML/CSS/JS. Do not invent facts or images. This tool does not generate images, publish, approve, or charge.',
    parameters: { type: 'object', additionalProperties: false, properties: { planHash: { type: 'string', const: plan.planHash }, pages: { type: 'array', minItems: plan.pages.length, maxItems: plan.pages.length, items: { type: 'object', additionalProperties: false, properties: { key: { type: 'string', enum: plan.pages.map(p => p.key) }, composition: v2PageJsonSchema }, required: ['key', 'composition'] } } }, required: ['planHash', 'pages'] } };
}

/** Exercises the exact structured response -> native renderer path used by
 * the review gallery. A future paid-workflow adapter must separately satisfy
 * approval, immutable artifact storage, notices/export, billing and replay. */
export async function compileV2GenerationSubmission(plan: V2GenerationPlan, raw: unknown, context: Parameters<typeof compileV2Page>[1]) {
  const input = v2GenerationSubmissionSchema.parse(raw);
  const { planHash, ...payload } = plan;
  if (input.planHash !== planHash || await sha256(JSON.stringify(payload)) !== planHash) return fail('BNX_PLAN_CHANGED');
  if (!plan.reviewOnly || plan.productionEnabled || plan.customerExportReady) return fail('BNX_REVIEW_ONLY');
  if (await sha256(JSON.stringify(plan.catalog)) !== plan.catalogHash || await sha256(JSON.stringify(GENERATION_PATTERNS.map(f => ({ id: f.id, revision: f.revision, role: f.role, variants: f.variants.map(v => ({ id: v.id, layoutKey: v.layoutKey, capacity: v.capacity, preferredMedia: v.preferredMedia, completeSubjects: v.completeSubjects })) })))) !== plan.catalogHash) return fail('BNX_FROZEN_COMPILER_UNAVAILABLE');
  if (JSON.stringify(await compilerSnapshot(plan.preset)) !== JSON.stringify(plan.compilerSnapshot)) return fail('BNX_FROZEN_COMPILER_UNAVAILABLE');
  if (new Set(input.pages.map(p => p.key)).size !== input.pages.length || input.pages.length !== plan.pages.length) return fail('BNX_ALL_PAGES_REQUIRED');
  const sectionIds = new Set<string>();
  const warnings: Array<{ code: string; pageKey: string; message: string }> = [];
  let totalImages = 0, plannedImages = 0;
  for (const page of input.pages) {
    const expected = plan.pages.find(p => p.key === page.key);
    if (!expected || page.composition.preset !== plan.preset) return fail('BNX_PAGE_OR_PRESET_CHANGED');
    const content = page.composition.sections.filter(s => s.patternId !== 'footer');
    if (content.length !== expected.sections.length) return fail('BNX_CONTENT_RESPONSIBILITIES_MISSING');
    for (const section of page.composition.sections) {
      if (sectionIds.has(section.id)) return fail('BNX_SITE_DUPLICATE_SECTION_ID');
      sectionIds.add(section.id);
      if (section.patternId !== 'footer') {
        const planned = expected.sections.find(s => s.id === section.id);
        if (!planned || !planned.choices.some(c => c.patternId === section.patternId && c.variantId === section.variantId)) return fail('BNX_SECTION_OUTSIDE_PLAN');
      }
      totalImages += section.media.filter(m => m.kind !== 'missing').length;
      plannedImages += section.media.filter(m => m.kind === 'planned').length;
      for (const media of section.media) {
        if (media.kind === 'missing') continue;
        const asset = media.kind === 'owned' ? context.ownedAssets?.find(value => value.path === media.assetPath) : undefined;
        if (plan.uploadedImagesOnly && asset?.source !== 'uploaded') return fail('BNX_UPLOADED_IMAGES_REQUIRED');
        if (expected.visual.evidence === 'owned-only' && (!asset || asset.source === 'generated')) return fail('BNX_REAL_IMAGE_EVIDENCE_REQUIRED');
      }
    }
    const count = page.composition.sections.flatMap(s => s.media).filter(m => m.kind !== 'missing').length;
    if (count < expected.visual.minimum) warnings.push({ code: 'BNX_PAGE_MEDIA_MISSING', pageKey: page.key, message: '本页图片不足；这是结构预览，不代表生图或成品验收通过。' });
  }
  if (plan.imageBudget.generation === 'disabled' && plannedImages > 0) return fail('BNX_IMAGE_GENERATION_DISABLED');
  if (plannedImages > plan.imageBudget.max || (plan.imageBudget.max === 0 && totalImages > 0)) return fail('BNX_SITE_IMAGE_BUDGET');
  const pages = [];
  for (const page of input.pages) pages.push({ key: page.key, result: await compileV2Page(page.composition, context) });
  return { version: 'bnx-site-review-1' as const, planHash, pages, warnings, reviewOnly: true as const, customerExportReady: false as const,
    paidModelCalls: 0, imagesGenerated: 0, browserRendered: false, visualAcceptance: false };
}
