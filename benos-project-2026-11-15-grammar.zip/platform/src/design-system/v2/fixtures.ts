import { PATTERN_GALLERY_ASSETS } from '../../contracts/pattern-gallery-assets';
import { v2PageSchema, v2SectionSchema, type V2PageInput, type V2SectionInput } from './contracts';

export type V2FixturePreset = V2SectionInput['preset'];
export type V2FixtureExample = 'industrial' | 'stay';
export type V2FixtureScenario = 'standard' | 'long' | 'no-images' | 'rtl';
export const V2_FIXTURE_VARIANTS = {
  'hero-cover': ['scene', 'editorial'], 'hero-stage': ['split', 'centered', 'showcase', 'reverse'],
  'media-story': ['alternating', 'lead-list', 'spotlight'], 'media-mosaic': ['dominant', 'bento', 'cards'],
  features: ['grid', 'ledger', 'band', 'statement'], process: ['steps', 'timeline', 'cards'], faq: ['split', 'centered'],
  footer: ['directory', 'compact'], action: ['band', 'split', 'centered'], banner: ['fullbleed', 'split'], manifesto: ['center', 'index'], contact: ['form', 'details'], 'hero-kit': ['routes'], 'kit-statement': ['split'], 'kit-duo': ['cards'], 'kit-steps': ['flow'], 'kit-cta': ['band'],
} as const;
/** Existing generated concepts only. Never third-party component-library demo photographs. */
export const V2_FIXTURE_ASSETS = [
    { ...PATTERN_GALLERY_ASSETS[0], path: '/assets/design-system-v2/3365f01d98b81334c09d2603691d5c088fa9b9e844b2efdd2ac242f215a37e8d.png', example: 'stay' as const, source: 'generated' as const },
  { ...PATTERN_GALLERY_ASSETS[1], path: '/assets/design-system-v2/9f1a77ffcd46dc3498ea85875040a531a480c0a309b772efec2d9505539323f7.png', example: 'stay' as const, source: 'generated' as const },
  { ...PATTERN_GALLERY_ASSETS[2], path: '/assets/design-system-v2/a7708ab518a364bb2a14c090d4b1a42e532d8660e0e6379b2d1b4efa4fa1f91b.png', example: 'stay' as const, source: 'generated' as const },
  { ...PATTERN_GALLERY_ASSETS[3], path: '/assets/design-system-v2/eb6339668e38af2d3fbecf4774d01e31529e422ae40854b9942492f01eb43868.png', example: 'stay' as const, source: 'generated' as const },
  { file: '7b2f11209b5d33d51b2c1c40c8a322724ffc50d9f81e7e7c04952fff2ed3b655.png', path: '/assets/design-system-v2/7b2f11209b5d33d51b2c1c40c8a322724ffc50d9f81e7e7c04952fff2ed3b655.png', sha256: '7b2f11209b5d33d51b2c1c40c8a322724ffc50d9f81e7e7c04952fff2ed3b655', width: 1024, height: 1024, size: 1580118, example: 'industrial' as const, source: 'generated' as const },
  { file: 'c3fb0d49844a29f7fe748c61f56502e313983517e03cd22b0d95bca9bb5b6763.png', path: '/assets/design-system-v2/c3fb0d49844a29f7fe748c61f56502e313983517e03cd22b0d95bca9bb5b6763.png', sha256: 'c3fb0d49844a29f7fe748c61f56502e313983517e03cd22b0d95bca9bb5b6763', width: 1536, height: 1024, size: 2021636, example: 'industrial' as const, source: 'generated' as const },
  { file: '2759a036c27502da80cd43b8f1d92ab578c776927be8514743ee38806add7dc3.png', path: '/assets/design-system-v2/2759a036c27502da80cd43b8f1d92ab578c776927be8514743ee38806add7dc3.png', sha256: '2759a036c27502da80cd43b8f1d92ab578c776927be8514743ee38806add7dc3', width: 1536, height: 1024, size: 2302336, example: 'industrial' as const, source: 'generated' as const },
] as const;
export type V2FixtureOptions = { imageBaseUrl?: string; scenario?: V2FixtureScenario; example?: V2FixtureExample; exampleHref?: string };
const stayItems = [
  ['面向山色', '让窗外的层叠绿意留作背景。阅读、发呆或一杯热茶，都不必安排得太满。'],
  ['跟着光线', '观察光怎样进入房间，从明亮的共享空间走向安静的阅读角。'],
  ['朴素的触感', '木、石与棉麻留下各自的纹理，空间因此有了可感知的细节。'],
  ['留出自己的时间', '和同行的人一起散步，也为独处留下一个不被打扰的角落。'],
];
const industrialItems = [
  ['Begin with the part', 'Identify the material, drawing revision and features that define the job.'],
  ['Understand access', 'Review tool approach, workholding and the sequence between operations.'],
  ['Define the outcome', 'Agree what must be inspected and which evidence will establish acceptance.'],
  ['Make assumptions visible', 'Keep configuration, handling and operating conditions in the same brief.'],
];
const titleMap: Record<string, [string, string]> = {
  'hero-cover': ['在群山之间，留一段空白。', 'See the process. Understand the possibilities.'],
  'hero-stage': ['不赶路，也有新的风景。', 'Start with the part. Define the right machine.'],
  'media-story': ['让空间，跟着一天慢慢展开。', 'Look closer at how the work reaches the tool.'],
  'media-mosaic': ['从一扇窗，走进山间生活。', 'A closer view of process and detail.'],
  features: ['少一点安排，多一点感受。', 'A useful shortlist starts with the right questions.'],
  process: ['从出发的念头，到自己的节奏。', 'From a requirement to a clear project brief.'],
  faq: ['出发之前，先把这些想清楚。', 'Clear answers before the specification.'],
  action: ['下一段空闲，留给山间。', 'Make the next discussion specific.'],
  footer: ['山间来信', 'JianTai / Process-led thinking'],
  banner: ['把一整面山，留在窗外。', 'One view of the whole process.'],
  manifesto: ['慢下来，才看得见。', 'Clarity before commitment.'],
  contact: ['告诉我们，你想去哪里。', 'Tell us about the part.'],
  'hero-kit': ['在群山之间，留一段空白。', 'Start with the part. Define the right machine.'],
  'kit-statement': ['少一点安排，多一点感受。', 'Better-defined projects. More considered machinery.'],
  'kit-duo': ['跟着光，看看房间里的日常。', 'Two views of the same process.'],
  'kit-steps': ['从出发的念头，到自己的节奏。', 'From a requirement to a clear project brief.'],
  'kit-cta': ['下一段空闲，留给山间。', 'Make the next discussion specific.'],
};
const purposes = ['山间木屋与自然环境的关系', '木质卧室与自然光', '窗边阅读角与材质细节', '茶席与山景的关系'];
const equipmentPurposes = ['Spindle and tool above a clamped workpiece', 'Workpiece in a locating and clamping fixture', 'Machined metal housing and mating plate'];

export function getV2Fixture(patternId: string, variantId: string, preset: V2FixturePreset, options: V2FixtureOptions = {}) {
  if (!(patternId in V2_FIXTURE_VARIANTS) || !(V2_FIXTURE_VARIANTS[patternId as keyof typeof V2_FIXTURE_VARIANTS] as readonly string[]).includes(variantId)) throw new Error('V2_FIXTURE_UNKNOWN');
  const example = options.example ?? 'stay', industrial = example === 'industrial', rtl = options.scenario === 'rtl';
  const base = (options.imageBaseUrl ?? '/api/admin/design-system-v2/assets').replace(/\/$/, '');
  const ownedAssets = V2_FIXTURE_ASSETS.map(asset => ({ path: `${base}/${asset.file}`, width: asset.width, height: asset.height, sha256: asset.sha256, source: asset.source }));
  const selected = V2_FIXTURE_ASSETS.filter(asset => asset.example === example);
  const itemCount = patternId === 'kit-duo' ? 2 : patternId === 'kit-steps' ? 4 : patternId === 'media-mosaic' ? variantId === 'bento' ? 4 : 3 : patternId === 'media-story' && variantId === 'alternating' ? 3 : 3;
  const rows = industrial ? industrialItems : stayItems;
  const items = Array.from({ length: itemCount }, (_, i) => ({ title: rows[i % rows.length][0], text: rows[i % rows.length][1] + (options.scenario === 'long' ? industrial ? ' Record the conditions behind each choice so the comparison stays useful when the project changes.' : ' 从同行人的需要、空间条件和可支配的时间出发，保留选择的余地，让每一种停留都有自己的理由。' : ''), icon: 'number' as const }));
  let mediaCount = ['hero-cover', 'hero-stage', 'banner', 'hero-kit'].includes(patternId) ? 1 : patternId === 'kit-duo' ? 2 : patternId === 'media-story' ? variantId === 'lead-list' || variantId === 'spotlight' ? 1 : 3 : patternId === 'media-mosaic' ? itemCount : 0;
  if (options.scenario === 'no-images') mediaCount = 0;
  const media = Array.from({ length: mediaCount }, (_, i) => { const asset = selected[i % selected.length], purpose = industrial ? equipmentPurposes[i % equipmentPurposes.length] : purposes[i % purposes.length]; return { id: `image-${i + 1}`, kind: 'owned' as const, assetPath: `${base}/${asset.file}`, purpose, alt: industrial ? `Equipment concept illustration: ${purpose}` : `${purpose}的生成概念图`, subjectPolicy: industrial && patternId !== 'hero-cover' ? 'complete' as const : 'crop-safe' as const, focalPoint: 'center' as const, textSafeArea: patternId === 'hero-cover' ? 'left' as const : 'none' as const, ...(patternId === 'hero-kit' || patternId === 'kit-duo' ? { caption: purpose } : {}) }; });
  const href = options.exampleHref ?? `/api/admin/design-system-v2/page?example=${example}&preset=${preset}`;
  const questions = industrial ? [
    { question: 'What is useful for an initial discussion?', answer: 'A current drawing, the material and the features that need machining. Add handling, output and inspection requirements when they are known.' },
    { question: 'Do these images identify a machine available to order?', answer: 'They are equipment concept illustrations. Confirm the model, configuration and acceptance conditions in the actual project documentation.' },
    { question: 'Can a catalogue image establish achievable precision?', answer: 'No. Part geometry, tooling, setup and verification conditions need to be evaluated together.' },
  ] : [
    { question: '怎样安排一次不匆忙的停留？', answer: '先选一件最想做的事，再给它留出完整时间。阅读、散步和休息需要不同的节奏，不必全部排进同一天。' },
    { question: '出发之前，需要核实哪些信息？', answer: '向实际经营者确认地点、交通、可用房型、价格与预订规则。此处的概念画面不代表可预订的真实房源。' },
    { question: '怎样兼顾独处与一起旅行？', answer: '提前聊聊每个人最在意的体验。在共同行程之外留出各自的时间，通常比增加更多安排更轻松。' },
  ];
  const content: V2SectionInput['content'] = {
    eyebrow: industrial ? 'Process / Equipment / Decisions' : '山野 / 日常 / 空间', title: titleMap[patternId][industrial ? 1 : 0],
    lead: industrial ? 'Connect the production goal, the process and the evidence needed to make a useful decision.' : '从自然光、朴素材质与生活片段出发，探索停留的不同可能。',
    items: ['features', 'process', 'media-story', 'media-mosaic', 'hero-kit', 'kit-duo', 'kit-steps'].includes(patternId) || (patternId === 'manifesto' && variantId === 'index') || (patternId === 'banner' && variantId === 'split') ? items : [],
    questions: patternId === 'faq' ? questions : [],
    actions: ['hero-cover', 'hero-stage', 'action', 'banner', 'hero-kit', 'kit-cta'].includes(patternId) ? [{ label: industrial ? 'Explore the process' : '看看空间', href: `${href}#gallery`, kind: 'primary' }, { label: industrial ? 'Read the questions' : '出发前了解', href: `${href}#questions`, kind: 'secondary' }] : [],
    ...(patternId === 'contact' ? { items: [{ title: industrial ? 'Address' : '地址', text: industrial ? '100 Example Road, Shanghai' : '上海市示例路 100 号' }, { title: industrial ? 'Hours' : '工作时间', text: industrial ? 'Mon–Fri 9:00–18:00' : '周一至周五 9:00–18:00' }] } : {}),
    ...(patternId === 'footer' ? { navigation: [{ title: industrial ? 'Explore' : '发现', links: [{ label: industrial ? 'Overview' : '开始', href: `${href}#orientation` }, { label: industrial ? 'Process details' : '空间与细节', href: `${href}#gallery` }] }, { title: industrial ? 'Prepare' : '计划', links: [{ label: industrial ? 'Your next step' : '旅居节奏', href: `${href}#process` }, { label: industrial ? 'Questions' : '常见问题', href: `${href}#questions` }] }], copyright: industrial ? 'JianTai · Equipment concept study' : '山间来信 · 空间概念研究', imageAttribution: industrial ? 'Generated equipment concepts; no product specifications or company delivery claims.' : '图像为复用既有素材的生成概念图，不代表真实经营场所。' } : {}),
  };
  if (rtl) { content.title = 'مساحة واضحة للفكرة والتفاصيل'; content.lead = 'ابدأ بالاحتياج ثم اقرأ التفاصيل واترك مجالاً لاختيار الخطوة المناسبة.'; }
  if (options.scenario === 'long') content.title = (content.title + (industrial ? ' — a shared view of the work and its conditions.' : ' 在自然与日常之间，找到适合自己的方式。')).slice(0, 120);
  const input = v2SectionSchema.parse({ id: `sample-${patternId}`, patternId, variantId, preset, content, media });
  return { input, context: { mode: 'review' as const, ownedAssets, verifiedFactRefs: [] as string[] }, lang: rtl ? 'ar' : industrial ? 'en' : 'zh-CN', dir: rtl ? 'rtl' as const : 'ltr' as const, fixtureOnly: true as const };
}

export function createV2PageFixture(options: { preset: V2FixturePreset; example: V2FixtureExample; imageBaseUrl?: string; scenario?: V2FixtureScenario }) {
  const industrial = options.example === 'industrial';
  const plan: Array<[string, string, string]> = industrial ? [
    ['orientation', 'hero-stage', 'split'], ['criteria', 'features', 'ledger'], ['gallery', 'media-story', 'alternating'],
    ['applications', 'features', 'band'], ['process', 'process', 'cards'], ['technical-detail', 'media-story', 'lead-list'],
    ['questions', 'faq', 'split'], ['next', 'action', 'band'], ['colophon', 'footer', 'compact'],
  ] : [
    ['orientation', 'hero-cover', 'scene'], ['gallery', 'media-mosaic', 'cards'], ['choices', 'features', 'grid'],
    ['details', 'media-story', 'lead-list'], ['process', 'process', 'timeline'], ['questions', 'faq', 'centered'], ['next', 'action', 'centered'], ['colophon', 'footer', 'directory'],
  ];
  const items = (rows: Array<[string, string]>) => rows.map(([title, text]) => ({ title, text }));
  const overrides: Record<string, Partial<V2SectionInput['content']>> = industrial ? {
    criteria: { lead: 'Keep every proposal tied to the same part, process and acceptance conditions.' },
    applications: { eyebrow: 'Application thinking', title: 'Different parts. Different questions.', lead: 'The shape of the component changes what deserves attention. Use these examples to organise the discussion, not as a promise of a particular machine capability.', items: items([
      ['Enclosed cavities', 'Review tool reach, chip evacuation and the surfaces that are difficult to access. A headline travel distance is only one part of the discussion.'],
      ['Multiple working faces', 'Consider the locating strategy and how the relationship between faces is maintained through the operation sequence.'],
      ['Repeated part families', 'Look at which fixtures, tools and checks can be shared, and which details still need a dedicated setup.'],
    ]) },
    gallery: { title: 'Three views of the same process.', lead: 'Tool access, workholding and part geometry should be considered together. The illustrations help make that relationship visible.', items: items([
      ['Where the tool meets the work', 'Approach angles, cutting conditions and access to internal features shape the machining strategy.'],
      ['How the part is held', 'Locating surfaces and clamp positions influence repeatability, tool clearance and the sequence between operations.'],
      ['What the finished part must do', 'Mating faces, pockets and holes have different functional requirements. Define which characteristics need verification.'],
    ]) },
    process: { title: 'Make each decision traceable.', lead: 'A shared sequence keeps technical discussion useful as the project becomes more specific.', items: items([
      ['Define the input', 'Gather the current drawing, material, samples and the requirements that are already known.'],
      ['Review the process', 'Discuss operations, access, workholding and handling before narrowing the configuration.'],
      ['Agree the evidence', 'Record the proposed scope and the acceptance checks needed before a commitment.'],
    ]) },
    'technical-detail': { eyebrow: 'Selection detail', title: 'Compare proposals against one common brief.', lead: 'Small differences in assumptions can make apparently similar proposals difficult to compare.', items: items([
      ['One drawing revision', 'Use the same geometry, material and revision for every proposal. Keep open questions beside the relevant feature.'],
      ['Explicit operating conditions', 'Separate the machine configuration from tooling, fixtures and handling assumptions. Each affects the expected result.'],
      ['A written acceptance method', 'Define the inspection conditions, evidence and responsibilities. Images and headline specifications do not replace this agreement.'],
    ]) },
    next: { title: 'Bring the part. Build the brief.', lead: 'Review the checklist and questions above, then gather the information that is specific to your project.', actions: [{ label: 'Review selection details', href: '#technical-detail', kind: 'primary' }, { label: 'Back to the process', href: '#process', kind: 'secondary' }] },
  } : {
    gallery: { title: '跟着光，看看房间里的日常。', lead: '从卧室到阅读角，再到一张茶桌，空间为不同的停留方式留下位置。', items: items([
      ['自然光里的卧室', '让窗景成为安静的背景，把休息留给一段完整、不被打断的时间。'],
      ['靠近窗边的阅读角', '一把椅子、一段光线，足够让注意力慢慢回到手中的书。'],
      ['一起坐下的茶席', '围绕一张桌子放慢节奏，让共享的时刻不必以安排更多活动为前提。'],
    ]) },
    choices: { title: '把有限的时间，留给真正想做的事。', lead: '不必把一次停留变成更紧的日程。先想清楚自己需要怎样的节奏。', items: items([
      ['一段完整的阅读', '带一本正在读的书，在自然光里慢慢读完一章，让注意力停留在眼前。'],
      ['一起坐下聊聊', '把聊天从行程缝隙里拿出来，留给共同的桌边，也留给没有结论的闲谈。'],
      ['不必记录的时刻', '观察山色和天气的变化，也允许自己不拍照、不打卡，只在这里待一会儿。'],
    ]) },
    details: { title: '空间的细节，比安排更多事情更重要。', lead: '用光线、材质与人之间的距离，理解一种更从容的生活方式。' },
    process: { title: '从出发的念头，到自己的节奏。', lead: '实际行程与入住条件需要向经营者核实。先为自己的需要排出顺序。', items: items([
      ['确定最在意的体验', '和同行的人聊聊，这次更需要独处、相聚，还是在自然里走走。'],
      ['核实真实条件', '查看天气与交通，再确认地点、房型、价格和实际可用服务。'],
      ['给计划留一点空白', '抵达之后不必急着完成清单，让光线、天气和当下的感受带来新的安排。'],
    ]) },
    next: { title: '下一段空闲，留一点余地。', lead: '从一处空间、一个问题开始，整理自己真正需要的停留方式。' },
  };
  const fixtures = plan.map(([id, patternId, variantId]) => {
    const fixture = getV2Fixture(patternId, variantId, options.preset, { ...options, exampleHref: '' });
    const input = { ...fixture.input, id, content: { ...fixture.input.content, ...overrides[id] } };
    if (id !== 'orientation') delete input.content.eyebrow;
    if (['questions', 'colophon'].includes(id)) delete input.content.lead;
    if (industrial && id === 'technical-detail') input.media = [getV2Fixture('media-story', 'alternating', options.preset, { ...options, exampleHref: '' }).input.media[2]].filter(Boolean);
    if (!industrial && id === 'gallery') input.media = getV2Fixture('media-mosaic', 'bento', options.preset, { ...options, exampleHref: '' }).input.media.slice(1);
    if (!industrial && id === 'details') input.media = [getV2Fixture('media-mosaic', 'bento', options.preset, { ...options, exampleHref: '' }).input.media[3]].filter(Boolean);
    return { ...fixture, input };
  });
  const input: V2PageInput = v2PageSchema.parse({ version: 'bnx-compose-1', preset: options.preset, sections: fixtures.map(fixture => fixture.input) });
  return { input, context: fixtures[0].context, lang: fixtures[0].lang, dir: fixtures[0].dir, title: industrial ? 'JianTai — Process-led equipment study' : '山间来信 — 留给生活的空间', fixtureOnly: true as const, example: options.example };
}
