import { sha256 } from '../../lib/crypto';
import type { SitePlan } from '../../contracts/site-plan';
import { deepFreeze, V2_PATTERN_DEFINITIONS, V2_PRESETS, type V2Preset } from './contracts';
import { prepareV2Generation, type V2GenerationPlan } from './generation';
import { getV2Catalog, type V2OwnedAsset } from './render';
import { hasExactV2Review, type V2TrustedReview } from './registry';

type Base = Omit<V2GenerationPlan, 'version' | 'reviewOnly' | 'productionEnabled' | 'customerExportReady' | 'planHash'>;
export type V2ProductionPlan = Base & {
  version: 'bnx-generation-1'; reviewOnly: false; productionEnabled: true; customerExportReady: true;
  approvedSnapshot: readonly V2TrustedReview[]; planHash: string;
  componentSelection?: { version: 'model-choice-1'; previousSignature: string | null; instruction: string };
  verifiedContent?: { factRefs: readonly string[]; contacts?: readonly { factRef: string; label: string; href: string }[]; instruction: string };
};

/** Selecting a new engine never grants approval. It is available only when a
 * single reviewed preset can fulfill every page responsibility and a footer. */
export async function prepareApprovedV2Generation(input: {
  request: string; seed: string; sitePlan: SitePlan; availableImageCount: number;
  previousSignature?: string; stylePreference?: string; approvedSnapshot: readonly V2TrustedReview[];
  confirmedContacts?: readonly { factRef: string; label: string; href: string }[];
}): Promise<V2ProductionPlan | null> {
  if (!input.approvedSnapshot.length) return null;
  const catalog = await getV2Catalog();
  const ordinal = parseInt((await sha256(input.seed)).slice(0, 8), 16);
  const permitted=permittedV2Presets(input.request,input.stylePreference);
  const presets = [...V2_PRESETS.slice(ordinal % 3), ...V2_PRESETS.slice(0, ordinal % 3)].filter(p=>permitted.includes(p));
  for (const preset of presets) {
    const artifacts = catalog.patterns.flatMap(f => f.variants.flatMap(v => v.artifacts)).filter(a => a.preset === preset && hasExactV2Review(a, input.approvedSnapshot));
    if (!artifacts.some(a => a.patternId === 'footer')) continue;
    const source = await prepareV2Generation({ request: input.request, seed: input.seed, preset, previousSignature: input.previousSignature, availableImageCount: input.availableImageCount }, { sitePlan: input.sitePlan });
    const pages = source.pages.map(page => { let previousLayout = ''; return ({ ...page, sections: page.sections.map(section => {
      const choices = section.choices.filter(choice => artifacts.some(a => a.patternId === choice.patternId && a.variantId === choice.variantId));
      let recommended = choices.find(c => c.variantId === section.recommended.variantId && c.patternId === section.recommended.patternId) ?? choices[(ordinal + page.sections.indexOf(section)) % Math.max(1, choices.length)];
      if (recommended?.layoutKey === previousLayout) recommended = choices.find(c => c.layoutKey !== previousLayout) ?? recommended;
      previousLayout = recommended?.layoutKey ?? '';
      return { ...section, choices, recommended };
    }) }); });
    if (pages.some(page => page.sections.some(section => !section.choices.length))) continue;
    const signatureOf = () => sha256(JSON.stringify(pages.map(p => [p.key, p.sections.map(s => s.recommended.layoutKey)])));
    let signature = await signatureOf();
    if (signature === input.previousSignature) {
      const section = pages.flatMap(page => page.sections).find(section => section.choices.some(choice => choice.layoutKey !== section.recommended.layoutKey));
      if (section) { section.recommended = section.choices.find(choice => choice.layoutKey !== section.recommended.layoutKey)!; signature = await signatureOf(); }
    }
    const { planHash: _reviewHash, ...base } = source;
    const approvedSnapshot = input.approvedSnapshot.filter(row => artifacts.some(a => a.artifactHash === row.artifactHash));
    const payload = { ...base, version: 'bnx-generation-1' as const, pages, signature,
      compilerSnapshot: source.compilerSnapshot.filter(entry => artifacts.some(a => a.artifactHash === entry.artifactHash)),
      catalog: source.catalog.map(f => { const definition = V2_PATTERN_DEFINITIONS.find(d => d.id === f.id)!; return { ...f,
        label: definition.label, description: definition.description, sourceIds: definition.sourceIds,
        variants: f.variants.filter(v => artifacts.some(a => a.patternId === f.id && a.variantId === v.id)).map(v => ({ ...v, label: definition.variants.find(d => d.id === v.id)!.label })) };
      }).filter(f => f.variants.length),
      componentSelection: { version: 'model-choice-1' as const, previousSignature: input.previousSignature ?? null,
        instruction: 'Choose the best patternId/variantId independently for each responsibility from its choices. recommended is optional, not a mandatory assignment. Use catalog labels, purpose, capacity, completeSubjects and preferredMedia to match content and available images. Avoid adjacent identical layoutKeys when another eligible layout exists. Preserve page/section IDs, order, one preset, facts and image budget. Do not repeat the previous actual layout combination when alternatives exist. Shared footer is also chosen from approved catalog variants.' },
      verifiedContent: input.confirmedContacts?.length
        ? { factRefs: input.confirmedContacts.map(c => c.factRef), contacts: input.confirmedContacts.map(c => ({ ...c })), instruction: 'The customer confirmed these contact details. Use them in content.contact with exactly the given factRef, label and href (contact sections and the shared footer). Leave items.value/factRef null. Do not invent any other fact reference, phone, email or address.' }
        : { factRefs: [] as string[], instruction: 'No verified metric/contact fact references are available in this workflow. Leave content.contact empty and items.value/factRef null. Do not invent fact references. User-supplied contact details can appear verbatim in ordinary body text or a safe contact action; do not fabricate facts or contact data.' },
      approvedSnapshot, exceptions: [...base.exceptions, ...(signature === input.previousSignature ? ['已确认组件只有一种可用组合，本次无法继续变化；没有启用未确认模式。'] : [])], reviewOnly: false as const, productionEnabled: true as const, customerExportReady: true as const };
    payload.catalogHash = await sha256(JSON.stringify(payload.catalog));
    return deepFreeze({ ...payload, planHash: await sha256(JSON.stringify(payload)) });
  }
  return null;
}

type PlannedComposition = { pages: Array<{ pageKey: string; composition: { preset: string; sections: Array<{ id: string; patternId: string; variantId: string; media: Array<{ kind: string; assetPath?: string }> }> } }>; footer?: unknown };
/** Runs before compilation/payment. The compiler separately verifies types,
 * links, media ownership and exact production approvals. */
export async function assertV2ProductionPlan(plan: V2ProductionPlan, hash: string, input: PlannedComposition, owned: readonly V2OwnedAsset[]) {
  const { planHash, ...payload } = plan;
  const fail = (code: string): never => { throw new Error(code); };
  if (!input.footer) fail('BNX_SHARED_FOOTER_REQUIRED');
  if (plan.version !== 'bnx-generation-1' || hash !== planHash || await sha256(JSON.stringify(payload)) !== planHash) fail('BNX_PLAN_CHANGED');
  const current = (await getV2Catalog()).patterns.flatMap(f => f.variants.flatMap(v => v.artifacts));
  if (plan.compilerSnapshot.some(entry => !current.some(a => a.artifactHash === entry.artifactHash && a.patternId === entry.patternId && a.variantId === entry.variantId))) fail('BNX_FROZEN_COMPILER_UNAVAILABLE');
  if (input.pages.length !== plan.pages.length || new Set(input.pages.map(p => p.pageKey)).size !== plan.pages.length) fail('BNX_ALL_PAGES_REQUIRED');
  let planned = 0, visible = 0;
  const autonomous = plan.componentSelection?.version === 'model-choice-1';
  for (const page of input.pages) {
    const expected = plan.pages.find(p => p.key === page.pageKey);
    if (!expected || page.composition.preset !== plan.preset) fail('BNX_PAGE_OR_PRESET_CHANGED');
    const content = page.composition.sections.filter(s => s.patternId !== 'footer');
    if (content.length !== expected!.sections.length) fail('BNX_CONTENT_RESPONSIBILITIES_MISSING');
    let previousLayout = '';
    for (let index = 0; index < content.length; index++) {
      const section = content[index], duty = expected!.sections[index];
      const choice = duty.choices.find(c => c.patternId === section.patternId && c.variantId === section.variantId);
      if (section.id !== duty.id || !choice || (!autonomous && (section.patternId !== duty.recommended.patternId || section.variantId !== duty.recommended.variantId))) fail('BNX_SECTION_OUTSIDE_PLAN');
      if (autonomous && choice!.layoutKey === previousLayout && duty.choices.some(c => c.layoutKey !== previousLayout)) fail('BNX_ADJACENT_LAYOUT_REPEATED');
      previousLayout = choice!.layoutKey;
    }
    for (const media of page.composition.sections.flatMap(s => s.media)) {
      if (media.kind === 'missing') continue;
      visible++; if (media.kind === 'planned') planned++;
      const asset = media.kind === 'owned' ? owned.find(a => a.path === media.assetPath) : undefined;
      if (plan.uploadedImagesOnly && asset?.source !== 'uploaded') fail('BNX_UPLOADED_IMAGES_REQUIRED');
      if (expected!.visual.evidence === 'owned-only' && (!asset || asset.source === 'generated')) fail('BNX_REAL_IMAGE_EVIDENCE_REQUIRED');
    }
  }
  if (plan.imageBudget.generation === 'disabled' && planned) fail('BNX_IMAGE_GENERATION_DISABLED');
  if (planned > plan.imageBudget.max || (plan.imageBudget.max === 0 && visible)) fail('BNX_SITE_IMAGE_BUDGET');
  const pages = plan.pages.map(page => ({ key: page.key, sections: input.pages.find(p => p.pageKey === page.key)!.composition.sections.filter(s => s.patternId !== 'footer').map(section => {
    const duty = page.sections.find(s => s.id === section.id)!;
    return { id: section.id, ...duty.choices.find(c => c.patternId === section.patternId && c.variantId === section.variantId)! };
  }) }));
  const signature = await sha256(JSON.stringify(pages.map(p => [p.key, p.sections.map(s => s.layoutKey)])));
  if (autonomous && signature === plan.componentSelection!.previousSignature && plan.pages.some(p => p.sections.some(s => new Set(s.choices.map(c => c.layoutKey)).size > 1))) fail('BNX_LAYOUT_REPEATED');
  return { version: 'bnx-selection-1' as const, signature, pages };
}

/** Respect explicit light/dark and accent requests. A reviewed palette that
 * cannot satisfy them is not silently substituted; the existing engine remains available. */
export function permittedV2Presets(request:string,stylePreference=''):V2Preset[]{
 const text=(request+' '+stylePreference).normalize('NFKC').toLowerCase();
 const negative=/(?:不要|不用|避免|禁止|别用|不使用|no\b|not\b|without\b)[^，,。.;；!?！？]{0,12}$/;
 const positive=(pattern:RegExp)=>[...text.matchAll(pattern)].some(m=>!negative.test(text.slice(Math.max(0,m.index!-24),m.index)));
 const noDark=/(?:不要|不用|避免|禁止|别用|不使用)[^，,。.;；!?！？]{0,8}(?:深色|暗色|黑底)|\b(?:no|not|without)\s+(?:a\s+)?dark\b/.test(text);
 const noLight=/(?:不要|不用|避免|禁止|别用|不使用)[^，,。.;；!?！？]{0,8}(?:浅色|亮色|白底)|\b(?:no|not|without)\s+(?:a\s+)?light\b/.test(text);
 const dark=positive(/深色|暗色|黑底|\bdark (?:theme|mode|background)\b/g),light=positive(/浅色|亮色|白底|白色背景|\b(?:light|white) (?:theme|mode|background)\b/g);
 let pool:V2Preset[]=[...V2_PRESETS];
 if(noDark||light)pool=pool.filter(p=>p!=='deep-studio');
 if(noLight||dark)pool=pool.filter(p=>p==='deep-studio');
 const accents:[RegExp,V2Preset[]][]=[[/绿色(?:配色|主色|强调色)|(?:配色|主色|强调色)[^，,。.;；]{0,6}绿色|\bgreen (?:theme|accent|palette)\b/g,['calm-paper']],[/紫色(?:配色|主色|强调色)|(?:配色|主色|强调色)[^，,。.;；]{0,6}紫色|\bpurple (?:theme|accent|palette)\b/g,['bold-signal']],[/蓝色(?:配色|主色|强调色)|(?:配色|主色|强调色)[^，,。.;；]{0,6}蓝色|\bblue (?:theme|accent|palette)\b/g,['deep-studio']],[/(?:红色|橙色|黄色|粉色)(?:配色|主色|强调色)|(?:配色|主色|强调色)[^，,。.;；]{0,6}(?:红色|橙色|黄色|粉色)|\b(?:red|orange|yellow|pink) (?:theme|accent|palette)\b|#[a-f0-9]{6}\b/g,[]]];
 for(const [pattern,allowed] of accents)if(positive(pattern))pool=pool.filter(p=>allowed.includes(p));
 return pool;
}

/** The model supplies site metadata and empty template slots. Ordinary raw
 * page/footer bodies, global CSS and undeclared pages cannot bypass approval. */
export function assertV2ManifestSkeleton(plan:V2ProductionPlan,composition:any,manifest:any,reference:any){
 const fail=(code:string):never=>{throw new Error(code);};
 if(!composition?.footer)fail('BNX_SHARED_FOOTER_REQUIRED');
 const actual=manifest?.site?.pages;
 if(!Array.isArray(actual)||actual.length!==plan.pages.length||new Set(actual.map((p:any)=>p.key)).size!==plan.pages.length||actual.some((p:any)=>!plan.pages.some(expected=>expected.key===p.key)))fail('BNX_MANIFEST_PAGES_OUTSIDE_PLAN');
 if(String(manifest.site.theme?.global_css??'').trim())fail('BNX_AUTHOR_GLOBAL_STYLE_FORBIDDEN');
 const targets=new Set([...composition.pages.map((p:any)=>p.templateId),composition.footer.templateId]);
 if(!Array.isArray(manifest.templates))fail('BNX_MANIFEST_SKELETON_INVALID');
 for(const template of manifest.templates){
  const document=template?.document;
  const empty=document&&Object.keys(document).every(key=>['version','html','css'].includes(key))&&!String(document.html??'').trim()&&!String(document.css??'').trim();
  if(targets.has(template.id)){if(!empty)fail('BNX_TEMPLATE_BODY_MUST_BE_EMPTY');}
  else if(!empty&&!reference.templates.some((t:any)=>t.id===template.id&&t.type===template.type&&JSON.stringify(t.document)===JSON.stringify(document)))fail('BNX_UNPLANNED_TEMPLATE_CONTENT');
 }
}
