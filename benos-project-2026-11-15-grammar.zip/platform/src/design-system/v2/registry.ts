import { z } from 'zod';
import { sha256 } from '../../lib/crypto';
import { patternContentSchema, patternMediaSchema } from '../../contracts/section-patterns';
import { BNX_VERSION, BNX_SCHEMA_VERSION, V2_PATTERN_DEFINITIONS, V2_PRESETS, createWebsiteTokenSnapshot, deepFreeze, parseV2Page, v2ContractFingerprint, v2SectionSchema, v2PageJsonSchema, type V2PatternId, type V2Preset, type WebsiteTokenSnapshot } from './contracts';
import { assertV2SourceAdaptersReady, getV2Notices, getV2Sources, type V2Notice, type V2Source } from './provenance';

export { V2_PATTERN_DEFINITIONS, V2_PRESETS, parseV2Page };
export const V2_PATTERNS = V2_PATTERN_DEFINITIONS;
export function getV2Pattern(patternId: string) {
  const family = V2_PATTERN_DEFINITIONS.find(item => item.id === patternId);
  if (!family) throw new Error('BNX_PATTERN_UNKNOWN');
  return family;
}
export function findV2Pattern(patternId: string, variantId: string) {
  const family = getV2Pattern(patternId), variant = family.variants.find(item => item.id === variantId);
  if (!variant) throw new Error('BNX_VARIANT_UNKNOWN');
  return { family, variant };
}
export type V2ArtifactInput = {
  patternId: V2PatternId; variantId: string; preset: V2Preset;
  rendererVersion: string; rendererFingerprint: string; css: string;
};
export type V2ApprovalKey = {
  patternId: V2PatternId; variantId: string; revision: number; preset: V2Preset;
  artifactHash: string; sourceGraphHash: string; noticeBundleHash: string;
};
export type V2Artifact = V2ApprovalKey & {
  version: typeof BNX_VERSION; schemaVersion: typeof BNX_SCHEMA_VERSION;
  rendererVersion: string; rendererHash: string; cssHash: string; contractHash: string; tokenSnapshot: WebsiteTokenSnapshot;
  semanticRole: string; layoutKey: string; sourceRefs: V2Source[]; notices: V2Notice[];
  reviewOnly: true; customerExportReady: false; approvalStatus: 'draft';
};
/** These rows may only come from the server review ledger; a successful match is NOT export authorization. */
export type V2TrustedReview = V2ApprovalKey & { state: 'approved' | 'rejected'; reviewerId: string; reviewedAt: string };

/** Deterministic object-key serialization; array order and exact renderer/CSS bytes are significant. */
export function canonicalV2Json(value: unknown): string {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalV2Json).join(',')}]`;
  if (value && typeof value === 'object') {
    const entries = Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    return `{${entries.map(([key, item]) => `${JSON.stringify(key)}:${canonicalV2Json(item)}`).join(',')}}`;
  }
  throw new Error('BNX_HASH_VALUE_UNSUPPORTED');
}

/** Artifact identity covers executable renderer identity, exact CSS, contracts, selected tokens and provenance. */
export async function createV2Artifact(input: V2ArtifactInput): Promise<V2Artifact> {
  const { family, variant } = findV2Pattern(input.patternId, input.variantId);
  const tokenSnapshot = createWebsiteTokenSnapshot(input.preset);
  if (typeof input.rendererVersion !== 'string' || !/^[a-zA-Z0-9._-]{1,80}$/.test(input.rendererVersion) || typeof input.rendererFingerprint !== 'string' || !input.rendererFingerprint.trim() || input.rendererFingerprint.length > 1_000_000) throw new Error('BNX_RENDERER_IDENTITY_REQUIRED');
  if (typeof input.css !== 'string' || !input.css.trim() || new TextEncoder().encode(input.css).length > 100_000) throw new Error('BNX_ARTIFACT_CSS_INVALID');
  const sourceRefs = getV2Sources(family.sourceIds), notices = getV2Notices(family.sourceIds);
  const sourceGraphHash = await sha256(canonicalV2Json(sourceRefs));
  const noticeBundleHash = await sha256(canonicalV2Json(notices));
  const rendererHash = await sha256(input.rendererFingerprint), cssHash = await sha256(input.css);
  const contractHash = await sha256(canonicalV2Json({ section: z.toJSONSchema(v2SectionSchema), page: v2PageJsonSchema, validation: v2ContractFingerprint() }));
  const descriptor = {
    version: BNX_VERSION, schemaVersion: BNX_SCHEMA_VERSION,
    pattern: { id: family.id, role: family.role, revision: family.revision, variant },
    contentSchema: z.toJSONSchema(patternContentSchema), mediaSchema: z.toJSONSchema(patternMediaSchema),
    contractHash, rendererVersion: input.rendererVersion,
    rendererHash, cssHash, tokenSnapshot, sourceGraphHash, noticeBundleHash,
    reviewOnly: true, customerExportReady: false,
  };
  const artifactHash = await sha256(canonicalV2Json(descriptor));
  return deepFreeze({
    version: BNX_VERSION, schemaVersion: BNX_SCHEMA_VERSION,
    patternId: family.id, variantId: variant.id, revision: family.revision, preset: input.preset,
    artifactHash, sourceGraphHash, noticeBundleHash, rendererVersion: input.rendererVersion, rendererHash, cssHash, contractHash,
    tokenSnapshot, semanticRole: family.role, layoutKey: variant.layoutKey, sourceRefs, notices,
    reviewOnly: true, customerExportReady: false, approvalStatus: 'draft',
  });
}

export function v2ApprovalKey(artifact: V2Artifact): V2ApprovalKey {
  return { patternId: artifact.patternId, variantId: artifact.variantId, revision: artifact.revision, preset: artifact.preset, artifactHash: artifact.artifactHash, sourceGraphHash: artifact.sourceGraphHash, noticeBundleHash: artifact.noticeBundleHash };
}
export function hasExactV2Review(artifact: V2Artifact, rows: readonly V2TrustedReview[]): boolean {
  const expected = canonicalV2Json(v2ApprovalKey(artifact));
  return rows.some(row => row.state === 'approved' && !!row.reviewerId && !!row.reviewedAt && canonicalV2Json({ patternId: row.patternId, variantId: row.variantId, revision: row.revision, preset: row.preset, artifactHash: row.artifactHash, sourceGraphHash: row.sourceGraphHash, noticeBundleHash: row.noticeBundleHash }) === expected);
}
/** Only server-owned review rows and completed source adapters may authorize a
 * production compilation. Callers must never populate rows from model args. */
export function assertV2ProductionReady(artifact?: V2Artifact, rows: readonly V2TrustedReview[] = []): void {
  if (!artifact || !hasExactV2Review(artifact, rows)) throw new Error('BNX_PATTERN_NOT_APPROVED');
  assertV2SourceAdaptersReady(artifact.sourceRefs.map(value => value.id));
}
