import type { Env } from '../env';
import { assert } from './errors';
import { sha256 } from './crypto';
import { DESIGN_FONT_CATALOG, DESIGN_FONT_PAIRS, createTypographySnapshot, typographySnapshotSchema, type TypographySnapshot } from '../contracts/design-typography';
import { materializeTypography, patchNodeTypography, addTypographyFontImports } from './typography-materialization';
import { patchCompiledHeaderTypography, projectCompiledHeaderTypography } from './header-typography';
export { projectCompiledHeaderTypography } from './header-typography';
import { designNodeHtml, type DesignScope, type DesignManifest } from '../modules/design-nodes';

export async function loadTypographySnapshot(env:Env,userId:string,projectId:string,kind:'version'|'candidate',sourceId:string,manifestHash?:string):Promise<TypographySnapshot|null>{
 const row=await env.DB.prepare('SELECT manifest_hash,profile_json FROM design_typography_snapshots WHERE source_kind=? AND source_id=? AND user_id=? AND project_id=?').bind(kind,sourceId,userId,projectId).first<{manifest_hash:string;profile_json:string}>();
 if(!row)return null;
 assert(!manifestHash||row.manifest_hash===manifestHash,'TYPOGRAPHY_SNAPSHOT_CONFLICT','字体设置与设计版本不一致',409);
 const parsed=typographySnapshotSchema.safeParse(JSON.parse(row.profile_json));assert(parsed.success,'TYPOGRAPHY_SNAPSHOT_INVALID','字体设置无法读取',503);return parsed.data;
}

/** Run within the same guarded batch that creates the immutable source. */
export function typographySnapshotStatement(db:D1Database,input:{kind:'version'|'candidate';sourceId:string;userId:string;projectId:string;manifestHash:string;profile:TypographySnapshot;now:string}){
 const profile=typographySnapshotSchema.parse(input.profile),table=input.kind==='version'?'design_versions':'design_candidates';
 return db.prepare(`INSERT INTO design_typography_snapshots(source_kind,source_id,user_id,project_id,manifest_hash,profile_json,created_at) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM ${table} WHERE id=? AND project_id=?) ON CONFLICT(source_kind,source_id) DO NOTHING`).bind(input.kind,input.sourceId,input.userId,input.projectId,input.manifestHash,JSON.stringify(profile),input.now,input.sourceId,input.projectId);
}

export function copyTypographySnapshotStatement(db:D1Database,input:{fromKind:'version'|'candidate';fromId:string;toKind:'version'|'candidate';toId:string;userId:string;projectId:string;manifestHash:string;now:string}){
 const table=input.toKind==='version'?'design_versions':'design_candidates';
 return db.prepare(`INSERT INTO design_typography_snapshots(source_kind,source_id,user_id,project_id,manifest_hash,profile_json,created_at) SELECT ?,?,user_id,project_id,?,profile_json,? FROM design_typography_snapshots WHERE source_kind=? AND source_id=? AND user_id=? AND project_id=? AND EXISTS(SELECT 1 FROM ${table} WHERE id=? AND project_id=?) ON CONFLICT(source_kind,source_id) DO NOTHING`).bind(input.toKind,input.toId,input.manifestHash,input.now,input.fromKind,input.fromId,input.userId,input.projectId,input.toId,input.projectId);
}

export function typographyOptions(snapshot:TypographySnapshot|null){
 return {version:'btf-1' as const,fonts:DESIGN_FONT_CATALOG.filter(f=>!f.legacy),pairs:[],selection:{headingId:snapshot?.heading?.id??'helvetica',bodyId:snapshot?.body?.id??'helvetica',customCount:snapshot?.overrides.length??0}};
}

export const isTypographyMutation=(properties:Record<string,unknown>)=>Object.keys(properties).some(k=>['headingFontId','bodyFontId','fontPairId','fontId','resetFontOverrides'].includes(k));

export async function patchTypographySelection(base:DesignManifest,scope:DesignScope,properties:Record<string,string|number>,previous:TypographySnapshot|null,requestKey:string){
 const keys=Object.keys(properties),manifest=JSON.parse(JSON.stringify(base)) as DesignManifest;
 if(scope.kind==='site'){
  assert(keys.length>0&&keys.every(k=>['headingFontId','bodyFontId','fontPairId','resetFontOverrides'].includes(k)),'TYPOGRAPHY_INPUT','整站字体参数无效');
  assert(keys.every(k=>k==='resetFontOverrides'?properties[k]===1:typeof properties[k]==='string'),'TYPOGRAPHY_INPUT','整站字体参数无效');
  assert(keys.every(k=>k==='resetFontOverrides'||k==='fontPairId'?k==='resetFontOverrides'||DESIGN_FONT_PAIRS.some(p=>p.id===properties[k]):DESIGN_FONT_CATALOG.some(f=>f.id===properties[k])),'TYPOGRAPHY_INPUT','请选择目录中可发布的字体');
  let profile=createTypographySnapshot(properties as {headingFontId?:string;bodyFontId?:string;fontPairId?:string},previous??undefined);
  if(properties.resetFontOverrides===1){
   for(const source of previous?.headerSources??[]){const template=manifest.templates.find(t=>t.id===source.templateId);assert(template,'TYPOGRAPHY_HEADER_SOURCE','页头模板不存在',409);const projected=projectCompiledHeaderTypography({...source},previous);assert(template.document.html===projected.html&&String(template.document.css??'')===projected.css,'TYPOGRAPHY_HEADER_CONFLICT','页头已变化，不能重置未确认的字体范围',409);template.document.css=source.css;}
   profile={...profile,overrides:[]};
  }
  const protectedTemplateIds=manifest.templates.filter(t=>t.type==='header'&&/\bbnh-site-header\b/.test(t.document.html)).map(t=>t.id);
  const result=materializeTypography(manifest,profile,{protectedTemplateIds,...(properties.resetFontOverrides===1?{clearedAnchors:(previous?.overrides??[]).map(o=>({templateId:o.templateId,anchor:o.anchor}))}:{})});
  assert(!result.issues.length,'TYPOGRAPHY_CONFLICT',result.issues.map(i=>typeof i==='string'?i:JSON.stringify(i)).join('\n'),409);
  return {manifest:result.manifest as DesignManifest,profile:result.snapshot,changes:result.changes};
 }
 assert(keys.length===1&&keys[0]==='fontId'&&typeof properties.fontId==='string','TYPOGRAPHY_INPUT','请选择此处字体');
 assert(properties.fontId==='inherit'||DESIGN_FONT_CATALOG.some(f=>f.id===properties.fontId),'TYPOGRAPHY_INPUT','请选择目录中可发布的字体');
 const selected=designNodeHtml(manifest,scope);
 const header=selected.template.type==='header'&&/\bbnh-site-header\b/.test(selected.template.document.html);
 if(header){
  const existing=previous?.overrides.find(o=>o.templateId===scope.templateId&&o.headerNodeKey===scope.nodeKey),anchor=existing?.anchor??'btf-local-'+(await sha256(requestKey+':'+scope.templateId+':'+scope.nodeKey)).slice(0,16);
  const result=patchCompiledHeaderTypography(selected.template,scope.nodeKey,properties.fontId,anchor,previous??createTypographySnapshot({}));selected.template.document.html=result.html;selected.template.document.css=result.css;return {manifest:addTypographyFontImports(manifest,result.snapshot),profile:result.snapshot,changes:{localOverrides:1}};
 }
 const existing=selected.node.attrs.find(a=>a.name==='class')?.value.split(/\s+/).find(c=>previous?.overrides.some(o=>o.templateId===scope.templateId&&o.anchor===c));
 const anchor=existing??'btf-local-'+(await sha256(requestKey+':'+scope.templateId+':'+scope.nodeKey)).slice(0,16);
 const result=patchNodeTypography(selected.template.document.html,{templateId:scope.templateId,startOffset:selected.start,endOffset:selected.end,fontId:properties.fontId,anchor},previous??createTypographySnapshot({}));
 assert(!result.issues.length,'TYPOGRAPHY_CONFLICT',result.issues.map(i=>typeof i==='string'?i:JSON.stringify(i)).join('\n'),409);
 selected.template.document.html=result.html;
 return {manifest:addTypographyFontImports(manifest,result.snapshot),profile:result.snapshot,changes:{localOverrides:1}};
}

/** No catalog re-resolution on replay. Authoring cannot replace saved choices. */
export function enforceTypographySnapshot(manifest:any,snapshot:TypographySnapshot|null){
 if(!snapshot)return manifest;
 const protectedTemplateIds=manifest.templates.filter((t:any)=>t.type==='header'&&/\bbnh-site-header\b/.test(t.document.html)).map((t:any)=>t.id),result=materializeTypography(manifest,snapshot,{protectedTemplateIds});
 assert(!result.issues.length,'TYPOGRAPHY_CONFLICT','请保留用户已设置字体的文字锚点与结构；'+result.issues.map(i=>typeof i==='string'?i:JSON.stringify(i)).join('\n'),409);
 return result.manifest;
}

export function typographyForStyle(styleId:string):TypographySnapshot{
 return createTypographySnapshot({headingFontId:'helvetica',bodyFontId:'helvetica'});
}
