﻿import { z } from 'zod';
import type { Env } from '../env';
import { assert } from './errors';

/** Frozen on a new workflow. This target never replaces its wallet budget. */
export const generationPolicySchema=z.object({
 version:z.literal('gp-1').default('gp-1'),
 pipeline:z.enum(['frame-first-1','frame-first-2']).default('frame-first-2'),
 imageQuality:z.enum(['low','medium']).default('low'),
 maxImages:z.number().int().min(1).max(8).default(8),
 imageConcurrency:z.number().int().min(1).max(4).default(3),
 costTargetMicros:z.number().int().positive().max(1_000_000_000).default(400_000),
 optionalReview:z.boolean().default(true),
 optionalReviewEstimateMicros:z.number().int().min(0).max(1_000_000).default(60_000),
 imageEstimation:z.enum(['image-estimate-v1','legacy']).default('image-estimate-v1'),
 /** Off by default. 'syntax-1' is the bnl-0 layout grammar and only runs for the owner account. */
 newSiteEngine:z.enum(['compose-1','compose-v2','syntax-1']).default('compose-v2'),
}).strict();
export type GenerationPolicy=z.infer<typeof generationPolicySchema>;
export const GENERATION_POLICY_KEY='ai.generation-policy.v1';
export async function loadGenerationPolicy(env:Env):Promise<GenerationPolicy>{
 const row=await env.DB.prepare('SELECT value_json FROM settings WHERE key=?').bind(GENERATION_POLICY_KEY).first<{value_json:string}>();
 let value:unknown={};try{if(row)value=JSON.parse(row.value_json);}catch{assert(false,'GENERATION_POLICY_INVALID','生成设置无效，请联系平台管理员',503);}
 const parsed=generationPolicySchema.safeParse(value);
 assert(parsed.success,'GENERATION_POLICY_INVALID','生成设置无效，请联系平台管理员',503);
 return parsed.data;
}
export function workflowGenerationPolicy(requirements:string):GenerationPolicy|null{
 const value=JSON.parse(requirements).generationPolicy;
 return value?generationPolicySchema.parse(value):null;
}
/** Optional work alone obeys the target. Required work can exceed it. */
export function canStartOptionalReview(policy:GenerationPolicy,settledMicros:number){
 return policy.optionalReview&&settledMicros+policy.optionalReviewEstimateMicros<=policy.costTargetMicros;
}
