import { verifiedTextPricing,type TextPricing } from '../modules/ai-billing';
/** New design capacity only. Never mutate the integration or a saved task. */
export const DESIGN_OUTPUT_TOKENS=24000;
export function effectiveDesignPricing<T extends TextPricing>(pricing:T,enabled:boolean):T{
 const effective=enabled?{...pricing,maxOutputTokens:DESIGN_OUTPUT_TOKENS}:{...pricing};
 verifiedTextPricing(effective);return effective;
}
