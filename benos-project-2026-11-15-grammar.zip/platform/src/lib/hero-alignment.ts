import type { DefaultTreeAdapterMap } from 'parse5';
import { assert } from './errors';
import { designNodeHtml, type DesignManifest, type DesignScope } from '../modules/design-nodes';

type Element=DefaultTreeAdapterMap['element'];
const attr=(node:Element,key:string)=>node.attrs.find(a=>a.name===key)?.value??'';
const contains=(outer:Element,inner:Element):boolean=>outer===inner||outer.childNodes.some(n=>'tagName' in n&&contains(n,inner));
const escape=(text:string)=>text.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');

/** Explicit manual centering, never an automatic guess about an arbitrary hero.
 * Only inline alignment/spacing inside the selected span changes. Asset size,
 * fit, content, global CSS, and all other templates remain byte-identical. */
export function patchHeroAlignment(input:DesignManifest,scope:DesignScope):DesignManifest {
 assert(scope.kind==='node','DESIGN_HERO_ALIGNMENT','请选择需要居中的首屏区块',422);
 const manifest=structuredClone(input),target=designNodeHtml(manifest,scope),root=target.node,rows:Element[]=[];
 const stack=[root];while(stack.length){const node=stack.pop()!;rows.push(node);assert(rows.length<=2000,'DESIGN_HERO_ALIGNMENT','该区块过大，请交给 AI 审查',422);for(const child of node.childNodes)if('tagName' in child)stack.push(child);}
 const headings=rows.filter(node=>node.tagName==='h1'),images=rows.filter(node=>node.tagName==='img');
 assert(['section','article','div','main'].includes(root.tagName)&&headings.length===1&&images.length===1,'DESIGN_HERO_ALIGNMENT','此操作只适用于单张主图的首屏，其他构图请交给 AI 审查',422);
 const image=images[0],frame=rows.find(node=>/^bnf-image-[\w-]+$/.test(attr(node,'id'))&&contains(node,image));
 assert(frame&&frame!==root,'DESIGN_HERO_ALIGNMENT','未找到独立主图框，请交给 AI 审查',422);
 const patches=new Map<Element,string>();patches.set(frame,'margin-left:auto !important;margin-right:auto !important;');
 const figure=rows.find(node=>node.tagName==='figure'&&contains(node,frame));
 if(figure)patches.set(figure,'margin-top:clamp(24px,3vw,40px) !important;');
 let copy:Element|undefined;
 for(let node:Element|undefined=headings[0];node&&node!==root;node=node.parentNode&&'tagName' in node.parentNode?node.parentNode:undefined){
  if(attr(node,'class').split(/\s+/).includes('bnf-order-group')&&!contains(node,image)){copy=node;break;}
 }
 if(copy)patches.set(copy,'align-items:center !important;');
 else for(const node of rows)if(attr(node,'class').split(/\s+/).includes('bnf-actions'))patches.set(node,'align-self:center !important;justify-content:center !important;');
 const edits=[...patches].map(([node,css])=>{
  const location=node.sourceCodeLocation!,style=location.attrs?.style,value=escape(attr(node,'style').replace(/;?\s*$/,';')+css);
  return style?{start:style.startOffset,end:style.endOffset,text:'style="'+value+'"'}:{start:location.startTag!.endOffset-1,end:location.startTag!.endOffset-1,text:' style="'+value+'"'};
 }).sort((a,b)=>b.start-a.start);
 let html=target.template.document.html;for(const edit of edits)html=html.slice(0,edit.start)+edit.text+html.slice(edit.end);
 target.template.document.html=html;return manifest;
}
