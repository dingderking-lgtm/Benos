﻿// The bnl-0 grammar as a workflow engine. A task frozen to `site-grammar-1` offers one tool; the
// submission is compiled into a complete AACMS site package, checked against the platform's importer
// contract and against the owner's approval, and then handed to the normal propose_files path so the
// canvas, candidate saving and freeze all work unchanged.
import { z } from 'zod';
import type { Env } from '../env';
import { sha256 } from './crypto';
import { GRAMMAR_IDENTITY } from '../design-system/grammar/identity';
import { GRAMMAR_GENERATION_VERSION, grammarRepairBrief, grammarTool, type GrammarPlan } from '../design-system/grammar/generation';
import { compileSite } from '../design-system/grammar/site';
import { compileGrammarManifest, type GrammarManifestAsset } from '../design-system/grammar/manifest';
import { bindingFrames, type GrammarBindingFrame } from '../design-system/grammar/frames';
import { bindGrammarImages, type GrammarImageBinding } from '../design-system/grammar/bind';
import { validateSiteManifest } from '../modules/template-contract';
import type { GrammarBrand, Issue } from '../design-system/grammar/brand';
import { contrastReport, isDirection, isIndustry, paletteTokens } from '../design-system/grammar/palettes';
import { assertGrammarApproved, brandRangeIssues, readGrammarApprovals } from './grammar-approvals';

/** Frozen into `requirements_json.designPipelineVersion` and `siteCompositionVersion`. */
export const GRAMMAR_PIPELINE_VERSION = 'site-grammar-1' as const;

export type GrammarWorkflowPlan = GrammarPlan & { createdAt: string };
export { bindGrammarImages };
export type { GrammarImageBinding };

/** A new site frozen to the grammar engine offers only its own composition tool. */
export function canComposeSiteGrammar(w: { requirements_json: string; base_manifest_json: string | null; scope_json: string }) {
  const r = JSON.parse(w.requirements_json);
  return !w.base_manifest_json && JSON.parse(w.scope_json).kind === 'site' && r.siteCompositionVersion === GRAMMAR_PIPELINE_VERSION && r.grammarPlan?.version === GRAMMAR_GENERATION_VERSION;
}

export const grammarComposeSchema = z.object({
  planHash: z.string().regex(/^[a-f0-9]{64}$/),
  /** The chosen palette. Sending colours is a schema violation, not a preference. */
  palette: z.object({ industry: z.string().min(1).max(40), direction: z.string().min(1).max(20) }).strict(),
  pages: z.array(z.object({ key: z.string().regex(/^[a-z][a-z0-9-]{0,31}$/), title: z.string().max(120).optional(), sections: z.array(z.record(z.string(), z.unknown())).min(3).max(10) }).strict()).min(1).max(12),
  /** Picture slots the page wants illustrated, addressed the way the page is written. */
  images: z.array(z.object({
    page: z.string().regex(/^[a-z][a-z0-9-]{0,31}$/),
    section: z.string().regex(/^[a-z][a-z0-9-]{0,23}$/),
    index: z.number().int().min(1).max(6).default(1),
    purpose: z.string().trim().min(2).max(120),
    prompt: z.string().trim().min(10).max(1500),
  }).strict()).max(6).default([]),
}).strict();

export function grammarFailureMessage(issues: readonly Issue[]): string {
  const errors = issues.filter(issue => issue.level === 'error');
  return (errors.length ? errors : issues).slice(0, 12).map(issue => `${issue.path}: ${issue.message}`).join('\n').slice(0, 1800);
}

export type GrammarPackage = {
  manifest: Record<string, unknown>;
  frames: GrammarBindingFrame[];
  pages: { key: string; path: string; templateId: number; frames: string[] }[];
  manifestDigest: string;
  palette: { industry: string; direction: string; tokens: ReturnType<typeof paletteTokens> };
  /** Picture slots the submission asked to illustrate, already validated against the compiled frames. */
  images: Array<{ frameId: string; purpose: string; prompt: string }>;
  stats: { pages: number; sections: number; cssBytes: number };
};

/** Compiles one submission into a shippable package. Nothing is written: the caller stores it. */
export async function compileGrammarPackage(
  env: Env,
  plan: GrammarWorkflowPlan,
  submission: unknown,
  options: { assets: GrammarManifestAsset[]; siteName: string; siteSlug: string },
): Promise<{ ok: true; package: GrammarPackage } | { ok: false; code: string; message: string; issues: Issue[] }> {
  const parsed = grammarComposeSchema.safeParse(submission);
  const issues: Issue[] = [];
  if (!parsed.success) {
    const detail = parsed.error.issues.slice(0, 4).map(issue => `${issue.path.join('.')} ${issue.message}`).join('; ');
    return { ok: false, code: 'GRAMMAR_SUBMISSION_INVALID', message: '组合数据格式不正确：' + detail, issues: [{ level: 'error', path: 'submission', message: detail }] };
  }
  const input = parsed.data;
  const { planHash, ...frozen } = plan;
  if (await sha256(JSON.stringify(frozen)) !== planHash) return { ok: false, code: 'GRAMMAR_PLAN_CHANGED', message: '设计计划已变化，请重新开始本次设计', issues };
  if (input.planHash !== planHash) return { ok: false, code: 'GRAMMAR_PLAN_CHANGED', message: '提交的计划编号与本次任务不一致', issues };
  for (const page of plan.pages) if (!input.pages.some(submitted => submitted.key === page.key)) {
    return { ok: false, code: 'GRAMMAR_PAGES_MISSING', message: `缺少页面 ${page.key}，计划里的每一页都要提交`, issues: [{ level: 'error', path: 'pages', message: `page ${page.key} is missing` }] };
  }

  // The owner's approval is the licence to build a production site with this exact grammar.
  const approvals = await readGrammarApprovals(env.DB);
  const approval = assertGrammarApproved(approvals);
  if (!isIndustry(input.palette.industry) || !isDirection(input.palette.direction)) return { ok: false, code: 'GRAMMAR_PALETTE_UNKNOWN', message: '请从设计计划给出的行业与方向里选择配色', issues };
  const tokens = paletteTokens(input.palette.industry, input.palette.direction);
  // The derived palette must clear the owner's contrast rules before a page is built from it.
  const unreadable = contrastReport(tokens).filter(check => !check.ok);
  if (unreadable.length) return { ok: false, code: 'GRAMMAR_PALETTE_UNREADABLE', message: '配色对比度不合格：' + unreadable.map(check => check.pair + ' ' + check.ratio).join('；'), issues };
  const ranges = brandRangeIssues(tokens.brand as GrammarBrand, approval.brandRanges);
  if (ranges.length) return { ok: false, code: 'GRAMMAR_BRAND_OUTSIDE_RANGE', message: '配色取值超出已批准范围：' + grammarFailureMessage(ranges), issues: ranges };

  const images = Object.fromEntries(plan.images.map(image => [image.id, { src: image.src, w: image.w, h: image.h, alt: image.alt }]));
  const pages = input.pages.map(page => {
    const planned = plan.pages.find(entry => entry.key === page.key)!;
    return { key: page.key, path: planned.path, title: page.title || planned.title, sections: page.sections as never };
  });
  const site = compileSite({ brand: tokens.brand as unknown as GrammarBrand, pages, images }, {});
  if (!site.ok) return { ok: false, code: 'GRAMMAR_SITE_INVALID', message: '页面没通过校验：\n' + grammarFailureMessage(site.issues), issues: site.issues };

  const built = compileGrammarManifest(
    { brand: tokens.brand as unknown as GrammarBrand, pages, images },
    { name: options.siteName, slug: options.siteSlug, createdAt: plan.createdAt, assets: options.assets },
  );
  if (!built.ok || !built.manifest) return { ok: false, code: 'GRAMMAR_PACKAGE_INVALID', message: '站点包没通过平台导入校验：\n' + grammarFailureMessage(built.issues), issues: built.issues };
  const frames = bindingFrames(site, { containerWidth: tokens.brand.space.container });
  // A picture request names a slot the way the page is written: page, section, and the n-th figure in
  // that section. A wrong address is answered with the slots the page really has.
  // A pending frame without a generation request would ship as an empty box.
  const pending = site.pages.flatMap(page => page.stats.pendingFrames.map(frameId => ({ page: page.key, frameId })));
  const unrequested = pending.filter(frame => !(input.images ?? []).some(wanted => {
    const page = site.pages.find(entry => entry.key === wanted.page);
    const slot = page?.frames.find(entry => entry.sectionId === wanted.section && entry.index === wanted.index);
    return slot?.frameId === frame.frameId;
  }));
  if (unrequested.length) return { ok: false, code: 'GRAMMAR_IMAGE_REQUEST_MISSING', message: '这些图位声明了 pending 但没有提交配图请求：' + unrequested.map(frame => frame.page + '/' + frame.frameId).join('、'), issues };
  const resolvedImages: Array<{ frameId: string; purpose: string; prompt: string }> = [];
  for (const wanted of input.images ?? []) {
    const page = site.pages.find(entry => entry.key === wanted.page);
    const frame = page?.frames.find(entry => entry.sectionId === wanted.section && entry.index === wanted.index);
    if (!frame) {
      const available = site.pages.flatMap(entry => entry.frames.map(item => entry.key + '/' + item.sectionId + '/' + item.index)).join('、') || '（这一站没有图位：先用 figure / media / cover 写出图位，再给它配图）';
      return { ok: false, code: 'GRAMMAR_IMAGE_FRAME_UNKNOWN', message: '页面 ' + wanted.page + ' 的区段 ' + wanted.section + ' 没有第 ' + wanted.index + ' 张图。现有图位：' + available, issues };
    }
    resolvedImages.push({ frameId: frame.frameId, purpose: wanted.purpose, prompt: wanted.prompt });
  }
  if (frames.issues.length) return { ok: false, code: 'GRAMMAR_FRAMES_INVALID', message: '图片帧不完整：\n' + grammarFailureMessage(frames.issues), issues: frames.issues };
  return {
    ok: true,
    package: {
      manifest: built.manifest, frames: frames.frames, pages: built.pages,
      manifestDigest: await sha256(JSON.stringify(built.manifest)),
      palette: { industry: input.palette.industry, direction: input.palette.direction, tokens },
      images: resolvedImages,
      stats: { pages: site.pages.length, sections: site.pages.reduce((sum, page) => sum + page.stats.sections, 0), cssBytes: Math.max(...site.pages.map(page => page.stats.cssBytes)) },
    },
  };
}

export type GrammarSnapshot = { version: typeof GRAMMAR_PIPELINE_VERSION; identity: string; manifestDigest: string; templates: Array<{ templateId: number; header: boolean; html: string; css: string }> };

/** Byte-freeze: the exact templates that were shown to the customer, kept with the task. */
export function grammarSnapshot(manifest: any): GrammarSnapshot {
  return {
    version: GRAMMAR_PIPELINE_VERSION, identity: GRAMMAR_IDENTITY.digest, manifestDigest: '',
    templates: (manifest.templates ?? []).map((template: any) => ({ templateId: template.id, header: template.type === 'header' || template.type === 'footer', html: String(template.document?.html ?? ''), css: String(template.document?.css ?? '') })),
  };
}

export function freezeGrammarComposition(manifest: any, snapshot: GrammarSnapshot): GrammarSnapshot {
  return { ...snapshot, ...grammarSnapshot(manifest), identity: snapshot.identity };
}

/** Any drift between the frozen templates and the manifest is a refusal, never a silent update. */
export function validateGrammarComposition(manifest: any, snapshot: GrammarSnapshot | null | undefined): Array<{ code: string; message: string }> {
  const issues: Array<{ code: string; message: string }> = [];
  if (!snapshot) return [{ code: 'GRAMMAR_SNAPSHOT_MISSING', message: '缺少冻结的页面字节，请重新提交整站。' }];
  if (snapshot.identity !== GRAMMAR_IDENTITY.digest) issues.push({ code: 'GRAMMAR_IDENTITY_CHANGED', message: '版式语法引擎已更新，本任务需要重新提交。' });
  const current = grammarSnapshot(manifest).templates;
  if (current.length !== snapshot.templates.length) issues.push({ code: 'GRAMMAR_TEMPLATE_COUNT', message: '模板数量与冻结快照不一致。' });
  for (const template of snapshot.templates) {
    const now = current.find(entry => entry.templateId === template.templateId);
    if (!now || now.html !== template.html || now.css !== template.css) issues.push({ code: 'GRAMMAR_OUTPUT_CHANGED', message: `模板 ${template.templateId} 与冻结快照不一致，请重新组合整站。` });
  }
  const validation = validateSiteManifest(manifest);
  for (const issue of validation.issues) if (issue.severity !== 'warning') issues.push({ code: issue.code, message: issue.message });
  return issues;
}

export { grammarTool as grammarComposeTool };