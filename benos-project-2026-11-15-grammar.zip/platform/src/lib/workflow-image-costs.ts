import type { Env } from '../env';
import { sha256 } from './crypto';

export type WorkflowImageCosts = { consumed:number; held:number; estimated:number; pendingAdjustment:number };
type OwnedWorkflow = { id:string; user_id:string };

/** Ledger projection only: does not reconcile receipts, release holds or change a task. */
export async function workflowImageTotalsMany(env:Pick<Env,'DB'>, workflows:readonly OwnedWorkflow[]):Promise<Map<string,WorkflowImageCosts>> {
 if(!workflows.length)return new Map();
 const requested=await Promise.all(workflows.map(async w=>({...w,prefix:'wfimg_'+(await sha256(w.id)).slice(0,20)+'_'})));
 const rows=await env.DB.prepare(`WITH requested AS (
 SELECT json_extract(value,'$.id') id,json_extract(value,'$.user_id') user_id,json_extract(value,'$.prefix') prefix FROM json_each(?)
 ) SELECT requested.id,
 COALESCE(SUM(CASE WHEN r.state IN ('settled','released') THEN r.actual_micros+CASE WHEN c.state='applied' THEN c.delta_micros ELSE 0 END ELSE 0 END),0) consumed,
 COALESCE(SUM(CASE WHEN r.state IN ('reserved','dispatching','uncertain') THEN r.amount_micros ELSE 0 END),0) held,
 COALESCE(SUM(CASE WHEN e.job_id IS NOT NULL AND c.job_id IS NULL THEN e.estimated_micros ELSE 0 END),0) estimated,
 COALESCE(SUM(CASE WHEN c.state='pending' THEN c.delta_micros ELSE 0 END),0) pendingAdjustment
 FROM requested LEFT JOIN image_jobs j ON j.user_id=requested.user_id AND substr(j.request_key,1,length(requested.prefix))=requested.prefix
 LEFT JOIN api_reservations r ON r.id=j.reservation_id
 LEFT JOIN image_estimated_settlements e ON e.job_id=j.id
 LEFT JOIN image_cost_corrections c ON c.job_id=j.id GROUP BY requested.id`).bind(JSON.stringify(requested)).all<WorkflowImageCosts&{id:string}>();
 return new Map(rows.results.map(({id,...cost})=>[id,cost]));
}

export async function workflowImageTotals(env:Pick<Env,'DB'>,workflow:OwnedWorkflow):Promise<WorkflowImageCosts> {
 return (await workflowImageTotalsMany(env,[workflow])).get(workflow.id)!;
}
