import type { Env } from '../env';
import type { GenerationPolicy } from './generation-policy';

/** Which engine writes a new site. `syntax-1` is the bnl-0 layout grammar (design-system/grammar). */
export type SiteEngine = 'compose-1' | 'compose-v2' | 'syntax-1';
export const SITE_ENGINES: readonly SiteEngine[] = ['compose-1', 'compose-v2', 'syntax-1'];

/** The grammar engine is switched on by policy and then limited to the owner account: it is the
 *  newest and least proven of the three, and its approval model still has to be decided. Anything
 *  else falls back to the engine that was live before, so flipping the flag off is a rollback. */
export function resolveSiteEngine(policy: Pick<GenerationPolicy, 'newSiteEngine'>, role: string | null | undefined): SiteEngine {
  const wanted = policy.newSiteEngine as SiteEngine;
  if (wanted !== 'syntax-1') return wanted;
  return role === 'owner' ? 'syntax-1' : 'compose-v2';
}

/** Reads the frozen policy and the caller's role, and answers with the engine this task will use. */
export async function siteEngineFor(env: Env, userId: string, policy: GenerationPolicy): Promise<SiteEngine> {
  if (policy.newSiteEngine !== 'syntax-1') return resolveSiteEngine(policy, null);
  const row = await env.DB.prepare('SELECT role FROM users WHERE id=?').bind(userId).first<{ role: string }>();
  return resolveSiteEngine(policy, row?.role ?? null);
}
