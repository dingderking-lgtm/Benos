/** Dispatch only after the lease check. Already dispatched jobs always finish.
 * A failed lease check stops the queue and is thrown after those jobs settle. */
export async function boundedImageQueue<T>(count:number,concurrency:number,beforeDispatch:()=>Promise<void>,dispatch:(index:number)=>Promise<T>):Promise<PromiseSettledResult<T>[]>{
 if(!Number.isSafeInteger(count)||count<0||!Number.isSafeInteger(concurrency)||concurrency<1||concurrency>4)throw new RangeError('Invalid image queue bounds');
 const results:PromiseSettledResult<T>[]=new Array(count);let next=0,stopped=false,stopReason:unknown;
 const run=async()=>{
  while(!stopped){
   const index=next++;if(index>=count)return;
   try{await beforeDispatch();}catch(error){stopped=true;stopReason??=error;return;}
   if(stopped)return;
   try{results[index]={status:'fulfilled',value:await dispatch(index)};}
   catch(reason){results[index]={status:'rejected',reason};}
  }
 };
 await Promise.all(Array.from({length:Math.min(count,concurrency)},run));
 if(stopped)throw stopReason;
 return results;
}
