import { z } from 'zod';
import type { Env } from '../env';
import { assert } from './errors';

/** Separate from billing/image policy. Only a newly created account site reads
 * this setting; persisted tasks never gain a presentation compiler implicitly. */
export const PRESENTATION_POLICY_KEY = 'ai.presentation-policy.v1';
export const presentationPolicySchema = z.object({
  version: z.literal('pp-1').default('pp-1'),
  mode: z.enum(['orderly', 'legacy']).default('orderly'),
  fixedHeaderMenus: z.boolean().default(true),
  sampleContent: z.enum(['off', 'marked']).default('off'),
  fontLibrary: z.enum(['deferred', 'hosted']).default('deferred'),
}).strict();
export type PresentationPolicy = z.infer<typeof presentationPolicySchema>;
export const presentationCapabilities = Object.freeze({
  fixedHeaderMenus: true, markedSamples: false, hostedFonts: false,
  dynamicSubmenuDisclosure: false, popover: false,
});
export function assertPresentationCapabilities(policy: PresentationPolicy) {
  assert(policy.sampleContent === 'off', 'PRESENTATION_CAPABILITY_UNAVAILABLE', '带标记示例内容将在区块库与发布确认接入后开放；当前保持关闭', 409);
  assert(policy.fontLibrary === 'deferred', 'PRESENTATION_CAPABILITY_UNAVAILABLE', '托管字体需要 AACMS 字体库契约与发版，当前使用本机字体', 409);
}
export async function loadPresentationPolicy(env: Env): Promise<PresentationPolicy> {
  const row = await env.DB.prepare('SELECT value_json FROM settings WHERE key=?').bind(PRESENTATION_POLICY_KEY).first<{value_json:string}>();
  let raw: unknown = {};
  try { if (row) raw = JSON.parse(row.value_json); } catch { assert(false, 'PRESENTATION_POLICY_INVALID', '页面生成设置无效', 503); }
  const parsed = presentationPolicySchema.safeParse(raw);
  assert(parsed.success, 'PRESENTATION_POLICY_INVALID', '页面生成设置无效', 503);
  assertPresentationCapabilities(parsed.data);
  return parsed.data;
}
