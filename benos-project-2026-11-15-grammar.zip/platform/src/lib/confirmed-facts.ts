/**
 * Facts the customer typed themselves before generation (the intake questions in the
 * workspace). They travel inside the request text under a fixed heading so that an
 * ordinary message, a retry and a stored conversation all carry the same evidence.
 * Only these values may become contact links; nothing here is inferred or invented.
 */
export const CONFIRMED_FACTS_HEADING = '【已确认的真实信息】';
export type ConfirmedContact = { factRef: 'phone' | 'email' | 'address'; label: string; href: string };
export type ConfirmedFacts = { company?: string; intro?: string; founded?: string; city?: string; products?: string; action?: string; audience?: string; objections?: string; phone?: string; email?: string; address?: string; hours?: string; messaging?: string };

const KEYS: Record<string, keyof ConfirmedFacts> = {
  '公司名称': 'company', '公司介绍': 'intro', '成立时间': 'founded', '所在城市': 'city', '主要产品或服务': 'products',
  '希望访客做什么': 'action', '目标客户': 'audience', '客户常见顾虑': 'objections',
  '联系电话': 'phone', '联系邮箱': 'email', '公司地址': 'address', '工作时间': 'hours', '微信或WhatsApp': 'messaging',
};

export function parseConfirmedFacts(request: string): ConfirmedFacts | null {
  const start = request.indexOf(CONFIRMED_FACTS_HEADING);
  if (start < 0) return null;
  const facts: ConfirmedFacts = {};
  for (const line of request.slice(start + CONFIRMED_FACTS_HEADING.length).split(/\r?\n/)) {
    const match = line.match(/^\s*([^：:]{2,16})[：:]\s*(.+?)\s*$/);
    if (!match) { if (line.trim() && Object.keys(facts).length) break; continue; }
    const key = KEYS[match[1].trim()];
    if (key && !facts[key]) facts[key] = match[2].slice(0, 600);
  }
  return Object.keys(facts).length ? facts : null;
}

/** Links are built by the server from the typed value; a malformed value stays plain text. */
export function confirmedContacts(facts: ConfirmedFacts | null): ConfirmedContact[] {
  if (!facts) return [];
  const out: ConfirmedContact[] = [];
  const phone = facts.phone?.trim();
  if (phone && /^[+\d][\d\s()./-]{4,28}$/.test(phone)) out.push({ factRef: 'phone', label: phone.slice(0, 80), href: 'tel:' + phone.replace(/[^\d+]/g, '') });
  const email = facts.email?.trim();
  if (email && /^[^\s@<>"'`\\]{1,64}@[a-z0-9.-]{1,180}\.[a-z]{2,24}$/i.test(email)) out.push({ factRef: 'email', label: email.slice(0, 80), href: 'mailto:' + email });
  return out;
}
