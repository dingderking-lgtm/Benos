/**
 * Rich text of a blog post: a small, fixed vocabulary of HTML written by the admin editor.
 *
 * Whatever arrives is rebuilt from scratch — only the tags and attributes listed here are ever written out, every
 * tag is closed, and all text is escaped — so the result can be placed into a public page as it is. It runs when a
 * post is saved and again when it is shown. No scripts, styles, frames, forms or event attributes survive; links and
 * images may only point to this site (`/…`) or to an `https:` address (links also `mailto:`).
 */
const BLOCKS=new Set(['p','h2','h3','h4','ul','ol','li','blockquote','pre','figure','figcaption']);
const INLINE=new Set(['strong','em','u','s','code','a']);
const VOID=new Set(['br','hr','img']);
const RENAME:Record<string,string>={b:'strong',i:'em',strike:'s',del:'s',h1:'h2',h5:'h4',h6:'h4',div:'p'};
/** Dropped together with everything inside them. */
const OPAQUE=new Set(['script','style','iframe','object','embed','svg','math','template','noscript','textarea','title','head','select','button','form','video','audio','canvas']);
const NAMED:Record<string,string>={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:' '};

function decode(value:string){
 return value.replace(/&(#x[0-9a-f]{1,6}|#\d{1,7}|[a-z]{2,8});?/gi,(whole,name:string)=>{
  if(name[0]==='#'){const code=name[1].toLowerCase()==='x'?parseInt(name.slice(2),16):parseInt(name.slice(1),10);return Number.isFinite(code)&&code>0&&code<=0x10ffff?String.fromCodePoint(code):'';}
  return NAMED[name.toLowerCase()]??whole;
 });
}
const escapeText=(value:string)=>value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const escapeAttribute=(value:string)=>escapeText(value).replace(/"/g,'&quot;');
function safeAddress(raw:string,link:boolean):string|null{
 const value=decode(raw).trim();
 if(!value||value.length>2000||/[\\\x00-\x20\x7f]/.test(value))return null;
 if(/^\/(?!\/)/.test(value))return value;
 if(link&&/^mailto:[^\s<>"']{3,320}$/i.test(value))return value;
 try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password?value:null;}catch{return null;}
}
function attributes(source:string){
 const found:Record<string,string>={};
 for(const match of source.matchAll(/([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*(?:=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g))found[match[1].toLowerCase()]??=match[2]??match[3]??match[4]??'';
 return found;
}

export function sanitizeRichText(input:string):string{
 const source=String(input??'').slice(0,400_000),open:string[]=[];let out='',skip='';
 const close=(name:string)=>{const at=open.lastIndexOf(name);if(at<0)return;while(open.length>at)out+=`</${open.pop()}>`;};
 for(const token of source.matchAll(/<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<![^>]*>|<\/?([a-zA-Z][a-zA-Z0-9]*)\b((?:"[^"]*"|'[^']*'|[^>"'])*)>|[^<]+|</g)){
  const whole=token[0],tag=token[1]?.toLowerCase();
  if(skip){if(tag===skip&&whole[1]==='/')skip='';continue;}
  if(!tag){if(whole[0]!=='<'||whole==='<')out+=escapeText(decode(whole));continue;}
  const closing=whole[1]==='/',name=RENAME[tag]??tag;
  if(OPAQUE.has(tag)){if(!closing&&!/\/\s*>$/.test(whole))skip=tag;continue;}
  if(closing){if(BLOCKS.has(name)||INLINE.has(name))close(name);continue;}
  if(VOID.has(name)){
   if(name==='img'){
    const given=attributes(token[2]??''),src=safeAddress(given.src??'',false);if(!src)continue;
    out+=`<img src="${escapeAttribute(src)}" alt="${escapeAttribute(decode(given.alt??'').slice(0,300))}" loading="lazy">`;
   }else out+=`<${name}>`;
   continue;
  }
  if(BLOCKS.has(name)){
   // A paragraph or heading cannot hold another block: the one that is open ends here.
   if(name!=='li'&&name!=='figcaption')for(const inner of ['p','h2','h3','h4'])if(open.includes(inner))close(inner);
   if(name==='li'&&open.lastIndexOf('li')>Math.max(open.lastIndexOf('ul'),open.lastIndexOf('ol')))close('li');
   open.push(name);out+=`<${name}>`;continue;
  }
  if(INLINE.has(name)){
   if(open.length>60)continue;
   if(name==='a'){
    const href=safeAddress(attributes(token[2]??'').href??'',true);if(!href)continue;
    close('a');open.push('a');out+=`<a href="${escapeAttribute(href)}"${href[0]==='/'?'':' target="_blank" rel="noopener noreferrer"'}>`;
   }else{open.push(name);out+=`<${name}>`;}
  }
  // Any other tag is left out; what it contains stays.
 }
 while(open.length)out+=`</${open.pop()}>`;
 return out.replace(/<(p|h2|h3|h4|li|blockquote|figcaption|strong|em|u|s|code|a(?: [^>]*)?)>\s*<\/(?:p|h2|h3|h4|li|blockquote|figcaption|strong|em|u|s|code|a)>/g,(whole,start:string)=>start==='li'?whole:'').trim();
}
/** The words of a rich text, for summaries and search-engine descriptions. */
export function richTextToPlain(html:string):string{
 return decode(String(html??'').replace(/<(?:br|\/p|\/h[2-4]|\/li|\/blockquote|\/pre|\/figcaption|hr)[^>]*>/gi,'\n').replace(/<[^>]*>/g,'')).replace(/[ \t ]+/g,' ').replace(/\s*\n\s*/g,'\n').trim();
}
