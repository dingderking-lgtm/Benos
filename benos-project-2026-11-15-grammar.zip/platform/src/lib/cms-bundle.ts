import { assert,AppError } from './errors';
import { base64url,randomToken,sha256,constantTimeEqual } from './crypto';

export const CMS_BUNDLE_PROTOCOL='BENOS-CMS-BUNDLE-V2';
export const CMS_BUNDLE_CHUNK_BYTES=1048576;
export type CmsBundleFile={file:string;size:number;sha256:string};
export type CmsBundleMetadata={schemaVersion:2;bundleId:string;purpose:'preview'|'publish';projectId:string;versionId:string;expiresAt:number;manifest:CmsBundleFile;assets:CmsBundleFile[]};
export type CmsBundleState={protocol:'benos-bundle-v2';bundleId:string;siteId:string;purpose:'preview'|'publish';projectId:string;versionId:string;state:'receiving'|'sealed'|'discarded'|'expired';expiresAt:number;expired:boolean;pinned:boolean;chunkBytes:number;zipBytes:number;zipSha256:string|null;nativeValidated:false;files:Array<CmsBundleFile&{received:number}>};
export type CmsBundleCredentials={url:string;siteId:string;keyId:string;secret:string};
const encoder=new TextEncoder();
function publicEndpoint(value:string){let url:URL;try{url=new URL(value);}catch{throw new AppError('CMS_BUNDLE_URL_INVALID','CMS 分块连接地址无效',422);}const host=url.hostname.toLowerCase();assert(url.protocol==='https:'&&!url.username&&!url.password&&!url.search&&!url.hash&&(!url.port||url.port==='443')&&host.includes('.')&&!/^[\d.]+$/.test(host)&&!host.includes(':')&&!/(^|\.)(localhost|local|internal|lan|test|invalid|example)$/.test(host),'CMS_BUNDLE_URL_INVALID','CMS 分块连接必须使用公开域名的标准 HTTPS 地址',422);}
async function hmac(secret:string,value:string){assert(encoder.encode(secret).byteLength>=32,'CMS_BUNDLE_CONFIGURATION_INVALID','CMS 连接签名配置无效',503);const key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return base64url(new Uint8Array(await crypto.subtle.sign('HMAC',key,encoder.encode(value))));}
/** Bounded binary envelope. No base64 copy of uploaded resources. */
export async function encodeCmsBundleChunk(bundleId:string,file:string,offset:number,bytes:Uint8Array){
 assert(/^bundle_[a-f0-9]{32}$/.test(bundleId)&&(file==='manifest.json'||/^assets\/[0-9]{1,2}\.(jpg|jpeg|png|webp|gif|svg|pdf)$/.test(file))&&Number.isSafeInteger(offset)&&offset>=0&&offset%CMS_BUNDLE_CHUNK_BYTES===0&&bytes.length>0&&bytes.length<=CMS_BUNDLE_CHUNK_BYTES,'CMS_BUNDLE_CHUNK_INVALID','CMS 资源分块无效',422);
 const metadata=encoder.encode(JSON.stringify({operation:'bundle-chunk',bundleId,file,offset,size:bytes.length,sha256:await sha256(bytes)}));assert(metadata.length<=4096,'CMS_BUNDLE_CHUNK_INVALID','CMS 分块元数据超限',422);
 const frame=new Uint8Array(8+metadata.length+bytes.length);frame.set(encoder.encode('BNB2'));new DataView(frame.buffer).setUint32(4,metadata.length,false);frame.set(metadata,8);frame.set(bytes,8+metadata.length);return frame;
}
export async function signCmsBundleRequest(credentials:CmsBundleCredentials,raw:Uint8Array,requestKey:string,binary=false,now=Date.now()){
 const url=new URL(credentials.url);assert(!url.search&&!url.hash&&/^\/[a-zA-Z0-9/_-]+\.php$/.test(url.pathname),'CMS_BUNDLE_URL_INVALID','CMS 分块地址无效',422);
 assert(/^[a-zA-Z0-9_-]{8,160}$/.test(requestKey),'CMS_BUNDLE_REQUEST_KEY_INVALID','CMS 分块请求编号无效',422);
 const timestamp=String(Math.floor(now/1000)),nonce=randomToken(18),canonical=[CMS_BUNDLE_PROTOCOL,credentials.keyId,credentials.siteId,timestamp,nonce,'POST',url.pathname,await sha256(raw),requestKey].join('\n');
 return {'X-Benos-Key-Id':credentials.keyId,'X-Benos-Site-Id':credentials.siteId,'X-Benos-Timestamp':timestamp,'X-Benos-Nonce':nonce,'X-Benos-Signature':await hmac(credentials.secret,canonical),'Idempotency-Key':requestKey,'Content-Type':binary?'application/vnd.benos.bundle-v2':'application/json'};
}
/** Low-level transport only; callers persist bundle identity and reconcile offset
 * after an uncertain response before advancing their own job. Never auto-retries. */
export async function cmsBundleRequest(credentials:CmsBundleCredentials,input:Record<string,unknown>|Uint8Array,requestKey:string){
 publicEndpoint(credentials.url);const binary=input instanceof Uint8Array,raw=binary?input:encoder.encode(JSON.stringify(input));assert(raw.byteLength<=(binary?CMS_BUNDLE_CHUNK_BYTES+4104:16384),'CMS_BUNDLE_REQUEST_TOO_LARGE','CMS 分块请求超限',413);
 const headers=await signCmsBundleRequest(credentials,raw,requestKey,binary),response=await fetch(credentials.url,{method:'POST',headers,body:raw,redirect:'manual',signal:AbortSignal.timeout(20000)});
 assert(response.status<300||response.status>=400,'CMS_BUNDLE_REDIRECT_DENIED','CMS 分块连接发生重定向',502);
 assert(Number(response.headers.get('Content-Length')||0)<=65536,'CMS_BUNDLE_RESPONSE_INVALID','CMS 分块响应过大',502);
 const reader=response.body?.getReader(),chunks:Uint8Array[]=[];let length=0;if(reader)while(true){const next=await reader.read();if(next.done)break;length+=next.value.byteLength;if(length>65536){await reader.cancel();throw new AppError('CMS_BUNDLE_RESPONSE_INVALID','CMS 分块响应过大',502);}chunks.push(next.value);}
 const dataBytes=new Uint8Array(length);let at=0;for(const chunk of chunks){dataBytes.set(chunk,at);at+=chunk.length;}const text=new TextDecoder().decode(dataBytes),timestamp=response.headers.get('X-Benos-Timestamp')||'',signature=response.headers.get('X-Benos-Signature')||'';
 assert(/^\d{10,12}$/.test(timestamp)&&Math.abs(Date.now()/1000-Number(timestamp))<=120,'CMS_BUNDLE_RESPONSE_INVALID','CMS 分块响应已过期',502);
 const expected=await hmac(credentials.secret,[CMS_BUNDLE_PROTOCOL+'-RESPONSE',headers['X-Benos-Nonce'],String(response.status),timestamp,await sha256(dataBytes)].join('\n'));assert(constantTimeEqual(signature,expected),'CMS_BUNDLE_RESPONSE_INVALID','CMS 分块响应未通过签名核对',502);
 let data:unknown;try{data=JSON.parse(text);}catch{throw new AppError('CMS_BUNDLE_RESPONSE_INVALID','CMS 分块响应格式无效',502);}return {status:response.status,data};
}
