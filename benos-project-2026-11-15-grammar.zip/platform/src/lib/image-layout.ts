import { z } from 'zod';

/** Standard raster sizes documented for the configured GPT Image models.
 * Do not infer support for arbitrary resolutions from another model family.
 * https://developers.openai.com/api/reference/resources/images/methods/generate
 */
export const IMAGE_SIZES = ['1024x1024', '1536x1024', '1024x1536'] as const;
export type ImageSize = typeof IMAGE_SIZES[number];
// A conservative UTF-8 allowance for the geometry instructions appended below.
// Exposed to manual-image clients so a description accepted by the UI still fits.
export const IMAGE_SLOT_PROMPT_RESERVE_BYTES = 640;
const edge = z.number().int().min(64).max(4096);
const position = z.enum(['center', 'left', 'right', 'top', 'bottom']);
export const imageSlotSchema = z.object({
  width: edge,
  height: edge,
  fit: z.enum(['cover', 'contain']).default('cover'),
  focalPoint: position.default('center'),
  textSafeArea: z.enum(['none', 'left', 'right', 'top', 'bottom']).default('none'),
}).strict().refine(slot => slot.width / slot.height >= 0.25 && slot.width / slot.height <= 4,
  '图片图框比例必须介于 1:4 与 4:1 之间');
export type ImageSlot = z.infer<typeof imageSlotSchema>;
export type ImageSlotInput = z.input<typeof imageSlotSchema>;

// Old stored tool calls have no slot. They must replay with their original hash,
// configured dimensions and prompt; only newly authored calls require the slot.
export const workflowImagesSchema = z.object({
  images: z.array(z.object({
    section: z.string().trim().max(60),
    prompt: z.string().trim().min(10).max(2000),
    slot: imageSlotSchema.optional(),
  }).strict()).min(1).max(4),
}).strict();

export const imageSlotParameter = {
  type: 'object',
  description: 'The planned CSS image frame, decided before generating the image. Use contain for equipment/products that must stay complete, cover for a scene that may be cropped. This is display geometry, not an arbitrary API resolution.',
  properties: {
    width: { type: 'integer', minimum: 64, maximum: 4096, description: 'Planned desktop frame width in CSS pixels.' },
    height: { type: 'integer', minimum: 64, maximum: 4096, description: 'Planned desktop frame height in CSS pixels.' },
    fit: { type: 'string', enum: ['cover', 'contain'] },
    focalPoint: { type: 'string', enum: ['center', 'left', 'right', 'top', 'bottom'], description: 'Where the important subject is placed and preserved in the frame.' },
    textSafeArea: { type: 'string', enum: ['none', 'left', 'right', 'top', 'bottom'], description: 'Quiet negative space for HTML text over the image; never generate text into the image.' },
  },
  required: ['width', 'height', 'fit', 'focalPoint', 'textSafeArea'],
  additionalProperties: false,
};

const dimensions = (size: ImageSize) => {
  const [width, height] = size.split('x').map(Number);
  return { width, height };
};

/** Closest aspect ratio minimizes the fraction lost by object-fit:cover. */
export function imageSizeForSlot(slot: Pick<ImageSlot, 'width' | 'height'>): ImageSize {
  const ratio = slot.width / slot.height;
  return IMAGE_SIZES.reduce((best, size) => {
    const a = dimensions(size), b = dimensions(best);
    return Math.abs(Math.log(ratio / (a.width / a.height))) < Math.abs(Math.log(ratio / (b.width / b.height))) ? size : best;
  });
}

export function imageDisplay(slot: ImageSlot, width: number, height: number) {
  const x = slot.focalPoint === 'left' ? 0 : slot.focalPoint === 'right' ? 1 : 0.5;
  const y = slot.focalPoint === 'top' ? 0 : slot.focalPoint === 'bottom' ? 1 : 0.5;
  const target = slot.width / slot.height, source = width / height;
  const visibleWidth = slot.fit === 'contain' ? 1 : Math.min(1, target / source);
  const visibleHeight = slot.fit === 'contain' ? 1 : Math.min(1, source / target);
  const percent = (n: number) => Math.round(n * 1000) / 10;
  return {
    aspectRatio: `${slot.width} / ${slot.height}`,
    objectFit: slot.fit,
    objectPosition: `${x * 100}% ${y * 100}%`,
    cropFraction: Math.round((1 - visibleWidth * visibleHeight) * 1000) / 1000,
    visibleRegion: { left: percent((1 - visibleWidth) * x), top: percent((1 - visibleHeight) * y), width: percent(visibleWidth), height: percent(visibleHeight) },
  };
}

export function imageLayout(slot: ImageSlot, size = imageSizeForSlot(slot)) {
  const generation = { size, ...dimensions(size) };
  return { slot, generation, display: imageDisplay(slot, generation.width, generation.height) };
}

/** Layout instructions follow the content brief so actual crop geometry is explicit. */
export function imagePromptForSlot(prompt: string, slot: ImageSlot, size = imageSizeForSlot(slot)) {
  const { display } = imageLayout(slot, size), visible = display.visibleRegion;
  return `${prompt}\n\nWebsite image composition: output ${size}; destination frame ${slot.width}x${slot.height}, fit ${slot.fit}, subject focal point ${slot.focalPoint}. ` +
    (slot.fit === 'contain' ? 'Show the complete subject with breathing room on every side; no clipped equipment, products or people. ' :
      `The visible crop starts at ${visible.left}% from the left and ${visible.top}% from the top, covering ${visible.width}% of width and ${visible.height}% of height. Keep all essential subjects inside this region, with an extra 8% inset; extend scenery into the cropped edges. `) +
    (slot.textSafeArea === 'none' ? 'No text overlay area is needed. ' : `Keep the ${slot.textSafeArea} third quiet for HTML text; place the subject outside that area. `) +
    'Do not draw text, logos, watermarks, borders or a website mockup. This image is for this specific frame; do not force one composition into incompatible frames.';
}
