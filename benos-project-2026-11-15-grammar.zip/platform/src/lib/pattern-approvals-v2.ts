import { z } from 'zod';
import type { Env } from '../env';
import { assert } from './errors';
import { sha256 } from './crypto';
import { auditStatement } from './audit';
import { getV2Catalog } from '../design-system/v2/render';
import { V2_PRESETS, V2_PATTERN_DEFINITIONS } from '../design-system/v2/contracts';
import { canonicalV2Json, v2ApprovalKey, type V2ApprovalKey, type V2TrustedReview } from '../design-system/v2/registry';

const hash = z.string().regex(/^[a-f0-9]{64}$/);
export const v2PatternReviewInputSchema = z.object({
  patternId: z.enum(V2_PATTERN_DEFINITIONS.map(p => p.id) as [V2ApprovalKey['patternId'], ...V2ApprovalKey['patternId'][]]),
  variantId: z.string().regex(/^[a-z][a-z0-9-]{0,59}$/),
  revision: z.number().int().positive().max(10000), preset: z.enum(V2_PRESETS),
  artifactHash: hash, sourceGraphHash: hash, noticeBundleHash: hash,
  state: z.enum(['approved', 'rejected', 'draft']), requestKey: z.string().regex(/^[A-Za-z0-9:_-]{16,128}$/),
}).strict();
export type V2PatternReviewInput = z.infer<typeof v2PatternReviewInputSchema>;
export type V2PatternReview = V2ApprovalKey & { state: 'approved'|'rejected'|'draft'; reviewerId: string; reviewedAt: string };
type Row = { pattern_id: V2ApprovalKey['patternId']; variant_id: string; revision: number; preset_id: V2ApprovalKey['preset']; artifact_hash: string; source_graph_hash: string; notice_bundle_hash: string; state: V2PatternReview['state']; reviewer_id: string; reviewed_at: string };
const approvalKeyOf = (value: V2ApprovalKey): V2ApprovalKey => ({ patternId:value.patternId,variantId:value.variantId,revision:value.revision,preset:value.preset,artifactHash:value.artifactHash,sourceGraphHash:value.sourceGraphHash,noticeBundleHash:value.noticeBundleHash });
const keyOf = (value: V2ApprovalKey) => canonicalV2Json(approvalKeyOf(value));

export async function readV2PatternReviews(db: D1Database): Promise<V2PatternReview[]> {
  const result = await db.prepare('SELECT pattern_id,variant_id,revision,preset_id,artifact_hash,source_graph_hash,notice_bundle_hash,state,reviewer_id,reviewed_at FROM design_pattern_v2_reviews ORDER BY reviewed_at DESC').all<Row>();
  return result.results.map(r => ({patternId:r.pattern_id,variantId:r.variant_id,revision:r.revision,preset:r.preset_id,artifactHash:r.artifact_hash,sourceGraphHash:r.source_graph_hash,noticeBundleHash:r.notice_bundle_hash,state:r.state,reviewerId:r.reviewer_id,reviewedAt:r.reviewed_at}));
}

/** Server ledger only. Code, CSS, schema, token, source or notice changes invalidate
 * the exact key. Call once when creating a workflow and persist the returned snapshot. */
export async function readApprovedV2Patterns(db: D1Database): Promise<readonly V2TrustedReview[]> {
  const [catalog, rows] = await Promise.all([getV2Catalog(),readV2PatternReviews(db)]);
  const current = new Set(catalog.patterns.flatMap(p => p.variants.flatMap(v => v.artifacts.map(a => keyOf(v2ApprovalKey(a))))));
  return rows.filter((r): r is V2TrustedReview => r.state === 'approved' && !!r.reviewerId && !!r.reviewedAt && current.has(keyOf(r)));
}

/** Do not accept a client supplied reviewer or approval object. Authentication,
 * current artifact identity and idempotency are enforced again below the route. */
export async function recordV2PatternReview(env: Env, actorId: string, input: V2PatternReviewInput, requestId: string): Promise<V2PatternReview> {
  const value = v2PatternReviewInputSchema.parse(input);
  const actor = await env.DB.prepare("SELECT id FROM users WHERE id=? AND role='owner' AND status='active'").bind(actorId).first();
  assert(actor,'FORBIDDEN','仅平台所有者可以审核新版模式',403);
  const requestHash = await sha256(canonicalV2Json({...value,requestKey:null}));
  const previous = () => env.DB.prepare('SELECT request_hash,result_json FROM design_pattern_v2_review_requests WHERE actor_id=? AND request_key=?').bind(actorId,value.requestKey).first<{request_hash:string;result_json:string}>();
  const resultOf = (row:{request_hash:string;result_json:string}) => {assert(row.request_hash===requestHash,'IDEMPOTENCY_CONFLICT','审核请求已用于另一项操作',409);return JSON.parse(row.result_json) as V2PatternReview;};
  const prior = await previous(); if(prior) return resultOf(prior);
  const catalog = await getV2Catalog();
  const current = catalog.patterns.flatMap(p=>p.variants.flatMap(v=>v.artifacts)).some(a=>keyOf(v2ApprovalKey(a))===keyOf(value));
  // Withdrawal of a previously reviewed, now obsolete artifact is permitted;
  // approving obsolete bytes or inventing an unknown record is never permitted.
  const historical = !current && value.state!=='approved' ? (await readV2PatternReviews(env.DB)).some(r=>keyOf(r)===keyOf(value)) : false;
  assert(current||historical,'BNX_REVIEW_STALE','模式已更新，请刷新并查看新版后再审核',409);
  const now = new Date().toISOString(), result:V2PatternReview = {...approvalKeyOf(value),state:value.state,reviewerId:actorId,reviewedAt:now};
  try {
    await env.DB.batch([
      env.DB.prepare('INSERT INTO design_pattern_v2_review_requests(actor_id,request_key,request_hash,result_json,created_at) VALUES(?,?,?,?,?)').bind(actorId,value.requestKey,requestHash,JSON.stringify(result),now),
      env.DB.prepare('INSERT INTO design_pattern_v2_reviews(pattern_id,variant_id,revision,preset_id,artifact_hash,source_graph_hash,notice_bundle_hash,state,reviewer_id,reviewed_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(pattern_id,variant_id,revision,preset_id,artifact_hash) DO UPDATE SET source_graph_hash=excluded.source_graph_hash,notice_bundle_hash=excluded.notice_bundle_hash,state=excluded.state,reviewer_id=excluded.reviewer_id,reviewed_at=excluded.reviewed_at').bind(value.patternId,value.variantId,value.revision,value.preset,value.artifactHash,value.sourceGraphHash,value.noticeBundleHash,value.state,actorId,now),
      auditStatement(env.DB,actorId,'design.v2_pattern_reviewed','design_pattern_v2',value.patternId+':'+value.variantId,{namespace:'bnx-1',...result},requestId),
    ]);
  } catch(error) {const row=await previous();if(row)return resultOf(row);throw error;}
  return result;
}
