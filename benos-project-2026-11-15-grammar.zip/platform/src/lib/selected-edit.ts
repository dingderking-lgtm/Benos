import {parseFragment,type DefaultTreeAdapterMap} from 'parse5';
import {designNodeHtml,type DesignScope,type DesignManifest} from '../modules/design-nodes';
import {parseTypographyDeclarations} from './typography-materialization';

export const SELECTED_EDIT_VERSION='selected-edit-v1';
export type SelectedEditIntent='restyle'|'edit';
type Element=DefaultTreeAdapterMap['element'];
type Declaration={name:string;value:string;important:boolean};
type Rule={selector:string;parts:string[]|null;declarations:Declaration[];condition:string[];order:number};
type IndexedRules={all:Rule[];keys:Map<string,Rule[]>;universal:Rule[];uncertain:Set<string>};
type CascadeValue={value:string;important:boolean;weight:number;order:number};
type ComputedSource={variables:Map<string,string>;values:Map<string,CascadeValue>};
type Budget={remaining:number;exhausted:boolean;inline:WeakMap<Element,Declaration[]>;computed:Map<number,WeakMap<Element,ComputedSource>>};
type Issue={code:string;message:string};
const attr=(node:Element,name:string)=>node.attrs.find(a=>a.name===name)?.value??'';
const parent=(node:Element)=>node.parentNode&&'tagName' in node.parentNode?node.parentNode:null;
const inert=new Set(['script','style','template','noscript','meta','link']);
const media=new Set(['img','picture','source','video','audio','svg','canvas']);
const visualProperty=/^(?:display|position|(?:min-|max-)?(?:width|height)|aspect-ratio|(?:margin|padding|border|inset)(?:-[a-z-]+)?|top|right|bottom|left|gap|row-gap|column-gap|grid(?:-[a-z-]+)?|flex(?:-[a-z-]+)?|align(?:-[a-z-]+)?|justify(?:-[a-z-]+)?|place(?:-[a-z-]+)?|order|columns?|column-(?:count|width|gap|rule)|background(?:-[a-z-]+)?|color|font(?:-[a-z-]+)?|line-height|letter-spacing|word-spacing|text-(?:align|decoration(?:-[a-z-]+)?|transform|shadow|indent|overflow|wrap)|white-space|word-break|overflow(?:-[a-z-]+)?|object-(?:fit|position)|opacity|visibility|transform(?:-origin)?|filter|box-shadow|box-sizing|outline(?:-[a-z-]+)?|vertical-align|float|clear|list-style(?:-[a-z-]+)?|content)$/;
const normal=(text:string)=>text.replace(/\s+/g,' ').trim();

/** Intent is frozen at creation. An explicit image operation is not silently
 * promoted into a whole-section redesign requirement. */
export function selectedEditIntent(request:string):SelectedEditIntent{
 const restyle=/(?:\bui\b|风格|样式|布局|排版|美化|重设计|重新设计|\b(?:restyle|redesign|layout|styling)\b|(?:visual|design)\s+style|(?:change|update)\s+(?:the\s+)?look)/i.test(request);
 const wholeBlock=/(?:区块|版块|首屏|页面|整段|布局|排版|\b(?:section|block|hero|layout)\b).{0,22}(?:风格|样式|UI|重新设计|改成|换成|redesign|restyle|style|look)|(?:风格|UI|redesign|restyle|layout).{0,22}(?:整个|整块|区块|版块|首屏|section|block|hero)/i.test(request);
 const imageOnly=!wholeBlock&&/(?:只|仅|单独).{0,8}(?:图片|图像|照片|配图)|(?:图片|图像|照片|配图)(?:的)?(?:风格|样式)|\bonly\s+(?:the\s+)?(?:image|photo|picture)\b|\b(?:image|photo|picture)\s+style\b/i.test(request);
 return restyle&&!imageOnly?'restyle':'edit';
}

export const SELECTED_EDIT_RULES=`选中编辑协议 selected-edit-v1：selected.html 是唯一可写范围；祖先定位与 CSS 均只读。用 replace_selected 返回同根标签的完整区块，不改其他文件、全局样式、真实链接、CMS 绑定或用户字体/本地字体锚点。现有风格与 foundation 只是当前基底；用户要求更换 UI/风格时，在范围内真正改变容器构图、文案/行动组外观或内容结构，不能仅给图片加滤镜/边框、改注释/空白或添加没有规则的 class。明确换图、只改图片不要求重设计文字。使用已有有效类或目标元素的内联样式；已有 inline !important 需要就地修改同一声明，可保留其优先级，但不得写全局 !important 覆盖、改字体快照或突破范围。保持响应式与已存在图片资源。平台只做静态有效改动检查，不代表浏览器视觉验收；失败应按回执修正目标，不声称完成。`;

function nodes(root:DefaultTreeAdapterMap['node']):Element[]{
 const result:Element[]=[],stack=[root];
 while(stack.length){const node=stack.pop()!;if('tagName' in node)result.push(node);if('childNodes' in node&&!('tagName' in node&&inert.has(node.tagName)))for(let i=node.childNodes.length-1;i>=0;i--)stack.push(node.childNodes[i]);}
 return result;
}
function declarations(input:string):Declaration[]{
 try{return parseTypographyDeclarations(input).map(d=>{const raw=d.raw.replace(/\/\*[\s\S]*?\*\//g,'');const value=normal(raw.slice(raw.indexOf(':')+1));return{name:d.name,value:value.replace(/\s*!\s*important\s*$/i,'').trim(),important:/!\s*important\s*$/i.test(value)};}).filter(d=>d.value&&(d.name.startsWith('--')||visualProperty.test(d.name)));}catch{return[];}
}
function expand(d:Declaration):Declaration[]{
 const sides=['top','right','bottom','left'];
 if(/^(?:padding|margin|inset|border-(?:width|style|color))$/.test(d.name)){
  const values=d.value.split(/\s+/);if(values.length<=4&&!/[()]/.test(d.value)){const [a,b=a,c=a,e=b]=values;return sides.map((side,i)=>({...d,name:d.name.startsWith('border-')?'border-'+side+'-'+d.name.slice(7):d.name==='inset'?side:d.name+'-'+side,value:[a,b,c,e][i]}));}
 }
 if(d.name==='gap'&&!/[()]/.test(d.value)){const [row,column=row]=d.value.split(/\s+/);return [{...d,name:'row-gap',value:row},{...d,name:'column-gap',value:column}];}
 if(d.name==='border'||/^border-(?:top|right|bottom|left)$/.test(d.name)){
  const values=d.value.split(/\s+/),width=values.find(v=>/^(?:0|[\d.]+(?:px|em|rem)|thin|medium|thick)$/.test(v))??'medium',style=values.find(v=>/^(?:none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset)$/.test(v))??'none',color=values.filter(v=>v!==width&&v!==style).join(' ')||'currentColor';
  if(values.length<=3&&!/[()]/.test(d.value))return (d.name==='border'?sides:[d.name.slice(7)]).flatMap(side=>[['width',width],['style',style],['color',color]].map(([part,value])=>({...d,name:'border-'+side+'-'+part,value})));
 }
 return [d];
}
function parts(selector:string):string[]|null{
 const list=selector.trim().replace(/\s*>\s*/g,'>').split(/(>|\s+)/).filter(Boolean).map(p=>/^\s+$/.test(p)?' ':p);
 return list.length%2===1&&list.length<=33&&list.every((p,i)=>i%2?p===' '||p==='>':/^(?:\*|[a-z][\w-]*|:root)?(?:[.#][a-z_][\w-]*)*$/i.test(p))?list:null;
}
function compound(node:Element,selector:string):boolean{
 const tag=selector.match(/^(?:\*|[a-z][\w-]*|:root)/i)?.[0];if(tag&&tag!=='*'&&(tag===':root'?node.tagName!=='html':tag.toLowerCase()!==node.tagName))return false;
 const classes=attr(node,'class').split(/\s+/);return [...selector.matchAll(/([.#])([\w-]+)/g)].every(([,kind,name])=>kind==='#'?attr(node,'id')===name:classes.includes(name));
}
function matches(node:Element,selector:string[]):boolean{
 let current:Element|null=node,i=selector.length-1,hops=0;if(!compound(current,selector[i]))return false;
 while(i>0){current=parent(current);if(selector[i-1]===' ')while(current&&!compound(current,selector[i-2])){if(++hops>128)return false;current=parent(current);}if(!current||!compound(current,selector[i-2]))return false;i-=2;}return true;
}
/** Bounded block scanner; it deliberately does not claim full CSS support.
 * Unknown selectors/conditions cannot establish an effective class change. */
function rules(css:string):Rule[]{
 const output:Rule[]=[],work=[{source:css.slice(0,600000),condition:[] as string[],depth:0,offset:0}];
 while(work.length&&output.length<6000){const {source,condition,depth,offset}=work.shift()!;let start=0,quote='',comment=false,escaped=false,brace=0,open=-1;
  for(let i=0;i<source.length;i++){const ch=source[i],next=source[i+1];if(comment){if(ch==='*'&&next==='/'){comment=false;i++;}continue;}if(quote){if(escaped)escaped=false;else if(ch==='\\')escaped=true;else if(ch===quote)quote='';continue;}if(ch==='/'&&next==='*'){comment=true;i++;continue;}if(ch==='"'||ch==="'"){quote=ch;continue;}
   if(ch==='{'){if(brace++===0)open=i;}else if(ch==='}'&&brace>0&&--brace===0){const selector=source.slice(start,open).replace(/\/\*[\s\S]*?\*\//g,'').trim(),body=source.slice(open+1,i),order=offset+start;start=i+1;
    if(selector.startsWith('@')){if(depth<4&&/^@(?:media|supports|container|layer)\b/i.test(selector))work.push({source:body,condition:[...condition,selector],depth:depth+1,offset:offset+open+1});continue;}
    const parsed=declarations(body);if(parsed.length)for(const part of selector.split(',')){if(output.length>=6000)break;output.push({selector:part.trim(),parts:parts(part),declarations:parsed,condition,order});}
   }else if(ch===';'&&brace===0)start=i+1;
  }
 }return output.sort((a,b)=>a.order-b.order);
}
function cssSources(manifest:DesignManifest,templateId:number){const template=manifest.templates.find(t=>t.id===templateId)!;return [{path:'site.theme.global_css',text:String(manifest.site.theme?.global_css??'')},{path:`templates/${templateId}.css`,text:String(template.document.css??'')},{path:`templates/${templateId}.customCss`,text:String(template.document.customCss??'')}];}
function describe(node:Element){return {tag:node.tagName,...(attr(node,'id')?{id:attr(node,'id').slice(0,160)}:{}),classes:attr(node,'class').split(/\s+/).filter(Boolean).slice(0,24)};}
export function selectedEditContext(manifest:DesignManifest,scope:DesignScope){
 const target=designNodeHtml(manifest,scope),ancestors:Element[]=[];for(let n=parent(target.node);n&&ancestors.length<8;n=parent(n))ancestors.push(n);
 const related=[...nodes(target.node).slice(0,2000),...ancestors],tokens=new Set(related.flatMap(n=>[attr(n,'id'),...attr(n,'class').split(/\s+/)]).filter(Boolean)),tags=new Set(related.map(n=>n.tagName));
 const css=cssSources(manifest,scope.kind==='node'?scope.templateId:0).map(source=>{const limit=source.path.endsWith('.customCss')?4000:source.path.startsWith('templates/')?12000:16000;let text=source.text;
  if(text.length>limit){text=rules(text).filter(rule=>rule.declarations.some(d=>d.name.startsWith('--'))||[...rule.selector.matchAll(/[.#]([\w-]+)/g)].some(m=>tokens.has(m[1]))||[...rule.selector.matchAll(/(?:^|[\s,>])([a-z][\w-]*)/gi)].some(m=>tags.has(m[1].toLowerCase()))||/:root|\*/.test(rule.selector)).map(rule=>rule.condition.map(c=>c+'{').join('')+rule.selector+'{'+rule.declarations.map(d=>d.name+':'+d.value+(d.important?'!important':'')).join(';')+'}'+'}'.repeat(rule.condition.length)).join('\n');}
  return {path:source.path,readOnly:true,characters:source.text.length,truncated:source.text.length>limit||text.length>limit,css:text.slice(0,limit)};
 }).filter(source=>source.characters);
 return {protocol:SELECTED_EDIT_VERSION,templateId:target.template.id,nodeKey:scope.kind==='node'?scope.nodeKey:'',html:target.html,target:describe(target.node),ancestors:ancestors.map(describe),css,cssUsage:'Read-only source context, not browser computed styles. A truncated source can be read with read_file; stylesheet writes remain forbidden.'};
}
function conditionActive(condition:string[],width:number):boolean{
 return condition.every(value=>{if(!/^@media\b/i.test(value))return false;const rest=value.replace(/^@media\s*(?:screen\s*(?:and\s*)?)?/i,'').trim();return /^(?:\((?:min|max)-width\s*:\s*\d+(?:\.\d+)?px\)\s*(?:and\s*)?)+$/i.test(rest)&&[...rest.matchAll(/\((min|max)-width\s*:\s*([\d.]+)px\)/gi)].every(([,kind,n])=>kind.toLowerCase()==='min'?width>=Number(n):width<=Number(n));});
}
function indexRules(list:Rule[],targets:Element[]):IndexedRules{
 const keys=new Map<string,Rule[]>(),universal:Rule[]=[],uncertain=new Set<string>();
 // An unsupported selector with !important can defeat an ordinary inline
 // declaration. Unless its first ordinary compound is absent from both trees,
 // exclude those properties from evidence instead of assuming it cannot match.
 const related=new Set<Element>(targets);for(const node of targets){let at=parent(node),hops=0;while(at&&hops++<128){related.add(at);at=parent(at);}}
 for(const rule of list)if(!rule.parts&&rule.declarations.some(d=>d.important)){
  const first=rule.selector.match(/^((?:[a-z][\w-]*|\*)?(?:[.#][a-z_][\w-]*)+)/i)?.[1],safe=!/[+~\\|&]/.test(rule.selector);
  if(first&&safe&&![...related].some(n=>compound(n,first)))continue;
  for(const declaration of rule.declarations.filter(d=>d.important))for(const d of expand(declaration))uncertain.add(d.name);
 }
 for(const rule of list){if(!rule.parts)continue;const last=rule.parts.at(-1)!,key=last.match(/#[\w-]+/)?.[0]??last.match(/\.[\w-]+/)?.[0]??last.match(/^[a-z][\w-]*/i)?.[0]?.toLowerCase();if(!key){universal.push(rule);continue;}const bucket=keys.get(key)??[];bucket.push(rule);keys.set(key,bucket);}
 return {all:list,keys,universal,uncertain};
}
function cascade(node:Element,index:IndexedRules,width:number,budget:Budget){
 const values=new Map<string,CascadeValue>();
 const put=(declaration:Declaration,weight:number,order:number)=>{for(const d of expand(declaration)){const before=values.get(d.name);if(!before||Number(d.important)>Number(before.important)||d.important===before.important&&(weight>before.weight||weight===before.weight&&order>=before.order))values.set(d.name,{...d,weight,order});}};
 const candidates=[...index.universal,...new Set([node.tagName,'#'+attr(node,'id'),...attr(node,'class').split(/\s+/).filter(Boolean).map(c=>'.'+c)]).values()].flatMap(value=>typeof value==='string'?index.keys.get(value)??[]:[value]);
 for(const rule of candidates){if(--budget.remaining<0){budget.exhausted=true;break;}if(rule.parts&&conditionActive(rule.condition,width)&&matches(node,rule.parts))for(const d of rule.declarations)put(d,(rule.selector.match(/#/g)?.length??0)*10000+(rule.selector.match(/[.:]/g)?.length??0)*100+(rule.selector.match(/(?:^|\s|>)[a-z]/gi)?.length??0),rule.order);}
 let inline=budget.inline.get(node);if(!inline){inline=declarations(attr(node,'style'));budget.inline.set(node,inline);}for(const d of inline)put(d,1000000,index.all.length);
 return values;
}
function resolveValue(value:string,variables:Map<string,string>,seen=new Set<string>(),depth=0):string|null{
 if(depth>8||value.length>4096)return null;let cursor=0,result='';
 while(cursor<value.length){const at=value.indexOf('var(',cursor);if(at<0)return result+value.slice(cursor);let end=at+4,nesting=1;for(;end<value.length&&nesting;end++){if(value[end]==='(')nesting++;else if(value[end]===')')nesting--;}
  if(nesting)return null;const contents=value.slice(at+4,end-1),comma=contents.indexOf(','),name=(comma<0?contents:contents.slice(0,comma)).trim(),fallback=comma<0?null:contents.slice(comma+1).trim();if(!/^--[\w-]+$/.test(name))return null;
  const raw=variables.get(name),resolved=raw!==undefined&&!seen.has(name)?resolveValue(raw,variables,new Set([...seen,name]),depth+1):null;
  const chosen=resolved??(fallback!==null?resolveValue(fallback,variables,seen,depth+1):null);if(chosen===null)return null;result+=value.slice(cursor,at)+chosen;cursor=end;
 }return result;
}
function computed(node:Element,index:IndexedRules,width:number,budget:Budget):[string,string][]{
 let cache=budget.computed.get(width);if(!cache){cache=new WeakMap();budget.computed.set(width,cache);}
 const chain:Element[]=[];let ancestor:Element|null=node;while(ancestor&&!cache.has(ancestor)){if(chain.length>=128){budget.exhausted=true;return [];}chain.push(ancestor);ancestor=parent(ancestor);}
 let variables=new Map(ancestor?cache.get(ancestor)!.variables:[]);
 if(!ancestor){for(const tagName of ['html','body']){const virtual={tagName,attrs:[],childNodes:[],parentNode:null} as unknown as Element;for(const [name,d]of cascade(virtual,index,width,budget))if(name.startsWith('--'))variables.set(name,d.value);}}
 while(chain.length){const current=chain.pop()!,values=cascade(current,index,width,budget);variables=new Map(variables);for(const [name,d]of values)if(name.startsWith('--'))variables.set(name,d.value);cache.set(current,{variables,values});}
 const source=cache.get(node)!,effective=new Map<string,CascadeValue>();
 for(const [name,original]of source.values){if(name.startsWith('--'))continue;const resolved=resolveValue(original.value,source.variables)??original.value;
  // Resolve consumed variables before a second shorthand expansion so
  // padding:var(--space)!important also defeats ordinary padding-top.
  for(const d of expand({name,value:resolved,important:original.important})){const before=effective.get(d.name);if(!before||Number(d.important)>Number(before.important)||d.important===before.important&&(original.weight>before.weight||original.weight===before.weight&&original.order>=before.order))effective.set(d.name,{...original,value:d.value});}
 }
 return [...effective].filter(([name])=>![...index.uncertain].some(p=>name===p||/^(?:padding|margin|border|background|font)$/.test(p)&&name.startsWith(p+'-'))).map(([name,d]):[string,string]=>[name,d.value]).sort(([a],[b])=>a.localeCompare(b));
}
function signature(root:Element,index:IndexedRules,width:number,budget:Budget){
 const elements=nodes(root);if(elements.length>2000)return null;
 const visible=new Map<Element,boolean>(),hasText=new Map<Element,boolean>(),hasMedia=new Map<Element,boolean>(),styles=new Map<Element,[string,string][]>();
 for(const n of elements){const style=computed(n,index,width,budget),map=new Map(style);if(budget.exhausted)return null;styles.set(n,style);visible.set(n,!inert.has(n.tagName)&&!n.attrs.some(a=>a.name==='hidden')&&map.get('display')!=='none'&&map.get('visibility')!=='hidden'&&map.get('opacity')!=='0'&&(n===root||visible.get(parent(n)!)!==false));}
 for(let i=elements.length-1;i>=0;i--){const n=elements[i],children=n.childNodes.filter((c):c is Element=>'tagName' in c);hasText.set(n,visible.get(n)===true&&(n.childNodes.some(c=>'value' in c&&!!normal(c.value))||children.some(c=>hasText.get(c)===true)));hasMedia.set(n,visible.get(n)===true&&(media.has(n.tagName)||children.some(c=>hasMedia.get(c)===true)));}
 const content:string[]=[],semantics:unknown[]=[],visual:unknown[]=[],nonMedia:unknown[]=[];
 for(const n of elements){if(!visible.get(n))continue;const childrenText=n.childNodes.filter(c=>'value' in c).map(c=>normal((c as DefaultTreeAdapterMap['textNode']).value)).filter(Boolean);content.push(...childrenText);
  const meaningful=hasText.get(n)||hasMedia.get(n),style=styles.get(n)!;
  // Empty decoration/wrappers, IDs, comments and unconsumed class/data changes
  // cannot by themselves prove a new design. Existing semantic elements count.
  if(!meaningful)continue;
  const semanticAttrs=n.attrs.filter(a=>/^(?:src|srcset|alt|href|width|height|open|type|value|aria-label|aria-expanded|role)$/.test(a.name)).map(a=>[a.name,normal(a.value)]).sort(([a],[b])=>a.localeCompare(b));
  if(semanticAttrs.length)semantics.push([n.tagName,semanticAttrs]);
  const structural=!['div','span','main','section','article'].includes(n.tagName)||childrenText.length>0;
  if(style.length||structural||n===root){const item=[n.tagName,style,structural?childrenText.map(()=>'#text'):[]];visual.push(item);if(hasText.get(n)&&!media.has(n.tagName))nonMedia.push(item);}
 }
 return {content:JSON.stringify(content),semantics:JSON.stringify(semantics),visual:JSON.stringify(visual),nonMedia:JSON.stringify(nonMedia),hasText:hasText.get(root)===true};
}

/** Static evidence only, never a screenshot or full CSS-cascade acceptance.
 * The caller must still enforce scope, safe HTML and owned assets separately. */
export function selectedEditIssues(base:DesignManifest,next:DesignManifest,scope:DesignScope,intent:SelectedEditIntent):Issue[]{
 if(scope.kind!=='node')return [];
 const original=designNodeHtml(base,scope),newHtml=next.templates.find(t=>t.id===scope.templateId)?.document.html;
 if(typeof newHtml!=='string')return [{code:'SELECTED_EDIT_INVALID',message:'选中模板缺失。'}];
 const prefix=original.template.document.html.slice(0,original.start),suffix=original.template.document.html.slice(original.end);
 if(!newHtml.startsWith(prefix)||!newHtml.endsWith(suffix))return [{code:'SELECTED_EDIT_INVALID',message:'修改超出选中范围。'}];
 const replacement=newHtml.slice(prefix.length,suffix.length?newHtml.length-suffix.length:undefined),fragment=parseFragment(replacement),roots=fragment.childNodes.filter((n):n is Element=>'tagName' in n);
 if(roots.length!==1||roots[0].tagName!==original.node.tagName||fragment.childNodes.some(n=>'value' in n&&!!normal(n.value)))return [{code:'SELECTED_EDIT_ROOT',message:'请保留选中区块的单个根标签，仅重组其内部。'}];
 // Attach the replacement to the same read-only ancestors for selector matching.
 roots[0].parentNode=original.node.parentNode;
 const css=indexRules(rules(cssSources(base,scope.templateId).map(s=>s.text).join('\n')),[...nodes(original.node),...nodes(roots[0])]),budget:Budget={remaining:120000,exhausted:false,inline:new WeakMap(),computed:new Map()};let changed=false,restyled=false,hasText=false;
 for(const width of [320,390,768,1440]){const before=signature(original.node,css,width,budget),after=signature(roots[0],css,width,budget);if(!before||!after)return [{code:'SELECTED_EDIT_UNVERIFIED',message:'选中内容或样式匹配过大，无法确认有效改动；请缩小区块范围。'}];changed ||= before.content!==after.content||before.semantics!==after.semantics||before.visual!==after.visual;restyled ||= before.nonMedia!==after.nonMedia;hasText ||= before.hasText;}
 if(!changed)return [{code:'SELECTED_EDIT_NO_CHANGE',message:'尚未检测到有效内容或样式变化。空白、注释、无效 class、被覆盖的同值声明不算修改；请修改目标元素实际生效的样式或内容。'}];
 if(intent==='restyle'&&hasText&&!media.has(original.node.tagName)&&!restyled)return [{code:'SELECTED_EDIT_MEDIA_ONLY',message:'用户要求更换整个区块的 UI 风格；目前只有图片/纯媒体框或文案变化。请实际调整容器构图、文字与行动组外观或有效内容结构，保留字体、链接和区块外内容。'}];
 return [];
}
