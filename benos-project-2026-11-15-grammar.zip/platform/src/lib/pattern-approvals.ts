import { z } from 'zod';
import type { Env } from '../env';
import { assert } from './errors';
import { sha256 } from './crypto';
import { auditStatement } from './audit';

export const patternReviewInputSchema = z.object({
  patternId: z.string().regex(/^[a-z][a-z0-9-]{0,59}$/),
  variantId: z.string().regex(/^[a-z][a-z0-9-]{0,59}$/),
  revision: z.number().int().positive().max(10000),
  compiledHash: z.string().regex(/^[a-f0-9]{64}$/),
  skin: z.string().regex(/^[a-z][a-z0-9-]{0,59}$/),
  state: z.enum(['approved', 'rejected', 'draft']),
  requestKey: z.string().regex(/^[A-Za-z0-9:_-]{16,128}$/),
}).strict();
export type PatternReviewInput = z.infer<typeof patternReviewInputSchema>;
export type PatternReview = { patternId: string; variantId: string; revision: number; compiledHash: string; skin: string; state: 'draft'|'approved'|'rejected'; reviewedAt: string };
export type PatternApproval = { patternId: string; variantId: string; revision: number; compiledHash: string; skins: string[] };
type Row = { pattern_id: string; variant_id: string; revision: number; compiled_hash: string; skin_id: string; state: PatternReview['state']; reviewed_at: string };
export async function readPatternReviews(db: D1Database): Promise<PatternReview[]> {
  const result = await db.prepare('SELECT pattern_id,variant_id,revision,compiled_hash,skin_id,state,reviewed_at FROM design_pattern_reviews ORDER BY reviewed_at DESC').all<Row>();
  return result.results.map(r => ({ patternId:r.pattern_id, variantId:r.variant_id, revision:r.revision, compiledHash:r.compiled_hash, skin:r.skin_id, state:r.state, reviewedAt:r.reviewed_at }));
}
/** Exact bytes + revision + skin, never family-level or latest-revision approval. */
export async function readApprovedPatterns(db: D1Database): Promise<PatternApproval[]> {
  const reviews = (await readPatternReviews(db)).filter(r => r.state === 'approved');
  const groups = new Map<string,PatternApproval>();
  for (const r of reviews) {
    const key = [r.patternId,r.variantId,r.revision,r.compiledHash].join(':');
    const value = groups.get(key) || {patternId:r.patternId,variantId:r.variantId,revision:r.revision,compiledHash:r.compiledHash,skins:[]};
    value.skins.push(r.skin); groups.set(key,value);
  }
  return [...groups.values()];
}
/** Caller verifies the current catalog/hash first; the owner role is checked
 * here as well, so another internal caller cannot silently grant approval. */
export async function recordPatternReview(env: Env, actorId: string, input: PatternReviewInput, requestId: string): Promise<PatternReview> {
  const value = patternReviewInputSchema.parse(input);
  const actor = await env.DB.prepare("SELECT id FROM users WHERE id=? AND role='owner' AND status='active'").bind(actorId).first();
  assert(actor,'FORBIDDEN','仅平台所有者可以确认设计模式',403);
  const requestHash = await sha256(JSON.stringify({...value,requestKey:undefined}));
  const previous = async () => env.DB.prepare('SELECT request_hash,result_json FROM design_pattern_review_requests WHERE actor_id=? AND request_key=?').bind(actorId,value.requestKey).first<{request_hash:string;result_json:string}>();
  const readResult = (row:{request_hash:string;result_json:string}) => { assert(row.request_hash===requestHash,'IDEMPOTENCY_CONFLICT','审核请求已用于另一项操作',409); return JSON.parse(row.result_json) as PatternReview; };
  const saved = await previous(); if(saved) return readResult(saved);
  const now = new Date().toISOString();
  const result:PatternReview = {patternId:value.patternId,variantId:value.variantId,revision:value.revision,compiledHash:value.compiledHash,skin:value.skin,state:value.state,reviewedAt:now};
  try {
    await env.DB.batch([
      env.DB.prepare('INSERT INTO design_pattern_review_requests(actor_id,request_key,request_hash,result_json,created_at) VALUES(?,?,?,?,?)').bind(actorId,value.requestKey,requestHash,JSON.stringify(result),now),
      env.DB.prepare('INSERT INTO design_pattern_reviews(pattern_id,variant_id,revision,compiled_hash,skin_id,state,actor_id,reviewed_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(pattern_id,variant_id,revision,compiled_hash,skin_id) DO UPDATE SET state=excluded.state,actor_id=excluded.actor_id,reviewed_at=excluded.reviewed_at').bind(value.patternId,value.variantId,value.revision,value.compiledHash,value.skin,value.state,actorId,now),
      auditStatement(env.DB,actorId,'design.pattern_reviewed','design_pattern',value.patternId+':'+value.variantId,{...result},requestId),
    ]);
  } catch (error) { const row = await previous(); if(row) return readResult(row); throw error; }
  return result;
}
