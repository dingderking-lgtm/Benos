import { z } from 'zod';
import { SECTION_PATTERN_VERSION, SECTION_PATTERN_SCHEMA_VERSION, SKIN_VERSION, PATTERN_SKINS, SECTION_PATTERN_FAMILIES, sectionPatternInputSchema, pageCompositionSchema, sectionPatternValidationFingerprint, findSectionPattern, type PatternSkin, type SectionPatternInput, type ResolvedSectionPatternInput, type SectionPatternFamily, type SectionPatternVariant, type PageCompositionInput } from '../contracts/section-patterns';
import { PATTERN_CSS_VERSION, SECTION_BASE_CSS, SKIN_CSS, PATTERN_FAMILY_CSS } from '../contracts/section-pattern-css';
import { sha256 } from './crypto';
import type { PatternApproval } from './pattern-approvals';
export type { PatternApproval } from './pattern-approvals';
export { createSectionPatternFixture } from '../contracts/section-pattern-fixtures';
export type PatternOwnedAsset={path:string;width:number;height:number;source:'uploaded'|'generated'|'licensed';sha256?:string};
/** Gallery access is a server authorization decision, not a model/client input. */
export type PatternRenderContext={mode:'gallery'|'production';approved?:readonly PatternApproval[];ownedAssets?:readonly PatternOwnedAsset[];verifiedFactRefs?:readonly string[]};
export type PatternIssue={code:string;sectionId:string;message:string;severity:'warning'|'error'};
export type PatternFrame={id:string;frameId:string;sectionId:string;purpose:string;alt:string;prompt?:string;source:'owned'|'planned';assetPath?:string;presentation:'standard'|'hero-cover';slot:{width:number;height:number;fit:'cover';focalPoint:'center'|'left'|'right'|'top'|'bottom';textSafeArea:'none'|'left'|'right'|'top'|'bottom'};subjectPolicy:'complete'|'crop-safe';framePolicy:'adapt'|'fixed'};
export type PatternReceipt={patternId:string;variantId:string;revision:number;compiledHash:string;skin:PatternSkin;sectionId:string;degraded:boolean};
export type RenderedSectionPattern={html:string;css:string;frames:PatternFrame[];assets:PatternOwnedAsset[];receipt:PatternReceipt;issues:PatternIssue[]};
export type SectionPatternCatalog={version:typeof SECTION_PATTERN_VERSION;schemaVersion:typeof SECTION_PATTERN_SCHEMA_VERSION;skinVersion:typeof SKIN_VERSION;skins:{id:PatternSkin;label:string}[];families:Array<Omit<SectionPatternFamily,'variants'>&{variants:Array<SectionPatternVariant&{compiledHash:string;allowedSkins:PatternSkin[];approvalStatus:'draft'}>}>};
const e=(value:string)=>value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const p=(value?:string,cls='bns-copy')=>value?`<p class="${cls}">${e(value)}</p>`:'';
const symbols:Record<string,string>={plus:'+',check:'✓',circle:'○',arrow:'↗',number:'•'};
const position={center:'50% 50%',left:'0% 50%',right:'100% 50%',top:'50% 0%',bottom:'50% 100%'};
function actions(input:ResolvedSectionPatternInput){return input.content.actions.length?`<div class="bns-actions">${input.content.actions.map(a=>`<a class="bns-button${a.kind==='secondary'?' bns-button-secondary':''}" href="${e(a.href)}">${e(a.label)}<span aria-hidden="true">↗</span></a>`).join('')}</div>`:'';}
function heading(input:ResolvedSectionPatternInput,hero=false,withActions=false){const c=input.content,tag=hero?'h1':'h2';return `<div class="bns-heading-group bns-heading-${input.headingLayout}">${input.headingLayout==='numbered-side'?'<span class="bns-section-index" aria-hidden="true">01</span>':''}${c.eyebrow?p(c.eyebrow,'bns-kicker'):''}<${tag} class="${hero?'bns-hero-title':'bns-title'}">${e(c.title)}</${tag}>${p(c.lead,'bns-lead')}${withActions?actions(input):''}</div>`;}
function itemBody(item:ResolvedSectionPatternInput['content']['items'][number]){return `<h3 class="bns-item-title">${e(item.title)}</h3>${p(item.text,'bns-item-text')}`;}
function cards(input:ResolvedSectionPatternInput){return input.content.items.map((item,i)=>`<article class="bns-card">${item.href?`<a class="bns-card-link" href="${e(item.href)}">`:''}<span class="bns-symbol" aria-hidden="true">${item.icon==='number'?String(i+1).padStart(2,'0'):(symbols[item.icon||'plus']??symbols.plus)}</span>${itemBody(item)}${item.href?'</a>':''}</article>`).join('');}
function list(input:ResolvedSectionPatternInput){return `<ul class="bns-list-items">${input.content.items.map((item,i)=>`<li><span class="bns-symbol" aria-hidden="true">${String(i+1).padStart(2,'0')}</span><div>${itemBody(item)}</div></li>`).join('')}</ul>`;}
function geometry(input:ResolvedSectionPatternInput,index:number,asset?:PatternOwnedAsset):[number,number]{
 const media=input.media[index];if(media.subjectPolicy==='complete')return asset?[asset.width,asset.height]:[1536,1024];
 if(input.patternId==='media-mosaic')return input.variantId==='bento'?(index===0?[720,1000]:index===1?[1500,980]:[720,980]):index===0?[882,1000]:[1200,1000];
 if(input.patternId==='hero-cover')return[1536,1024];if(input.patternId==='hero-centered')return[1600,900];
 if(input.patternId==='media-rail')return[1000,1250];if(input.variantId==='full-bleed-caption'||input.variantId==='image-caption-strip')return[1600,900];return[1536,1024];
}
function prepareMedia(input:ResolvedSectionPatternInput,ctx:PatternRenderContext,variant:SectionPatternVariant){
 const frames:PatternFrame[]=[],assets:PatternOwnedAsset[]=[],issues:PatternIssue[]=[],html:string[]=[];
 for(let i=0;i<input.media.length;i++){
  const m=input.media[i];if(m.kind==='missing'){issues.push({code:'IMAGE_UNAVAILABLE',sectionId:input.id,message:`图片 ${m.id} 不可用，保留有意义的文字内容。`,severity:'warning'});html.push('');continue;}
  if(m.subjectPolicy==='complete'&&!variant.completeSubjects)throw new Error('PATTERN_COMPLETE_SUBJECT_UNSUPPORTED');
  const asset=m.kind==='owned'?ctx.ownedAssets?.find(a=>a.path===m.assetPath):undefined;
  if(m.kind==='owned'&&(!asset||!Number.isInteger(asset.width)||!Number.isInteger(asset.height)||asset.width<1||asset.height<1||asset.width>32768||asset.height>32768))throw new Error('PATTERN_ASSET_NOT_VERIFIED');
  if(asset&&(!/^\/(?!\/)/.test(asset.path)||/[<>"'`\\\s]/.test(asset.path)||(ctx.mode!=='gallery'&&/^\/api\/admin\//.test(asset.path))))throw new Error('PATTERN_ASSET_PATH_INVALID');
  const [width,height]=geometry(input,i,asset),id=`${input.id}-${m.id}`,cover=input.patternId==='hero-cover';
  const frame:PatternFrame={id,frameId:`bnf-image-${id}`,sectionId:input.id,purpose:m.purpose,alt:m.alt,...(m.prompt?{prompt:m.prompt}:{}),source:m.kind,...(asset?{assetPath:asset.path}:{}),presentation:cover?'hero-cover':'standard',slot:{width,height,fit:'cover',focalPoint:m.focalPoint,textSafeArea:m.textSafeArea},subjectPolicy:m.subjectPolicy,framePolicy:m.subjectPolicy==='complete'?'adapt':'fixed'};frames.push(frame);if(asset)assets.push(asset);
  html.push(`<div id="${frame.frameId}" class="bns-frame${cover?' bnf-hero-cover-media':''}" style="--bns-ratio:${width}/${height};--bns-position:${position[m.focalPoint]}">${asset?`<img src="${e(asset.path)}" width="${asset.width}" height="${asset.height}" alt="${e(m.alt)}" loading="${input.patternId.startsWith('hero-')?'eager':'lazy'}" decoding="async">`:''}</div>`);
 }
 return{frames,assets,issues,html};
}
function figure(input:ResolvedSectionPatternInput,media:string,index:number,caption=true,focusable=false){if(!media)return'';const item=input.content.items[index];return `<figure class="bns-figure"${focusable?` id="${input.id}-item-${index+1}" tabindex="0" aria-label="${e(item?.title||input.media[index].alt)}"`:''}>${media}${caption&&item?`<figcaption class="bns-figure-caption"><span class="bns-caption-title">${e(item.title)}</span>${e(item.text)}</figcaption>`:''}</figure>`;}
function renderBody(input:ResolvedSectionPatternInput,media:string[],issues:PatternIssue[]){
 const {patternId:f,variantId:v,content:c}=input,head=heading(input),images=media.filter(Boolean),wrap=(h:string)=>`<div class="bns-wrap">${h}</div>`,noMedia=!images.length&&(f.startsWith('media-')||(f==='process-path'&&(v==='alternating'||v==='image-steps')));
 if(noMedia&&!f.startsWith('hero-'))return wrap(head+`<div class="bns-fallback-list">${cards(input)}</div>`+p(c.body,'bns-copy bns-body-block')+actions(input));
 if(f==='hero-stage')return wrap(`<div class="bns-hero-grid">${heading(input,true,true)}${images[0]?`<div class="bns-stage-shell">${images[0]}${c.items[0]?`<div class="bns-stage-foot"><strong>${e(c.items[0].title)}</strong><span>${e(c.items[0].text)}</span></div>`:''}</div>`:''}</div>`);
 if(f==='hero-centered')return wrap(heading(input,true,true)+(images[0]?`<div class="bns-wide-stage">${images[0]}</div>`:''));
 if(f==='hero-cover')return (images[0]||'')+`<div class="bns-wrap bns-cover-content bnf-hero-cover-content"><div class="bns-cover-panel bnf-hero-cover-panel">${heading(input,true,true)}</div></div>`;
 if(f==='media-mosaic'){
  if(images.length!==media.length||media.length<(v==='bento'?4:3)){issues.push({code:'COMPOSITION_DEGRADED',sectionId:input.id,message:'缺图后改为完整图文阅读序列，不留下拼贴空格。',severity:'warning'});return wrap(head+`<div class="bns-fallback-list">${media.map((m,i)=>figure(input,m,i)).join('')}</div>`);}
  return wrap(head+`<div class="bns-mosaic-grid${v==='bento'?' bns-mosaic-bento':''}">${media.map((m,i)=>figure(input,m,i)).join('')}</div>`);
 }
 if(f==='media-story'){
  if(v==='alternating')return wrap(head+`<div class="bns-story-rows">${c.items.map((item,i)=>`<article class="bns-story-row${media[i]?'':' bns-story-text-only'}">${figure(input,media[i],i,false)}<div class="bns-story-copy">${itemBody(item)}</div></article>`).join('')}</div>`);
  if(v==='lead-image-list')return wrap(head+`<div class="bns-lead-list">${figure(input,images[0],0,false)}${list(input)}</div>`);
  if(v==='full-bleed-caption')return wrap(head+`<div class="bns-immersive">${images[0]}<div class="bns-immersive-card">${c.items[0]?itemBody(c.items[0]):p(c.body||c.lead)}${actions(input)}</div></div>`);
  return wrap(head+`<div class="bns-caption-strip">${images[0]}<div class="bns-caption-bar">${p(c.body||c.lead,'bns-copy')}<ul>${c.items.map(item=>`<li>${itemBody(item)}</li>`).join('')}</ul></div></div>`);
 }
 if(f==='media-rail'){const live=media.map((m,i)=>m?i:-1).filter(i=>i>=0),first=live[0],last=live[live.length-1];return wrap(head+`<div class="bns-rail" role="region" aria-label="${e(c.title)}" tabindex="0">${media.map((m,i)=>figure(input,m,i,true,true)).join('')}</div><div class="bns-rail-note">${p(c.body||c.lead)}<div class="bns-rail-controls"><a href="#${input.id}-item-${first+1}" aria-label="${e(c.items[first]?.title||input.media[first].alt)}">←</a><a href="#${input.id}-item-${last+1}" aria-label="${e(c.items[last]?.title||input.media[last].alt)}">→</a></div></div>`);}
 if(f==='features-icons')return wrap(head+`<div class="${v==='feature-band'?'bns-feature-band':'bns-feature-grid'} bns-feature-count-${c.items.length}">${cards(input)}</div>`);
 if(f==='features-ledger'){
  if(v==='verified-comparison')return wrap(head+`<table class="bns-verified-table"><tbody>${c.items.map(item=>`<tr><th scope="row">${e(item.title)}</th><td><span class="bns-verified-value">${e(item.value||'')}</span></td><td>${e(item.text)}</td></tr>`).join('')}</tbody></table>`);
  return wrap(head+`<div class="bns-ledger${v==='selection'?' bns-selection':''}">${c.items.map((item,i)=>`<article class="bns-ledger-row">${v==='selection'?p(item.label||String(i+1).padStart(2,'0'),'bns-selection-label'):`<span class="bns-ledger-index" aria-hidden="true">${String(i+1).padStart(2,'0')}</span>`}<h3 class="bns-item-title">${e(item.title)}</h3>${p(item.text)}</article>`).join('')}</div>`);
 }
 if(f==='process-path')return wrap(head+`<ol class="bns-ordered bns-path-${v==='image-steps'?'images':v}">${c.items.map((item,i)=>`<li class="bns-step">${v==='alternating'?figure(input,media[i],i,false):''}${v!=='alternating'?`<span class="bns-step-number" aria-hidden="true">${String(i+1).padStart(2,'0')}</span>`:''}<div class="bns-step-body">${v==='alternating'?`<span class="bns-step-number" aria-hidden="true">${String(i+1).padStart(2,'0')}</span>`:''}${v==='image-steps'?(media[i]||''):''}${itemBody(item)}</div></li>`).join('')}</ol>`);
 if(f==='faq-details')return wrap(`<div class="bns-faq-layout">${head}<div class="bns-faq-list">${c.questions.map(q=>`<details><summary>${e(q.question)}</summary>${p(q.answer,'bns-answer')}</details>`).join('')}</div></div>`);
 if(f==='action-panel')return wrap(`<div class="bns-action-shell bns-action-${v}">${heading(input)}${v==='split-contact'?`<div class="bns-contact-panel">${list(input)}${actions(input)}</div>`:actions(input)}</div>`);
 if(f==='footer-directory')return wrap(`<div class="bns-footer-top${c.navigation.length?'':' bns-footer-top-solo'}"><div class="bns-footer-brand">${heading(input)}${p(c.body)}${c.contact.map(x=>`<p><a class="bns-text-link" href="${e(x.href)}">${e(x.label)}</a></p>`).join('')}</div>${c.navigation.length?`<nav class="bns-footer-groups" aria-label="${e(c.title)}">${c.navigation.map(group=>`<div class="bns-footer-group"><h3>${e(group.title)}</h3><ul>${group.links.map(link=>`<li><a href="${e(link.href)}">${e(link.label)}</a></li>`).join('')}</ul></div>`).join('')}</nav>`:''}</div>${c.copyright||c.imageAttribution?`<div class="bns-footer-bottom">${p(c.copyright,'bns-footer-note')}${p(c.imageAttribution,'bns-footer-note')}</div>`:''}`);
 throw new Error('PATTERN_RENDERER_MISSING');
}
function rendererFingerprint(){return [e,p,actions,heading,itemBody,cards,list,geometry,prepareMedia,figure,renderBody,renderSectionPattern,compilePageComposition].map(fn=>fn.toString()).join('\n')+sectionPatternValidationFingerprint()+JSON.stringify({symbols,position});}
let catalogPromise:Promise<SectionPatternCatalog>|undefined;
export function getSectionPatternCatalog():Promise<SectionPatternCatalog>{
 return catalogPromise??=Promise.all(SECTION_PATTERN_FAMILIES.map(async family=>({...family,variants:await Promise.all(family.variants.map(async variant=>({...variant,compiledHash:await sha256(JSON.stringify({version:SECTION_PATTERN_VERSION,schemaVersion:SECTION_PATTERN_SCHEMA_VERSION,schema:z.toJSONSchema(sectionPatternInputSchema),skinVersion:SKIN_VERSION,cssVersion:PATTERN_CSS_VERSION,family:{...family,variants:undefined},variant,css:SECTION_BASE_CSS+PATTERN_FAMILY_CSS[family.id],skins:SKIN_CSS,renderer:rendererFingerprint()})),allowedSkins:[...PATTERN_SKINS],approvalStatus:'draft' as const})))}))).then(families=>({version:SECTION_PATTERN_VERSION,schemaVersion:SECTION_PATTERN_SCHEMA_VERSION,skinVersion:SKIN_VERSION,skins:[{id:'soft-gradient',label:'柔和渐变'},{id:'bold-outline',label:'鲜明描边'},{id:'clean-business',label:'干净商务'}],families}));
}
/** Input rows have already passed the server's approval ledger query. */
export async function filterCurrentPatternApprovals(rows:readonly PatternApproval[]):Promise<PatternApproval[]>{const catalog=await getSectionPatternCatalog();return rows.flatMap(row=>{const f=catalog.families.find(f=>f.id===row.patternId),v=f?.variants.find(v=>v.id===row.variantId);if(!f||!v||f.revision!==row.revision||v.compiledHash!==row.compiledHash)return[];const skins=[...new Set(row.skins)].filter(s=>v.allowedSkins.some(a=>a===s));return skins.length?[{patternId:f.id,variantId:v.id,revision:f.revision,compiledHash:v.compiledHash,skins}]:[];});}
export async function renderSectionPattern(raw:SectionPatternInput,ctx:PatternRenderContext):Promise<RenderedSectionPattern>{
 const input=sectionPatternInputSchema.parse(raw),{family,variant}=findSectionPattern(input.patternId,input.variantId),catalog=await getSectionPatternCatalog(),meta=catalog.families.find(f=>f.id===family.id)!.variants.find(v=>v.id===variant.id)!;
 if(ctx.mode!=='gallery'&&!ctx.approved?.some(a=>a.patternId===family.id&&a.variantId===variant.id&&a.revision===family.revision&&a.compiledHash===meta.compiledHash&&a.skins.includes(input.skin)))throw new Error('PATTERN_NOT_APPROVED');
 const count=family.group==='faq'?input.content.questions.length:input.content.items.length;
 if(count<variant.itemRange[0]||count>variant.itemRange[1])throw new Error('PATTERN_CONTENT_COUNT');
 if(input.media.length>variant.mediaRange[1])throw new Error('PATTERN_MEDIA_COUNT');
 const receipt:PatternReceipt={patternId:family.id,variantId:variant.id,revision:family.revision,compiledHash:meta.compiledHash,skin:input.skin,sectionId:input.id,degraded:false};
 const css=SKIN_CSS[input.skin]+SECTION_BASE_CSS+PATTERN_FAMILY_CSS[family.id];
 const facts=new Set(ctx.verifiedFactRefs||[]);
 if(input.content.contact.some(c=>!facts.has(c.factRef)))throw new Error('PATTERN_CONTACT_NOT_VERIFIED');
 if(variant.requiresFacts&&input.content.items.some(i=>!i.factRef||!facts.has(i.factRef)||!i.value))return{html:'',css,frames:[],assets:[],receipt:{...receipt,degraded:true},issues:[{code:'FACTS_MISSING',sectionId:input.id,message:'缺少核验事实，省略对照区块。',severity:'warning'}]};
 const media=prepareMedia(input,ctx,variant),issues=media.issues;
 if(input.media.length<variant.mediaRange[0])issues.push({code:'MEDIA_COUNT_DEGRADED',sectionId:input.id,message:'图片不足，改用现有文字内容，不补图或留空框。',severity:'warning'});
 const noMedia=!media.html.some(Boolean),tag=family.group==='footer'?'footer':'section';
 const body=renderBody(input,media.html,issues),html=`<${tag} id="${input.id}" class="bns-section bns-${family.id} bns-skin-${input.skin} bns-surface-${input.surface}${noMedia?' bns-no-media':''}${family.id==='hero-cover'?` bnf-hero-cover bnf-hero-cover-text-${input.media[0]?.textSafeArea||'none'}`:''}">${body}</${tag}>`;
 return{html,css,frames:media.frames,assets:media.assets,receipt:{...receipt,degraded:issues.length>0},issues};
}
export async function compilePageComposition(raw:PageCompositionInput,ctx:PatternRenderContext){
 const input=pageCompositionSchema.parse(raw);if(input.sections.filter(s=>s.patternId.startsWith('hero-')).length>1)throw new Error('PATTERN_MULTIPLE_HEROES');if(input.sections.filter(s=>s.patternId==='footer-directory').length>1)throw new Error('PATTERN_MULTIPLE_FOOTERS');
 const sections=await Promise.all(input.sections.map(s=>renderSectionPattern(s,ctx))),css=SKIN_CSS[input.skin]+SECTION_BASE_CSS+[...new Set(input.sections.map(s=>s.patternId))].map(id=>PATTERN_FAMILY_CSS[id]).join('\n');
 if(new TextEncoder().encode(css).length>40000)throw new Error('PATTERN_CSS_TOO_LARGE');
 const frames=sections.flatMap(s=>s.frames),assets=[...new Map(sections.flatMap(s=>s.assets).map(a=>[a.path,a])).values()];
 return{html:sections.map(s=>s.html).join('\n'),css,frames,assets,receipts:sections.map(s=>s.receipt),issues:sections.flatMap(s=>s.issues)};
}
/** Pure wrapper: preserves all unrelated templates/pages and does not modify frozen foundation bytes. */
export function wrapCompositionManifest<T extends {site:any;templates:any[];theme?:any}>(base:T,result:Awaited<ReturnType<typeof compilePageComposition>>,pageKey='home'):T{
 const output=structuredClone(base),page=output.site.pages?.find((p:any)=>p.key===pageKey);if(!page)throw new Error('PATTERN_PAGE_NOT_FOUND');
 const template=output.templates.find(t=>t.id===(page.template_id??page.templateId));if(!template)throw new Error('PATTERN_TEMPLATE_NOT_FOUND');
 template.document={...template.document,html:result.html,css:result.css};return output;
}
