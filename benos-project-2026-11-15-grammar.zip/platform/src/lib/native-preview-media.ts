import { assert } from './errors';
import { inspectMediaBytes } from '../modules/media';
import { inspectGif } from './extended-media';
/** CMS-native decoded/re-encoded derivatives have a separate 16 MiB bound.
 * User uploads remain at 12 MiB. Keep the same container, dimensions and pixel
 * constraints; larger derived bytes never become user-upload inventory. */
export async function inspectNativePreviewMedia(bytes:Uint8Array,mime:string){
 assert(bytes.length>0&&bytes.length<=16*1048576,'NATIVE_PREVIEW_ARTIFACT_INVALID','原生派生图片超出容量',422);
 if(bytes.length<=12*1048576){const result=await inspectMediaBytes(bytes,mime);assert(result.mimeType!=='application/pdf','NATIVE_PREVIEW_ARTIFACT_INVALID','PDF 不能作为预览图片',422);return;}
 const invalid=(condition:unknown)=>assert(condition,'NATIVE_PREVIEW_ARTIFACT_INVALID','原生派生图片格式、尺寸或像素校验失败',422),ascii=(at:number,size:number)=>String.fromCharCode(...bytes.subarray(at,at+size)),v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let width=0,height=0;
 if(mime==='image/png'&&ascii(0,8)==='\x89PNG\r\n\x1a\n'){
  const table=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n>>>1)^((n&1)?0xedb88320:0);return n>>>0;});let at=8,header=false,data=false,end=false;
  while(at+12<=bytes.length){const size=v.getUint32(at),type=ascii(at+4,4);invalid(size<=16*1048576&&at+size+12<=bytes.length);let crc=0xffffffff;for(const b of bytes.subarray(at+4,at+size+8))crc=(crc>>>8)^table[(crc^b)&255];invalid(((crc^0xffffffff)>>>0)===v.getUint32(at+size+8));
   if(!header){invalid(type==='IHDR'&&size===13);width=v.getUint32(at+8);height=v.getUint32(at+12);header=true;invalid(!!({0:[1,2,4,8,16],2:[8,16],3:[1,2,4,8],4:[8,16],6:[8,16]} as Record<number,number[]>)[bytes[at+17]]?.includes(bytes[at+16])&&bytes[at+18]===0&&bytes[at+19]===0&&bytes[at+20]<=1);}else invalid(!['IHDR','acTL','fcTL','fdAT'].includes(type));
   if(type==='IDAT'){invalid(size>0);data=true;}if(type==='IEND'){invalid(size===0&&data&&at+12===bytes.length);end=true;break;}invalid(/^[a-zA-Z]{4}$/.test(type));at+=size+12;
  }invalid(header&&end);
 }else if(mime==='image/jpeg'&&bytes[0]===255&&bytes[1]===216){let at=2,frame=false,scan=false,end=false;while(at<bytes.length){invalid(bytes[at++]===255);while(bytes[at]===255)at++;const marker=bytes[at++];if(marker===217){end=true;break;}invalid(marker!==216&&marker!==0&&marker!==undefined);if(marker===1||(marker>=208&&marker<=215)){invalid(scan);continue;}invalid(at+2<=bytes.length);const size=v.getUint16(at);invalid(size>=2&&at+size<=bytes.length);
   if([192,193,194].includes(marker)){invalid(!frame&&size>=8);height=v.getUint16(at+3);width=v.getUint16(at+5);invalid(bytes[at+2]===8&&[1,3,4].includes(bytes[at+7]));frame=true;}if(marker===218){invalid(frame&&size>=6);scan=true;at+=size;while(at<bytes.length){if(bytes[at]!==255){at++;continue;}const next=bytes[at+1];if(next===0||next===255||(next>=208&&next<=215)){at+=2;continue;}break;}continue;}at+=size;
  }invalid(frame&&scan&&end&&at===bytes.length);
 }else if(mime==='image/webp'&&ascii(0,4)==='RIFF'&&ascii(8,4)==='WEBP'){invalid(v.getUint32(4,true)+8===bytes.length);let at=12,frames=0,extended=false;while(at+8<=bytes.length){const type=ascii(at,4),length=v.getUint32(at+4,true),p=at+8;invalid(p+length+length%2<=bytes.length&&!['ANIM','ANMF'].includes(type));if(type==='VP8X'){invalid(!extended&&at===12&&length===10&&!(bytes[p]&2));extended=true;width=1+bytes[p+4]+(bytes[p+5]<<8)+(bytes[p+6]<<16);height=1+bytes[p+7]+(bytes[p+8]<<8)+(bytes[p+9]<<16);}if(type==='VP8 '){invalid(length>=10&&ascii(p+3,3)==='\x9d\x01\x2a'&&!(bytes[p]&1));const w=v.getUint16(p+6,true)&16383,h=v.getUint16(p+8,true)&16383;invalid(!extended||(width===w&&height===h));width=w;height=h;frames++;}if(type==='VP8L'){invalid(length>=5&&bytes[p]===47&&!(bytes[p+4]&224));const bits=v.getUint32(p+1,true),w=(bits&16383)+1,h=((bits>>>14)&16383)+1;invalid(!extended||(width===w&&height===h));width=w;height=h;frames++;}at=p+length+length%2;}invalid(at===bytes.length&&frames===1);
 }else if(mime==='image/gif'&&/^GIF8[79]a$/.test(ascii(0,6))){({width,height}=inspectGif(bytes));}else invalid(false);
 invalid(Number.isSafeInteger(width)&&Number.isSafeInteger(height)&&width>=1&&height>=1&&width<=8192&&height<=8192&&width*height<=16000000);
}
