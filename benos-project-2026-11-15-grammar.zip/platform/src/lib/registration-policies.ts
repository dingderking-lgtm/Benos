import type { Env } from '../env';

// Availability only: published operator content is the policy. Never synthesize legal text here.
// Keep this module independent of auth/content routes, which depend on one another.
export const REGISTRATION_POLICIES = {
  terms: { title: '服务条款', href: '/pages/terms' },
  privacy: { title: '隐私说明', href: '/pages/privacy' },
} as const;
export type RegistrationPolicy = keyof typeof REGISTRATION_POLICIES;

export function isRegistrationPolicy(slug: string): slug is RegistrationPolicy {
  return Object.prototype.hasOwnProperty.call(REGISTRATION_POLICIES, slug);
}
export function hasPolicyBody(item: { body?: unknown } | null): boolean {
  return typeof item?.body === 'string' && item.body.trim().length > 0;
}
export async function registrationStatus(env: Env) {
  const policies = {
    terms: { ready: false, href: REGISTRATION_POLICIES.terms.href },
    privacy: { ready: false, href: REGISTRATION_POLICIES.privacy.href },
  };
  // The public snapshot's slug/body matter; a newer draft must not change what a visitor can read.
  const rows = await env.DB.prepare("SELECT published_json FROM content_entries WHERE state='published' AND COALESCE(kind_override,kind)='page' AND json_extract(published_json,'$.slug') IN ('terms','privacy')").all<{ published_json: string }>();
  for (const row of rows.results) {
    const item = JSON.parse(row.published_json) as { slug: string; body?: unknown };
    if (isRegistrationPolicy(item.slug) && hasPolicyBody(item)) policies[item.slug].ready = true;
  }
  const registrationEnabled = env.REGISTRATION_ENABLED === 'true';
  return { registrationEnabled, ready: registrationEnabled && policies.terms.ready && policies.privacy.ready, policies };
}
