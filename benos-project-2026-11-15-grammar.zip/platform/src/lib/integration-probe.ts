import { AppError } from './errors';
import { fetchWithoutRedirect,ProviderRedirectError } from './provider-fetch';

const messages = {
  PROBE_FAILED: '服务访问验证失败，请检查配置后重试',
  PROBE_CREDENTIALS_INVALID: '密钥无效或已失效，请检查后创建新配置',
  PROBE_ACCESS_DENIED: '当前密钥或网络环境无权访问该服务，请检查访问权限',
  PROBE_MODEL_UNAVAILABLE: '该模型不存在或当前密钥无访问权限，请核对模型名称和权限',
  PROBE_RATE_LIMITED: '服务暂时限制请求，请稍后重试',
  PROBE_UPSTREAM_UNAVAILABLE: '服务暂时不可用，请稍后重试',
  PROBE_TIMEOUT: '连接验证超时，请检查服务器网络后重试',
  PROBE_NETWORK_ERROR: '服务器无法连接服务，请检查网络、代理和证书配置',
  PROBE_RESPONSE_INVALID: '服务返回的数据无法完成验证，请检查接口地址与模型配置',
} as const;
type ProbeCode = keyof typeof messages;
type NetworkReason = 'DNS' | 'TLS' | 'CONNECTION' | 'TIMEOUT' | 'NETWORK';
type ProbeDetails = { upstreamStatus?: number; networkReason?: NetworkReason };

class ModelProbeError extends AppError {
  constructor(readonly probeCode: ProbeCode, readonly details: ProbeDetails = {}) {
    // Upstream HTTP status is evidence, not the status of the Benos session.
    // In particular, returning 401 here would log the administrator out.
    super(probeCode, messages[probeCode], 409);
  }
}

/** Only our fixed classification reaches the response/audit; never copy an
 * exception message, response body, URL, request headers or credential. */
export function safeProbeFailure(error: unknown) {
  const known = error instanceof ModelProbeError;
  const code: ProbeCode = known ? error.probeCode : 'PROBE_FAILED';
  return { code, message: messages[code], ...(known ? error.details : {}) };
}

function transportFailure(error: unknown): ModelProbeError {
  if (error instanceof ProviderRedirectError) return new ModelProbeError('PROBE_RESPONSE_INVALID', { upstreamStatus: error.status });
  let reason: NetworkReason = 'NETWORK';
  let current = error;
  for (let depth = 0; depth < 3 && current && typeof current === 'object'; depth++) {
    const item = current as { name?: unknown; code?: unknown; message?: unknown; cause?: unknown };
    const code = typeof item.code === 'string' ? item.code : '';
    const message = typeof item.message === 'string' ? item.message : '';
    if (item.name === 'TimeoutError' || ['ETIMEDOUT', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_BODY_TIMEOUT'].includes(code)) {
      return new ModelProbeError('PROBE_TIMEOUT', { networkReason: 'TIMEOUT' });
    }
    if (['ENOTFOUND', 'EAI_AGAIN', 'EAI_FAIL'].includes(code) || /\bDNS\b|name resolution|hostname lookup/i.test(message)) reason = 'DNS';
    else if (/^(?:CERT_|ERR_TLS_|ERR_SSL_)|^(?:UNABLE_TO_VERIFY_LEAF_SIGNATURE|DEPTH_ZERO_SELF_SIGNED_CERT|SELF_SIGNED_CERT_IN_CHAIN|UNABLE_TO_GET_ISSUER_CERT_LOCALLY)$/.test(code) || /\bTLS\b|\bSSL\b|certificate/i.test(message)) reason = 'TLS';
    else if (reason === 'NETWORK' && (['ECONNREFUSED', 'ECONNRESET', 'EPIPE', 'UND_ERR_SOCKET'].includes(code) || /connection|socket/i.test(message))) reason = 'CONNECTION';
    current = item.cause;
  }
  return new ModelProbeError('PROBE_NETWORK_ERROR', { networkReason: reason });
}

function httpFailure(status: number): ModelProbeError {
  const code: ProbeCode = status === 401 ? 'PROBE_CREDENTIALS_INVALID'
    : status === 403 ? 'PROBE_ACCESS_DENIED'
    : status === 404 ? 'PROBE_MODEL_UNAVAILABLE'
    : status === 429 ? 'PROBE_RATE_LIMITED'
    : status >= 500 ? 'PROBE_UPSTREAM_UNAVAILABLE'
    : 'PROBE_FAILED';
  return new ModelProbeError(code, { upstreamStatus: status });
}

async function modelJson(response: Response): Promise<Record<string, unknown>> {
  const reader = response.body?.getReader();
  if (!reader) throw new ModelProbeError('PROBE_RESPONSE_INVALID', { upstreamStatus: response.status });
  let size = 0;
  const chunks: Uint8Array[] = [];
  try {
    while (true) {
      let part: ReadableStreamReadResult<Uint8Array>;
      try { part = await reader.read(); } catch (error) { throw transportFailure(error); }
      if (part.done) break;
      size += part.value.byteLength;
      if (size > 1024 * 1024) {
        try { await reader.cancel(); } catch { /* Cancellation diagnostics are not public. */ }
        throw new ModelProbeError('PROBE_RESPONSE_INVALID', { upstreamStatus: response.status });
      }
      chunks.push(part.value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  let data: unknown;
  try { data = JSON.parse(new TextDecoder().decode(bytes)); }
  catch { throw new ModelProbeError('PROBE_RESPONSE_INVALID', { upstreamStatus: response.status }); }
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new ModelProbeError('PROBE_RESPONSE_INVALID', { upstreamStatus: response.status });
  return data as Record<string, unknown>;
}

/** Read access only. Never fall back to a generation request or a different model. */
export async function probeModelAccess(config: { baseUrl: string; model: string; listing: boolean }, apiKey: string, fetcher: typeof fetch = fetch): Promise<void> {
  let response: Response;
  try {
    response = await fetchWithoutRedirect(`${config.baseUrl}/models${config.listing ? '' : '/' + encodeURIComponent(config.model)}`, {
      method: 'GET', headers: { Authorization: `Bearer ${apiKey}` }, signal: AbortSignal.timeout(15_000),
    }, fetcher);
  } catch (error) { throw transportFailure(error); }
  if (!response.ok) {
    try { await response.body?.cancel(); } catch { /* Do not read upstream error content. */ }
    throw httpFailure(response.status);
  }
  const data = await modelJson(response);
  if (config.listing ? !Array.isArray(data.data) : typeof data.id !== 'string') throw new ModelProbeError('PROBE_RESPONSE_INVALID', { upstreamStatus: response.status });
  const matched = config.listing
    ? (data.data as unknown[]).some(model => model !== null && typeof model === 'object' && (model as { id?: unknown }).id === config.model)
    : data.id === config.model;
  if (!matched) throw new ModelProbeError('PROBE_MODEL_UNAVAILABLE', { upstreamStatus: response.status });
}
