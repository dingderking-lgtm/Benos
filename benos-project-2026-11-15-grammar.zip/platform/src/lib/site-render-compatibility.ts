import {parseFragment} from 'parse5';

export const SITE_RENDER_COMPATIBILITY_VERSION='native-sequence-1' as const;
const CSS='/* benos-native-sequence:1 */\n.bnp-native-sequence{list-style:decimal-leading-zero;margin:0;padding:0 0 0 1.75em}.bnp-native-sequence>li{padding:0 0 24px 12px}.bnp-native-sequence>li:last-child{padding-bottom:0}[dir="rtl"] .bnp-native-sequence{padding:0 1.75em 0 0}[dir="rtl"] .bnp-native-sequence>li{padding:0 12px 24px 0}';
/** The CMS CSS sanitizer does not retain counters/logical positioned offsets.
 * New workflows use native ol numbering instead. No legacy CSS is rewritten,
 * no generated company facts, selectors, text, links or list order are changed. */
export function materializeSiteRenderCompatibility<T>(input:T,version:unknown):T{
 if(version!==SITE_RENDER_COMPATIBILITY_VERSION)return input;
 const manifest=structuredClone(input) as any;let changed=false;
 for(const template of manifest.templates??[]){const html=template.document?.html;if(typeof html!=='string')continue;const edits:Array<{start:number;end:number;text:string}>=[],stack:any[]=[parseFragment(html,{sourceCodeLocationInfo:true})];
  while(stack.length){const node=stack.pop();if(node.tagName==='ol'){const attr=node.attrs.find((a:any)=>a.name==='class'),location=node.sourceCodeLocation?.attrs?.class;if(attr&&location&&attr.value.split(/\s+/).includes('bnf-sequence')){const value=attr.value.split(/\s+/).filter((c:string)=>c&&c!=='bnf-sequence');value.push('bnp-native-sequence');edits.push({start:location.startOffset,end:location.endOffset,text:'class="'+[...new Set(value)].join(' ').replace(/&/g,'&amp;').replace(/"/g,'&quot;')+'"'});}}
   for(const child of node.childNodes??[])stack.push(child);
  }
  if(edits.length){let next=html;for(const edit of edits.sort((a,b)=>b.start-a.start))next=next.slice(0,edit.start)+edit.text+next.slice(edit.end);template.document.html=next;changed=true;}
 }
 const css=String(manifest.site?.theme?.global_css??'');
 if(changed&&!css.includes('/* benos-native-sequence:1 */'))manifest.site.theme={...manifest.site.theme,global_css:css+'\n'+CSS};
 return changed?manifest:input;
}
