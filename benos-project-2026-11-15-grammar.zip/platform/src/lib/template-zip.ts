import { assert } from './errors';
const encoder=new TextEncoder();
const crcTable=Uint32Array.from({length:256},(_,value)=>{let c=value;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);return c>>>0;});
const crc=(data:Uint8Array)=>{let c=0xffffffff;for(const b of data)c=(c>>>8)^crcTable[(c^b)&255];return (c^0xffffffff)>>>0;};
/** Stored ZIP, UTF-8 names, no directory entries. Only manifest and the exact
 * declared assets can be passed by the authenticated exporter. */
export function templateZip(manifest:unknown,assets:Array<{file:string;bytes:Uint8Array}>){
 const entries=[{file:'manifest.json',bytes:encoder.encode(JSON.stringify(manifest))},...assets];
 assert(entries.length<=65,'ZIP_LIMIT','模板文件数量超限');let offset=0;const local:Uint8Array[]=[],central:Uint8Array[]=[];
 for(const entry of entries){assert(entry.file==='manifest.json'||/^assets\/\d{1,2}\.(jpg|jpeg|png|webp|gif|svg|pdf)$/.test(entry.file),'ZIP_PATH','模板文件名无效');assert(entry.bytes.length<=12*1024*1024,'ZIP_LIMIT','模板文件过大');const name=encoder.encode(entry.file),checksum=crc(entry.bytes),header=new Uint8Array(30+name.length),h=new DataView(header.buffer);h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x0800,true);h.setUint16(12,0x2821,true);h.setUint32(14,checksum,true);h.setUint32(18,entry.bytes.length,true);h.setUint32(22,entry.bytes.length,true);h.setUint16(26,name.length,true);header.set(name,30);
  const index=new Uint8Array(46+name.length),v=new DataView(index.buffer);v.setUint32(0,0x02014b50,true);v.setUint16(4,20,true);v.setUint16(6,20,true);v.setUint16(8,0x0800,true);v.setUint16(14,0x2821,true);v.setUint32(16,checksum,true);v.setUint32(20,entry.bytes.length,true);v.setUint32(24,entry.bytes.length,true);v.setUint16(28,name.length,true);v.setUint32(42,offset,true);index.set(name,46);local.push(header,entry.bytes);central.push(index);offset+=header.length+entry.bytes.length;
 }
 const centralLength=central.reduce((sum,x)=>sum+x.length,0),end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,entries.length,true);v.setUint16(10,entries.length,true);v.setUint32(12,centralLength,true);v.setUint32(16,offset,true);const output=new Uint8Array(offset+centralLength+end.length);assert(output.length<=74*1024*1024,'ZIP_LIMIT','模板压缩包过大');let at=0;for(const data of [...local,...central,end]){output.set(data,at);at+=data.length;}return output;
}
