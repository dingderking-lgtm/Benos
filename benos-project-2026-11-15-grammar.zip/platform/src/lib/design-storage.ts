import type { Env } from '../env';
import { assert,AppError } from './errors';
import { id,sha256 } from './crypto';

export const MAX_INLINE_MANIFEST_BYTES=1_000_000,MAX_DESIGN_MANIFEST_BYTES=10*1048576;
const MAX_STAGED_OBJECTS=20,MAX_STAGED_BYTES=200*1048576,LEASE_MS=120000,UNREFERENCED_TTL_MS=24*3600000;
const FORMAT='benos-manifest-ref';
export type ManifestStorageRow={manifest_json:string;manifest_object_id?:string|null;content_hash?:string};
export type ManifestObjectRow={id:string;user_id:string;project_id:string;object_key:string;sha256:string;byte_size:number;index_json:string;state:string;lease_token:string|null;lease_until_ms:number|null;created_at:string;updated_at:string};
export type ManifestStorage={manifestJson:string;objectId:string|null;contentHash:string;byteSize:number};
type Scope={userId:string;projectId:string};
function parse(json:string):any{try{return JSON.parse(json);}catch{throw new AppError('DESIGN_STORAGE_CORRUPT','设计清单副本格式无效',503);}}
export function serializeDesignManifest(manifest:unknown):string{
 const json=JSON.stringify(manifest);assert(typeof json==='string'&&new TextEncoder().encode(json).byteLength<=MAX_DESIGN_MANIFEST_BYTES,'TEMPLATE_STORAGE_LIMIT','清单文本最多 10 MiB，请精简模板后重试；已有设计不会被覆盖',413);return json;
}
/** Legacy inline-only callers must explicitly opt into the R2 storage API. */
export function inlineManifestJson(manifest:unknown):string{
 const json=serializeDesignManifest(manifest);assert(new TextEncoder().encode(json).byteLength<=MAX_INLINE_MANIFEST_BYTES,'TEMPLATE_STORAGE_LIMIT','当前清单文本最多 1 MB，请通过大清单存储通道保存；已有设计不会被覆盖',413);return json;
}
export function designManifestSummary(manifest:any){
 const site=manifest.site;return {siteName:String(site.name??'').slice(0,180),home:site.home??null,headerTemplateId:site.header_template_id??null,footerTemplateId:site.footer_template_id??null,
  templates:manifest.templates.map((t:any)=>({id:t.id,type:t.type,name:String(t.name??'').slice(0,180)})),pages:site.pages.map((p:any)=>({key:p.key,slug:p.slug,templateId:p.template_id}))};
}
export function designManifestIndex(manifest:unknown,object:{id:string;sha256:string;byte_size:number}){
 return {format:FORMAT,version:1,objectId:object.id,sha256:object.sha256,byteSize:object.byte_size,assets:(manifest as {assets:unknown[]}).assets,summary:designManifestSummary(manifest)};
}
export function designManifestObjectKey(scope:Scope,objectId:string,digest:string){return `private/users/${encodeURIComponent(scope.userId)}/projects/${encodeURIComponent(scope.projectId)}/manifests/${objectId}/${digest}.json`;}
function store(env:Env){assert(env.BUCKET,'DESIGN_STORAGE_NOT_CONFIGURED','大清单私有存储尚未配置',503);return env.BUCKET;}
function identity(row:ManifestObjectRow,scope:Scope){assert(row.user_id===scope.userId&&row.project_id===scope.projectId&&row.object_key===designManifestObjectKey(scope,row.id,row.sha256),'DESIGN_STORAGE_IDENTITY','设计清单存储归属不一致',503);}
async function readObject(env:Env,row:ManifestObjectRow):Promise<string>{
 const object=await store(env).get(row.object_key);assert(object&&object.size===row.byte_size,'DESIGN_STORAGE_MISSING','设计清单存储副本暂不可用',503);
 const bytes=new Uint8Array(await object.arrayBuffer());assert(bytes.byteLength===row.byte_size&&await sha256(bytes)===row.sha256,'DESIGN_STORAGE_CORRUPT','设计清单存储副本校验失败',503);
 let json:string;try{json=new TextDecoder('utf-8',{fatal:true,ignoreBOM:false}).decode(bytes);}catch{throw new AppError('DESIGN_STORAGE_CORRUPT','设计清单编码无效',503);}return json;
}
const unreferenced=`NOT EXISTS(SELECT 1 FROM design_versions v WHERE v.manifest_object_id=design_manifest_objects.id) AND NOT EXISTS(SELECT 1 FROM design_candidates c WHERE c.manifest_object_id=design_manifest_objects.id)`;
export async function prepareDesignManifestStorage(env:Env,userId:string,projectId:string,manifest:unknown,nowMs=Date.now()):Promise<ManifestStorage>{
 const json=serializeDesignManifest(manifest),bytes=new TextEncoder().encode(json),contentHash=await sha256(bytes),scope={userId,projectId};
 if(bytes.length<=MAX_INLINE_MANIFEST_BYTES)return {manifestJson:json,objectId:null,contentHash,byteSize:bytes.length};
 const bucket=store(env),now=new Date(nowMs).toISOString();
 let row=await env.DB.prepare("SELECT * FROM design_manifest_objects WHERE user_id=? AND project_id=? AND sha256=? AND state<>'purged'").bind(userId,projectId,contentHash).first<ManifestObjectRow>();
 if(!row){
  const objectId=id('manifest'),key=designManifestObjectKey(scope,objectId,contentHash),index=JSON.stringify(designManifestIndex(manifest,{id:objectId,sha256:contentHash,byte_size:bytes.length})),guard=id('guard');
  assert(new TextEncoder().encode(index).length<=250000,'TEMPLATE_STORAGE_LIMIT','清单索引超过安全容量',413);
  try{await env.DB.batch([
   env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM projects WHERE id=? AND user_id=? AND archived_at IS NULL) AND (EXISTS(SELECT 1 FROM design_manifest_objects WHERE user_id=? AND project_id=? AND sha256=? AND state<>'purged') OR ((SELECT COUNT(*) FROM design_manifest_objects WHERE project_id=? AND state<>'purged' AND ${unreferenced})<? AND (SELECT COALESCE(SUM(byte_size),0) FROM design_manifest_objects WHERE project_id=? AND state<>'purged' AND ${unreferenced})+?<=?)) THEN 1 ELSE 0 END`).bind(guard,projectId,userId,userId,projectId,contentHash,projectId,MAX_STAGED_OBJECTS,projectId,bytes.length,MAX_STAGED_BYTES),
   env.DB.prepare("INSERT INTO design_manifest_objects(id,user_id,project_id,object_key,sha256,byte_size,index_json,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'staging',?,?) ON CONFLICT(user_id,project_id,sha256) WHERE state<>'purged' DO NOTHING").bind(objectId,userId,projectId,key,contentHash,bytes.length,index,now,now),
   env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard),
  ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('DESIGN_STAGING_LIMIT','待保存的大清单已达暂存上限，请完成原方案或等待过期清理',409);throw error;}
  row=await env.DB.prepare("SELECT * FROM design_manifest_objects WHERE user_id=? AND project_id=? AND sha256=? AND state<>'purged'").bind(userId,projectId,contentHash).first<ManifestObjectRow>();
 }
 assert(row,'DESIGN_STORAGE_UNCONFIRMED','清单存储结果待确认，请重试原操作',503);identity(row,scope);
 assert(row.byte_size===bytes.length&&row.index_json===JSON.stringify(designManifestIndex(manifest,row)),'DESIGN_STORAGE_CORRUPT','清单索引与原字节不一致',503);
 if(row.state==='ready'){await readObject(env,row);return {manifestJson:row.index_json,objectId:row.id,contentHash,byteSize:bytes.length};}
 const token=id('manifest_lease'),claimed=await env.DB.prepare("UPDATE design_manifest_objects SET lease_token=?,lease_until_ms=?,updated_at=? WHERE id=? AND state='staging' AND (lease_until_ms IS NULL OR lease_until_ms<=?) RETURNING id").bind(token,nowMs+LEASE_MS,now,row.id,nowMs).first();
 assert(claimed,'DESIGN_STORAGE_BUSY','原清单正在保存或清理，请稍后重试同一操作',409);
 try{
  try{const result=await bucket.put(row.object_key,bytes,{onlyIf:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json; charset=utf-8',cacheControl:'private, no-store'},customMetadata:{sha256:contentHash}});if(!result)await readObject(env,row);}
  catch(error){try{await readObject(env,row);}catch{throw error;}}
  const ready=await env.DB.prepare("UPDATE design_manifest_objects SET state='ready',lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND state='staging' AND lease_token=? RETURNING id").bind(now,row.id,token).first();assert(ready,'DESIGN_STORAGE_UNCONFIRMED','清单写入确认已变化，请重试原操作',503);
 }catch(error){await env.DB.prepare("UPDATE design_manifest_objects SET lease_token=NULL,lease_until_ms=NULL WHERE id=? AND state='staging' AND lease_token=?").bind(row.id,token).run();throw error;}
 return {manifestJson:row.index_json,objectId:row.id,contentHash,byteSize:bytes.length};
}
export async function readStoredManifestJson(env:Env,stored:ManifestStorageRow,scope:Scope):Promise<string>{
 const index=parse(stored.manifest_json);
 if(!stored.manifest_object_id){assert(index?.format!==FORMAT,'DESIGN_STORAGE_CORRUPT','设计清单索引缺少存储引用',503);return stored.manifest_json;}
 const row=await env.DB.prepare('SELECT * FROM design_manifest_objects WHERE id=?').bind(stored.manifest_object_id).first<ManifestObjectRow>();
 assert(row&&row.state==='ready'&&row.index_json===stored.manifest_json&&index?.format===FORMAT&&index.version===1&&index.objectId===row.id&&index.sha256===row.sha256&&index.byteSize===row.byte_size&&(!stored.content_hash||stored.content_hash===row.sha256),'DESIGN_STORAGE_CORRUPT','设计清单索引校验失败',503);identity(row,scope);
 const json=await readObject(env,row),manifest=parse(json);assert(JSON.stringify(designManifestIndex(manifest,row))===row.index_json,'DESIGN_STORAGE_CORRUPT','设计清单素材索引或页面摘要不一致',503);return json;
}
export async function readStoredManifest(env:Env,stored:ManifestStorageRow,scope:Scope){return parse(await readStoredManifestJson(env,stored,scope));}
/** Small index projection never fetches the complete R2 manifest. */
export function storedManifestSummary(stored:ManifestStorageRow){const value=parse(stored.manifest_json);return stored.manifest_object_id?value.summary:designManifestSummary(value);}

/** Old keys are never reused, including after an unknown DELETE response. A
 * tombstone remains so a late PUT can be removed on a later maintenance pass. */
export async function purgeUnreferencedDesignManifests(env:Env,nowMs=Date.now()){
 if(!env.BUCKET)return {removed:0,uncertain:0};const now=new Date(nowMs).toISOString(),before=new Date(nowMs-UNREFERENCED_TTL_MS).toISOString();
 const rows=await env.DB.prepare(`SELECT * FROM design_manifest_objects WHERE updated_at<=? AND (lease_until_ms IS NULL OR lease_until_ms<=?) AND ${unreferenced} ORDER BY updated_at LIMIT 20`).bind(before,nowMs).all<ManifestObjectRow>();let removed=0,uncertain=0;
 for(const row of rows.results){const token=id('manifest_gc'),claimed=await env.DB.prepare(`UPDATE design_manifest_objects SET state=CASE WHEN state='purged' THEN 'purged' ELSE 'purging' END,lease_token=?,lease_until_ms=?,updated_at=? WHERE id=? AND (lease_until_ms IS NULL OR lease_until_ms<=?) AND ${unreferenced} RETURNING id`).bind(token,nowMs+LEASE_MS,now,row.id,nowMs).first();if(!claimed)continue;
  try{identity(row,{userId:row.user_id,projectId:row.project_id});await env.BUCKET.delete(row.object_key);await env.DB.prepare("UPDATE design_manifest_objects SET state='purged',lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND state IN ('purging','purged') AND lease_token=?").bind(now,row.id,token).run();removed++;}
  catch{await env.DB.prepare("UPDATE design_manifest_objects SET lease_token=NULL,lease_until_ms=NULL WHERE id=? AND state IN ('purging','purged') AND lease_token=?").bind(row.id,token).run();uncertain++;}
 }return {removed,uncertain};
}
