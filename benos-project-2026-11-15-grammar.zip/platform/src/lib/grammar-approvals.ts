// The grammar's approval model. Per-block approval cannot apply to a page composed from scratch each
// time, so what the owner approves is the machine: the compiler identity, the ranges a model may pick
// brand values from, and the reference page it is measured against. Without an exact approval the
// engine may compile previews but never a production package.
import { z } from 'zod';
import type { Env } from '../env';
import { assert } from './errors';
import { sha256 } from './crypto';
import { GRAMMAR_IDENTITY, type GrammarIdentity } from '../design-system/grammar/identity';
import type { GrammarBrand, Issue } from '../design-system/grammar/brand';

/** Brand ranges: the values a model may choose. Anything outside them is refused in production. */
export const grammarBrandRangesSchema = z.object({
  type: z.object({
    head: z.array(z.string().min(1).max(20)).min(1).max(12).optional(),
    body: z.array(z.string().min(1).max(20)).min(1).max(12).optional(),
    weight: z.array(z.number().int().min(100).max(900)).min(1).max(9).optional(),
    tracking: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
    scale: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
  }).strict().optional(),
  shape: z.object({
    radius: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
    button: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
  }).strict().optional(),
  styles: z.object({
    kicker: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
    link: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
    card: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
    figure: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
  }).strict().optional(),
  space: z.object({
    container: z.array(z.number().int().min(960).max(1680)).min(1).max(9).optional(),
    density: z.array(z.string().min(1).max(20)).min(1).max(9).optional(),
  }).strict().optional(),
}).strict();
export type GrammarBrandRanges = z.infer<typeof grammarBrandRangesSchema>;

export const grammarApprovalInputSchema = z.object({
  decision: z.enum(['approved', 'rejected']),
  brandRanges: grammarBrandRangesSchema,
  note: z.string().max(2000).optional(),
}).strict();
export type GrammarApprovalInput = z.infer<typeof grammarApprovalInputSchema>;

export type GrammarApproval = {
  grammarDigest: string;
  specDigest: string;
  exemplarDigest: string;
  brandRanges: GrammarBrandRanges;
  state: 'approved' | 'rejected' | 'draft';
  reviewerId: string;
  reviewedAt: string;
};
type ApprovalRow = { grammar_digest: string; spec_digest: string; exemplar_digest: string; brand_ranges_json: string; state: GrammarApproval['state']; reviewer_id: string; reviewed_at: string };
const toApproval = (row: ApprovalRow): GrammarApproval => ({
  grammarDigest: row.grammar_digest, specDigest: row.spec_digest, exemplarDigest: row.exemplar_digest,
  brandRanges: grammarBrandRangesSchema.parse(JSON.parse(row.brand_ranges_json)),
  state: row.state, reviewerId: row.reviewer_id, reviewedAt: row.reviewed_at,
});

export async function readGrammarApprovals(db: Env['DB']): Promise<GrammarApproval[]> {
  const rows = await db.prepare('SELECT grammar_digest,spec_digest,exemplar_digest,brand_ranges_json,state,reviewer_id,reviewed_at FROM design_grammar_approvals ORDER BY reviewed_at DESC LIMIT 200').all<ApprovalRow>();
  return (rows.results ?? []).map(toApproval);
}

/** Records the owner's decision about the grammar identity the server is actually running. */
export async function recordGrammarApproval(env: Env, reviewerId: string, input: GrammarApprovalInput): Promise<{ approval: GrammarApproval; created: boolean }> {
  const identity = GRAMMAR_IDENTITY;
  const existing = await env.DB.prepare('SELECT state FROM design_grammar_approvals WHERE grammar_digest=? AND spec_digest=? AND exemplar_digest=?')
    .bind(identity.digest, identity.spec, identity.exemplar).first<{ state: string }>();
  const reviewedAt = new Date().toISOString();
  const brandRanges = JSON.stringify(input.brandRanges);
  await env.DB.prepare('INSERT INTO design_grammar_approvals(grammar_digest,spec_digest,exemplar_digest,brand_ranges_json,state,reviewer_id,reviewed_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(grammar_digest,spec_digest,exemplar_digest) DO UPDATE SET brand_ranges_json=excluded.brand_ranges_json,state=excluded.state,reviewer_id=excluded.reviewer_id,reviewed_at=excluded.reviewed_at')
    .bind(identity.digest, identity.spec, identity.exemplar, brandRanges, input.decision, reviewerId, reviewedAt).run();
  return { approval: { grammarDigest: identity.digest, specDigest: identity.spec, exemplarDigest: identity.exemplar, brandRanges: input.brandRanges, state: input.decision, reviewerId, reviewedAt }, created: !existing };
}

/** The approval that matches the running grammar exactly, or none. */
export function findGrammarApproval(approvals: readonly GrammarApproval[], identity: GrammarIdentity = GRAMMAR_IDENTITY): GrammarApproval | undefined {
  return approvals.find(approval => approval.state === 'approved' && approval.grammarDigest === identity.digest && approval.specDigest === identity.spec && approval.exemplarDigest === identity.exemplar);
}

/** Production compiling requires an exact approval: same compiler, same spec, same exemplar. */
export function assertGrammarApproved(approvals: readonly GrammarApproval[], identity: GrammarIdentity = GRAMMAR_IDENTITY): GrammarApproval {
  const approval = findGrammarApproval(approvals, identity);
  assert(approval, 'GRAMMAR_NOT_APPROVED', '版式语法引擎尚未批准，不能生成正式网站。请运营后台批准当前语法版本。', 409);
  return approval;
}

/** Checks a brand system against the ranges the owner approved. */
export function brandRangeIssues(brand: GrammarBrand, ranges: GrammarBrandRanges): Issue[] {
  const issues: Issue[] = [];
  const inside = (path: string, value: unknown, allowed: readonly unknown[] | undefined) => {
    if (!allowed || allowed.length === 0) return;
    if (!allowed.includes(value)) issues.push({ level: 'error', path: `brand.${path}`, message: `${JSON.stringify(value)} is outside the approved range ${allowed.join(' | ')}` });
  };
  inside('type.head', brand.type.head, ranges.type?.head);
  inside('type.body', brand.type.body, ranges.type?.body);
  inside('type.weight', brand.type.weight, ranges.type?.weight);
  inside('type.tracking', brand.type.tracking, ranges.type?.tracking);
  inside('type.scale', brand.type.scale, ranges.type?.scale);
  inside('shape.radius', brand.shape.radius, ranges.shape?.radius);
  inside('shape.button', brand.shape.button, ranges.shape?.button);
  inside('styles.kicker', brand.styles.kicker, ranges.styles?.kicker);
  inside('styles.link', brand.styles.link, ranges.styles?.link);
  inside('styles.card', brand.styles.card, ranges.styles?.card);
  inside('styles.figure', brand.styles.figure, ranges.styles?.figure);
  inside('space.container', brand.space.container, ranges.space?.container);
  inside('space.density', brand.space.density, ranges.space?.density);
  return issues;
}

/** A short, stable label for one approval row, used in the owner's list and in audit lines. */
export async function grammarApprovalKey(approval: GrammarApproval): Promise<string> {
  return sha256(JSON.stringify([approval.grammarDigest, approval.specDigest, approval.exemplarDigest, approval.state]));
}
