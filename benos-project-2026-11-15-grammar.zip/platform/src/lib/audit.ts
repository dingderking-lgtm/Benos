import { id } from './crypto';
export function auditStatement(db: D1Database, actorId: string|null, action: string, entityType: string, entityId: string|null, details: unknown = {}, requestId: string|null = null) {
  return db.prepare('INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) VALUES (?,?,?,?,?,?,?,?)').bind(id('audit'),actorId,action,entityType,entityId,JSON.stringify(details),requestId,new Date().toISOString());
}
