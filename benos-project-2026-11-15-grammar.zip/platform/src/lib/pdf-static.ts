import { AppError } from './errors';

// A deliberately bounded, traditional-xref subset of ISO 32000-1 §§7.2–7.7.
// https://opensource.adobe.com/dc-acrobat-sdk-docs/pdfstandards/PDF32000_2008.pdf
// This checks object structure and a real page tree; it is not a renderer, a
// stream decompressor, or support for every PDF variant. Bytes are never fixed
// up, rewritten, executed, or sent to an external service.
const MAX_BYTES=12*1048576,MAX_OBJECTS=5000,MAX_VALUES=100000,MAX_DEPTH=40,MAX_PAGES=1000;
const activeNames=new Set('javascript js launch embeddedfile embeddedfiles richmedia openaction aa additionalactions xfa acroform submitform importdata gotor gotoe encrypt objstm xref xrefstm crypt linearized movie sound rendition 3d goto3dview ps'.split(' '));
type Name={kind:'name';value:string};
type Ref={kind:'ref';id:number;generation:number};
type Str={kind:'string'};
type Arr={kind:'array';values:Value[]};
type Dict={kind:'dict';values:Map<string,Value>};
type Value=null|boolean|number|Name|Ref|Str|Arr|Dict;
type Entry={id:number;generation:number;offset:number;inUse:boolean};
type ObjectValue={value:Value;stream:boolean};
function invalid(message='PDF 结构无效；请重新导出普通 PDF（传统交叉引用表、非加密、无增量更新）'):never{throw new AppError('MEDIA_INVALID',message,422);}
function is<T extends Exclude<Value,null|number|boolean>>(v:Value|undefined,kind:T['kind']):v is T{return !!v&&typeof v==='object'&&v.kind===kind;}
const ws=(c:string|undefined)=>c!==undefined&&/^[\x00\t\n\f\r ]$/.test(c);
const delimiter=(c:string|undefined)=>c===undefined||ws(c)||'()<>[]{}/%'.includes(c);
function latin1(bytes:Uint8Array){const parts:string[]=[];for(let at=0;at<bytes.length;at+=8192)parts.push(String.fromCharCode(...bytes.subarray(at,at+8192)));return parts.join('');}
class Budget {values=0;refs:Ref[]=[];tick(){if(++this.values>MAX_VALUES)invalid('PDF 对象内容过于复杂，请简化后上传');}}
class Parser {
 constructor(readonly text:string,public at:number,readonly end:number,readonly budget:Budget){}
 skip(){while(this.at<this.end){if(ws(this.text[this.at])){this.at++;continue;}if(this.text[this.at]==='%'){while(this.at<this.end&&!['\r','\n'].includes(this.text[this.at]))this.at++;continue;}break;}}
 keyword(word:string){this.skip();if(this.text.startsWith(word,this.at)&&this.at+word.length<=this.end&&delimiter(this.text[this.at+word.length])){this.at+=word.length;return true;}return false;}
 expect(word:string){if(!this.keyword(word))invalid();}
 uint(){this.skip();const start=this.at;while(this.at<this.end&&/[0-9]/.test(this.text[this.at]))this.at++;if(this.at===start||!delimiter(this.text[this.at]))invalid();const n=Number(this.text.slice(start,this.at));if(!Number.isSafeInteger(n))invalid();return n;}
 name():Name {
  if(this.text[this.at++]!=='/')invalid();let name='';
  while(this.at<this.end&&!delimiter(this.text[this.at])){let c=this.text[this.at++];if(c==='#'){const hex=this.text.slice(this.at,this.at+2);if(!/^[a-f\d]{2}$/i.test(hex))invalid('PDF 名称转义无效');c=String.fromCharCode(parseInt(hex,16));this.at+=2;}if(c==='\0'||name.length>=255)invalid('PDF 名称无效或过长');name+=c;}
  if(activeNames.has(name.toLowerCase()))invalid('PDF 含主动内容、加密或不支持的对象/交叉引用流；请导出静态普通 PDF');return {kind:'name',value:name};
 }
 value(depth=0):Value {
  if(depth>MAX_DEPTH)invalid('PDF 对象嵌套过深');this.budget.tick();this.skip();if(this.at>=this.end)invalid();const c=this.text[this.at];
  if(c==='/')return this.name();
  if(c==='('){this.at++;let nesting=1,seen=0;while(this.at<this.end){let ch=this.text[this.at++];if(++seen>1048576)invalid('PDF 字符串过长');if(ch==='\\'){if(this.at>=this.end)invalid();ch=this.text[this.at++];if(ch==='\r'&&this.text[this.at]==='\n')this.at++;else if(/[0-7]/.test(ch))for(let i=0;i<2&&this.at<this.end&&/[0-7]/.test(this.text[this.at]);i++)this.at++;continue;}if(ch==='('&&++nesting>MAX_DEPTH)invalid();if(ch===')'&&--nesting===0)return {kind:'string'};}return invalid();}
  if(c==='<'&&this.text[this.at+1]!=='<'){this.at++;let seen=0;while(this.at<this.end){const ch=this.text[this.at++];if(ch==='>')return {kind:'string'};if(!ws(ch)&&!/^[a-f\d]$/i.test(ch))invalid();if(++seen>2097152)invalid('PDF 字符串过长');}return invalid();}
  if(c==='['){this.at++;const values:Value[]=[];while(true){this.skip();if(this.text[this.at]===']'){this.at++;return {kind:'array',values};}if(values.length>=10000)invalid('PDF 数组过长');values.push(this.value(depth+1));}}
  if(c==='<'&&this.text[this.at+1]==='<'){this.at+=2;const values=new Map<string,Value>();while(true){this.skip();if(this.text.startsWith('>>',this.at)){this.at+=2;return {kind:'dict',values};}if(this.text[this.at]!=='/'||values.size>=2048)invalid();const key=this.name().value;if(values.has(key))invalid('PDF 字典存在重复或转义后重复的键');values.set(key,this.value(depth+1));}}
  for(const [word,value] of [['true',true],['false',false],['null',null]] as const)if(this.keyword(word))return value;
  const match=/^[+-]?(?:\d+\.\d*|\.\d+|\d+)/.exec(this.text.slice(this.at,Math.min(this.end,this.at+128)));if(!match||!delimiter(this.text[this.at+match[0].length]))invalid();
  this.at+=match[0].length;const number=Number(match[0]);if(!Number.isFinite(number)||Math.abs(number)>Number.MAX_SAFE_INTEGER)invalid();const after=this.at;
  if(/^\d+$/.test(match[0])){this.skip();const second=/^\d+/.exec(this.text.slice(this.at,Math.min(this.end,this.at+32)));if(second&&delimiter(this.text[this.at+second[0].length])){this.at+=second[0].length;if(this.keyword('R')){const generation=Number(second[0]);if(number<1||generation>65534)invalid('PDF 间接引用无效');const reference:Ref={kind:'ref',id:number,generation};this.budget.refs.push(reference);return reference;}}}
  this.at=after;return number;
 }
}
function dictionary(v:Value|undefined):Dict{if(!is<Dict>(v,'dict'))invalid();return v;}
function reference(v:Value|undefined):Ref{if(!is<Ref>(v,'ref'))invalid();return v;}
function named(v:Value|undefined,value:string){return is<Name>(v,'name')&&v.value===value;}

export function validateStaticPdf(bytes:Uint8Array):{pages:number;objects:number}{
 if(bytes.byteLength<32||bytes.byteLength>MAX_BYTES)invalid();const text=latin1(bytes);
 if(!/^%PDF-(?:1\.[0-7]|2\.0)[\r\n]/.test(text))invalid('PDF 文件头无效');
 if(/<\?(?:php|=)|<%[=@]/i.test(text))invalid('PDF 含服务端脚本标记');
 const tail=/startxref[\x00\t\n\f\r ]+(\d+)[\x00\t\n\f\r ]+%%EOF[\x00\t\n\f\r ]*$/.exec(text.slice(-2048));if(!tail)invalid('PDF 缺少有效的文件尾部与交叉引用地址');
 const tailAt=text.length-Math.min(text.length,2048)+tail.index,xrefAt=Number(tail[1]);
 if(!Number.isSafeInteger(xrefAt)||xrefAt<9||xrefAt>=tailAt||text.slice(xrefAt,xrefAt+4)!=='xref')invalid('仅支持带有效传统 xref 表的 PDF；请重新导出，关闭增量更新和对象流');
 const budget=new Budget(),parser=new Parser(text,xrefAt,tailAt,budget),entries=new Map<number,Entry>();parser.expect('xref');
 while(true){if(parser.keyword('trailer'))break;const first=parser.uint(),count=parser.uint();if(count<1||first+count>MAX_OBJECTS+1||entries.size+count>MAX_OBJECTS+1)invalid('PDF 交叉引用表过大或无效');parser.skip();
  for(let n=0;n<count;n++){
   const entry=/^(\d{10}) (\d{5}) ([nf])(?:\r\n| \r| \n)/.exec(text.slice(parser.at,parser.at+20));if(!entry||entry[0].length!==20||parser.at+20>tailAt)invalid('PDF 交叉引用记录无效');parser.at+=20;
   const id=first+n,offset=Number(entry[1]),generation=Number(entry[2]),inUse=entry[3]==='n';
   if(entries.has(id)||generation>65535||inUse&&(id===0||generation===65535||offset<9||offset>=xrefAt))invalid('PDF 交叉引用记录重复或越界');entries.set(id,{id,offset,generation,inUse});
  }
 }
 const trailer=dictionary(parser.value());parser.skip();if(parser.at!==tailAt)invalid('不支持增量或混合交叉引用 PDF，请重新导出');
 for(const key of trailer.values.keys())if(!['Size','Root','Info','ID'].includes(key))invalid('不支持该 PDF trailer 扩展或增量更新，请导出普通 PDF');
 const size=trailer.values.get('Size');if(typeof size!=='number'||!Number.isSafeInteger(size)||size!==entries.size||size<2)invalid('PDF Size 与交叉引用表不一致');
 for(let i=0;i<size;i++)if(!entries.has(i))invalid('PDF 交叉引用缺少对象记录');
 const zero=entries.get(0)!;if(zero.inUse||zero.generation!==65535)invalid('PDF 保留对象记录无效');
 for(const entry of entries.values())if(!entry.inUse&&(entry.offset>=size||entries.get(entry.offset)?.inUse))invalid('PDF 空闲对象链无效');
 const used=[...entries.values()].filter(e=>e.inUse).sort((a,b)=>a.offset-b.offset);if(!used.length)invalid();
 for(let i=1;i<used.length;i++)if(used[i-1].offset===used[i].offset)invalid('PDF 对象地址重复');
 const prefix=new Parser(text,0,used[0].offset,budget);prefix.skip();if(prefix.at!==prefix.end)invalid('PDF 包含未索引的前置对象');
 const ends=new Map(used.map((entry,i)=>[entry.id,used[i+1]?.offset??xrefAt])),objects=new Map<number,ObjectValue>(),parsing=new Set<number>();
 const parseObject=(id:number,recursion=0):ObjectValue=>{
  const cached=objects.get(id);if(cached)return cached;if(recursion>MAX_DEPTH||parsing.has(id))invalid('PDF stream Length 引用循环或过深');const entry=entries.get(id);if(!entry?.inUse)invalid('PDF 引用了不存在的对象');parsing.add(id);
  const objectParser=new Parser(text,entry.offset,ends.get(id)!,budget);if(!/^\d/.test(text[objectParser.at]))invalid('PDF 对象地址未指向对象头');if(objectParser.uint()!==entry.id||objectParser.uint()!==entry.generation)invalid('PDF 对象编号或代数与索引不一致');objectParser.expect('obj');
  const value=objectParser.value();let stream=false;
  if(objectParser.keyword('stream')){
   const dict=dictionary(value);if(dict.values.has('F')||dict.values.has('FFilter')||dict.values.has('FDecodeParms'))invalid('PDF 不允许外部文件数据流');
   let length=dict.values.get('Length');if(is<Ref>(length,'ref')){const target=entries.get(length.id);if(!target?.inUse||target.generation!==length.generation)invalid('PDF stream Length 引用无效');const resolved=parseObject(length.id,recursion+1);if(resolved.stream)invalid();length=resolved.value;}
   if(typeof length!=='number'||!Number.isSafeInteger(length)||length<0||length>MAX_BYTES)invalid('PDF stream Length 无效');
   if(text.startsWith('\r\n',objectParser.at))objectParser.at+=2;else if(text[objectParser.at]==='\n')objectParser.at++;else invalid('PDF stream 缺少规定的换行');
   objectParser.at+=length;if(objectParser.at>objectParser.end)invalid('PDF 数据流越过对象边界');
   if(text.startsWith('\r\n',objectParser.at))objectParser.at+=2;else if(['\r','\n'].includes(text[objectParser.at]))objectParser.at++;else if(!['\r','\n'].includes(text[objectParser.at-1]))invalid('PDF endstream 缺少换行分隔');
   if(!text.startsWith('endstream',objectParser.at))invalid('PDF 数据流长度与结束位置不符');objectParser.expect('endstream');stream=true;
  }
  objectParser.expect('endobj');objectParser.skip();if(objectParser.at!==objectParser.end)invalid('PDF 对象尾部包含未索引或无法识别的内容');
  const result={value,stream};objects.set(id,result);parsing.delete(id);return result;
 };
 for(const entry of used)parseObject(entry.id);
 for(const ref of budget.refs){const target=entries.get(ref.id);if(!target?.inUse||target.generation!==ref.generation)invalid('PDF 间接引用指向不存在的对象或错误代数');}
 const deref=(value:Value|undefined):Value|undefined=>{if(!is<Ref>(value,'ref'))return value;const target=entries.get(value.id);if(!target?.inUse||target.generation!==value.generation)invalid();return objects.get(value.id)!.value;};
 const plainDict=(ref:Ref)=>{const entry=entries.get(ref.id),object=objects.get(ref.id);if(!entry?.inUse||entry.generation!==ref.generation||!object||object.stream)invalid();return dictionary(object.value);};
 const catalog=plainDict(reference(trailer.values.get('Root')));if(!named(catalog.values.get('Type'),'Catalog'))invalid('PDF Root 不是有效的 Catalog');
 if(trailer.values.has('Info'))plainDict(reference(trailer.values.get('Info')));
 const pagesRoot=reference(catalog.values.get('Pages')),seen=new Set<number>();let pages=0;
 const box=(value:Value|undefined)=>{const actual=deref(value);if(!is<Arr>(actual,'array')||actual.values.length!==4||!actual.values.every(n=>typeof n==='number'&&Number.isFinite(n)&&Math.abs(n)<=1_000_000))invalid('PDF 页尺寸无效');const a=actual.values as number[];if(a[2]<=a[0]||a[3]<=a[1])invalid('PDF 页尺寸无效');};
 const contents=(value:Value|undefined)=>{if(value===undefined||value===null)return;const array=deref(value);if(is<Arr>(array,'array')){for(const item of array.values){const ref=reference(item);if(!objects.get(ref.id)?.stream)invalid('PDF 页面内容不是数据流');}}else{const ref=reference(value);if(!objects.get(ref.id)?.stream)invalid('PDF 页面内容不是数据流');}};
 const walk=(ref:Ref,parent:Ref|null,inherited:{mediaBox?:Value;resources?:Value},depth:number):number=>{
  if(depth>MAX_DEPTH||seen.has(ref.id))invalid('PDF 页树循环、重复或嵌套过深');seen.add(ref.id);const dict=plainDict(ref),values=dict.values;
  if(parent){const actual=reference(values.get('Parent'));if(actual.id!==parent.id||actual.generation!==parent.generation)invalid('PDF 页树 Parent 与 Kids 不一致');}else if(values.has('Parent'))invalid('PDF 页树根节点不应有 Parent');
  const next={mediaBox:values.get('MediaBox')??inherited.mediaBox,resources:values.get('Resources')??inherited.resources};
  if(named(values.get('Type'),'Pages')){const kids=deref(values.get('Kids')),count=values.get('Count');if(!is<Arr>(kids,'array')||!kids.values.length||kids.values.length>MAX_PAGES||typeof count!=='number'||!Number.isSafeInteger(count)||count<1||count>MAX_PAGES)invalid('PDF 页树 Kids 或 Count 无效');let total=0;for(const kid of kids.values)total+=walk(reference(kid),ref,next,depth+1);if(total!==count)invalid('PDF 页树 Count 与真实页数不一致');return total;}
  if(!named(values.get('Type'),'Page')||parent===null||++pages>MAX_PAGES)invalid('PDF 缺少真实页面或超过页数限制');box(next.mediaBox);dictionary(deref(next.resources));if(values.has('CropBox'))box(values.get('CropBox'));contents(values.get('Contents'));return 1;
 };
 walk(pagesRoot,null,{},0);if(!pages)invalid('PDF 不包含可用页面');return {pages,objects:used.length};
}
