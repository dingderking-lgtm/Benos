import type { Env } from '../env';
import { assert,AppError } from './errors';
import { id,sha256 } from './crypto';

export const EDIT_MAX_BYTES=10*1048576,EDIT_TTL_MS=24*3600000,EDIT_LEASE_MS=240000;
export type EditWorkspace={id:string;user_id:string;project_id:string;base_version_id:string;source_hash:string;request_key:string;request_hash:string;scope_json:string;state:string;revision:number;blueprint_object_id:string|null;assets_json:string;selection_json:string|null;validated_revision:number|null;candidate_id:string|null;lease_token:string|null;lease_until_ms:number|null;expires_at_ms:number;created_at:string;updated_at:string};
export type EditObject={id:string;workspace_id:string;logical_key:string;object_key:string;sha256:string;byte_size:number;kind:'blueprint'|'file'|'response'|'tool'|'validation';state:string;created_at:string;updated_at:string};
const encoder=new TextEncoder(),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:false});
export const editNowSql="CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)";
export const editPermissionSql=`EXISTS(SELECT 1 FROM users u JOIN projects p ON p.user_id=u.id WHERE u.id=w.user_id AND u.status='active' AND p.id=w.project_id AND p.archived_at IS NULL) AND NOT EXISTS(SELECT 1 FROM user_restrictions r WHERE r.user_id=w.user_id AND r.scope='ai' AND r.revoked_at IS NULL AND r.starts_at<=strftime('%Y-%m-%dT%H:%M:%fZ','now') AND (r.ends_at IS NULL OR r.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now')))`;
export function editObjectKey(w:Pick<EditWorkspace,'user_id'|'project_id'|'id'>,objectId:string,digest:string){return `private/users/${encodeURIComponent(w.user_id)}/projects/${encodeURIComponent(w.project_id)}/edit-workspaces/${w.id}/objects/${objectId}/${digest}`;}
export async function ownedEditWorkspace(env:Env,userId:string,workspaceId:string,mutable=false){
 const w=await env.DB.prepare('SELECT * FROM design_edit_workspaces WHERE id=? AND user_id=?').bind(workspaceId,userId).first<EditWorkspace>();assert(w,'NOT_FOUND','编辑工作区不存在',404);
 assert(await env.DB.prepare(`SELECT 1 FROM design_edit_workspaces w WHERE w.id=? AND ${editPermissionSql}`).bind(w.id).first(),'FORBIDDEN','账户或项目当前不能编辑',403);
 if(mutable)assert(['preparing','ready'].includes(w.state)&&w.expires_at_ms>Date.now(),'EDIT_WORKSPACE_CLOSED','编辑工作区已关闭或到期，原版本保持不变',409);return w;
}
export function editGuard(env:Env,w:EditWorkspace,guardId:string,options:{revision?:number;lease?:string;state?:string;head?:boolean}={}){
 return env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM design_edit_workspaces w WHERE w.id=? AND w.state IN ('preparing','ready') AND w.expires_at_ms>${editNowSql} AND ${editPermissionSql} ${options.revision===undefined?'':'AND w.revision=?'} ${options.lease?'AND w.lease_token=? AND w.lease_until_ms>'+editNowSql:''} ${options.state?'AND w.state=?':''} ${options.head?'AND EXISTS(SELECT 1 FROM projects p WHERE p.id=w.project_id AND p.current_version_id=w.base_version_id)':''}) THEN 1 ELSE 0 END`).bind(guardId,w.id,...(options.revision===undefined?[]:[options.revision]),...(options.lease?[options.lease]:[]),...(options.state?[options.state]:[]));
}
export async function readEditObject(env:Env,w:EditWorkspace,objectId:string){
 const row=await env.DB.prepare('SELECT * FROM design_edit_objects WHERE id=? AND workspace_id=?').bind(objectId,w.id).first<EditObject>();assert(row&&row.state==='ready','EDIT_OBJECT_UNAVAILABLE','编辑数据尚未持久确认',503);
 assert(row.object_key===editObjectKey(w,row.id,row.sha256),'EDIT_OBJECT_IDENTITY','编辑数据归属校验失败',503);assert(env.BUCKET,'DESIGN_STORAGE_NOT_CONFIGURED','私有存储尚未配置',503);
 const object=await env.BUCKET.get(row.object_key);assert(object&&object.size===row.byte_size,'EDIT_OBJECT_CORRUPT','编辑数据长度校验失败',503);const bytes=new Uint8Array(await object.arrayBuffer());assert(bytes.length===row.byte_size&&await sha256(bytes)===row.sha256,'EDIT_OBJECT_CORRUPT','编辑数据摘要校验失败',503);
 try{return decoder.decode(bytes);}catch{throw new AppError('EDIT_OBJECT_CORRUPT','编辑数据编码无效',503);}
}
/** A committed R2 response may outlive a lost D1 ready acknowledgement. Recover
 * only that exact immutable intent; this never contacts the AI provider. */
export async function recoverEditObject(env:Env,w:EditWorkspace,logicalKey:string){
 const row=await env.DB.prepare('SELECT * FROM design_edit_objects WHERE workspace_id=? AND logical_key=?').bind(w.id,logicalKey).first<EditObject>();if(!row||!['staging','ready'].includes(row.state))return null;
 if(row.state==='ready')return row;assert(row.object_key===editObjectKey(w,row.id,row.sha256),'EDIT_OBJECT_IDENTITY','编辑记录归属错误',503);assert(env.BUCKET,'DESIGN_STORAGE_NOT_CONFIGURED','私有存储尚未配置',503);const object=await env.BUCKET.get(row.object_key);if(!object)return null;assert(object.size===row.byte_size&&await sha256(new Uint8Array(await object.arrayBuffer()))===row.sha256,'EDIT_OBJECT_CORRUPT','原结果副本校验失败',503);
 const guard=id('guard');await env.DB.batch([editGuard(env,w,guard),env.DB.prepare("UPDATE design_edit_objects SET state='ready',updated_at=? WHERE id=? AND state='staging'").bind(new Date().toISOString(),row.id),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)]);return {...row,state:'ready'};
}
export async function putEditObject(env:Env,w:EditWorkspace,logicalKey:string,kind:EditObject['kind'],text:string){
 assert(env.BUCKET,'DESIGN_STORAGE_NOT_CONFIGURED','私有存储尚未配置',503);const bytes=encoder.encode(text);assert(bytes.length<=EDIT_MAX_BYTES,'EDIT_FILE_TOO_LARGE','单个编辑对象超过安全容量',413);
 const digest=await sha256(bytes),now=new Date().toISOString();let row=await env.DB.prepare('SELECT * FROM design_edit_objects WHERE workspace_id=? AND logical_key=?').bind(w.id,logicalKey).first<EditObject>();
 if(!row){const objectId=id('editobj'),guard=id('guard');await env.DB.batch([
  editGuard(env,w,guard),
  env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN (SELECT COALESCE(SUM(byte_size),0) FROM design_edit_objects WHERE workspace_id=? AND state<>'purged')+?<=134217728 AND (SELECT COALESCE(SUM(o.byte_size),0) FROM design_edit_objects o JOIN design_edit_workspaces x ON x.id=o.workspace_id WHERE x.user_id=? AND x.state<>'purged' AND o.state<>'purged')+?<=268435456 THEN 1 ELSE 0 END`).bind(guard+'quota',w.id,bytes.length,w.user_id,bytes.length),
  env.DB.prepare('INSERT INTO design_edit_objects(id,workspace_id,logical_key,object_key,sha256,byte_size,kind,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(workspace_id,logical_key) DO NOTHING').bind(objectId,w.id,logicalKey,editObjectKey(w,objectId,digest),digest,bytes.length,kind,now,now),
  env.DB.prepare('DELETE FROM mutation_guards WHERE id IN (?,?)').bind(guard,guard+'quota')]);row=await env.DB.prepare('SELECT * FROM design_edit_objects WHERE workspace_id=? AND logical_key=?').bind(w.id,logicalKey).first<EditObject>();}
 assert(row&&row.sha256===digest&&row.byte_size===bytes.length&&row.kind===kind,'IDEMPOTENCY_CONFLICT','原编辑操作已对应其他内容',409);
 assert(['staging','ready'].includes(row.state),'EDIT_OBJECT_CLOSED','编辑对象已进入清理',409);
 if(row.state==='ready'){await readEditObject(env,w,row.id);return row;}
 const checkStored=async()=>{const existing=await env.BUCKET!.get(row!.object_key);assert(existing&&existing.size===bytes.length&&await sha256(new Uint8Array(await existing.arrayBuffer()))===digest,'EDIT_OBJECT_UNCONFIRMED','原编辑数据写入结果待确认',503);};
 try{const saved=await env.BUCKET.put(row.object_key,bytes,{onlyIf:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'text/plain; charset=utf-8',cacheControl:'private, no-store'},customMetadata:{sha256:digest}});if(!saved)await checkStored();}catch(error){try{await checkStored();}catch{throw error;}}
 const guard=id('guard');await env.DB.batch([editGuard(env,w,guard),env.DB.prepare("UPDATE design_edit_objects SET state='ready',updated_at=? WHERE id=? AND state='staging'").bind(now,row.id),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)]);
 const verified=await env.DB.prepare("SELECT * FROM design_edit_objects WHERE id=? AND state='ready'").bind(row.id).first<EditObject>();assert(verified,'EDIT_OBJECT_UNCONFIRMED','编辑数据未完成确认',503);return verified;
}
