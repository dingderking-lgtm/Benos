import { parseFragment } from 'parse5';

/** PDF documents are downloadable attachments, never visual media. This runs
 * before saving or importing a candidate, alongside native CMS checks. */
export function pdfVisualReferences(manifest:unknown):string[] {
 if(!manifest||typeof manifest!=='object')return [];
 const assets=(manifest as {assets?:unknown}).assets;if(!Array.isArray(assets))return [];
 const pdf=assets.filter(a=>a&&typeof a==='object'&&typeof a.file==='string'&&a.file.endsWith('.pdf'));
 if(!pdf.length)return [];
 const paths=pdf.map(a=>a.path).filter((p):p is string=>typeof p==='string'),ids=new Set(pdf.map(a=>String(a.media_id||'')).filter(Boolean)),issues:string[]=[];
 const normal=(value:string)=>{let text=value;try{text=decodeURIComponent(text);}catch{}return text.replace(/\\([\da-f]{1,6})\s?/gi,(_,digits)=>{const n=parseInt(digits,16);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'\ufffd';}).replace(/\\([^\r\n])/g,'$1');};
 const refers=(value:string)=>paths.some(path=>normal(value).includes(path));
 const visit=(value:unknown,path:string,key:string,depth=0)=>{
  if(issues.length>=100||depth>64)return;
  if(typeof value==='string'){
   if(/^(?:html|content)$/i.test(key)&&value.includes('<')){
    const tree=parseFragment(value);const nodes=(node:any)=>{for(const attribute of node.attrs||[]){
     if((['src','srcset','poster','background','data-src','data-srcset','style'].includes(attribute.name)||node.tagName==='image'&&['href','xlink:href'].includes(attribute.name))&&refers(attribute.value))issues.push(path);
     if(['img','source','image'].includes(node.tagName)&&attribute.name==='data-media-id'&&ids.has(attribute.value))issues.push(path);
    }if(node.tagName==='style'&&refers((node.childNodes||[]).map((child:any)=>child.value||'').join('')))issues.push(path);for(const child of node.childNodes||[])nodes(child);if(node.content)nodes(node.content);};nodes(tree);
   }
   if(/^(?:css|customCss|global_css|style)$/i.test(key)&&refers(value))issues.push(path);
   if(/^(?:src|srcset|poster|background|background-image|data-src|data-srcset)$/i.test(key)&&refers(value))issues.push(path);
   if(/(?:^|[._\[])(?:logo(?:_url|_path)?|favicon|avatar|featured_image|og_image|background_image|poster)(?:[.\[]|$)/i.test(path)&&refers(value))issues.push(path);
   if(/^\s*[\[{]/.test(value)){try{visit(JSON.parse(value),path+'<json>','',depth+1);}catch{}}
  }else if(Array.isArray(value))value.forEach((item,index)=>visit(item,`${path}[${index}]`,String(index),depth+1));
  else if(value&&typeof value==='object')for(const [name,item]of Object.entries(value))visit(item,path+'.'+name,name,depth+1);
 };
 visit(manifest,'$','');return [...new Set(issues)].slice(0,100);
}
