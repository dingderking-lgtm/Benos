import { AppError } from './errors';

// Admission, not an in-memory job queue: durable callers retain their original
// step and retry later. Never wait while holding another large source document.
let active = false;
export async function withDesignMemoryBudget<T>(work:()=>Promise<T>):Promise<T> {
  if (active) throw new AppError('DESIGN_MEMORY_BUSY','正在处理另一份大型设计，请稍后继续原任务',503);
  active = true;
  try { return await work(); }
  finally { active = false; }
}
