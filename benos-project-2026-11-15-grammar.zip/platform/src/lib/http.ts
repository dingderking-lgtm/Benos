import type { Context } from 'hono';
import type { AuthContext, Env } from '../env';
import type { ZodType } from 'zod';
import { AppError } from './errors';
export type App = { Bindings: Env; Variables: { auth: AuthContext; requestId: string } };
export function ok(c: Context<App>, data: unknown, status: 200|201|202 = 200) { return c.json({ok:true,data},status); }
export async function body<T>(c: Context<App>, schema: ZodType<T>): Promise<T> {
  if(!c.req.header('content-type')?.toLowerCase().startsWith('application/json')) throw new AppError('CONTENT_TYPE','请使用 JSON 提交',415);
  const raw = await c.req.text();
  if(raw.length > 1024*1024) throw new AppError('REQUEST_TOO_LARGE','提交内容过大',413);
  let parsed: unknown;
  try { parsed=JSON.parse(raw); } catch { throw new AppError('INVALID_JSON','提交格式不正确'); }
  const validated=schema.safeParse(parsed);
  // Keep a schema's own Chinese message; never forward the schema library's English default text.
  if(!validated.success){const message=validated.error.issues[0]?.message;throw new AppError('VALIDATION',message&&/[一-鿿]/.test(message)?message:'请检查填写内容');}
  return validated.data;
}
