import { sha256 } from './crypto';
import { AppError } from './errors';
import type { SiteCompositionV2Snapshot } from './site-composer-v2';

export const V2_SNAPSHOT_STORAGE = 'forward-text-1' as const;
type ForwardText = { forwardText: 'html' | 'css' };
type StoredSnapshot = Omit<SiteCompositionV2Snapshot, 'templates'> & {
  templates: Array<Omit<SiteCompositionV2Snapshot['templates'][number], 'html' | 'css'> & { html: string | ForwardText; css: string | ForwardText }>;
};
type CompositionRecord = { snapshotStorage?: unknown; forwardManifestSha256?: unknown; forwardArgs?: any; snapshot?: any };
const invalid = (): never => { throw new AppError('BNX_FROZEN_MANIFEST_UNAVAILABLE', '原始组件布局或存储引用不完整，不能重新编译或重新生成图片', 409); };

/** Storage-only codec. Callers must supply the server-owned composedLayout
 * record, never model arguments or the mutable current manifest. */
export async function readCompositionForwardManifest(record: CompositionRecord): Promise<any> {
  if (record.snapshotStorage !== undefined && record.snapshotStorage !== V2_SNAPSHOT_STORAGE) invalid();
  const files = record.forwardArgs?.files;
  if (!Array.isArray(files) || files.length !== 1 || files[0]?.path !== 'manifest.json' || typeof files[0].content !== 'string') invalid();
  const content = files[0].content;
  if (record.snapshotStorage === V2_SNAPSHOT_STORAGE && (typeof record.forwardManifestSha256 !== 'string'
    || !/^[a-f0-9]{64}$/.test(record.forwardManifestSha256) || await sha256(content) !== record.forwardManifestSha256)) invalid();
  let manifest: any;
  try { manifest = JSON.parse(content); } catch { invalid(); }
  if (!Array.isArray(manifest?.templates)) invalid();
  const ids = new Set<number>();
  for (const template of manifest.templates) {
    if (!Number.isSafeInteger(template?.id) || template.id <= 0 || ids.has(template.id)
      || typeof template.document?.html !== 'string' || (template.document.css !== undefined && typeof template.document.css !== 'string')) invalid();
    ids.add(template.id);
  }
  return manifest;
}

/** Enable only while creating a NEW server-compiled v2 record. Old records
 * without this flag remain literal, including when they are replayed. */
export async function initializeV2SnapshotStorage<T extends CompositionRecord>(record: T): Promise<T> {
  if (record.snapshotStorage !== undefined || record.snapshot?.version !== 'site-compose-v2') invalid();
  await readCompositionForwardManifest(record);
  const next = { ...record, snapshotStorage: V2_SNAPSHOT_STORAGE, forwardManifestSha256: await sha256(record.forwardArgs.files[0].content) };
  return { ...next, snapshot: await storeCompositionSnapshot(next, record.snapshot) };
}

export async function storeCompositionSnapshot(record: CompositionRecord, snapshot: any): Promise<any> {
  if (record.snapshotStorage === undefined) return snapshot;
  const manifest = await readCompositionForwardManifest(record);
  if (snapshot?.version !== 'site-compose-v2' || !Array.isArray(snapshot.templates) || !snapshot.templates.length || snapshot.templates.length > 21) invalid();
  const ids = new Set<number>();
  const templates = snapshot.templates.map((template: any) => {
    const original = manifest.templates.find((entry: any) => entry.id === template.templateId);
    if (!original || ids.has(template.templateId) || typeof template.html !== 'string' || typeof template.css !== 'string') invalid();
    ids.add(template.templateId);
    const next = { ...template };
    for (const field of ['html', 'css'] as const) if (template[field] === (original.document[field] ?? '')) next[field] = { forwardText: field };
    return next;
  });
  return { ...snapshot, templates } satisfies StoredSnapshot;
}

export async function readCompositionSnapshot(record: CompositionRecord | null | undefined): Promise<any> {
  if (!record || record.snapshotStorage === undefined) return record?.snapshot ?? null;
  const manifest = await readCompositionForwardManifest(record), snapshot = record.snapshot;
  if (snapshot?.version !== 'site-compose-v2' || !Array.isArray(snapshot.templates) || !snapshot.templates.length || snapshot.templates.length > 21) invalid();
  const ids = new Set<number>();
  const templates = snapshot.templates.map((template: any) => {
    const original = manifest.templates.find((entry: any) => entry.id === template.templateId);
    if (!original || ids.has(template.templateId)) invalid();
    ids.add(template.templateId);
    const next = { ...template };
    for (const field of ['html', 'css'] as const) {
      const value = template[field];
      if (typeof value === 'string') continue;
      if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== 1 || value.forwardText !== field) invalid();
      next[field] = original.document[field] ?? '';
    }
    return next;
  });
  return { ...snapshot, templates };
}
