import type { DesignFoundation } from '../contracts/design-foundation';
import { COHERENCE_VERSION } from '../contracts/design-coherence';
import { IMAGE_SLOT_PROMPT_RESERVE_BYTES } from './image-layout';

type ImageDirectionOptions={section?:string;source?:'generated'|'uploaded';preserveExplicitDirection?:boolean;maxPromptBytes?:number};
type DirectionResult={prompt:string;applied:boolean;reason:'applied'|'legacy-profile'|'uploaded-asset'|'explicit-direction'|'insufficient-prompt-budget'};
const encoder=new TextEncoder();
/** Inspect the USER request, never the model's detailed image prompt. Negative
 * preferences alone do not opt out of the remaining shared art direction. */
export function userSpecifiesImageDirection(request:string):boolean{
 const text=request.normalize('NFKC').toLowerCase(),image=/(?:图片|配图|主图|照片|插图|插画|图像|原图|参考图|背景图|产品图|视觉图|画面|所有图|这些图|\b(?:images?|photos?|photographs?|illustrations?|pictures?|visuals?|artwork|hero image|reference images?)\b)/;
 const visual=/(?:#[a-f\d]{6}\b|黑白|单色|灰阶|[红黄蓝绿紫橙]色|暖色|冷色|色温|配色|品牌色|饱和|手绘|水彩|油画|像素|黏土|粘土|3d|三维|写实|纪实|胶片|扁平|线稿|剪纸|等距|等角|素描|漫画|卡通|赛博朋克|复古|科技感|科技风|工业风|\b(?:palette|colors?|colours?|monochrome|black and white|warm|cool|red|blue|green|yellow|purple|orange|watercolou?r|hand.drawn|pixel|clay|3d|photorealistic|documentary|film|flat|line art|isometric|sketch|cartoon|cyberpunk|retro|editorial|lighting)\b)/;
 const directive=/(?:用|采用|使用|保持|保留|按照|照着|遵循|必须|需要|想要|希望|要求|做成|画成|改成|改为|改用|统一|\b(?:use|using|keep|preserve|retain|make|want|must|should|match|follow|prefer|render|paint|draw)\b)/;
 const strictReference=/(?:严格参考|完全按照|完全按|照着原图|保留原图|保持原图|原图不变|不要(?:改动|改变|修改|重绘|替换)[^，,。.;；\n]{0,24}(?:照片|原图|图片)|(?:照片|原图|图片)[^，,。.;；\n]{0,16}不要(?:改动|改变|修改|重绘|替换)|\b(?:exactly (?:match|follow)|strictly (?:match|follow)|preserve (?:the )?(?:original|uploaded)|keep (?:the )?(?:original|uploaded)[^.;\n]{0,30}unchanged)\b)/;
 const preserveOriginal=/(?:不要(?:改动|改变|修改|重绘|替换)[^，,。.;；\n]{0,24}(?:照片|原图|图片)|(?:照片|原图|图片)[^，,。.;；\n]{0,16}不要(?:改动|改变|修改|重绘|替换))/;
 if(preserveOriginal.test(text))return true;
 let imageContext=false;
 for(const raw of text.split(/[，,。；;.!?！？\n]+/)){
  if(image.test(raw))imageContext=true;
  // Preservation was handled above; negative style suggestions alone do not
  // become the requested style.
  const clause=raw.replace(/(?:不要|不需要|无需|无须|避免|禁止|不能|别|不采用|不使用|不用|不必)[^，,。；;.!?！？\n]*/g,'').replace(/\b(?:do not|don't|dont|avoid|never|without|no|not)\b[^,;.!?\n]*/g,'').trim();
  if(image.test(clause)&&strictReference.test(clause))return true;
  // Structured image labels are explicit requests even without an imperative.
  const shortForm=/^(?:(?:所有|全部|整站|全站|这些)?(?:图片|配图|主图|照片|插图|插画|图像|背景图|产品图|视觉图|主视觉|画面)(?:的)?(?:风格|配色|色调|色温|光线|媒介|表现方式|视觉方向)?|(?:all |hero |background |product )?(?:images?|photos?|photographs?|illustrations?|pictures?|visuals?|artwork)(?:\s+(?:style|palette|colou?r|lighting|medium|direction))?)\s*[:=\u2014-]\s*(.+)$/.exec(clause);
  if(shortForm&&visual.test(shortForm[1])&&!/^(?:不是|非|不要|不用|无需|不需要|no\b|not\b|avoid\b|without\b)/.test(shortForm[1]))return true;
  if(!clause||!visual.test(clause)||!directive.test(clause))continue;
  if(image.test(clause))return true;
  if(imageContext&&!/(?:网站|页面|网页|按钮|背景色|\b(?:website|page|button|site|layout)\b)/.test(clause)&&/(?:改用|改成|改为|统一|\b(?:instead|switch|make them|keep them)\b)/.test(clause))return true;
 }
 return false;
}
/** Stable art direction for NEW generated assets, not an edit of existing media.
 * The workflow sets preserveExplicitDirection from the user's actual request,
 * never merely from how detailed the model made this image's subject prompt.
 * Old profiles are byte-for-byte unchanged, including image-job replay hashes. */
export function imagePromptWithVisualDirection(prompt:string,foundation:DesignFoundation|null,options:ImageDirectionOptions={}):DirectionResult{
 const skipped=(reason:DirectionResult['reason']):DirectionResult=>({prompt,applied:false,reason});
 if(options.source==='uploaded')return skipped('uploaded-asset');
 if(options.preserveExplicitDirection||foundation?.styleName==='自定义方向')return skipped('explicit-direction');
 if(!foundation||foundation.coherenceVersion!==COHERENCE_VERSION)return skipped('legacy-profile');
 const t=foundation.tokens,bg=foundation.frozenTheme?.brand_background??t.background,accent=foundation.frozenTheme?.brand_color??t.accent;
 const palette=[bg,t.surface,accent].filter((value,index,all)=>all.indexOf(value)===index).join(', ');
 const technology=['tech','dark'].includes(foundation.styleId),engineering=foundation.styleId==='industrial',editorial=['editorial','luxury','portfolio'].includes(foundation.styleId),natural=['warm','fresh'].includes(foundation.styleId);
 const light=technology?'restrained directional light with soft cool edge highlights':engineering?'controlled neutral studio light revealing materials and joints':editorial?'soft side light with gentle shadows':natural?'soft natural daylight with consistent warmth':'soft neutral light with controlled contrast';
 const motif=technology?'connected layers, routes or component relationships relevant to the subject':engineering?'material, mechanism and process relationships':editorial?'material detail, human scale and editorial framing':natural?'tactile material and organic relationships':'clear object relationships and purposeful negative space';
 // This framing applies equally to a hero and detail without prescribing the
 // same subject, crop, model medium or composition in every slot.
 const paletteDiscipline=foundation.version==='bnf-3'?' For invented scenes, use this palette consistently across every frame; exclude unrelated high-saturation accent colors. Preserve the actual colors of real products and supplied assets; never recolor evidence to fit the theme.':'';
 const suffix=`\n\nShared site art direction: palette ${palette}; ${light}; recurring motif: ${motif}. Keep the original subject, requested palette and medium. Use a distinct view for this frame; do not repeat the hero composition. Prefer an explanatory object or process over generic stock team portraits. This is an illustration, not evidence of real customers or a working product. Explicit user visual requirements and the frame geometry take priority.${paletteDiscipline}`;
 const max=options.maxPromptBytes??(4000-IMAGE_SLOT_PROMPT_RESERVE_BYTES);
 if(!Number.isSafeInteger(max)||max<1||encoder.encode(prompt+suffix).length>max)return skipped('insufficient-prompt-budget');
 return {prompt:prompt+suffix,applied:true,reason:'applied'};
}
