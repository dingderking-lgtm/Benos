import { parseFragment, type DefaultTreeAdapterMap } from 'parse5';
import { sitePlanSchema, validateSitePlanManifest, type SitePlan, type SitePlanBinding } from '../contracts/site-plan';
import type { ImageFramePlan } from './image-frame-plan';
import { prepareSiteLayout, validatePreparedImageCompletion, preparedImageOmissions, type PreparedImageCompletionReceipt, type PreparedImageRetention, type PreparedImageDispositions } from './prepared-site-layout';

export const SITE_IMAGE_ALLOCATION_VERSION='site-image-allocation-1' as const;
export const SITE_IMAGE_OMISSION_REASONS=['user-no-images','budget','no-owned-evidence','not-needed','generation-unavailable'] as const;
export type SiteImageOmissionReason=typeof SITE_IMAGE_OMISSION_REASONS[number];
export type SiteImageOmissionInput={pageKey:string;reason:SiteImageOmissionReason;explanation:string};
export type OwnedSiteImage={path:string;width:number;height:number;source?:'uploaded'|'generated'|'unknown'};
export type SiteImageAllocationIssue={code:string;severity:'error'|'warning';message:string;pageKey?:string;plannedKey?:string;frameId?:string};
type Exception={reason:SiteImageOmissionReason|'provider-failure'|'explicit-discard';explanation:string;submittedExplanation?:string};
export type SiteImagePageAllocation=SitePlanBinding&{minimum:number;ownedPaths:string[];frameIds:string[];requiredFrameIds:string[];exceptions:Exception[]};
export type SiteImageAllocation={version:typeof SITE_IMAGE_ALLOCATION_VERSION;maxImages:number;pages:SiteImagePageAllocation[];frames:{frameId:string;templateId:number;pageKeys:string[]}[]};
export type SitePageImageCoverage=SitePlanBinding&{need:'required'|'optional'|'none';minimum:number;preferred:number;ownedPaths:string[];plannedFrameIds:string[];successfulFrameIds:string[];failedFrameIds:string[];omittedFrameIds:string[];missing:number;status:'planned'|'covered'|'degraded'|'exempt'|'missing';exceptions:Exception[];evidence:'structural-owned-references'};
export type PrepareSiteImageAllocationInput={manifest:unknown;sitePlan:SitePlan;framePlan?:ImageFramePlan;ownedImages:readonly OwnedSiteImage[];maxImages:number;serverGenerationUnavailable?:boolean;omissions?:readonly SiteImageOmissionInput[]};
export type CheckSiteImageAllocationInput={manifest:unknown;sitePlan:SitePlan;allocation:SiteImageAllocation;framePlan?:ImageFramePlan;ownedImages:readonly OwnedSiteImage[];receipts?:readonly PreparedImageCompletionReceipt[];retention?:PreparedImageRetention;dispositions?:PreparedImageDispositions};
export type SiteImageAllocationResult={allocation:SiteImageAllocation|null;coverage:SitePageImageCoverage[];issues:SiteImageAllocationIssue[]};
type Element=DefaultTreeAdapterMap['element'];type Node=DefaultTreeAdapterMap['node'];
type Scan={frames:Map<string,{templateId:number;node:Element;hidden:boolean}[]>;images:Map<number,{src:string;frameId?:string;width?:string;height?:string}[]>};
const attribute=(node:Element,name:string)=>node.attrs.find(a=>!a.namespace&&a.name===name)?.value;
const failure=(code:string,message:string,page?:Partial<SitePlanBinding>,frameId?:string):SiteImageAllocationIssue=>({code,severity:'error',message,...(page?.plannedKey?{plannedKey:page.plannedKey}:{}),...(page?.pageKey?{pageKey:page.pageKey}:{}),...(frameId?{frameId}:{})});
const unique=(values:string[])=>[...new Set(values)];
function scanManifest(manifest:unknown):Scan {
 const templates=(manifest as any)?.templates;if(!Array.isArray(templates)||templates.length>200)throw Error('templates');
 const frames:Scan['frames']=new Map(),images:Scan['images']=new Map();let characters=0,visited=0;
 for(const template of templates){const html=template?.document?.html;if(!Number.isSafeInteger(template.id)||typeof html!=='string'||(characters+=html.length)>600000)throw Error('size');
  const stack:Array<{node:Node;hidden:boolean;frameId?:string}>=[{node:parseFragment(html),hidden:false}];
  while(stack.length){const current=stack.pop()!,node=current.node;if(++visited>30000)throw Error('nodes');let hidden=current.hidden,frameId=current.frameId;
   if('tagName'in node){hidden ||= ['header','footer','nav','template','svg','math','script','style'].includes(node.tagName)||node.attrs.some(a=>a.name==='hidden'||a.name==='inert'||/^data-(?:aacms|form|menu|template|placeholder)(?:-|$)/i.test(a.name))||attribute(node,'aria-hidden')==='true'||/(?:^|;)\s*(?:display\s*:\s*none|visibility\s*:\s*hidden)\s*(?:!important)?\s*(?:;|$)/i.test(attribute(node,'style')||'');
    const id=attribute(node,'id');if(id?.startsWith('bnf-image-')){frameId=id.slice(10);const locations=frames.get(frameId)||[];locations.push({templateId:template.id,node,hidden});frames.set(frameId,locations);}
    if(node.tagName==='img'&&!hidden){const src=attribute(node,'src');if(src){const list=images.get(template.id)||[];list.push({src,width:attribute(node,'width'),height:attribute(node,'height'),...(frameId?{frameId}:{})});images.set(template.id,list);}}
   }
   if('childNodes'in node)for(const child of node.childNodes)stack.push({node:child,hidden,frameId});
  }
 }return{frames,images};
}
function ownedMap(images:readonly OwnedSiteImage[]){
 if(!Array.isArray(images)||images.length>500)throw Error('assets');
 return new Map(images.filter(image=>image&&typeof image.path==='string'&&image.path.length<=4096&&Number.isFinite(image.width)&&Number.isFinite(image.height)&&image.width>=64&&image.height>=64).map(image=>[image.path,image]));
}
function pathsFor(scan:Scan,templateId:number,owned:Map<string,OwnedSiteImage>,evidence:'owned-only'|'concept-allowed'){
 return unique((scan.images.get(templateId)||[]).filter(image=>!image.frameId&&owned.has(image.src)&&(evidence!=='owned-only'||owned.get(image.src)!.source==='uploaded')).map(image=>image.src));
}
const explanation:Record<SiteImageOmissionReason,string>={
 'user-no-images':'用户明确不使用图片，本页以文字和原生内容呈现。',budget:'本次总图片额度不足以覆盖全部视觉位置，不追加收费图片。',
 'no-owned-evidence':'没有可确认适用于本页的真实素材，不生成冒充作品、案例或实拍证据的图片。','not-needed':'本页以信息和真实入口为主，不需要装饰图片。',
 'generation-unavailable':'服务器当前不能生成新图片；保留已有素材，以实际内容降级，不额外派发。',
};
function coverageRow(page:SiteImagePageAllocation,plan:SitePlan,phase:'prepare'|'completion',successful:string[]=[],failed:string[]=[],omitted:string[]=[],ownedPaths=page.ownedPaths):SitePageImageCoverage{
 const visual=plan.pages.find(item=>item.key===page.plannedKey)!.visual,missing=Math.max(0,page.minimum-ownedPaths.length-(phase==='prepare'?page.frameIds.length:successful.length));
 const exceptions=[...page.exceptions,...(failed.length?[{reason:'provider-failure' as const,explanation:'本页部分已派发图片未成功；如实降级，不自动重生。'}]:[]),...(omitted.length?[{reason:'explicit-discard' as const,explanation:'不适用的成功图片已明确记录原因并移除。'}]:[])];
 return{plannedKey:page.plannedKey,pageKey:page.pageKey,templateId:page.templateId,need:visual.need,minimum:page.minimum,preferred:visual.preferred,ownedPaths,plannedFrameIds:[...page.frameIds],successfulFrameIds:successful,failedFrameIds:failed,omittedFrameIds:omitted,missing,status:missing?'missing':failed.length||omitted.length?'degraded':phase==='prepare'&&page.frameIds.length?'planned':ownedPaths.length||successful.length?'covered':'exempt',exceptions,evidence:'structural-owned-references'};
}

/** Validate before any provider reservation. Only the caller's verified owned
 * asset list and server plan can establish coverage or an exception. This is
 * structural coverage, not image-subject or browser-visibility verification. */
export function prepareSiteImageAllocation(input:PrepareSiteImageAllocationInput):SiteImageAllocationResult{
 const issues:SiteImageAllocationIssue[]=[],coverage:SitePageImageCoverage[]=[];
 try{
  const plan=sitePlanSchema.parse(input.sitePlan),validation=validateSitePlanManifest(input.manifest,plan);issues.push(...validation.issues);
  if(!validation.valid)return{allocation:null,coverage,issues};
  if(!Number.isSafeInteger(input.maxImages)||input.maxImages<0||input.maxImages>8)throw Error('budget');
  const maxImages=Math.min(input.maxImages,plan.imageBudget.max),frames=input.framePlan?.frames||[],scan=scanManifest(input.manifest),owned=ownedMap(input.ownedImages);
  for(const id of scan.frames.keys())if(!frames.some(frame=>frame.id===id))issues.push(failure('SITE_IMAGE_FRAME_UNPLANNED','页面图框没有对应的收费前计划，不能把它当作已有图片覆盖。',undefined,id));
  if(frames.length>maxImages)issues.push(failure('SITE_IMAGE_BUDGET_EXCEEDED','整站计划图片超过本次总额度，不能为内页追加收费。'));
  if(frames.length&&(plan.imageBudget.generation==='disabled'||input.serverGenerationUnavailable))issues.push(failure('SITE_IMAGE_GENERATION_UNAVAILABLE','本次不允许派发新图片，请使用已有素材或内容降级。'));
  if(input.framePlan)issues.push(...prepareSiteLayout(input.manifest,input.framePlan).issues.map(issue=>({...issue,severity:'error' as const})));
  const assigned:SiteImageAllocation['frames']=[];
  for(const frame of frames){const locations=scan.frames.get(frame.id)||[],binding=locations.length===1?validation.bindings.find(binding=>binding.templateId===locations[0].templateId):null;
   if(!binding||locations[0].hidden){issues.push(failure('SITE_IMAGE_FRAME_PAGE_INVALID','每个生成图框须唯一归属规划中的可见正文页面，不能用隐藏内容或公共页头页脚代替内页图片。',undefined,frame.id));continue;}
   const page=plan.pages.find(page=>page.key===binding.plannedKey)!;
   if(page.visual.need==='none'||page.visual.max===0)issues.push(failure('SITE_IMAGE_NOT_REQUESTED','本页已明确无图或无需配图，不新增收费装饰图片。',binding,frame.id));
   if(page.visual.evidence==='owned-only')issues.push(failure('SITE_IMAGE_REAL_EVIDENCE_REQUIRED','本页需要真实作品或实拍素材，生成图不能冒充真实证据。',binding,frame.id));
   assigned.push({frameId:frame.id,templateId:binding.templateId,pageKeys:[binding.pageKey]});
  }
  const pages:SiteImagePageAllocation[]=validation.bindings.map(binding=>{
   const page=plan.pages.find(page=>page.key===binding.plannedKey)!,ownedPaths=pathsFor(scan,binding.templateId,owned,page.visual.evidence),exceptions:Exception[]=[];
   let minimum=page.visual.minimum;
   if(page.visual.exception==='user-no-images'&&(scan.images.get(binding.templateId)||[]).length)issues.push(failure('SITE_IMAGES_DISABLED','用户要求无图，不能继续放入正文图片。',binding));
   if(page.visual.exception)exceptions.push({reason:page.visual.exception,explanation:explanation[page.visual.exception]});
   if(page.visual.evidence==='owned-only'&&!ownedPaths.length){minimum=0;if(!exceptions.some(e=>e.reason==='no-owned-evidence'))exceptions.push({reason:'no-owned-evidence',explanation:explanation['no-owned-evidence']});}
   else if(minimum>ownedPaths.length&&(input.serverGenerationUnavailable||plan.imageBudget.generation==='disabled'&&owned.size===0)){
    minimum=ownedPaths.length;const reason=input.serverGenerationUnavailable?'generation-unavailable':'no-owned-evidence';exceptions.push({reason,explanation:explanation[reason]});
   }
   if(!minimum&&!exceptions.length&&page.visual.need!=='required')exceptions.push({reason:'not-needed',explanation:explanation['not-needed']});
   const frameIds=assigned.filter(frame=>frame.templateId===binding.templateId).map(frame=>frame.frameId);
   return{...binding,minimum,ownedPaths,frameIds,requiredFrameIds:[],exceptions};
  });
  // The frozen plan normally fits the cap already. A lower live cap never
  // creates extra paid work: one image favors the entry page; otherwise reserve
  // the required inner pages before discretionary extra homepage images.
  let remaining=maxImages;
  const ordered=[...pages].sort((a,b)=>maxImages<=1?Number(b.plannedKey===plan.entryPageKey)-Number(a.plannedKey===plan.entryPageKey):Number(a.plannedKey===plan.entryPageKey)-Number(b.plannedKey===plan.entryPageKey));
  for(const page of ordered){const required=Math.max(0,page.minimum-page.ownedPaths.length),allowed=Math.min(required,remaining);remaining-=allowed;
   if(allowed<required){page.minimum=page.ownedPaths.length+allowed;page.exceptions.push({reason:'budget',explanation:explanation.budget});}
   page.requiredFrameIds=page.frameIds.slice(0,allowed);
   if(page.frameIds.length<allowed)issues.push(failure('SITE_IMAGE_PAGE_UNCOVERED','必要页面缺少自己的图片或收费前图框，请在现有总额度内重新分配，不能把图片全部留给首页。',page));
   const visual=plan.pages.find(item=>item.key===page.plannedKey)!.visual;
   if(page.frameIds.length+page.ownedPaths.length>visual.max&&page.frameIds.length)issues.push(failure('SITE_IMAGE_PAGE_LIMIT','该页新增图框超过规划上限，请保留内页分配空间。',page));
  }
  const omissionKeys=new Set<string>();
  for(const page of pages){const visual=plan.pages.find(item=>item.key===page.plannedKey)!.visual;if(!visual.allowReuse&&page.ownedPaths.some(path=>pages.some(other=>other!==page&&other.ownedPaths.includes(path))))issues.push({code:'SITE_IMAGE_REUSE_ADVISORY',severity:'warning',plannedKey:page.plannedKey,pageKey:page.pageKey,message:'本页与其他页面复用了同一素材；尚未证明它符合本页不同内容职责，不把重复引用算作不同作品。'});}
  if(input.omissions!==undefined){if(!Array.isArray(input.omissions)||input.omissions.length>12)throw Error('omissions');
   for(const omission of input.omissions){const page=pages.find(page=>page.pageKey===omission?.pageKey||page.plannedKey===omission?.pageKey);
    if(!page||omissionKeys.has(page.pageKey)||!SITE_IMAGE_OMISSION_REASONS.includes(omission.reason)||typeof omission.explanation!=='string'||!omission.explanation.trim()||omission.explanation.length>300||!page.exceptions.some(exception=>exception.reason===omission.reason))issues.push(failure('SITE_IMAGE_EXCEPTION_DENIED','省略图片的理由与服务器规划、素材或额度不符，不能以“不需要”跳过必要产品视觉。',page));
    else{omissionKeys.add(page.pageKey);page.exceptions.find(exception=>exception.reason===omission.reason)!.submittedExplanation=omission.explanation.trim();}
   }
  }
  for(const page of pages)coverage.push(coverageRow(page,plan,'prepare'));
  return{allocation:issues.some(issue=>issue.severity==='error')?null:{version:SITE_IMAGE_ALLOCATION_VERSION,maxImages,pages,frames:assigned},coverage,issues};
 }catch{return{allocation:null,coverage,issues:[...issues,failure('SITE_IMAGE_ALLOCATION_INVALID','无法安全校验整站图片分配，尚未派发图片。')]};}
}

/** Use the frozen pre-charge map. Moving a homepage marker into an inner page
 * cannot satisfy the inner page's allocation after generation. */
export function checkSiteImageAllocation(input:CheckSiteImageAllocationInput):SiteImageAllocationResult{
 const issues:SiteImageAllocationIssue[]=[],coverage:SitePageImageCoverage[]=[];
 try{
  const plan=sitePlanSchema.parse(input.sitePlan),allocation=input.allocation,validation=validateSitePlanManifest(input.manifest,plan);issues.push(...validation.issues);
  if(!allocation||allocation.version!==SITE_IMAGE_ALLOCATION_VERSION||!Array.isArray(allocation.pages)||allocation.pages.length!==plan.pages.length||!Array.isArray(allocation.frames)||allocation.frames.length>8||!Number.isSafeInteger(allocation.maxImages)||allocation.maxImages<0||allocation.maxImages>8)throw Error('snapshot');
  const scan=scanManifest(input.manifest),owned=ownedMap(input.ownedImages),receipts=input.receipts||[],byReceipt=new Map(receipts.map(receipt=>[receipt.frameId,receipt]));
  if(byReceipt.size!==receipts.length||receipts.length!==allocation.frames.length||receipts.some(receipt=>typeof receipt.ok!=='boolean'||!allocation.frames.some(frame=>frame.frameId===receipt.frameId)))issues.push(failure('SITE_IMAGE_RECEIPTS_INVALID','图片回执必须逐项覆盖原整站分配且不能重复。'));
  if(allocation.frames.length){if(!input.framePlan)issues.push(failure('SITE_IMAGE_PLAN_REQUIRED','缺少原图框计划，不能确认页面图片归属。'));
   else{if(input.framePlan.frames.length!==allocation.frames.length||input.framePlan.frames.some(frame=>!allocation.frames.some(saved=>saved.frameId===frame.id)))issues.push(failure('SITE_IMAGE_PLAN_CHANGED','收费前图框计划不能在完成检查时更换。'));
    if(receipts.some(receipt=>receipt.ok)&&!input.retention)issues.push(failure('SITE_IMAGE_RETENTION_REQUIRED','成功图片缺少可信保留记录。'));
    issues.push(...validatePreparedImageCompletion(input.manifest,input.framePlan,input.retention,input.dispositions).map(issue=>({...issue,severity:'error' as const})));}
  }
  const omissions=input.framePlan&&input.retention?preparedImageOmissions(input.manifest,input.framePlan,input.retention,input.dispositions):[],omitted=new Set(omissions.map(item=>item.frameId));
  for(const saved of allocation.frames){const locations=scan.frames.get(saved.frameId)||[];if(locations.length>1||locations.some(location=>location.templateId!==saved.templateId))issues.push(failure('SITE_IMAGE_FRAME_MOVED','生成图框必须保留收费前的页面归属，不能移动首页图片来补内页。',{pageKey:saved.pageKeys[0]},saved.frameId));}
  for(const page of allocation.pages){const binding=validation.bindings.find(binding=>binding.plannedKey===page.plannedKey),planned=plan.pages.find(item=>item.key===page.plannedKey);
   if(!planned||!binding||binding.pageKey!==page.pageKey||binding.templateId!==page.templateId){issues.push(failure('SITE_IMAGE_PAGE_CHANGED','规划页面与原图片分配的映射已改变。',page));continue;}
   if(!Number.isSafeInteger(page.minimum)||page.minimum<0||page.minimum>8||!Array.isArray(page.frameIds)||!Array.isArray(page.requiredFrameIds)||page.requiredFrameIds.some(id=>!page.frameIds.includes(id)))throw Error('page snapshot');
   const ownedPaths=pathsFor(scan,page.templateId,owned,planned.visual.evidence),successful=page.frameIds.filter(id=>{const receipt=byReceipt.get(id);return receipt?.ok===true&&!omitted.has(id)&&(scan.frames.get(id)||[]).some(frame=>frame.templateId===page.templateId&&!frame.hidden)&&(scan.images.get(page.templateId)||[]).some(image=>image.frameId===id&&image.src===receipt.asset?.path&&image.width===String(receipt.width)&&image.height===String(receipt.height));}),failed=page.frameIds.filter(id=>byReceipt.get(id)?.ok===false),omittedHere=page.frameIds.filter(id=>omitted.has(id));
   const result=coverageRow(page,plan,'completion',successful,failed,omittedHere,ownedPaths);
   const explainedLoss=page.requiredFrameIds.filter(id=>failed.includes(id)||omitted.has(id)).length;
   if(result.missing>explainedLoss)issues.push(failure('SITE_IMAGE_COVERAGE_LOST','本页必要视觉缺失，且没有对应失败回执或明确弃用记录；不能静默略过内页图片。',page));
   else if(result.missing)result.status='degraded';
   coverage.push(result);
  }
  return{allocation,coverage,issues};
 }catch{return{allocation:null,coverage,issues:[...issues,failure('SITE_IMAGE_COMPLETION_INVALID','无法安全核对整站图片结果，请保留原分配与回执。')]};}
}
