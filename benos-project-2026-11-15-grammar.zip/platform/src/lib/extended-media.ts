import { SaxesParser } from 'saxes';
import { AppError } from './errors';
import { validateStaticPdf } from './pdf-static';

const MIB=1048576;
function invalid(message:string):never { throw new AppError('MEDIA_INVALID',message,422); }
const ascii=(bytes:Uint8Array,start:number,length:number)=>String.fromCharCode(...bytes.subarray(start,start+length));
export type ExtendedMedia={mimeType:'image/gif'|'image/svg+xml'|'application/pdf';extension:'gif'|'svg'|'pdf';width:number;height:number};

/** Decode LZW indices without allocating a canvas. Every frame must produce
 * exactly its declared pixels and reference its active colour table. */
function gifLzw(blocks:Uint8Array[],minimum:number,pixels:number,colours:number) {
 if(minimum<2||minimum>8)invalid('GIF 压缩字典无效');
 let block=0,at=0,buffer=0,bits=0,count=0;
 const clear=1<<minimum,end=clear+1,lengths=new Uint32Array(4096),first=new Uint16Array(4096);
 let next=end+1,width=minimum+1,previous=-1,cleared=false;
 for(let i=0;i<clear;i++){lengths[i]=1;first[i]=i;}
 const read=()=>{while(bits<width){while(block<blocks.length&&at===blocks[block].length){block++;at=0;}if(block===blocks.length)return -1;buffer|=blocks[block][at++]<<bits;bits+=8;}const code=buffer&((1<<width)-1);buffer>>>=width;bits-=width;return code;};
 while(true){const code=read();if(code<0)invalid('GIF 压缩像素已截断');
  if(code===clear){next=end+1;width=minimum+1;previous=-1;cleared=true;continue;}
  if(!cleared)invalid('GIF 缺少初始字典清除码');
  if(code===end){if(count!==pixels)invalid('GIF 实际像素数量与尺寸不符');return;}
  if(code>next||code===next&&previous<0||code<clear&&code>=colours)invalid('GIF 引用了无效字典或颜色');
  const size=code===next?lengths[previous]+1:lengths[code],head=code===next?first[previous]:first[code];
  if(!size||(count+=size)>pixels)invalid('GIF 实际解码超出声明像素');
  if(previous>=0&&next<4096){lengths[next]=lengths[previous]+1;first[next]=first[previous];next++;if(next===(1<<width)&&width<12)width++;}
  // A first colour of a newly built string is already validated through its
  // prefix; checking it also catches references to an uninitialised dictionary.
  if(head>=colours)invalid('GIF 颜色索引无效');previous=code;
 }
}
export function inspectGif(bytes:Uint8Array):ExtendedMedia {
 if(bytes.length<14||!/^GIF8[79]a$/.test(ascii(bytes,0,6)))invalid('GIF 文件头无效');
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.length),width=view.getUint16(6,true),height=view.getUint16(8,true);
 if(!width||!height||width>8192||height>8192||width*height>16_000_000)invalid('GIF 图片尺寸超过限制');
 let at=13,frames=0,totalPixels=0;
 const globalColours=bytes[10]&128?1<<((bytes[10]&7)+1):0;
 at+=globalColours*3;if(at>bytes.length)invalid('GIF 全局颜色表已截断');
 const subblocks=()=>{const parts:Uint8Array[]=[];while(at<bytes.length){const size=bytes[at++];if(size===0)return parts;if(at+size>bytes.length)invalid('GIF 数据块已截断');parts.push(bytes.subarray(at,at+size));at+=size;}return invalid('GIF 缺少数据块结束标志');};
 while(at<bytes.length){const marker=bytes[at++];
  if(marker===0x3b){if(!frames||at!==bytes.length)invalid('GIF 缺少图像或含尾部数据');return {mimeType:'image/gif',extension:'gif',width,height};}
  if(marker===0x21){const kind=bytes[at++];
   if(kind===0xf9){if(at+6>bytes.length||bytes[at]!==4||bytes[at+5]!==0||(bytes[at+1]&0xe0)||(bytes[at+1]>>2&7)>3)invalid('GIF 图形控制块无效');at+=6;}
   else if(kind===0xfe)subblocks();
   else if(kind===0xff){if(bytes[at++]!==11||at+11>bytes.length)invalid('GIF 扩展块无效');const application=ascii(bytes,at,11);at+=11;const parts=subblocks();if(!['NETSCAPE2.0','ANIMEXTS1.0'].includes(application)||parts.length!==1||parts[0].length!==3||parts[0][0]!==1)invalid('GIF 仅支持标准动画循环扩展');}
   else invalid('GIF 含不支持的扩展块');
   continue;
  }
  if(marker!==0x2c||at+9>bytes.length)invalid('GIF 图像记录无效');
  const left=view.getUint16(at,true),top=view.getUint16(at+2,true),w=view.getUint16(at+4,true),h=view.getUint16(at+6,true),packed=bytes[at+8];at+=9;
  if(!w||!h||left+w>width||top+h>height||(packed&0x18)||++frames>500||(totalPixels+=w*h)>32_000_000)invalid('GIF 帧尺寸、帧数或累计解码像素超过限制');
  const colours=packed&128?1<<((packed&7)+1):globalColours;if(!colours)invalid('GIF 缺少颜色表');
  if(packed&128)at+=colours*3;if(at>=bytes.length)invalid('GIF 颜色表已截断');const minimum=bytes[at++];gifLzw(subblocks(),minimum,w*h,colours);
 }
 return invalid('GIF 缺少结束标志');
}

const svgElements=new Set('svg g path rect circle ellipse line polyline polygon text tspan defs lineargradient radialgradient stop clippath mask title desc symbol use'.split(' '));
const svgAttributes=new Set('id viewbox width height x y x1 x2 y1 y2 cx cy r rx ry d points fill fill-rule fill-opacity stroke stroke-width stroke-linecap stroke-linejoin stroke-miterlimit stroke-dasharray stroke-dashoffset stroke-opacity opacity transform gradienttransform gradientunits offset stop-color stop-opacity font-family font-size font-weight text-anchor dominant-baseline preserveaspectratio clip-path mask maskunits cliprule href style'.split(' '));
const svgStyles=new Set('fill stroke stroke-width opacity fill-opacity stroke-opacity font-size font-weight text-anchor stop-color stop-opacity'.split(' '));
export function inspectSvg(bytes:Uint8Array):ExtendedMedia {
 if(bytes.length>MIB)invalid('SVG 最多 1 MiB，请简化图形后上传');
 let text:string;try{text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:false}).decode(bytes);}catch{return invalid('SVG 必须使用 UTF-8 编码');}
 if(/<!DOCTYPE|<!ENTITY|<\?(?!xml\s)|<\?(?:php|=)|<%[=@]/i.test(text))invalid('SVG 不允许 DTD、实体或处理指令');
 let nodes=0,depth=0,root:Record<string,string>|null=null;
 const parser=new SaxesParser({xmlns:true});
 parser.on('error',()=>invalid('SVG 不是有效的 XML 文档'));
 parser.on('doctype',()=>invalid('SVG 不允许 DTD'));
 parser.on('processinginstruction',()=>invalid('SVG 不允许处理指令'));
 parser.on('xmldecl',declaration=>{if(declaration.encoding&&!/^utf-8$/i.test(declaration.encoding))invalid('SVG 必须使用 UTF-8 编码');});
 parser.on('opentag',tag=>{
  if(++nodes>2500||++depth>64)invalid('SVG 节点数量或嵌套层数超过限制');
  if(!svgElements.has(tag.local.toLowerCase())||tag.uri&&tag.uri!=='http://www.w3.org/2000/svg')invalid('SVG 含不支持的元素');
  if(nodes===1){if(tag.local.toLowerCase()!=='svg')invalid('SVG 根节点无效');root={};}
  for(const attribute of Object.values(tag.attributes)){
   const key=attribute.local.toLowerCase(),value=attribute.value;
   if(attribute.uri==='http://www.w3.org/2000/xmlns/'){if(!['http://www.w3.org/2000/svg','http://www.w3.org/1999/xlink'].includes(value))invalid('SVG 命名空间不受支持');continue;}
   if(attribute.uri&&!(attribute.uri==='http://www.w3.org/1999/xlink'&&key==='href')||!svgAttributes.has(key)||value.length>100000)invalid('SVG 含不支持的属性');
   if(key==='href'&&!/^#[a-zA-Z_][\w.-]*$/.test(value))invalid('SVG 只能引用文档内的图形');
   if(/(?:javascript:|vbscript:|data:|https?:|@import|expression\s*\(|\\|\/\*)/i.test(value)||/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(value))invalid('SVG 不允许主动内容或外部资源');
   if(/url\s*\(/i.test(value)&&!/^url\(\s*#[a-zA-Z_][\w.-]*\s*\)$/i.test(value))invalid('SVG 只能使用内部渐变和蒙版');
   if(key==='style')for(const declaration of value.split(';')){if(!declaration.trim())continue;const split=declaration.indexOf(':'),property=declaration.slice(0,split).trim().toLowerCase(),v=declaration.slice(split+1).trim();if(split<1||!svgStyles.has(property)||!v||!/^[a-z0-9#.,%()\s-]+$/i.test(v))invalid('SVG 内联样式不受支持');}
   if(nodes===1)root![key]=value;
  }
 });
 parser.on('closetag',()=>{depth--;});
 try{parser.write(text).close();}catch(error){if(error instanceof AppError)throw error;return invalid('SVG XML 解析失败');}
 if(!root||depth!==0)invalid('SVG 文档无效');
 const attributes=root as Record<string,string>;
 const dimension=(value:string|undefined)=>value&&/^\s*(?:\d+(?:\.\d*)?|\.\d+)(?:px)?\s*$/.test(value)?parseFloat(value):0;
 let width=dimension(attributes.width),height=dimension(attributes.height);
 if(!width||!height){const viewBox=(attributes.viewbox||'').trim().split(/[\s,]+/).map(Number);if(viewBox.length===4&&viewBox.every(Number.isFinite)){width=viewBox[2];height=viewBox[3];}}
 if(!width||!height||width<=0||height<=0||width>8192||height>8192)invalid('SVG 需要有效的 width/height 或 viewBox，最大边长 8192');
 return {mimeType:'image/svg+xml',extension:'svg',width:Math.ceil(width),height:Math.ceil(height)};
}

/** This accepts ordinary, inspectable PDF downloads, never an embedded viewer.
 * Encrypted/object-stream documents are rejected because active dictionary keys
 * cannot be inspected safely without a complete PDF interpreter. */
export function inspectPdf(bytes:Uint8Array):ExtendedMedia {
 validateStaticPdf(bytes);
 return {mimeType:'application/pdf',extension:'pdf',width:0,height:0};
}
