import { z } from 'zod';
import { assert } from './errors';
import type { DesignFoundation } from '../contracts/design-foundation';
import { foundationContrast, foundationSurfaces, foundationTextColorTokens } from '../contracts/design-coherence';

/** Only persisted workflow requirements grant this capability. A manifest,
 * class name or CSS marker cannot opt an old task into a newer palette. */
export const COMPILED_BODY_PALETTE_VERSION = 'bnx-palette-1' as const;
const color = z.string().regex(/^#[a-f\d]{6}$/i);
const colorsSchema = z.object({background:color,surface:color,raised:color,text:color,muted:color,accent:color,accentText:color,border:color,dark:color,darkText:color}).strict();
const paletteSchema = z.object({preset:z.enum(['calm-paper','bold-signal','deep-studio']),colors:colorsSchema}).strict();
export type CompiledBodyPalette = z.infer<typeof paletteSchema>;
const START = '/* benos-compiled-body-palette:1:start */', END = '/* benos-compiled-body-palette:1:end */';
const ownBlock = /\/\* benos-compiled-body-palette:1:start \*\/[\s\S]*?\/\* benos-compiled-body-palette:1:end \*\//g;

/** The caller supplies an already trusted, server-created production plan. */
export function createCompiledBodyPalette(plan:unknown):CompiledBodyPalette|null {
 const p=plan as any;if(p?.version!=='bnx-generation-1')return null;
 const result=paletteSchema.safeParse({preset:p.preset,colors:p.tokens?.colors});
 return result.success?result.data:null;
}
/** Called only after the version lineage and frozen header were verified.
 * Pre-capability BNX sites upgrade only when starting a NEW whole-site edit. */
export function inheritCompiledBodyPalette(source:any,allowUpgrade:boolean):CompiledBodyPalette|null {
 if(source?.compiledBodyPolicy!=='bnx-owned-1')return null;
 if(source.compiledBodyPaletteVersion!==undefined){
  assert(source.compiledBodyPaletteVersion===COMPILED_BODY_PALETTE_VERSION,'COMPILED_PALETTE_INVALID','配色快照版本无效，不能隐式重建');
  const parsed=paletteSchema.safeParse(source.compiledBodyPalette);
  assert(parsed.success,'COMPILED_PALETTE_INVALID','配色快照不完整，不能隐式重建');return parsed.data;
 }
 return allowUpgrade?createCompiledBodyPalette(source.designSystemV2):null;
}
export function foundationWithCompiledBodyPalette(profile:DesignFoundation,palette:CompiledBodyPalette):DesignFoundation {
 const c=paletteSchema.parse(palette).colors;
 return {...profile,tokens:{...profile.tokens,background:c.background,surface:c.surface,ink:c.text,muted:c.muted,accent:c.accent,border:c.border}};
}
function readable(preferred:string,background:string){return foundationContrast(preferred,background)>=4.5?preferred:foundationContrast('#000000',background)>=foundationContrast('#ffffff',background)?'#000000':'#ffffff';}
function mix(a:string,b:string,amount:number){return '#'+[1,3,5].map(i=>Math.round(parseInt(a.slice(i,i+2),16)*(1-amount)+parseInt(b.slice(i,i+2),16)*amount).toString(16).padStart(2,'0')).join('');}

/** New flagged tasks only. Retain valid user theme values and authored inline
 * colors; the preset is a default, never a lock on subsequent user choices.
 * This bridge does not recolor compiler-owned BNX section styles. */
export function materializeCompiledBodyPalette<T>(input:T,requirements:any):T {
 if(requirements?.compiledBodyPaletteVersion===undefined)return input;
 assert(requirements.compiledBodyPolicy==='bnx-owned-1'&&requirements.compiledBodyPaletteVersion===COMPILED_BODY_PALETTE_VERSION,'COMPILED_PALETTE_INVALID','配色快照版本或来源无效');
 const parsed=paletteSchema.safeParse(requirements.compiledBodyPalette);
 assert(parsed.success,'COMPILED_PALETTE_INVALID','配色快照不完整，不能隐式重建');
 const m=input as any,c=parsed.data.colors,theme=m?.site?.theme;
 assert(theme&&typeof theme.global_css==='string','COMPILED_PALETTE_FOUNDATION_REQUIRED','配色需要已冻结的基础样式');
 const blocks=[...theme.global_css.matchAll(/\/\* benos-foundation:(bnf-[123]):start \*\/[\s\S]*?\/\* benos-foundation:\1:end \*\//g)];
 assert(blocks.length===1,'COMPILED_PALETTE_FOUNDATION_REQUIRED','配色需要唯一的受信基础样式');
 const background=color.safeParse(theme.brand_background).success?theme.brand_background:c.background,accent=color.safeParse(theme.brand_color).success?theme.brand_color:c.accent;
 const changed=background.toLowerCase()!==c.background.toLowerCase(),ink=readable(c.text,background),muted=readable(c.muted,background);
 const palette={background,accent,ink,muted,surface:changed?mix(background,ink,.04):c.surface};
 const shades=foundationSurfaces(palette);
 // Use the exact reviewed base planes while deriving readable secondary
 // planes for a legitimate later background change.
 if(!changed){shades.raised={background:c.raised,ink:readable(ink,c.raised),muted:readable(muted,c.raised),line:c.border};shades.deep={background:c.dark,ink:readable(c.darkText,c.dark),muted:readable(muted,c.dark),line:c.border};}
 const surfaceTokens=Object.entries(shades).flatMap(([key,value])=>{const name=key.replace(/[A-Z]/g,x=>'-'+x.toLowerCase());return [`--bnf-${name}:${value.background}`,`--bnf-${name}-ink:${value.ink}`,`--bnf-${name}-muted:${value.muted}`,`--bnf-${name}-line:${value.line}`];});
 const css=`${START}\n:root{--bnf-bg:${background};--bnf-page-bg:${background};--bnf-surface:${palette.surface};--bnf-ink:${ink};--bnf-muted:${muted};--bnf-accent:${accent};--bnf-accent-ink:${readable(c.accentText,accent)};--bnf-line:${changed?mix(background,ink,.22):c.border};${surfaceTokens.join(';')}}\n${foundationTextColorTokens(palette,{tone:shades.tone.background,raised:shades.raised.background,deep:shades.deep.background,deepRaised:shades.deepRaised.background})}\n${END}\n`;
 const original=blocks[0][0],end=`/* benos-foundation:${blocks[0][1]}:end */`,clean=original.replace(ownBlock,'').replace(/\n+(?=\/\* benos-foundation:bnf-[123]:end \*\/)/,'\n');
 const updated=clean.replace(end,css+end),global_css=theme.global_css.replace(original,updated);
 return global_css===theme.global_css?input:{...m,site:{...m.site,theme:{...theme,global_css}}};
}
