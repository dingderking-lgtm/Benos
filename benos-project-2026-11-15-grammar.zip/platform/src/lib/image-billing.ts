import { z } from 'zod';
import { assert } from './errors';
import { inspectMediaBytes } from '../modules/media';
import { IMAGE_SIZES } from './image-layout';

const rate=z.number().int().min(0).max(1_000_000_000);
// Legacy unverified drafts remain readable; production requires the explicit
// metered reservation policy and the audited standard raster profiles below.
export const imageConfigSchema=z.object({
 baseUrl:z.string().url(),model:z.string().regex(/^[a-zA-Z0-9._:/-]{1,200}$/),protocol:z.literal('images'),providerPoolId:z.string().regex(/^[a-zA-Z0-9_-]{1,100}$/),
 size:z.enum(IMAGE_SIZES),quality:z.enum(['low','medium','high','xhigh','max']),complexity:z.enum(['low','medium','high']),n:z.literal(1),outputFormat:z.literal('png'),
 textInputMicrosPerMillion:rate,imageInputMicrosPerMillion:rate,cachedTextInputMicrosPerMillion:rate,cachedImageInputMicrosPerMillion:rate,imageOutputMicrosPerMillion:rate,
 pricingConfirmedAt:z.string().datetime(),billingContract:z.object({kind:z.enum(['unverified','metered-reserve-v1'])}).strict(),
}).strict().refine(c=>c.textInputMicrosPerMillion>0&&c.imageOutputMicrosPerMillion>0&&c.cachedTextInputMicrosPerMillion<=c.textInputMicrosPerMillion&&c.cachedImageInputMicrosPerMillion<=c.imageInputMicrosPerMillion,'图片计价无效');
export type ImagePricing=z.infer<typeof imageConfigSchema>;
export type FixtureImageContract={version:'fixture-v1';model:string;size:string;quality:string;complexity:string;maxPromptBytes:number;maxInputTextTokens:number;maxInputImageTokens:0;maxOutputImageTokens:number;cacheBilling:'uncached'|'reported-split-v1'};

export const SUPPORTED_IMAGE_MODELS=['gpt-image-2.6-sunburst','gpt-image-2.6-flare'] as const;
export const IMAGE_RESERVATION_MICROS=1_000_000;
export const IMAGE_MAX_PROMPT_BYTES=4000;
export type MeteredImageContract={version:'metered-reserve-v1';model:string;size:string;quality:string;complexity:string;maxPromptBytes:number;reservationMicros:number;reservationIsEstimate:true;cacheBilling:'uncached'};
export type ImageContract=FixtureImageContract|MeteredImageContract;

/** Official standard rates verified 2026-11-13:
 * https://developers.openai.com/api/docs/models/gpt-image-2.6-sunburst
 * https://developers.openai.com/api/docs/models/gpt-image-2.6-flare
 * https://developers.openai.com/api/reference/resources/images/methods/generate
 * Images has no max_output_tokens. The $1 reservation is an operating buffer,
 * NOT an OpenAI maximum, price estimate, or permission to overdraw the ledger.
 * Actual usage above the reservation remains held for reconciliation.
 */
export function verifiedImagePricing(value:unknown,provider='openai'):ImagePricing {
 const parsed=imageConfigSchema.safeParse(value);
 assert(parsed.success,'IMAGE_CONFIG_INVALID','图片计费配置无效',409);
 const pricing=parsed.data;
 assert(provider==='openai'&&pricing.baseUrl==='https://api.openai.com/v1'&&SUPPORTED_IMAGE_MODELS.includes(pricing.model as typeof SUPPORTED_IMAGE_MODELS[number]),'IMAGE_ADAPTER_UNSUPPORTED','请选择支持的 OpenAI 图片模型',409);
 assert(pricing.billingContract.kind==='metered-reserve-v1','IMAGE_BOUND_UNVERIFIED','图片生成尚未启用，请确认按用量结算的预占策略',409);
 assert(IMAGE_SIZES.includes(pricing.size)&&['low','medium'].includes(pricing.quality)&&pricing.complexity==='low','IMAGE_PROFILE_UNSUPPORTED','当前图片模型支持 low、medium 与三种标准尺寸',409);
 assert(pricing.textInputMicrosPerMillion===5_000_000&&pricing.cachedTextInputMicrosPerMillion===1_250_000&&pricing.imageInputMicrosPerMillion===8_000_000&&pricing.cachedImageInputMicrosPerMillion===2_000_000&&pricing.imageOutputMicrosPerMillion===30_000_000,'IMAGE_PRICING_MISMATCH','图片价格与当前已核验价目不一致',409);
 return pricing;
}
export function meteredImageContract(pricing:ImagePricing):MeteredImageContract {
 verifiedImagePricing(pricing);
 return {version:'metered-reserve-v1',model:pricing.model,size:pricing.size,quality:pricing.quality,complexity:pricing.complexity,maxPromptBytes:IMAGE_MAX_PROMPT_BYTES,reservationMicros:IMAGE_RESERVATION_MICROS,reservationIsEstimate:true,cacheBilling:'uncached'};
}
export function createImageRequest(pricing:ImagePricing,prompt:string){
 return {model:pricing.model,prompt,n:1 as const,size:pricing.size,quality:pricing.quality,complexity:pricing.complexity,output_format:'png' as const,background:'opaque' as const,stream:false,partial_images:0};
}
export function createImageTestRequest(value:unknown){const pricing=verifiedImagePricing(value);return createImageRequest(pricing,'A simple solid blue circle centered on a plain white background.');}
export function imageTestReservation(value:unknown){const pricing=verifiedImagePricing(value);return imageReservationCost(pricing,meteredImageContract(pricing));}
function number(value:unknown,max=2_000_000):number{assert(Number.isSafeInteger(value)&&Number(value)>=0&&Number(value)<=max,'IMAGE_USAGE_INVALID','图片用量暂无法确认',502);return Number(value);}
function micros(n:bigint){const result=(n+999999n)/1000000n;assert(result<=BigInt(Number.MAX_SAFE_INTEGER),'IMAGE_USAGE_INVALID','图片费用超出可核算范围',502);return Number(result);}
export function imageReservationCost(pricing:ImagePricing,contract:ImageContract){if(contract.version==='metered-reserve-v1')return contract.reservationMicros;return micros(BigInt(contract.maxInputTextTokens)*BigInt(pricing.textInputMicrosPerMillion)+BigInt(contract.maxInputImageTokens)*BigInt(pricing.imageInputMicrosPerMillion)+BigInt(contract.maxOutputImageTokens)*BigInt(pricing.imageOutputMicrosPerMillion));}
/** Direct Images API input modalities must be accounted for separately.
 * Cache discounts require an adapter contract AND separately reported counts;
 * totals cannot infer which tokens were cached. SVG/text output is unsupported. */
export function imageUsageCost(pricing:ImagePricing,usage:any,contract:ImageContract):number{
 assert(usage&&typeof usage==='object'&&!Array.isArray(usage),'IMAGE_USAGE_INVALID','图片响应缺少完整用量',502);
 const input=number(usage.input_tokens),output=number(usage.output_tokens),total=number(usage.total_tokens,4_000_000),details=usage.input_tokens_details;
 assert(details&&typeof details==='object','IMAGE_USAGE_INVALID','图片输入用量明细缺失',502);
 const text=number(details.text_tokens),images=number(details.image_tokens);assert(text+images===input&&total===input+output,'IMAGE_USAGE_INVALID','图片用量合计不一致',502);
 assert(images===0&&(contract.version!=='fixture-v1'||text<=contract.maxInputTextTokens&&output<=contract.maxOutputImageTokens),'IMAGE_CONTRACT_BREACH','图片用量包含未支持的类型或超出已核验范围，等待对账',502);
 let cachedText=0,cachedImages=0;
 if(contract.cacheBilling==='reported-split-v1'){
  const cached=details.cached_tokens_details;assert(cached&&typeof cached==='object','IMAGE_USAGE_INVALID','缓存用量明细缺失',502);cachedText=number(cached.text_tokens);cachedImages=number(cached.image_tokens);
  assert(number(details.cached_tokens)===cachedText+cachedImages,'IMAGE_USAGE_INVALID','缓存用量合计不一致',502);
 }else {
  assert(number(details.cached_tokens??0)===0&&number(details.cached_tokens_details?.text_tokens??0)===0&&number(details.cached_tokens_details?.image_tokens??0)===0,'IMAGE_PRICING_MISMATCH','当前合同不支持缓存折扣，等待对账',502);
 }
 assert(cachedText<=text&&cachedImages<=images,'IMAGE_USAGE_INVALID','缓存用量超出输入用量',502);
 if(usage.output_tokens_details)assert(number(usage.output_tokens_details.image_tokens)===output&&number(usage.output_tokens_details.text_tokens)===0,'IMAGE_PRICING_MISMATCH','图片响应包含未配置的输出类型',502);
 for(const key of Object.keys(usage))assert(['input_tokens','input_tokens_details','output_tokens','output_tokens_details','total_tokens'].includes(key),'IMAGE_USAGE_INVALID','图片响应包含未知计费类型',502);
 for(const key of Object.keys(details))assert(['text_tokens','image_tokens','cached_tokens','cached_tokens_details'].includes(key),'IMAGE_USAGE_INVALID','图片输入含未知计费明细',502);
 for(const extra of [details.cached_tokens_details,usage.output_tokens_details])if(extra)for(const key of Object.keys(extra))assert(['text_tokens','image_tokens'].includes(key),'IMAGE_USAGE_INVALID','图片用量包含未知计费明细',502);
 return micros(BigInt(text-cachedText)*BigInt(pricing.textInputMicrosPerMillion)+BigInt(cachedText)*BigInt(pricing.cachedTextInputMicrosPerMillion)+BigInt(images-cachedImages)*BigInt(pricing.imageInputMicrosPerMillion)+BigInt(cachedImages)*BigInt(pricing.cachedImageInputMicrosPerMillion)+BigInt(output)*BigInt(pricing.imageOutputMicrosPerMillion));
}

export function imageResponseUsage(pricing:ImagePricing,result:any,contract:ImageContract=meteredImageContract(pricing)){
 assert(result&&typeof result==='object'&&!Array.isArray(result)&&!result.svg_usage,'IMAGE_PRICING_MISMATCH','图片响应包含未支持的计费种类',502);
 assert(result.model===undefined||result.model===pricing.model,'IMAGE_PRICING_MISMATCH','图片模型与配置不一致',502);
 assert(result.output_format===undefined||result.output_format==='png','IMAGE_PRICING_MISMATCH','图片输出格式与配置不一致',502);
 assert(result.quality===undefined||result.quality===pricing.quality,'IMAGE_PRICING_MISMATCH','图片质量与配置不一致',502);
 assert(result.size===undefined||result.size===pricing.size,'IMAGE_PRICING_MISMATCH','图片尺寸与配置不一致',502);
 const actualMicros=imageUsageCost(pricing,result.usage,contract),metadata={created:result.created,model:result.model,quality:result.quality,size:result.size,output_format:result.output_format};
 return {actualMicros,usage:result.usage,metadata};
}
export async function imageResponseBytes(pricing:ImagePricing,result:any):Promise<Uint8Array>{
 assert(Array.isArray(result.data)&&result.data.length===1&&typeof result.data[0]?.b64_json==='string'&&!result.data[0].url,'IMAGE_OUTPUT_INVALID','图片输出不完整，已按实际用量结算',422);
 const encoded=result.data[0].b64_json,padding=encoded.endsWith('==')?2:encoded.endsWith('=')?1:0;
 assert(encoded.length>0&&encoded.length<=16*1024*1024&&encoded.length%4===0&&!/[^A-Za-z0-9+/=]/.test(encoded)&&!encoded.slice(0,encoded.length-padding).includes('='),'IMAGE_OUTPUT_INVALID','图片编码无效，已按实际用量结算',422);
 let image:Uint8Array;try{image=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0));}catch{assert(false,'IMAGE_OUTPUT_INVALID','图片编码无效，已按实际用量结算',422);}
 const info=await inspectMediaBytes(image!,'image/png');assert(info.width+'x'+info.height===pricing.size,'IMAGE_OUTPUT_INVALID','图片实际尺寸与请求不一致，已按实际用量结算',422);
 return image!;
}
export async function validateImageTestResponse(pricing:ImagePricing,result:any){const evidence=imageResponseUsage(pricing,result);await imageResponseBytes(pricing,result);return evidence;}
