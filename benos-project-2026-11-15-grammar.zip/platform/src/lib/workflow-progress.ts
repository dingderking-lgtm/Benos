/**
 * Live progress of a design step while the model is still writing (ai-workflow.ts, design-preview.ts).
 *
 * The stream's deltas are display material only: they are never executed, validated as a result or used for
 * billing. What the customer sees while waiting is rebuilt from them here — the note the model writes before it
 * works, which tool it is filling in, and a draft of the pages inside an unfinished `propose_files` call.
 */
import { materializeDesignFoundation,type DesignFoundation } from '../contracts/design-foundation';
export type StreamProgress={text:string;calls:{name:string;arguments:string}[]};
export type DraftFile={path:string;content:string};

/** Parses JSON that stops anywhere: an open string, a dangling key or comma, unclosed brackets. `undefined` when
 * nothing usable can be recovered. Text the model has not finished is kept as far as it got. */
export function parsePartialJson(source:string):any{
 if(!source.trim())return undefined;
 try{return JSON.parse(source);}catch{/* recover below */}
 const closers:string[]=[];let inString=false,escaped=false;
 for(let i=0;i<source.length;i++){
  const ch=source[i];
  if(inString){if(escaped)escaped=false;else if(ch==='\\')escaped=true;else if(ch==='"')inString=false;continue;}
  if(ch==='"')inString=true;else if(ch==='{')closers.push('}');else if(ch==='[')closers.push(']');else if(ch==='}'||ch===']')closers.pop();
 }
 let head=source;
 if(inString){if(escaped)head=head.slice(0,-1);head=head.replace(/\\u[0-9a-fA-F]{0,3}$/,'')+'"';}
 const tail=closers.reverse().join(''),bare=head.replace(/[^,:\[{]*$/,'');
 for(const candidate of [head+tail,head+':null'+tail,head.replace(/[\s,]+$/,'')+tail,head+'null'+tail,bare.replace(/[\s,]+$/,'')+tail,bare+'null'+tail]){
  try{return JSON.parse(candidate);}catch{/* next shape */}
 }
 return undefined;
}

const DRAFT_PATH=/^(?:manifest\.json|templates\/\d{1,9}\.(?:html|css))$/;
/** The files of every `propose_files` call so far, the unfinished one included. */
export function draftFiles(progress:StreamProgress):DraftFile[]{
 const files:DraftFile[]=[];
 for(const call of progress.calls){
  if(!['propose_files','prepare_layout'].includes(call.name))continue;
  const args=parsePartialJson(call.arguments);
  for(const file of Array.isArray(args?.files)?args.files:[]){
   if(file&&typeof file.path==='string'&&typeof file.content==='string'&&DRAFT_PATH.test(file.path))files.push({path:file.path,content:file.content});
  }
 }
 return files;
}

type Template={id:number;name:string;type:string;document:{html:string;css:string}};
function draftTemplates(value:unknown):Template[]{
 return (Array.isArray(value)?value:[]).filter((t:any)=>t&&Number.isSafeInteger(t.id)&&t.id>0&&t.document&&typeof t.document==='object'&&(typeof t.document.html==='string'||typeof t.document.css==='string'))
  .map((t:any)=>({id:t.id,name:typeof t.name==='string'?t.name:'',type:typeof t.type==='string'?t.type:'',document:{html:typeof t.document.html==='string'?t.document.html:'',css:typeof t.document.css==='string'?t.document.css:''}}));
}
function draftSite(value:any){
 if(!value||typeof value!=='object'||!Array.isArray(value.pages))return null;
 const pages=value.pages.filter((p:any)=>p&&typeof p.key==='string'&&Number.isSafeInteger(p.template_id));
 return pages.length?{name:typeof value.name==='string'?value.name:'',home:typeof value.home==='string'?value.home:pages[0].key,header_template_id:value.header_template_id,footer_template_id:value.footer_template_id,theme:value.theme&&typeof value.theme==='object'?{brand_color:value.theme.brand_color,brand_background:value.theme.brand_background,container_width:value.theme.container_width,global_css:typeof value.theme.global_css==='string'?value.theme.global_css:''}:undefined,pages}:null;
}
/** The design as far as it has been written: the working design with the draft files laid over it. A whole-site
 * draft (`manifest.json`) replaces the working design; `null` until at least one page has some markup. */
export function liveManifest(working:any,files:readonly DraftFile[],foundation:DesignFoundation|null=null):{site:ReturnType<typeof draftSite>;templates:Template[];assets:{file:string;path:string}[];latest:number|null}|null{
 let site=draftSite(working?.site),templates=draftTemplates(working?.templates),assets:any[]=Array.isArray(working?.assets)?working.assets:[],latest:number|null=null,drafted=false;
 for(const file of files){
  if(file.path==='manifest.json'){
   const draft=parsePartialJson(file.content);if(!draft||typeof draft!=='object'||Array.isArray(draft))continue;
   drafted=true;site=draftSite(draft.site);templates=draftTemplates(draft.templates);assets=Array.isArray(draft.assets)?draft.assets:[];latest=templates.at(-1)?.id??null;continue;
  }
  const match=/^templates\/(\d+)\.(html|css)$/.exec(file.path),template=match&&templates.find(t=>t.id===Number(match[1]));
  if(!match||!template)continue;
  drafted=true;template.document[match[2] as 'html'|'css']=file.content;latest=template.id;
 }
 if(!drafted||!templates.some(t=>t.document.html.trim()))return null;
 return materializeDesignFoundation({site,templates,assets:assets.filter(a=>a&&typeof a.file==='string'&&typeof a.path==='string'),latest},foundation);
}
