import { parseFragment, serialize, type DefaultTreeAdapterMap } from 'parse5';
import { SITE_COMPOSITION_VERSION, parseSiteComposition } from '../contracts/site-composition';
import { findSectionPattern } from '../contracts/section-patterns';
import { compilePageComposition, filterCurrentPatternApprovals, type PatternFrame, type PatternIssue, type PatternOwnedAsset, type PatternReceipt } from './page-composer';
import type { PatternApproval } from './pattern-approvals';
export { siteCompositionSchema, siteCompositionJsonSchema } from '../contracts/site-composition';

type Node = DefaultTreeAdapterMap['node'];
type Element = DefaultTreeAdapterMap['element'];
type Template = { id: number; type: string; document: { html: string; css?: string; [key: string]: unknown }; [key: string]: unknown };
export type SiteCompositionManifest = { site: { pages: Array<{ key: string; template_id: number; [key: string]: unknown }>; header_template_id?: number; footer_template_id?: number; [key: string]: unknown }; templates: Template[]; assets?: Array<{ path: string; sha256?: string; [key: string]: unknown }>; [key: string]: unknown };
export type SiteCompositionContext = { approvedSnapshot: readonly PatternApproval[]; ownedAssets?: readonly PatternOwnedAsset[]; verifiedFactRefs?: readonly string[] };
export type SitePatternFrame = PatternFrame & { pageKey: string; templateId: number };
export type SitePatternReceipt = PatternReceipt & { pageKey?: string; templateId: number; location: 'page' | 'footer' };
export type SiteCompositionSnapshot = {
  version: typeof SITE_COMPOSITION_VERSION; phase: 'compiled' | 'frozen';
  templates: Array<{ templateId: number; pageKey?: string; location: 'page' | 'footer'; html: string; css: string; sectionIds: string[] }>;
  frames: SitePatternFrame[]; ownedFrames: SitePatternFrame[]; receipts: SitePatternReceipt[];
  removedFrameIds: string[]; themeJson: string; ownedAssets: Array<{ path: string; sha256?: string }>;
};
export type SiteCompositionIssue = { code: string; message: string; templateId?: number; frameId?: string };
const fail = (code: string): never => { throw new Error(code); };
const attr = (node: Element, name: string) => node.attrs.find(a => a.name === name)?.value;
const classes = (node: Element) => (attr(node, 'class') || '').split(/\s+/).filter(Boolean);
const hasClass = (node: Element, name: string) => classes(node).includes(name);
function setAttr(node: Element, name: string, value: string) { const existing = node.attrs.find(a => a.name === name); if (existing) existing.value = value; else node.attrs.push({ name, value }); }
function nodes(html: string) {
  if (html.length > 600_000) fail('SITE_COMPOSITION_TOO_LARGE');
  const root = parseFragment(html), elements: Element[] = [], stack: Array<{ node: Node; depth: number }> = [{ node: root, depth: 0 }];
  let count = 0;
  while (stack.length) {
    const { node, depth } = stack.pop()!;
    if (++count > 30_000 || depth > 128) fail('SITE_COMPOSITION_TOO_COMPLEX');
    if ('tagName' in node) { elements.push(node); if (node.tagName === 'template' && 'content' in node) stack.push({ node: node.content as Node, depth: depth + 1 }); }
    if ('childNodes' in node) for (let i = node.childNodes.length - 1; i >= 0; i--) stack.push({ node: node.childNodes[i], depth: depth + 1 });
  }
  return { root, elements };
}
function manifestShape(manifest: SiteCompositionManifest) {
  if (!manifest?.site || !Array.isArray(manifest.site.pages) || !manifest.site.pages.length || manifest.site.pages.length > 100
    || !Array.isArray(manifest.templates) || manifest.templates.length > 200) fail('SITE_COMPOSITION_MANIFEST_INVALID');
  const templates = new Map<number, Template>(), keys = new Set<string>(), pageTemplates = new Set<number>();
  for (const template of manifest.templates) {
    if (!Number.isSafeInteger(template.id) || template.id <= 0 || templates.has(template.id) || typeof template.document?.html !== 'string') fail('SITE_COMPOSITION_TEMPLATE_INVALID');
    templates.set(template.id, template);
  }
  for (const page of manifest.site.pages) {
    if (!page.key || keys.has(page.key) || pageTemplates.has(page.template_id) || templates.get(page.template_id)?.type !== 'page') fail('SITE_COMPOSITION_PAGE_INVALID');
    keys.add(page.key); pageTemplates.add(page.template_id);
  }
  for (const [id, type] of [[manifest.site.header_template_id, 'header'], [manifest.site.footer_template_id, 'footer']] as const)
    if (id !== undefined && (templates.get(id)?.type !== type || pageTemplates.has(id))) fail('SITE_COMPOSITION_SHARED_TEMPLATE_INVALID');
  return templates;
}
function assertGlobalIds(manifest: SiteCompositionManifest) {
  const ids = new Set<string>(); let size = 0;
  for (const template of manifest.templates) {
    if ((size += template.document.html.length) > 600_000) fail('SITE_COMPOSITION_TOO_LARGE');
    for (const element of nodes(template.document.html).elements) {
      const id = attr(element, 'id'); if (id) { if (ids.has(id)) fail('SITE_COMPOSITION_DUPLICATE_ID'); ids.add(id); }
    }
  }
}
function hasPatternMarkup(template: Template) {
  return nodes(template.document.html).elements.some(node => classes(node).some(c => c.startsWith('bns-')) || node.attrs.some(a => a.name.startsWith('data-bns')) || attr(node, 'id')?.startsWith('bns-owned-'))
    || /\.bns-[a-z]/i.test(template.document.css || '');
}
/** Only the production wrapper performs these integration changes. Gallery
 * renderer bytes and their approval hashes are not rewritten or re-approved. */
function productionHtml(html: string, frames: PatternFrame[]) {
  const parsed = nodes(html), owned = new Map(frames.filter(f => f.source === 'owned').map(f => [f.frameId, 'bns-owned-' + f.id]));
  for (const node of parsed.elements) {
    const replacement = owned.get(attr(node, 'id') || ''); if (replacement) setAttr(node, 'id', replacement);
    if (hasClass(node, 'bnf-hero-cover-content') && !hasClass(node, 'bnf-container')) setAttr(node, 'class', [...classes(node), 'bnf-container'].join(' '));
  }
  return serialize(parsed.root);
}
/** Caller supplies a server-owned approval snapshot and verified project media;
 * neither the model input nor this pure compiler can grant approvals. */
export async function compileSiteComposition<T extends SiteCompositionManifest>(raw: unknown, baseManifest: T, context: SiteCompositionContext) {
  const input = parseSiteComposition(raw), baseTemplates = manifestShape(baseManifest);
  if (/\.bns-[a-z]|\[\s*data-bns/i.test(String((baseManifest.site.theme as any)?.global_css || ''))) fail('SITE_COMPOSITION_GLOBAL_STYLE_OVERRIDE');
  const approved = await filterCurrentPatternApprovals(context.approvedSnapshot || []);
  if (!approved.length) fail('SITE_COMPOSITION_NO_APPROVED_PATTERNS');
  const declared = new Set<number>(), pageKeys = new Set<string>(), sectionIds = new Set<string>();
  const targets: Array<{ templateId: number; pageKey?: string; location: 'page' | 'footer'; composition: typeof input.pages[number]['composition'] }> = input.pages.map(page => {
    if (pageKeys.has(page.pageKey) || declared.has(page.templateId)) fail('SITE_COMPOSITION_DUPLICATE_PAGE');
    if (!baseManifest.site.pages.some(p => p.key === page.pageKey && p.template_id === page.templateId) || baseTemplates.get(page.templateId)?.type !== 'page') fail('SITE_COMPOSITION_PAGE_MISMATCH');
    pageKeys.add(page.pageKey); declared.add(page.templateId);
    if (page.composition.sections.some(section => findSectionPattern(section.patternId, section.variantId).family.group === 'footer')) fail('SITE_COMPOSITION_FOOTER_IN_PAGE');
    return { templateId: page.templateId, pageKey: page.pageKey, location: 'page' as 'page' | 'footer', composition: page.composition };
  });
  if (input.footer) {
    const footer = input.footer;
    if (footer.templateId !== baseManifest.site.footer_template_id || baseTemplates.get(footer.templateId)?.type !== 'footer'
      || findSectionPattern(footer.section.patternId, footer.section.variantId).family.group !== 'footer') fail('SITE_COMPOSITION_FOOTER_MISMATCH');
    declared.add(footer.templateId);
    targets.push({ templateId: footer.templateId, location: 'footer', composition: { version: 'compose-1', skin: footer.section.skin, sections: [footer.section] } });
  }
  for (const target of targets) for (const section of target.composition.sections) {
    if (sectionIds.has(section.id)) fail('SITE_COMPOSITION_DUPLICATE_SECTION'); sectionIds.add(section.id);
  }
  // Preserve existing media records; an ownership record alone is insufficient
  // if that asset is absent from this manifest or its checksum disagrees.
  const ownedAssets = (context.ownedAssets || []).filter(asset => baseManifest.assets?.some(a => a.path === asset.path && (!asset.sha256 || a.sha256 === asset.sha256)));
  if (new Set(ownedAssets.map(asset => asset.path)).size !== ownedAssets.length) fail('SITE_COMPOSITION_DUPLICATE_ASSET');
  const manifest = structuredClone(baseManifest), frames: SitePatternFrame[] = [], ownedFrames: SitePatternFrame[] = [], receipts: SitePatternReceipt[] = [], issues: PatternIssue[] = [];
  const snapshot: SiteCompositionSnapshot = { version: SITE_COMPOSITION_VERSION, phase: 'compiled', templates: [], frames, ownedFrames, receipts, removedFrameIds: [], themeJson: JSON.stringify(baseManifest.site.theme ?? null), ownedAssets: [] };
  for (const target of targets) {
    const rendered = await compilePageComposition(target.composition, { mode: 'production', approved, ownedAssets, verifiedFactRefs: context.verifiedFactRefs });
    if (!rendered.html.trim()) fail('SITE_COMPOSITION_EMPTY_TEMPLATE');
    const template = manifest.templates.find(t => t.id === target.templateId)!;
    template.document = { ...template.document, html: productionHtml(rendered.html, rendered.frames), css: rendered.css };
    for (const frame of rendered.frames) {
      const value = { ...frame, templateId: target.templateId, pageKey: target.pageKey || '' };
      if (frame.source === 'owned') ownedFrames.push({ ...value, frameId: 'bns-owned-' + frame.id }); else frames.push(value);
    }
    receipts.push(...rendered.receipts.map(receipt => ({ ...receipt, templateId: target.templateId, ...(target.pageKey ? { pageKey: target.pageKey } : {}), location: target.location })));
    issues.push(...rendered.issues);
    snapshot.templates.push({ templateId: target.templateId, ...(target.pageKey ? { pageKey: target.pageKey } : {}), location: target.location, html: template.document.html, css: template.document.css || '', sectionIds: rendered.receipts.filter(r => nodes(template.document.html).elements.some(n => attr(n, 'id') === r.sectionId)).map(r => r.sectionId) });
  }
  if (frames.length > 12) fail('SITE_COMPOSITION_FRAME_LIMIT');
  snapshot.ownedAssets = [...new Set(ownedFrames.map(frame => frame.assetPath!))].map(path => {
    const record = baseManifest.assets!.find(asset => asset.path === path)!;
    return { path, ...(record.sha256 ? { sha256: record.sha256 } : {}) };
  });
  if (new Set([...frames, ...ownedFrames].map(frame => frame.id)).size !== frames.length + ownedFrames.length) fail('SITE_COMPOSITION_DUPLICATE_FRAME');
  assertGlobalIds(manifest);
  // No previously authored content may impersonate this approval receipt.
  if (manifest.templates.some(template => !declared.has(template.id) && hasPatternMarkup(template))) fail('SITE_COMPOSITION_UNRECEIPTED_MARKUP');
  return { manifest, frames, ownedFrames, receipts, issues, snapshot: structuredClone(snapshot) };
}

function shapeIssues(manifest: SiteCompositionManifest, snapshot: SiteCompositionSnapshot): SiteCompositionIssue[] {
  const issues: SiteCompositionIssue[] = [];
  manifestShape(manifest); assertGlobalIds(manifest);
  if (snapshot.version !== SITE_COMPOSITION_VERSION || !snapshot.templates.length || snapshot.templates.length > 21) fail('SITE_COMPOSITION_SNAPSHOT_INVALID');
  const ids = new Set(snapshot.templates.map(t => t.templateId));
  if (ids.size !== snapshot.templates.length) fail('SITE_COMPOSITION_SNAPSHOT_INVALID');
  for (const asset of snapshot.ownedAssets) if (!manifest.assets?.some(record => record.path === asset.path && (!asset.sha256 || record.sha256 === asset.sha256))) issues.push({ code: 'SITE_COMPOSITION_OWNED_ASSET_CHANGED', message: '已核验的现有图片清单被移除或替换。' });
  for (const expected of snapshot.templates) {
    const template = manifest.templates.find(t => t.id === expected.templateId);
    if (!template || (expected.location === 'page' ? !manifest.site.pages.some(p => p.key === expected.pageKey && p.template_id === expected.templateId) : manifest.site.footer_template_id !== expected.templateId)) {
      issues.push({ code: 'SITE_COMPOSITION_TARGET_CHANGED', message: '已编译页面或公共页脚的映射已改变。', templateId: expected.templateId }); continue;
    }
    const elements = nodes(template.document.html).elements;
    for (const id of expected.sectionIds) if (!elements.some(n => attr(n, 'id') === id && hasClass(n, 'bns-section'))) issues.push({ code: 'SITE_COMPOSITION_SECTION_MISSING', message: '已编译区块缺失或被移至其他模板。', templateId: expected.templateId });
    for (const frame of [...snapshot.frames, ...snapshot.ownedFrames].filter(f => f.templateId === expected.templateId && !snapshot.removedFrameIds.includes(f.id))) {
      const element = elements.find(n => attr(n, 'id') === frame.frameId);
      let section: Element | undefined = element;
      while (section && attr(section, 'id') !== frame.sectionId) section = section.parentNode && 'tagName' in section.parentNode ? section.parentNode : undefined;
      if (!element || !section) issues.push({ code: 'SITE_COMPOSITION_FRAME_CHANGED', message: '图片框不再属于原编译区块。', templateId: expected.templateId, frameId: frame.id });
    }
  }
  if (manifest.templates.some(template => !ids.has(template.id) && hasPatternMarkup(template))) issues.push({ code: 'SITE_COMPOSITION_UNRECEIPTED_MARKUP', message: '存在未通过审批快照编译的模式标记。' });
  return issues;
}
/** Call ONLY with the trusted result of server materialization and image
 * prepare/bind, never with unchecked model-authored HTML. The old catalog is
 * not recompiled. Once frozen, re-freezing cannot bless an altered template. */
export function freezeSiteComposition<T extends SiteCompositionManifest>(manifest: T, snapshot: SiteCompositionSnapshot): SiteCompositionSnapshot {
  const issues = snapshot.phase === 'frozen' ? validateSiteComposition(manifest, snapshot) : shapeIssues(manifest, snapshot);
  if (issues.length) fail(issues[0].code);
  return { ...structuredClone(snapshot), phase: 'frozen', themeJson: JSON.stringify(manifest.site.theme ?? null), templates: snapshot.templates.map(expected => {
    const template = manifest.templates.find(t => t.id === expected.templateId)!;
    return { ...expected, html: template.document.html, css: template.document.css || '' };
  }) };
}
/** Exact authored bytes are retained after the server transformations. This
 * intentionally does not erase all style/class attributes for comparison. */
export function validateSiteComposition(manifest: SiteCompositionManifest, snapshot: SiteCompositionSnapshot | null | undefined): SiteCompositionIssue[] {
  try {
    if (!snapshot) return manifest.templates.some(hasPatternMarkup) ? [{ code: 'SITE_COMPOSITION_SNAPSHOT_REQUIRED', message: '模式内容必须来自已审批的生产编译快照。' }] : [];
    const issues = shapeIssues(manifest, snapshot);
    if (JSON.stringify(manifest.site.theme ?? null) !== snapshot.themeJson) issues.push({ code: 'SITE_COMPOSITION_THEME_CHANGED', message: '编译后冻结的全局主题或字体样式已改变。' });
    for (const expected of snapshot.templates) {
      const template = manifest.templates.find(t => t.id === expected.templateId);
      if (template && (template.document.html !== expected.html || (template.document.css || '') !== expected.css)) issues.push({ code: 'SITE_COMPOSITION_OUTPUT_CHANGED', message: '已审批编译区块的结构、文案或样式被修改，请保留编译结果。', templateId: expected.templateId });
    }
    return issues;
  } catch { return [{ code: 'SITE_COMPOSITION_INVALID', message: '无法确认模式输出与可信快照一致。' }]; }
}
const meaningful = (node: Element) => node.childNodes.filter(child => child.nodeName !== '#comment' && !(child.nodeName === '#text' && 'value' in child && !child.value.trim()));
function detach(node: Element) { const parent = node.parentNode; if (parent && 'childNodes' in parent) parent.childNodes.splice(parent.childNodes.indexOf(node), 1); }
/** Explicit server-known failures/discards only. Removes just media subtrees,
 * preserves existing captions/copy, and collapses empty media shells. No model
 * HTML, fresh renderer version, provider request or accounting is involved. */
export function finalizeSiteCompositionImages<T extends SiteCompositionManifest>(input: T, snapshot: SiteCompositionSnapshot, options: { failedFrameIds: readonly string[]; discardedFrameIds?: readonly string[] }) {
  const failed = new Set(options.failedFrameIds), discarded = new Set(options.discardedFrameIds || []), requested = new Set([...failed, ...discarded]);
  if (failed.size !== options.failedFrameIds.length || discarded.size !== (options.discardedFrameIds || []).length || [...failed].some(id => discarded.has(id))) fail('SITE_COMPOSITION_IMAGE_DECISION_INVALID');
  const preIssues = snapshot.phase === 'frozen' ? validateSiteComposition(input, snapshot) : shapeIssues(input, snapshot);
  if (preIssues.length) fail(preIssues[0].code);
  for (const id of requested) if (!snapshot.frames.some(f => f.id === id)) fail('SITE_COMPOSITION_IMAGE_NOT_PLANNED');
  if (discarded.size && snapshot.phase !== 'frozen') fail('SITE_COMPOSITION_DISCARD_REQUIRES_FROZEN');
  const manifest = structuredClone(input), next = structuredClone(snapshot);
  for (const template of manifest.templates) {
    const frames = snapshot.frames.filter(f => f.templateId === template.id && requested.has(f.id) && !snapshot.removedFrameIds.includes(f.id));
    if (!frames.length) continue;
    const parsed = nodes(template.document.html), affected = new Set<string>();
    for (const frame of frames) {
      const node = parsed.elements.find(n => attr(n, 'id') === frame.frameId)!;
      if (failed.has(frame.id) && meaningful(node).length) fail('SITE_COMPOSITION_FAILED_FRAME_HAS_CONTENT');
      let removable = node;
      while (removable.parentNode && 'tagName' in removable.parentNode) {
        const parent = removable.parentNode;
        if (!['div', 'figure'].includes(parent.tagName) || meaningful(parent).length !== 1 || attr(parent, 'id') === frame.sectionId) break;
        removable = parent;
      }
      detach(removable); affected.add(frame.sectionId); next.removedFrameIds.push(frame.id);
    }
    for (const id of affected) {
      const section = parsed.elements.find(n => attr(n, 'id') === id)!;
      const descendants = nodes(serialize(section)).elements;
      const hasMedia = descendants.some(n => hasClass(n, 'bns-frame'));
      if (!hasMedia) setAttr(section, 'class', [...classes(section).filter(c => !c.startsWith('bnf-hero-cover')), 'bns-no-media'].filter((x, i, all) => all.indexOf(x) === i).join(' '));
      // Keep captions and facts. A failed mosaic cell becomes a text entry in
      // the existing responsive list instead of an empty picture rectangle.
      for (const node of parsed.elements) if (hasClass(node, 'bns-mosaic-grid')) {
        let parent: Element | undefined = node;
        while (parent && parent !== section) parent = parent.parentNode && 'tagName' in parent.parentNode ? parent.parentNode : undefined;
        if (parent === section) setAttr(node, 'class', [...classes(node).filter(c => c !== 'bns-mosaic-grid' && c !== 'bns-mosaic-bento'), 'bns-fallback-list'].join(' '));
      }
    }
    template.document.html = serialize(parsed.root);
  }
  // This helper alone can create a revised frozen projection, after the exact
  // previous snapshot was checked above. Removed IDs remain an audit trail.
  next.phase = 'compiled';
  return { manifest, snapshot: freezeSiteComposition(manifest, next) };
}
