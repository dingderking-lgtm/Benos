import { z } from 'zod';
import { imageSlotSchema, imageSizeForSlot, imageDisplay, type ImageSlot, type ImageSize } from './image-layout';

/** Trusted geometry compiled before any image reservation or provider request.
 * Storage, ownership, revision checks and paid-job reuse belong to the workflow.
 * The compiler never edits existing images or treats pixels as semantic evidence. */
export const IMAGE_FRAME_PLAN_VERSION = 'image-frame-plan-v1' as const;
export const IMAGE_FRAME_PLAN_V2_VERSION = 'image-frame-plan-v2' as const;
export const IMAGE_COVER_BREAKPOINT = 640;
export type ImageFramePresentation = 'standard' | 'hero-cover';
const identifier = z.string().regex(/^[a-z][a-z0-9-]{0,59}$/);
function uniqueFrameIds(plan:{sections:Array<{id:string;frames:Array<{id:string}>}>},ctx:z.RefinementCtx){
 const sections=new Set<string>(),frames=new Set<string>();
 for(const [index,section] of plan.sections.entries()){
  if(sections.has(section.id))ctx.addIssue({code:'custom',path:['sections',index,'id'],message:'Section IDs must be unique'});
  sections.add(section.id);
  for(const [frameIndex,frame] of section.frames.entries()){
   if(frames.has(frame.id))ctx.addIssue({code:'custom',path:['sections',index,'frames',frameIndex,'id'],message:'Frame IDs must be globally unique'});
   frames.add(frame.id);
  }
 }
 if(frames.size>12)ctx.addIssue({code:'custom',path:['sections'],message:'At most 12 planned frames are supported'});
}
export const imageFramePlanInputSchema = z.object({
 sections: z.array(z.object({
  id: identifier,
  layout: z.string().trim().min(3).max(160),
  frames: z.array(z.object({
   id: identifier,
   purpose: z.string().trim().min(3).max(160),
   slot: imageSlotSchema,
   subjectPolicy: z.enum(['complete', 'crop-safe']),
   framePolicy: z.enum(['adapt', 'fixed']),
  }).strict()).max(4),
 }).strict()).min(1).max(12),
}).strict().superRefine(uniqueFrameIds);
export type ImageFramePlanInput=z.input<typeof imageFramePlanInputSchema>;
/** A separate schema keeps stored v1 calls and their serialisation unchanged. */
export const imageFramePlanV2InputSchema = z.object({sections:z.array(z.object({
 id:identifier,layout:z.string().trim().min(3).max(160),
 frames:z.array(z.object({id:identifier,purpose:z.string().trim().min(3).max(160),slot:imageSlotSchema,
  subjectPolicy:z.enum(['complete','crop-safe']),framePolicy:z.enum(['adapt','fixed']),
  presentation:z.enum(['standard','hero-cover']).default('standard'),
 }).strict()).max(8),
}).strict()).min(1).max(12)}).strict().superRefine((plan,ctx)=>{
 uniqueFrameIds(plan,ctx);
 for(const [sectionIndex,section] of plan.sections.entries())for(const [frameIndex,frame] of section.frames.entries()){
  if(frame.presentation==='hero-cover'&&(frame.subjectPolicy!=='crop-safe'||frame.framePolicy!=='fixed'||frame.slot.fit!=='cover'))
   ctx.addIssue({code:'custom',path:['sections',sectionIndex,'frames',frameIndex,'presentation'],message:'A hero cover requires crop-safe, fixed and cover; complete products use a standard adapt frame'});
 }
});
type ParsedFrame=z.infer<typeof imageFramePlanInputSchema>['sections'][number]['frames'][number];
export type CompiledImageFrame={
 id:string;sectionId:string;purpose:string;subjectPolicy:ParsedFrame['subjectPolicy'];framePolicy:ParsedFrame['framePolicy'];
 requestedSlot:ImageSlot;resolvedSlot:ImageSlot;generation:{size:ImageSize;width:number;height:number};
 elementId:string;adapted:boolean;preserveContain:boolean;
 presentation?:ImageFramePresentation;
};
export type ImageFramePlan={version:typeof IMAGE_FRAME_PLAN_VERSION|typeof IMAGE_FRAME_PLAN_V2_VERSION;sections:{id:string;layout:string;frameIds:string[]}[];frames:CompiledImageFrame[]};
/** Determined from the user's actual request by the caller, never by model args. */
export type ImageFramePlanOptions={preserveExplicitContainIds?:readonly string[];version?:ImageFramePlan['version']};
const pixels=(size:ImageSize)=>{const [width,height]=size.split('x').map(Number);return{width,height};};
const round=(n:number)=>Math.round(n*10000)/10000;
function adaptFrame(slot:ImageSlot,width:number,height:number):ImageSlot{
 // Prefer an inscribed frame: a full equipment photograph must not become a
 // giant hero merely to fill a banner. The surrounding section can use the rest
 // of the width for copy. Whole-number multiples preserve the exact ratio.
 const gcd=(a:number,b:number):number=>b?gcd(b,a%b):a,divisor=gcd(width,height),x=width/divisor,y=height/divisor;
 if(Math.max(x,y)<=3){
  const scale=Math.max(Math.ceil(64/Math.min(x,y)),Math.floor(Math.min(slot.width/x,slot.height/y)));
  return {...slot,width:x*scale,height:y*scale};
 }
 // Actual media can have other dimensions. CSS geometry may be fractional; do
 // not scale an irreducible source ratio up to thousands of CSS pixels.
 const scale=Math.min(slot.width/width,slot.height/height);
 return {...slot,width:round(width*scale),height:round(height*scale)};
}
export function compileImageFramePlan(value:unknown,options:ImageFramePlanOptions={}):ImageFramePlan{
 const version=options.version??IMAGE_FRAME_PLAN_VERSION;
 if(![IMAGE_FRAME_PLAN_VERSION,IMAGE_FRAME_PLAN_V2_VERSION].includes(version))throw new Error('IMAGE_FRAME_PLAN_VERSION_UNSUPPORTED');
 const input=version===IMAGE_FRAME_PLAN_V2_VERSION?imageFramePlanV2InputSchema.parse(value):imageFramePlanInputSchema.parse(value),frames:CompiledImageFrame[]=[];
 const sections=input.sections.map(section=>({id:section.id,layout:section.layout,frameIds:section.frames.map(frame=>{
  const presentation='presentation' in frame?frame.presentation as ImageFramePresentation:undefined,cover=presentation==='hero-cover';
  const size:ImageSize=cover?'1536x1024':imageSizeForSlot(frame.slot),generation={size,...pixels(size)};
  // New generated assets fill their resolved frame. Complete subjects in a fixed
  // banner are composed inside its safe crop, not letterboxed with contain.
  const preserveContain=!!options.preserveExplicitContainIds?.includes(frame.id),slot={...frame.slot,fit:preserveContain?'contain' as const:'cover' as const};
  if(cover&&preserveContain)throw new Error('IMAGE_COVER_EXPLICIT_CONTAIN');
  if(cover&&slot.textSafeArea!=='none')slot.focalPoint=({left:'right',right:'left',top:'bottom',bottom:'top'} as const)[slot.textSafeArea];
  const resolvedSlot=frame.framePolicy==='adapt'?adaptFrame(slot,generation.width,generation.height):slot;
  frames.push({id:frame.id,sectionId:section.id,purpose:frame.purpose,subjectPolicy:frame.subjectPolicy,framePolicy:frame.framePolicy,requestedSlot:frame.slot,resolvedSlot,generation,elementId:'bnf-image-'+frame.id,preserveContain,adapted:resolvedSlot.width!==frame.slot.width||resolvedSlot.height!==frame.slot.height||resolvedSlot.fit!==frame.slot.fit,...(presentation?{presentation}:{})});
  return frame.id;
 })}));
 return{version,sections,frames};
}

/** CSS viewport units are intentional: this is layout geometry, not an image resolution. */
export function imageCoverGeometry(viewportWidth:number,viewportHeight:number){
 if(![viewportWidth,viewportHeight].every(value=>Number.isFinite(value)&&value>0))throw new Error('IMAGE_COVER_VIEWPORT_INVALID');
 return {width:viewportWidth,height:viewportWidth<=IMAGE_COVER_BREAKPOINT?viewportHeight*.56:Math.min(viewportHeight*.88,760)};
}
/** Intersection of representative desktop/tablet/phone crops for composition.
 * It reduces crop risk; it does not prove a generated subject is complete. */
export function imageCoverSafeRegion(frame:CompiledImageFrame){
 const slots=[frame.resolvedSlot,...[[1440,900],[768,1024],[390,844],[320,568]].map(([width,height])=>({...frame.resolvedSlot,...imageCoverGeometry(width,height)}))];
 const regions=slots.map(slot=>imageDisplay(slot,frame.generation.width,frame.generation.height).visibleRegion);
 const left=Math.max(...regions.map(r=>r.left)),top=Math.max(...regions.map(r=>r.top));
 return {left,top,width:round(Math.min(...regions.map(r=>r.left+r.width))-left),height:round(Math.min(...regions.map(r=>r.top+r.height))-top)};
}

/** Stable serialization for the workflow's persisted hash/revision boundary. */
export function imageFramePlanSignature(plan:ImageFramePlan):string{return JSON.stringify(plan);}
export function plannedImageFrame(plan:ImageFramePlan,frameId:string):CompiledImageFrame{
 const frame=plan.frames.find(item=>item.id===frameId);if(!frame)throw new Error('IMAGE_FRAME_NOT_PLANNED');return frame;
}
const actualSchema=z.object({width:z.number().int().min(1).max(32768),height:z.number().int().min(1).max(32768)}).strict();
export function resolvePlannedImageFrame(frame:CompiledImageFrame,actualWidth:number,actualHeight:number){
 const actual=actualSchema.parse({width:actualWidth,height:actualHeight});
 const slot=frame.framePolicy==='adapt'?adaptFrame({...frame.requestedSlot,fit:frame.resolvedSlot.fit},actual.width,actual.height):frame.resolvedSlot;
 const display=imageDisplay(slot,actual.width,actual.height);
 const target=slot.width/slot.height,source=actual.width/actual.height,letterboxFraction=slot.fit==='contain'?round(1-Math.min(target/source,source/target)):0;
 if(frame.presentation==='hero-cover')return{frameId:frame.id,elementId:frame.elementId,slot,actual,generationMatches:actual.width===frame.generation.width&&actual.height===frame.generation.height,
  display:{...display,aspectRatio:'auto',letterboxFraction,presentation:'hero-cover' as const},layout:{maxWidth:'none',width:'100%',height:'var(--bnf-hero-cover-height,min(88vh,760px))',aspectRatio:'auto',mobileMaxWidth:IMAGE_COVER_BREAKPOINT,mobileHeight:'56vh'},subjectVerified:false as const};
 return{frameId:frame.id,elementId:frame.elementId,slot,actual,generationMatches:actual.width===frame.generation.width&&actual.height===frame.generation.height,display:{...display,letterboxFraction},layout:{maxWidth:slot.width,width:'100%',height:'auto',aspectRatio:display.aspectRatio},subjectVerified:false as const};
}

/** Added before the existing bounded composition appendix. No model call. */
export function imagePromptForPlannedFrame(prompt:string,frame:CompiledImageFrame):string{
 if(frame.presentation==='hero-cover'){
  const region=imageCoverSafeRegion(frame);
  return `${prompt}\n\nFrame ${frame.id}: responsive landscape cover. Keep essential subject matter inside the shared desktop/phone crop (${region.left}% left, ${region.top}% top, ${region.width}% width, ${region.height}% height), with 8% inset. The ${frame.resolvedSlot.textSafeArea==='none'?'background':frame.resolvedSlot.textSafeArea+' side'} stays quiet; HTML carries all words. Extend the scene to every edge; no bars, borders or website mockup. Distinct ${frame.purpose} view.`;
 }
 const {visibleRegion}=imageDisplay(frame.resolvedSlot,frame.generation.width,frame.generation.height);
 const subject=frame.subjectPolicy==='complete'
  ? `Show the complete subject inside the final visible region (${visibleRegion.left}% left, ${visibleRegion.top}% top, ${visibleRegion.width}% width, ${visibleRegion.height}% height), with 8% inset. No cropped parts.`
  : 'Keep essential subject matter inside the final visible region.';
 return `${prompt}\n\nFrame ${frame.id}: ${subject} Extend real scene/background to every image edge; no bars, padding, borders or baked-in frame. This is a distinct ${frame.purpose} view.`;
}

export type ObservedImageFrame={frameWidth:number;frameHeight:number;imageWidth:number;imageHeight:number;objectFit:string;objectPosition?:string;naturalWidth:number;naturalHeight:number;viewportWidth:number;viewportHeight?:number};
/** Browser geometry only; callers must supply measured DOM values. This cannot
 * verify whether an AI drew the complete subject or baked borders into pixels. */
export function validateImageFramePresentation(frame:CompiledImageFrame,actual:{width:number;height:number},observed:ObservedImageFrame){
 const receipt=resolvePlannedImageFrame(frame,actual.width,actual.height),issues:string[]=[],warnings:string[]=[];
 const measured=[observed.frameWidth,observed.frameHeight,observed.imageWidth,observed.imageHeight,observed.naturalWidth,observed.naturalHeight,observed.viewportWidth];
 if(!measured.every(value=>Number.isFinite(value)&&value>0))return{valid:false,issues:['invalid_observed_geometry'],warnings,letterboxFraction:null,cropFraction:null,subjectVerified:false as const};
 if(observed.naturalWidth!==actual.width||observed.naturalHeight!==actual.height)issues.push('image_source_dimensions_mismatch');
 const target=observed.imageWidth/observed.imageHeight,source=actual.width/actual.height,visibleFraction=Math.min(target/source,source/target);
 const letterboxFraction=observed.objectFit==='contain'?round(1-visibleFraction):0;
 const cropFraction=observed.objectFit==='cover'?round(1-visibleFraction):0;
 if(!['cover','contain'].includes(observed.objectFit))issues.push('unsupported_image_fit');
 if(observed.objectPosition&&cropFraction>.02){
  const position=/^(-?\d+(?:\.\d+)?)%\s+(-?\d+(?:\.\d+)?)%$/.exec(observed.objectPosition.trim());
  const expected=receipt.display.objectPosition.split(' ').map(value=>parseFloat(value));
  if(position){if(Math.abs(Number(position[1])-expected[0])>1||Math.abs(Number(position[2])-expected[1])>1)issues.push('crop_position_changed');}
  else warnings.push('unverified_image_position');
 }
 if(Math.abs(observed.frameWidth-observed.imageWidth)>2||Math.abs(observed.frameHeight-observed.imageHeight)>2)issues.push('image_does_not_fill_frame');
 if(frame.preserveContain&&observed.objectFit!=='contain')issues.push('explicit_contain_not_preserved');
 if(letterboxFraction>.02)(frame.preserveContain?warnings:issues).push(frame.preserveContain?'explicit_contain_letterboxing':'image_letterboxing');
 // Responsive scaling preserves this planned ratio; a separate art-directed
 // mobile frame must be planned independently instead of silently cropping it.
 if(frame.presentation==='hero-cover'){
  if(!observed.viewportHeight||!Number.isFinite(observed.viewportHeight))issues.push('cover_viewport_height_missing');
  else {const expected=imageCoverGeometry(observed.viewportWidth,observed.viewportHeight);if(Math.abs(observed.frameHeight-expected.height)>2)issues.push('cover_height_changed');}
  if(Math.abs(observed.frameWidth-observed.viewportWidth)>2)issues.push('cover_not_full_width');
  if(observed.objectFit!=='cover')issues.push('cover_fit_changed');
 }else if(Math.abs(Math.log(target/(receipt.slot.width/receipt.slot.height)))>.03)issues.push('frame_ratio_changed');
 if(frame.subjectPolicy==='complete'&&frame.framePolicy==='adapt'&&cropFraction>.02)issues.push('complete_subject_frame_cropped');
 if(observed.imageWidth>observed.viewportWidth+2)issues.push('image_overflows_viewport');
 return{valid:issues.length===0,issues,warnings,letterboxFraction,cropFraction,subjectVerified:false as const};
}
