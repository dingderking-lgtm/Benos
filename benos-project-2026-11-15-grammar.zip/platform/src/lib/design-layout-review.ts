import { parseFragment } from 'parse5';
export const LAYOUT_REVIEW_VERSION='layout-review-1';
export const LAYOUT_REVIEW_CSS=`/* benos-layout-review:1 */
.bnf-reviewed-hero{--bnf-order-size-h1:clamp(36px,4.4vw,64px);display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.08fr);align-items:center;gap:clamp(28px,4vw,64px)}
.bnf-reviewed-hero>*{min-width:0;max-width:100%}.bnf-reviewed-hero figure{margin:0}.bnf-reviewed-hero [id^="bnf-image-"]{margin-top:0!important;margin-inline:auto}.bnf-reviewed-hero .bnf-actions{flex-direction:row!important;flex-wrap:wrap!important;align-items:center!important}.bnf-reviewed-hero .bnf-title{max-width:18ch!important}
@media(max-width:960px){.bnf-reviewed-hero{grid-template-columns:minmax(0,1fr);gap:28px}.bnf-reviewed-hero .bnf-title{max-width:22ch!important}}
`;
/** Deterministic repair of a common unfinished split: exactly one copy column
 * and one planned image, in a plain container. Never crops media or rewrites text. */
export function reviewHeroLayout<T>(input:T):{manifest:T;repairs:string[]} {
 const m=input as any,home=m.site?.pages?.find((p:any)=>p.key===m.site.home),t=m.templates?.find((t:any)=>t.id===home?.template_id);
 if(!t?.document?.html)return {manifest:input,repairs:[]};
 const root=parseFragment(t.document.html,{sourceCodeLocationInfo:true}) as any,rows:any[]=[];
 const walk=(n:any)=>{if(n.tagName)rows.push(n);for(const c of n.childNodes||[])walk(c);};walk(root);
 const attr=(n:any,k:string)=>n.attrs?.find((a:any)=>a.name===k)?.value||'',classes=(n:any)=>attr(n,'class').split(/\s+/),inside=(n:any,match:(n:any)=>boolean):boolean=>match(n)||(n.childNodes||[]).some((c:any)=>inside(c,match));
 const section=rows.find(n=>n.tagName==='section'&&classes(n).includes('bnf-hero')&&!classes(n).some((c:string)=>['bnf-hero-cover','bnf-hero-center','bnf-reviewed-hero'].includes(c)));
 if(!section)return {manifest:input,repairs:[]};
 const container=section.childNodes?.find((n:any)=>n.tagName==='div'&&classes(n).includes('bnf-container'));
 if(!container||classes(container).some((c:string)=>/split|grid|reviewed|center/.test(c))||/display\s*:\s*(grid|flex)/i.test(attr(container,'style')))return {manifest:input,repairs:[]};
 const children=container.childNodes.filter((n:any)=>n.tagName),copy=children.find((n:any)=>inside(n,x=>x.tagName==='h1')),media=children.find((n:any)=>n!==copy&&inside(n,x=>/^bnf-image-/.test(attr(x,'id'))));
 if(children.length!==2||!copy||!media||inside(copy,n=>n.tagName==='img'))return {manifest:input,repairs:[]};
 const a=container.sourceCodeLocation?.attrs?.class;if(!a)return {manifest:input,repairs:[]};
 const next=structuredClone(input) as any,nt=next.templates.find((x:any)=>x.id===t.id),html=t.document.html;
 nt.document.html=html.slice(0,a.startOffset)+'class="'+attr(container,'class')+' bnf-reviewed-hero"'+html.slice(a.endOffset);
 next.site.theme={...next.site.theme,global_css:String(next.site.theme?.global_css||'')+(String(next.site.theme?.global_css||'').includes('/* benos-layout-review:1 */')?'':'\n'+LAYOUT_REVIEW_CSS)};
 return {manifest:next,repairs:['hero-copy-media-alignment']};
}
/** Only safe public progress, not raw tool output. Older stored receipts work too. */
export function publicDesignTool(t:any){const r=t.result||{},layoutSaved=['prepare_layout','compose_site','compose_site_v2'].includes(t.name)&&(r.layoutSaved===true||Array.isArray(r.images)&&Array.isArray(r.changedFiles));return {name:t.name,ok:layoutSaved||r.ok!==false,code:r.code??null,layoutSaved,reviewPassed:r.check?.passed===true||t.name==='check_preview'&&r.ok===true,imageFailures:layoutSaved?r.images?.filter((i:any)=>i.ok===false).length||0:0,...(t.name==='discard_prepared_images'&&r.ok===true?{label:'记录图片弃用',message:r.message==='已记录弃用原因，并由平台收起对应的组合式图框。'?r.message:'已记录弃用原因；此操作本身没有删除图片。'}:{})};}
