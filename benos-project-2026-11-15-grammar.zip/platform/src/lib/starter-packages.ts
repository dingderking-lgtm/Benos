import type { Env } from '../env';
import { assert } from './errors';

/**
 * Starter templates that ship as a complete site package (manifest + media) among the Worker's static assets:
 * `/starters/<id>/manifest.json` and `/starters/<id>/assets/*`, assembled from the front end's dist/starters
 * folder by scripts/build-web.mjs. This is what customers see under "模板与灵感"; the two small built-in designs
 * of contracts/starter-library.ts stay available to the code and tests that use them, but are no longer listed.
 */
export const starterCatalogue=[
 {id:'arkpm',name:'工业设备企业站',description:'塑料再生与挤出设备品牌的完整英文站：产品线、解决方案、选型工具与资讯，共 25 个页面，可交给 AI 改成你的品牌与语言。',style:'structured',pages:25},
] as const;
export const isStarterPackage=(id:string)=>starterCatalogue.some(item=>item.id===id);
export const starterAssetUrl=(id:string,file:string)=>`/starters/${encodeURIComponent(id)}/${file.split('/').map(encodeURIComponent).join('/')}`;

const manifests=new Map<string,Promise<any>>();
async function asset(env:Env,path:string){
 assert(env.ASSETS,'STARTER_UNAVAILABLE','起步模板暂时无法读取',503);
 const response=await env.ASSETS.fetch(new Request(new URL(path,'https://assets.invalid')));
 assert(response.ok,'STARTER_UNAVAILABLE','起步模板暂时无法读取',503);
 return response;
}
/** The package's manifest, read once per isolate. Callers that change it must clone it first. */
export function starterPackageManifest(env:Env,id:string):Promise<any>{
 assert(isStarterPackage(id),'NOT_FOUND','起步模板不存在',404);
 let loading=manifests.get(id);
 if(!loading){loading=asset(env,`/starters/${id}/manifest.json`).then(response=>response.json());loading.catch(()=>manifests.delete(id));manifests.set(id,loading);}
 return loading;
}
export async function starterPackageFile(env:Env,id:string,file:string):Promise<Uint8Array>{
 assert(isStarterPackage(id)&&/^assets\/[A-Za-z0-9._-]{1,80}$/.test(file),'NOT_FOUND','起步模板素材不存在',404);
 return new Uint8Array(await (await asset(env,starterAssetUrl(id,file))).arrayBuffer());
}
