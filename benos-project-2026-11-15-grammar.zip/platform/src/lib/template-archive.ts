import { assert,AppError } from './errors';

const MIB=1_048_576;
export const MAX_TEMPLATE_ARCHIVE_BYTES=74*MIB;
export const MAX_TEMPLATE_ASSET_BYTES=64*MIB;
const CHUNK=64*1024;
const encoder=new TextEncoder(),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:false});
const crcTable=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n>>>1)^((n&1)?0xedb88320:0);return n>>>0;});
function updateCrc(crc:number,bytes:Uint8Array){for(const b of bytes)crc=(crc>>>8)^crcTable[(crc^b)&255];return crc;}
function reject(ok:unknown,message='模板 ZIP 目录或文件记录无效'):asserts ok{assert(ok,'TEMPLATE_ZIP_INVALID',message,422);}
const validName=(name:string)=>name==='manifest.json'||/^assets\/\d{1,2}\.(jpg|jpeg|png|webp|gif|svg|pdf)$/.test(name);
const fileLimit=(name:string)=>name==='manifest.json'?10*MIB:name.endsWith('.svg')?MIB:12*MIB;

/** The caller must bind a source to one immutable, authorized object. A range
 * source never exposes arbitrary bucket keys or loads the entire ZIP. */
export interface TemplateRangeSource { size:number; read(offset:number,length:number):Promise<Uint8Array>; }
export type TemplateArchiveEntry={name:string;size:number;packed:number;method:number;flags:number;checksum:number;offset:number;start:number;end:number};
export function r2TemplateRangeSource(bucket:R2Bucket,key:string,identity:{size:number;etag:string}):TemplateRangeSource{
 return {size:identity.size,async read(offset,length){
  const object=await bucket.get(key,{range:{offset,length},onlyIf:{etagMatches:identity.etag}});
  assert(object&&'body' in object&&object.etag===identity.etag&&object.size===identity.size,'TEMPLATE_SOURCE_CHANGED','暂存模板已变更或不可读取，请重试上传',409);
  return new Uint8Array(await object.arrayBuffer());
 }};
}
async function range(source:TemplateRangeSource,offset:number,length:number){
 reject(Number.isSafeInteger(offset)&&Number.isSafeInteger(length)&&offset>=0&&length>=0&&offset+length<=source.size);
 const bytes=await source.read(offset,length);reject(bytes instanceof Uint8Array&&bytes.length===length,'模板存储读取不完整');return bytes;
}
function view(bytes:Uint8Array){return new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);}
function nameText(bytes:Uint8Array){reject(bytes.every(b=>b>=32&&b<=126),'ZIP 文件名必须使用规范中的 ASCII 路径');return decoder.decode(bytes);}

/** Central-directory validation is completed BEFORE any file is inflated. Each
 * metadata read is <=65,557 bytes, even for archives with large extra fields. */
export async function openTemplateArchive(source:TemplateRangeSource):Promise<TemplateArchiveEntry[]>{
 reject(Number.isSafeInteger(source.size)&&source.size>=22&&source.size<=MAX_TEMPLATE_ARCHIVE_BYTES,'模板 ZIP 最大 74 MiB');
 const tailOffset=Math.max(0,source.size-22-65535),tail=await range(source,tailOffset,source.size-tailOffset),tv=view(tail);let end=-1;
 for(let at=tail.length-22;at>=0;at--)if(tv.getUint32(at,true)===0x06054b50&&at+22+tv.getUint16(at+20,true)===tail.length){end=at;break;}
 reject(end>=0);reject(tv.getUint16(end+4,true)===0&&tv.getUint16(end+6,true)===0&&tv.getUint16(end+8,true)===tv.getUint16(end+10,true),'不支持分卷 ZIP');
 const count=tv.getUint16(end+10,true),directorySize=tv.getUint32(end+12,true),directory=tv.getUint32(end+16,true),endOffset=tailOffset+end;
 reject(count>0&&count<=65&&directory+directorySize===endOffset&&directory>0,'ZIP 文件数量或目录边界不符');
 const entries:TemplateArchiveEntry[]=[],names=new Set<string>();let at=directory,total=0,assetTotal=0;
 for(let n=0;n<count;n++){
  reject(at+46<=endOffset);const h=view(await range(source,at,46));reject(h.getUint32(0,true)===0x02014b50);
  const flags=h.getUint16(8,true),method=h.getUint16(10,true),checksum=h.getUint32(16,true),packed=h.getUint32(20,true),size=h.getUint32(24,true),nameSize=h.getUint16(28,true),extraSize=h.getUint16(30,true),commentSize=h.getUint16(32,true),external=h.getUint32(38,true),offset=h.getUint32(42,true),recordEnd=at+46+nameSize+extraSize+commentSize;
  reject(recordEnd<=endOffset&&nameSize>0&&nameSize<=100&&h.getUint16(34,true)===0);
  const name=nameText(await range(source,at+46,nameSize));reject(validName(name)&&!names.has(name),'ZIP 只能包含一份根目录 manifest.json 与清单中的 assets 文件');names.add(name);
  reject((flags&~0x080e)===0&&(flags&1)===0&&[0,8].includes(method),'ZIP 压缩算法或加密标记不受支持');
  const mode=(external>>>16)&0xf000;reject((mode===0||mode===0x8000)&&(external&0x10)===0,'不允许目录或符号链接');
  reject(size>0&&size<=fileLimit(name)&&packed>0&&packed<=MAX_TEMPLATE_ARCHIVE_BYTES&&offset<directory,'ZIP 文件大小超过限制');
  total+=size;if(name!=='manifest.json')assetTotal+=size;reject(total<=MAX_TEMPLATE_ARCHIVE_BYTES&&assetTotal<=MAX_TEMPLATE_ASSET_BYTES,'模板素材总量最多 64 MiB');
  reject(offset+30<=directory);const l=view(await range(source,offset,30));reject(l.getUint32(0,true)===0x04034b50&&l.getUint16(6,true)===flags&&l.getUint16(8,true)===method);
  const localNameSize=l.getUint16(26,true),localExtra=l.getUint16(28,true),start=offset+30+localNameSize+localExtra;reject(start<=directory&&start+packed<=directory&&localNameSize===nameSize);
  reject(nameText(await range(source,offset+30,localNameSize))===name,'ZIP 本地记录与目录文件名不一致');
  let dataEnd=start+packed;
  if(flags&8){reject(dataEnd+12<=directory);const d=view(await range(source,dataEnd,Math.min(16,directory-dataEnd))),marker=d.getUint32(0,true)===0x08074b50?4:0;
   reject(d.byteLength>=marker+12&&d.getUint32(marker,true)===checksum&&d.getUint32(marker+4,true)===packed&&d.getUint32(marker+8,true)===size,'ZIP 数据描述符不一致');dataEnd+=marker+12;
  }else reject(l.getUint32(14,true)===checksum&&l.getUint32(18,true)===packed&&l.getUint32(22,true)===size,'ZIP 本地记录与目录大小不一致');
  reject(method!==0||packed===size,'ZIP 存储条目大小不一致');entries.push({name,size,packed,method,flags,checksum,offset,start,end:dataEnd});at=recordEnd;
 }
 reject(at===endOffset&&names.has('manifest.json'));let boundary=0;
 for(const entry of [...entries].sort((a,b)=>a.offset-b.offset)){reject(entry.offset===boundary,'ZIP 包含重叠记录、前缀或未声明文件');boundary=entry.end;}
 reject(boundary===directory,'ZIP 数据区包含未声明内容');return entries;
}

/** Inflate one entry only. The consumer must not commit staged output before
 * the iterator reaches EOF: length and CRC are final checks. */
export async function* streamTemplateEntry(source:TemplateRangeSource,entry:TemplateArchiveEntry):AsyncGenerator<Uint8Array>{
 reject(validName(entry.name)&&entry.size>0&&entry.size<=fileLimit(entry.name)&&[0,8].includes(entry.method)&&entry.start>=0&&entry.packed>0&&entry.start+entry.packed<=source.size);
 let cursor=entry.start;const stop=cursor+entry.packed;
 const compressed=new ReadableStream<Uint8Array>({async pull(controller){try{if(cursor===stop){controller.close();return;}const length=Math.min(CHUNK,stop-cursor),bytes=await range(source,cursor,length);cursor+=length;controller.enqueue(bytes);}catch(error){controller.error(error);}}},{highWaterMark:0});
 const stream=entry.method===8?compressed.pipeThrough(new DecompressionStream('deflate-raw')):compressed;
 const reader=stream.getReader();let length=0,crc=0xffffffff;
 try{while(true){const item=await reader.read();if(item.done)break;length+=item.value.length;reject(length<=entry.size,'ZIP 实际解压大小超过声明');crc=updateCrc(crc,item.value);yield item.value;}
  reject(length===entry.size,'ZIP 解压大小与声明不符');reject(((crc^0xffffffff)>>>0)===entry.checksum,'ZIP 文件 CRC 校验失败');
 }catch(error){if(error instanceof AppError)throw error;throw new AppError('TEMPLATE_ZIP_INVALID','ZIP 压缩数据无效或实际解压大小超过限制',422);}
 finally{await reader.cancel().catch(()=>{});reader.releaseLock();}
}
export async function readTemplateEntry(source:TemplateRangeSource,entry:TemplateArchiveEntry){
 reject(entry.size>0&&entry.size<=fileLimit(entry.name));const bytes=new Uint8Array(entry.size);let offset=0;for await(const chunk of streamTemplateEntry(source,entry)){bytes.set(chunk,offset);offset+=chunk.length;}return bytes;
}

export type TemplateZipAsset={file:string;size:number;load:()=>Promise<Uint8Array>};
/** Backpressured stored ZIP. Only the current verified file, the manifest, and
 * <=65 small directory records are retained. No concatenated archive buffer. */
export function streamTemplateZip(manifest:unknown,assets:TemplateZipAsset[]){
 const manifestBytes=encoder.encode(JSON.stringify(manifest));
 const entries:TemplateZipAsset[]=[{file:'manifest.json',size:manifestBytes.length,load:async()=>manifestBytes},...assets];
 reject(entries.length<=65);const names=new Set<string>();let size=22,assetTotal=0;
 for(const e of entries){reject(validName(e.file)&&!names.has(e.file));names.add(e.file);reject(Number.isSafeInteger(e.size)&&e.size>0&&e.size<=fileLimit(e.file),'ZIP 文件大小超过限制');size+=76+2*encoder.encode(e.file).length+e.size;if(e.file!=='manifest.json')assetTotal+=e.size;}
 reject(size<=MAX_TEMPLATE_ARCHIVE_BYTES&&assetTotal<=MAX_TEMPLATE_ASSET_BYTES,'模板 ZIP 或素材总量超过限制');
 async function* generate(){
  let offset=0;const indices:Uint8Array[]=[];
  for(const e of entries){
   const bytes=await e.load();reject(bytes.length===e.size,'导出素材大小与清单不符');const checksum=(updateCrc(0xffffffff,bytes)^0xffffffff)>>>0,name=encoder.encode(e.file),header=new Uint8Array(30+name.length),h=view(header);
   h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x0800,true);h.setUint16(12,0x2821,true);h.setUint32(14,checksum,true);h.setUint32(18,bytes.length,true);h.setUint32(22,bytes.length,true);h.setUint16(26,name.length,true);header.set(name,30);
   const index=new Uint8Array(46+name.length),v=view(index);v.setUint32(0,0x02014b50,true);v.setUint16(4,20,true);v.setUint16(6,20,true);v.setUint16(8,0x0800,true);v.setUint16(14,0x2821,true);v.setUint32(16,checksum,true);v.setUint32(20,bytes.length,true);v.setUint32(24,bytes.length,true);v.setUint16(28,name.length,true);v.setUint32(42,offset,true);index.set(name,46);indices.push(index);offset+=header.length+bytes.length;
   yield header;for(let at=0;at<bytes.length;at+=CHUNK)yield bytes.subarray(at,Math.min(bytes.length,at+CHUNK));
  }
  let centralLength=0;for(const entry of indices){centralLength+=entry.length;yield entry;}
  const end=new Uint8Array(22),v=view(end);v.setUint32(0,0x06054b50,true);v.setUint16(8,entries.length,true);v.setUint16(10,entries.length,true);v.setUint32(12,centralLength,true);v.setUint32(16,offset,true);yield end;
 }
 const iterator=generate(),stream=new ReadableStream<Uint8Array>({async pull(controller){try{const item=await iterator.next();if(item.done)controller.close();else controller.enqueue(item.value);}catch(error){controller.error(error);}},async cancel(){await iterator.return(undefined);}},{highWaterMark:0});
 // Workers derives Content-Length from its fixed-length stream rather than a
 // caller-supplied header. The transform also aborts if actual bytes differ.
 return {byteSize:size,stream:typeof FixedLengthStream==='function'?stream.pipeThrough(new FixedLengthStream(size)):stream};
}
