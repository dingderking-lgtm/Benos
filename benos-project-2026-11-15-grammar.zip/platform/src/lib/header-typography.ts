import { stripManagedFontImports } from '../contracts/design-web-fonts';
import { parseFragment } from 'parse5';
import { typographySnapshotSchema, freezeDesignFont, type TypographySnapshot } from '../contracts/design-typography';
import { assert } from './errors';

const START='/* benos-header-typography:btf-1:start */';
const END='/* benos-header-typography:btf-1:end */';
const attr=(n:any,key:string):string|undefined=>n.attrs?.find((a:any)=>a.name===key)?.value;
const textTags=new Set(['h1','h2','h3','h4','h5','h6','p','span','a','summary','strong','em','b','i','small','label','li','dt','dd','button']);
function entries(html:string){
 const root=parseFragment(html,{sourceCodeLocationInfo:true}),all:any[]=[],stack:any[]=[root];
 while(stack.length){const node=stack.pop();if(node.tagName&&node.sourceCodeLocation?.startTag)all.push(node);for(let i=(node.childNodes?.length??0)-1;i>=0;i--)stack.push(node.childNodes[i]);}
 return all;
}
function ignored(node:any){for(let n=node;n?.tagName;n=n.parentNode)if(attr(n,'aria-hidden')==='true'||['svg','img','style','script','template'].includes(n.tagName)||/(?:^|\s)(?:icon-|bnh-menu-icon|aacms-nav-chevron)/.test(attr(n,'class')||''))return true;return false;}
function text(node:any):boolean{return textTags.has(node.tagName)&&(node.childNodes??[]).some((n:any)=>n.nodeName==='#text'&&n.value.trim()||n.tagName&&!ignored(n));}
function selector(node:any){
 const segments:string[]=[];for(let n=node;n?.tagName;n=n.parentNode){
  if(n.tagName==='header'&&(attr(n,'class')||'').split(/\s+/).includes('bnh-site-header')){segments.unshift('header.bnh-site-header');return segments.join(' > ');}
  const siblings=(n.parentNode?.childNodes??[]).filter((x:any)=>x.tagName===n.tagName);segments.unshift(n.tagName+':nth-of-type('+(siblings.indexOf(n)+1)+')');
 }throw Error('TYPOGRAPHY_HEADER_TARGET');
}
function selectors(node:any){
 const primary=selector(node),li=node.parentNode,ul=li?.parentNode,nav=ul?.parentNode;
 // The compiler preview uses UL even for a flat source; official Renderer
 // removes that UL only when the menu has no nested items. Preserve both exact
 // representations, never a broad href selector that could style another item.
 if(node.tagName==='a'&&li?.tagName==='li'&&ul?.tagName==='ul'&&nav?.tagName==='nav'&&attr(nav,'data-aacms')==='site-navigation'&&attr(nav,'data-aacms-menu-markup')==='flat'){
  const list=(ul.childNodes??[]).filter((n:any)=>n.tagName==='li');
  if(list.every((n:any)=>!(n.childNodes??[]).some((c:any)=>c.tagName==='ul')))return primary+','+selector(nav)+' > a:nth-of-type('+(list.indexOf(li)+1)+')';
 }
 return primary;
}
/** Only frozen, server-owned sources can mint selectors. No selector/CSS input is
 * accepted from a client. nth-of-type remains stable when CMS inserts submenu
 * buttons, and the compiler and Renderer both use flat links or the same UL tree. */
export function projectCompiledHeaderTypography<T extends {templateId:number;html:string;css:string}>(header:T,value:TypographySnapshot|null):T{
 if(!value)return header;const snapshot=typographySnapshotSchema.parse(value),source=snapshot.headerSources?.find(s=>s.templateId===header.templateId);
 const overrides=snapshot.overrides.filter(o=>o.templateId===header.templateId&&o.headerNodeKey);
 if(!source){assert(!overrides.length,'TYPOGRAPHY_HEADER_SOURCE','页头字体缺少已确认来源',409);return header;}
 assert(header.html===source.html,'TYPOGRAPHY_HEADER_CONFLICT','页头结构已变化，请重新选择此处字体',409);
 const all=entries(source.html),targets=overrides.map(o=>({entry:o,node:all[Number(o.headerNodeKey!.slice(1))]}));
 for(const t of targets)assert(t.node&&text(t.node)&&!ignored(t.node),'TYPOGRAPHY_HEADER_TARGET','页头文字位置已变化，请重新选择',409);
 const rules:string[]=[];
 for(const node of all){if(!text(node)||ignored(node))continue;let chosen:typeof targets[number]|undefined;
  for(let n=node;n?.tagName&&!chosen;n=n.parentNode)chosen=targets.find(t=>t.node===n);
  if(chosen)rules.push(selectors(node)+'{font-family:'+chosen.entry.font.stack+'!important}');
 }
 const css=source.css+(rules.length?'\n'+START+'\n'+rules.join('\n')+'\n'+END:'');
 // A caller may supply the unprojected compiler snapshot or an already projected
 // header. Other CSS is never silently blessed as the trusted baseline.
 assert(header.css===source.css||header.css===css,'TYPOGRAPHY_HEADER_CONFLICT','页头样式已变化，字体设置不能覆盖其他修改',409);
 return {...header,css};
}

export function patchCompiledHeaderTypography(template:{id:number;document:{html:string;css?:string}},nodeKey:string,fontId:string,anchor:string,value:TypographySnapshot){
 const previous=typographySnapshotSchema.parse(value),profile=structuredClone(previous),source=profile.headerSources?.find(s=>s.templateId===template.id);
 const baseline=source??{templateId:template.id,html:template.document.html,css:template.document.css??''};
 if(!source)profile.headerSources=[...(profile.headerSources??[]),baseline];
 const current=projectCompiledHeaderTypography({...baseline},previous);
 assert(template.document.html===current.html&&String(template.document.css??'')===current.css,'TYPOGRAPHY_HEADER_CONFLICT','页头与已确认字体来源不一致',409);
 const node=entries(baseline.html)[Number(nodeKey.slice(1))];assert(node&&text(node)&&!ignored(node),'TYPOGRAPHY_NODE_INVALID','请选择页头中的具体文字',409);
 profile.overrides=profile.overrides.filter(o=>!(o.templateId===template.id&&o.headerNodeKey===nodeKey));
 if(fontId!=='inherit')profile.overrides.push({templateId:template.id,anchor,font:freezeDesignFont(fontId),headerNodeKey:nodeKey});
 const next=projectCompiledHeaderTypography({...baseline},profile);
 return {html:next.html,css:next.css,snapshot:typographySnapshotSchema.parse(profile)};
}

/** A font operation may alter only the compiler-derived CSS projection outside
 * the selected node. Generic node edits retain the original strict scope guard. */
export function typographyScopeProjection<T>(base:T,next:T,snapshot:TypographySnapshot):T{
 const before=base as any,after=structuredClone(next) as any;
 if(stripManagedFontImports(String(after.site?.theme?.global_css||'')).trim()===stripManagedFontImports(String(before.site?.theme?.global_css||'')).trim())after.site.theme.global_css=before.site.theme.global_css;
 for(const source of snapshot.headerSources??[]){const prior=before.templates.find((t:any)=>t.id===source.templateId),candidate=after.templates.find((t:any)=>t.id===source.templateId);if(!prior||!candidate)continue;
  const expected=projectCompiledHeaderTypography({...source},snapshot);
  assert(candidate.document.html===expected.html&&String(candidate.document.css??'')===expected.css,'TYPOGRAPHY_HEADER_CONFLICT','字体修改不能更改页头结构或其他样式',409);
  candidate.document.css=prior.document.css;
 }
 return after as T;
}
