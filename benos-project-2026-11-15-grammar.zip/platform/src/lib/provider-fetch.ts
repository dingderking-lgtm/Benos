/** Workers rejects redirect: 'error' before sending a request. Keep the same
 * no-redirect boundary with manual mode; never forward provider credentials.
 * https://developers.cloudflare.com/workers/runtime-apis/request/#properties
 */
export class ProviderRedirectError extends TypeError {
  constructor(readonly status: number) {
    super('Service redirect refused');
    this.name = 'ProviderRedirectError';
  }
}

export async function fetchWithoutRedirect(
  input: Parameters<typeof fetch>[0],
  init: Parameters<typeof fetch>[1] = {},
  send: typeof fetch = fetch,
): Promise<Response> {
  const response = await send(input, { ...init, redirect: 'manual' });
  if (response.status >= 300 && response.status < 400) {
    // Disposal must not replace the safe failure with an upstream stream error.
    try { await response.body?.cancel(); } catch { /* Still refuse the redirect. */ }
    throw new ProviderRedirectError(response.status);
  }
  return response;
}
