import { createLayoutPlan,type LayoutPlan,type LayoutPlanInput } from '../contracts/layout-plan';
import { AppError } from './errors';

export interface LayoutAllocationInput extends Omit<LayoutPlanInput,'history'> {
 userId:string;workflowId:string;requestKey:string;
 /** Must insert this exact workflow id. Both statements are one transaction. */
 workflowStatement:(plan:LayoutPlan)=>D1PreparedStatement;
}
/** Cursor check is a DB trigger, not a read-then-write promise. A racing winner
 * rolls back this entire batch; no orphan workflow or consumed allocation. */
export async function allocateWorkflowLayout(db:D1Database,input:LayoutAllocationInput):Promise<void>{
 await db.prepare('INSERT OR IGNORE INTO design_layout_cursors(user_id) VALUES(?)').bind(input.userId).run();
 for(let attempt=0;attempt<8;attempt++){
  const replay=await db.prepare('SELECT workflow_id FROM design_layout_allocations WHERE user_id=? AND request_key=?').bind(input.userId,input.requestKey).first();
  if(replay)return;
  const cursor=await db.prepare('SELECT sequence FROM design_layout_cursors WHERE user_id=?').bind(input.userId).first<{sequence:number}>();
  const recent=await db.prepare("SELECT plan_json FROM design_layout_allocations WHERE user_id=? AND source='automatic' ORDER BY sequence DESC LIMIT 7").bind(input.userId).all<{plan_json:string}>();
  const plan=await createLayoutPlan({...input,history:recent.results.map(row=>JSON.parse(row.plan_json))});
  try{await db.batch([
   input.workflowStatement(plan),
   db.prepare(`INSERT INTO design_layout_allocations(workflow_id,user_id,request_key,sequence,source,combination_hash,primary_media_composition,plan_json,created_at)
    SELECT ?,?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM ai_workflows WHERE id=? AND user_id=? AND request_key=?)`).bind(input.workflowId,input.userId,input.requestKey,cursor!.sequence+1,plan.source,plan.combinationHash,plan.primaryMediaComposition,JSON.stringify(plan),new Date().toISOString(),input.workflowId,input.userId,input.requestKey),
  ]);return;}catch(error){
   const cause=String(error)+' '+String((error as Error)?.cause);
   if(!cause.includes('layout_allocation_conflict'))throw error;
  }
 }
 throw new AppError('LAYOUT_ALLOCATION_BUSY','设计布局分配繁忙，请稍后使用同一请求重试',503);
}
