import { parseFragment, type DefaultTreeAdapterMap } from 'parse5';
import { IMAGE_FRAME_PLAN_VERSION, IMAGE_FRAME_PLAN_V2_VERSION, resolvePlannedImageFrame, type CompiledImageFrame, type ImageFramePlan } from './image-frame-plan';
import { imageSlotSchema, IMAGE_SIZES } from './image-layout';

type Node = DefaultTreeAdapterMap['node'];
type Element = DefaultTreeAdapterMap['element'];
type Template = { id: number; document: { html: string; [key: string]: unknown }; [key: string]: unknown };
type Manifest = { templates: Template[]; [key: string]: unknown };
type Edit = { start: number; end: number; text: string };
type LocatedFrame = { node: Element; wrappers: Element[]; template: Template; frame: CompiledImageFrame; image?: Element };
type ParseError = { startOffset?: number; endOffset?: number };
export type PreparedSiteLayoutIssue = { code: string; message: string; frameId?: string; templateId?: number };
export type PreparedSiteLayoutResult<T> = { manifest: T; issues: PreparedSiteLayoutIssue[] };
/** Ownership and manifest.assets insertion belong to the caller. These are
 * verified media records, never model-supplied URLs or invented dimensions. */
export type PreparedImageBinding = { frameId: string; asset: { id: string | number; width: number; height: number; mime?: string; path?: string }; src: string; alt: string };
export const PREPARED_IMAGE_RETENTION_VERSION = 'prepared-image-retention-v1' as const;
export type PreparedImageCompletionReceipt = { frameId: string; ok: boolean; asset?: { path: string }; width?: number; height?: number };
export type PreparedImageRetention = {
  version: typeof PREPARED_IMAGE_RETENTION_VERSION;
  images: Array<{ frameId: string; templateId: number; pageKeys: string[]; src: string; width: number; height: number }>;
};
export const PREPARED_IMAGE_DISPOSITIONS_VERSION = 'prepared-image-dispositions-v1' as const;
export const IMAGE_DISPOSITION_REASONS = ['content_mismatch', 'unsupported_claim', 'generation_defect', 'redundant', 'user_requested'] as const;
export type PreparedImageDispositionInput = { frameId: string; reasonCode: typeof IMAGE_DISPOSITION_REASONS[number]; reason: string };
export type PreparedImageDispositions = { version: typeof PREPARED_IMAGE_DISPOSITIONS_VERSION; images: Array<PreparedImageRetention['images'][number] & PreparedImageDispositionInput & { stepId: string; callId: string }> };
export type PreparedImageOmission = PreparedImageDispositionInput & { templateId: number; pageKeys: string[] };
const HTML = 'http://www.w3.org/1999/xhtml';
const PREFIX = 'bnf-image-';
const ID = /^[a-z][a-z0-9-]{0,59}$/;
const attr = (node: Element, name: string) => node.attrs.find(a => a.name === name && !a.namespace)?.value;
const escape = (text: string) => text.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const dynamic = (text: string) => /\{\{|\}\}|\{%|%\}/.test(text);
const protectedNode = (node: Element) => ['nav', 'a', 'button', 'label', 'form', 'template', 'select', 'picture', 'svg', 'math', 'figcaption', 'textarea'].includes(node.tagName)
  || node.namespaceURI !== HTML || node.attrs.some(a => /^data-(?:aacms|form|menu|template|placeholder)(?:-|$)/i.test(a.name) || dynamic(a.value));
function issue(code: string, message: string, frame?: CompiledImageFrame, template?: Template): PreparedSiteLayoutIssue {
  return { code, message, ...(frame ? { frameId: frame.id } : {}), ...(template ? { templateId: template.id } : {}) };
}
function validSource(src: unknown): src is string {
  if (typeof src !== 'string' || !src || src.length > 4096 || /[\u0000-\u0020\u007f\\<>"']/u.test(src) || dynamic(src)) return false;
  if (/^\/(?!\/)/.test(src)) return src.length > 1;
  try { const url = new URL(src); return ['https:', 'http:'].includes(url.protocol) && !!url.hostname && !url.username && !url.password; } catch { return false; }
}
function validMediaId(value: unknown): boolean { return (typeof value === 'string' || typeof value === 'number') && /^[a-zA-Z0-9_-]{1,160}$/.test(String(value)); }
function plainBoundImage(node: Element): boolean {
  const allowed = new Set(['src', 'alt', 'width', 'height', 'style', 'loading', 'decoding']);
  return node.tagName === 'img' && node.namespaceURI === HTML && node.attrs.every(a => !a.namespace && allowed.has(a.name) && !dynamic(a.value))
    && validSource(attr(node, 'src'))
    && [attr(node, 'width'), attr(node, 'height')].every(value => !!value && /^\d+$/.test(value) && Number(value) > 0 && Number(value) <= 32768);
}
function validPlan(plan: ImageFramePlan): boolean {
  return !!plan && [IMAGE_FRAME_PLAN_VERSION, IMAGE_FRAME_PLAN_V2_VERSION].includes(plan.version) && Array.isArray(plan.frames) && plan.frames.length <= 12
    && new Set(plan.frames.map(frame => frame?.id)).size === plan.frames.length
    && plan.frames.every(frame => frame && typeof frame.id === 'string' && ID.test(frame.id) && frame.elementId === PREFIX + frame.id
      && ['adapt', 'fixed'].includes(frame.framePolicy) && ['complete', 'crop-safe'].includes(frame.subjectPolicy)
      && (plan.version === IMAGE_FRAME_PLAN_VERSION ? frame.presentation === undefined : ['standard', 'hero-cover'].includes(frame.presentation || ''))
      && (frame.presentation !== 'hero-cover' || frame.framePolicy === 'fixed' && frame.subjectPolicy === 'crop-safe' && !frame.preserveContain && frame.resolvedSlot.fit === 'cover' && frame.generation?.size === '1536x1024')
      && imageSlotSchema.safeParse(frame.requestedSlot).success && imageSlotSchema.safeParse(frame.resolvedSlot).success
      && IMAGE_SIZES.includes(frame.generation?.size) && Number.isInteger(frame.generation?.width) && frame.generation.width > 0
      && Number.isInteger(frame.generation?.height) && frame.generation.height > 0);
}
function safeFrameStyle(style: string): boolean {
  if (/url\s*\(|expression\s*\(|@|[{}<>"'\\]|\/\*|\*\//i.test(style)) return false;
  let depth = 0;
  for (const character of style) {
    if (character === '(' && ++depth > 16) return false;
    if (character === ')' && --depth < 0) return false;
  }
  return depth === 0;
}
const MEDIA_ATTRIBUTES = new Set(['id', 'class', 'style', 'title', 'role', 'aria-label', 'aria-labelledby', 'aria-describedby']);
const meaningfulChildren = (node: Element) => node.childNodes.filter(child => child.nodeName !== '#comment' && !(child.nodeName === '#text' && 'value' in child && !child.value.trim()));
const hasClass = (node: Element, name: string) => (attr(node, 'class') || '').split(/\s+/).includes(name);
/** Cover layout is an explicit v2 contract. Do not infer it from a class on an
 * old product frame, or let a background wrapper capture the business copy. */
function coverSection(node: Element): Element | null {
  const section = node.parentNode;
  if (!section || !('tagName' in section) || section.tagName !== 'section' || !hasClass(section, 'bnf-hero-cover') || protectedNode(section)) return null;
  const children = meaningfulChildren(section), content = children.find(child => child !== node);
  if (children.length !== 2 || children[0] !== node || !content || !('tagName' in content) || content.tagName !== 'div'
    || !hasClass(content, 'bnf-container') || !hasClass(content, 'bnf-hero-cover-content')) return null;
  const panels = meaningfulChildren(content);
  if (panels.length !== 1 || !('tagName' in panels[0]) || panels[0].tagName !== 'div' || !hasClass(panels[0], 'bnf-hero-cover-panel')) return null;
  return section;
}
function plainMediaContainer(node: Element, errors: ParseError[]): boolean {
  const location = node.sourceCodeLocation;
  return node.namespaceURI === HTML && ['div', 'figure'].includes(node.tagName)
    && node.attrs.every(a => !a.namespace && MEDIA_ATTRIBUTES.has(a.name) && !dynamic(a.value))
    && (attr(node, 'role') === undefined || ['img', 'none', 'presentation', 'figure'].includes(attr(node, 'role')!))
    && safeFrameStyle(attr(node, 'style') || '') && !!location?.startTag && !!location.endTag
    && !errors.some(error => error.startOffset !== undefined && error.startOffset >= location.startOffset && error.startOffset < location.startTag!.endOffset);
}
/** A shell containing only this media chain shares its resolved dimensions.
 * Stop at a caption, sibling, text, control, binding or non-media container.
 * IDs, classes, hierarchy, backgrounds, radii and margins remain untouched. */
function pureMediaWrappers(frame: Element, errors: ParseError[]): Element[] | null {
  // An unusual interactive div ancestor is not a media shell even when its
  // interactivity is expressed through role/handlers instead of an HTML button.
  for (let at: Node | null = frame.parentNode; at; at = 'parentNode' in at ? at.parentNode : null) {
    if ('tagName' in at && (protectedNode(at) || at.attrs.some(a => /^on/i.test(a.name) || a.name === 'tabindex')
      || ['button', 'link', 'menu', 'menuitem', 'tab', 'checkbox', 'radio', 'switch', 'slider', 'textbox', 'combobox'].includes(attr(at, 'role') || ''))) return [];
  }
  const wrappers: Element[] = [];
  let child = frame;
  while (child.parentNode && 'tagName' in child.parentNode) {
    const parent = child.parentNode, children = meaningfulChildren(parent);
    if (!plainMediaContainer(parent, errors) || children.length !== 1 || children[0] !== child) break;
    wrappers.push(parent);
    // Bound source-span work as well as tree traversal; pathological nesting
    // must not expand into megabytes of repeated inline CSS.
    if (wrappers.length > 64) return null;
    child = parent;
  }
  return wrappers;
}

/** Parse once per template and edit only source spans. Unrelated HTML, CSS,
 * uploaded images, captions and asset arrays retain their original bytes. */
function locate(input: unknown, plan: ImageFramePlan, mode: 'prepare' | 'bind' | 'completion') {
  const issues: PreparedSiteLayoutIssue[] = [], found: LocatedFrame[] = [];
  const sourceImages: Array<{ node: Element; template: Template }> = [];
  if (!validPlan(plan)) return { issues: [issue('INVALID_FRAME_PLAN', '图片框计划无效，请重新编译布局。')], found };
  const manifest = input as Manifest;
  if (!manifest || !Array.isArray(manifest.templates) || manifest.templates.length > 200
    || manifest.templates.some(template => !template || !Number.isSafeInteger(template.id) || typeof template.document?.html !== 'string')
    || new Set(manifest.templates.map(template => template.id)).size !== manifest.templates.length) return { issues: [issue('INVALID_LAYOUT_MANIFEST', '模板结构无效。')], found };
  const byId = new Map(plan.frames.map(frame => [frame.elementId, frame])), counts = new Map<string, number>();
  let characters = 0, visited = 0;
  for (const template of manifest.templates) {
    const html = template.document.html;
    if ((characters += html.length) > 600_000) return { issues: [issue('LAYOUT_TOO_COMPLEX', '模板过大，未修改任何内容。')], found: [] };
    const errors: ParseError[] = [];
    const root = parseFragment(html, { sourceCodeLocationInfo: true, onParseError: error => errors.push(error) });
    const stack: Array<{ node: Node; protectedParent: boolean }> = [{ node: root, protectedParent: false }];
    while (stack.length) {
      const { node, protectedParent } = stack.pop()!;
      if (++visited > 30_000) return { issues: [issue('LAYOUT_TOO_COMPLEX', '模板节点过多，未修改任何内容。')], found: [] };
      let protectedChildren = protectedParent;
      if ('tagName' in node) {
        if (node.tagName === 'img' || node.tagName === 'source') sourceImages.push({ node, template });
        protectedChildren ||= protectedNode(node);
        const id = attr(node, 'id');
        if (id?.startsWith(PREFIX)) {
          counts.set(id, (counts.get(id) || 0) + 1);
          const frame = byId.get(id);
          if (!frame) issues.push(issue('UNPLANNED_IMAGE_FRAME', `图片标记 ${id} 未映射到布局计划。`, undefined, template));
          else {
            const children = meaningfulChildren(node);
            const image = children.length === 1 && 'tagName' in children[0] && plainBoundImage(children[0]) ? children[0] : undefined;
            if (protectedChildren || !plainMediaContainer(node, errors)) issues.push(issue('UNSAFE_IMAGE_FRAME', '图片框必须是独立、闭合且无动态绑定的普通 div/figure；不能放在导航、表单或 picture 内。', frame, template));
            else if (frame.presentation === 'hero-cover' && !coverSection(node)) issues.push(issue('INVALID_COVER_STRUCTURE', '封面图片必须是 bnf-hero-cover 的首个直接子项；文字放在其后的 bnf-container bnf-hero-cover-content > bnf-hero-cover-panel 内。', frame, template));
            else if (children.length && (mode === 'prepare' || !image)) issues.push(issue('IMAGE_FRAME_CONTENT', '图片框只能为空白/注释占位；图注放框外，已有图片、picture 和业务内容不能被替换。', frame, template));
            else if (mode === 'completion' && !image) issues.push(issue('UNFINISHED_IMAGE_FRAME', '图片框尚未绑定真实图片；请完成图片或移除框标记后改用内容退化。', frame, template));
            else {
              const wrappers = mode === 'completion' ? [] : pureMediaWrappers(node, errors);
              if (!wrappers) issues.push(issue('LAYOUT_TOO_COMPLEX', '媒体包装层过深，未修改任何内容。', frame, template));
              else found.push({ node, wrappers, template, frame, ...(image ? { image } : {}) });
            }
          }
        }
        if (node.tagName === 'template' && 'content' in node) stack.push({ node: node.content as Node, protectedParent: true });
      }
      if ('childNodes' in node) for (let i = node.childNodes.length - 1; i >= 0; i--) stack.push({ node: node.childNodes[i], protectedParent: protectedChildren });
    }
  }
  for (const frame of plan.frames) {
    const count = counts.get(frame.elementId) || 0;
    if (count > 1) issues.push(issue('DUPLICATE_IMAGE_FRAME', '图片框 ID 在模板中重复，无法唯一绑定。', frame));
    else if (!count && mode !== 'completion') issues.push(issue('MISSING_IMAGE_FRAME', '计划中的图片框不存在于模板 HTML。', frame));
  }
  return { issues, found, sourceImages };
}

const FRAME_PROPERTIES = ['display', 'box-sizing', 'width', 'max-width', 'min-width', 'height', 'max-height', 'min-height', 'aspect-ratio', 'overflow', 'padding', 'border'];
function frameStyle(node: Element, width: number, height: number, cover = false): string {
  // Only discard exact simple declarations controlled by this compiler. The
  // remainder is preserved, and final !important geometry wins the cascade.
  const properties = cover ? [...FRAME_PROPERTIES, 'position', 'top', 'right', 'bottom', 'left', 'inset', 'transform', 'margin'] : FRAME_PROPERTIES;
  const prior = (attr(node, 'style') || '').split(';').filter(part => !properties.includes(part.split(':', 1)[0].trim().toLowerCase())).join(';').replace(/;+$/, '');
  if (cover) return (prior ? prior + ';' : '') + 'display:block!important;position:relative!important;top:auto!important;right:auto!important;bottom:auto!important;left:auto!important;transform:none!important;box-sizing:border-box!important;width:100%!important;max-width:none!important;min-width:0!important;height:var(--bnf-hero-cover-height,min(88vh,760px))!important;max-height:none!important;min-height:0!important;aspect-ratio:auto!important;overflow:hidden!important;margin:0!important;padding:0!important;border:0!important';
  return (prior ? prior + ';' : '') + `display:block!important;box-sizing:border-box!important;width:100%!important;max-width:${width}px!important;min-width:0!important;height:auto!important;max-height:none!important;min-height:0!important;aspect-ratio:${width} / ${height}!important;overflow:hidden!important;padding:0!important;border:0!important`;
}
function styleEdit(node: Element, style: string): Edit {
  const location = node.sourceCodeLocation!, existing = location.attrs?.style;
  return existing ? { start: existing.startOffset, end: existing.endOffset, text: `style="${escape(style)}"` }
    : { start: location.startTag!.endOffset - 1, end: location.startTag!.endOffset - 1, text: ` style="${escape(style)}"` };
}
function classEdit(node: Element, classes: string): Edit {
  const location = node.sourceCodeLocation!, existing = location.attrs?.class;
  return existing ? { start: existing.startOffset, end: existing.endOffset, text: `class="${escape(classes)}"` }
    : { start: location.startTag!.endOffset - 1, end: location.startTag!.endOffset - 1, text: ` class="${escape(classes)}"` };
}
function apply<T>(input: T, changes: Map<number, Edit[]>): T {
  const manifest = input as Manifest;
  if (!changes.size) return input;
  return { ...manifest, templates: manifest.templates.map(template => {
    const edits = changes.get(template.id); if (!edits?.length) return template;
    let html = template.document.html;
    for (const edit of edits.sort((a, b) => b.start - a.start || b.end - a.end)) html = html.slice(0, edit.start) + edit.text + html.slice(edit.end);
    return { ...template, document: { ...template.document, html } };
  }) } as T;
}
function addEdit(changes: Map<number, Edit[]>, template: Template, edit: Edit) { const edits = changes.get(template.id) || []; edits.push(edit); changes.set(template.id, edits); }
function coverClasses(changes: Map<number, Edit[]>, template: Template, node: Element, frame: CompiledImageFrame) {
  if (frame.presentation !== 'hero-cover') return;
  const section = coverSection(node)!;
  if (!hasClass(node, 'bnf-hero-cover-media')) addEdit(changes, template, classEdit(node, [attr(node, 'class'), 'bnf-hero-cover-media'].filter(Boolean).join(' ')));
  const modifier = 'bnf-hero-cover-text-' + frame.resolvedSlot.textSafeArea;
  const classes = (attr(section, 'class') || '').split(/\s+/).filter(value => value && !/^bnf-hero-cover-text-(?:left|right|top|bottom|none)$/.test(value));
  classes.push(modifier);
  if (classes.join(' ') !== attr(section, 'class')) addEdit(changes, template, classEdit(section, classes.join(' ')));
}

export function prepareSiteLayout<T>(manifest: T, plan: ImageFramePlan): PreparedSiteLayoutResult<T> {
  try {
    const scan = locate(manifest, plan, 'prepare'); if (scan.issues.length) return { manifest, issues: scan.issues };
    const changes = new Map<number, Edit[]>();
    for (const { node, wrappers, template, frame } of scan.found) {
      coverClasses(changes, template, node, frame);
      for (const target of [node, ...wrappers]) addEdit(changes, template, styleEdit(target, frameStyle(target, frame.resolvedSlot.width, frame.resolvedSlot.height, frame.presentation === 'hero-cover')));
    }
    return { manifest: apply(manifest, changes), issues: [] };
  } catch { return { manifest, issues: [issue('INVALID_LAYOUT', '无法安全解析图片布局，未修改内容。')] }; }
}

export function bindPreparedImages<T>(manifest: T, plan: ImageFramePlan, images: readonly PreparedImageBinding[]): PreparedSiteLayoutResult<T> {
  try {
    const scan = locate(manifest, plan, 'bind'); if (scan.issues.length) return { manifest, issues: scan.issues };
    const issues: PreparedSiteLayoutIssue[] = [], changes = new Map<number, Edit[]>(), seen = new Set<string>();
    if (!Array.isArray(images) || images.length > 12) return { manifest, issues: [issue('INVALID_IMAGE_BINDINGS', '图片绑定列表无效。')] };
    for (const binding of images) {
      const target = scan.found.find(found => found.frame.id === binding?.frameId);
      if (!target || seen.has(binding.frameId)) { issues.push(issue('INVALID_IMAGE_BINDING', '图片绑定缺少唯一的已计划图框。')); continue; }
      seen.add(binding.frameId);
      const { node, wrappers, template, frame, image } = target, asset = binding.asset;
      if (!asset || !validMediaId(asset.id) || !validSource(binding.src) || typeof binding.alt !== 'string' || binding.alt.length > 2000
        || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(binding.alt) || dynamic(binding.alt)
        || (asset.mime !== undefined && !/^image\/(?:png|jpeg|webp|avif|gif)$/.test(asset.mime))) {
        issues.push(issue('INVALID_IMAGE_ASSET', '图片必须来自调用方已验证的项目媒体，使用安全地址、真实尺寸和文本说明。', frame, template)); continue;
      }
      if (image && (attr(image, 'src') !== binding.src || attr(image, 'width') !== String(asset.width) || attr(image, 'height') !== String(asset.height))) {
        issues.push(issue('IMAGE_FRAME_ALREADY_BOUND', '图片框已绑定其他素材，不能隐式替换。', frame, template)); continue;
      }
      const receipt = resolvePlannedImageFrame(frame, asset.width, asset.height), slot = receipt.slot;
      const cover = frame.presentation === 'hero-cover';
      coverClasses(changes, template, node, frame);
      for (const target of [node, ...wrappers]) addEdit(changes, template, styleEdit(target, frameStyle(target, slot.width, slot.height, cover)));
      const imageStyle = `display:block!important;position:static!important;box-sizing:border-box!important;width:100%!important;max-width:100%!important;min-width:0!important;height:${cover ? '100%' : 'auto'}!important;max-height:none!important;min-height:0!important;aspect-ratio:${cover ? 'auto' : slot.width + ' / ' + slot.height}!important;object-fit:${receipt.display.objectFit}!important;object-position:${receipt.display.objectPosition}!important;margin:0!important;padding:0!important;border:0!important`;
      const markup = `<img src="${escape(binding.src)}" alt="${escape(binding.alt)}" width="${asset.width}" height="${asset.height}" style="${imageStyle}">`;
      addEdit(changes, template, { start: node.sourceCodeLocation!.startTag!.endOffset, end: node.sourceCodeLocation!.endTag!.startOffset, text: markup });
    }
    return issues.length ? { manifest, issues } : { manifest: apply(manifest, changes), issues: [] };
  } catch { return { manifest, issues: [issue('INVALID_IMAGE_BINDING', '图片尺寸或绑定结构无效，未修改内容。')] }; }
}

function imagePages(manifest: unknown): Array<{ key: string; template_id: number }> {
  const pages = (manifest as { site?: { pages?: unknown } } | null)?.site?.pages;
  return Array.isArray(pages) ? pages.filter(page => page && typeof page.key === 'string' && Number.isSafeInteger(page.template_id)) : [];
}
const mediaDimension = (value: unknown): value is number => typeof value === 'number' && Number.isSafeInteger(value) && value > 0 && value <= 32768;
function validDisposition(value: PreparedImageDispositionInput): boolean {
  return !!value && typeof value.frameId === 'string' && ID.test(value.frameId) && IMAGE_DISPOSITION_REASONS.includes(value.reasonCode)
    && typeof value.reason === 'string' && value.reason.trim() === value.reason && value.reason.length >= 10 && value.reason.length <= 300 && !/[\u0000-\u001f\u007f]/u.test(value.reason);
}
function dispositionRecords(retention: PreparedImageRetention, dispositions?: PreparedImageDispositions): Map<string, PreparedImageDispositions['images'][number]> | null {
  const records = new Map<string, PreparedImageDispositions['images'][number]>();
  if (dispositions === undefined) return records;
  if (!dispositions || dispositions.version !== PREPARED_IMAGE_DISPOSITIONS_VERSION || !Array.isArray(dispositions.images) || dispositions.images.length > 8) return null;
  for (const record of dispositions.images) {
    const saved = retention.images.find(image => image.frameId === record?.frameId);
    if (!saved || !validDisposition(record) || records.has(record.frameId) || typeof record.stepId !== 'string' || !record.stepId || record.stepId.length > 200 || typeof record.callId !== 'string' || !record.callId || record.callId.length > 200
      || record.templateId !== saved.templateId || record.src !== saved.src || record.width !== saved.width || record.height !== saved.height || JSON.stringify(record.pageKeys) !== JSON.stringify(saved.pageKeys)) return null;
    records.set(record.frameId, record);
  }
  return records;
}

/** A bounded append-only decision log, separate from the original success
 * snapshot. Server context supplies receipt identity; recording does not remove
 * an image, rewrite HTML, request a provider or change billing. */
export function recordPreparedImageDispositions(retention: PreparedImageRetention, input: readonly PreparedImageDispositionInput[], context: { stepId: string; callId: string }, existing?: PreparedImageDispositions): { dispositions: PreparedImageDispositions | null; issues: PreparedSiteLayoutIssue[] } {
  try {
    if (retention?.version !== PREPARED_IMAGE_RETENTION_VERSION || !Array.isArray(retention.images) || !Array.isArray(input) || !input.length || input.length > 8
      || typeof context.stepId !== 'string' || !context.stepId || context.stepId.length > 200 || typeof context.callId !== 'string' || !context.callId || context.callId.length > 200) throw new Error('invalid');
    const records = dispositionRecords(retention, existing), seen = new Set<string>();
    if (!records) throw new Error('invalid');
    for (const decision of input) {
      const saved = retention.images.find(image => image.frameId === decision?.frameId);
      if (!saved || !validDisposition(decision) || seen.has(decision.frameId)) throw new Error('invalid');
      seen.add(decision.frameId);
      const previous = records.get(decision.frameId);
      if (previous && (previous.reason !== decision.reason || previous.reasonCode !== decision.reasonCode)) return { dispositions: null, issues: [issue('IMAGE_DISPOSITION_CONFLICT', '该图片的弃用原因已记录，不能改写原决定。')] };
      if (!previous) records.set(decision.frameId, { ...saved, pageKeys: [...saved.pageKeys], ...decision, stepId: context.stepId, callId: context.callId });
    }
    if (records.size > 8) throw new Error('invalid');
    return { dispositions: { version: PREPARED_IMAGE_DISPOSITIONS_VERSION, images: [...records.values()] }, issues: [] };
  } catch { return { dispositions: null, issues: [issue('INVALID_IMAGE_DISPOSITION', '只能为本次成功图片记录唯一的弃用原因，不能引用未知或失败图片。')] }; }
}

/** Capture only server-confirmed successes, immediately after binding. The caller
 * owns receipt authenticity and persists this snapshot outside model-authored
 * files. This never upgrades old workflows or requires failed images to exist. */
export function freezePreparedImageRetention(manifest: unknown, plan: ImageFramePlan, receipts: readonly PreparedImageCompletionReceipt[]): { retention: PreparedImageRetention | null; issues: PreparedSiteLayoutIssue[] } {
  try {
    const scan = locate(manifest, plan, 'bind');
    if (scan.issues.length) return { retention: null, issues: scan.issues };
    if (!Array.isArray(receipts) || receipts.length !== plan.frames.length) return { retention: null, issues: [issue('INVALID_IMAGE_RECEIPTS', '图片回执必须覆盖本次全部已计划图框。')] };
    const issues: PreparedSiteLayoutIssue[] = [], images: PreparedImageRetention['images'] = [], seen = new Set<string>(), pages = imagePages(manifest);
    for (const receipt of receipts) {
      const target = scan.found.find(found => found.frame.id === receipt?.frameId);
      if (!target || seen.has(receipt.frameId) || typeof receipt.ok !== 'boolean') { issues.push(issue('INVALID_IMAGE_RECEIPTS', '图片回执缺少唯一的已计划图框。')); continue; }
      seen.add(receipt.frameId);
      if (!receipt.ok) continue;
      const { image, frame, template } = target;
      if (!validSource(receipt.asset?.path) || !mediaDimension(receipt.width) || !mediaDimension(receipt.height)
        || !image || attr(image, 'src') !== receipt.asset.path || attr(image, 'width') !== String(receipt.width) || attr(image, 'height') !== String(receipt.height)) {
        issues.push(issue('IMAGE_RECEIPT_MISMATCH', '已生成图片与绑定回执不一致，不能冻结保留记录。', frame, template)); continue;
      }
      images.push({ frameId: frame.id, templateId: template.id, pageKeys: [...new Set(pages.filter(page => page.template_id === template.id).map(page => page.key))].sort(), src: receipt.asset.path, width: receipt.width, height: receipt.height });
    }
    return issues.length ? { retention: null, issues } : { retention: { version: PREPARED_IMAGE_RETENTION_VERSION, images }, issues: [] };
  } catch { return { retention: null, issues: [issue('INVALID_IMAGE_RECEIPTS', '无法安全冻结图片回执。')] }; }
}

/** Without a retention snapshot, old workflows keep their existing content
 * fallback behavior. A new server-owned snapshot protects successful bindings;
 * missing failed frames remain allowed. Neither mode proves image visibility,
 * network loading, media ownership or subject completeness. */
export function validatePreparedImageCompletion(manifest: unknown, plan: ImageFramePlan, retention?: PreparedImageRetention, dispositions?: PreparedImageDispositions): PreparedSiteLayoutIssue[] {
  try {
    const scan = locate(manifest, plan, 'completion');
    if (retention === undefined) return dispositions === undefined ? scan.issues : [...scan.issues, issue('INVALID_IMAGE_DISPOSITION', '弃用决定缺少成功图片的保留记录。')];
    if (!retention || retention.version !== PREPARED_IMAGE_RETENTION_VERSION || !Array.isArray(retention.images) || retention.images.length > 12)
      return [...scan.issues, issue('INVALID_IMAGE_RETENTION', '已生成图片的保留记录无效。')];
    const decisions = dispositionRecords(retention, dispositions);
    if (!decisions) return [...scan.issues, issue('INVALID_IMAGE_DISPOSITION', '图片弃用决定与原成功回执不一致。')];
    const issues = [...scan.issues], seen = new Set<string>(), pages = imagePages(manifest);
    // Shared byte-deduplicated assets may legitimately back multiple original
    // frames. Exempt only those other still-intact frozen bindings, not an
    // unmarked copy of the discarded image or a copy moved to another page.
    const intactImages = new Set(scan.found.filter(target => {
      const saved = retention.images.find(image => image.frameId === target.frame.id);
      return saved && target.template.id === saved.templateId && target.image && attr(target.image, 'src') === saved.src && attr(target.image, 'width') === String(saved.width) && attr(target.image, 'height') === String(saved.height);
    }).map(target => target.image));
    for (const saved of retention.images) {
      const frame = plan.frames.find(frame => frame.id === saved?.frameId);
      if (!frame || seen.has(saved.frameId) || !Number.isSafeInteger(saved.templateId) || saved.templateId <= 0
        || !Array.isArray(saved.pageKeys) || saved.pageKeys.some(key => typeof key !== 'string' || !key || key.length > 200)
        || new Set(saved.pageKeys).size !== saved.pageKeys.length || !validSource(saved.src) || !mediaDimension(saved.width) || !mediaDimension(saved.height)) {
        issues.push(issue('INVALID_IMAGE_RETENTION', '已生成图片的保留记录无效。')); continue;
      }
      seen.add(saved.frameId);
      const target = scan.found.find(found => found.frame.id === saved.frameId);
      if (saved.pageKeys.some(key => !pages.some(page => page.key === key && page.template_id === saved.templateId)) || target && target.template.id !== saved.templateId)
        issues.push({ ...issue('SUCCESSFUL_IMAGE_PAGE_CHANGED', '已成功生成图片的原页面必须保留，图片也不能搬到别页。', frame), templateId: saved.templateId });
      if (!target) {
        if (!decisions.has(saved.frameId)) issues.push({ ...issue('SUCCESSFUL_IMAGE_REMOVED', '已成功生成的图片框被移除或不再有效；请恢复原图，或先记录明确的弃用原因。', frame), templateId: saved.templateId });
        else if ((('sourceImages' in scan && scan.sourceImages) || []).some(({ node }) => !intactImages.has(node) && (attr(node, 'src') === saved.src || (attr(node, 'srcset') || '').split(',').some(candidate => candidate.trim().split(/\s+/, 1)[0] === saved.src))))
          issues.push({ ...issue('DISCARDED_IMAGE_STILL_REFERENCED', '已记录弃用的原图仍在其他位置使用；请保留原图框，或完整移除该图片引用。', frame), templateId: saved.templateId });
        continue;
      }
      if (!target.image || attr(target.image, 'src') !== saved.src || attr(target.image, 'width') !== String(saved.width) || attr(target.image, 'height') !== String(saved.height))
        issues.push(issue('SUCCESSFUL_IMAGE_CHANGED', '已成功生成的图片或真实尺寸被改变，请保留已绑定素材。', frame, target.template));
    }
    return issues;
  }
  catch { return [issue('INVALID_LAYOUT', '无法安全检查图片布局。')]; }
}

/** Report applied frame omissions only. A recorded intention with the original
 * image still present is not an omission. Invalid/unfinished designs are not
 * reported as completed fallbacks. */
export function preparedImageOmissions(manifest: unknown, plan: ImageFramePlan, retention: PreparedImageRetention, dispositions?: PreparedImageDispositions): PreparedImageOmission[] {
  if (!dispositions?.images.length) return [];
  try {
    if (validatePreparedImageCompletion(manifest, plan, retention, dispositions).length) return [];
    const present = new Set(locate(manifest, plan, 'completion').found.map(frame => frame.frame.id));
    return dispositions.images.filter(record => !present.has(record.frameId)).map(({ frameId, templateId, pageKeys, reasonCode, reason }) => ({ frameId, templateId, pageKeys: [...pageKeys], reasonCode, reason }));
  } catch { return []; }
}
