import { AppError } from './errors';
const encoder = new TextEncoder();
export function base64url(bytes: Uint8Array): string {
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function unbase64url(value: string): Uint8Array<ArrayBuffer> {
  return Uint8Array.from(atob(value.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
}
export function randomToken(bytes = 32): string { return base64url(crypto.getRandomValues(new Uint8Array(bytes))); }
export function id(prefix: string): string { return `${prefix}_${crypto.randomUUID().replaceAll('-', '')}`; }
export async function sha256(value: string | Uint8Array): Promise<string> {
  return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', typeof value === 'string' ? encoder.encode(value) : new Uint8Array(value)))).map(v => v.toString(16).padStart(2, '0')).join('');
}
export function constantTimeEqual(a: string, b: string): boolean {
  let difference = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) difference |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return difference === 0;
}
export async function hashPassword(password: string, salt = randomToken(16)): Promise<string> {
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const result = await crypto.subtle.deriveBits({name:'PBKDF2', hash:'SHA-256', salt:encoder.encode(salt), iterations:100000}, key, 256);
  return `pbkdf2-sha256$100000$${salt}$${base64url(new Uint8Array(result))}`;
}
export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 4 || parts[0] !== 'pbkdf2-sha256' || parts[1] !== '100000') return false;
  return constantTimeEqual(await hashPassword(password, parts[2]), stored);
}
async function encryptionKey(secret: string): Promise<CryptoKey> {
  let bytes: Uint8Array<ArrayBuffer>;
  try { bytes = unbase64url(secret); } catch { throw new AppError('SERVER_NOT_CONFIGURED', '安全配置尚未完成', 503); }
  if(bytes.length !== 32) throw new AppError('SERVER_NOT_CONFIGURED', '安全配置尚未完成', 503);
  return crypto.subtle.importKey('raw', bytes, 'AES-GCM', false, ['encrypt','decrypt']);
}
export async function encryptSecret(value: string, secret: string, context: string): Promise<string> {
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({name:'AES-GCM',iv:nonce,additionalData:encoder.encode(context)},await encryptionKey(secret),encoder.encode(value));
  return `v1.${base64url(nonce)}.${base64url(new Uint8Array(ciphertext))}`;
}
export async function decryptSecret(value: string, secret: string, context: string): Promise<string> {
  const [version,nonce,body] = value.split('.');
  if(version!=='v1'||!nonce||!body) throw new AppError('SECRET_INVALID','密钥配置无法读取',503);
  try {
    const plain = await crypto.subtle.decrypt({name:'AES-GCM',iv:unbase64url(nonce),additionalData:encoder.encode(context)},await encryptionKey(secret),unbase64url(body));
    return new TextDecoder().decode(plain);
  } catch { throw new AppError('SECRET_INVALID','密钥配置无法读取',503); }
}
