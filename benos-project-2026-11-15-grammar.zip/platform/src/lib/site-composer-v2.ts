import { V2_INQUIRY_FORM_REF, v2InquiryFields } from '../design-system/v2/render';
import { V2_DIRECTIONS } from '../design-system/v2/styles';
import { KIT_PATTERN_IDS } from '../design-system/v2/kit';
import { parseFragment, serialize, type DefaultTreeAdapterMap } from 'parse5';
import { z } from 'zod';
import { v2PageSchema, v2SectionSchema, type V2Preset } from '../design-system/v2/contracts';
import { findV2Pattern } from '../design-system/v2/registry';
import { compileV2Page, type V2MediaFrame as PatternFrame, type V2RenderIssue as PatternIssue, type V2OwnedAsset as PatternOwnedAsset, type V2RenderedSection } from '../design-system/v2/render';
import type { V2Notice } from '../design-system/v2/provenance';
type PatternReceipt = V2RenderedSection['receipt'];
import { v2ApprovalKey, type V2TrustedReview as PatternApproval, type V2ApprovalKey } from '../design-system/v2/registry';
import { sha256 } from './crypto';

export const SITE_COMPOSITION_V2_VERSION = 'site-compose-v2' as const;
export const siteCompositionV2Schema = z.object({
  version: z.literal(SITE_COMPOSITION_V2_VERSION),
  pages: z.array(z.object({ pageKey: z.string().min(1).max(100), templateId: z.number().int().positive(), composition: v2PageSchema }).strict()).min(1).max(20),
  footer: z.object({ templateId: z.number().int().positive(), section: v2SectionSchema }).strict().nullable(),
  /** Site-wide design language and palette intent, decided by the model from the brand and industry. */
  art: z.object({ direction: z.enum(V2_DIRECTIONS), mode: z.enum(['light', 'dark']), accent: z.string().regex(/^#[a-fA-F0-9]{6}$/), neutral: z.enum(['pure', 'warm', 'cool', 'stone']), accent2: z.string().regex(/^#[a-fA-F0-9]{6}$/).optional() }).strict().optional(),
}).strict();
export type SiteCompositionV2Input = z.input<typeof siteCompositionV2Schema>;
const inputSchema = z.toJSONSchema(siteCompositionV2Schema, { io: 'input' });
function strictWireSchema(value: any): any {
  if (Array.isArray(value)) return value.map(strictWireSchema);
  if (!value || typeof value !== 'object') return value;
  const result: any = Object.fromEntries(Object.entries(value).filter(([key]) => !['$schema', 'default'].includes(key)).map(([key, child]) => [key, strictWireSchema(child)]));
  if (result.type === 'object' && result.properties) {
    const required = new Set(value.required || []);
    for (const key of Object.keys(result.properties)) if (!required.has(key)) result.properties[key] = { anyOf: [result.properties[key], { type: 'null' }] };
    result.required = Object.keys(result.properties); result.additionalProperties = false;
  }
  return result;
}
/** Inputs that only the template-derived kit reads (a card's link text, a figure caption, the second
 * accent, the stone neutrals, the kit pattern ids). The compiler accepts them, but generation plans
 * generic sections only (see design-system/v2/generation.ts), so the model is not offered them yet:
 * a strict provider would otherwise have to fill every one of them on every item. */
const KIT_ONLY_PROPERTIES = ['linkLabel', 'caption', 'accent2'];
const KIT_ONLY_VALUES: readonly string[] = [...KIT_PATTERN_IDS, 'stone'];
function withoutKitInputs(value: any): any {
  if (Array.isArray(value)) return value.map(withoutKitInputs);
  if (!value || typeof value !== 'object') return value;
  const result: any = Object.fromEntries(Object.entries(value).map(([key, child]) => [key, withoutKitInputs(child)]));
  if (result.type === 'object' && result.properties) {
    for (const key of KIT_ONLY_PROPERTIES) delete result.properties[key];
    if (Array.isArray(result.required)) result.required = result.required.filter((key: string) => !KIT_ONLY_PROPERTIES.includes(key));
  }
  if (Array.isArray(result.enum)) result.enum = result.enum.filter((entry: unknown) => typeof entry !== 'string' || !KIT_ONLY_VALUES.includes(entry));
  return result;
}
function productionWireSchema() {
  const wire = withoutKitInputs(strictWireSchema(inputSchema));
  // Shared-footer navigation is never valid inside a production page section.
  // Keep that unused branch shallow for strict providers, including conservative
  // object-plus-array nesting counts. The independent footer retains real links.
  wire.properties.pages.items.properties.composition.properties.sections.items.properties.content.properties.navigation = {
    anyOf: [{ type: 'array', items: { type: 'null' }, maxItems: 0 }, { type: 'null' }],
  };
  return wire;
}
export const siteCompositionV2JsonSchema = productionWireSchema();
export function parseSiteCompositionV2(raw: unknown): z.output<typeof siteCompositionV2Schema> {
  function normalize(value: any, schema: any): any {
    if (Array.isArray(value)) return value.map(child => normalize(child, schema?.items));
    if (!value || typeof value !== 'object') return value;
    const object = schema?.type === 'object' ? schema : schema?.anyOf?.find((candidate: any) => candidate.type === 'object');
    return Object.fromEntries(Object.entries(value).filter(([key, child]) => child !== null || !object?.properties?.[key] || object.required?.includes(key)).map(([key, child]) => [key, normalize(child, object?.properties?.[key])]));
  }
  return siteCompositionV2Schema.parse(normalize(raw, inputSchema));
}


type Node = DefaultTreeAdapterMap['node'];
type Element = DefaultTreeAdapterMap['element'];
type Template = { id: number; type: string; document: { html: string; css?: string; [key: string]: unknown }; [key: string]: unknown };
export type SiteCompositionManifest = { site: { pages: Array<{ key: string; template_id: number; [key: string]: unknown }>; header_template_id?: number; footer_template_id?: number; [key: string]: unknown }; templates: Template[]; assets?: Array<{ path: string; sha256?: string; [key: string]: unknown }>; [key: string]: unknown };
export type SiteCompositionV2Context = { approvedSnapshot: readonly PatternApproval[]; ownedAssets?: readonly PatternOwnedAsset[]; verifiedFactRefs?: readonly string[]; preset?: V2Preset };
export type SitePatternFrame = PatternFrame & { pageKey: string; templateId: number };
export type SitePatternReceipt = PatternReceipt & { pageKey?: string; templateId: number; location: 'page' | 'footer' };
export type SiteCompositionV2Snapshot = {
  version: typeof SITE_COMPOSITION_V2_VERSION; phase: 'compiled' | 'frozen';
  templates: Array<{ templateId: number; pageKey?: string; location: 'page' | 'footer'; html: string; css: string; sectionIds: string[] }>;
  frames: SitePatternFrame[]; ownedFrames: SitePatternFrame[]; receipts: SitePatternReceipt[];
  removedFrameIds: string[]; themeJson: string; ownedAssets: Array<{ path: string; sha256?: string }>;
  preset: V2Preset; approvals: V2ApprovalKey[]; notices: V2Notice[];
};
export type SiteCompositionV2Issue = { code: string; message: string; templateId?: number; frameId?: string };
const fail = (code: string): never => { throw new Error(code); };
const attr = (node: Element, name: string) => node.attrs.find(a => a.name === name)?.value;
const classes = (node: Element) => (attr(node, 'class') || '').split(/\s+/).filter(Boolean);
const hasClass = (node: Element, name: string) => classes(node).includes(name);
function setAttr(node: Element, name: string, value: string) { const existing = node.attrs.find(a => a.name === name); if (existing) existing.value = value; else node.attrs.push({ name, value }); }
function nodes(html: string) {
  if (html.length > 600_000) fail('BNX_SITE_COMPOSITION_TOO_LARGE');
  const root = parseFragment(html), elements: Element[] = [], stack: Array<{ node: Node; depth: number }> = [{ node: root, depth: 0 }];
  let count = 0;
  while (stack.length) {
    const { node, depth } = stack.pop()!;
    if (++count > 30_000 || depth > 128) fail('BNX_SITE_COMPOSITION_TOO_COMPLEX');
    if ('tagName' in node) { elements.push(node); if (node.tagName === 'template' && 'content' in node) stack.push({ node: node.content as Node, depth: depth + 1 }); }
    if ('childNodes' in node) for (let i = node.childNodes.length - 1; i >= 0; i--) stack.push({ node: node.childNodes[i], depth: depth + 1 });
  }
  return { root, elements };
}
function manifestShape(manifest: SiteCompositionManifest) {
  if (!manifest?.site || !Array.isArray(manifest.site.pages) || !manifest.site.pages.length || manifest.site.pages.length > 100
    || !Array.isArray(manifest.templates) || manifest.templates.length > 200) fail('BNX_SITE_COMPOSITION_MANIFEST_INVALID');
  const templates = new Map<number, Template>(), keys = new Set<string>(), pageTemplates = new Set<number>();
  for (const template of manifest.templates) {
    if (!Number.isSafeInteger(template.id) || template.id <= 0 || templates.has(template.id) || typeof template.document?.html !== 'string') fail('BNX_SITE_COMPOSITION_TEMPLATE_INVALID');
    templates.set(template.id, template);
  }
  for (const page of manifest.site.pages) {
    if (!page.key || keys.has(page.key) || pageTemplates.has(page.template_id) || templates.get(page.template_id)?.type !== 'page') fail('BNX_SITE_COMPOSITION_PAGE_INVALID');
    keys.add(page.key); pageTemplates.add(page.template_id);
  }
  for (const [id, type] of [[manifest.site.header_template_id, 'header'], [manifest.site.footer_template_id, 'footer']] as const)
    if (id !== undefined && (templates.get(id)?.type !== type || pageTemplates.has(id))) fail('BNX_SITE_COMPOSITION_SHARED_TEMPLATE_INVALID');
  return templates;
}
function assertGlobalIds(manifest: SiteCompositionManifest) {
  const ids = new Set<string>(); let size = 0;
  for (const template of manifest.templates) {
    if ((size += template.document.html.length) > 600_000) fail('BNX_SITE_COMPOSITION_TOO_LARGE');
    for (const element of nodes(template.document.html).elements) {
      const id = attr(element, 'id'); if (id) { if (ids.has(id)) fail('BNX_SITE_COMPOSITION_DUPLICATE_ID'); ids.add(id); }
    }
  }
}
function hasPatternMarkup(template: Template) {
  return nodes(template.document.html).elements.some(node => classes(node).some(c => c.startsWith('bnx-')) || node.attrs.some(a => a.name.startsWith('data-bnx')) || attr(node, 'id')?.startsWith('bnx-owned-'))
    || /\.bnx-[a-z]/i.test(template.document.css || '');
}
/** Only the production wrapper performs these integration changes. Gallery
 * renderer bytes and their approval hashes are not rewritten or re-approved. */
function productionHtml(html: string, frames: PatternFrame[]) {
  const parsed = nodes(html), owned = new Map(frames.filter(f => f.source === 'owned').map(f => [f.frameId, 'bnx-owned-' + f.id]));
  for (const node of parsed.elements) {
    const replacement = owned.get(attr(node, 'id') || ''); if (replacement) setAttr(node, 'id', replacement);
    const additions = hasClass(node, 'bnx-hero-cover') && !hasClass(node, 'bnx-cover-no-media') ? ['bnf-hero-cover']
      : hasClass(node, 'bnx-cover-content') ? ['bnf-container', 'bnf-hero-cover-content']
        : hasClass(node, 'bnx-cover-panel') ? ['bnf-hero-cover-panel'] : [];
    if (additions.length) setAttr(node, 'class', [...new Set([...classes(node), ...additions])].join(' '));
  }
  return serialize(parsed.root);
}
/** Notices remain inside the distributed, supported manifest CSS field. The
 * CMS may strip comments from rendered CSS; the source package retains them. */
export function siteCompositionV2NoticeCss(notices: readonly V2Notice[]): string {
  const unique = [...new Map(notices.map(notice => [notice.sourceId + '/' + notice.path + '/' + notice.sha256, notice])).values()];
  return unique.map(notice => {
    const value = `${notice.sourceId}\nUpstream: ${notice.url}\nSource notice SHA-256: ${notice.sha256}\nBenos native HTML/CSS adaptation; see the upstream notice below.\n\n${notice.text}`;
    if (!/^[a-f0-9]{64}$/.test(notice.sha256) || /\*\/|<\/?style|[\u0000]/i.test(value) || value.length > 60000) fail('BNX_SITE_COMPOSITION_NOTICE_INVALID');
    return `/*! BENOS THIRD-PARTY SOURCE NOTICE\n${value}\n*/`;
  }).join('\n');
}

/** A later manual or AI edit may replace CSS, but may not silently remove the
 * licenses of previously distributed source. Only a server-owned base is an
 * authority here. This does not restore an old layout or grant any approval. */
export async function preserveSiteCompositionV2Notices<T extends SiteCompositionManifest>(base: SiteCompositionManifest | null | undefined, next: T): Promise<{ manifest: T; restoredNoticeHashes: string[] }> {
  if (!base) return { manifest: next, restoredNoticeHashes: [] };
  const cssValues = (manifest: SiteCompositionManifest) => [...(manifest.templates || []).map(template => String(template.document?.css || '')), String((manifest.site?.theme as any)?.global_css || '')];
  const baseCss = cssValues(base);
  if (!baseCss.some(css => css.includes('/*! BENOS THIRD-PARTY SOURCE NOTICE\n'))) return { manifest: next, restoredNoticeHashes: [] };
  if (baseCss.reduce((size, css) => size + css.length, 0) > 10_000_000) fail('BNX_SITE_COMPOSITION_NOTICE_TOO_LARGE');
  const blocks = new Map<string, string>(); let visited = 0;
  for (const css of baseCss) for (const match of css.matchAll(/\/\*! BENOS THIRD-PARTY SOURCE NOTICE\n([\s\S]*?)\n\*\//g)) {
    if (++visited > 128 || blocks.size >= 64 || match[0].length > 65000) fail('BNX_SITE_COMPOSITION_NOTICE_TOO_LARGE');
    const parsed = /^([a-z][a-z0-9-]{0,63})\nUpstream: (https:\/\/[^\s<>]+)\nSource notice SHA-256: ([a-f0-9]{64})\nBenos native HTML\/CSS adaptation; see the upstream notice below\.\n\n([\s\S]*)$/.exec(match[1]);
    if (!parsed) return fail('BNX_SITE_COMPOSITION_NOTICE_INVALID');
    if (/<\/?style|\u0000/i.test(match[0]) || await sha256(parsed[4]) !== parsed[3]) fail('BNX_SITE_COMPOSITION_NOTICE_INVALID');
    blocks.set(parsed[1] + '/' + parsed[3], match[0]);
  }
  if (baseCss.reduce((count, css) => count + css.split('/*! BENOS THIRD-PARTY SOURCE NOTICE\n').length - 1, 0) !== visited) fail('BNX_SITE_COMPOSITION_NOTICE_INVALID');
  const currentCss = cssValues(next), missing = [...blocks].filter(([, block]) => !currentCss.some(css => css.includes(block)));
  if (!missing.length) return { manifest: next, restoredNoticeHashes: [] };
  const fallback = next.templates.find(template => template.id === next.site.footer_template_id && template.type === 'footer')
    ?? next.templates.find(template => template.type === 'page' && next.site.pages.some(page => page.template_id === template.id));
  const additions = new Map<number, string[]>();
  for (const [, block] of missing) {
    const original = base.templates.find(template => template.document.css?.includes(block));
    const target = next.templates.find(template => original && template.id === original.id && template.type === original.type) ?? fallback;
    if (!target) return fail('BNX_SITE_COMPOSITION_NOTICE_TARGET_MISSING');
    additions.set(target.id, [...(additions.get(target.id) || []), block]);
  }
  const manifest = { ...next, templates: next.templates.map(template => !additions.has(template.id) ? template : {
    ...template, document: { ...template.document, css: (template.document.css || '') + '\n' + additions.get(template.id)!.join('\n') },
  }) } as T;
  return { manifest, restoredNoticeHashes: missing.map(([key]) => key.slice(key.indexOf('/') + 1)) };
}
const productionBridgeCss = '\n.bnx-hero-cover{--bnf-hero-cover-height:min(88vh,760px)}.bnx-fallback-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:28px}.bnx-fallback-list>.bnx-figure{min-width:0}.bnx-fallback-list .bnx-caption{margin-top:0}@media(max-width:640px){.bnx-hero-cover{--bnf-hero-cover-height:56vh}.bnx-fallback-list{grid-template-columns:1fr}}';
/** Caller supplies a server-owned approval snapshot and verified project media;
 * neither the model input nor this pure compiler can grant approvals. */
export async function compileSiteCompositionV2<T extends SiteCompositionManifest>(raw: unknown, baseManifest: T, context: SiteCompositionV2Context) {
  const input = parseSiteCompositionV2(raw), baseTemplates = manifestShape(baseManifest);
  if (/\.bnx-[a-z]|\[\s*data-bnx/i.test(String((baseManifest.site.theme as any)?.global_css || ''))) fail('BNX_SITE_COMPOSITION_GLOBAL_STYLE_OVERRIDE');
  const approved = context.approvedSnapshot || [];
  if (!approved.length) fail('BNX_SITE_COMPOSITION_NO_APPROVED_PATTERNS');
  const preset = context.preset ?? input.pages[0].composition.preset;
  if (input.pages.some(page => page.composition.preset !== preset) || input.footer && input.footer.section.preset !== preset) fail('BNX_SITE_COMPOSITION_PRESET_CHANGED');
  const declared = new Set<number>(), pageKeys = new Set<string>(), sectionIds = new Set<string>();
  const targets: Array<{ templateId: number; pageKey?: string; location: 'page' | 'footer'; composition: typeof input.pages[number]['composition'] }> = input.pages.map(page => {
    if (pageKeys.has(page.pageKey) || declared.has(page.templateId)) fail('BNX_SITE_COMPOSITION_DUPLICATE_PAGE');
    if (!baseManifest.site.pages.some(p => p.key === page.pageKey && p.template_id === page.templateId) || baseTemplates.get(page.templateId)?.type !== 'page') fail('BNX_SITE_COMPOSITION_PAGE_MISMATCH');
    pageKeys.add(page.pageKey); declared.add(page.templateId);
    if (page.composition.sections.some(section => findV2Pattern(section.patternId, section.variantId).family.role === 'footer')) fail('BNX_SITE_COMPOSITION_FOOTER_IN_PAGE');
    return { templateId: page.templateId, pageKey: page.pageKey, location: 'page' as 'page' | 'footer', composition: page.composition };
  });
  if (input.footer) {
    const footer = input.footer;
    if (footer.templateId !== baseManifest.site.footer_template_id || baseTemplates.get(footer.templateId)?.type !== 'footer'
      || findV2Pattern(footer.section.patternId, footer.section.variantId).family.role !== 'footer') fail('BNX_SITE_COMPOSITION_FOOTER_MISMATCH');
    declared.add(footer.templateId);
    targets.push({ templateId: footer.templateId, location: 'footer', composition: { version: 'bnx-compose-1', preset: footer.section.preset, sections: [footer.section] } });
  }
  for (const target of targets) for (const section of target.composition.sections) {
    if (sectionIds.has(section.id)) fail('BNX_SITE_COMPOSITION_DUPLICATE_SECTION'); sectionIds.add(section.id);
  }
  // Preserve existing media records; an ownership record alone is insufficient
  // if that asset is absent from this manifest or its checksum disagrees.
  const ownedAssets = (context.ownedAssets || []).filter(asset => baseManifest.assets?.some(a => a.path === asset.path && (!asset.sha256 || a.sha256 === asset.sha256)));
  if (new Set(ownedAssets.map(asset => asset.path)).size !== ownedAssets.length) fail('BNX_SITE_COMPOSITION_DUPLICATE_ASSET');
  const manifest = structuredClone(baseManifest), frames: SitePatternFrame[] = [], ownedFrames: SitePatternFrame[] = [], receipts: SitePatternReceipt[] = [], issues: PatternIssue[] = [];
  const snapshot: SiteCompositionV2Snapshot = { version: SITE_COMPOSITION_V2_VERSION, phase: 'compiled', templates: [], frames, ownedFrames, receipts, removedFrameIds: [], themeJson: JSON.stringify(baseManifest.site.theme ?? null), ownedAssets: [], preset, approvals: [], notices: [] };
  for (const target of targets) {
    const rendered = await compileV2Page(target.composition, { mode: 'production', approvedSnapshot: approved, ownedAssets, verifiedFactRefs: context.verifiedFactRefs, ...(input.art ? { art: input.art, artCss: target.location === 'footer' || !input.footer } : {}) });
    if (!rendered.html.trim()) fail('BNX_SITE_COMPOSITION_EMPTY_TEMPLATE');
    const template = manifest.templates.find(t => t.id === target.templateId)!;
    template.document = { ...template.document, html: productionHtml(rendered.html, rendered.frames), css: rendered.css + productionBridgeCss };
    snapshot.approvals.push(...rendered.artifacts.map(v2ApprovalKey)); snapshot.notices.push(...rendered.notices);
    for (const frame of rendered.frames) {
      const value = { ...frame, templateId: target.templateId, pageKey: target.pageKey || '' };
      if (frame.source === 'owned') ownedFrames.push({ ...value, frameId: 'bnx-owned-' + frame.id }); else frames.push(value);
    }
    receipts.push(...rendered.receipts.map(receipt => ({ ...receipt, templateId: target.templateId, ...(target.pageKey ? { pageKey: target.pageKey } : {}), location: target.location })));
    issues.push(...rendered.issues);
    snapshot.templates.push({ templateId: target.templateId, ...(target.pageKey ? { pageKey: target.pageKey } : {}), location: target.location, html: template.document.html, css: template.document.css || '', sectionIds: rendered.receipts.filter(r => nodes(template.document.html).elements.some(n => attr(n, 'id') === r.sectionId)).map(r => r.sectionId) });
  }
  // The enquiry form is a CMS component: the package must declare it and carry a deployable definition.
  const contactForm = targets.flatMap(target => target.composition.sections).find(section => section.patternId === 'contact' && section.variantId === 'form');
  if (contactForm) {
    const chinese = /[\p{Script=Han}]/u.test(contactForm.content.title), site = manifest.site as any, pack = manifest as any;
    pack.forms = [...(Array.isArray(pack.forms) ? pack.forms : []).filter((form: any) => form?.ref !== V2_INQUIRY_FORM_REF), { ref: V2_INQUIRY_FORM_REF }];
    site.forms = [...(Array.isArray(site.forms) ? site.forms : []).filter((form: any) => form?.ref !== V2_INQUIRY_FORM_REF), { ref: V2_INQUIRY_FORM_REF, name: chinese ? '网站询盘' : 'Website enquiry',
      definition: { schema_version: 1, fields: v2InquiryFields(chinese).map(([id, type, label]) => ({ id, type, label, required: id !== 'phone' })), settings: { auto_reply: false, webhook_secret: '' } } }];
  }
  if (frames.length > 12) fail('BNX_SITE_COMPOSITION_FRAME_LIMIT');
  snapshot.ownedAssets = [...new Set(ownedFrames.map(frame => frame.assetPath!))].map(path => {
    const record = baseManifest.assets!.find(asset => asset.path === path)!;
    return { path, ...(record.sha256 ? { sha256: record.sha256 } : {}) };
  });
  if (new Set([...frames, ...ownedFrames].map(frame => frame.id)).size !== frames.length + ownedFrames.length) fail('BNX_SITE_COMPOSITION_DUPLICATE_FRAME');
  assertGlobalIds(manifest);
  // No previously authored content may impersonate this approval receipt.
  if (manifest.templates.some(template => !declared.has(template.id) && hasPatternMarkup(template))) fail('BNX_SITE_COMPOSITION_UNRECEIPTED_MARKUP');
  snapshot.approvals = [...new Map(snapshot.approvals.map(value => [value.artifactHash, value])).values()];
  snapshot.notices = [...new Map(snapshot.notices.map(value => [value.sourceId + '/' + value.path + '/' + value.sha256, value])).values()];
  // A site package distributes one complete copy of each used source notice.
  // Prefer the compiled shared footer, without touching an undeclared template.
  const noticeTarget = snapshot.templates.find(value => value.location === 'footer') ?? snapshot.templates[0];
  const noticeTemplate = manifest.templates.find(value => value.id === noticeTarget.templateId)!;
  noticeTemplate.document.css = (noticeTemplate.document.css || '') + '\n' + siteCompositionV2NoticeCss(snapshot.notices);
  noticeTarget.css = noticeTemplate.document.css;
  return { manifest, frames, ownedFrames, receipts, issues, notices: snapshot.notices, snapshot: structuredClone(snapshot) };
}

function shapeIssues(manifest: SiteCompositionManifest, snapshot: SiteCompositionV2Snapshot): SiteCompositionV2Issue[] {
  const issues: SiteCompositionV2Issue[] = [];
  manifestShape(manifest); assertGlobalIds(manifest);
  if (snapshot.version !== SITE_COMPOSITION_V2_VERSION || !snapshot.templates.length || snapshot.templates.length > 21) fail('BNX_SITE_COMPOSITION_SNAPSHOT_INVALID');
  const ids = new Set(snapshot.templates.map(t => t.templateId));
  if (ids.size !== snapshot.templates.length) fail('BNX_SITE_COMPOSITION_SNAPSHOT_INVALID');
  for (const asset of snapshot.ownedAssets) if (!manifest.assets?.some(record => record.path === asset.path && (!asset.sha256 || record.sha256 === asset.sha256))) issues.push({ code: 'BNX_SITE_COMPOSITION_OWNED_ASSET_CHANGED', message: '已核验的现有图片清单被移除或替换。' });
  for (const expected of snapshot.templates) {
    const template = manifest.templates.find(t => t.id === expected.templateId);
    if (!template || (expected.location === 'page' ? !manifest.site.pages.some(p => p.key === expected.pageKey && p.template_id === expected.templateId) : manifest.site.footer_template_id !== expected.templateId)) {
      issues.push({ code: 'BNX_SITE_COMPOSITION_TARGET_CHANGED', message: '已编译页面或公共页脚的映射已改变。', templateId: expected.templateId }); continue;
    }
    const elements = nodes(template.document.html).elements;
    for (const id of expected.sectionIds) if (!elements.some(n => attr(n, 'id') === id && hasClass(n, 'bnx-section'))) issues.push({ code: 'BNX_SITE_COMPOSITION_SECTION_MISSING', message: '已编译区块缺失或被移至其他模板。', templateId: expected.templateId });
    for (const frame of [...snapshot.frames, ...snapshot.ownedFrames].filter(f => f.templateId === expected.templateId && !snapshot.removedFrameIds.includes(f.id))) {
      const element = elements.find(n => attr(n, 'id') === frame.frameId);
      let section: Element | undefined = element;
      while (section && attr(section, 'id') !== frame.sectionId) section = section.parentNode && 'tagName' in section.parentNode ? section.parentNode : undefined;
      if (!element || !section) issues.push({ code: 'BNX_SITE_COMPOSITION_FRAME_CHANGED', message: '图片框不再属于原编译区块。', templateId: expected.templateId, frameId: frame.id });
    }
  }
  if (manifest.templates.some(template => !ids.has(template.id) && hasPatternMarkup(template))) issues.push({ code: 'BNX_SITE_COMPOSITION_UNRECEIPTED_MARKUP', message: '存在未通过审批快照编译的模式标记。' });
  return issues;
}
/** Call ONLY with the trusted result of server materialization and image
 * prepare/bind, never with unchecked model-authored HTML. The old catalog is
 * not recompiled. Once frozen, re-freezing cannot bless an altered template. */
export function freezeSiteCompositionV2<T extends SiteCompositionManifest>(manifest: T, snapshot: SiteCompositionV2Snapshot): SiteCompositionV2Snapshot {
  const issues = snapshot.phase === 'frozen' ? validateSiteCompositionV2(manifest, snapshot) : shapeIssues(manifest, snapshot);
  if (issues.length) fail(issues[0].code);
  return { ...structuredClone(snapshot), phase: 'frozen', themeJson: JSON.stringify(manifest.site.theme ?? null), templates: snapshot.templates.map(expected => {
    const template = manifest.templates.find(t => t.id === expected.templateId)!;
    return { ...expected, html: template.document.html, css: template.document.css || '' };
  }) };
}
/** Exact authored bytes are retained after the server transformations. This
 * intentionally does not erase all style/class attributes for comparison. */
export function validateSiteCompositionV2(manifest: SiteCompositionManifest, snapshot: SiteCompositionV2Snapshot | null | undefined): SiteCompositionV2Issue[] {
  try {
    if (!snapshot) return manifest.templates.some(hasPatternMarkup) ? [{ code: 'BNX_SITE_COMPOSITION_SNAPSHOT_REQUIRED', message: '模式内容必须来自已审批的生产编译快照。' }] : [];
    const issues = shapeIssues(manifest, snapshot);
    if (JSON.stringify(manifest.site.theme ?? null) !== snapshot.themeJson) issues.push({ code: 'BNX_SITE_COMPOSITION_THEME_CHANGED', message: '编译后冻结的全局主题或字体样式已改变。' });
    for (const expected of snapshot.templates) {
      const template = manifest.templates.find(t => t.id === expected.templateId);
      if (template && (template.document.html !== expected.html || (template.document.css || '') !== expected.css)) issues.push({ code: 'BNX_SITE_COMPOSITION_OUTPUT_CHANGED', message: '已审批编译区块的结构、文案或样式被修改，请保留编译结果。', templateId: expected.templateId });
    }
    return issues;
  } catch { return [{ code: 'BNX_SITE_COMPOSITION_INVALID', message: '无法确认模式输出与可信快照一致。' }]; }
}
const meaningful = (node: Element) => node.childNodes.filter(child => child.nodeName !== '#comment' && !(child.nodeName === '#text' && 'value' in child && !child.value.trim()));
function detach(node: Element) { const parent = node.parentNode; if (parent && 'childNodes' in parent) parent.childNodes.splice(parent.childNodes.indexOf(node), 1); }
/** Explicit server-known failures/discards only. Removes just media subtrees,
 * preserves existing captions/copy, and collapses empty media shells. No model
 * HTML, fresh renderer version, provider request or accounting is involved. */
export function finalizeSiteCompositionV2Images<T extends SiteCompositionManifest>(input: T, snapshot: SiteCompositionV2Snapshot, options: { failedFrameIds: readonly string[]; discardedFrameIds?: readonly string[] }) {
  const failed = new Set(options.failedFrameIds), discarded = new Set(options.discardedFrameIds || []), requested = new Set([...failed, ...discarded]);
  if (failed.size !== options.failedFrameIds.length || discarded.size !== (options.discardedFrameIds || []).length || [...failed].some(id => discarded.has(id))) fail('BNX_SITE_COMPOSITION_IMAGE_DECISION_INVALID');
  const preIssues = snapshot.phase === 'frozen' ? validateSiteCompositionV2(input, snapshot) : shapeIssues(input, snapshot);
  if (preIssues.length) fail(preIssues[0].code);
  for (const id of requested) if (!snapshot.frames.some(f => f.id === id)) fail('BNX_SITE_COMPOSITION_IMAGE_NOT_PLANNED');
  if (discarded.size && snapshot.phase !== 'frozen') fail('BNX_SITE_COMPOSITION_DISCARD_REQUIRES_FROZEN');
  const manifest = structuredClone(input), next = structuredClone(snapshot);
  for (const template of manifest.templates) {
    const frames = snapshot.frames.filter(f => f.templateId === template.id && requested.has(f.id) && !snapshot.removedFrameIds.includes(f.id));
    if (!frames.length) continue;
    const parsed = nodes(template.document.html), affected = new Set<string>();
    for (const frame of frames) {
      const node = parsed.elements.find(n => attr(n, 'id') === frame.frameId)!;
      if (failed.has(frame.id) && meaningful(node).length) fail('BNX_SITE_COMPOSITION_FAILED_FRAME_HAS_CONTENT');
      let removable = node;
      while (removable.parentNode && 'tagName' in removable.parentNode) {
        const parent = removable.parentNode;
        if (!['div', 'figure'].includes(parent.tagName) || meaningful(parent).length !== 1 || attr(parent, 'id') === frame.sectionId) break;
        removable = parent;
      }
      detach(removable); affected.add(frame.sectionId); next.removedFrameIds.push(frame.id);
    }
    for (const id of affected) {
      const section = parsed.elements.find(n => attr(n, 'id') === id)!;
      const descendants = nodes(serialize(section)).elements;
      const hasMedia = descendants.some(n => hasClass(n, 'bnx-media'));
      if (!hasMedia) setAttr(section, 'class', [...classes(section).filter(c => !c.startsWith('bnf-hero-cover')), 'bnx-no-media', ...(hasClass(section, 'bnx-hero-cover') ? ['bnx-cover-no-media'] : [])].filter((x, i, all) => all.indexOf(x) === i).join(' '));
      // Keep captions and facts. A failed mosaic cell becomes a text entry in
      // the existing responsive list instead of an empty picture rectangle.
      for (const node of parsed.elements) {
        let parent: Element | undefined = node;
        while (parent && parent !== section) parent = parent.parentNode && 'tagName' in parent.parentNode ? parent.parentNode : undefined;
        if (parent !== section) continue;
        if (hasClass(node, 'bnx-mosaic-grid') || hasClass(node, 'bnx-media-rail'))
          setAttr(node, 'class', [...classes(node).filter(c => !['bnx-mosaic-grid', 'bnx-mosaic-bento', 'bnx-mosaic-natural', 'bnx-media-rail'].includes(c)), 'bnx-fallback-list'].join(' '));
        if (hasClass(node, 'bnx-stage-layout') || hasClass(node, 'bnx-stage-centered')) {
          if (!hasMedia) setAttr(node, 'class', [...new Set([...classes(node), 'bnx-stage-no-media'])].join(' '));
        }
        if (hasClass(node, 'bnx-story-row') || hasClass(node, 'bnx-story-lead')) {
          if (!nodes(serialize(node)).elements.some(child => hasClass(child, 'bnx-media')))
            setAttr(node, 'class', [...new Set([...classes(node), 'bnx-story-text-only'])].join(' '));
        }
      }
    }
    template.document.html = serialize(parsed.root);
  }
  // This helper alone can create a revised frozen projection, after the exact
  // previous snapshot was checked above. Removed IDs remain an audit trail.
  next.phase = 'compiled';
  return { manifest, snapshot: freezeSiteCompositionV2(manifest, next) };
}
