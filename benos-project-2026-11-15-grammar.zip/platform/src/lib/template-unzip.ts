import { assert,AppError } from './errors';
const MIB=1048576;
export const MAX_IMPORT_ZIP_BYTES=8*MIB;
const crcTable=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n>>>1)^((n&1)?0xedb88320:0);return n>>>0;});
const crc=(bytes:Uint8Array)=>{let n=0xffffffff;for(const b of bytes)n=(n>>>8)^crcTable[(n^b)&255];return (n^0xffffffff)>>>0;};
const nameOk=(name:string)=>name==='manifest.json'||/^assets\/\d{1,2}\.(jpg|jpeg|png|webp|gif|svg|pdf)$/.test(name);
function reject(ok:unknown,message='模板 ZIP 目录或文件记录无效'):asserts ok{assert(ok,'TEMPLATE_ZIP_INVALID',message,422);}
type Entry={name:string;size:number;packed:number;method:number;flags:number;checksum:number;offset:number;start:number;end:number};
/** Strict classic ZIP reader. Declared and streamed output sizes are both bounded;
 * no filesystem extraction, ZIP64, encryption, extra entries, symlinks or aliases. */
export async function readTemplateZip(bytes:Uint8Array){
 reject(bytes.length>=22&&bytes.length<=MAX_IMPORT_ZIP_BYTES,'平台导入 ZIP 最大 8 MiB');const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),u16=(at:number)=>v.getUint16(at,true),u32=(at:number)=>v.getUint32(at,true);
 let end=-1;for(let at=bytes.length-22;at>=Math.max(0,bytes.length-22-65535);at--){if(u32(at)===0x06054b50&&at+22+u16(at+20)===bytes.length){end=at;break;}}
 reject(end>=0);reject(u16(end+4)===0&&u16(end+6)===0&&u16(end+8)===u16(end+10),'不支持分卷 ZIP');const count=u16(end+10),directorySize=u32(end+12),directory=u32(end+16);reject(count>0&&count<=65&&directory+directorySize===end,'ZIP 文件数量或目录边界不符');
 const entries:Entry[]=[],names=new Set<string>();let at=directory,total=0,assetTotal=0;
 for(let n=0;n<count;n++){
  reject(at+46<=end&&u32(at)===0x02014b50);const flags=u16(at+8),method=u16(at+10),checksum=u32(at+16),packed=u32(at+20),size=u32(at+24),nameSize=u16(at+28),extraSize=u16(at+30),commentSize=u16(at+32),external=u32(at+38),offset=u32(at+42),recordEnd=at+46+nameSize+extraSize+commentSize;
  reject(recordEnd<=end&&nameSize>0&&nameSize<=100&&u16(at+34)===0);const nameBytes=bytes.subarray(at+46,at+46+nameSize);reject(nameBytes.every(b=>b>=32&&b<=126),'ZIP 文件名必须使用规范中的 ASCII 路径');const name=new TextDecoder().decode(nameBytes);
  reject(nameOk(name)&&!names.has(name),'ZIP 只能包含一份根目录 manifest.json 与清单中的 assets 文件');names.add(name);
  reject((flags&~0x080e)===0&&(flags&1)===0&&[0,8].includes(method),'ZIP 压缩算法或加密标记不受支持');const mode=(external>>>16)&0xf000;reject((mode===0||mode===0x8000)&&(external&0x10)===0,'不允许目录或符号链接');
  reject(size>0&&size<=(name==='manifest.json'?10:12)*MIB&&packed<=MAX_IMPORT_ZIP_BYTES&&offset<directory,'ZIP 文件大小超过限制');total+=size;if(name!=='manifest.json')assetTotal+=size;reject(total<=16*MIB&&assetTotal<=6*MIB,'平台模板素材总量最多 6 MiB');
  reject(offset+30<=directory&&u32(offset)===0x04034b50&&u16(offset+6)===flags&&u16(offset+8)===method);const localNameSize=u16(offset+26),localExtra=u16(offset+28),start=offset+30+localNameSize+localExtra;reject(start<=directory&&start+packed<=directory&&localNameSize===nameSize);
  reject(new TextDecoder().decode(bytes.subarray(offset+30,offset+30+localNameSize))===name,'ZIP 本地记录与目录文件名不一致');
  let dataEnd=start+packed;if(flags&8){const marker=dataEnd+4<=directory&&u32(dataEnd)===0x08074b50?4:0;reject(dataEnd+marker+12<=directory&&u32(dataEnd+marker)===checksum&&u32(dataEnd+marker+4)===packed&&u32(dataEnd+marker+8)===size,'ZIP 数据描述符不一致');dataEnd+=marker+12;}
  else reject(u32(offset+14)===checksum&&u32(offset+18)===packed&&u32(offset+22)===size,'ZIP 本地记录与目录大小不一致');
  entries.push({name,size,packed,method,flags,checksum,offset,start,end:dataEnd});at=recordEnd;
 }
 reject(at===end&&names.has('manifest.json'));let boundary=0;for(const entry of [...entries].sort((a,b)=>a.offset-b.offset)){reject(entry.offset===boundary,'ZIP 包含重叠记录、前缀或未声明文件');boundary=entry.end;}reject(boundary===directory,'ZIP 数据区包含未声明内容');
 const files:Array<{file:string;bytes:Uint8Array}>=[];let manifest:unknown;
 for(const e of entries){let raw:Uint8Array;const packed=bytes.subarray(e.start,e.start+e.packed);
  if(e.method===0){reject(e.packed===e.size);raw=new Uint8Array(packed);}
  else{try{const stream=new Blob([new Uint8Array(packed)]).stream().pipeThrough(new DecompressionStream('deflate-raw')),reader=stream.getReader();raw=new Uint8Array(e.size);let length=0;while(true){const chunk=await reader.read();if(chunk.done)break;if(length+chunk.value.length>e.size){await reader.cancel();throw new Error('Expanded output exceeds declared size');}raw.set(chunk.value,length);length+=chunk.value.length;}reject(length===e.size,'ZIP 解压大小与声明不符');}catch(error){if(error instanceof AppError)throw error;throw new AppError('TEMPLATE_ZIP_INVALID','ZIP 压缩数据无效或实际解压大小超过限制',422);}}
  reject(crc(raw)===e.checksum,'ZIP 文件 CRC 校验失败');if(e.name==='manifest.json'){try{manifest=JSON.parse(new TextDecoder('utf-8',{fatal:true,ignoreBOM:false}).decode(raw));}catch{throw new AppError('TEMPLATE_ZIP_INVALID','manifest.json 不是有效 UTF-8 JSON',422);}}else files.push({file:e.name,bytes:raw});
 }
 return {manifest,files};
}
