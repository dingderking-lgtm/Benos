import { compileSiteHeader, resolveSiteHeader, siteHeaderSpecSchema, explicitlyRequestsHeaderPattern, EXPERIMENTAL_HEADER_PATTERNS, type ResolvedSiteHeader } from '../contracts/site-header';
import { assert } from './errors';
import { parseFragment } from 'parse5';
import { withoutFoundationCss } from '../contracts/design-foundation';

/** These bytes belong to the server-side workflow snapshot, never to a model's
 * manifest. Replaying a task does not invoke a newer compiler. */
export type CompiledHeaderSnapshot = {
  version: 'bnh-1'; templateId: number; resolved: ResolvedSiteHeader;
  html: string; css: string; receipt: unknown;
};
export function hasCompiledHeaderPolicy(requirements: any): boolean {
  return requirements?.designOrder?.version === 'dq-1' && requirements?.presentationPolicy?.mode === 'orderly';
}
function context(manifest: any, requirements: any, seed: string) {
  const ownAssets = new Set((requirements.availableAssets ?? []).map((entry:any) => entry?.asset?.path));
  const home = manifest.site?.pages?.find((page:any) => page.key === manifest.site?.home);
  const request = String(requirements.request ?? '') + ' ' + String(requirements.style ?? '');
  return {
    seed, menus: manifest.menus ?? [], homeHref: '/',
    language: home?.seo?.language ?? manifest.site?.settings?.site_language ?? 'en',
    heroPresentation: manifest.templates?.find((t:any) => t.id === home?.template_id)?.document?.html?.includes('bnf-hero-cover') ? 'hero-cover' as const : 'standard' as const,
    // A requested two-tier/directory header does not require an experimental
    // body layout. The compiler still checks the specific positive request.
    allowExperimental: requirements.designOrder?.layoutMode === 'experimental' || EXPERIMENTAL_HEADER_PATTERNS.some(pattern => explicitlyRequestsHeaderPattern(pattern, request)),
    request,
    siteKind: requirements.designBrief?.inference?.siteKind ?? 'general',
    styleId: requirements.foundation?.styleId ?? 'modern',
    allowFixedOverlay: requirements.presentationPolicy?.fixedHeaderMenus === true,
    // Never infer a real search/subscription/language capability from a label.
    capabilities: {},
    verifiedLogoPaths: (manifest.assets ?? []).map((asset:any) => asset.path).filter((p:any) => typeof p === 'string' && ownAssets.has(p)),
  };
}
export function freezeSiteHeader(manifest: any, spec: unknown, requirements: any, seed: string): CompiledHeaderSnapshot {
  assert(hasCompiledHeaderPolicy(requirements), 'HEADER_COMPILER_UNAVAILABLE', '旧任务继续使用原页头协议', 409);
  const parsed = siteHeaderSpecSchema.parse(spec), ctx = context(manifest, requirements, seed);
  parsed.actions=parsed.actions.map(action=>({...action,href:action.href.startsWith('#')?'/'+action.href:action.href}));
  for (const action of parsed.actions) assert(headerActionResolves(manifest,action.href,requirements), 'HEADER_ACTION_UNRESOLVED', '页头操作必须指向已存在的页面、唯一章节或用户提供的真实地址');
  // Only the platform-wide switch can grant fixed menus.
  parsed.options.allowFixedOverlay = parsed.options.allowFixedOverlay && ctx.allowFixedOverlay;
  const resolved = resolveSiteHeader(parsed, ctx), compiled = compileSiteHeader(resolved, ctx);
  let templateId = manifest.site?.header_template_id;
  if (!Number.isSafeInteger(templateId) || templateId <= 0) templateId = Math.max(0, ...(manifest.templates ?? []).map((t:any) => Number.isSafeInteger(t.id) ? t.id : 0)) + 1;
  const existing = (manifest.templates ?? []).find((t:any) => t.id === templateId);
  assert(!existing || existing.type === 'header', 'HEADER_TEMPLATE_CONFLICT', '页头模板编号不能指向正文或页脚');
  return {version:'bnh-1', templateId, resolved, html:compiled.html, css:compiled.css, receipt:compiled.receipt};
}
function headerActionResolves(manifest:any,href:string,requirements:any):boolean {
  if (!href.startsWith('/') && !href.startsWith('#')) return (requirements.designOrder?.providedTargets ?? []).includes(href);
  if (href.startsWith('//')) return false;
  let url:URL;try{url=new URL(href,'https://site.invalid/');}catch{return false;}
  const page=url.pathname==='/' ? manifest.site?.pages?.find((p:any)=>p.key===manifest.site.home)
    : manifest.site?.pages?.find((p:any)=>'/'+String(p.slug||p.key).replace(/^\/|\/$/g,'')===url.pathname.replace(/\/$/,''));
  if(!page)return !url.hash&&!!manifest.site?.blog?.enabled&&url.pathname==='/'+(manifest.site.blog.base_path||'insights');
  if(!url.hash)return true;
  let id:string;try{id=decodeURIComponent(url.hash.slice(1));}catch{return false;}
  const ids=[manifest.site.header_template_id,page.template_id,manifest.site.footer_template_id];let count=0;
  for(const template of (manifest.templates??[]).filter((t:any)=>ids.includes(t.id))){const stack:any[]=[parseFragment(template.document?.html||'')];while(stack.length){const node=stack.pop();if(node.attrs?.some((a:any)=>a.name==='id'&&a.value===id))count++;if(node.childNodes)stack.push(...node.childNodes);}}
  return count===1;
}
export function materializeFrozenHeader<T>(input: T, snapshot: CompiledHeaderSnapshot): T {
  assert(snapshot?.version === 'bnh-1' && typeof snapshot.html === 'string' && typeof snapshot.css === 'string', 'HEADER_SNAPSHOT_INVALID', '页头快照无效，不能隐式重建');
  const manifest = input as any;
  assert(manifest?.site && Array.isArray(manifest.templates), 'HEADER_MANIFEST_INVALID', '请先提交完整网站结构');
  const existing = manifest.templates.find((t:any) => t.id === snapshot.templateId);
  assert(!existing || existing.type === 'header', 'HEADER_TEMPLATE_CONFLICT', '页头模板编号不能指向正文或页脚');
  const header = {...(existing ?? {id:snapshot.templateId,name:'Site header',type:'header',conditions:{all:false,pages:[],exclude_pages:[],types:[],categories:[]}}),
    // No stale editor tree/customCss can override the compiler-owned subtree.
    document:{version:1, html:snapshot.html, css:snapshot.css}};
  return {...manifest, site:{...manifest.site,header_template_id:snapshot.templateId,navigation_menu_id:snapshot.resolved.menuId},
    templates:existing ? manifest.templates.map((t:any) => t.id === snapshot.templateId ? header : t) : [...manifest.templates,header]} as T;
}
/** The new header is compiler-owned. Author CSS remains available for page
 * classes, but cannot use cascade overrides to undo the compiled structure. */
export function headerCssIsolationIssues(manifest:any,snapshot:CompiledHeaderSnapshot):{code:string;message:string}[] {
  const issues:{code:string;message:string}[]=[];
  const sheets=[withoutFoundationCss(String(manifest.site?.theme?.global_css??'')),...(manifest.templates??[]).filter((t:any)=>t.id!==snapshot.templateId).flatMap((t:any)=>[String(t.document?.css??''),String(t.document?.customCss??'')])];
  const add=(detail:string)=>{if(!issues.length)issues.push({code:'HEADER_STYLE_OWNERSHIP',message:'页头样式由平台控制；请将自定义 CSS 限定为正文/页脚类，并移除'+detail+'。'})};
  for(const raw of sheets){
    const css=raw.replace(/\/\*[\s\S]*?\*\//g,'');
    if(/!\s*important/i.test(css))add('作者样式中的 !important 覆盖');
    for(const match of css.matchAll(/([^{}]+)\{([^{}]*)\}/g)){
      const selector=match[1].trim(),declarations=match[2];
      if(selector.startsWith('@'))continue;
      if(/\\/.test(selector)||/bnh-|(?:^|[^\w-])header(?:$|[^\w-])/i.test(selector))add('对平台页头选择器的覆盖');
      if(/(?:^|;)\s*--bnh-/i.test(declarations))add('平台页头变量覆盖');
      if(/(?:^|[\s,>+~])(?:html|body|:root|\*)(?:$|[\s,.:#\[>+~])/i.test(selector)
        &&/(?:^|;)\s*(?:all|position|display|visibility|opacity|overflow(?:-[xy])?|height|max-height|min-height|width|min-width|max-width|inset|top|left|right|bottom|transform|filter|perspective|contain|content-visibility|z-index)\s*:/i.test(declarations))add('全局布局或可见性覆盖');
    }
  }
  return issues;
}
