﻿import { Hono } from 'hono';
import { AppError,assert } from './lib/errors';
import { type App,ok } from './lib/http';
import { id } from './lib/crypto';
import { authRoutes } from './modules/auth';
import { projectRoutes } from './modules/projects';
import { commerceRoutes,publicBillingRoutes } from './modules/commerce';
import { adminRoutes } from './modules/admin';
import { integrationRoutes } from './modules/integrations';
import { contentRoutes,publicContentRoutes } from './modules/content';
import { hostingRoutes } from './modules/hosting';
import { paymentWebhookRoutes } from './modules/payments';
import { alipayWebhookRoutes,alipayAdminRoutes } from './modules/alipay';
import { LedgerError } from './modules/ledger';
import { aiRoutes,previewRoutes } from './modules/ai';
import { membershipRoutes } from './modules/memberships';
import { accountSecurityRoutes } from './modules/account-security';
import { maintenance,maintenanceRoutes } from './modules/maintenance';
import { designWorkspaceRoutes } from './modules/design-workspace';
import { designEditorRoutes } from './modules/design-editor-view';
import { manifestEditRoutes } from './modules/manifest-edits';
import { designEditingRoutes } from './modules/design-editing';
import { aiWorkflowRoutes } from './modules/ai-workflow';
import { receivedDesignRoutes } from './modules/received-design';
import { hostingManagementRoutes } from './modules/hosting-management';
import { nativePreviewApiRoutes,nativePreviewPageRoutes } from './modules/native-previews';
import { nativePreviewJobRoutes,nativePreviewAssetRoutes } from './modules/native-preview-jobs';
import { templateImportRoutes } from './modules/template-import';
import { packageUploadRoutes } from './modules/package-uploads';
import { adminOperationsRoutes } from './modules/admin-operations';
import { budgetReviewRoutes } from './modules/budget-reviews';
import { adminSettingsRoutes,platformBrandRoutes } from './modules/admin-settings';
import type { Env } from './env';
import { mediaRoutes } from './modules/media';
import { imagesRoutes } from './modules/images';
import { publishingRoutes } from './modules/publishing';
import { marketingRoutes,marketingSitemap,indexingEnabled } from './modules/marketing';
import { financialRoutes } from './modules/payment-reviews';
import { cmsReleaseRoutes } from './modules/cms-releases';
import { hostingPoolRoutes } from './modules/hosting-pools';
import { notificationRoutes } from './modules/notifications';
import { retentionRoutes } from './modules/hosting-retention';
import { webScriptHashes } from './generated/web-csp';
import { designPatternGalleryRoutes,designPatternAssetRoutes } from './modules/design-pattern-gallery';
import { designSystemV2Routes,designSystemV2AssetRoutes } from './modules/design-system-v2';
import { designGrammarRoutes } from './modules/design-grammar';

export const app=new Hono<App>();
app.use('*',async(c,next)=>{
  c.set('requestId',id('req'));
  if(c.env.RECOVERY_MODE==='true'){
    c.header('Cache-Control','no-store');c.header('Retry-After','300');
    return c.json({ok:false,error:{code:'RECOVERY_MODE',message:'平台正在维护，请稍后重试',requestId:c.get('requestId')}},503);
  }
  if(c.req.path.startsWith('/preview/')){
    c.header('Cache-Control','private, no-store');
    c.header('Referrer-Policy','no-referrer');
    c.header('X-Content-Type-Options','nosniff');
  }
  if(c.req.path.startsWith('/api/')){
    c.header('Cache-Control','no-store');c.header('X-Content-Type-Options','nosniff');
    c.header('X-Frame-Options','DENY');c.header('Referrer-Policy','same-origin');
    assert(c.env.APP_ENV!=='production'||c.env.APP_ORIGIN?.startsWith('https://'),'SERVER_NOT_CONFIGURED','平台域名配置尚未完成',503);
    if(!['GET','HEAD','OPTIONS'].includes(c.req.method)) {
      const paymentCallback=c.req.method==='POST'&&/^\/api\/webhooks\/(?:stripe|alipay)\/cfg_[a-f0-9]{32}$/.test(c.req.path);
      if(!paymentCallback)assert(c.req.header('origin')===c.env.APP_ORIGIN,'ORIGIN_DENIED','请求来源无效，请从平台页面重试',403);
      const length=Number(c.req.header('content-length')||0);
      const cmsReleaseUpload=c.req.method==='POST'&&c.req.path==='/api/admin/cms-releases/upload';
      const templateUpload=c.req.method==='POST'&&/^\/api\/design\/projects\/prj_[a-f0-9]{32}\/template-package$/.test(c.req.path);
      const contentMediaUpload=c.req.method==='POST'&&c.req.path==='/api/admin/content/media';
      const maxBytes=cmsReleaseUpload?48*1024*1024:templateUpload?8*1024*1024:contentMediaUpload||c.req.method==='POST'&&/^\/api\/media\/projects\/prj_[a-f0-9]{32}\/assets$/.test(c.req.path)?12*1024*1024:1024*1024;
      assert(Number.isFinite(length)&&length<=maxBytes,'REQUEST_TOO_LARGE','提交内容过大',413);
      // Large private release uploads authenticate before reading their stream;
      // their route applies the same bounded read without a second full copy.
      if(c.req.raw.body&&!cmsReleaseUpload&&!templateUpload&&!contentMediaUpload){
        const reader=c.req.raw.body.getReader(),chunks:Uint8Array[]=[];let total=0;
        while(true){const part=await reader.read();if(part.done)break;total+=part.value.byteLength;if(total>maxBytes){await reader.cancel();throw new AppError('REQUEST_TOO_LARGE','提交内容过大',413);}chunks.push(part.value);}
        const bytes=new Uint8Array(total);let at=0;for(const part of chunks){bytes.set(part,at);at+=part.length;}
        c.req.raw=new Request(c.req.raw,{body:bytes});
      }
    }
  }
  await next();
  c.header('X-Request-Id',c.get('requestId'));
});
app.get('/api/health',async c=>{await c.env.DB.prepare('SELECT 1').first();return ok(c,{service:'Benos',status:'ready',environment:c.env.APP_ENV});});
app.route('/api',authRoutes);
app.route('/api/projects',projectRoutes);
// The public catalogue must be mounted before commerceRoutes, whose '*' requires a session.
app.route('/api/billing',publicBillingRoutes);
app.route('/api/billing',commerceRoutes);
app.route('/api/admin',adminRoutes);
app.route('/api/admin/operations',adminOperationsRoutes);
app.route('/api/admin/budget-reviews',budgetReviewRoutes);
app.route('/api/admin/settings',adminSettingsRoutes);
app.route('/api/admin/design-patterns',designPatternGalleryRoutes);
app.route('/api/admin/design-system-v2',designSystemV2Routes);
app.route('/api/admin/design-grammar',designGrammarRoutes);
app.route('/api/branding',platformBrandRoutes);
app.route('/api/admin',financialRoutes);
app.route('/api/admin/cms-releases',cmsReleaseRoutes);
app.route('/api/admin/hosting-pools',hostingPoolRoutes);
app.route('/api/notifications',notificationRoutes);
app.route('/api/admin/hosting-retention',retentionRoutes);
app.route('/api/admin/integrations',integrationRoutes);
app.route('/api/admin/payments/alipay',alipayAdminRoutes);
app.route('/api/admin/content',contentRoutes);
app.route('/api/admin/memberships',membershipRoutes);
app.route('/api/admin/maintenance',maintenanceRoutes);
app.route('/api/design',designWorkspaceRoutes);
app.route('/api/design',designEditorRoutes);
app.route('/api/design',manifestEditRoutes);
app.route('/api/design',designEditingRoutes);
app.route('/api/design',nativePreviewApiRoutes);
app.route('/api/design',nativePreviewJobRoutes);
app.route('/api/design',templateImportRoutes);
app.route('/api/design',packageUploadRoutes);
app.route('/api/content',publicContentRoutes);
app.route('/api/hosting',hostingRoutes);
app.route('/api/hosting-management',hostingManagementRoutes);
app.route('/api/webhooks/stripe',paymentWebhookRoutes);
app.route('/api/webhooks/alipay',alipayWebhookRoutes);
app.route('/api/ai',aiRoutes);
app.route('/api/ai',aiWorkflowRoutes);
app.route('/api/ai',receivedDesignRoutes);
app.route('/api/account',accountSecurityRoutes);
app.route('/api/media',mediaRoutes);
app.route('/api/images',imagesRoutes);
app.route('/api/publishing',publishingRoutes);
// Capability-protected image reads must precede session middleware: sandboxed
// native preview frames intentionally use an opaque origin without cookies.
app.route('/preview',nativePreviewAssetRoutes);
app.route('/preview',previewRoutes);
app.route('/preview',nativePreviewPageRoutes);
app.route('/assets/pattern-gallery',designPatternAssetRoutes);
app.route('/assets/design-system-v2',designSystemV2AssetRoutes);
app.route('/',marketingRoutes);
app.get('/robots.txt',c=>c.text(indexingEnabled(c.env)?`User-agent: *\nAllow: /home\nAllow: /blog\nAllow: /pages/\nAllow: /category/\nAllow: /faq\nDisallow: /api/\nDisallow: /preview/\nDisallow: /account/\nDisallow: /app/\nDisallow: /admin/\nSitemap: ${c.env.APP_ORIGIN}/sitemap.xml\n`:'User-agent: *\nDisallow: /\n'));
app.get('/sitemap.xml',async c=>c.body(await marketingSitemap(c.env),200,{'Content-Type':'application/xml'}));
app.all('/api/*',c=>c.json({ok:false,error:{code:'NOT_FOUND',message:'接口不存在',requestId:c.get('requestId')}},404));
// Inline scripts of the Next.js export (appearance bootstrap, RSC payload), hashed at
// build time by scripts/build-web.mjs. Only HTML documents receive them.
const webScriptSources=webScriptHashes.filter(hash=>/^[A-Za-z0-9+/]{43}=$/.test(hash)).map(hash=>` 'sha256-${hash}'`).join('');
app.get('*',async c=>{
  if(!c.env.ASSETS)return c.text('Benos assets are not configured',503);
  let result=await c.env.ASSETS.fetch(c.req.raw);
  if(result.status===404&&!c.req.path.split('/').pop()?.includes('.')){const fallback=new URL('/',c.req.url);result=await c.env.ASSETS.fetch(new Request(fallback,c.req.raw));}
  const response=new Response(result.body,result);
  const html=(response.headers.get('Content-Type')||'').toLowerCase().startsWith('text/html');
  // Staff/customer entry documents stay private to search engines even when marketing indexing is enabled.
  if(html&&/^\/(?:app|admin|account)(?:\/|$|\.(?:html|txt)$)/.test(c.req.path))response.headers.set('X-Robots-Tag','noindex,nofollow');
  // Next.js RSC payloads keep their flight content type (the asset binding would say text/plain).
  if(response.ok&&/(?:^|\/)(?:index|__next\.[^/]+)\.txt$/.test(c.req.path))response.headers.set('Content-Type','text/x-component; charset=utf-8');
  // Content-hashed Next chunks never change; everything else revalidates (ETag) on each use.
  if(response.ok&&c.req.path.startsWith('/_next/static/'))response.headers.set('Cache-Control','public, max-age=31536000, immutable');
  else if(html)response.headers.set('Cache-Control','no-cache');
  else if(response.ok||response.status===304)response.headers.set('Cache-Control',response.headers.get('Cache-Control')||'public, max-age=0, must-revalidate');
  response.headers.set('X-Content-Type-Options','nosniff');
  response.headers.set('Referrer-Policy','same-origin');
  response.headers.set('X-Frame-Options','DENY');
  // Wrangler 4.158.0 injects this fixed live-reload script. Permit its exact
  // hash only on a local development origin; production keeps script-src self.
  const localReload=c.env.APP_ENV==='development'&&['127.0.0.1','localhost','[::1]'].includes(new URL(c.req.url).hostname);
  const reloadScript=localReload?" 'sha256-g5a3SrOYIecCloZ8S7M4xdT1pbYi6e7mjHrmwphRxfE='":'';
  const pageScripts=html?webScriptSources:'';
  response.headers.set('Content-Security-Policy',`default-src 'self'; script-src 'self'${reloadScript}${pageScripts}; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; img-src 'self' data: blob:; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-src 'self' blob:; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'`);
  return response;
});
app.onError((error,c)=>{
  if(error instanceof LedgerError){const messages:Record<string,string>={INSUFFICIENT_CREDIT:'AI 余额不足，请检查可用额度',INSUFFICIENT_PROVIDER_FUNDS:'AI 服务额度暂不可用，请稍后重试',ACCOUNT_RESTRICTED:'该账户暂不能使用 AI',IDEMPOTENCY_CONFLICT:'操作编号已被不同的请求使用',RESERVATION_STATE:'用量记录正在核对，请勿重复提交',COST_EXCEEDS_RESERVATION:'费用核对需要人工处理，相关额度保持冻结'};return c.json({ok:false,error:{code:error.code,message:messages[error.code]||'用量记录暂时无法确认，请稍后查询原操作',requestId:c.get('requestId')}},409);}
  const known=error instanceof AppError;
  if(!known)console.error(JSON.stringify({event:'request_failed',requestId:c.get('requestId'),type:error.name}));
  return c.json({ok:false,error:{code:known?error.code:'INTERNAL_ERROR',message:known?error.message:'服务暂时不可用，请稍后重试',requestId:c.get('requestId')}},(known?error.status:500) as 400);
});
export { maintenance };
export default {fetch:app.fetch,scheduled(_controller:ScheduledController,env:Env,ctx:ExecutionContext){ctx.waitUntil(maintenance(env));}};
