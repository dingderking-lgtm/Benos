export interface Env {
  DB: D1Database;
  ASSETS: Fetcher;
  BUCKET?: R2Bucket;
  APP_ENV: 'development' | 'test' | 'production';
  APP_ORIGIN: string;
  REGISTRATION_ENABLED?: string;
  /** Enable only after the public production domain and policies are verified. */
  INDEXING_ENABLED?: string;
  /** Isolated recovery: reject all traffic before auth, writes or external calls. */
  RECOVERY_MODE?: string;
  /** Service expiry emails require explicit deployment opt-in. */
  NOTIFICATION_EMAIL_ENABLED?: string;
  SESSION_SECRET: string;
  ENCRYPTION_KEY: string;
  BOOTSTRAP_TOKEN?: string;
  /** Set only in the Sites server adapter after dispatch identity verification. */
  VERIFIED_BOOTSTRAP_EMAIL?: string;
}

export type Role = 'owner' | 'admin' | 'support' | 'editor' | 'user';
export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  status: 'active' | 'restricted';
  email_verified_at: string | null;
  created_at: string;
}

export interface AuthContext { user: User; sessionId: string; csrfToken: string; }
