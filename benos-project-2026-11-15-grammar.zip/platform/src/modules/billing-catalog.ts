import { z } from 'zod';
import type { Env } from '../env';
import { assert,AppError } from '../lib/errors';
import { id,sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';

export const BUILTIN_CATALOG_ID='benos-default-2026-11-07';
const planSchema=z.object({priceCents:z.number().int().min(100).max(1_000_000),creditMicros:z.number().int().min(1).max(10_000_000_000),includedSites:z.number().int().min(1).max(1000)}).strict().refine(p=>p.creditMicros<=p.priceCents*10000,'月额度不能超过套餐售价的美元面值');
export const cnyPricingSchema=z.object({goPriceCents:z.number().int().min(1).max(1_000_000),proPriceCents:z.number().int().min(1).max(1_000_000),hostingAnnualPriceCents:z.number().int().min(1).max(1_000_000),minimumTopupCents:z.number().int().min(1).max(1_000_000),topupCreditMicrosPerCnyCent:z.number().int().min(1).max(1_000_000)}).strict();
export const catalogSchema=z.object({go:planSchema,pro:planSchema,hosting:z.object({annualPriceCents:z.number().int().min(100).max(1_000_000)}).strict(),topup:z.object({creditBps:z.literal(6500),minimumCents:z.literal(500)}).strict(),enterprise:z.object({contactEnabled:z.boolean(),description:z.string().trim().min(1).max(500)}).strict(),cnyPricing:cnyPricingSchema.optional()}).strict();
export type Catalog=z.infer<typeof catalogSchema>;
export const DEFAULT_CATALOG:Catalog=Object.freeze({go:{priceCents:2500,creditMicros:16_250_000,includedSites:1},pro:{priceCents:10000,creditMicros:65_000_000,includedSites:2},hosting:{annualPriceCents:3000},topup:{creditBps:6500,minimumCents:500},enterprise:{contactEnabled:true,description:'企业方案按网站数量与服务范围单独约定，请联系平台。'}});
export type CatalogView={id:string;version:number;enabled:boolean;catalog:Catalog;createdAt:string|null;reason:string;createdBy:string|null};
type CatalogRow={id:string;version:number;payload_json:string;payload_hash:string;reason:string;created_by:string;created_at:string};
export async function currentCatalog(db:D1Database):Promise<CatalogView>{const row=await db.prepare('SELECT v.*,a.enabled FROM billing_catalog_active a JOIN billing_catalog_versions v ON v.id=a.version_id WHERE a.singleton=1').first<CatalogRow&{enabled:number}>();return row?{id:row.id,version:row.version,enabled:!!row.enabled,catalog:catalogSchema.parse(JSON.parse(row.payload_json)),createdAt:row.created_at,reason:row.reason,createdBy:row.created_by}:{id:BUILTIN_CATALOG_ID,version:0,enabled:true,catalog:structuredClone(DEFAULT_CATALOG),createdAt:null,reason:'已确认的默认商业规则',createdBy:null};}
export function catalogPlans(catalog:Catalog){return (['go','pro'] as const).map(tier=>({tier,name:tier==='go'?'Go':'Pro',...catalog[tier],billingInterval:'month'}));}
export async function listCatalog(db:D1Database){const current=await currentCatalog(db),rows=await db.prepare('SELECT * FROM billing_catalog_versions ORDER BY version DESC LIMIT 100').all<CatalogRow>();return {current,items:rows.results.map(r=>({id:r.id,version:r.version,catalog:JSON.parse(r.payload_json) as Catalog,reason:r.reason,createdBy:r.created_by,createdAt:r.created_at,active:r.id===current.id})),builtin:{id:BUILTIN_CATALOG_ID,catalog:DEFAULT_CATALOG},limits:{topupCreditBps:6500,minimumTopupCents:500,subscriptionInterval:'month',hostingInterval:'year',enterpriseCheckout:false}};}
async function owner(env:Env,actorId:string){assert(await env.DB.prepare("SELECT 1 FROM users WHERE id=? AND role='owner' AND status='active'").bind(actorId).first(),'FORBIDDEN','只有平台所有者可以修改套餐配置',403);}
export async function createCatalogVersion(env:Env,actorId:string,input:{catalog:Catalog;reason:string;requestKey:string}){
 await owner(env,actorId);const parsed=z.object({catalog:catalogSchema,reason:z.string().trim().min(3).max(500),requestKey:z.string().regex(/^[\w:-]{16,128}$/)}).strict().parse(input),payload=JSON.stringify(parsed.catalog),hash=await sha256(JSON.stringify(parsed));
 const existing=await env.DB.prepare('SELECT id,payload_hash FROM billing_catalog_versions WHERE request_key=?').bind(parsed.requestKey).first<{id:string;payload_hash:string}>();if(existing){assert(existing.payload_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他套餐版本',409);return {id:existing.id};}
 const versionId=id('catalog'),now=new Date().toISOString();await env.DB.batch([
  env.DB.prepare('INSERT INTO billing_catalog_versions(id,version,payload_json,payload_hash,request_key,reason,created_by,created_at) SELECT ?,COALESCE(MAX(version),0)+1,?,?,?,?,?,? FROM billing_catalog_versions WHERE 1 ON CONFLICT(request_key) DO NOTHING').bind(versionId,payload,hash,parsed.requestKey,parsed.reason,actorId,now),
  env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?,?,'billing.catalog_created','catalog',id,?,?,? FROM billing_catalog_versions WHERE id=?`).bind(id('audit'),actorId,JSON.stringify({after:parsed.catalog,reason:parsed.reason}),parsed.requestKey,now,versionId),
 ]);const saved=await env.DB.prepare('SELECT id,payload_hash FROM billing_catalog_versions WHERE request_key=?').bind(parsed.requestKey).first<{id:string;payload_hash:string}>();assert(saved?.payload_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他套餐版本',409);return {id:saved.id};
}
export async function activateCatalog(env:Env,actorId:string,versionId:string,input:{expectedVersionId:string;enabled:boolean;reason:string;confirmedFutureOrdersOnly:true}){
 await owner(env,actorId);const parsed=z.object({expectedVersionId:z.string(),enabled:z.boolean(),reason:z.string().trim().min(3).max(500),confirmedFutureOrdersOnly:z.literal(true)}).strict().parse(input),before=await currentCatalog(env.DB);
 const target=await env.DB.prepare('SELECT id,payload_json FROM billing_catalog_versions WHERE id=?').bind(versionId).first<{id:string;payload_json:string}>();assert(target,'NOT_FOUND','套餐版本不存在',404);
 if(before.id===versionId&&before.enabled===parsed.enabled)return before;
 assert(before.id===parsed.expectedVersionId,'CATALOG_CONFLICT','当前套餐已变化，请刷新后确认',409);const guard=id('guard'),now=new Date().toISOString();
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN COALESCE((SELECT version_id FROM billing_catalog_active WHERE singleton=1),?)=? THEN 1 ELSE 0 END`).bind(guard,BUILTIN_CATALOG_ID,parsed.expectedVersionId),
  env.DB.prepare('INSERT INTO billing_catalog_active(singleton,version_id,enabled,updated_by,updated_at) VALUES(1,?,?,?,?) ON CONFLICT(singleton) DO UPDATE SET version_id=excluded.version_id,enabled=excluded.enabled,updated_by=excluded.updated_by,updated_at=excluded.updated_at').bind(versionId,parsed.enabled?1:0,actorId,now),
  auditStatement(env.DB,actorId,'billing.catalog_activated','catalog',versionId,{before:{id:before.id,enabled:before.enabled,catalog:before.catalog},after:{id:versionId,enabled:parsed.enabled,catalog:JSON.parse(target.payload_json)},reason:parsed.reason,futureOrdersOnly:true}),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard),
 ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('CATALOG_CONFLICT','套餐已被其他管理员更改，请刷新后重试',409);throw error;}
 return currentCatalog(env.DB);
}
export type PlanSnapshot={catalogVersionId:string;kind:'subscription'|'topup'|'hosting';tier:'go'|'pro'|null;name:string;amountCents:number;creditMicros:number;includedSites:number;interval:'month'|'year'|'once';topupCreditBps:6500|null;minimumTopupCents:number;currency?:'USD'|'CNY';billingMode?:'manual'|'automatic';topupCreditMicrosPerCnyCent?:number};
export function makeCnyPlanSnapshot(catalog:CatalogView,kind:PlanSnapshot['kind'],tier:'go'|'pro'|null=null,amount?:number):PlanSnapshot{
 const price=catalog.catalog.cnyPricing;assert(price,'ALIPAY_PRICING_NOT_CONFIGURED','管理员尚未设置人民币套餐价格与充值兑换规则，暂不能付款',503);
 const snapshot=makePlanSnapshot(catalog,kind,tier,amount);const cents=kind==='subscription'?(tier==='go'?price.goPriceCents:price.proPriceCents):kind==='hosting'?price.hostingAnnualPriceCents:amount!;
 assert(Number.isSafeInteger(cents)&&cents>0&&cents<=100_000_000,'VALIDATION','人民币金额无效');
 if(kind==='topup')assert(cents>=price.minimumTopupCents,'VALIDATION','充值金额低于当前人民币最低充值金额');
 const credit=kind==='topup'?cents*price.topupCreditMicrosPerCnyCent:snapshot.creditMicros;
 assert(Number.isSafeInteger(credit)&&credit<=100_000_000_000,'VALIDATION','充值所得AI额度超出单笔支持范围');
 return {...snapshot,currency:'CNY',billingMode:'manual',amountCents:cents,creditMicros:credit,topupCreditBps:null,minimumTopupCents:price.minimumTopupCents,topupCreditMicrosPerCnyCent:price.topupCreditMicrosPerCnyCent};
}
export function makePlanSnapshot(catalog:CatalogView,kind:PlanSnapshot['kind'],tier:'go'|'pro'|null=null,amountCents?:number):PlanSnapshot{const plan=tier?catalog.catalog[tier]:null;return {catalogVersionId:catalog.id,kind,tier,name:kind==='subscription'?(tier==='go'?'Go':'Pro'):kind==='hosting'?'CMS 年度托管':'AI 用量',amountCents:kind==='subscription'?plan!.priceCents:kind==='hosting'?catalog.catalog.hosting.annualPriceCents:amountCents!,creditMicros:kind==='subscription'?plan!.creditMicros:kind==='topup'?amountCents!*6500:0,includedSites:plan?.includedSites??0,interval:kind==='subscription'?'month':kind==='hosting'?'year':'once',topupCreditBps:6500,minimumTopupCents:500};}
export function orderPlanSnapshot(order:{kind:PlanSnapshot['kind'];plan_tier:'go'|'pro'|null;amount_cents:number;credit_micros:number;plan_snapshot_json?:string|null}):PlanSnapshot{
 if(order.plan_snapshot_json)return JSON.parse(order.plan_snapshot_json) as PlanSnapshot;
 // All pre-versioned orders were sold under these exact legacy site limits.
 // Preserve their recorded money, never substitute the currently active price.
 return {...makePlanSnapshot({id:BUILTIN_CATALOG_ID,version:0,enabled:true,catalog:DEFAULT_CATALOG,createdAt:null,createdBy:null,reason:'legacy'},order.kind,order.plan_tier,order.amount_cents),amountCents:order.amount_cents,creditMicros:order.credit_micros};
}
