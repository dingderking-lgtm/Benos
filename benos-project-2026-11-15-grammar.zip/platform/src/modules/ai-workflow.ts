﻿import { reviewHeroLayout, publicDesignTool, LAYOUT_REVIEW_VERSION } from '../lib/design-layout-review';
import { renderReviewSchema,assertRenderReviewSource,RENDER_REVIEW_RULES } from '../contracts/render-review';
import { DESIGN_AUTHORING_RULES,blueprintAuthoringRules } from '../contracts/design-authoring';
import { DESIGN_STYLES,findDesignStyle,suggestDesignStyles } from '../contracts/design-style-catalog';
import { createDesignBrief,createLegacyDesignBrief } from '../contracts/design-brief';
import { allocateWorkflowLayout } from '../lib/layout-allocation';
import type { LayoutPlan } from '../contracts/layout-plan';
import { createSitePlan,expandLayoutPlan,validateSitePlanManifest } from '../contracts/site-plan';
import { prepareSiteImageAllocation,checkSiteImageAllocation } from '../lib/site-image-allocation';
import { materializeSiteRenderCompatibility,SITE_RENDER_COMPATIBILITY_VERSION } from '../lib/site-render-compatibility';
import { effectiveDesignPricing } from '../lib/design-output-budget';
import { readApprovedPatterns } from '../lib/pattern-approvals';
import { filterCurrentPatternApprovals } from '../lib/page-composer';
import { siteCompositionJsonSchema,compileSiteComposition,freezeSiteComposition,finalizeSiteCompositionImages,validateSiteComposition } from '../lib/site-composer';
import { readApprovedV2Patterns } from '../lib/pattern-approvals-v2';
import { initializeV2SnapshotStorage,readCompositionSnapshot,storeCompositionSnapshot,readCompositionForwardManifest } from '../lib/site-composition-v2-storage';
import { siteCompositionV2JsonSchema,parseSiteCompositionV2,compileSiteCompositionV2,freezeSiteCompositionV2,finalizeSiteCompositionV2Images,validateSiteCompositionV2,preserveSiteCompositionV2Notices } from '../lib/site-composer-v2';
import { prepareApprovedV2Generation,assertV2ProductionPlan,assertV2ManifestSkeleton } from '../design-system/v2/production-plan';
import { COMPILED_BODY_PALETTE_VERSION,createCompiledBodyPalette,inheritCompiledBodyPalette,foundationWithCompiledBodyPalette,materializeCompiledBodyPalette } from '../lib/compiled-body-palette';
import { workflowImageTotals } from '../lib/workflow-image-costs';
import { v2ArtColors } from '../design-system/v2/styles';
import { parseConfirmedFacts,confirmedContacts,CONFIRMED_FACTS_HEADING } from '../lib/confirmed-facts';
import { MOBILE_NAV_VERSION,materializeMobileHeaderNavigation,validateMobileHeaderNavigation,mobileNavigationFeedback } from '../contracts/mobile-nav';
import { compileImageFramePlan,imagePromptForPlannedFrame,resolvePlannedImageFrame,type ImageFramePlan } from '../lib/image-frame-plan';
import { prepareSiteLayout,bindPreparedImages,validatePreparedImageCompletion,freezePreparedImageRetention,PREPARED_IMAGE_RETENTION_VERSION,IMAGE_DISPOSITION_REASONS,recordPreparedImageDispositions,preparedImageOmissions } from '../lib/prepared-site-layout';
import { createDesignFoundation,inheritDesignFoundation,foundationFromRequirements,foundationAuthoringContext,foundationAuthoringExample,foundationAuthoringManifest,materializeDesignFoundation,type DesignFoundation } from '../contracts/design-foundation';
import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { body,ok,type App } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { id,sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole,enforceScope,rateLimit } from './auth';
import { reserve,claimReservation,settle,markUncertain,getWallet,LedgerError,releaseConfirmedUnused } from './ledger';
import { textReservationCost,verifiedTextPricing,estimatedTextCost,type TextPricing } from './ai-billing';
import { buildTextProviderRequest,readTextProviderResponse,assertTextProviderResponse,textProviderUsageCost,textSupportsReferences } from './text-provider-adapter';
import { assertIntegrationCapability } from './integration-tests';
import { integrationSecret,resolveActiveTextConfiguration,textConfigurationPricing,type IntegrationRow } from './integrations';
import { GRAMMAR_PIPELINE_VERSION,bindGrammarImages,canComposeSiteGrammar,compileGrammarPackage,freezeGrammarComposition,grammarComposeSchema,grammarComposeTool,grammarSnapshot,validateGrammarComposition,type GrammarSnapshot,type GrammarWorkflowPlan } from '../lib/grammar-workflow';
import { siteEngineFor } from '../lib/engine-access';
import { prepareGrammarGeneration } from '../design-system/grammar/generation';
import { GRAMMAR_IDENTITY } from '../design-system/grammar/identity';
import { TEMPLATE_CONTRACT_BASELINE,validateSiteManifest } from './template-contract';
import { listMedia,readMedia } from './media';
import { createImageGeneration,imageGenerationQuote } from './images';
import { imageSlotParameter,imageSlotSchema,workflowImagesSchema,imageDisplay,imagePromptForSlot } from '../lib/image-layout';
import { diagnoseDesignCoherence,filterExplicitCoherenceIntent,designCoherenceFeedback } from './design-coherence';
import { normalizeSharedFragmentLinks } from './shared-fragment-links';
import { imagePromptWithVisualDirection,userSpecifiesImageDirection } from '../lib/image-visual-direction';
import { boundedImageQueue } from '../lib/bounded-image-queue';
import { GENERATION_POLICY_KEY,generationPolicySchema,loadGenerationPolicy,workflowGenerationPolicy,canStartOptionalReview } from '../lib/generation-policy';
import { PRESENTATION_POLICY_KEY,presentationPolicySchema,loadPresentationPolicy,presentationCapabilities,assertPresentationCapabilities } from '../lib/presentation-policy';
import { createDesignOrder,designOrderSchema,designOrderAuthoringRules,materializeDesignOrder,orderCreativeBrief } from '../contracts/design-order';
import { siteHeaderSpecSchema } from '../contracts/site-header';
import { hasCompiledHeaderPolicy,freezeSiteHeader,materializeFrozenHeader,headerCssIsolationIssues } from '../lib/site-header-materialization';
import { loadTypographySnapshot,enforceTypographySnapshot,typographyForStyle,projectCompiledHeaderTypography } from '../lib/design-typography';
import { typographySnapshotSchema } from '../contracts/design-typography';
import { verifyProjectAssets } from './project-assets';
import { ownedDesignProject,readDesignVersion,saveDesignCandidate,describeDesignNodes,assertDesignScope,type DesignScope } from './design-workspace';
import { designNodeHtml } from './design-nodes';
import { SELECTED_EDIT_VERSION,SELECTED_EDIT_RULES,selectedEditIntent,selectedEditContext,selectedEditIssues } from '../lib/selected-edit';
import example from '../contracts/site-example.json';
import { prepareEditWorkspace,editWorkspaceView,listEditFiles,readEditFragment,findEditText,patchEditWorkspace,validateEditWorkspace,finishEditWorkspace } from './design-editing';
import { ownedEditWorkspace,readEditObject,putEditObject,recoverEditObject,editNowSql,type EditWorkspace,type EditObject } from '../lib/design-edit-storage';
import { draftFiles,liveManifest,type StreamProgress } from '../lib/workflow-progress';
import { receiveMessage,rejectMessage,customerRefusal,projectConversation,conversationByKey,publicOutput,publicText,whiteLabel,pricingTerms,stepReplies } from './design-conversation';

// Audited 2026-11-07: function-call items/call_id and encrypted reasoning replay:
// https://developers.openai.com/api/docs/guides/function-calling
// https://developers.openai.com/api/docs/guides/reasoning
// Vision inputs become billable input tokens at the model input price and share
// its context ceiling. We reserve the WHOLE context, never estimated patch counts.
// https://developers.openai.com/api/docs/guides/images-vision
// https://developers.openai.com/api/docs/models/gpt-6.1-sol
const ADAPTER='responses-projected-files-v2-2026-11-07';
const MAX_STEPS=6,MAX_JSON_BYTES=600_000,MAX_REFERENCE_BYTES=6*1024*1024,LEASE_MS=240_000;
const scopeSchema=z.discriminatedUnion('kind',[z.object({kind:z.literal('site')}).strict(),z.object({kind:z.literal('node'),templateId:z.number().int().positive(),nodeKey:z.string().regex(/^n\d{1,9}$/)}).strict()]);
export const workflowInputSchema=z.object({requestKey:z.string().regex(/^[a-zA-Z0-9:_-]{16,128}$/),prompt:z.string().trim().min(3).max(20000),baseVersionId:z.string().nullable(),scope:scopeSchema,maxSteps:z.number().int().min(1).max(MAX_STEPS),maxCostMicros:z.number().int().positive().max(1_000_000_000),quoteHash:z.string().regex(/^[a-f0-9]{64}$/),referenceMediaIds:z.array(z.string().max(120)).max(3).default([]),configId:z.string().regex(/^[A-Za-z0-9_-]{1,120}$/).optional(),confirmedCharge:z.literal(true)}).strict();
export type WorkflowInput=z.infer<typeof workflowInputSchema>;
// Optional visual style preference: one line of at most 200 characters. Invisible
// characters (zero-width, direction marks) are removed before trimming; an
// absent, null or blank style is normalised away, so messages without a style
// keep the exact request hash they had before this field existed.
const STYLE_MAX=200,INVISIBLE=/[\u00AD\u200B-\u200F\u202A-\u202E\u2060-\u2064\u2066-\u2069\uFEFF]/g;
const styleSchema=z.string({error:'视觉风格必须是文字'}).transform(value=>value.replace(INVISIBLE,'').trim())
 .refine(value=>!/[\p{Cc}\u2028\u2029]/u.test(value),{error:'视觉风格只能是一行文字，不能包含换行或控制字符'})
 .refine(value=>[...value].length<=STYLE_MAX,{error:'视觉风格最多 200 个字符'})
 .nullish().transform(value=>value||undefined);
export const designMessageSchema=workflowInputSchema.pick({
 requestKey:true,prompt:true,baseVersionId:true,scope:true,referenceMediaIds:true,configId:true,
}).extend({prompt:z.string().trim().min(1).max(20000),style:styleSchema,renderReview:renderReviewSchema.optional()}).strict();
const MAX_PUBLIC_REPLY=8000,MAX_FINISH_SUMMARY=600;
type DesignMessage=Omit<z.infer<typeof designMessageSchema>,'style'>&{style?:string};
const MESSAGE_ORIGIN='account-design-message-v1';
const SITE_EDIT_COMPLETION_VERSION='explicit-site-edit-1';
const SITE_EDIT_COMPLETION_RULES='整站编辑完成契约 explicit-site-edit-1：先逐项核对本次用户请求，完成所有受影响页面/文件与已有素材复用；一次写入或静态检查通过只代表当前文件有效，不代表全部完成。无需凑轮数或重复读取；可在同轮依次提交必要修改，最后确认最新检查通过后明确调用 finish，才保存待采用方案。尚有未完成事项就继续处理或说明阻碍，不得声称已保存/采用。';
const FRAME_FIRST_VERSION='frame-first-2';
function frameFirst(w:{requirements_json:string}){return ['frame-first-1',FRAME_FIRST_VERSION].includes(JSON.parse(w.requirements_json).designPipelineVersion);}
function frameFirstV2(w:{requirements_json:string}){return JSON.parse(w.requirements_json).designPipelineVersion===FRAME_FIRST_VERSION;}
// A task started from a message runs until it is done or the customer's credit runs out. The ceiling only stops a
// task that keeps going without ever producing a design; a quoted task keeps the number of steps it was authorised for.
const ACCOUNT_STEP_CEILING=24;
function fromMessage(row:{requirements_json:string}){try{return JSON.parse(row.requirements_json)?.origin===MESSAGE_ORIGIN;}catch{return false;}}
function stepLimit(row:{max_steps:number;requirements_json:string}){return fromMessage(row)?ACCOUNT_STEP_CEILING:row.max_steps;}
const formatUsd=new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:6});
type BillingIntent={mode:'account'}|{mode:'quoted';authorization:WorkflowInput};
type Workflow={id:string;user_id:string;project_id:string;config_version_id:string;provider_id:string;request_key:string;request_hash:string;base_version_id:string|null;scope_json:string;requirements_json:string;pricing_json:string;reference_images_json:string;base_manifest_json:string|null;manifest_json:string;validated_hash:string|null;max_steps:number;max_cost_micros:number;per_step_micros:number;state:string;lease_token:string|null;lease_until_ms:number|null;candidate_id:string|null;error_code:string|null;created_at:string;updated_at:string;workspace_id?:string|null;activeStepId?:string;coherenceReview?:{offered:boolean;pendingHash?:string}};
type Step={attempts?:number;retired_micros?:number;progress_json?:string|null;id:string;workflow_id:string;ordinal:number;reservation_id:string;state:string;response_json:string|null;tool_results_json:string|null;error_code:string|null;created_at:string;updated_at:string;response_object_id?:string|null;tool_object_id?:string|null;public_reply?:string|null};
type Reference={id:string;sha256:string;mimeType:string;byteSize:number};
export interface WorkflowRuntime{fetch?:typeof fetch;}
const stringify=(value:unknown)=>JSON.stringify(value);
const pricingIdentity=(value:Record<string,unknown>)=>stringify(Object.keys(value).sort().map(key=>[key,value[key]]));
function boundedJson(value:unknown){const text=stringify(value);assert(new TextEncoder().encode(text).length<=MAX_JSON_BYTES,'WORKSPACE_TOO_LARGE','工作流内容超过安全处理上限',413);return text;}
function code(error:unknown){if(String((error as Error)?.cause).includes('edit_workspace_dispatch_denied'))return 'EDIT_WORKSPACE_CLOSED';return error instanceof AppError||error instanceof LedgerError?error.code:'WORKFLOW_TEMPORARILY_UNAVAILABLE';}
async function workflow(env:Env,userId:string,workflowId:string){const row=await env.DB.prepare('SELECT * FROM ai_workflows WHERE id=? AND user_id=?').bind(workflowId,userId).first<Workflow>();assert(row,'NOT_FOUND','设计工作流不存在',404);return row;}
async function steps(env:Env,workflowId:string){return (await env.DB.prepare('SELECT * FROM ai_workflow_steps WHERE workflow_id=? ORDER BY ordinal').bind(workflowId).all<Step>()).results;}
async function totals(env:Env,workflowId:string){return (await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN r.state IN ('settled','released') THEN r.actual_micros ELSE 0 END),0)+COALESCE(SUM(s.retired_micros),0) consumed,COALESCE(SUM(CASE WHEN r.state IN ('reserved','dispatching','uncertain') THEN r.amount_micros ELSE 0 END),0) held FROM ai_workflow_steps s LEFT JOIN api_reservations r ON r.id=s.reservation_id WHERE s.workflow_id=?`).bind(workflowId).first<{consumed:number;held:number}>())!;}
/** Public assistant text of one round: assistant messages (sanitised) plus the
 * `finish` summary when that call actually produced a candidate. Tool
 * arguments, reasoning and raw provider output never become public. */
function stepReply(response:any,executed:ToolResult,call:any,terms:readonly string[]){
 const parts=[publicOutput(response,terms)];
 if((executed.name==='finish'&&executed.result?.candidateId||executed.name==='complete_render_review'&&executed.result?.reviewCompleted)&&executed.result?.ok!==false){
  try{const summary=JSON.parse(String(call?.arguments??'{}'))?.summary;if(typeof summary==='string')parts.push(publicText([...summary.trim()].slice(0,MAX_FINISH_SUMMARY).join(''),terms));}catch{/* No summary. */}
 }
 return parts.filter(Boolean).join('\n\n').slice(0,MAX_PUBLIC_REPLY);
}
/** Public replies of a workflow's rounds, the same text the conversation shows.
 * Rounds recorded before replies were stored go through the shared loader,
 * which derives and stores them once. */
async function assistantReplies(env:Env,row:Workflow,history:Step[]){
 const terms=pricingTerms(row.pricing_json);
 const loaded=history.some(s=>typeof s.public_reply!=='string'&&(s.response_json||s.response_object_id))?new Map((await stepReplies(env,row.user_id,row.project_id,[row.id])).map(s=>[s.id,s.public_reply])):null;
 return history.map(s=>({ordinal:s.ordinal,text:loaded?loaded.get(s.id)??null:typeof s.public_reply==='string'?whiteLabel(s.public_reply,terms):null})).filter((r):r is {ordinal:number;text:string}=>!!r.text);
}
/** What the model has written so far in the step that is still being answered (display only). */
function stepProgress(step:Step){
 if(!['dispatching','responded'].includes(step.state)||!step.progress_json)return null;
 try{const value=JSON.parse(step.progress_json);return {seq:Number(value.seq)||0,text:typeof value.text==='string'?value.text:'',tool:typeof value.tool==='string'?value.tool:null,chars:Number(value.chars)||0,preview:value.preview===true,page:typeof value.page==='string'?value.page:null};}catch{return null;}
}
export async function workflowView(env:Env,userId:string,workflowId:string){
 const row=await workflow(env,userId,workflowId),history=await steps(env,row.id),balance=await totals(env,row.id),workspace=row.workspace_id?await env.DB.prepare('SELECT revision FROM design_edit_workspaces WHERE id=? AND user_id=?').bind(row.workspace_id,userId).first<{revision:number}>():null;
 const requirements = JSON.parse(row.requirements_json);
 const requestPrompt = typeof requirements?.request === 'string' ? requirements.request : null;
 const referenceMediaIds = (JSON.parse(row.reference_images_json) as Reference[]).map(reference => reference.id);
 const replies=await assistantReplies(env,row,history);
 const imageCosts=await workflowImageTotals(env,row),generationPolicy=workflowGenerationPolicy(row.requirements_json),cost={textMicros:balance.consumed,imageMicros:imageCosts.consumed,settledMicros:balance.consumed+imageCosts.consumed,heldMicros:balance.held+imageCosts.held,estimatedImageMicros:imageCosts.estimated,pendingImageAdjustmentMicros:imageCosts.pendingAdjustment,targetMicros:generationPolicy?.costTargetMicros??null,targetExceeded:!!generationPolicy&&balance.consumed+imageCosts.consumed>generationPolicy.costTargetMicros,basis:'settled-ledger-including-audited-estimates' as const};
 return {...imageOmissionResult(row),id:row.id,projectId:row.project_id,configId:row.config_version_id,requestOrigin:requirements?.origin===MESSAGE_ORIGIN?'account':'quoted',requestPrompt,style:typeof requirements?.style==='string'?requirements.style:null,assistantReplies:replies,assistantReply:replies.map(r=>r.text).join('\n\n')||null,state:row.state,workspaceId:row.workspace_id??null,workspaceRevision:workspace?.revision??null,baseVersionId:row.base_version_id,scope:JSON.parse(row.scope_json) as DesignScope,stepsUsed:history.length,maxSteps:stepLimit(row),maxCostMicros:row.max_cost_micros,perStepReservationMicros:row.per_step_micros,consumedMicros:balance.consumed,heldMicros:balance.held,cost,candidateId:row.candidate_id,previewUrl:row.candidate_id?`/preview/${encodeURIComponent(row.project_id)}/candidate/${encodeURIComponent(row.candidate_id)}`:null,errorCode:row.error_code,referenceMediaIds,referenceMode:referenceMediaIds.length?'model-input-image':'none',recoverable:row.state==='processing'&&(row.lease_until_ms??0)<=Date.now(),steps:history.map(s=>({id:s.id,ordinal:s.ordinal,state:s.state,reservationId:s.reservation_id,errorCode:s.error_code,progress:stepProgress(s),tools:s.tool_results_json?JSON.parse(s.tool_results_json).map(publicDesignTool):[]})),createdAt:row.created_at,updatedAt:row.updated_at};
}
async function activeConfig(env:Env,configId?:string){const row=await resolveActiveTextConfiguration(env,configId),pricing=textConfigurationPricing(row);verifiedTextPricing(pricing,row.provider);await assertIntegrationCapability(env.DB,row.id,'text');return {row,pricing};}
async function quoteHash(row:IntegrationRow,pricing?:TextPricing){return sha256(stringify({adapter:ADAPTER,id:row.id,publicConfig:row.public_config_json,...(pricing&&pricing.maxOutputTokens!==textConfigurationPricing(row).maxOutputTokens?{designOutputTokens:pricing.maxOutputTokens}:{})}));}
export function workflowAvailableAssets(media:Awaited<ReturnType<typeof listMedia>>,existing:ReadonlyArray<{file:string;path:string;sha256:string;size:number}>){
 assert(existing.length<=64,'ASSET_LIMIT','现有模板素材超过 64 项，不能开始设计任务');
 const usedFiles=new Set(existing.map(a=>a.file)),usedPaths=new Set(existing.map(a=>a.path)),usedHashes=new Set(existing.map(a=>a.sha256));
 const mapped=existing.map(asset=>{const item=media.find(m=>m.sha256===asset.sha256&&m.byteSize===asset.size);return {id:item?.id??null,fileName:item?.fileName??asset.file,width:item?.width??null,height:item?.height??null,asset:{...asset}};});
 for(const item of media){
  if(mapped.length>=64)break;
  if(usedPaths.has(item.assetPath)||usedHashes.has(item.sha256))continue;
  let n=0;while(usedFiles.has(`assets/${n}.${item.extension}`))n++;
  const asset={file:`assets/${n}.${item.extension}`,path:item.assetPath,sha256:item.sha256,size:item.byteSize};
  usedFiles.add(asset.file);usedPaths.add(asset.path);usedHashes.add(asset.sha256);
  mapped.push({id:item.id,fileName:item.fileName,width:item.width,height:item.height,asset});
 }
 return mapped;
}
function workflowMediaAsset(media:Awaited<ReturnType<typeof listMedia>>,available:ReturnType<typeof workflowAvailableAssets>,mediaId:string){
 const original=media.find(item=>item.id===mediaId);if(!original)return null;
 const shared=available.find(item=>item.asset.sha256===original.sha256&&item.asset.size===original.byteSize);
 return shared?{...shared,id:original.id,width:original.width,height:original.height}:null;
}
export async function workflowQuote(env:Env,userId:string,projectId:string,configId?:string){
 const project=await ownedDesignProject(env,userId,projectId);
 try{const {row,pricing:configured}=await activeConfig(env,configId),policy=!project.current_version_id?await loadGenerationPolicy(env):null,pricing=effectiveDesignPricing(configured,policy?.pipeline==='frame-first-2'),wallet=await getWallet(env.DB,userId),perStepReservationMicros=textReservationCost(pricing);return {available:true,configId:row.id,provider:row.provider,model:pricing.model,quoteHash:await quoteHash(row,pricing),maxOutputTokens:pricing.maxOutputTokens,perStepReservationMicros,maxStepsLimit:MAX_STEPS,availableMicros:wallet.availableMicros,canReserve:wallet.availableMicros>=perStepReservationMicros,referenceImagesSupported:textSupportsReferences(pricing),maxReferenceImages:3,maxReferenceBytes:MAX_REFERENCE_BYTES,basis:'model-context-ceiling',previewCheck:'structure-assets-scope-only'};}
 catch(error){return {available:false,reason:code(error),maxStepsLimit:MAX_STEPS,referenceImagesSupported:false};}
}
/** New-site design capacity, separate from the generic text generation quote. */
export async function designGenerationQuote(env:Env,userId:string,configId?:string){
 try{const {row,pricing:configured}=await activeConfig(env,configId),policy=await loadGenerationPolicy(env),pricing=effectiveDesignPricing(configured,policy.pipeline==='frame-first-2'),requiredReservationMicros=textReservationCost(pricing);
  const [wallet,pool]=await Promise.all([getWallet(env.DB,userId),env.DB.prepare('SELECT enabled FROM provider_pools WHERE provider_id=?').bind(pricing.providerPoolId).first<{enabled:number}>()]);
  return {available:pool?.enabled!==0,reason:pool?.enabled===0?'PROVIDER_UNAVAILABLE':null,configId:row.id,provider:row.provider,model:pricing.model,referenceImages:textSupportsReferences(pricing),maxOutputTokens:pricing.maxOutputTokens,requiredReservationMicros,availableMicros:wallet.availableMicros,canReserve:pool?.enabled!==0&&wallet.availableMicros>=requiredReservationMicros,basis:'model-context-ceiling'};
 }catch(error){return {available:false,canReserve:false,reason:code(error)};}
}
export async function createWorkflow(env:Env,userId:string,projectId:string,raw:WorkflowInput,runtime:WorkflowRuntime={}){
 const authorization=workflowInputSchema.parse(raw);
 return startDesignWorkflow(env,userId,projectId,authorization,{mode:'quoted',authorization},runtime);
}
export async function sendDesignMessage(env:Env,userId:string,projectId:string,raw:unknown,runtime:WorkflowRuntime={}){
 return startDesignWorkflow(env,userId,projectId,designMessageSchema.parse(raw),{mode:'account'},runtime);
}
const conversationQuerySchema=z.object({limit:z.coerce.number({error:'每页条数无效'}).int({error:'每页条数无效'}).min(1,{error:'每页可读取 1 至 50 条消息'}).max(50,{error:'每页可读取 1 至 50 条消息'}).default(20),before:z.string().min(1,{error:'对话分页位置无效'}).max(900,{error:'对话分页位置无效'}).optional()});
const REQUEST_KEY=/^[a-zA-Z0-9:_-]{16,128}$/;
/** Newest-first conversation page: one turn per message, including refused
 * messages and messages still waiting to be resumed. */
export async function listConversation(env:Env,userId:string,projectId:string,rawQuery:Record<string,string|undefined>){
 await ownedDesignProject(env,userId,projectId);await releaseHeldRounds(env,userId);
 const query=conversationQuerySchema.safeParse(rawQuery);
 if(!query.success)throw new AppError('VALIDATION',query.error.issues[0]?.message||'对话分页参数无效',400);
 return projectConversation(env,userId,projectId,query.data.limit,query.data.before);
}
export async function findConversationTurn(env:Env,userId:string,projectId:string,requestKey:string){
 await ownedDesignProject(env,userId,projectId);
 assert(REQUEST_KEY.test(requestKey),'VALIDATION','请求编号格式无效',400);
 return conversationByKey(env,userId,projectId,requestKey);
}
export async function findDesignMessage(env:Env,userId:string,projectId:string,requestKey:string){
 await ownedDesignProject(env,userId,projectId);await releaseHeldRounds(env,userId);
 const stored=await env.DB.prepare('SELECT id FROM ai_workflows WHERE user_id=? AND project_id=? AND request_key=?')
  .bind(userId,projectId,requestKey).first<{id:string}>();
 assert(stored,'NOT_FOUND','此项目尚无该消息记录',404);
 return workflowView(env,userId,stored.id);
}
async function startDesignWorkflow(env:Env,userId:string,projectId:string,input:DesignMessage,intent:BillingIntent,runtime:WorkflowRuntime){
 const project=await ownedDesignProject(env,userId,projectId);
 // Quoted requests preserve their historical hash. Direct messages derive identity
 // from the caller's immutable intent, independently of the live balance and rates.
 const hash=await sha256(stringify(intent.mode==='quoted'?{projectId,...intent.authorization}:{origin:MESSAGE_ORIGIN,projectId,...input}));
 const original=async()=>{
  const row=await env.DB.prepare('SELECT id,project_id,request_hash FROM ai_workflows WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<{id:string;project_id:string;request_hash:string}>();
  if(!row)return null;
  assert(row.project_id===projectId&&row.request_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他设计任务',409);
  return workflowView(env,userId,row.id);
 };
 const existing=await original();if(existing)return existing;
 if(intent.mode==='quoted')return createNewDesignWorkflow(env,userId,projectId,project,input,intent,hash,runtime);
 await releaseHeldRounds(env,userId);
 // Durable user intent is stored before pricing, reservation or dispatch, under
 // the same key and hash as the workflow (a trigger links them on insert). A
 // replay of a refused key returns the original refusal; a different payload
 // under the same key is an idempotency conflict.
 await receiveMessage(env,userId,projectId,hash,input);
 try{
  return await createNewDesignWorkflow(env,userId,projectId,project,input,intent,hash,runtime);
 }catch(error){
  // Record a definitive refusal first: it only applies while the turn is still
  // unlinked, so it can never override a workflow a concurrent identical request
  // created. When that turn is already refused, the stored refusal is thrown.
  // Platform-side conditions reach the customer, live and in the history, as a
  // neutral text; 5xx answers and conflicts are not stored at all.
  const refusal=customerRefusal(error);
  await rejectMessage(env,userId,projectId,input.requestKey,hash,refusal);
  // A concurrent identical create can consume the last available funds or finish
  // before this request gets its quote. Return its durable receipt in either case.
  const stored=await original();if(stored)return stored;throw refusal;
 }
}
async function existingDesignProfiles(env:Env,userId:string,projectId:string,versionId:string,base:any,allowPaletteUpgrade=false){
 const typography=await loadTypographySnapshot(env,userId,projectId,'version',versionId,await sha256(stringify(base)));
 // Follow content provenance, not version.parent_id (restore parents describe
 // history, not the restored content). Imports, advanced whole-manifest writes,
 // legacy generators and unknown sources are deliberate lineage boundaries.
 const origins=await env.DB.prepare(`WITH RECURSIVE ancestry(id,depth) AS (
  SELECT id,0 FROM design_versions WHERE id=? AND project_id=?
  UNION ALL SELECT source.id,a.depth+1 FROM ancestry a JOIN design_versions current ON current.id=a.id
   LEFT JOIN design_restore_requests r ON r.result_version_id=current.id AND r.source_hash=current.content_hash AND r.user_id=? AND r.project_id=?
   LEFT JOIN design_candidates c ON c.adopted_version_id=current.id AND c.state='adopted' AND c.user_id=? AND c.project_id=?
   JOIN design_versions source ON source.id=CASE WHEN r.id IS NOT NULL THEN r.source_version_id WHEN c.source='manual' THEN c.base_version_id ELSE NULL END AND source.project_id=?
   WHERE a.depth<32
 ) SELECT w.requirements_json FROM ancestry a JOIN design_candidates c ON c.adopted_version_id=a.id AND c.state='adopted' JOIN ai_workflows w ON w.id=c.workflow_id
 WHERE c.user_id=? AND c.project_id=? AND w.user_id=? AND w.project_id=? ORDER BY a.depth LIMIT 33`).bind(versionId,projectId,userId,projectId,userId,projectId,projectId,userId,projectId,userId,projectId).all<{requirements_json:string}>();
 for(const origin of origins.results){const profile=foundationFromRequirements(origin.requirements_json);if(profile){
  const foundation=inheritDesignFoundation(base,profile),source=JSON.parse(origin.requirements_json);
  const policy=presentationPolicySchema.safeParse(source.presentationPolicy),order=designOrderSchema.safeParse(source.designOrder),snapshot=source.compiledHeader;
  const header=base.templates?.find((template:any)=>template.id===base.site?.header_template_id),projectedHeader=snapshot?.version==='bnh-1'?projectCompiledHeaderTypography(snapshot,typography):snapshot;
  // Provenance alone cannot recompile a manually replaced header. Preserve
  // ownership only while the adopted subtree still equals its frozen bytes.
  const presentation=foundation?.version==='bnf-3'&&policy.success&&policy.data.mode==='orderly'&&order.success
   &&snapshot?.version==='bnh-1'&&typeof source.authoringRules==='string'
   &&snapshot.templateId===base.site?.header_template_id&&snapshot.resolved?.menuId===base.site?.navigation_menu_id
   &&header?.type==='header'&&header.document?.html===projectedHeader.html&&header.document?.css===projectedHeader.css&&!header.document?.customCss
   ?{presentationPolicy:policy.data,designOrder:order.data,compiledHeader:snapshot,authoringRules:source.authoringRules,...(source.compiledBodyPolicy==='bnx-owned-1'?{compiledBodyPolicy:'bnx-owned-1' as const}:{})}:null;
  return {foundation,presentation,compiledBodyPalette:presentation?inheritCompiledBodyPalette(source,allowPaletteUpgrade):null};
 }}
 return {foundation:null,presentation:null};
}
const BNX_LEGACY_SITE_AUTHORING_RULE='\n本任务已冻结 bnx-1 生产组件计划：只用 compose_site_v2 完成每页全部职责，使用设计计划的区块 ID、已分配 recommended 布局和统一 preset。页面及共享页脚模板先留空，平台编译真实组件、适配图框和样式。不得用原始 HTML/CSS 绕开组件。只为内容填写结构数据；不得捏造经营事实、图片或许可声明。';
const BNX_NEW_SITE_AUTHORING_RULE_1='\n本任务已冻结 bnx-1 生产组件计划：只用 compose_site_v2 完成每页全部职责，保持区块 ID、职责顺序和统一 preset。根据用户意图、内容数量、图片预算及完整主体要求，自主从各区块 choices 中挑选 patternId / variantId；recommended 仅作参考，不必照用。catalog 提供六个公开组件库适配后的名称、来源、版式和容量。不要为用完组件而塞入无关内容；有替代时相邻区块避免同版式，整站避免重复上一站的实际组合。页面及共享页脚模板先留空，平台编译真实组件、适配图框和样式。不得用原始 HTML/CSS 绕开组件，不得捏造经营事实、图片或许可声明。';
/** bnx-style-2: the compiler owns tone, spacing and heading arrangement; the
 * model is told how to choose a layout from the content and how to write for it. */
const BNX_NEW_SITE_AUTHORING_RULE=BNX_NEW_SITE_AUTHORING_RULE_1+'\n首屏若选 hero-cover（全幅场景首屏），图片 subjectPolicy 必须是 crop-safe。本站独有的构思：动笔前先为这个品牌定一个只属于本次任务的版面构思（节奏快慢、图文比重、首屏气质），不要套用"首屏—要点—图片—流程—问答—行动"的通用骨架；本任务每个区块只开放了少数几种版式且顺序已打乱，这是有意为之，请在这些选项内把这一站做出自己的性格。\n选版式（按内容，不按顺序轮换；只能选该区块 choices 里出现的）：有 2–4 个并列对象且各有图（产品、车型、房型、服务、案例）→ media-mosaic/cards，每项写 label 分类词与 href；只有一张强图要讲清一个主题 → media-story/spotlight；2–4 张图逐条讲述 → media-story/alternating；一张图配 3–5 条说明 → media-story/lead-list；多张氛围图 → media-mosaic/dominant 或 bento；需要一张有气势的整屏主题画面（品牌、汽车、地产、酒店、时装尤其适合，每页至多一处）→ banner/fullbleed，图片用 crop-safe；一张图与一段主张左右对开 → banner/split；只有一句品牌宣言 → manifesto/center；3–5 个关键词式的大字条目（系列、理念、服务门类）→ manifesto/index；品牌理念、定位或一句主张配说明 → features/statement；3–4 条短亮点 → features/band；6 条并列能力或服务 → features/grid（每个 item 按含义填 icon：check 保障或确认、layers 结构或层级、chart 数据或效率、search 检测或查找、grid 模块或品类、clock 时效或周期、circle 目标或精度、chat 沟通或服务、arrow 增长或出口、plus 扩展或增值，不要全部用同一个）；需要对照阅读的依据 → features/ledger；先后步骤 → process/cards（3–4 步）、process/steps 或 process/timeline；收尾行动 → action/centered 或 action/band。同一页内 features、process 不要都选带编号的版式。底色节奏、标题摆法、间距与悬停由平台决定，不要用文字去描述或弥补版式。'
 +'\n设计语言与配色（composition.art，必填，先想清楚再填）：direction 按品牌气质选——editorial：大牌官网的克制与留白，直角、细线、轻字重、极少装饰，适合汽车、奢侈品、时装、腕表、高端地产、建筑与酒店；bold：粗重大字、强对比、图形感，适合运动、潮流、电竞、活动、年轻消费品；soft：大圆角、柔和色块，适合母婴、宠物、美业、餐饮、生活方式、教育；studio：清晰的产品与企业风格，适合软件、科技、工业制造、专业服务。mode 选 light 或 dark：汽车、腕表、影音、夜间场景常用 dark，食品、家居、医疗、教育常用 light。accent 是这个品牌或行业真正会用的主色（十六进制）：已知品牌用其品牌色；没有品牌色时用行业共识色，例如豪华汽车用银灰或黑白，不要用与行业无关的颜色（汽车不用绿色，除非用户要求或品牌本身如此）；用户指定了颜色就用用户的。neutral 选 pure（纯黑白灰）、warm（偏暖米色）或 cool（偏冷蓝灰）。选完自问一遍：把这套颜色放到该行业头部品牌的官网旁边是否协调？不协调就改。'
 +'\n真实信息：需求里如果有“'+CONFIRMED_FACTS_HEADING+'”，其中每一项都是客户亲自确认的事实，必须原样使用，优先于你的任何推测：公司名称用作品牌名；公司介绍、成立时间、所在城市用于关于页和页脚；主要产品或服务逐项成为产品页的条目，不要另编产品。联系页的 contact 区块：电话和邮箱放进 content.contact（factRef 只能用设计计划 verifiedContent.contacts 里给出的），地址、工作时间、微信或 WhatsApp 作为 items（title 写“地址”“工作时间”等，text 写原文）；有联系表单需求时选 contact/form，表单由平台以 CMS 原生询盘表单输出。客户没有填写的项目一律不写，不要用“请联系我们获取”之类的话去填空，更不要编造电话、地址、年份、数字或客户名。'
 +'\n内容与说服：一个页面只推动一个主要行动，首屏只放一个主行动按钮（至多再加一个次行动），整页的行动按钮指向同一件事。首屏依次回答“这是什么、给谁、我能得到什么”：标题写结果和对象，lead 说明怎么做到并给出一个具体细节。中段按“访客的问题 → 你的做法 → 带来的好处 → 怎么开始”推进，每个区块只讲一件事。先写好处再写功能：功能是它做什么，好处是这对访客意味着什么。用具体说法代替空话：不写“高效”“专业”“一站式”“赋能”“引领”“打造”“助力”“匠心”“极致”“全方位”“world class”“cutting edge”“revolutionize”“effortless”这类词，改成说清楚具体做了什么、访客会看到什么变化。佐证紧跟在它支撑的那句话旁边，不要集中堆到页面底部；没有已确认的佐证就不写佐证，绝不自己编。按钮写“动词 + 得到什么”（如“预约试驾”“获取报价”“下载选型表”），不写“了解更多”“点击这里”“提交”。常见问题写访客真正的顾虑（价格、周期、售后、是否适合自己），每条答案直接回答，不绕开。需求里如果写了“希望访客做什么”“目标客户”“客户常见顾虑”，主行动、语气和常见问题分别以它们为准。'
 +'\n书写规范：英文标题和按钮用句首大写（sentence case），不用全大写，不用感叹号；正文和标题里不用连字符“-”把词硬接在一起，改写成完整的说法；不用斜体。每个首页要有一处独立的主张区块：区块 choices 里出现 manifesto/center 或 features/statement 时至少选用一次，标题写成至少两行的品牌主张，而不是栏目名。'
 +'\n文案：标题是一句完整主张，中文不超过 16 个字、英文不超过 9 个词，不写“关于我们”“我们的服务”这类栏目名；eyebrow 用 2–6 个字的栏目词；lead 一句话；每个 item 的 title 不超过 12 个字，text 一句话说清一个具体好处或事实，不重复 title。items 数量取能排满网格的数（3、4 或 6），不要 5 条或只有 2 条的卡片组。不写“概念示意”“仅供参考”“点击了解更多”等说明性或免责性辅助文字，图片说明只写画面内容。首屏给一个主行动和至多一个次行动。图片预算内优先把图用在首屏和 cards/spotlight 上，同一张图不在同一页重复出现。';
async function createNewDesignWorkflow(env:Env,userId:string,projectId:string,project:Awaited<ReturnType<typeof ownedDesignProject>>,input:DesignMessage,intent:BillingIntent,hash:string,runtime:WorkflowRuntime){
 assert(project.current_version_id===input.baseVersionId,'VERSION_CONFLICT','当前设计已变化，请刷新后重新发送',409);
 const generationPolicy=!input.baseVersionId&&input.scope.kind==='site'?await loadGenerationPolicy(env):null;
 // A new site is written by one engine. The grammar engine is off by default and owner only, so a
 // policy that never mentions it keeps the composition engine exactly as it was.
 const siteEngine=generationPolicy?await siteEngineFor(env,userId,generationPolicy):'compose-v2';
 const grammar=siteEngine==='syntax-1';
 const planning=generationPolicy?.pipeline==='frame-first-2'&&!grammar;
 const {row,pricing:configured}=await activeConfig(env,input.configId),pricing=effectiveDesignPricing(configured,planning),perStep=textReservationCost(pricing);
 let maxSteps=MAX_STEPS,maxCostMicros:number;
 if(intent.mode==='quoted'){
  const authorization=intent.authorization;
  assert(authorization.quoteHash===await quoteHash(row,pricing),'QUOTE_CHANGED','模型或计价配置已变化，请重新确认本次任务预算',409);
  maxSteps=authorization.maxSteps;maxCostMicros=authorization.maxCostMicros;
  assert(maxCostMicros>=perStep,'WORKFLOW_BUDGET_TOO_SMALL',`本次每轮需预占 ${perStep} 微美元，请确认不低于该金额的任务上限`);
 }else{
  const wallet=await getWallet(env.DB,userId);
  // The text is stored with a refused message and replayed later, so it carries
  // the stable per-round requirement and no balance, which would go stale.
  assert(wallet.availableMicros>=perStep,'INSUFFICIENT_CREDIT',`本轮需预留 ${formatUsd.format(perStep/1e6)}，账户可用额度不足；请充值后重新发送`,409);
  // The customer's own credit is the only spending limit of a message.
  maxCostMicros=Math.min(wallet.availableMicros,1_000_000_000);
  assert(maxCostMicros>=perStep,'AI_BILLING_UNVERIFIED','单轮预留超出平台单消息限额',503);
 }
 assert(!input.referenceMediaIds.length||textSupportsReferences(pricing),'VISION_BILLING_UNVERIFIED','所选模型不支持参考图；请移除参考图或选择支持图片的模型',422);
 assert(new Set(input.referenceMediaIds).size===input.referenceMediaIds.length,'VALIDATION','参考图片不能重复');
 const media=await listMedia(env,userId,projectId),references:Reference[]=[];let referenceBytes=0;
 for(const mediaId of input.referenceMediaIds){const item=media.find(m=>m.id===mediaId);assert(item,'MEDIA_NOT_FOUND','参考图必须属于当前项目且处于可用状态',404);assert(['image/png','image/jpeg','image/webp'].includes(item.mimeType),'REFERENCE_IMAGE_TYPE','AI 参考图仅支持 PNG、JPEG、WebP，其他素材可用于网站设计',422);referenceBytes+=item.byteSize;assert(referenceBytes<=MAX_REFERENCE_BYTES,'REFERENCE_IMAGE_LIMIT','参考图合计最多 6 MiB，请先压缩');references.push({id:item.id,sha256:item.sha256,mimeType:item.mimeType,byteSize:item.byteSize});}
 const source=input.baseVersionId?await env.DB.prepare('SELECT manifest_json,manifest_object_id,content_hash FROM design_versions WHERE id=? AND project_id=?').bind(input.baseVersionId,projectId).first<{manifest_json:string;manifest_object_id:string|null;content_hash:string}>():null;
 const sourceBytes=source?.manifest_object_id?JSON.parse(source.manifest_json).byteSize:source?new TextEncoder().encode(source.manifest_json).length:0;
 if(input.renderReview){assert(sourceBytes<=MAX_JSON_BYTES,'RENDER_REVIEW_TOO_LARGE','当前页面较大，请先缩小设计后审查',422);assert(input.referenceMediaIds.length===0,'RENDER_REVIEW_REFERENCES','渲染审查使用现有页面，请移除额外参考图',422);}
 const workspace=sourceBytes>MAX_JSON_BYTES?await prepareEditWorkspace(env,userId,projectId,{requestKey:input.requestKey,baseVersionId:input.baseVersionId!,scope:input.scope},true):null;
 const base=!workspace&&input.baseVersionId?await readDesignVersion(env,userId,projectId,input.baseVersionId,MAX_JSON_BYTES):null;if(!workspace)assertDesignScope(base,base??example,input.scope);
 if(input.renderReview){assert(base,'RENDER_REVIEW_SOURCE','请先保存设计再审查',422);assertRenderReviewSource(input.renderReview,{versionId:input.baseVersionId,hash:source?.content_hash??null},base,input.scope);}
 const now=new Date().toISOString(),workflowId=id('workflow');
 const availableAssets=workflowAvailableAssets(media,workspace?JSON.parse(workspace.assets_json):(base??example).assets);
 const previousTurns = await env.DB.prepare(`
   SELECT substr(json_extract(w.requirements_json, '$.request'), 1, 1200) AS request,
          w.state AS workflowState, c.state AS candidateState, w.error_code AS errorCode,
          (SELECT substr(group_concat(s.public_reply, char(10)), 1, 900) FROM ai_workflow_steps s
            WHERE s.workflow_id = w.id AND s.public_reply IS NOT NULL AND s.public_reply <> '') AS reply
   FROM ai_workflows w LEFT JOIN design_candidates c
     ON c.id = w.candidate_id AND c.project_id = w.project_id
   WHERE w.user_id = ? AND w.project_id = ?
   ORDER BY w.created_at DESC, w.id DESC LIMIT 8
 `).bind(userId, projectId).all<{ request: string | null; workflowState: string; candidateState: string | null; errorCode: string | null; reply: string | null }>();
 const previousRequests = previousTurns.results.reverse().filter(turn => turn.request);
 // Choose once on the server. Resume/retry reuses this exact token snapshot; a
 // legacy design or a scoped edit never acquires a new foundation implicitly.
 const inherited=base&&input.baseVersionId?await existingDesignProfiles(env,userId,projectId,input.baseVersionId,base,input.scope.kind==='site'&&!workspace):null;
 const presentationPolicy=grammar?null:inherited?.presentation?.presentationPolicy??(generationPolicy?.pipeline==='frame-first-2'?await loadPresentationPolicy(env):null);
 const requestedOrder=presentationPolicy?.mode==='orderly'?createDesignOrder({request:input.prompt,stylePreference:input.style}):null;
 const designOrder=grammar?null:inherited?.presentation?{...inherited.presentation.designOrder,providedTargets:[...new Set([...(requestedOrder?.providedTargets??[]),...inherited.presentation.designOrder.providedTargets])].slice(0,12)}:requestedOrder;
 const knownStyle=findDesignStyle(input.style),suggested=suggestDesignStyles(input.prompt+' '+(project.description??'')),selectedStyle=!input.baseVersionId?(knownStyle??(input.style?DESIGN_STYLES[0]:suggested[crypto.getRandomValues(new Uint32Array(1))[0]%suggested.length])):null;
 let foundation=selectedStyle?createDesignFoundation(input.style&&!knownStyle?{id:selectedStyle.id,name:'自定义方向',brief:input.style,tokens:selectedStyle.tokens,primitives:selectedStyle.primitives}:selectedStyle,workflowId,designOrder?{designOrder}:undefined):inherited?.foundation??null;
 const typography=input.baseVersionId?await loadTypographySnapshot(env,userId,projectId,'version',input.baseVersionId,source?.content_hash):(selectedStyle&&foundation?typographyForStyle(selectedStyle.id):null);
 if(!input.baseVersionId&&foundation&&typography){if(typography.heading)foundation.tokens.headingFont=typography.heading.stack;if(typography.body)foundation.tokens.bodyFont=typography.body.stack;}
 // The professional brief is local and immutable for this workflow. Ordinary
 // users supply business intent; they need not author typography/layout/image
 // instructions or pay for a separate planning request. Existing edits keep
 // their established direction and never receive a new-site plan implicitly.
 const baseBrief=(planning?createDesignBrief:createLegacyDesignBrief)({request:input.prompt,hasExistingSite:!!input.baseVersionId,referenceImageCount:references.length,scope:input.scope.kind,stylePreference:input.style});
 const designBrief=designOrder&&baseBrief?orderCreativeBrief(baseBrief,designOrder):baseBrief;
 let manifest=workspace?JSON.stringify({format:'benos-edit-workspace',version:1,workspaceId:workspace.id}):boundedJson(base??(foundation?foundationAuthoringExample(foundation):example));
 const approvedPatternSnapshot=planning?await filterCurrentPatternApprovals(await readApprovedPatterns(env.DB)):undefined;
 const siteOwnedImages=availableAssets.filter(asset=>asset.width&&asset.height).map(asset=>({path:asset.asset.path,width:asset.width!,height:asset.height!,source:media.find(item=>item.id===asset.id)?.source==='upload'?'uploaded' as const:media.find(item=>item.id===asset.id)?.source==='generation'?'generated' as const:'unknown' as const}));
 const frozenSitePlan=planning&&designBrief?createSitePlan({request:input.prompt,brief:designBrief,availableImageCount:availableAssets.filter(a=>a.width&&a.height).length,maxImages:generationPolicy?.maxImages??8}):null;
 const grammarImages=grammar?availableAssets.filter(asset=>asset.width&&asset.height).slice(0,24).map((asset,index)=>({id:'img-'+(index+1),src:asset.asset.path,w:asset.width!,h:asset.height!,alt:''})):[];
 const grammarAssets=grammar?availableAssets.filter(asset=>asset.width&&asset.height).slice(0,24).map((asset,index)=>{const item=media.find(entry=>entry.id===asset.id),extension=/\.(png|jpe?g|webp|avif|gif)$/i.exec(asset.asset.path)?.[1]?.toLowerCase()??'webp';return {path:asset.asset.path,file:'assets/'+String(index+1).padStart(2,'0')+'.'+(extension==='jpg'?'jpeg':extension),sha256:item?.sha256??'',size:item?.byteSize??0};}):[];
 const grammarSiteSlug=(String(project.name||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60)||'benos-site').padEnd(2,'-');
 const grammarPlan:GrammarWorkflowPlan|null=grammar?await prepareGrammarGeneration({request:input.prompt,seed:workflowId,createdAt:now,pageCount:Math.min(4,Math.max(2,Math.ceil(grammarImages.length/2)||2)),images:grammarImages.map(image=>({id:image.id,src:image.src,width:image.w,height:image.h,alt:image.alt}))}) as GrammarWorkflowPlan:null;
 const v2Approvals=frozenSitePlan?await readApprovedV2Patterns(env.DB):[];
 const previousV2=v2Approvals.length?await env.DB.prepare("SELECT COALESCE(json_extract(requirements_json,'$.composedLayout.selection.signature'),json_extract(requirements_json,'$.designSystemV2.signature')) signature FROM ai_workflows WHERE user_id=? AND json_extract(requirements_json,'$.designSystemV2.version')='bnx-generation-1' AND json_extract(requirements_json,'$.composedLayout.version')='site-compose-v2' ORDER BY created_at DESC,id DESC LIMIT 1").bind(userId).first<{signature:string}>():null;
 const designSystemV2=frozenSitePlan&&v2Approvals.length?await prepareApprovedV2Generation({request:input.prompt,seed:workflowId,stylePreference:input.style,sitePlan:frozenSitePlan,availableImageCount:siteOwnedImages.length,approvedSnapshot:v2Approvals,confirmedContacts:confirmedContacts(parseConfirmedFacts(input.prompt)),...(previousV2?{previousSignature:previousV2.signature}:{})}):null;
 const compiledBodyPalette=designSystemV2?createCompiledBodyPalette(designSystemV2):inherited?.compiledBodyPalette??null;
 if(foundation&&compiledBodyPalette){foundation=foundationWithCompiledBodyPalette(foundation,compiledBodyPalette);if(!base&&!workspace)manifest=boundedJson(foundationAuthoringExample(foundation));}
 let frozenRules=inherited?.presentation?.authoringRules??(planning?blueprintAuthoringRules(DESIGN_AUTHORING_RULES):DESIGN_AUTHORING_RULES);
 // An existing-site edit has ordinary scoped tools, not the new-site composer.
 // Remove only our exact creation instruction when freezing this NEW edit;
 // stored task messages and all typography/scope rules remain unchanged.
 if(input.baseVersionId)frozenRules=frozenRules.replace(BNX_NEW_SITE_AUTHORING_RULE,'').replace(BNX_NEW_SITE_AUTHORING_RULE_1,'').replace(BNX_LEGACY_SITE_AUTHORING_RULE,'');
 if(designOrder&&!inherited?.presentation)frozenRules=designOrderAuthoringRules(frozenRules,designOrder)+'\n页头 CSS 归平台所有：自定义样式只用正文/页脚类；不写 header/bnh-* 选择器，不用 !important 或全局布局覆盖。品牌配色使用 theme 字段。';
 if(typography&&!frozenRules.includes('字体目录 btf-1 已冻结'))frozenRules+='\n字体目录 btf-1 已冻结：使用 --bnf-heading / --bnf-body，保留所有 btf-local-* 用户字体锚点，不得重命名、移除或重复；平台在提交后恢复已确认字体，不调用外部字体。';
 if(designSystemV2)frozenRules+=BNX_NEW_SITE_AUTHORING_RULE;
 const paletteRule='\n平台页头与基础配色已配对，普通内容修改提交时也会恢复可读颜色；无需先单独修页头。完成用户的全部修改，保留明确配色和字体，不写页头 CSS。';
 if(compiledBodyPalette&&!frozenRules.includes(paletteRule))frozenRules+=paletteRule;
 const selectedEdit=!!base&&input.scope.kind==='node'&&!workspace?{selectedEditProtocol:SELECTED_EDIT_VERSION,selectedEditIntent:selectedEditIntent(input.prompt),selectedEditRules:frozenRules.replace('不用 !important 或全局布局覆盖','不用全局布局覆盖')+'\n'+SELECTED_EDIT_RULES}:null;
 const requirementsValue={...(intent.mode==='account'?{layoutReviewVersion:LAYOUT_REVIEW_VERSION}:{}),...(selectedEdit??{}),...(typography?{typography}:{}),...(intent.mode==='account'?{origin:MESSAGE_ORIGIN}:{}),...(generationPolicy?{designPipelineVersion:grammar?GRAMMAR_PIPELINE_VERSION:generationPolicy.pipeline,generationPolicy,...(!designOrder?{mobileNavigation:MOBILE_NAV_VERSION}:{})}:{}),...(presentationPolicy?{presentationPolicy}:{}),...(inherited?.presentation?{compiledHeader:inherited.presentation.compiledHeader}:{}),...(designOrder?{designOrder}:{}),...((planning||designOrder||typography||selectedEdit)?{authoringRules:frozenRules}:{}),...(planning?{approvedPatternSnapshot}:{}),projectName:project.name,brief:project.description,previousRequests,request:input.prompt,...(foundation?{foundation}:{}),...(designBrief?{designBrief}:{}),...(input.style?{style:input.style}:{}),scope:input.scope,referenceImageIds:input.referenceMediaIds,availableAssets};
 if(input.baseVersionId&&input.scope.kind==='site')Object.assign(requirementsValue,{completionProtocol:SITE_EDIT_COMPLETION_VERSION,completionRules:SITE_EDIT_COMPLETION_RULES});
 if(input.renderReview)Object.assign(requirementsValue,{renderReview:input.renderReview,renderReviewRules:RENDER_REVIEW_RULES,selectedEditIntent:'edit',selectedEditRules:(selectedEdit?.selectedEditRules??frozenRules)+'\n'+RENDER_REVIEW_RULES});
 if(planning)Object.assign(requirementsValue,{componentContract:'bnx-1'});
 if(designSystemV2)Object.assign(requirementsValue,{designSystemV2,compiledBodyPolicy:'bnx-owned-1'});
 else if(inherited?.presentation?.compiledBodyPolicy==='bnx-owned-1')Object.assign(requirementsValue,{compiledBodyPolicy:'bnx-owned-1'});
 if(compiledBodyPalette)Object.assign(requirementsValue,{compiledBodyPaletteVersion:COMPILED_BODY_PALETTE_VERSION,compiledBodyPalette});
 const workflowStatement=(plan?:LayoutPlan)=>{
  // Page responsibility is frozen with the same atomic account allocation.
  // Existing tasks never infer a newer plan while being resumed or edited.
  const sitePlan=frozenSitePlan;
  return env.DB.prepare(`INSERT INTO ai_workflows(id,user_id,project_id,config_version_id,provider_id,request_key,request_hash,base_version_id,scope_json,requirements_json,pricing_json,reference_images_json,base_manifest_json,manifest_json,max_steps,max_cost_micros,per_step_micros,created_at,updated_at,workspace_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,request_key) DO NOTHING`).bind(workflowId,userId,projectId,row.id,pricing.providerPoolId,input.requestKey,hash,input.baseVersionId,stringify(input.scope),boundedJson({...requirementsValue,...(planning?{imageCompletionPolicy:PREPARED_IMAGE_RETENTION_VERSION}:{}),...(sitePlan?{sitePlan,siteOwnedImages,siteCompositionVersion:designSystemV2?'site-compose-v2':'site-compose-1',siteLayoutCompatibilityVersion:SITE_RENDER_COMPATIBILITY_VERSION}:{}),...(grammarPlan?{siteCompositionVersion:GRAMMAR_PIPELINE_VERSION,grammarPlan,grammarImages,grammarAssets,grammarSiteName:project.name,grammarSiteSlug}:{}),...(plan?{layoutPlan:sitePlan?expandLayoutPlan(plan,sitePlan):plan}:{})}),stringify(pricing),stringify(references),base?manifest:null,manifest,maxSteps,maxCostMicros,perStep,now,now,workspace?.id??null);
 };
 try{
  if(planning&&designBrief)await allocateWorkflowLayout(env.DB,{userId,workflowId,requestKey:input.requestKey,seed:workflowId,allocationId:id('layout'),request:input.prompt,referenceImageCount:references.length,availableImageCount:availableAssets.filter(a=>a.width&&a.height).length,brief:designBrief,workflowStatement});
  else await workflowStatement().run();
 }catch(error){
  // The conversation guard refuses a workflow for a key whose message was
  // refused or recorded with a different payload or project.
  if(String(error).includes('conversation_intent_conflict')||String((error as Error)?.cause).includes('conversation_intent_conflict'))throw new AppError('IDEMPOTENCY_CONFLICT','请求编号已用于其他设计消息',409);
  throw error;
 }
 const created=await env.DB.prepare('SELECT * FROM ai_workflows WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<Workflow>();assert(created&&created.request_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他设计任务',409);
 if(created.id!==workflowId)return workflowView(env,userId,created.id);
 return continueWorkflow(env,userId,workflowId,runtime,1);
}

const empty={type:'object',properties:{},required:[],additionalProperties:false};
const MAX_WORKFLOW_IMAGES=6;
const fileProperties={path:{type:'string',description:'manifest.json or an existing templates/<numeric-id>.html / .css virtual file'},content:{type:'string'}};
const tool=(name:string,description:string,parameters:unknown=empty)=>({type:'function',name,description,parameters,strict:true});
// The summary is user-facing chat text and purely cosmetic: whatever the model
// sends for it (too long, null, a number, nothing) never fails `finish`. Only a
// string is shown, trimmed and cut to the limit the tool schema declares.
const finishParameters={type:'object',properties:{summary:{type:'string',maxLength:MAX_FINISH_SUMMARY,description:'One or two sentences in Simplified Chinese for the end user describing the main changes of this candidate. No code, HTML, JSON or tool names.'}},required:['summary'],additionalProperties:false};
const finishArgs=z.object({summary:z.unknown().optional()}).strict();
const COMPLETE_RENDER_REVIEW_TOOL=tool('complete_render_review','Complete this render-informed review WITHOUT changing the design when no reliable fix is necessary or possible. Explain the reason, do not invent a change. This is not screenshot review or browser acceptance.',{type:'object',properties:{verdict:{type:'string',enum:['no_change','needs_attention']},summary:{type:'string',minLength:1,maxLength:600}},required:['verdict','summary'],additionalProperties:false});
export const WORKFLOW_TOOLS=[
 tool('read_project','Read the immutable user brief, scope, private media metadata, and current editable node identifiers.'),
 tool('read_rules','Read the AACMS contract and authoring rules. No external access.'),
 tool('list_files','List the isolated template virtual files.'),
 tool('read_file','Read one isolated virtual file.',{type:'object',properties:{path:fileProperties.path},required:['path'],additionalProperties:false}),
 tool('propose_files','Propose changes to virtual files only. Does not publish, adopt or touch the current design. manifest.json can initialize a new complete site; existing template files can be edited individually.',{type:'object',properties:{files:{type:'array',minItems:1,maxItems:8,items:{type:'object',properties:fileProperties,required:['path','content'],additionalProperties:false}}},required:['files'],additionalProperties:false}),
 tool('check_preview','Check AACMS structure, private asset bytes and requested modification scope. This is NOT browser rendering, screenshot comparison or visual acceptance.'),
 tool('finish','After check_preview passed for the latest files, save a candidate for the user to preview and adopt. Never publish or change the current design.',finishParameters),
];
/** Offered only while an image model is enabled and the customer's credit can hold one image. */
export const IMAGE_WORKFLOW_TOOL=tool('create_images','Plan the actual image frames first, then generate only the 1-4 images needed in one call. Each image is charged and saved to project media. The platform chooses the closest supported landscape, portrait or square size and adds crop-safe composition instructions. Results include real dimensions, the planned slot and display CSS. Do not reuse one image across incompatible frames.',{type:'object',properties:{images:{type:'array',minItems:1,maxItems:4,items:{type:'object',properties:{section:{type:'string',maxLength:60,description:'The specific image frame, e.g. hero-wide, product-detail, portrait-factory.'},prompt:{type:'string',minLength:10,maxLength:2000,description:'Subject, visual style, light, materials, brand palette and composition for this exact frame. Keep concise: content plus geometry must fit the model prompt limit. No text, logos or watermarks.'},slot:imageSlotParameter},required:['section','prompt','slot'],additionalProperties:false}}},required:['images'],additionalProperties:false});
const assetParameter={type:'object',properties:{file:{type:'string'},path:{type:'string'},sha256:{type:'string'},size:{type:'integer'}},required:['file','path','sha256','size'],additionalProperties:false};
const preparedImageProperties={id:{type:'string',pattern:'^[a-z][a-z0-9-]{0,59}$'},sectionId:{type:'string',pattern:'^[a-z][a-z0-9-]{0,59}$'},layout:{type:'string',minLength:3,maxLength:160,description:'How this section arranges copy and media.'},purpose:{type:'string',minLength:3,maxLength:160},prompt:{type:'string',minLength:10,maxLength:2000},alt:{type:'string',minLength:1,maxLength:240},slot:imageSlotParameter,subjectPolicy:{type:'string',enum:['complete','crop-safe']},framePolicy:{type:'string',enum:['adapt','fixed']}};
export const PREPARE_LAYOUT_TOOL=tool('prepare_layout','Create a new complete site AND its 1-4 image frames in one call. Submit manifest.json first; each image frame is an EMPTY div with id="bnf-image-<id>" (caption outside). The platform validates and saves the layout before paying for images, then fills the frames automatically. Complete products: use subjectPolicy=complete and framePolicy=adapt; the frame adapts to the supported source ratio without bars. A fixed banner uses crop-safe composition. Do not add placeholder img or these generated assets yourself. On failure, fix only the affected file or remove the empty frame; never repeat paid images for cosmetic revisions.',{type:'object',properties:{files:{type:'array',minItems:1,maxItems:1,items:{type:'object',properties:fileProperties,required:['path','content'],additionalProperties:false}},images:{type:'array',minItems:1,maxItems:4,items:{type:'object',properties:preparedImageProperties,required:Object.keys(preparedImageProperties),additionalProperties:false}}},required:['files','images'],additionalProperties:false});
const preparedLayoutSchema=z.object({files:z.array(z.object({path:z.literal('manifest.json'),content:z.string().min(1).max(MAX_JSON_BYTES)}).strict()).length(1),images:z.array(z.object({id:z.string().regex(/^[a-z][a-z0-9-]{0,59}$/),sectionId:z.string().regex(/^[a-z][a-z0-9-]{0,59}$/),layout:z.string().min(3).max(160),purpose:z.string().min(3).max(160),prompt:z.string().min(10).max(2000),alt:z.string().trim().min(1).max(240).refine(value=>!/[\u0000-\u0008\u000b\u000c\u000e-\u001f]|\{\{|\}\}|\{%|%\}/u.test(value),'图片说明必须是普通文字'),slot:imageSlotSchema,subjectPolicy:z.enum(['complete','crop-safe']),framePolicy:z.enum(['adapt','fixed'])}).strict()).min(1).max(4)}).strict();
const preparedImageV2Properties={...preparedImageProperties,presentation:{type:'string',enum:['standard','hero-cover'],description:'hero-cover only with bnf-2 cover structure, crop-safe + fixed + cover. standard for other frames.'}};
export const PREPARE_LAYOUT_V2_TOOL=tool('prepare_layout','Save a complete new site and its 1-8 purpose-specific image frames before generating. Use uploaded assets first; follow designBrief.imagePlan and explicit user limits. Submit one shared artDirection for colour, light, lens, scene and avoid-list; vary subjects and composition. Each frame is an empty div id="bnf-image-<id>". Full-bleed hero-cover must use the platform cover structure with a separate safe text panel; complete products use standard + complete + adapt. The platform validates all frames and prompts before any image is charged, then fills them. Failed images are not retried: replace only those frames with meaningful content. Never regenerate the whole site for cosmetic fixes.',{type:'object',properties:{files:{type:'array',minItems:1,maxItems:1,items:{type:'object',properties:fileProperties,required:['path','content'],additionalProperties:false}},artDirection:{type:'string',minLength:1,maxLength:600,description:'One shared visual direction for this site, subordinate to explicit user preferences and the frame composition.'},images:{type:'array',minItems:1,maxItems:8,items:{type:'object',properties:preparedImageV2Properties,required:Object.keys(preparedImageV2Properties),additionalProperties:false}}},required:['files','artDirection','images'],additionalProperties:false});
const preparedLayoutV2Schema=preparedLayoutSchema.extend({artDirection:z.string().trim().min(1).max(600),images:z.array(preparedLayoutSchema.shape.images.element.extend({presentation:z.enum(['standard','hero-cover'])})).min(1).max(8)}).strict();
// A versioned tool variant keeps old call arguments and hashes unchanged.
const { $schema:_headerSchemaDialect,...headerParameter }=z.toJSONSchema(siteHeaderSpecSchema);
const orderedPrepareParameters=PREPARE_LAYOUT_V2_TOOL.parameters as any;
export const PREPARE_ORDERED_LAYOUT_TOOL=tool('prepare_layout',PREPARE_LAYOUT_V2_TOOL.description+' Submit header as data; leave the shared header template HTML/CSS empty. The platform compiles it.',{...orderedPrepareParameters,properties:{...orderedPrepareParameters.properties,header:headerParameter},required:[...orderedPrepareParameters.required,'header']});
const preparedOrderedLayoutSchema=preparedLayoutV2Schema.extend({header:siteHeaderSpecSchema});
// The compiler validates/normalizes nullable strict-tool options, retaining
// raw wire arguments here for deterministic replay identity.
const composeSiteSchema=z.object({files:preparedLayoutSchema.shape.files,composition:z.unknown(),header:siteHeaderSpecSchema.nullable(),artDirection:z.string().trim().min(1).max(600)}).strict();
export const COMPOSE_SITE_TOOL=tool('compose_site','Compile approved section patterns into real page layouts, then use the same saved-layout image batch. Submit the complete site structure and any custom page bodies in files; composition replaces only listed pages and optional shared footer. Use ONLY approvedPatternSnapshot exact variants and skins. IDs are unique across the site. Do not write pattern HTML/CSS yourself. The compiler chooses real frame geometry. Uploads first; planned media generate once within the shared site image budget. Supply header data when requested; otherwise null. No extra planning/model round.',{type:'object',properties:{files:(PREPARE_LAYOUT_V2_TOOL.parameters as any).properties.files,composition:siteCompositionJsonSchema,header:{anyOf:[headerParameter,{type:'null'}]},artDirection:{type:'string',minLength:1,maxLength:600}},required:['files','composition','header','artDirection'],additionalProperties:false});
function canComposeSite(w:{requirements_json:string;base_manifest_json:string|null;scope_json:string}){const r=JSON.parse(w.requirements_json);return !w.base_manifest_json&&JSON.parse(w.scope_json).kind==='site'&&r.siteCompositionVersion==='site-compose-1'&&r.approvedPatternSnapshot?.length>0;}
const composeSiteV2Schema=composeSiteSchema.extend({planHash:z.string().regex(/^[a-f0-9]{64}$/)});
export const COMPOSE_SITE_V2_TOOL=tool('compose_site_v2','Compile the frozen bnx-1 plan using approved components adapted from six public libraries. For componentSelection model-choice-1, independently choose the most suitable pattern/variant from each responsibility choices; recommended is optional. Consult catalog labels, sourceIds, layoutKey, capacity and preferredMedia. Older plans without componentSelection retain their assigned recommended variants. Submit every planned page with exact section IDs, ordered responsibilities and one preset. Do not repeat adjacent layouts or the previous actual site combination when alternatives exist. Page bodies and shared footer in files are empty; compiler writes them. Choose an approved shared footer, header spec when requested and shared image direction. The platform saves layout before images with existing billing. No raw HTML/CSS, invented facts, new fonts or separate model planning round.',{type:'object',properties:{files:(PREPARE_LAYOUT_V2_TOOL.parameters as any).properties.files,composition:siteCompositionV2JsonSchema,header:{anyOf:[headerParameter,{type:'null'}]},artDirection:{type:'string',minLength:1,maxLength:600},planHash:{type:'string',pattern:'^[a-f0-9]{64}$'}},required:['files','composition','header','artDirection','planHash'],additionalProperties:false});
function canComposeSiteV2(w:{requirements_json:string;base_manifest_json:string|null;scope_json:string}){const r=JSON.parse(w.requirements_json);return !w.base_manifest_json&&JSON.parse(w.scope_json).kind==='site'&&r.siteCompositionVersion==='site-compose-v2'&&r.designSystemV2?.version==='bnx-generation-1'&&r.designSystemV2.approvedSnapshot?.length>0;}
const orderedProposeParameters=WORKFLOW_TOOLS.find(t=>t.name==='propose_files')!.parameters as any;
export const PROPOSE_ORDERED_FILES_TOOL=tool('propose_files','Submit ordinary page files and a structured header for the first complete site. On later body edits use header:null. Never write the shared header HTML/CSS; set_site_header changes that data.',{...orderedProposeParameters,properties:{...orderedProposeParameters.properties,header:{anyOf:[headerParameter,{type:'null'}]}},required:[...orderedProposeParameters.required,'header']});
export const SET_SITE_HEADER_TOOL=tool('set_site_header','Change the structured shared header of this new candidate. It uses the existing CMS menu and verified logo assets; no images are regenerated.',{type:'object',properties:{header:headerParameter},required:['header'],additionalProperties:false});
const imageDispositionsSchema=z.object({images:z.array(z.object({frameId:z.string().regex(/^[a-z][a-z0-9-]{0,59}$/),reasonCode:z.enum(IMAGE_DISPOSITION_REASONS),reason:z.string().trim().min(10).max(300).refine(value=>!/[\u0000-\u001f\u007f]/u.test(value))}).strict()).min(1).max(8)}).strict();
const {$schema:_dispositionsSchemaDialect,...imageDispositionsParameter}=z.toJSONSchema(imageDispositionsSchema);
export const DISCARD_PREPARED_IMAGES_TOOL=tool('discard_prepared_images','Record an explicit reason to discard an unsuitable successfully generated image: wrong subject, unsupported claim, generation defect, redundancy or user request. A success receipt does not prove content is appropriate. This records intent only, without deleting media, regenerating images or changing charges. Then edit only the affected content and remove its bnf-image marker; preserve the original page and useful existing content, without invented facts. Otherwise keep the exact original image and frame. No silent replacement or move to another page. Failed images can already be removed without this tool.',imageDispositionsParameter);
function canDiscardPreparedImages(w:{scope_json:string;base_manifest_json:string|null;requirements_json:string;workspace_id?:string|null}){
 const requirements=JSON.parse(w.requirements_json),record=requirements.imageFramePlan;
 return !w.base_manifest_json&&!w.workspace_id&&JSON.parse(w.scope_json).kind==='site'&&requirements.imageCompletionPolicy===PREPARED_IMAGE_RETENTION_VERSION&&record?.status==='bound'&&record.retention?.version===PREPARED_IMAGE_RETENTION_VERSION&&record.retention.images?.length>0;
}
/** Offered only when the customer selected one block: the change is that block and nothing else. */
export const SELECTED_WORKFLOW_TOOL=tool('replace_selected','Replace ONLY the block the user selected with its new complete HTML (same root tag). The rest of the page, every other file and all stylesheets stay untouched. List project assets used by the new HTML in assets.',{type:'object',properties:{html:{type:'string',minLength:1,maxLength:200000},assets:{type:'array',maxItems:8,items:assetParameter}},required:['html','assets'],additionalProperties:false});
/** Find-and-replace inside one page file: the way to correct or adjust a design that already exists. */
export const EDIT_WORKFLOW_TOOL=tool('edit_file','Change parts of one existing template file by exact find-and-replace. Each find must be copied exactly from the file and occur exactly once. Use this to fix check issues or adjust an existing design instead of sending whole files again.',{type:'object',properties:{path:{type:'string',maxLength:100,description:'templates/<numeric-id>.html or templates/<numeric-id>.css'},edits:{type:'array',minItems:1,maxItems:12,items:{type:'object',properties:{find:{type:'string',minLength:1},replace:{type:'string'}},required:['find','replace'],additionalProperties:false}}},required:['path','edits'],additionalProperties:false});
async function directTools(env:Env,userId:string,w:{scope_json:string;base_manifest_json:string|null;requirements_json:string;coherenceReview?:{offered:boolean;pendingHash?:string}}){
 let selected=false;try{selected=!!w.base_manifest_json&&JSON.parse(w.scope_json)?.kind==='node';}catch{selected=false;}
 if(JSON.parse(w.requirements_json).renderReview)return [SELECTED_WORKFLOW_TOOL,COMPLETE_RENDER_REVIEW_TOOL,...WORKFLOW_TOOLS.filter(t=>['read_project','read_rules','list_files','read_file','check_preview','finish'].includes(t.name))];
 // A selected block needs no new illustration round and no whole-file tools beyond reading: its own tool comes first.
 if(selected)return [hasSelectedEditProtocol(w)?{...SELECTED_WORKFLOW_TOOL,description:SELECTED_WORKFLOW_TOOL.description+' CSS and ancestors are read-only context. Preserve confirmed fonts, bindings and links. A section restyle must change its non-media composition or text/action appearance, not just an image filter or unused class. Existing inline !important declarations may be replaced inside this exact span.'}:SELECTED_WORKFLOW_TOOL,...WORKFLOW_TOOLS];
 const ordered=hasCompiledHeaderPolicy(JSON.parse(w.requirements_json));
 const composed=JSON.parse(w.requirements_json).composedLayout;
 if(canComposeSiteGrammar(w)){const plan=JSON.parse(w.requirements_json).grammarPlan;return [...WORKFLOW_TOOLS.filter(t=>['read_project','read_rules','list_files','read_file','check_preview','finish'].includes(t.name)),...(!composed?[grammarComposeTool(plan)]:[])];}
 if(canComposeSiteV2(w))return [...WORKFLOW_TOOLS.filter(t=>['read_project','read_rules','list_files','read_file','check_preview','finish'].includes(t.name)),...(!composed?[COMPOSE_SITE_V2_TOOL]:[]),...(ordered?[SET_SITE_HEADER_TOOL]:[]),...(canDiscardPreparedImages(w)?[DISCARD_PREPARED_IMAGES_TOOL]:[])];
 const tools=[...WORKFLOW_TOOLS.map(t=>ordered&&t.name==='propose_files'?PROPOSE_ORDERED_FILES_TOOL:t),EDIT_WORKFLOW_TOOL,...(ordered?[SET_SITE_HEADER_TOOL]:[]),...(canDiscardPreparedImages(w)?[composed?{...DISCARD_PREPARED_IMAGES_TOOL,description:DISCARD_PREPARED_IMAGES_TOOL.description+' For compiler-owned frames the platform also removes that media subtree and preserves the compiled text/layout; do not hand-edit compiled templates.'}:DISCARD_PREPARED_IMAGES_TOOL]:[]),...(canComposeSite(w)?[COMPOSE_SITE_TOOL]:[])];
 if(w.coherenceReview?.offered||w.coherenceReview?.pendingHash)return tools;
 const imagePlan=JSON.parse(w.requirements_json).designBrief?.imagePlan;
 if(frameFirstV2(w)&&(imagePlan?.mode==='none'||imagePlan?.generation==='disabled'))return tools;
 try{const quote=await imageGenerationQuote(env,userId);return quote.available&&quote.canReserve?[...tools,ordered&&frameFirstV2(w)?PREPARE_ORDERED_LAYOUT_TOOL:frameFirstV2(w)?PREPARE_LAYOUT_V2_TOOL:frameFirst(w)?PREPARE_LAYOUT_TOOL:IMAGE_WORKFLOW_TOOL]:tools;}catch{return tools;}
}
const pathProperty={type:'string',maxLength:100};
export const PROJECTED_WORKFLOW_TOOLS=[
 tool('read_project','Read the immutable brief and the bounded workspace/file index.'),
 tool('read_rules','Read AACMS authoring and security rules.'),
 tool('list_files','Read the next file index page.',{type:'object',properties:{cursor:{type:'integer',minimum:0}},required:['cursor'],additionalProperties:false}),
 tool('read_fragment','Read at most 32 KiB of one virtual file. Use returned nextOffset and spanRef.',{type:'object',properties:{path:pathProperty,offset:{type:'integer',minimum:0}},required:['path','offset'],additionalProperties:false}),
 tool('find_text','Search at most 128 KiB for an exact literal; continue with nextOffset. Returns signed replacement spans.',{type:'object',properties:{path:pathProperty,query:{type:'string',minLength:1,maxLength:128},offset:{type:'integer',minimum:0}},required:['path','query','offset'],additionalProperties:false}),
 tool('propose_edits','Replace only returned exact spans in this workspace revision; no adoption or publication.',{type:'object',properties:{expectedRevision:{type:'integer',minimum:0},edits:{type:'array',minItems:1,maxItems:8,items:{type:'object',properties:{path:pathProperty,expectedSha:{type:'string'},spanRef:{type:'string'},replacement:{type:'string',maxLength:131072}},required:['path','expectedSha','spanRef','replacement'],additionalProperties:false}},mediaIds:{type:'array',maxItems:64,items:{type:'string'}}},required:['expectedRevision','edits','mediaIds'],additionalProperties:false}),
 tool('check_preview','Validate the current complete design, assets and original scope. This is not visual browser rendering.'),
 tool('finish','After successful check_preview of this revision, create a candidate for explicit user adoption.',finishParameters),
];
const RULES=DESIGN_AUTHORING_RULES;
function hasSelectedEditProtocol(w:{requirements_json:string}){return JSON.parse(w.requirements_json).selectedEditProtocol===SELECTED_EDIT_VERSION;}
function requiresExplicitSiteEditFinish(w:{requirements_json:string}){return JSON.parse(w.requirements_json).completionProtocol===SITE_EDIT_COMPLETION_VERSION;}
const selectedEditCheckCache=new WeakMap<object,{json:string;issues:ReturnType<typeof selectedEditIssues>}>();
function selectedWorkflowIssues(w:{requirements_json:string;base_manifest_json:string|null;scope_json:string},manifest:any){if(!w.base_manifest_json||!hasSelectedEditProtocol(w))return [];const json=stringify(manifest),cached=selectedEditCheckCache.get(w);if(cached?.json===json)return cached.issues;const requirements=JSON.parse(w.requirements_json),issues=selectedEditIssues(JSON.parse(w.base_manifest_json),manifest,JSON.parse(w.scope_json),requirements.selectedEditIntent==='restyle'?'restyle':'edit');selectedEditCheckCache.set(w,{json,issues});return issues;}
function workflowRules(w:{requirements_json:string}){const requirements=JSON.parse(w.requirements_json);const base=hasSelectedEditProtocol(w)&&typeof requirements.selectedEditRules==='string'?requirements.selectedEditRules:(hasSelectedEditProtocol(w)||hasCompiledHeaderPolicy(requirements)||requirements.designBrief?.version==='db-3'||requirements.typography)&&typeof requirements.authoringRules==='string'?requirements.authoringRules:RULES;return base+(requiresExplicitSiteEditFinish(w)?'\n'+(typeof requirements.completionRules==='string'?requirements.completionRules:SITE_EDIT_COMPLETION_RULES):'');}
function initialManifestJson(w:{requirements_json:string;base_manifest_json:string|null}){const foundation=foundationFromRequirements(w.requirements_json);return w.base_manifest_json??stringify(foundation?foundationAuthoringExample(foundation):example);}
function authoringRequirements(w:{requirements_json:string}){const {imageFramePlan,composedLayout,siteImageAllocation,siteOwnedImages:_ownedImageEvidence,authoringRules:_frozenRules,selectedEditRules:_selectedRules,completionRules:_completionRules,compiledHeader,...requirements}=JSON.parse(w.requirements_json),foundation=foundationFromRequirements(requirements);return {...requirements,...(requirements.designSystemV2&&!requirements.siteArt?{designSystemV2:{...requirements.designSystemV2,tokens:{...requirements.designSystemV2.tokens,colors:undefined}},compiledBodyPalette:undefined,paletteDecision:'本站配色尚未决定。preset 只决定字号、间距和圆角；foundation 里出现的颜色是占位值，不代表品牌，不得照抄。请在 composition.art 中按品牌与行业独立决定 mode、accent、neutral。'}:{}),...(requirements.sitePlan?{siteExecution:{instruction:'Every requested page needs its own template. Fulfill the frozen per-page visual minima within one shared image batch; optional home images cannot displace inner-page images. Only the offered compose_site or compose_site_v2 tool may create approved pattern markup. Compiler-owned templates are immutable within this generation.',...(siteImageAllocation?{allocation:siteImageAllocation}:{}),...(composedLayout?{composition:{version:composedLayout.version,receipts:composedLayout.receipts}}:{})}}:{}),...(compiledHeader?{header:{version:compiledHeader.version,templateId:compiledHeader.templateId,spec:compiledHeader.resolved?.spec,receipt:compiledHeader.receipt}}:{}),...(imageFramePlan?{imageFramePlan:{plan:imageFramePlan.plan,status:imageFramePlan.status,images:imageFramePlan.images}}:{}),...(foundation?{foundation:foundationAuthoringContext(foundation)}:{})};}
function authoringRules(w:{requirements_json:string;base_manifest_json:string|null}){const foundation=foundationFromRequirements(w.requirements_json);return {baseline:TEMPLATE_CONTRACT_BASELINE,rules:workflowRules(w),...(foundation?{foundation:foundationAuthoringContext(foundation),...(!w.base_manifest_json?{example:foundationAuthoringExample(foundation)}:{})}:w.base_manifest_json?{}:{example})};}
function files(source:any,foundation:DesignFoundation|null=null):Record<string,string>{const manifest=foundationAuthoringManifest(source,foundation),output:Record<string,string>=Object.create(null);output['manifest.json']=stringify(manifest);output['site.json']=stringify({...manifest,templates:(Array.isArray(manifest?.templates)?manifest.templates:[]).map((t:any)=>{const {document:_document,...meta}=t??{};return meta;})});for(const t of Array.isArray(manifest?.templates)?manifest.templates:[]){if(!t||!Number.isSafeInteger(t.id)||t.id<=0)continue;output[`templates/${t.id}.html`]=typeof t.document?.html==='string'?t.document.html:'';output[`templates/${t.id}.css`]=typeof t.document?.css==='string'?t.document.css:'';}return output;}
function virtualFile(manifest:unknown,path:string,foundation:DesignFoundation|null=null){const map=files(manifest,foundation);assert(Object.hasOwn(map,path),'WORKFLOW_PATH_DENIED','仅可读取当前模板虚拟文件');return map[path];}
type ToolResult={name:string;callId:string;result:any};
async function projectedTool(env:Env,w:Workflow,call:any):Promise<ToolResult>{
 const name=String(call.name??''),callId=String(call.call_id??'');assert(w.workspace_id,'EDIT_WORKSPACE_MISSING','任务缺少工作区',503);
 try{assert(PROJECTED_WORKFLOW_TOOLS.some(t=>t.name===name),'WORKFLOW_TOOL_DENIED','工具未开放');const args=JSON.parse(call.arguments);let result:any;
  if(name==='read_project'){z.object({}).strict().parse(args);result={ok:true,requirements:authoringRequirements(w),workspace:await editWorkspaceView(env,w.user_id,w.workspace_id),files:await listEditFiles(env,w.user_id,w.workspace_id)};}
  else if(name==='read_rules'){z.object({}).strict().parse(args);result={ok:true,baseline:TEMPLATE_CONTRACT_BASELINE,rules:requiresExplicitSiteEditFinish(w)?workflowRules(w):RULES};}
  else if(name==='list_files'){const a=z.object({cursor:z.number().int().min(0).max(216)}).strict().parse(args);result={ok:true,...await listEditFiles(env,w.user_id,w.workspace_id,a.cursor)};}
  else if(name==='read_fragment'){const a=z.object({path:z.string().max(100),offset:z.number().int().nonnegative()}).strict().parse(args);result={ok:true,...await readEditFragment(env,w.user_id,w.workspace_id,a.path,a.offset)};}
  else if(name==='find_text'){const a=z.object({path:z.string().max(100),query:z.string().min(1).max(128),offset:z.number().int().nonnegative()}).strict().parse(args);result={ok:true,...await findEditText(env,w.user_id,w.workspace_id,a.path,a.query,a.offset)};}
  else if(name==='propose_edits'){result=await patchEditWorkspace(env,w.user_id,w.workspace_id,{...args,requestKey:'tool:'+await sha256(w.id+':'+callId)});}
  else if(name==='check_preview'){z.object({}).strict().parse(args);result=await validateEditWorkspace(env,w.user_id,w.workspace_id);}
  else{finishArgs.parse(args);result=await finishEditWorkspace(env,w.user_id,w.workspace_id,w.id);w.candidate_id=result.candidateId;}
  assert(new TextEncoder().encode(JSON.stringify(result)).length<=131072,'WORKFLOW_TOOL_RESULT_LIMIT','工具投影过大，请读取更小片段',413);return {name,callId,result};
 }catch(error){if(!(error instanceof AppError)&&!(error instanceof z.ZodError))throw error;if(error instanceof AppError&&['DESIGN_MEMORY_BUSY','EDIT_WORKSPACE_BUSY','EDIT_OBJECT_UNCONFIRMED','EDIT_OBJECT_UNAVAILABLE'].includes(error.code))throw error;return {name,callId,result:{ok:false,code:error instanceof z.ZodError?'WORKFLOW_TOOL_ARGUMENTS':code(error),message:error instanceof AppError?error.message:'工具输入无效'}};}
}
async function receiptWorkspace(env:Env,w:Workflow){assert(w.workspace_id,'EDIT_WORKSPACE_MISSING','缺少工作区',503);const row=await env.DB.prepare('SELECT * FROM design_edit_workspaces WHERE id=? AND user_id=? AND project_id=?').bind(w.workspace_id,w.user_id,w.project_id).first<EditWorkspace>();assert(row,'EDIT_WORKSPACE_MISSING','缺少工作区',503);return row;}
async function storedReceipt(env:Env,w:Workflow,step:Step,kind:'response'|'tool'){
 const workspace=await receiptWorkspace(env,w),object=await recoverEditObject(env,workspace,kind+':'+step.id);return object?{id:object.id,value:JSON.parse(await readEditObject(env,workspace,object.id))}:null;
}
/** Checks a just-written design at once (message-started tasks only): the same checks as `check_preview`, with
 * the issues handed back in the writing tool's own result. A passing design is marked as checked. */
/** Format slips that have exactly one right answer are put right by the system instead of costing a round each.
 * The CMS package format needs at least two pages: a site whose customer asked for the home page only gets a small
 * contact page from the system, so the model designs one page and the package is still valid. */
export function repairManifest(manifest:any,requirements:any):string[]{
 const fixed:string[]=[],site=manifest?.site;if(!site||typeof site!=='object'||!Array.isArray(manifest.templates))return fixed;
 const theme=site.theme;
 if(theme&&typeof theme==='object'&&theme.font_family!==undefined&&!['system','serif','sans-serif'].includes(theme.font_family)){theme.font_family=/serif/i.test(String(theme.font_family))&&!/sans/i.test(String(theme.font_family))?'serif':'system';fixed.push('theme.font_family');}
 const pages:any[]=Array.isArray(site.pages)?site.pages:[];
 if(pages.length&&!pages.some(page=>page?.key===site.home)){site.home=pages[0]?.key;fixed.push('site.home');}
 if(pages.length===1&&pages[0]&&typeof pages[0]==='object'){
  const language=String(pages[0].seo?.language??site.settings?.site_language??'').toLowerCase().split(/[-_]/)[0];
  const translations:Record<string,[string,string]>={en:['Contact','Contact details to be added.'],ja:['お問い合わせ','連絡先情報は後日掲載します。'],ko:['문의','연락처 정보가 추가될 예정입니다.'],es:['Contacto','Los datos de contacto se añadirán próximamente.'],fr:['Contact','Les coordonnées seront ajoutées prochainement.'],de:['Kontakt','Die Kontaktdaten werden noch ergänzt.'],pt:['Contato','Os dados de contato serão adicionados em breve.'],it:['Contatti','I recapiti saranno aggiunti prossimamente.'],ru:['Контакты','Контактные данные будут добавлены позже.'],ar:['تواصل معنا','ستتم إضافة معلومات التواصل لاحقًا.'],id:['Kontak','Informasi kontak akan ditambahkan.'],th:['ติดต่อเรา','จะเพิ่มข้อมูลติดต่อในภายหลัง'],vi:['Liên hệ','Thông tin liên hệ sẽ được bổ sung.'],tr:['İletişim','İletişim bilgileri daha sonra eklenecektir.'],he:['יצירת קשר','פרטי יצירת הקשר יתווספו בהמשך.']};
  const requestText=String(requirements?.request??'');
  const english=[...requestText.matchAll(/网站语言：\s*English|英(?:文|语)(?:版)?(?:官网|网站|网页)|\b(?:english\s+(?:website|site)|(?:website|site)\s+in\s+english)\b/gi)].some(match=>!/(?:不要|不用|不做|无需|not\b|no\b|without\b)[^，,。.;；!?！？]*$/i.test(requestText.slice(Math.max(0,match.index!-40),match.index)));
  const [title,note]=translations[language]??(english?translations.en:['联系我们','联系方式待补充。']);
  const id=Math.max(0,...manifest.templates.map((t:any)=>Number.isSafeInteger(t?.id)?t.id:0))+1,key=pages[0].key==='contact'?'contact-us':'contact';
  manifest.templates.push({id,name:title,type:'page',document:{version:1,html:'<section class="benos-contact"'+(['ar','he','fa','ur'].includes(language)?' dir="rtl"':'')+'><div class="benos-contact-inner"><h1>'+title+'</h1><p>'+note+'</p></div></section>',css:'.benos-contact{padding:clamp(72px,10vw,128px) clamp(20px,5vw,64px)}.benos-contact-inner{max-width:720px;margin:0 auto}.benos-contact h1{margin:0 0 16px;font-size:clamp(32px,4vw,48px);line-height:1.15}.benos-contact p{margin:0;font-size:18px;line-height:1.7;opacity:.72}'},conditions:{all:false,pages:[],exclude_pages:[],types:[],categories:[]}});
  site.pages=[...pages,{key,title,slug:key,type:'page',template_id:id,seo:{title,description:note,schema_type:'WebPage',...(pages[0].seo?.language?{language:pages[0].seo.language}:{})},excerpt:note}];
  fixed.push('site.pages');
 }
 return fixed;
}
function repairNewSiteLinks(w:Workflow,manifest:any){
 if(!fromMessage(w)||w.base_version_id||w.base_manifest_json||w.workspace_id||JSON.parse(w.scope_json).kind!=='site')return {manifest,repairs:[]};
 return normalizeSharedFragmentLinks(manifest);
}
/** One local correction opportunity, reconstructed from committed tool receipts on resume.
 * This is advisory static analysis, never a visual score. Same-round check/finish calls
 * cannot bypass an outstanding suggestion; the next round may resolve or retain it.
 * No new provider call is made by the checker, and existing/quoted designs are untouched. */
async function coherenceCheck(env:Env,w:Workflow,manifest:any){
 const requirements=JSON.parse(w.requirements_json),foundation=foundationFromRequirements(requirements);
 if(!fromMessage(w)||w.base_version_id||w.base_manifest_json||w.workspace_id||JSON.parse(w.scope_json).kind!=='site'||foundation?.coherenceVersion!=='bnf-coherence-1')return null;
 let report:ReturnType<typeof diagnoseDesignCoherence>;
 try{report=diagnoseDesignCoherence(manifest,{blueprint:requirements.designBrief?.version==='db-3'?requirements.designBrief.pageBlueprint:undefined});}catch{return null;} // Optional diagnostics cannot invalidate a renderable design.
 const diagnostics=filterExplicitCoherenceIntent(report.diagnostics,[requirements.request,requirements.style].filter(Boolean).join('\n'));
 const state=w.coherenceReview??={offered:false},hash=await sha256(w.manifest_json);
 if(!diagnostics.length){delete state.pendingHash;return null;}
 // Compiler-owned layouts cannot be improved by asking the model to rewrite
 // their frozen HTML. Report observations without charging an impossible repair.
 if(requirements.composedLayout){delete state.pendingHash;return {status:'advisory',browserRendered:false,visualAcceptance:false,feedback:designCoherenceFeedback(diagnostics),diagnostics:diagnostics.map(item=>({code:item.code,locations:item.locations}))};}
 if(diagnostics.every(d=>['blueprint_depth_gap','auxiliary_text_overuse','unfinished_visual_placeholder'].includes(d.code))){delete state.pendingHash;return {status:'advisory',browserRendered:false,visualAcceptance:false,feedback:designCoherenceFeedback(diagnostics),diagnostics:diagnostics.map(item=>({code:item.code,locations:item.locations}))};}
 if(!state.offered&&!state.pendingHash){
  const [balance,wallet,history]=await Promise.all([totals(env,w.id),getWallet(env.DB,w.user_id),steps(env,w.id)]);
  // A useful structurally valid candidate must not be lost just because there
  // is no room for an optional aesthetic revision. Never reserve extra credit.
  const policy=workflowGenerationPolicy(w.requirements_json),images=policy?await workflowImageTotals(env,w):null;
  if(history.length>=stepLimit(w)||balance.consumed+balance.held+w.per_step_micros>w.max_cost_micros||wallet.availableMicros<w.per_step_micros||policy&&!canStartOptionalReview(policy,balance.consumed+(images?.consumed??0)))state.offered=true;
  else state.pendingHash=hash;
 }
 return {status:state.pendingHash?'revision_requested':'advisory',browserRendered:false,visualAcceptance:false,feedback:designCoherenceFeedback(diagnostics),diagnostics:diagnostics.map(item=>({code:item.code,locations:item.locations}))};
}
function coherenceWasOffered(history:Step[]){
 return history.some(step=>{if(step.state!=='completed'||!step.tool_results_json)return false;try{return JSON.parse(step.tool_results_json).some((tool:any)=>(tool.result?.check?.designReview??tool.result?.designReview)?.status==='revision_requested');}catch{return false;}});
}
async function saveCoherenceFallback(env:Env,w:Workflow){
 if(requiresExplicitSiteEditFinish(w))return false;
 if(!w.coherenceReview?.offered||w.workspace_id||w.candidate_id)return false;
 await executeTool(env,w,{name:'check_preview',call_id:'local-coherence-check',arguments:'{}'});
 if(w.validated_hash!==await sha256(w.manifest_json))return false;
 await executeTool(env,w,{name:'finish',call_id:'local-coherence-finish',arguments:'{}'});
 if(!w.candidate_id)return false;
 await env.DB.prepare("UPDATE ai_workflows SET candidate_id=?,validated_hash=?,state='succeeded',error_code=NULL,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?").bind(w.candidate_id,w.validated_hash,new Date().toISOString(),w.id,w.lease_token).run();
 return true;
}
async function materializeWorkflowDesign(w:Workflow,manifest:any){
 const requirements=JSON.parse(w.requirements_json),foundation=foundationFromRequirements(requirements);
 manifest=materializeDesignFoundation(manifest,foundation);
 manifest=materializeCompiledBodyPalette(manifest,requirements);
 if(hasCompiledHeaderPolicy(requirements)){
  assert(requirements.compiledHeader,'HEADER_DATA_REQUIRED','请通过 header 提交页头数据；平台负责生成页头结构');
  const cssIssues=headerCssIsolationIssues(manifest,requirements.compiledHeader);
  assert(!cssIssues.length,'HEADER_STYLE_OWNERSHIP',cssIssues.map(issue=>issue.message).join('\n'));
  manifest=materializeFrozenHeader(manifest,requirements.compiledHeader);
  // Reviewed native components already own geometry and palette. Legacy
  // normalization injects inline !important colors from a different foundation
  // and can make a dark component's secondary action unreadable. This policy is
  // frozen by the server and inherited through verified version provenance;
  // author-supplied classes never grant this exemption. Old tasks stay unchanged.
  if(requirements.compiledBodyPolicy!=='bnx-owned-1')manifest=materializeDesignOrder(manifest,requirements.designOrder).manifest;
 }
 if(requirements.compiledBodyPolicy!=='bnx-owned-1'&&requirements.layoutReviewVersion===LAYOUT_REVIEW_VERSION&&!w.base_manifest_json&&!w.workspace_id&&JSON.parse(w.scope_json).kind==='site'&&requirements.designOrder?.layoutMode!=='experimental')manifest=reviewHeroLayout(manifest).manifest;
 if(JSON.parse(w.requirements_json).mobileNavigation===MOBILE_NAV_VERSION){
  const mobile=materializeMobileHeaderNavigation(manifest);
  assert(!mobile.issues.length,'MOBILE_NAV_REQUIRED',mobileNavigationFeedback(mobile.issues));manifest=mobile.manifest;
 }
 manifest=materializeSiteRenderCompatibility(manifest,requirements.siteLayoutCompatibilityVersion);
 manifest=requirements.typography?enforceTypographySnapshot(manifest,typographySnapshotSchema.parse(requirements.typography)):manifest;
 return w.base_manifest_json?(await preserveSiteCompositionV2Notices(JSON.parse(w.base_manifest_json),manifest)).manifest:manifest;
}
async function preparedDesignIssues(w:Workflow,manifest:any){
 // An untouched authoring example can pass a structural check but can never be
 // saved as a candidate. Do not mistake it for a generated mobile header.
 if(w.manifest_json===initialManifestJson(w))return [];
 const requirements=JSON.parse(w.requirements_json),issues:{code:string;message:string}[]=[];
 if(requirements.sitePlan){
  issues.push(...validateSitePlanManifest(manifest,requirements.sitePlan).issues.filter(issue=>issue.severity==='error'));
  if(!requirements.siteImageAllocation)issues.push({code:'SITE_IMAGES_NOT_PLANNED',message:'整站图片落位尚未通过检查，请完整提交各页内容。'});
  else issues.push(...siteImageCompletion(requirements,manifest).issues.filter(issue=>issue.severity==='error'));
 }
 if(requirements.siteCompositionVersion===GRAMMAR_PIPELINE_VERSION)issues.push(...validateGrammarComposition(manifest,requirements.composedLayout?.snapshot??null));
 if(['site-compose-1','site-compose-v2'].includes(requirements.siteCompositionVersion))issues.push(...validateWorkflowSiteComposition(manifest,await readCompositionSnapshot(requirements.composedLayout),requirements.siteCompositionVersion));
 if(requirements.componentContract==='bnx-1'&&requirements.siteCompositionVersion!=='site-compose-v2')issues.push(...validateSiteCompositionV2(manifest,null));
 if(hasCompiledHeaderPolicy(requirements)){
  const snapshot=requirements.compiledHeader,header=manifest.templates?.find((template:any)=>template.id===snapshot?.templateId),projected=snapshot?projectCompiledHeaderTypography(snapshot,requirements.typography?typographySnapshotSchema.parse(requirements.typography):null):snapshot;
  if(!snapshot||manifest.site?.header_template_id!==snapshot.templateId||manifest.site?.navigation_menu_id!==snapshot.resolved.menuId||header?.type!=='header'||header.document?.html!==projected.html||header.document?.css!==projected.css||header.document?.customCss)issues.push({code:'HEADER_SNAPSHOT_MISMATCH',message:'页头必须与平台编译快照一致，请使用结构化页头工具修改。'});
  issues.push(...materializeDesignOrder(manifest,requirements.designOrder).issues);
 }
 if(requirements.mobileNavigation===MOBILE_NAV_VERSION)issues.push(...validateMobileHeaderNavigation(manifest));
 if(requirements.imageFramePlan?.plan){
  const record=requirements.imageFramePlan,retain=requirements.imageCompletionPolicy===PREPARED_IMAGE_RETENTION_VERSION;
  if(retain&&record.status==='bound'&&!record.retention)issues.push({code:'IMAGE_RETENTION_REQUIRED',message:'成功图片的归属记录缺失，不能确认图片完整性。请恢复原记录，不重新生成图片。'});
  else issues.push(...validatePreparedImageCompletion(manifest,record.plan,retain?record.retention:undefined,retain?record.dispositions:undefined));
 }
 else if(frameFirst(w)&&(manifest.templates??[]).some((t:any)=>/\bid\s*=\s*["']bnf-image-/i.test(t.document?.html??'')))issues.push({code:'IMAGE_LAYOUT_REQUIRED',message:'图框尚未保存生图计划；请用 prepare_layout 提交布局和对应图片任务。无图片方案请删除空图框。'});
 return issues;
}
function siteImageCompletion(requirements:any,manifest:any){const record=requirements.imageFramePlan;return checkSiteImageAllocation({manifest,sitePlan:requirements.sitePlan,allocation:requirements.siteImageAllocation,ownedImages:requirements.siteOwnedImages??[],framePlan:record?.plan,receipts:record?.images,retention:record?.retention,dispositions:record?.dispositions});}
/** Charge-free preflight. Explicit pages and their image responsibility are
 * checked before the batch is persisted or any provider reservation is made. */
async function prepareWorkflowSitePlan(env:Env,w:Workflow,manifest:any,framePlan?:ImageFramePlan){
 const requirements=JSON.parse(w.requirements_json);if(!requirements.sitePlan)return;
 if(!requirements.composedLayout){const forged=validateWorkflowSiteComposition(manifest,null);assert(!forged.length,'SITE_COMPOSITION_REQUIRED','平台模式必须通过已批准的组合式工具提交，不能手写模式标记。');}
 const pageCheck=validateSitePlanManifest(manifest,requirements.sitePlan),errors=pageCheck.issues.filter(issue=>issue.severity==='error');
 assert(!errors.length,'SITE_PLAN_INVALID',errors.map(issue=>issue.message).join('\n').slice(0,1800));
 if(requirements.siteImageAllocation)return; // Recovery retains the original mapping and exceptions.
 let unavailable=false;
 if(!framePlan?.frames.length&&requirements.sitePlan.imageBudget.generation!=='disabled'){
  try{const quote=await imageGenerationQuote(env,w.user_id);unavailable=!quote.available||!quote.canReserve;}catch{unavailable=true;}
 }
 const allocation=prepareSiteImageAllocation({manifest,sitePlan:requirements.sitePlan,framePlan,ownedImages:requirements.siteOwnedImages??[],maxImages:requirements.generationPolicy?.maxImages??8,serverGenerationUnavailable:unavailable});
 const allocationErrors=allocation.issues.filter(issue=>issue.severity==='error');
 assert(!allocationErrors.length&&allocation.allocation,'SITE_IMAGE_ALLOCATION_INVALID',allocationErrors.map(issue=>issue.message).join('\n').slice(0,1800)||'整站图片计划无效');
 requirements.siteImageAllocation=allocation.allocation;w.requirements_json=boundedJson(requirements);
}
function validateWorkflowSiteComposition(manifest:any,snapshot:any,version?:string){return (snapshot?.version??version)==='site-compose-v2'?validateSiteCompositionV2(manifest,snapshot):validateSiteComposition(manifest,snapshot);}
/** The frozen forward manifest already contains these exact pre-image bytes.
 * Store them once; recovery hydrates from that saved manifest, never the newer renderer. */
function compactV2SourceSnapshot(snapshot:any){return {...snapshot,templateBytes:'forward-manifest-1',templates:snapshot.templates.map(({html:_html,css:_css,...template}:any)=>template)};}
async function workflowSourceSnapshot(record:any){
 const snapshot=record.sourceSnapshot;if(record.snapshotStorage!==undefined)assert(snapshot?.version==='site-compose-v2'&&snapshot?.templateBytes==='forward-manifest-1'&&Array.isArray(snapshot.templates),'BNX_FROZEN_MANIFEST_UNAVAILABLE','原始组件布局引用不完整，不重新生成图片',409);if(snapshot?.templateBytes!=='forward-manifest-1')return snapshot;
 const manifest=record.snapshotStorage===undefined?JSON.parse(record.forwardArgs.files[0].content):await readCompositionForwardManifest(record),{templateBytes:_codec,...metadata}=snapshot;
 return {...metadata,templates:snapshot.templates.map((template:any)=>{const original=manifest.templates.find((entry:any)=>entry.id===template.templateId);assert(original?.document&&typeof original.document.html==='string','BNX_FROZEN_MANIFEST_UNAVAILABLE','原始组件布局缺失，不重新生成图片',409);return {...template,html:original.document.html,css:original.document.css??''};})};
}
function freezeWorkflowSiteComposition(manifest:any,snapshot:any){if(snapshot?.version===GRAMMAR_PIPELINE_VERSION)return freezeGrammarComposition(manifest,snapshot as GrammarSnapshot);return snapshot?.version==='site-compose-v2'?freezeSiteCompositionV2(manifest,snapshot):freezeSiteComposition(manifest,snapshot);}
function finalizeWorkflowSiteCompositionImages(manifest:any,snapshot:any,options:{failedFrameIds:string[];discardedFrameIds?:string[]}){return snapshot?.version==='site-compose-v2'?finalizeSiteCompositionV2Images(manifest,snapshot,options):finalizeSiteCompositionImages(manifest,snapshot,options);}
async function freezeWorkflowComposition(w:Workflow,manifest:any){const requirements=JSON.parse(w.requirements_json);if(requirements.composedLayout){const record=requirements.composedLayout;record.snapshot=await storeCompositionSnapshot(record,freezeWorkflowSiteComposition(manifest,await readCompositionSnapshot(record)));w.requirements_json=boundedJson(requirements);}}
function imageOmissionResult(w:{requirements_json:string;manifest_json:string}):{imageOmissions?:ReturnType<typeof preparedImageOmissions>;sitePlanning?:unknown}{
 const requirements=JSON.parse(w.requirements_json),record=requirements.imageFramePlan;
 const manifest=JSON.parse(w.manifest_json),site= requirements.sitePlan?{sitePlanning:{version:requirements.sitePlan.version,pages:validateSitePlanManifest(manifest,requirements.sitePlan),images:requirements.siteImageAllocation?siteImageCompletion(requirements,manifest):{coverage:[],issues:[]},patternReceipts:requirements.composedLayout?.receipts??[],browserRendered:false}}:{};
 if(requirements.imageCompletionPolicy!==PREPARED_IMAGE_RETENTION_VERSION)return site;
 return {...site,imageOmissions:record?.retention&&record.dispositions?preparedImageOmissions(manifest,record.plan,record.retention,record.dispositions):[]};
}
/** The exact validated scaffold is committed before the first billable image.
 * Retried tool receipts reuse its immutable argument hash and image request keys. */
async function persistPreparedLayout(env:Env,w:Workflow,stage:'prepared'|'bound'){
 assert(w.activeStepId,'WORKFLOW_STEP_MISSING','生成步骤缺失',409);
 const guard=id('guard'),now=new Date().toISOString(),draft=JSON.stringify([{path:'manifest.json',content:w.manifest_json}]);
 const progress=JSON.stringify({seq:Date.now(),text:stage==='prepared'?'页面布局已确定，正在按图框生成图片。':'图片已填入对应图框，正在检查页面。',tool:stage==='prepared'?'generate_frame_images':'prepare_layout',chars:w.manifest_json.length,preview:true,page:null});
 await env.DB.batch([
  env.DB.prepare("INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM ai_workflows WHERE id=? AND lease_token=? AND state='processing' AND lease_until_ms>"+editNowSql+") THEN 1 ELSE 0 END").bind(guard,w.id,w.lease_token),
  env.DB.prepare('UPDATE ai_workflows SET manifest_json=?,requirements_json=?,validated_hash=NULL,updated_at=? WHERE id=?').bind(w.manifest_json,w.requirements_json,now,w.id),
  env.DB.prepare("UPDATE ai_workflow_steps SET progress_json=?,progress_draft=? WHERE id=? AND workflow_id=? AND state='responded'").bind(progress,draft,w.activeStepId,w.id),
  env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
 ]);
}
async function writtenCheck(env:Env,w:Workflow,manifest:any){
 if(!fromMessage(w))return {requiresPreviewCheck:true};
 const validation=validateSiteManifest(manifest),issues:{code?:string;path?:string;message:string}[]=[...validation.issues.filter((issue:any)=>issue.severity!=='warning').slice(0,20),...await preparedDesignIssues(w,manifest),...selectedWorkflowIssues(w,manifest)];
 if(validation.valid){try{await verifyProjectAssets(env,w.user_id,w.project_id,manifest);}catch(error){if(!(error instanceof AppError))throw error;issues.push({code:error.code,message:error.message});}}
 const structurePassed=validation.valid&&!issues.length,designReview=structurePassed?await coherenceCheck(env,w,manifest):null;
 const passed=structurePassed&&designReview?.status!=='revision_requested';
 w.validated_hash=passed?await sha256(w.manifest_json):null;
 return {...imageOmissionResult(w),check:{passed,issues,...(designReview?{designReview}:{})},next:designReview?.status==='revision_requested'?'Structure and assets passed. Make one targeted coherence revision using the feedback, only in the affected HTML/CSS. Preserve content, links and assets; do not redraw the whole site or generate more images just for this review. This is the only advisory correction opportunity.':passed?requiresExplicitSiteEditFinish(w)?'This write passed static checks; no candidate has been saved. Complete every part of the current user request across the affected pages/files, reusing existing assets as requested. Call finish explicitly only after all requested edits are complete and the latest checks pass.':hasSelectedEditProtocol(w)?'The block passed static checks. Candidate saving is still pending; do not claim it is saved until finalization succeeds.':'The design passed the check and is saved as the proposal.':'Fix exactly these issues in the next step by submitting only the affected file or block. Do not rewrite what already passed.'};
}
async function executeTool(env:Env,w:Workflow,call:any):Promise<ToolResult>{
 if(w.workspace_id)return projectedTool(env,w,call);
 const originalName=String(call.name??''),callId=String(call.call_id??''),beforeRequirements=w.requirements_json,beforeManifest=w.manifest_json;let name=originalName;
 try{
  const ordered=hasCompiledHeaderPolicy(JSON.parse(w.requirements_json));
  const renderReview=JSON.parse(w.requirements_json).renderReview;
  if(renderReview)assert(['replace_selected','complete_render_review','read_project','read_rules','list_files','read_file','check_preview','finish'].includes(name),'RENDER_REVIEW_TOOL_DENIED','审查只能调整所选区块并复用原图',422);
  if(canComposeSiteV2(w))assert(['read_project','read_rules','list_files','read_file','check_preview','finish','compose_site_v2','set_site_header','discard_prepared_images'].includes(name),'BNX_STRUCTURED_COMPOSITION_REQUIRED','本任务使用已确认组件，请通过结构化组合提交页面',422);
  if(canComposeSiteGrammar(w))assert(['read_project','read_rules','list_files','read_file','check_preview','finish','compose_site_grammar'].includes(name),'GRAMMAR_STRUCTURED_COMPOSITION_REQUIRED','本任务使用版式语法，请通过结构化组合提交页面',422);
  assert(name===COMPLETE_RENDER_REVIEW_TOOL.name&&renderReview||name===PREPARE_LAYOUT_TOOL.name||name===IMAGE_WORKFLOW_TOOL.name||name===SELECTED_WORKFLOW_TOOL.name||name===EDIT_WORKFLOW_TOOL.name||name===COMPOSE_SITE_TOOL.name&&canComposeSite(w)||name===COMPOSE_SITE_V2_TOOL.name&&canComposeSiteV2(w)||name==='compose_site_grammar'&&canComposeSiteGrammar(w)||name===DISCARD_PREPARED_IMAGES_TOOL.name&&canDiscardPreparedImages(w)||ordered&&name===SET_SITE_HEADER_TOOL.name||WORKFLOW_TOOLS.some(t=>t.name===name),'WORKFLOW_TOOL_DENIED','工具未开放');
  let args=JSON.parse(call.arguments);const foundation=foundationFromRequirements(w.requirements_json);let manifest=JSON.parse(w.manifest_json),result:any={ok:true};
  if(name==='complete_render_review'){
   const review=z.object({verdict:z.enum(['no_change','needs_attention']),summary:z.string().trim().min(1).max(600)}).strict().parse(args);
   assert(w.manifest_json===initialManifestJson(w)&&!w.candidate_id,'RENDER_REVIEW_CHANGED','已有修改，请检查并保存候选，不能按未修改结束',409);
   const requirements=JSON.parse(w.requirements_json);requirements.renderReviewOutcome={...review,sourceHash:renderReview.sourceHash,evidence:'client-sandbox-render',browserRechecked:false};w.requirements_json=boundedJson(requirements);
   result={ok:true,reviewCompleted:true,...review,candidateId:null,changed:false,browserRendered:false,visualAcceptance:false};
  }else if(name==='compose_site_grammar'){
   const requirements=JSON.parse(w.requirements_json),plan=requirements.grammarPlan as GrammarWorkflowPlan|null;
   assert(plan,'GRAMMAR_PLAN_MISSING','本次任务缺少已冻结的设计计划，请重新开始',409);
   const inputHash=await sha256(JSON.stringify(args)),prior=requirements.composedLayout;
   assert(!prior||prior.callId===callId&&prior.inputHash===inputHash,'GRAMMAR_COMPOSITION_ALREADY_PREPARED','组合布局已保存，请调整现有内容，不重新提交整站',409);
   assert(prior||w.manifest_json===initialManifestJson(w),'WORKFLOW_REWRITE_DENIED','已有完整设计，不能重新组合整站',409);
   if(prior){name=prior.forwardName;args=prior.forwardArgs;}
   else{
     const compiled=await compileGrammarPackage(env,plan,args,{assets:requirements.grammarAssets??[],siteName:requirements.grammarSiteName??'Site',siteSlug:requirements.grammarSiteSlug??'site'});
     if(!compiled.ok)throw new AppError(compiled.code,compiled.message,422);
     // Pictures the page asked for are generated now, with the same pipeline (and billing) as the
     // composition engine, then written into the frames the compiler reserved for them.
     let manifest=compiled.package.manifest,bound:string[]=[],imageFailures:{frameId:string;code:string}[]=[];
     const requested=compiled.package.images??[];
     if(requested.length){
      let imageQuote:{available?:boolean;canReserve?:boolean}|null=null;
      try{imageQuote=await imageGenerationQuote(env,w.user_id);}catch{imageQuote={available:false,canReserve:false};}
      if(imageQuote?.available&&imageQuote.canReserve){
       const prefix='gfimg_'+(await sha256(w.id)).slice(0,20)+'_',keys=await Promise.all(requested.map((_entry:{frameId:string;prompt:string},index:number)=>sha256(callId+':'+index).then(hash=>prefix+hash.slice(0,24))));
       const hold=()=>env.DB.prepare('UPDATE ai_workflows SET lease_until_ms=? WHERE id=? AND lease_token=?').bind(Date.now()+LEASE_MS,w.id,w.lease_token).run();
       await hold();
       const jobs=await Promise.allSettled(requested.map((entry:{frameId:string;prompt:string},index:number)=>createImageGeneration(env,w.user_id,w.project_id,{prompt:entry.prompt,requestKey:keys[index]})));
       await hold();
       const media=await listMedia(env,w.user_id,w.project_id),available=workflowAvailableAssets(media,(manifest.assets as Array<{file:string;path:string;sha256:string;size:number}>|undefined)??[]);
       const bindings:Array<{frameId:string;src:string;width:number;height:number;asset:{path:string;file:string;sha256:string;size:number}}>=[];
       jobs.forEach((job,index:number)=>{const frameId=requested[index].frameId;
        if(job.status!=='fulfilled'||job.value.state!=='succeeded'||!job.value.result_media_id){imageFailures.push({frameId,code:job.status==='fulfilled'?job.value.error_code??'IMAGE_UNAVAILABLE':code(job.reason)});return;}
        const item=workflowMediaAsset(media,available,job.value.result_media_id);
        if(!item||!item.width||!item.height){imageFailures.push({frameId,code:'IMAGE_UNAVAILABLE'});return;}
        bindings.push({frameId,src:item.asset.path,width:item.width,height:item.height,asset:item.asset});});
       if(bindings.length){const boundResult=bindGrammarImages(manifest,bindings);manifest=boundResult.manifest;bound=boundResult.bound;for(const frameId of boundResult.missing)imageFailures.push({frameId,code:'IMAGE_FRAME_MISSING'});}
      }else{for(const entry of requested as Array<{frameId:string}>)imageFailures.push({frameId:entry.frameId,code:'IMAGE_GENERATION_UNAVAILABLE'});}
     }
     // A picture that failed to generate leaves its frame empty: refuse, and let the model retry.
     if(imageFailures.length&&requested.length)throw new AppError('GRAMMAR_IMAGE_GENERATION_FAILED','配图生成失败：'+imageFailures.map(failure=>failure.frameId+' '+failure.code).join('、')+'；请去掉这些图位，或改用版式说明',422);
     name='propose_files';
     args={files:[{path:'manifest.json',content:boundedJson(manifest)}]};
     requirements.composedLayout={version:GRAMMAR_PIPELINE_VERSION,callId,inputHash,forwardName:name,forwardArgs:args,snapshot:freezeGrammarComposition(manifest,grammarSnapshot(manifest)),frames:compiled.package.frames,manifestDigest:await sha256(JSON.stringify(manifest)),images:{requested:requested.length,bound,failures:imageFailures}};
     requirements.grammarReceipt={pages:compiled.package.pages,stats:compiled.package.stats,identity:GRAMMAR_IDENTITY.digest,images:{requested:requested.length,bound,failures:imageFailures}};
     w.requirements_json=boundedJson(requirements);
   }
  }else if(name==='compose_site'||name==='compose_site_v2'){
   const isV2=name==='compose_site_v2',input=isV2?composeSiteV2Schema.parse(args):composeSiteSchema.parse(args),requirements=JSON.parse(w.requirements_json),prior=requirements.composedLayout,inputHash=await sha256(JSON.stringify(input));
   assert(!prior||prior.callId===callId&&prior.inputHash===inputHash,'SITE_COMPOSITION_ALREADY_PREPARED','组合布局已保存，请调整现有内容，不重新提交整站',409);
   assert(prior||w.manifest_json===initialManifestJson(w),'WORKFLOW_REWRITE_DENIED','已有完整设计，不能重新组合整站',409);
   if(prior){if(prior.snapshotStorage!==undefined){const original=await readCompositionForwardManifest(prior),source=await workflowSourceSnapshot(prior);await readCompositionSnapshot(prior);assert(!validateSiteCompositionV2(original,source).length,'BNX_FROZEN_MANIFEST_UNAVAILABLE','原始组件布局引用不完整，不重新生成图片',409);}name=prior.forwardName;args=prior.forwardArgs;}
   else{
    const base=JSON.parse(input.files[0].content);
    let composed:Awaited<ReturnType<typeof compileSiteComposition>>|Awaited<ReturnType<typeof compileSiteCompositionV2>>;
    let selection:Awaited<ReturnType<typeof assertV2ProductionPlan>>|undefined;
    try{
     const ownedAssets=(requirements.siteOwnedImages??[]).filter((asset:any)=>asset.source!=='unknown');
     if(isV2){const composition=parseSiteCompositionV2(input.composition);
      // Contact links are authoritative server values: whatever the model typed, the confirmed label and link are used.
      const confirmed:Array<{factRef:string;label:string;href:string}>=requirements.designSystemV2?.verifiedContent?.contacts??[];
      for(const section of [...composition.pages.flatMap(page=>page.composition.sections),...(composition.footer?[composition.footer.section]:[])])section.content.contact=section.content.contact.flatMap(entry=>{const fact=confirmed.find(value=>value.factRef===entry.factRef);return fact?[{...entry,label:fact.label,href:fact.href}]:[];});assertV2ManifestSkeleton(requirements.designSystemV2,composition,base,JSON.parse(initialManifestJson(w)));repairManifest(base,requirements);selection=await assertV2ProductionPlan(requirements.designSystemV2,(input as z.infer<typeof composeSiteV2Schema>).planHash,composition,ownedAssets);composed=await compileSiteCompositionV2(composition,base,{approvedSnapshot:requirements.designSystemV2.approvedSnapshot,ownedAssets,verifiedFactRefs:confirmed.map(value=>value.factRef)});}
     else {repairManifest(base,requirements);composed=await compileSiteComposition(input.composition,base,{approvedSnapshot:requirements.approvedPatternSnapshot,ownedAssets,verifiedFactRefs:[]});}
    }
    catch(error){if(error instanceof Error&&/^(?:BNX|PATTERN|SITE_COMPOSITION)_[A-Z_]+$/.test(error.message))throw new AppError(error.message,'组合数据未通过编译（'+error.message+'）。请核对已批准模式、页面映射、素材和内容数量。',422);throw error;}
    const failures=composed.issues.filter((issue:any)=>issue.severity==='error');assert(!failures.length,'SITE_COMPOSITION_INVALID',failures.map((issue:any)=>issue.message).join('\n').slice(0,1800));
    const images=composed.frames.map(frame=>({id:frame.id,sectionId:frame.sectionId,layout:'Approved '+composed.receipts.find(receipt=>receipt.sectionId===frame.sectionId)?.variantId+' composition',purpose:frame.purpose,prompt:frame.prompt,alt:frame.alt,slot:frame.slot,subjectPolicy:frame.subjectPolicy,framePolicy:frame.framePolicy,presentation:frame.presentation}));
    assert(images.length<=(requirements.generationPolicy?.maxImages??8),'WORKFLOW_IMAGE_LIMIT','组合式页面共用整站图片上限，请优先复用已有素材');
    name=images.length?'prepare_layout':'propose_files';
    args={files:[{path:'manifest.json',content:boundedJson(composed.manifest)}],...(images.length?{images,artDirection:input.artDirection}:{}),...(ordered?{header:input.header}:{})};
    // The header and page foundation follow the palette the model chose for this brand.
    const art=isV2?(input.composition as any)?.art:null;
    if(art&&requirements.compiledBodyPalette){requirements.compiledBodyPalette={preset:requirements.compiledBodyPalette.preset,colors:v2ArtColors(art)};requirements.siteArt=art;}
    requirements.composedLayout={version:isV2?'site-compose-v2':'site-compose-1',callId,inputHash,forwardName:name,forwardArgs:args,...(selection?{selection}:{}),sourceSnapshot:isV2?compactV2SourceSnapshot(composed.snapshot):composed.snapshot,snapshot:composed.snapshot,receipts:composed.receipts};if(isV2)requirements.composedLayout=await initializeV2SnapshotStorage(requirements.composedLayout);w.requirements_json=boundedJson(requirements);
   }
  }
  if(name==='read_project'){z.object({}).strict().parse(args);result={ok:true,requirements:authoringRequirements(w),nodes:describeDesignNodes(manifest)};}
  else if(name==='read_rules'){z.object({}).strict().parse(args);result={ok:true,...authoringRules(w)};}
  else if(name==='list_files'){z.object({}).strict().parse(args);result={ok:true,files:Object.entries(files(manifest,foundation)).map(([path,content])=>({path,characters:content.length}))};}
  else if(name==='read_file'){const a=z.object({path:z.string().max(100)}).strict().parse(args);result={ok:true,path:a.path,content:virtualFile(manifest,a.path,foundation)};}
  else if(name==='propose_files'){
   const schema=z.object({files:z.array(z.object({path:z.string().max(100),content:z.string().max(MAX_JSON_BYTES)}).strict()).min(1).max(8)}).strict();
   const a=ordered?schema.extend({header:siteHeaderSpecSchema.nullable()}).parse(args):schema.parse(args);
   assert(new Set(a.files.map(f=>f.path)).size===a.files.length,'WORKFLOW_PATH_DENIED','一次修改不得重复文件路径');
   assert(!a.files.some(f=>f.path==='manifest.json')||a.files.length===1,'WORKFLOW_PATH_DENIED','整包修改不能与局部文件修改混合');
   for(const f of a.files){virtualFile(manifest,f.path);
    if(f.path==='manifest.json'){
     // A complete design that is already written is corrected, never written again from the top: the customer
     // watched it being built, and a second full pass would throw that work away.
     assert(!(fromMessage(w)&&w.manifest_json!==initialManifestJson(w)),'WORKFLOW_REWRITE_DENIED','完整设计已经写好，不能整站重写。请用 edit_file 修改页面中的片段，或只提交需要改动的 templates/<id>.html、templates/<id>.css 或 site.json',409);
     manifest=JSON.parse(f.content);
    }else if(f.path==='site.json'){
     // Structure only: pages, menus, forms, assets and the list of templates. Page bodies stay where they are; a
     // template that is new here starts empty and gets its files in the same or a later call.
     const next=JSON.parse(f.content),bodies=new Map((manifest.templates??[]).map((t:any)=>[t.id,t.document]));
     assert(next&&typeof next==='object'&&!Array.isArray(next),'WORKFLOW_PATH_DENIED','site.json 必须是一个对象');
     // Only the site object, or a structure without its template list, keeps the templates that exist.
     const structure=Array.isArray(next.pages)&&next.site===undefined?{...manifest,site:next}:{...manifest,...next},listed=Array.isArray(next.templates)?next.templates:(manifest.templates??[]).map((t:any)=>{const {document:_document,...meta}=t??{};return meta;});
     manifest={...structure,templates:listed.map((meta:any)=>({...meta,document:bodies.get(meta?.id)??{version:1,html:'',css:''}}))};
    }else{const match=/^templates\/(\d+)\.(html|css)$/.exec(f.path);assert(match,'WORKFLOW_PATH_DENIED','文件路径未开放');const t=manifest.templates.find((t:any)=>t.id===Number(match[1]));assert(t,'WORKFLOW_PATH_DENIED','模板不存在');t.document[match[2]]=f.content;}}
   const repaired=fromMessage(w)&&!w.base_manifest_json?repairManifest(manifest,JSON.parse(w.requirements_json)):[];
   const links=repairNewSiteLinks(w,manifest);manifest=links.manifest;if(links.repairs.length)repaired.push('shared_fragment_links');
   if(ordered){const requirements=JSON.parse(w.requirements_json),header='header' in a?a.header:null;
    assert(requirements.compiledHeader||header,'HEADER_DATA_REQUIRED','首次提交请包含结构化 header 数据');
    if(header){assert(!requirements.compiledHeader||!w.base_manifest_json&&w.manifest_json===initialManifestJson(w),'HEADER_EDIT_REQUIRES_DATA','已冻结的页头请使用 set_site_header 修改',409);requirements.compiledHeader=freezeSiteHeader(manifest,header,requirements,w.id);w.requirements_json=boundedJson(requirements);}
   }
   manifest=await materializeWorkflowDesign(w,manifest);
   await prepareWorkflowSitePlan(env,w,manifest);
   if(originalName==='compose_site'||originalName==='compose_site_v2'||originalName==='compose_site_grammar')await freezeWorkflowComposition(w,manifest);
   assertDesignScope(w.base_manifest_json?JSON.parse(w.base_manifest_json):null,manifest,JSON.parse(w.scope_json));w.manifest_json=boundedJson(manifest);w.validated_hash=null;result={ok:true,changedFiles:a.files.map(f=>f.path),...(repaired.length?{repairedBySystem:repaired}:{}),...(links.repairs.length?{sharedFragmentLinkRepairs:links.repairs}:{}),...await writtenCheck(env,w,manifest)};
  }else if(name==='discard_prepared_images'){
   const a=imageDispositionsSchema.parse(args),requirements=JSON.parse(w.requirements_json),record=requirements.imageFramePlan;
   assert(canDiscardPreparedImages(w)&&w.activeStepId,'WORKFLOW_TOOL_DENIED','当前任务没有可明确弃用的成功图片');
   const decision=recordPreparedImageDispositions(record.retention,a.images,{stepId:w.activeStepId,callId},record.dispositions);
   assert(!decision.issues.length&&decision.dispositions,'IMAGE_DISPOSITION_INVALID',decision.issues.map(issue=>issue.message).join('\n').slice(0,1800));
   requirements.imageFramePlan={...record,dispositions:decision.dispositions};w.requirements_json=boundedJson(requirements);w.validated_hash=null;
   const compiledIds=requirements.composedLayout?.snapshot?.frames?.map((frame:any)=>frame.id)??[],compiledDiscards=a.images.filter(image=>compiledIds.includes(image.frameId)).map(image=>image.frameId);
   if(compiledDiscards.length){
    const finalized=finalizeWorkflowSiteCompositionImages(manifest,await readCompositionSnapshot(requirements.composedLayout),{failedFrameIds:[],discardedFrameIds:compiledDiscards});
    manifest=finalized.manifest;requirements.composedLayout.snapshot=await storeCompositionSnapshot(requirements.composedLayout,finalized.snapshot);w.manifest_json=boundedJson(manifest);w.requirements_json=boundedJson(requirements);
   }
   result={ok:true,recorded:true,frameIds:a.images.map(image=>image.frameId),message:compiledDiscards.length?'已记录弃用原因，并由平台收起对应的组合式图框。':'已记录图片弃用原因；此操作本身没有删除图片。',...imageOmissionResult(w)};
  }else if(name==='set_site_header'){
   assert(ordered,'WORKFLOW_TOOL_DENIED','旧任务不升级页头协议');
   assert(w.manifest_json!==initialManifestJson(w)||w.base_manifest_json&&JSON.parse(w.requirements_json).compiledHeader,'HEADER_MANIFEST_REQUIRED','先提交完整页面与菜单，再修改页头数据');
   const {header}=z.object({header:siteHeaderSpecSchema}).strict().parse(args),requirements=JSON.parse(w.requirements_json);
   requirements.compiledHeader=freezeSiteHeader(manifest,header,requirements,w.id);
   const nextRequirements=boundedJson(requirements);
   manifest=await materializeWorkflowDesign({...w,requirements_json:nextRequirements},manifest);
   assertDesignScope(w.base_manifest_json?JSON.parse(w.base_manifest_json):null,manifest,JSON.parse(w.scope_json));
   w.requirements_json=nextRequirements;w.manifest_json=boundedJson(manifest);w.validated_hash=null;
   result={ok:true,changed:'header',...await writtenCheck(env,w,manifest)};
  }else if(name==='edit_file'){
   const a=z.object({path:z.string().max(100),edits:z.array(z.object({find:z.string().min(1).max(20000),replace:z.string().max(60000)}).strict()).min(1).max(12)}).strict().parse(args);
   const match=/^templates\/(\d+)\.(html|css)$/.exec(a.path);assert(match,'WORKFLOW_PATH_DENIED','edit_file 只能修改 templates/<id>.html 或 templates/<id>.css');
   const template=manifest.templates.find((t:any)=>t.id===Number(match[1]));assert(template,'WORKFLOW_PATH_DENIED','模板不存在');
   assert(!ordered||template.id!==JSON.parse(w.requirements_json).compiledHeader?.templateId,'HEADER_EDIT_REQUIRES_DATA','页头由平台渲染，请使用 set_site_header 修改数据',409);
   let content=String(template.document[match[2]]??'');
   a.edits.forEach((change,index)=>{const count=content.split(change.find).length-1;assert(count===1,'WORKFLOW_EDIT_MISMATCH','第 '+(index+1)+' 处修改的 find '+(count?'出现了 '+count+' 次，请加长到只出现一次':'在文件中找不到，请用 read_file 核对原文后重试'),409);content=content.replace(change.find,()=>change.replace);});
   template.document[match[2]]=content;
   const links=repairNewSiteLinks(w,manifest);manifest=links.manifest;
   manifest=await materializeWorkflowDesign(w,manifest);
   assertDesignScope(w.base_manifest_json?JSON.parse(w.base_manifest_json):null,manifest,JSON.parse(w.scope_json));w.manifest_json=boundedJson(manifest);w.validated_hash=null;
   result={ok:true,changedFiles:[a.path],edits:a.edits.length,...(links.repairs.length?{repairedBySystem:['shared_fragment_links'],sharedFragmentLinkRepairs:links.repairs}:{}),...await writtenCheck(env,w,manifest)};
  }else if(name==='replace_selected'){
   const a=z.object({html:z.string().min(1).max(200000),assets:z.array(z.object({file:z.string().max(200),path:z.string().max(400),sha256:z.string().max(80),size:z.number().int().nonnegative()}).strict()).max(8)}).strict().parse(args);
   const scope=JSON.parse(w.scope_json) as DesignScope;assert(scope.kind==='node'&&w.base_manifest_json,'WORKFLOW_TOOL_DENIED','只有选中区块时才能使用');
   assert(!ordered||scope.templateId!==JSON.parse(w.requirements_json).compiledHeader?.templateId,'HEADER_EDIT_REQUIRES_DATA','页头由平台渲染；请切换到整站范围，用结构化页头工具修改');
   // Always applied to the design the customer selected in: the selection's position belongs to that version.
   const base=JSON.parse(w.base_manifest_json);let next=structuredClone(base);const target=designNodeHtml(next,scope),html=target.template.document.html;
   target.template.document.html=html.slice(0,target.start)+a.html.trim()+html.slice(target.end);
   // Only media of this project can be added, exactly as the project lists it.
   const available=(JSON.parse(w.requirements_json).availableAssets??[]) as {asset:{file:string;path:string;sha256:string;size:number}}[];
   for(const asset of a.assets){const known=available.find(entry=>entry.asset.path===asset.path&&entry.asset.sha256===asset.sha256);assert(known,'WORKFLOW_PATH_DENIED','只能使用本项目素材库里的图片');if(!next.assets.some((entry:{path:string})=>entry.path===known.asset.path))next.assets.push(known.asset);}
   // Canonicalize only the trusted font snapshot for new selected edits. New
   // text nodes and equivalent var(--bnf-*) declarations need the same frozen
   // stacks as existing text. The exact scope assertion below still rejects
   // any materialization that would change content outside the selected span.
   const typography=JSON.parse(w.requirements_json).typography;
   if(hasSelectedEditProtocol(w)&&typography)next=enforceTypographySnapshot(next,typographySnapshotSchema.parse(typography));
   assertDesignScope(base,next,scope);const selectedIssues=selectedWorkflowIssues(w,next);assert(!selectedIssues.length,selectedIssues[0]?.code??'SELECTED_EDIT_NO_CHANGE',selectedIssues[0]?.message??'选中区块尚无有效变化',409);manifest=next;w.manifest_json=boundedJson(next);w.validated_hash=null;
   result={ok:true,replaced:'selected block',...await writtenCheck(env,w,next)};
  }else if(name==='prepare_layout'){
   assert(frameFirst(w)&&!w.base_manifest_json&&!w.workspace_id&&JSON.parse(w.scope_json).kind==='site','WORKFLOW_TOOL_DENIED','此工具仅用于新站的先布局后生图流程');
   const v2=frameFirstV2(w),a=ordered&&v2?preparedOrderedLayoutSchema.parse(args):v2?preparedLayoutV2Schema.parse(args):preparedLayoutSchema.parse(args),requirements=JSON.parse(w.requirements_json),prior=requirements.imageFramePlan,argsHash=await sha256(JSON.stringify(a)),policy=workflowGenerationPolicy(w.requirements_json);
   assert(!v2||prior||requirements.designBrief?.imagePlan?.mode!=='none'&&requirements.designBrief?.imagePlan?.generation!=='disabled','WORKFLOW_IMAGES_DISABLED','本次要求不生成新图片，请使用已有素材或内容排版');
   assert(!prior||prior.callId===callId&&prior.argsHash===argsHash,'IMAGE_LAYOUT_ALREADY_PREPARED','图框和图片任务已保存；后续仅修改需要调整的模板，不重新生成整站图片',409);
   assert(prior||w.manifest_json===initialManifestJson(w),'WORKFLOW_REWRITE_DENIED','已有完整设计，请修改现有片段而非重新生成整站',409);
   assert(!(w.coherenceReview?.offered||w.coherenceReview?.pendingHash),'WORKFLOW_COHERENCE_IMAGES_DISABLED','局部审查修正不再生成收费图片');
   const sectionMap=new Map<string,{id:string;layout:string;frames:any[]}>();
   for(const task of a.images){let section=sectionMap.get(task.sectionId);if(!section){section={id:task.sectionId,layout:task.layout,frames:[]};sectionMap.set(task.sectionId,section);}section.frames.push({id:task.id,purpose:task.purpose,slot:task.slot,subjectPolicy:task.subjectPolicy,framePolicy:task.framePolicy,...(v2?{presentation:('presentation' in task?task.presentation:'standard')}:{} )});}
   const preserveContain=/\bobject-fit\s*:\s*contain\b|明确保留留白|固定图框并完整显示/i.test(String(requirements.request??''));
   const plan=compileImageFramePlan({sections:[...sectionMap.values()]},{...(v2?{version:'image-frame-plan-v2' as const}:{}),preserveExplicitContainIds:preserveContain?a.images.map(t=>t.id):[]});
   manifest=JSON.parse(a.files[0].content);repairManifest(manifest,requirements);manifest=repairNewSiteLinks(w,manifest).manifest;
   if(ordered){
    if(!prior){assert('header' in a,'HEADER_DATA_REQUIRED','请包含结构化 header 数据');requirements.compiledHeader=freezeSiteHeader(manifest,a.header,requirements,w.id);}
    assert(requirements.compiledHeader,'HEADER_SNAPSHOT_INVALID','已保存布局缺少页头快照，不重新编译或收费');w.requirements_json=boundedJson(requirements);
   }
   manifest=await materializeWorkflowDesign(w,manifest);
   const prepared=prepareSiteLayout(manifest,plan);
   assert(!prepared.issues.length,'IMAGE_LAYOUT_INVALID',prepared.issues.map(issue=>issue.message).join('\n').slice(0,1800));manifest=prepared.manifest;
   const validation=validateSiteManifest(manifest);
   assert(validation.valid,'IMAGE_LAYOUT_INVALID',validation.issues.filter((issue:any)=>issue.severity!=='warning').slice(0,8).map((issue:any)=>issue.message).join('\n'));
   assertDesignScope(null,manifest,JSON.parse(w.scope_json));await verifyProjectAssets(env,w.user_id,w.project_id,manifest);
   await prepareWorkflowSitePlan(env,w,manifest,plan);Object.assign(requirements,JSON.parse(w.requirements_json));
   const prefix='wfimg_'+(await sha256(w.id)).slice(0,20)+'_',keys=await Promise.all(a.images.map(task=>sha256('frame:'+task.id+':'+argsHash).then(hash=>prefix+hash.slice(0,24))));
   const made=await env.DB.prepare('SELECT request_key FROM image_jobs WHERE user_id=? AND request_key LIKE ?').bind(w.user_id,prefix+'%').all<{request_key:string}>(),known=new Set(made.results.map(row=>row.request_key));
   assert(known.size+keys.filter(key=>!known.has(key)).length<=(v2?policy?.maxImages??8:MAX_WORKFLOW_IMAGES),'WORKFLOW_IMAGE_LIMIT','本次任务的图片数量超过限制，请使用已有素材');
   const artDirection='artDirection' in a?a.artDirection:null;
   let imagePrompts=a.images.map(task=>imagePromptWithVisualDirection(imagePromptForPlannedFrame(task.prompt,plan.frames.find(frame=>frame.id===task.id)!),foundation,{section:task.purpose,preserveExplicitDirection:userSpecifiesImageDirection(String(requirements.request??'')),...(v2?{maxPromptBytes:Number.MAX_SAFE_INTEGER}:{})}).prompt+(artDirection?'\n\nSite art direction: '+artDirection+'\nRespect explicit user preferences and the frame geometry first.':''));
   let batch=prior?.batch as {configId:string;quality:'low'|'medium';prompts:string[];finalPrompts:string[];maxPromptBytes:number;projectedImageMicros:number}|undefined;
   if(v2&&batch){assert(batch.prompts.length===a.images.length&&batch.finalPrompts.length===a.images.length,'IMAGE_LAYOUT_CHANGED','已冻结图片批次与图框数量不一致',409);imagePrompts=batch.prompts;}
   if(keys.some(key=>!known.has(key))){
    const quote=await imageGenerationQuote(env,w.user_id,batch?.configId,v2?batch?.quality??policy?.imageQuality??'low':undefined);assert(quote.available,'IMAGE_NOT_CONFIGURED','图片服务当前不可用，请使用已有素材或内容排版');
    const limit=quote.maxPromptBytes;
    const finalPrompts=imagePrompts.map((prompt,index)=>{const frame=plan.frames.find(frame=>frame.id===a.images[index].id)!;return imagePromptForSlot(prompt,frame.resolvedSlot,frame.generation.size);});
    assert(typeof limit==='number'&&finalPrompts.every(prompt=>new TextEncoder().encode(prompt).length<=limit),'IMAGE_PROMPT_TOO_LONG','这批图片中有描述与构图说明超过支持长度；请先缩短描述，尚未派发任何图片');
    if(v2&&!batch)batch={configId:quote.configId!,quality:policy?.imageQuality??'low',prompts:imagePrompts,finalPrompts,maxPromptBytes:limit!,projectedImageMicros:(quote.estimatedMicrosForPlanning??(policy?.imageQuality==='medium'?300000:60000))*a.images.length};
   }
   w.manifest_json=boundedJson(manifest);w.validated_hash=null;
   const preparedHash=await sha256(w.manifest_json);assert(!prior||prior.preparedHash===preparedHash,'IMAGE_LAYOUT_CHANGED','已保存布局与重放内容不一致，不发起新的收费请求',409);
   assert(!v2||batch,'IMAGE_LAYOUT_CHANGED','新版图片任务缺少冻结的批次',409);
   requirements.imageFramePlan={version:v2?FRAME_FIRST_VERSION:'frame-first-1',callId,argsHash,preparedHash,plan,status:'prepared',...(batch?{batch,artDirection}:{}),...(prior?.retention?{retention:prior.retention}:{}),...(prior?.dispositions?{dispositions:prior.dispositions}:{})};w.requirements_json=boundedJson(requirements);
   await persistPreparedLayout(env,w,'prepared');
   const hold=async()=>{const result=await env.DB.prepare("UPDATE ai_workflows SET lease_until_ms=? WHERE id=? AND lease_token=? AND state='processing'").bind(Date.now()+LEASE_MS,w.id,w.lease_token).run();assert(result.meta.changes===1,'WORKFLOW_LEASE_LOST','任务执行权已变化，请查询原任务',409);};
   await hold();let leaseLost=false;const heartbeat=setInterval(()=>{void hold().catch(()=>{leaseLost=true;});},30000);
   let jobs:PromiseSettledResult<Awaited<ReturnType<typeof createImageGeneration>>>[];
   const dispatch=(index:number)=>{const task=a.images[index],frame=plan.frames.find(f=>f.id===task.id)!;return createImageGeneration(env,w.user_id,w.project_id,{requestKey:keys[index],slot:frame.resolvedSlot,prompt:imagePrompts[index],...(batch?{configId:batch.configId,quality:batch.quality,generationSize:frame.generation.size,expectedFinalPrompt:batch.finalPrompts[index],...(policy?.imageEstimation==='image-estimate-v1'?{estimationPolicy:'image-estimate-v1' as const}:{})}:{})});};
   try{jobs=v2?await boundedImageQueue(a.images.length,policy?.imageConcurrency??3,async()=>{assert(!leaseLost,'WORKFLOW_LEASE_LOST','任务执行权已变化，未派发剩余图片',409);await hold();},dispatch):await Promise.allSettled(a.images.map((_task,index)=>dispatch(index)));}finally{clearInterval(heartbeat);}
   assert(!leaseLost,'WORKFLOW_LEASE_LOST','图片任务已派发，执行权变化后请查询原任务，不自动重发',409);await hold();
   const media=await listMedia(env,w.user_id,w.project_id),available=workflowAvailableAssets(media,manifest.assets??[]),bindings:Parameters<typeof bindPreparedImages>[2][number][]=[];
   const images=jobs.map((job,index)=>{const task=a.images[index],frame=plan.frames.find(f=>f.id===task.id)!,item=job.status==='fulfilled'&&job.value.state==='succeeded'&&job.value.result_media_id?workflowMediaAsset(media,available,job.value.result_media_id):null;
    if(!item?.id||!item.width||!item.height)return{frameId:task.id,ok:false,code:job.status==='fulfilled'?job.value.error_code??'IMAGE_UNAVAILABLE':code(job.reason)};
    if(!manifest.assets.some((asset:any)=>asset.path===item.asset.path))manifest.assets.push(item.asset);
    bindings.push({frameId:task.id,asset:{id:item.id,width:item.width,height:item.height},src:item.asset.path,alt:task.alt});
    const receipt=resolvePlannedImageFrame(frame,item.width,item.height);return{frameId:task.id,ok:true,asset:item.asset,width:item.width,height:item.height,slot:receipt.slot,display:receipt.display,subjectVerified:false};
   });
   const bound=bindPreparedImages(manifest,plan,bindings);assert(!bound.issues.length,'IMAGE_LAYOUT_BINDING',bound.issues.map(issue=>issue.message).join('\n').slice(0,1800));manifest=bound.manifest;
   const retention=requirements.imageCompletionPolicy===PREPARED_IMAGE_RETENTION_VERSION?freezePreparedImageRetention(manifest,plan,images):null;
   assert(!retention?.issues.length,'IMAGE_RETENTION_INVALID',retention?.issues.map(issue=>issue.message).join('\n').slice(0,1800)??'');
   if(retention&&prior?.retention)assert(JSON.stringify(retention.retention)===JSON.stringify(prior.retention),'IMAGE_RETENTION_CHANGED','重放后的图片归属与原记录不一致，不重新生成图片',409);
   if(requirements.composedLayout){
    const finalized=finalizeWorkflowSiteCompositionImages(manifest,await workflowSourceSnapshot(requirements.composedLayout),{failedFrameIds:images.filter(image=>!image.ok).map(image=>image.frameId)});
    if(requirements.composedLayout.snapshot.phase==='frozen')assert(!validateWorkflowSiteComposition(finalized.manifest,await readCompositionSnapshot(requirements.composedLayout)).length,'SITE_COMPOSITION_REPLAY_CHANGED','组合布局重放与已保存结果不同，不重新生成图片',409);
    manifest=finalized.manifest;requirements.composedLayout.snapshot=await storeCompositionSnapshot(requirements.composedLayout,freezeWorkflowSiteComposition(manifest,finalized.snapshot));
   }
   w.manifest_json=boundedJson(manifest);requirements.imageFramePlan={...requirements.imageFramePlan,status:'bound',images,...(retention?{retention:prior?.retention??retention.retention}:{})};w.requirements_json=boundedJson(requirements);await persistPreparedLayout(env,w,'bound');
   result={ok:true,layoutSaved:true,changedFiles:['manifest.json'],images,...await writtenCheck(env,w,manifest),use:'The platform has saved the layout and bound successful owned images. Keep frame IDs and geometry. Failed frames cannot be saved empty: replace with useful text/diagram and remove its bnf-image ID, or remove that frame. Do not generate paid replacement images for cosmetic corrections.'};
  }else if(name==='create_images'){
   assert(!frameFirst(w),w.coherenceReview?.offered||w.coherenceReview?.pendingHash?'WORKFLOW_COHERENCE_IMAGES_DISABLED':'IMAGE_LAYOUT_REQUIRED','先用 prepare_layout 提交完整布局和图框；局部审查阶段请使用已有素材');
   const a=workflowImagesSchema.parse(args);
   // One key per task, call and position: a replayed round returns the same images and never pays twice.
   const prefix='wfimg_'+(await sha256(w.id)).slice(0,20)+'_',keys=await Promise.all(a.images.map((_image,index)=>sha256(callId+':'+index).then(hash=>prefix+hash.slice(0,24))));
   const made=await env.DB.prepare("SELECT request_key FROM image_jobs WHERE user_id=? AND request_key LIKE ?").bind(w.user_id,prefix+'%').all<{request_key:string}>(),known=new Set(made.results.map(row=>row.request_key));
   assert(!(w.coherenceReview?.offered||w.coherenceReview?.pendingHash)||keys.every(key=>known.has(key)),'WORKFLOW_COHERENCE_IMAGES_DISABLED','当前为局部设计修正，请使用已有素材，不再生成收费图片');
   assert(known.size+keys.filter(key=>!known.has(key)).length<=MAX_WORKFLOW_IMAGES,'WORKFLOW_IMAGE_LIMIT','本次任务最多生成 '+MAX_WORKFLOW_IMAGES+' 张插图，请使用已有图片');
   // Images take as long as a model answer: keep this executor's claim on the task while they are made.
   const hold=()=>env.DB.prepare('UPDATE ai_workflows SET lease_until_ms=? WHERE id=? AND lease_token=?').bind(Date.now()+LEASE_MS,w.id,w.lease_token).run();
   await hold();
   const preserveExplicitDirection=userSpecifiesImageDirection(String(JSON.parse(w.requirements_json).request??''));
   const jobs=await Promise.allSettled(a.images.map((image,index)=>createImageGeneration(env,w.user_id,w.project_id,{prompt:imagePromptWithVisualDirection(image.prompt,foundation,{section:image.section,preserveExplicitDirection}).prompt,requestKey:keys[index],...(image.slot?{slot:image.slot}:{})})));
   await hold();
   const media=await listMedia(env,w.user_id,w.project_id),available=workflowAvailableAssets(media,manifest.assets??[]);
   const images=jobs.map((job,index)=>{const item=job.status==='fulfilled'&&job.value.state==='succeeded'&&job.value.result_media_id?workflowMediaAsset(media,available,job.value.result_media_id):null,slot=a.images[index].slot;return item?{section:a.images[index].section,ok:true,width:item.width,height:item.height,asset:item.asset,...(slot&&item.width&&item.height?{slot,display:imageDisplay(slot,item.width,item.height)}:{})}:{section:a.images[index].section,ok:false,code:job.status==='fulfilled'?job.value.error_code??'IMAGE_UNAVAILABLE':code(job.reason)};});
   result={ok:images.some(image=>image.ok),images,use:'Add each successful asset to manifest.assets unchanged and use asset.path only in its planned frame. Set img width/height to the real dimensions; reserve frame aspect-ratio before loading and apply display.objectFit/objectPosition. Preserve contain for complete products; do not force cover or reuse the image in an incompatible frame. For failed images use layout and colour instead.'};
  }else if(name==='check_preview'){
   z.object({}).strict().parse(args);const validation=validateSiteManifest(manifest);assertDesignScope(w.base_manifest_json?JSON.parse(w.base_manifest_json):null,manifest,JSON.parse(w.scope_json));
   if(validation.valid)await verifyProjectAssets(env,w.user_id,w.project_id,manifest);
   const additionalIssues=[...await preparedDesignIssues(w,manifest),...selectedWorkflowIssues(w,manifest)],designReview=validation.valid&&!additionalIssues.length?await coherenceCheck(env,w,manifest):null,passed=validation.valid&&!additionalIssues.length&&designReview?.status!=='revision_requested';
   w.validated_hash=passed?await sha256(w.manifest_json):null;result={ok:passed,...imageOmissionResult(w),issues:[...validation.issues,...additionalIssues],...(designReview?{designReview}:{}),checks:['aacms-structure','html-css-policy','owned-media-bytes','modification-scope',...(hasSelectedEditProtocol(w)?['selected-static-change']:[]),...(frameFirst(w)?['mobile-navigation','planned-images-filled']:[])],browserRendered:false,visualAcceptance:false};
  }else if(name==='finish'){
   finishArgs.parse(args);assert(w.validated_hash===await sha256(w.manifest_json),'PREVIEW_CHECK_REQUIRED','请先对最新文件运行 check_preview 并修复问题');
   const initial=initialManifestJson(w);assert(w.manifest_json!==initial,'WORKFLOW_NO_CHANGES','尚未产生设计修改，不能把结构示例作为完成方案');
   const selectedIssues=selectedWorkflowIssues(w,manifest);assert(!selectedIssues.length,selectedIssues[0]?.code??'SELECTED_EDIT_NO_CHANGE',selectedIssues[0]?.message??'选中区块尚无有效变化',409);
   const typography=JSON.parse(w.requirements_json).typography;
   const candidate=await saveDesignCandidate(env,{userId:w.user_id,projectId:w.project_id,requestKey:'workflow:'+w.id,baseVersionId:w.base_version_id,scope:JSON.parse(w.scope_json),manifest,source:'ai',workflowId:w.id,...(typography?{typography:typographySnapshotSchema.parse(typography)}:{})});
   w.candidate_id=candidate.id;result={ok:true,candidateId:candidate.id,previewUrl:candidate.previewUrl,adopted:false,...imageOmissionResult(w)};
  }
  boundedJson(result);return {name:originalName,callId,result};
 }catch(error){
  // A paid image may already exist. Infrastructure failures must retain this
  // responded step for local replay, not turn it into a new model/tool call.
 
 if(name==='prepare_layout'&&!(error instanceof z.ZodError)&&!(error instanceof SyntaxError)&&(!(error instanceof AppError)||['STORAGE_FAILURE','WORKFLOW_TEMPORARILY_UNAVAILABLE','WORKFLOW_LEASE_LOST'].includes(error.code)))throw error;
  if((originalName==='compose_site'||originalName==='compose_site_v2')&&!JSON.parse(w.requirements_json).imageFramePlan){w.requirements_json=beforeRequirements;w.manifest_json=beforeManifest;w.validated_hash=null;}
  return {name:originalName,callId,result:{ok:false,code:error instanceof z.ZodError?'WORKFLOW_TOOL_ARGUMENTS':code(error),message:error instanceof AppError?error.message:'工具输入或文件内容无效，请按协议修正'}};
 }
}

async function requestInput(env:Env,w:Workflow,history:Step[]){
 const foundation=foundationFromRequirements(w.requirements_json),content:any[]=[{type:'input_text',text:stringify(authoringRequirements(w))}];
 for(const reference of JSON.parse(w.reference_images_json) as Reference[]){const {row,bytes}=await readMedia(env,w.user_id,reference.id);assert(row.project_id===w.project_id&&row.sha256===reference.sha256&&row.byte_size===reference.byteSize&&row.mime_type===reference.mimeType,'REFERENCE_IMAGE_CHANGED','参考图已变化，请重新创建任务',409);let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));content.push({type:'input_image',detail:'auto',image_url:`data:${reference.mimeType};base64,${btoa(binary)}`});}
 // Everything the model used to spend its first two rounds fetching is handed over with the request itself.
 if(!w.workspace_id){
  const base=w.base_manifest_json?JSON.parse(w.base_manifest_json):null;let scope:DesignScope={kind:'site'};try{scope=JSON.parse(w.scope_json);}catch{/* whole site */}
  // A selected block travels with its own markup, so changing it needs no reading round and no list of every block.
  if(base&&scope.kind==='node'){let selected:unknown=null;
   if(hasSelectedEditProtocol(w)){const context=selectedEditContext(base,scope);assert(context.html.length<=200000,'SELECTED_EDIT_TOO_LARGE','所选区块过大，请缩小选择后再修改',422);selected=context;}
   else try{selected={templateId:scope.templateId,nodeKey:scope.nodeKey,html:designNodeHtml(base,scope).html};}catch{selected=null;}
   content.push({type:'input_text',text:stringify({provided:'用户选中的区块已在此提供，直接调用 replace_selected 修改它，无需读取任何文件',selected})});}
  else content.push({type:'input_text',text:stringify({provided:'项目资料与规范已在此提供，无需调用 read_project 或 read_rules',baseline:TEMPLATE_CONTRACT_BASELINE,...(base?{nodes:describeDesignNodes(base)}:{example:foundation?foundationAuthoringExample(foundation):example})})});
 }
 const input:any[]=[{role:'user',content}];
 for(const s of history){assert(s.state==='completed'&&s.response_json&&s.tool_results_json,'WORKFLOW_HISTORY_INVALID','历史步骤尚未确认，不能继续派发',409);const response=w.workspace_id?await storedReceipt(env,w,s,'response'):null,tools=w.workspace_id?await storedReceipt(env,w,s,'tool'):null;if(w.workspace_id)assert(response&&tools,'WORKFLOW_HISTORY_INVALID','历史结果副本缺失，不能派发',503);input.push(...(response?response.value:JSON.parse(s.response_json)).output);for(const t of tools?tools.value:JSON.parse(s.tool_results_json))input.push({type:'function_call_output',call_id:t.callId,output:stringify(t.result)});}
 return input;
}
/**
 * Stores what the model has written so far, at most about once a second and never two writes at a time, so the
 * conversation and the canvas can show the step moving. It only ever touches the step that is being answered, and
 * a failed write is ignored: nothing here can change the result, the cost or the state of the step.
 */
function liveProgress(env:Env,stepId:string,terms:readonly string[],workingJson:string|null,foundation:DesignFoundation|null=null){
 let last=0,writing=false,seq=0,working:any;
 return (progress:StreamProgress)=>{
  const now=Date.now();if(writing||now-last<600)return;last=now;writing=true;
  void (async()=>{
   try{
    const files=workingJson?draftFiles(progress):[],draft=files.length?JSON.stringify(files):null;
    if(files.length&&working===undefined){try{working=JSON.parse(workingJson!);}catch{working=null;}}
    // The template being written right now, by the name the customer knows it (a page, the header, the footer).
    const live=files.length?liveManifest(working,files,foundation):null,page=live?live.templates.find(t=>t.id===live.latest)?.name.slice(0,60)||null:null,preview=!!live&&draft!.length<=900_000;
    const summary=JSON.stringify({seq:++seq,text:publicText(progress.text,terms).slice(0,2000),tool:progress.calls.at(-1)?.name??null,chars:progress.calls.reduce((total,call)=>total+call.arguments.length,0),preview,page});
    await env.DB.prepare("UPDATE ai_workflow_steps SET progress_json=?,progress_draft=? WHERE id=? AND state='dispatching'").bind(summary,preview?draft:null,stepId).run();
   }catch{/* display only */}finally{writing=false;}
  })();
 };
}
/** While the model is still sending, the task stays with the request that is reading it. */
function leaseHeartbeat(env:Env,w:Workflow){
 let last=Date.now();
 return ()=>{const now=Date.now();if(now-last<20_000)return;last=now;void env.DB.prepare("UPDATE ai_workflows SET lease_until_ms=? WHERE id=? AND lease_token=? AND state='processing'").bind(now+LEASE_MS,w.id,w.lease_token).run().catch(()=>{/* housekeeping only */});};
}
// ── A round without a usage receipt ─────────────────────────────────────────────────────────────────────────────
// The request went out, but the answer broke off, timed out or was refused, so the supplier never told us what the
// round cost. A task started from a message is not parked for a manual cost check in that case (owner decision,
// 2026-11-13: credit is tracked as the work happens and a task never waits on accounting). What is known is used:
// the request that was sent and the output that had already streamed in are priced as an estimate, the rest of the
// reservation goes back to the customer immediately, the estimate is written to the audit log, and the round is
// asked again — twice at most, after which the task ends as failed with nothing left on hold.
const UNRECEIPTED_RETRIES=2,BILLING_INTEGRITY=['AI_PRICING_MISMATCH','AI_USAGE_INVALID','COST_EXCEEDS_RESERVATION'];
type Unreceipted={dispatched:boolean;refused:boolean;inputTokens:number;cachedTokens:number;outputTokens:number;progress?:StreamProgress;received?:any};
function approxTokens(text:string){let wide=0;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>0x2E7F)wide++;return Math.ceil(wide+(text.length-wide)/3.5);}
function approxInputTokens(value:any):number{
 if(typeof value==='string')return approxTokens(value);
 if(!value||typeof value!=='object')return 0;
 if(Array.isArray(value))return value.reduce((total:number,item)=>total+approxInputTokens(item),0);
 if(value.type==='input_image')return 1500;
 let total=0;for(const [key,item] of Object.entries(value))total+=key==='encrypted_content'&&typeof item==='string'?Math.ceil(item.length/6):approxInputTokens(item);
 return total;
}
/** Size of one request: its fixed opening (rules, tools, the first message) is read from the supplier's cache from the second round on. */
function requestTokens(instructions:string,input:any[],tools:unknown,warm:boolean){const fixed=approxTokens(instructions)+approxInputTokens(tools)+approxInputTokens(input[0]);return {inputTokens:fixed+approxInputTokens(input.slice(1)),cachedTokens:warm?fixed:0};}
function storedOutputTokens(step:Step){try{const progress=JSON.parse(step.progress_json??'null');return progress?approxTokens(String(progress.text??''))+Math.ceil(Number(progress.chars||0)/2):0;}catch{return 0;}}
async function settleUnreceipted(env:Env,w:Workflow,step:Step,pricing:TextPricing,seen:Unreceipted,cause:string,retryAllowed=true){
 let micros=0,basis='not_dispatched';
 if(seen.refused)basis='refused_by_supplier';
 else if(seen.dispatched){
  basis='estimate';micros=Math.ceil(estimatedTextCost(pricing,{input:Math.max(0,seen.inputTokens-seen.cachedTokens),cachedInput:seen.cachedTokens,output:seen.outputTokens})*1.15);
  // A complete answer that only failed to be stored still carries its own receipt.
  if(seen.received){try{micros=textProviderUsageCost(pricing,seen.received);basis='receipt';}catch{/* keep the estimate */}}
  micros=Math.min(w.per_step_micros,micros);
 }
 if(micros>0)await settle(env.DB,{reservationId:step.reservation_id,actualMicros:micros});else await releaseConfirmedUnused(env.DB,step.reservation_id);
 const attempts=(step.attempts??0)+1,retry=retryAllowed&&attempts<=UNRECEIPTED_RETRIES,closed=step.reservation_id,next=retry?id('res'):closed,now=new Date().toISOString();
 await env.DB.batch([
  env.DB.prepare('UPDATE ai_workflow_steps SET reservation_id=?,state=?,error_code=?,attempts=?,retired_micros=retired_micros+?,progress_json=NULL,progress_draft=NULL,updated_at=? WHERE id=? AND reservation_id=?').bind(next,retry?'preparing':'failed',retry?null:'AI_PROVIDER_INTERRUPTED',attempts,retry?micros:0,now,step.id,closed),
  auditStatement(env.DB,null,'ai.workflow_step_estimated','workflow_step',step.id,{workflowId:w.id,ordinal:step.ordinal,reservationId:closed,basis,chargedMicros:micros,inputTokens:seen.inputTokens,cachedTokens:seen.cachedTokens,outputTokens:seen.outputTokens,cause,attempt:attempts,retry},closed),
 ]);
 step.reservation_id=next;step.state=retry?'preparing':'failed';step.attempts=attempts;step.error_code=retry?null:'AI_PROVIDER_INTERRUPTED';
 return {retry,micros};
}
/** Nothing the customer is not actively waiting for keeps credit on hold. Whenever the account's design tasks are
 * read or a new message arrives, every message task of the account whose round went out and never came back is
 * closed on the estimate: tasks an earlier version parked for a cost check end as failed, so a new message can be
 * sent; tasks that simply stopped mid-round (the page was closed, the request died — their lease ran out minutes
 * ago) get their hold back and stay resumable. This covers designs that were deleted in the meantime as well. */
const ABANDONED_AFTER_MS=120_000;
export async function releaseHeldRounds(env:Env,userId:string){
 const rows=await env.DB.prepare("SELECT * FROM ai_workflows WHERE user_id=? AND workspace_id IS NULL AND (state='uncertain' OR (state='processing' AND COALESCE(lease_until_ms,0)<?)) ORDER BY updated_at DESC LIMIT 6").bind(userId,Date.now()-ABANDONED_AFTER_MS).all<Workflow>();
 for(const w of rows.results){
  if(!fromMessage(w))continue;
  try{
   const parked=w.state==='uncertain',history=await steps(env,w.id),step=history.at(-1);
   if(!step||step.response_json||!(parked?step.state==='uncertain':['dispatching','uncertain'].includes(step.state))||BILLING_INTEGRITY.includes(step.error_code??''))continue;
   const reservation=await env.DB.prepare('SELECT state FROM api_reservations WHERE id=?').bind(step.reservation_id).first<{state:string}>();
   let retry=false;
   if(reservation&&['reserved','dispatching','uncertain'].includes(reservation.state)){
    const config=await env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(w.config_version_id).first<IntegrationRow>();if(!config)continue;
    const pricing=textConfigurationPricing({...config,public_config_json:w.pricing_json}),completed=history.filter(s=>s.state==='completed');
    // The request is sized from what the task stored; if its inputs can no longer be read, from its brief alone.
    let input:any[]=[{role:'user',content:[{type:'input_text',text:w.requirements_json}]}];try{input=await requestInput(env,w,completed);}catch{/* brief only */}
    ({retry}=await settleUnreceipted(env,w,step,pricing,{dispatched:reservation.state!=='reserved',refused:false,...requestTokens(workflowRules(w),input,WORKFLOW_TOOLS,completed.length>0),outputTokens:storedOutputTokens(step)},step.error_code??'AI_PROVIDER_UNCERTAIN',!parked));
   }else if(parked)await env.DB.prepare("UPDATE ai_workflow_steps SET state='failed',error_code='AI_PROVIDER_INTERRUPTED',updated_at=? WHERE id=? AND state='uncertain'").bind(new Date().toISOString(),step.id).run();
   else continue;
   if(!retry)await env.DB.prepare("UPDATE ai_workflows SET state='failed',error_code='AI_PROVIDER_INTERRUPTED',lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND state=? AND COALESCE(lease_token,'')=?").bind(new Date().toISOString(),w.id,w.state,w.lease_token??'').run();
  }catch{/* Left as it is for the owner to reconcile. */}
 }
}
async function endWorkflow(env:Env,w:Workflow,state:string,errorCode:string|null){await env.DB.prepare('UPDATE ai_workflows SET state=?,error_code=?,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(state,errorCode,new Date().toISOString(),w.id,w.lease_token).run();}
export async function continueWorkflow(env:Env,userId:string,workflowId:string,runtime:WorkflowRuntime={},requestedStep?:number){
 let w=await workflow(env,userId,workflowId);if(!['ready','processing'].includes(w.state))return workflowView(env,userId,workflowId);
 const before=await steps(env,w.id),expectedStep=requestedStep??((before.filter(s=>s.state==='completed').at(-1)?.ordinal??0)+1);
 assert(Number.isSafeInteger(expectedStep)&&expectedStep>=1&&expectedStep<=ACCOUNT_STEP_CEILING,'VALIDATION','步骤编号无效');
 const token=id('lease'),nowMs=Date.now();const claim=await env.DB.prepare(`UPDATE ai_workflows SET state='processing',lease_token=?,lease_until_ms=?,updated_at=? WHERE id=? AND user_id=? AND (state='ready' OR (state='processing' AND COALESCE(lease_until_ms,0)<=?)) AND ?=1+COALESCE((SELECT MAX(ordinal) FROM ai_workflow_steps WHERE workflow_id=ai_workflows.id AND state='completed'),0) RETURNING *`).bind(token,nowMs+LEASE_MS,new Date(nowMs).toISOString(),workflowId,userId,nowMs,expectedStep).all<Workflow>();
 if(!claim.results.length)return workflowView(env,userId,workflowId);w=claim.results[0];
 let step:Step|undefined,claimed=false,pricingUsed:TextPricing|undefined;
 const seen:Unreceipted={dispatched:false,refused:false,inputTokens:0,cachedTokens:0,outputTokens:0};
 try{
  const history=await steps(env,w.id);w.coherenceReview={offered:coherenceWasOffered(history)};step=history.at(-1);if(step?.state==='completed')step=undefined;
  if(step&&w.workspace_id&&!step.response_json){const recovered=await storedReceipt(env,w,step,'response');if(recovered){step.response_json=JSON.stringify({id:recovered.value.id,usage:recovered.value.usage});step.response_object_id=recovered.id;await env.DB.prepare("UPDATE ai_workflow_steps SET state='responded',response_json=?,response_object_id=? WHERE id=?").bind(step.response_json,recovered.id,step.id).run();}}
  if(!step){
   if(history.length>=stepLimit(w)){if(!await saveCoherenceFallback(env,w))await endWorkflow(env,w,'steps_exhausted','WORKFLOW_STEP_LIMIT');return workflowView(env,userId,w.id);}
   const balance=await totals(env,w.id),wallet=w.coherenceReview.offered?await getWallet(env.DB,userId):null;
   if(balance.consumed+balance.held+w.per_step_micros>w.max_cost_micros||(wallet&&wallet.availableMicros<w.per_step_micros)){if(!await saveCoherenceFallback(env,w))await endWorkflow(env,w,'budget_exhausted','WORKFLOW_BUDGET_LIMIT');return workflowView(env,userId,w.id);}
  }
  const config=await env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(w.config_version_id).first<IntegrationRow>();assert(config,'WORKFLOW_CONFIG_CHANGED','原模型配置不存在，任务已停止',409);
  const pricing=textConfigurationPricing({...config,public_config_json:w.pricing_json});verifiedTextPricing(pricing,config.provider);pricingUsed=pricing;
  if(!step?.response_json){const expectedPricing=effectiveDesignPricing(textConfigurationPricing(config),JSON.parse(w.requirements_json).designBrief?.version==='db-3');assert(config.status==='active'&&config.test_status==='passed'&&pricingIdentity(expectedPricing)===pricingIdentity(pricing),'WORKFLOW_CONFIG_CHANGED','模型配置已停用或更换，原任务停止；请重新确认新任务',409);await assertIntegrationCapability(env.DB,config.id,'text');}
  if(w.workspace_id&&history.length===0){const prepared=await prepareEditWorkspace(env,userId,w.project_id,{requestKey:w.request_key,baseVersionId:w.base_version_id!,scope:JSON.parse(w.scope_json)}),requirements=JSON.parse(w.requirements_json);requirements.availableAssets=workflowAvailableAssets(await listMedia(env,userId,w.project_id),JSON.parse(prepared.assets_json));requirements.workspace={id:prepared.id,revision:prepared.revision,files:await listEditFiles(env,userId,prepared.id)};w.requirements_json=boundedJson(requirements);await env.DB.prepare('UPDATE ai_workflows SET requirements_json=? WHERE id=? AND lease_token=? AND lease_until_ms>'+editNowSql).bind(w.requirements_json,w.id,w.lease_token).run();}
  if(!step){const stepId=id('step'),reservationId=id('res'),now=new Date().toISOString();await env.DB.prepare('INSERT INTO ai_workflow_steps(id,workflow_id,ordinal,reservation_id,created_at,updated_at) VALUES(?,?,?,?,?,?)').bind(stepId,w.id,history.length+1,reservationId,now,now).run();step={id:stepId,workflow_id:w.id,ordinal:history.length+1,reservation_id:reservationId,state:'preparing',response_json:null,tool_results_json:null,error_code:null,created_at:now,updated_at:now};}
  let result:any=step.response_json?(w.workspace_id?(await storedReceipt(env,w,step,'response'))?.value:JSON.parse(step.response_json)):null;
  if(w.workspace_id&&step.response_json)assert(result,'WORKFLOW_HISTORY_INVALID','原模型响应副本缺失，不能再次派发',503);
  if(!result){
   if(w.workspace_id)await ownedEditWorkspace(env,userId,w.workspace_id,true);
   // Build private image payload and validate the original configuration BEFORE
   // the irreversible dispatch claim. A deleted image cannot trigger paid work.
   const input=await requestInput(env,w,history.filter(s=>s.ordinal<step!.ordinal)),secret=await integrationSecret(env,config);
   const roundInstruction=requiresExplicitSiteEditFinish(w)?`\n这是第 ${step.ordinal} 轮；逐项完成本次请求后明确 finish，不为凑轮数重复读取。最迟不超过第 ${stepLimit(w)} 轮。`:JSON.parse(w.requirements_json).designBrief?.version==='db-3'?`\n这是第 ${step.ordinal} 轮；按冻结蓝图与范围完成有信息量的页面，容量上限不要求填满。最迟不超过第 ${stepLimit(w)} 轮。`:`\n这是第 ${step.ordinal} 轮；请在 3 轮内完成，最迟不超过第 ${stepLimit(w)} 轮。`;
   const request=buildTextProviderRequest({...pricing,stream:pricing.stream!==false},{model:pricing.model,instructions:workflowRules(w)+(w.workspace_id?'\n这是大型网站文件工作区。禁止整包 manifest.json。用 list_files/read_fragment/find_text 读取局部，再 propose_edits。文件未读取部分必须原样保留。工具中的 revision 与 spanRef 只对该修订有效。':'')+roundInstruction,input,tools:w.workspace_id?PROJECTED_WORKFLOW_TOOLS:await directTools(env,userId,w),parallel_tool_calls:false,tool_choice:'required',include:['reasoning.encrypted_content'],max_output_tokens:pricing.maxOutputTokens,service_tier:'default',store:false,truncation:'disabled',prompt_cache_options:{mode:'implicit',ttl:pricing.cacheTtl},prompt_cache_key:await sha256(userId)});
    Object.assign(seen,requestTokens(String(request.body.instructions??''),Array.isArray(request.body.input)?request.body.input:[],request.body.tools,history.some(s=>s.state==='completed')));
    const prior=await env.DB.prepare('SELECT state FROM api_reservations WHERE id=?').bind(step.reservation_id).first<{state:string}>();
   if(prior&&prior.state!=='reserved'){
     // An earlier request sent this round and never came back (the lease has run out, so it no longer owns the task).
     let reopened=false;
     if(fromMessage(w)&&!w.workspace_id&&['dispatching','uncertain'].includes(prior.state)){
      try{const outcome=await settleUnreceipted(env,w,step,pricing,{...seen,dispatched:true,outputTokens:storedOutputTokens(step)},'AI_PROVIDER_UNCERTAIN');if(!outcome.retry){await endWorkflow(env,w,'failed','AI_PROVIDER_INTERRUPTED');return workflowView(env,userId,w.id);}reopened=true;}
      catch{reopened=false;}
     }
     if(!reopened){if(['dispatching','uncertain'].includes(prior.state))await markUncertain(env.DB,step.reservation_id);await env.DB.prepare("UPDATE ai_workflow_steps SET state='uncertain',error_code='AI_PROVIDER_UNCERTAIN',updated_at=? WHERE id=?").bind(new Date().toISOString(),step.id).run();await endWorkflow(env,w,'uncertain','AI_PROVIDER_UNCERTAIN');return workflowView(env,userId,w.id);}
    }
   assert(await env.DB.prepare("SELECT 1 FROM ai_workflows WHERE id=? AND lease_token=? AND state='processing' AND lease_until_ms>"+editNowSql).bind(w.id,w.lease_token).first(),'WORKFLOW_LEASE_LOST','任务已由原步骤的另一请求接管',409);
   const workflowGuard={workflowId:w.id,leaseToken:w.lease_token!};
   await reserve(env.DB,{id:step.reservation_id,userId,providerId:w.provider_id,amountMicros:w.per_step_micros,requestKey:`workflow:${w.id}:${step.ordinal}`+(step.attempts?`:r${step.attempts}`:''),requestHash:w.request_hash,workflowGuard});
   assert(await claimReservation(env.DB,step.reservation_id,undefined,workflowGuard),'AI_DISPATCH_CONFLICT','任务已派发或账户权限发生变化',409);claimed=true;
   await env.DB.prepare("UPDATE ai_workflow_steps SET state='dispatching',updated_at=? WHERE id=?").bind(new Date().toISOString(),step.id).run();
   assert(await env.DB.prepare("SELECT 1 FROM ai_workflows WHERE id=? AND lease_token=? AND state='processing' AND lease_until_ms>"+editNowSql).bind(w.id,w.lease_token).first(),'WORKFLOW_LEASE_LOST','任务派发所有权已变化，原预算保留等待核对',409);
    // A long page takes minutes to write; the lease is renewed for as long as the stream keeps arriving.
    seen.dispatched=true;const live=liveProgress(env,step.id,[...pricingTerms(w.pricing_json),config.provider],w.workspace_id?null:w.manifest_json,foundationFromRequirements(w.requirements_json));
    const startedAtMs=Date.now(),response=await fetchWithoutRedirect(request.url,{method:'POST',headers:{Authorization:`Bearer ${secret.apiKey}`,'Content-Type':'application/json','X-Client-Request-Id':step.id+(step.attempts?'-r'+step.attempts:'')},body:stringify(request.body),signal:AbortSignal.timeout(fromMessage(w)?600000:180000)},runtime.fetch??fetch);
    if(!response.ok)seen.refused=true;
    assert(response.ok,'AI_PROVIDER_UNCERTAIN','模型响应或费用未知，原预占保留，任务不会自动重发',502);result=await readTextProviderResponse(response,pricing,startedAtMs,{onProgress:progress=>{seen.progress=progress;live(progress);},onActivity:leaseHeartbeat(env,w)});seen.received=result;
   // Save provider evidence before validating/settling; response acknowledgement
   // loss can recover locally, without any additional billable HTTP request.
   if(w.workspace_id){const object=await putEditObject(env,await receiptWorkspace(env,w),'response:'+step.id,'response',boundedJson(result));step.response_object_id=object.id;step.response_json=JSON.stringify({id:result.id,model:result.model,status:result.status,usage:result.usage});}
   else step.response_json=boundedJson(result);
   await env.DB.prepare("UPDATE ai_workflow_steps SET state='responded',response_json=?,response_object_id=?,updated_at=? WHERE id=? AND reservation_id=? AND state IN ('preparing','dispatching','responded','uncertain')").bind(step.response_json,step.response_object_id??null,new Date().toISOString(),step.id,step.reservation_id).run();
   // The live draft is display material: clearing it is best effort and separate from the accounting statements
   // (a database that has not received migration 0062 yet simply has nothing to clear).
   try{await env.DB.prepare('UPDATE ai_workflow_steps SET progress_json=NULL,progress_draft=NULL WHERE id=?').bind(step.id).run();}catch{/* display only */}
  }
  assertTextProviderResponse(pricing,result);
  await settle(env.DB,{reservationId:step.reservation_id,actualMicros:textProviderUsageCost(pricing,result)});
  assert(result.status==='completed','AI_OUTPUT_INCOMPLETE','本轮输出未完成，已按实际用量结算',422);
  assert(Array.isArray(result.output)&&result.output.every((o:any)=>['function_call','reasoning','message'].includes(o.type)),'WORKFLOW_OUTPUT_INVALID','模型返回了未开放的工具类型',422);
  const calls=result.output.filter((o:any)=>o.type==='function_call');assert(calls.length>=1&&calls.length<=8&&calls.every((call:any)=>typeof call.call_id==='string'&&call.call_id.length>0&&typeof call.name==='string'&&typeof call.arguments==='string')&&new Set(calls.map((call:any)=>call.call_id)).size===calls.length,'WORKFLOW_OUTPUT_INVALID','每轮需返回 1 至 8 个具有唯一编号的本地工具调用',422);
  // DeepSeek may return parallel calls despite parallel_tool_calls:false. Execute
  // the validated batch sequentially; finish must be the sole finalizing call.
  assert(calls.every((call:any,index:number)=>!['finish','complete_render_review'].includes(call.name)||index===calls.length-1),'WORKFLOW_OUTPUT_INVALID','方案完成操作必须位于本轮工具的最后',422);
  assert(await env.DB.prepare("SELECT 1 FROM ai_workflows WHERE id=? AND lease_token=? AND state='processing' AND lease_until_ms>"+editNowSql).bind(w.id,w.lease_token).first(),'WORKFLOW_LEASE_LOST','本地处理已由其他请求接管，请查询原任务',409);
  const savedTool=w.workspace_id?await storedReceipt(env,w,step,'tool'):null;
  w.activeStepId=step.id;
  const executedTools:ToolResult[]=[];
  if(savedTool){assert(Array.isArray(savedTool.value)&&savedTool.value.length===calls.length&&savedTool.value.every((tool:ToolResult,index:number)=>tool.callId===calls[index].call_id),'WORKFLOW_HISTORY_INVALID','已保存工具回执与原始调用不一致',503);executedTools.push(...savedTool.value);}
  else for(const call of calls)executedTools.push(await executeTool(env,w,call));
  // Legacy/new-site one-pass behavior stays frozen. A new existing-site edit
  // must explicitly finish after ALL requested pages/files, not its first valid
  // write. Quoted/projected tasks keep their explicit step-by-step contract.
  if(fromMessage(w)&&!requiresExplicitSiteEditFinish(w)&&!w.workspace_id&&!w.candidate_id&&w.manifest_json!==initialManifestJson(w)){
   const automatic:ToolResult[]=[],selectedProtocol=hasSelectedEditProtocol(w);
   if(w.validated_hash!==await sha256(w.manifest_json))automatic.push(await executeTool(env,w,{name:'check_preview',call_id:'auto-check',arguments:'{}'}));
   if(w.validated_hash===await sha256(w.manifest_json)&&(!selectedProtocol||!executedTools.some(t=>t.name==='finish')))automatic.push(await executeTool(env,w,{name:'finish',call_id:'auto-finish',arguments:'{}'}));
   // Attach server finalization to an existing model call receipt. Do not add
   // orphan function_call_output IDs which the provider never requested.
   if(selectedProtocol&&automatic.length){const completion=automatic.at(-1)!,receipt=executedTools.at(-1)!;
    receipt.result={...receipt.result,autoCompletion:{tool:completion.name,...completion.result},...(completion.result.ok===false?{ok:false,code:completion.result.code??'PREVIEW_CHECK_REQUIRED',message:completion.result.message??'候选尚未保存，请查看检查问题',next:'候选尚未保存。请按 autoCompletion 的失败原因处理；不得声称已经完成或采用。'}:completion.result.candidateId?{candidateId:completion.result.candidateId,previewUrl:completion.result.previewUrl,next:'Candidate saved for preview; it has not been adopted or published.'}:{})};
   }
  }
  const executed=executedTools.at(-1)!;
  if(executed.name==='finish'&&executed.result?.candidateId)w.candidate_id=executed.result.candidateId;
  if(w.workspace_id){const object=savedTool??await putEditObject(env,await receiptWorkspace(env,w),'tool:'+step.id,'tool',boundedJson(executedTools));step.tool_object_id=object.id;}
  const reviewCompleted=!!JSON.parse(w.requirements_json).renderReview&&executed.name==='complete_render_review'&&executed.result?.reviewCompleted===true;
  const nextState=w.candidate_id||reviewCompleted?'succeeded':step.ordinal>=stepLimit(w)?'steps_exhausted':'ready';
  const nextError=nextState==='steps_exhausted'?'WORKFLOW_STEP_LIMIT':null,updated=new Date().toISOString(),guard=id('guard'),reply=stepReply(result,executed,calls.at(-1),[...pricingTerms(w.pricing_json),config.provider]);
  await env.DB.batch([
   env.DB.prepare('INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM ai_workflows WHERE id=? AND lease_token=? AND lease_until_ms>'+editNowSql+') THEN 1 ELSE 0 END').bind(guard,w.id,w.lease_token),
   env.DB.prepare("UPDATE ai_workflow_steps SET state='completed',tool_results_json=?,tool_object_id=?,public_reply=?,updated_at=? WHERE id=?").bind(boundedJson(w.workspace_id?executedTools.map(tool=>({name:tool.name,callId:tool.callId,result:{ok:tool.result?.ok,code:tool.result?.code??null}})):executedTools),step.tool_object_id??null,reply,updated,step.id),
   env.DB.prepare('UPDATE ai_workflows SET manifest_json=?,requirements_json=?,validated_hash=?,candidate_id=?,state=?,error_code=?,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=?').bind(w.manifest_json,w.requirements_json,w.validated_hash,w.candidate_id,nextState,nextError,updated,w.id),
   ...(JSON.parse(w.requirements_json).renderReview&&nextState==='succeeded'?[auditStatement(env.DB,userId,'design.render_review_completed','workflow',w.id,{sourceVersionId:w.base_version_id,sourceHash:JSON.parse(w.requirements_json).renderReview.sourceHash,scope:JSON.parse(w.scope_json),candidateId:w.candidate_id,verdict:reviewCompleted?JSON.parse(w.requirements_json).renderReviewOutcome.verdict:'repair_proposed',evidence:'client-sandbox-render',visualAcceptance:false},step.id)]:[]),
   ...(w.workspace_id&&nextState==='succeeded'?[env.DB.prepare("UPDATE design_edit_workspaces SET state='completed',updated_at=? WHERE id=? AND state='ready' AND candidate_id=?").bind(updated,w.workspace_id,w.candidate_id)]:[]),
   auditStatement(env.DB,userId,'ai.workflow_step','workflow',w.id,{stepId:step.id,ordinal:step.ordinal,tool:executed.name,ok:executed.result.ok,reservationId:step.reservation_id},step.id),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
  ]);
 }catch(error){
  if(!await env.DB.prepare('SELECT 1 FROM ai_workflows WHERE id=? AND lease_token=?').bind(w.id,w.lease_token).first()){
   // A stale executor cannot release the new executor's reservation or regress
   // its step. If this executor actually claimed dispatch, preserve uncertainty.
   if(claimed&&step)try{await markUncertain(env.DB,step.reservation_id);}catch{/* Settled evidence remains final. */}
   return workflowView(env,userId,workflowId);
  }
  if(step&&w.workspace_id&&!step.response_json){try{const recovered=await storedReceipt(env,w,step,'response');if(recovered){step.response_json=JSON.stringify({id:recovered.value.id,usage:recovered.value.usage});step.response_object_id=recovered.id;}}catch{/* Missing evidence keeps the original reservation. */}}
  let errorCode=code(error),uncertain=false;const reservation=step?await env.DB.prepare('SELECT state FROM api_reservations WHERE id=?').bind(step.reservation_id).first<{state:string}>():null;
   if(step&&fromMessage(w)&&!w.workspace_id&&['AI_OUTPUT_INCOMPLETE','WORKFLOW_OUTPUT_INVALID'].includes(errorCode)&&reservation?.state==='settled'&&(step.attempts??0)<UNRECEIPTED_RETRIES){
    // The answer arrived and was paid for, but it was cut short or held no usable tool call. That is the model's
    // slip, not the customer's: the round is asked again under a new reservation (twice at most).
    try{
     const paid=await env.DB.prepare('SELECT actual_micros FROM api_reservations WHERE id=?').bind(step.reservation_id).first<{actual_micros:number|null}>(),now=new Date().toISOString(),attempts=(step.attempts??0)+1;
     await env.DB.batch([
      env.DB.prepare("UPDATE ai_workflow_steps SET reservation_id=?,state='preparing',response_json=NULL,response_object_id=NULL,error_code=NULL,attempts=?,retired_micros=retired_micros+?,progress_json=NULL,progress_draft=NULL,updated_at=? WHERE id=? AND reservation_id=?").bind(id('res'),attempts,paid?.actual_micros??0,now,step.id,step.reservation_id),
      env.DB.prepare("UPDATE ai_workflows SET state='processing',error_code=NULL,lease_token=NULL,lease_until_ms=0,updated_at=? WHERE id=? AND lease_token=?").bind(now,w.id,w.lease_token),
      auditStatement(env.DB,null,'ai.workflow_step_repeated','workflow_step',step.id,{workflowId:w.id,ordinal:step.ordinal,reservationId:step.reservation_id,cause:errorCode,paidMicros:paid?.actual_micros??0,attempt:attempts},step.reservation_id),
     ]);
     return workflowView(env,userId,workflowId);
    }catch{/* falls through to the ordinary failure */}
   }
   if(step&&pricingUsed&&claimed&&!step.response_json&&fromMessage(w)&&!w.workspace_id&&reservation&&['dispatching','uncertain'].includes(reservation.state)&&!BILLING_INTEGRITY.includes(errorCode)){
    // Sent, but no usable receipt came back: close the round now instead of holding the customer's credit.
    try{
     if(seen.progress)seen.outputTokens=approxTokens(seen.progress.text)+seen.progress.calls.reduce((total,call)=>total+approxTokens(call.arguments),0);
     const outcome=await settleUnreceipted(env,w,step,pricingUsed,seen,errorCode);
     if(outcome.retry)await env.DB.prepare("UPDATE ai_workflows SET state='processing',error_code=NULL,lease_token=NULL,lease_until_ms=0,updated_at=? WHERE id=? AND lease_token=?").bind(new Date().toISOString(),w.id,w.lease_token).run();
     else await endWorkflow(env,w,'failed','AI_PROVIDER_INTERRUPTED');
     return workflowView(env,userId,workflowId);
    }catch{/* The ledger did not accept it: the reservation stays on hold, as before. */}
   }
   if(reservation?.state==='reserved'&&!claimed){await releaseConfirmedUnused(env.DB,step!.reservation_id);}
  else if(reservation&&['reserved','dispatching','uncertain'].includes(reservation.state)){uncertain=true;try{await markUncertain(env.DB,step!.reservation_id);}catch{/* Preserve both holds. */}}
  if(uncertain&&errorCode==='WORKFLOW_TEMPORARILY_UNAVAILABLE')errorCode='AI_PROVIDER_UNCERTAIN';
  if(['AI_PRICING_MISMATCH','AI_USAGE_INVALID','COST_EXCEEDS_RESERVATION'].includes(errorCode)&&reservation){await env.DB.batch([env.DB.prepare('UPDATE provider_pools SET enabled=0,updated_at_ms=? WHERE provider_id=?').bind(Date.now(),w.provider_id),auditStatement(env.DB,null,'ai.workflow_budget_suspended','provider',w.provider_id,{workflowId:w.id,code:errorCode},w.id)]);}
  // A persisted response with valid cost can be replayed locally after a transient
  // settlement/storage error. Unknown billing never permits automatic HTTP retry.
  const preparing=!!w.workspace_id&&!step&&!!await env.DB.prepare("SELECT 1 FROM design_edit_workspaces WHERE id=? AND state='preparing'").bind(w.workspace_id).first();
  const localRecovery=(!!step?.response_json||preparing)&&!['AI_PRICING_MISMATCH','AI_USAGE_INVALID','COST_EXCEEDS_RESERVATION'].includes(errorCode)&&['STORAGE_FAILURE','WORKFLOW_TEMPORARILY_UNAVAILABLE','AI_PROVIDER_UNCERTAIN','DESIGN_MEMORY_BUSY','EDIT_WORKSPACE_BUSY','EDIT_OBJECT_UNCONFIRMED','EDIT_OBJECT_UNAVAILABLE','WORKFLOW_LEASE_LOST'].includes(errorCode);
  if(step&&!localRecovery)await env.DB.prepare('UPDATE ai_workflow_steps SET state=?,error_code=?,updated_at=? WHERE id=?').bind(uncertain?'uncertain':'failed',errorCode,new Date().toISOString(),step.id).run();
  if(localRecovery)await env.DB.prepare("UPDATE ai_workflows SET state='processing',error_code=?,lease_token=NULL,lease_until_ms=0,updated_at=? WHERE id=? AND lease_token=?").bind(errorCode,new Date().toISOString(),w.id,w.lease_token).run();
  else await endWorkflow(env,w,uncertain?'uncertain':'failed',errorCode);
 }
 return workflowView(env,userId,workflowId);
}

const reconciliationSchema=z.discriminatedUnion('outcome',[
 z.object({outcome:z.literal('confirmed_unused'),evidence:z.string().trim().min(10).max(2000)}).strict(),
 z.object({outcome:z.literal('confirmed_cost'),actualMicros:z.number().int().min(0).max(1_000_000_000),evidence:z.string().trim().min(10).max(2000)}).strict(),
]);
export async function reconcileWorkflowStep(env:Env,actorId:string,stepId:string,raw:z.infer<typeof reconciliationSchema>){
 const actor=await env.DB.prepare("SELECT 1 FROM users WHERE id=? AND role='owner' AND status='active'").bind(actorId).first();assert(actor,'FORBIDDEN','仅平台所有者可确认费用',403);
 const input=reconciliationSchema.parse(raw),s=await env.DB.prepare('SELECT * FROM ai_workflow_steps WHERE id=?').bind(stepId).first<Step>();assert(s,'NOT_FOUND','用量步骤不存在',404);
 const w=await env.DB.prepare('SELECT * FROM ai_workflows WHERE id=?').bind(s.workflow_id).first<Workflow>();assert(w&&(s.state==='uncertain'||s.error_code==='COST_RECONCILED')&&(w.state==='uncertain'||w.error_code==='COST_RECONCILED'),'INVALID_STATE','本步骤不处于人工费用核对状态',409);
 await auditStatement(env.DB,actorId,'ai.workflow_reconciliation_requested','workflow_step',s.id,input,s.id).run();
 const reservation=input.outcome==='confirmed_unused'?await releaseConfirmedUnused(env.DB,s.reservation_id):await settle(env.DB,{reservationId:s.reservation_id,actualMicros:input.actualMicros});
 await env.DB.batch([
  env.DB.prepare("UPDATE ai_workflow_steps SET state='failed',error_code='COST_RECONCILED',updated_at=? WHERE id=?").bind(new Date().toISOString(),s.id),
  env.DB.prepare("UPDATE ai_workflows SET state='failed',error_code='COST_RECONCILED',lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=?").bind(new Date().toISOString(),w.id),
  auditStatement(env.DB,actorId,'ai.workflow_reconciled','workflow_step',s.id,{outcome:input.outcome,actualMicros:reservation.actualMicros,reservationId:s.reservation_id,workflowId:w.id},s.id),
 ]);
 return {reconciled:true,reservationState:reservation.state,workflowState:'failed',redispatched:false};
}

export const aiWorkflowRoutes=new Hono<App>();aiWorkflowRoutes.use('*',requireAuth);
aiWorkflowRoutes.get('/admin/presentation-policy',requireRole('owner','admin'),async c=>ok(c,{policy:await loadPresentationPolicy(c.env),capabilities:presentationCapabilities,appliesTo:'new-workflows'}));
aiWorkflowRoutes.put('/admin/presentation-policy',requireRole('owner'),async c=>{
 const policy=await body(c,presentationPolicySchema);assertPresentationCapabilities(policy);
 const actor=c.get('auth').user.id,now=new Date().toISOString();
 await c.env.DB.batch([
  c.env.DB.prepare('INSERT INTO settings(key,value_json,updated_by,updated_at) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_by=excluded.updated_by,updated_at=excluded.updated_at').bind(PRESENTATION_POLICY_KEY,JSON.stringify(policy),actor,now),
  auditStatement(c.env.DB,actor,'ai.presentation_policy_changed','settings',PRESENTATION_POLICY_KEY,{policy,appliesTo:'new-workflows'}),
 ]);
 return ok(c,{policy,capabilities:presentationCapabilities,appliesTo:'new-workflows'});
});
aiWorkflowRoutes.get('/admin/generation-policy',requireRole('owner','admin'),async c=>ok(c,{policy:await loadGenerationPolicy(c.env),appliesTo:'new-workflows',costTargetIsLimit:false}));
aiWorkflowRoutes.put('/admin/generation-policy',requireRole('owner'),async c=>{
 const policy=await body(c,generationPolicySchema),actor=c.get('auth').user.id,now=new Date().toISOString();
 await c.env.DB.batch([
  c.env.DB.prepare('INSERT INTO settings(key,value_json,updated_by,updated_at) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_by=excluded.updated_by,updated_at=excluded.updated_at').bind(GENERATION_POLICY_KEY,JSON.stringify(policy),actor,now),
  auditStatement(c.env.DB,actor,'ai.generation_policy_changed','settings',GENERATION_POLICY_KEY,{policy,appliesTo:'new-workflows'}),
 ]);
 return ok(c,{policy,appliesTo:'new-workflows',costTargetIsLimit:false});
});
aiWorkflowRoutes.post('/projects/:project/messages',async c=>{
 const userId=c.get('auth').user.id;
 await enforceScope(c,'ai');await rateLimit(c,'ai-workflow-create',20,3600,userId);
 return ok(c,await sendDesignMessage(c.env,userId,c.req.param('project'),await body(c,designMessageSchema)),202);
});
aiWorkflowRoutes.get('/projects/:project/messages/:requestKey',async c=>ok(c,await findDesignMessage(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('requestKey'))));
aiWorkflowRoutes.get('/projects/:project/conversation',async c=>ok(c,await listConversation(c.env,c.get('auth').user.id,c.req.param('project'),c.req.query())));
aiWorkflowRoutes.get('/projects/:project/conversation/:requestKey',async c=>ok(c,await findConversationTurn(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('requestKey'))));
aiWorkflowRoutes.get('/projects/:project/workflow-quote',async c=>ok(c,await workflowQuote(c.env,c.get('auth').user.id,c.req.param('project'),c.req.query('configId'))));
aiWorkflowRoutes.get('/design-quote',async c=>ok(c,await designGenerationQuote(c.env,c.get('auth').user.id,c.req.query('configId'))));
aiWorkflowRoutes.post('/projects/:project/workflows',async c=>{await enforceScope(c,'ai');await rateLimit(c,'ai-workflow-create',20,3600,c.get('auth').user.id);return ok(c,await createWorkflow(c.env,c.get('auth').user.id,c.req.param('project'),await body(c,workflowInputSchema)),202);});
aiWorkflowRoutes.get('/projects/:project/workflows',async c=>{const userId=c.get('auth').user.id;await ownedDesignProject(c.env,userId,c.req.param('project'));const rows=await c.env.DB.prepare('SELECT id FROM ai_workflows WHERE user_id=? AND project_id=? ORDER BY created_at DESC LIMIT 30').bind(userId,c.req.param('project')).all<{id:string}>();return ok(c,{items:await Promise.all(rows.results.map(r=>workflowView(c.env,userId,r.id)))});});
aiWorkflowRoutes.get('/workflows/:id',async c=>{const userId=c.get('auth').user.id,view=await workflowView(c.env,userId,c.req.param('id'));if(view.state!=='uncertain')return ok(c,view);await releaseHeldRounds(c.env,userId);return ok(c,await workflowView(c.env,userId,view.id));});
aiWorkflowRoutes.post('/workflows/:id/continue',async c=>{const input=await body(c,z.object({step:z.number().int().min(1).max(ACCOUNT_STEP_CEILING)}).strict());await enforceScope(c,'ai');await rateLimit(c,'ai-workflow-continue',100,3600,c.get('auth').user.id);return ok(c,await continueWorkflow(c.env,c.get('auth').user.id,c.req.param('id'),{},input.step),202);});
aiWorkflowRoutes.get('/admin/workflow-steps',requireRole('owner','admin'),async c=>{
 const parsedQuery=z.object({page:z.coerce.number().int().min(1).max(100000).default(1),limit:z.coerce.number().int().min(1).max(100).default(50),state:z.enum(['preparing','dispatching','responded','completed','uncertain','failed']).optional(),userId:z.string().max(120).optional()}).safeParse(c.req.query());assert(parsedQuery.success,'VALIDATION','筛选条件无效：'+(parsedQuery.error?.issues[0]?.path??[]).map(String).join('.'));const query=parsedQuery.data;
 const where=[query.state?'s.state=?':'1=1',query.userId?'w.user_id=?':'1=1'].join(' AND '),values=[...(query.state?[query.state]:[]),...(query.userId?[query.userId]:[])];
 const rows=await c.env.DB.prepare(`SELECT s.*,w.user_id,w.project_id,w.config_version_id,w.pricing_json,w.max_cost_micros,w.state workflow_state,r.state reservation_state,r.amount_micros,r.actual_micros,r.provider_id FROM ai_workflow_steps s JOIN ai_workflows w ON w.id=s.workflow_id LEFT JOIN api_reservations r ON r.id=s.reservation_id WHERE ${where} ORDER BY s.created_at DESC,s.id DESC LIMIT ? OFFSET ?`).bind(...values,query.limit+1,(query.page-1)*query.limit).all<Record<string,any>>();
 return ok(c,{page:query.page,limit:query.limit,hasMore:rows.results.length>query.limit,items:rows.results.slice(0,query.limit).map(r=>({id:r.id,workflowId:r.workflow_id,userId:r.user_id,projectId:r.project_id,configId:r.config_version_id,providerId:r.provider_id,ordinal:r.ordinal,state:r.state,workflowState:r.workflow_state,reservationId:r.reservation_id,reservationState:r.reservation_state,reservedMicros:r.amount_micros??0,actualMicros:r.actual_micros,maxCostMicros:r.max_cost_micros,pricing:JSON.parse(r.pricing_json),usage:r.response_json?JSON.parse(r.response_json).usage??null:null,errorCode:r.error_code,createdAt:r.created_at}))});
});
aiWorkflowRoutes.post('/admin/workflow-steps/:id/reconcile',requireRole('owner'),async c=>ok(c,await reconcileWorkflowStep(c.env,c.get('auth').user.id,c.req.param('id'),await body(c,reconciliationSchema))));

