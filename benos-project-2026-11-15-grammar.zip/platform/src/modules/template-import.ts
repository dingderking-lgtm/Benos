import { Hono } from 'hono';
import type { Env } from '../env';
import { ok,type App } from '../lib/http';
import { assert } from '../lib/errors';
import { sha256 } from '../lib/crypto';
import { readTemplateZip,MAX_IMPORT_ZIP_BYTES } from '../lib/template-unzip';
import { requireAuth,rateLimit } from './auth';
import { boundedBytes,saveMedia,inspectMediaBytes } from './media';
import { ownedDesignProject,saveDesignCandidate } from './design-workspace';
import { validateSiteAssets } from './template-contract';
import { serializeDesignManifest } from '../lib/design-storage';
import { starterPackageManifest,starterPackageFile } from '../lib/starter-packages';
type PackageFile={file:string;bytes:Uint8Array};
/** A complete, validated site (manifest + the bytes of every asset) becomes the first proposal of an empty
 * project: each asset is saved to the project's media and the manifest is pointed at the saved copies. */
async function importSiteFiles(env:Env,userId:string,projectId:string,source:unknown,files:PackageFile[],archiveHash:string){
 const project=await ownedDesignProject(env,userId,projectId);assert(project.current_version_id===null,'TEMPLATE_PROJECT_NOT_EMPTY','请新建一个项目导入完整模板，已有设计与业务内容将继续保留',409);
 const checked=await validateSiteAssets(source,files);assert(checked.valid,'TEMPLATE_INVALID','模板未通过结构、媒体清单或 SHA256 校验',422);
 serializeDesignManifest(source);
 // Inspect all actual bytes before storing anything: raster containers, GIF LZW,
 // safe SVG XML and ordinary PDF downloads each have independent validators.
 for(const file of files)await inspectMediaBytes(file.bytes);
 const manifest=structuredClone(source) as any;let serialized=JSON.stringify(manifest);
 for(const file of files){const media=await saveMedia(env,userId,projectId,{bytes:file.bytes,fileName:file.file.split('/').at(-1)!,requestKey:'template-import:'+await sha256(projectId+':'+archiveHash+':'+file.file)}),asset=manifest.assets.find((a:{file:string})=>a.file===file.file);serialized=serialized.split(asset.path).join(media.assetPath);}
 return saveDesignCandidate(env,{userId,projectId,requestKey:'template-import:'+projectId+':'+archiveHash.slice(0,48),baseVersionId:null,scope:{kind:'site'},manifest:JSON.parse(serialized),source:'template'});
}
export async function importTemplatePackage(env:Env,userId:string,projectId:string,bytes:Uint8Array){
 await ownedDesignProject(env,userId,projectId);
 const parsed=await readTemplateZip(bytes);
 return importSiteFiles(env,userId,projectId,parsed.manifest,parsed.files,await sha256(bytes));
}
/** A packaged starter template (lib/starter-packages.ts): the same import, from the platform's own files. */
export async function importStarterPackage(env:Env,userId:string,projectId:string,starterId:string){
 await ownedDesignProject(env,userId,projectId);
 const manifest=await starterPackageManifest(env,starterId),files:PackageFile[]=[];
 for(const asset of manifest.assets as {file:string}[])files.push({file:asset.file,bytes:await starterPackageFile(env,starterId,asset.file)});
 return importSiteFiles(env,userId,projectId,manifest,files,await sha256('starter:'+starterId+':'+JSON.stringify(manifest.assets)+':'+manifest.site?.version));
}
export const templateImportRoutes=new Hono<App>();templateImportRoutes.use('*',requireAuth);
templateImportRoutes.post('/projects/:project/template-package',async c=>{await rateLimit(c,'template-import',20,3600,c.get('auth').user.id);await ownedDesignProject(c.env,c.get('auth').user.id,c.req.param('project'));return ok(c,await importTemplatePackage(c.env,c.get('auth').user.id,c.req.param('project'),await boundedBytes(c.req.raw.body,MAX_IMPORT_ZIP_BYTES)),201);});
