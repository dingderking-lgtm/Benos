import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { z } from 'zod';
import type { Env } from '../env';
import { AppError,assert } from '../lib/errors';
import type { HpanelConfiguration } from './hosting-hostinger';
import { ensureHostedSiteDnsTargets,normalizedHostingIp } from './hosting-dns-targets';
export { normalizedHostingIp } from './hosting-dns-targets';

type Job={id:string;siteId:string;domain:string;leaseToken:string};
type Intent={job_id:string;site_id:string;domain:string;account_username:string;hosting_order_id:number;website_ready:number;database_ready:number;ssl_setup_attempted:number};
type Readiness={ready:boolean;state?:'pending'|'awaiting_input'|'uncertain';step:string;errorCode?:string};
const sslSchema=z.object({status:z.enum(['active','installing','waiting_for_retry','failed','expired','not_installed','revoked']),is_https_redirect_enabled:z.boolean().optional(),isHttpsRedirectEnabled:z.boolean().optional()});
async function answers(domain:string,type:'A'|'AAAA'):Promise<string[]>{
 const response=await fetchWithoutRedirect('https://cloudflare-dns.com/dns-query?name='+encodeURIComponent(domain)+'&type='+type,{headers:{accept:'application/dns-json'},signal:AbortSignal.timeout(10000)});
 assert(response.ok,'DNS_UNAVAILABLE','域名解析暂未核对完成',502);
 const raw=await response.text();assert(raw.length<=65536,'DNS_UNAVAILABLE','域名解析响应无效',502);
 let data:any;try{data=JSON.parse(raw);}catch{throw new AppError('DNS_UNAVAILABLE','域名解析响应无效',502);}
 assert(data?.Status===0||data?.Status===3,'DNS_UNAVAILABLE','域名解析暂未核对完成',502);
 if(data.Status===3)return [];
 assert(data.Answer===undefined||Array.isArray(data.Answer),'DNS_UNAVAILABLE','域名解析响应无效',502);
 return (data.Answer||[]).filter((row:any)=>row?.type===(type==='A'?1:28)).map((row:any)=>String(row.data));
}
async function sslRequest(token:string,path:string,method:'GET'|'POST'|'PATCH'='GET',payload?:unknown):Promise<unknown>{
 assert(token.length>=16&&!/[\r\n]/.test(token),'HOSTINGER_TOKEN_REQUIRED','托管供应商凭据尚未配置',503);
 let response:Response;try{response=await fetchWithoutRedirect('https://developers.hostinger.com'+path,{method,headers:{Authorization:'Bearer '+token,Accept:'application/json',...(method!=='GET'?{'Content-Type':'application/json'}:{})},body:method==='GET'?undefined:JSON.stringify(payload??{}),signal:AbortSignal.timeout(12000)});}catch{throw new AppError('HOSTINGER_RESULT_UNCERTAIN','证书配置结果尚未确认，请稍后核对',502);}
 if(!response.ok)throw new AppError(response.status===401||response.status===403?'HOSTINGER_AUTH_REQUIRED':response.status===429?'HOSTINGER_RATE_LIMITED':'HOSTINGER_RESULT_UNCERTAIN','证书配置结果尚未确认，请稍后核对',502);
 const raw=await response.text();assert(raw.length<=65536,'HOSTINGER_RESPONSE_INVALID','证书状态响应无效',502);
 try{return raw?JSON.parse(raw):{};}catch{throw new AppError('HOSTINGER_RESPONSE_INVALID','证书状态响应无效',502);}
}

/** Official contract: hostinger/api-php-sdk docs/Api/HostingSSLApi.md.
 * This only controls the new website recorded for this job. It neither writes
 * DNS nor changes nameservers. The signed bootstrap still proves the exact site
 * identity before any database or CMS password is sent. */
export async function ensureInitialHostingHttps(env:Env,config:HpanelConfiguration,token:string,job:Job):Promise<Readiness>{
 const intent=await env.DB.prepare('SELECT * FROM hosting_provider_intents WHERE job_id=?').bind(job.id).first<Intent>();
 assert(intent&&intent.site_id===job.siteId&&intent.domain===job.domain&&intent.account_username===config.accountUsername&&intent.hosting_order_id===config.hostingOrderId&&intent.website_ready===1&&intent.database_ready===1,'HOSTINGER_INTENT_CONFLICT','证书任务与已创建网站身份不符',409);
 const ownsLease=()=>env.DB.prepare('SELECT 1 FROM provisioning_jobs WHERE id=? AND site_id=? AND lease_token=? AND lease_until>?').bind(job.id,job.siteId,job.leaseToken,new Date().toISOString()).first();
 assert(await ownsLease(),'HOSTING_LEASE_LOST','安装任务已由其他工作进程接管',409);
 const targets=await ensureHostedSiteDnsTargets(env,config,token,job);
 const [a,aaaa]=await Promise.all([answers(job.domain,'A'),answers(job.domain,'AAAA')]);
 const observed=[...a.map(value=>({type:'A',value})),...aaaa.map(value=>({type:'AAAA',value}))];
 const matches=observed.length>0&&observed.every(row=>{const ip=normalizedHostingIp(row.value);return ip&&targets.some(target=>target.type===row.type&&normalizedHostingIp(target.value)===ip);});
 if(!matches)return {ready:false,state:'awaiting_input',step:'verify_dns_records',errorCode:'DOMAIN_DNS_REQUIRED'};
 const path='/api/hosting/v1/accounts/'+encodeURIComponent(config.accountUsername)+'/websites/'+encodeURIComponent(job.domain)+'/ssl';
 const status=sslSchema.safeParse(await sslRequest(token,path+'/status'));
 assert(status.success,'HOSTINGER_RESPONSE_INVALID','证书状态响应无效',502);
 const stamp=new Date().toISOString();
 const recorded=await env.DB.prepare('UPDATE hosting_provider_intents SET ssl_status=?,ssl_checked_at=?,dns_verified_at=?,updated_at=? WHERE job_id=? AND EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND lease_token=? AND lease_until>?) RETURNING job_id').bind(status.data.status,stamp,stamp,stamp,job.id,job.id,job.leaseToken,stamp).first();
 assert(recorded,'HOSTING_LEASE_LOST','安装任务已由其他工作进程接管',409);
 if(status.data.status==='active'){
  const redirect=status.data.is_https_redirect_enabled??status.data.isHttpsRedirectEnabled;
  assert(typeof redirect==='boolean','HOSTINGER_RESPONSE_INVALID','证书跳转状态无效',502);
  if(!redirect){
   assert(await ownsLease(),'HOSTING_LEASE_LOST','安装任务已由其他工作进程接管',409);
   // Sets a desired boolean (not a flip): safe to reconcile GET before retrying.
   await sslRequest(token,path+'/https-redirect/toggle','PATCH',{is_enabled:true});
   return {ready:false,state:'pending',step:'verify_https_redirect'};
  }
  await env.DB.prepare('UPDATE hosting_provider_intents SET https_ready_at=?,updated_at=? WHERE job_id=? AND EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND lease_token=? AND lease_until>?)').bind(stamp,stamp,job.id,job.id,job.leaseToken,stamp).run();
  return {ready:true,step:'https_ready'};
 }
 if(status.data.status==='installing'||status.data.status==='waiting_for_retry')return {ready:false,state:'pending',step:'wait_https_certificate'};
 if(status.data.status==='failed'||status.data.status==='revoked')throw new AppError('HOSTING_SSL_REVIEW_REQUIRED','证书签发需要平台核对域名配置',409);
 if(intent.ssl_setup_attempted)return {ready:false,state:'uncertain',step:'wait_https_certificate',errorCode:'HOSTING_SSL_UNCONFIRMED'};
 const claimed=await env.DB.prepare('UPDATE hosting_provider_intents SET ssl_setup_attempted=1,updated_at=? WHERE job_id=? AND ssl_setup_attempted=0 AND EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND lease_token=? AND lease_until>?) RETURNING job_id').bind(stamp,job.id,job.id,job.leaseToken,stamp).first();
 assert(claimed,'HOSTING_LEASE_LOST','证书任务已由其他工作进程接管',409);
 await sslRequest(token,path+'/setup','POST');
 return {ready:false,state:'pending',step:'wait_https_certificate'};
}
