import { z } from 'zod';
import type { Env,User } from '../env';
import { assert,AppError } from '../lib/errors';
import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { id,sha256,decryptSecret } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { verifiedTextPricing,textReservationCost,textProvider,type TextPricing } from './ai-billing';
import { buildTextProviderRequest,readTextProviderResponse,assertTextProviderResponse,textProviderUsageCost } from './text-provider-adapter';
import { verifiedImagePricing,createImageTestRequest,imageTestReservation,imageResponseUsage,validateImageTestResponse } from '../lib/image-billing';
import { boundedBytes } from './media';

type Config={deleted_at?:string|null;id:string;kind:string;provider:string;status:string;public_config_json:string;secret_ciphertext:string|null;test_status:string;tested_at:string|null;capability_test_id:string|null;capability_tested_at:string|null};
type Pricing=TextPricing&{providerPoolId:string;protocol:string};
type TestRow={id:string;config_id:string;actor_id:string;provider_id:string;request_key:string;payload_hash:string;state:string;accounting_state:string;reserved_micros:number;actual_micros:number|null;request_json:string;pricing_json:string;response_json:string|null;usage_json:string|null;provider_response_id:string|null;error_code:string|null;created_at:string;updated_at:string;completed_at:string|null};
export interface IntegrationTestRuntime{fetch?:typeof fetch;nowMs?:number;}
export const functionalTestInput=z.object({requestKey:z.string().min(16).max(128).regex(/^[a-zA-Z0-9_-]+$/),quoteHash:z.string().regex(/^[a-f0-9]{64}$/),maxCostMicros:z.number().int().positive().max(100_000_000_000),confirmedCharge:z.literal(true)}).strict();
export const operationsBudgetInput=z.object({limitMicros:z.number().int().min(0).max(100_000_000_000),reason:z.string().trim().min(3).max(500)}).strict();
export const functionalReconciliationInput=z.discriminatedUnion('outcome',[z.object({outcome:z.literal('confirmed_unused'),evidence:z.string().trim().min(10).max(2000)}).strict(),z.object({outcome:z.literal('confirmed_cost'),actualMicros:z.number().int().min(0).max(100_000_000_000),evidence:z.string().trim().min(10).max(2000)}).strict()]);
const stamp=(runtime:IntegrationTestRuntime)=>new Date(runtime.nowMs??Date.now()).toISOString();
function view(job:TestRow){return {id:job.id,configId:job.config_id,providerId:job.provider_id,requestKey:job.request_key,state:job.state,accountingState:job.accounting_state,reservedMicros:job.reserved_micros,actualMicros:job.actual_micros,providerResponseId:job.provider_response_id,errorCode:job.error_code,createdAt:job.created_at,updatedAt:job.updated_at,completedAt:job.completed_at};}
async function configRow(env:Env,configId:string,includeDeleted=false){const config=await env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(configId).first<Config>();assert(config,'NOT_FOUND','服务配置不存在',404);assert(includeDeleted||!config.deleted_at,'CONFIG_DELETED','此服务配置已删除',409);return config;}
async function fingerprint(config:Config){return sha256(JSON.stringify([config.id,config.kind,config.provider,config.public_config_json]));}
async function testRow(env:Env,testId:string,configId?:string){const row=await env.DB.prepare(`SELECT * FROM integration_function_tests WHERE id=? ${configId?'AND config_id=?':''}`).bind(...(configId?[testId,configId]:[testId])).first<TestRow>();assert(row,'NOT_FOUND','运营测试记录不存在',404);return row;}
function testPricing(config:Config){
 assert(config.kind==='text','TEST_KIND_UNSUPPORTED','此配置类型不使用 AI 功能测试',409);
 let pricing:Pricing;try{pricing=JSON.parse(config.public_config_json);}catch{throw new AppError('AI_BILLING_UNVERIFIED','配置计费信息无效',409);}
 verifiedTextPricing(pricing,config.provider);assert(/^[a-zA-Z0-9_-]{1,100}$/.test(pricing.providerPoolId),'AI_BILLING_UNVERIFIED','计费配置无效',409);
 return {...pricing,provider:textProvider(pricing),maxOutputTokens:textProvider(pricing)==='moonshot'?1024:16};
}
export async function assertIntegrationCapability(db:D1Database,configId:string,kind:string){
 if(kind!=='text'&&kind!=='image')return;
 const config=await db.prepare('SELECT * FROM integration_configs WHERE id=?').bind(configId).first<Config>();assert(config,'NOT_FOUND','服务配置不存在',404);assert(!config.deleted_at,'CONFIG_DELETED','此服务配置已删除',409);
 if(kind==='image')verifiedImagePricing(JSON.parse(config.public_config_json),config.provider);
 // A configuration is usable once its access check passed and it is enabled; the paid capability test is optional (owner decision, 2026-11-13).
}
export async function listOperationsBudgets(env:Env){const result=await env.DB.prepare('SELECT provider_id AS providerId,limit_micros AS limitMicros,consumed_micros AS consumedMicros,reserved_micros AS reservedMicros,limit_micros-consumed_micros-reserved_micros AS availableMicros FROM operations_budgets ORDER BY provider_id').all();return {items:result.results};}
export async function setOperationsBudget(env:Env,actor:User,providerId:string,input:z.infer<typeof operationsBudgetInput>){
 assert(actor.role==='owner','FORBIDDEN','只有所有者可以配置运营测试预算',403);assert(/^[a-zA-Z0-9_-]{1,100}$/.test(providerId),'VALIDATION','供应商池名称无效');input=operationsBudgetInput.parse(input);
 assert(await env.DB.prepare('SELECT provider_id FROM provider_pools WHERE provider_id=?').bind(providerId).first(),'PROVIDER_POOL_REQUIRED','请先按真实付款收据登记供应商资金池',409);
 try{await env.DB.batch([env.DB.prepare('INSERT INTO operations_budgets(provider_id,limit_micros,updated_at) VALUES(?,?,?) ON CONFLICT(provider_id) DO UPDATE SET limit_micros=excluded.limit_micros,updated_at=excluded.updated_at').bind(providerId,input.limitMicros,new Date().toISOString()),auditStatement(env.DB,actor.id,'operations.budget.set','provider',providerId,input)]);}catch(error){if(String(error).includes('operations_budget_balance'))throw new AppError('OPERATIONS_BUDGET_HELD','运营上限不能低于已消耗与预占合计',409);throw error;}
 return listOperationsBudgets(env);
}
async function quoteDetails(env:Env,configId:string,runtime:IntegrationTestRuntime={}){
 const config=await configRow(env,configId);
 const isImage=config.kind==='image',imagePricing=isImage?verifiedImagePricing(JSON.parse(config.public_config_json),config.provider):null,pricing=imagePricing??testPricing(config);
 assert(config.status!=='active','CONFIG_ACTIVE','正式配置不能直接执行测试，请建立新版本',409);
 assert(config.test_status==='passed'&&config.tested_at&&(runtime.nowMs??Date.now())-Date.parse(config.tested_at)<86400000,'TEST_REQUIRED','请先在 24 小时内完成只读访问验证',409);
 const requiredReservationMicros=imagePricing?imageTestReservation(imagePricing):textReservationCost(pricing as Pricing),configFingerprint=await fingerprint(config);
 const textPricing=pricing as Pricing;
 // GPT-6 Sol defaults to medium reasoning, which can consume the tiny probe's
 // output allowance before its answer. Its official none setting keeps this
 // access/metering check within the already quoted 16-token spending ceiling.
 const request=imagePricing?createImageTestRequest(imagePricing):buildTextProviderRequest(textPricing,{model:textPricing.model,instructions:'Return exactly BENOS_TEST_OK and nothing else.',input:'Benos configuration capability and metering verification.',...(textPricing.model==='gpt-6-sol'?{reasoning:{effort:'none'}}:{}),max_output_tokens:textPricing.maxOutputTokens,service_tier:'default',store:false,truncation:'disabled',prompt_cache_options:{mode:'implicit',ttl:textPricing.cacheTtl},prompt_cache_key:await sha256('benos:operations:'+config.id)}).body;
 const quoteHash=await sha256(JSON.stringify([configFingerprint,request,requiredReservationMicros]));
 const [operations,provider]=await Promise.all([env.DB.prepare('SELECT limit_micros-consumed_micros-reserved_micros AS available FROM operations_budgets WHERE provider_id=?').bind(pricing.providerPoolId).first<{available:number}>(),env.DB.prepare('SELECT funded_micros-consumed_micros-reserved_micros-safety_micros AS available,enabled FROM provider_pools WHERE provider_id=?').bind(pricing.providerPoolId).first<{available:number;enabled:number}>()]);
 return {config,pricing,request,configFingerprint,quote:{available:true as const,requiredReservationMicros,operationsAvailableMicros:operations?.available??0,providerAvailableMicros:provider?.available??0,canReserve:!!provider?.enabled&&(operations?.available??0)>=requiredReservationMicros&&provider.available>=requiredReservationMicros,quoteHash,maxOutputTokens:isImage?0:textPricing.maxOutputTokens,reservationIsEstimate:isImage}};
}
export async function functionalTestQuote(env:Env,configId:string,runtime:IntegrationTestRuntime={}){try{return (await quoteDetails(env,configId,runtime)).quote;}catch(error){if(error instanceof AppError)return {available:false as const,reason:error.code,maxOutputTokens:16};throw error;}}
export async function listFunctionalTests(env:Env,configId:string){await configRow(env,configId,true);const rows=await env.DB.prepare('SELECT * FROM integration_function_tests WHERE config_id=? ORDER BY created_at DESC LIMIT 50').bind(configId).all<TestRow>();return {items:rows.results.map(view)};}
async function reserveTest(env:Env,job:TestRow,runtime:IntegrationTestRuntime){
 const nonce=id('ops_reserve'),guard=id('ops_guard'),time=stamp(runtime),db=env.DB,fresh="EXISTS(SELECT 1 FROM integration_function_tests WHERE id=?1 AND reserve_nonce=?2 AND accounting_state='none')",p=(sql:string,...v:(string|number|null)[])=>db.prepare(sql).bind(...v);
 try{await db.batch([
  p("UPDATE integration_function_tests SET reserve_nonce=? WHERE id=? AND state='created' AND accounting_state='none'",nonce,job.id),
  p(`INSERT INTO mutation_guards(id,permitted) SELECT ?3,CASE WHEN NOT ${fresh} OR (EXISTS(SELECT 1 FROM operations_budgets WHERE provider_id=?4 AND limit_micros-consumed_micros-reserved_micros>=?5) AND EXISTS(SELECT 1 FROM provider_pools WHERE provider_id=?4 AND enabled=1 AND funded_micros-consumed_micros-reserved_micros-safety_micros>=?5)) THEN 1 ELSE 0 END`,job.id,nonce,guard,job.provider_id,job.reserved_micros),
  p(`UPDATE operations_budgets SET reserved_micros=reserved_micros+?3,updated_at=?4 WHERE provider_id=?5 AND ${fresh}`,job.id,nonce,job.reserved_micros,time,job.provider_id),
  p(`UPDATE provider_pools SET reserved_micros=reserved_micros+?3,updated_at_ms=?4 WHERE provider_id=?5 AND ${fresh}`,job.id,nonce,job.reserved_micros,runtime.nowMs??Date.now(),job.provider_id),
  p(`INSERT INTO operations_budget_events(id,test_id,provider_id,kind,amount_micros,created_at) SELECT ?3,?1,?4,'reserve',?5,?6 WHERE ${fresh}`,job.id,nonce,id('ops_event'),job.provider_id,job.reserved_micros,time),
  p(`UPDATE integration_function_tests SET state='reserved',accounting_state='held',updated_at=?3 WHERE id=?1 AND ${fresh}`,job.id,nonce,time),p('DELETE FROM mutation_guards WHERE id=?',guard),
 ]);}catch(error){if(/mutation_revision_ok|operations_budget_balance|ledger_pool_balance/.test(String(error)))throw new AppError('OPERATIONS_BUDGET_INSUFFICIENT','运营预算或供应商余额不足，本次未派发',409);throw error;}
}
async function finalizeTest(env:Env,job:TestRow,actualMicros:number,outcome:'passed'|'failed',release:boolean,errorCode:string|null,runtime:IntegrationTestRuntime){
 assert(Number.isSafeInteger(actualMicros)&&actualMicros>=0&&actualMicros<=job.reserved_micros,'COST_EXCEEDS_RESERVATION','实际费用超出预占，继续保留额度待核对',409);
 const db=env.DB,nonce=id('ops_settle'),guard=id('ops_guard'),time=stamp(runtime),fresh="EXISTS(SELECT 1 FROM integration_function_tests WHERE id=?1 AND settlement_nonce=?2 AND accounting_state='held')",p=(sql:string,...v:(string|number|null)[])=>db.prepare(sql).bind(...v);
 try{await db.batch([
  p("UPDATE integration_function_tests SET settlement_nonce=? WHERE id=? AND accounting_state='held'",nonce,job.id),
  p(`INSERT INTO mutation_guards(id,permitted) SELECT ?3,CASE WHEN ${fresh} OR EXISTS(SELECT 1 FROM integration_function_tests WHERE id=?1 AND accounting_state IN ('settled','released') AND actual_micros=?4) THEN 1 ELSE 0 END`,job.id,nonce,guard,actualMicros),
  p(`UPDATE operations_budgets SET reserved_micros=reserved_micros-?3,consumed_micros=consumed_micros+?4,updated_at=?5 WHERE provider_id=?6 AND ${fresh}`,job.id,nonce,job.reserved_micros,actualMicros,time,job.provider_id),
  p(`UPDATE provider_pools SET reserved_micros=reserved_micros-?3,consumed_micros=consumed_micros+?4,updated_at_ms=?5 WHERE provider_id=?6 AND ${fresh}`,job.id,nonce,job.reserved_micros,actualMicros,runtime.nowMs??Date.now(),job.provider_id),
  p(`INSERT INTO operations_budget_events(id,test_id,provider_id,kind,amount_micros,created_at) SELECT ?3,?1,?4,?5,?6,?7 WHERE ${fresh}`,job.id,nonce,id('ops_event'),job.provider_id,release?'release':'settle',actualMicros,time),
  ...(outcome==='passed'?[p(`UPDATE integration_configs SET capability_test_id=?1,capability_tested_at=?3 WHERE id=?4 AND ${fresh}`,job.id,nonce,time,job.config_id)]:[]),
  p(`UPDATE integration_function_tests SET state=?3,accounting_state=?4,actual_micros=?5,error_code=?6,completed_at=?7,updated_at=?7 WHERE id=?1 AND ${fresh}`,job.id,nonce,outcome,release?'released':'settled',actualMicros,errorCode,time),p('DELETE FROM mutation_guards WHERE id=?',guard),
 ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('OPERATIONS_SETTLEMENT_CONFLICT','该运营测试已有不同的结算结果',409);throw error;}
}
export async function runFunctionalTest(env:Env,actor:User,configId:string,input:z.infer<typeof functionalTestInput>,runtime:IntegrationTestRuntime={}){
 assert(actor.role==='owner','FORBIDDEN','只有平台所有者可以确认付费测试',403);input=functionalTestInput.parse(input);await configRow(env,configId);const hash=await sha256(JSON.stringify([configId,input]));
 let job=await env.DB.prepare('SELECT * FROM integration_function_tests WHERE actor_id=? AND request_key=?').bind(actor.id,input.requestKey).first<TestRow>();
 if(job){assert(job.payload_hash===hash,'IDEMPOTENCY_CONFLICT','该请求编号已用于其他测试',409);if(!['created','reserved'].includes(job.state))return view(job);}
 const details=await quoteDetails(env,configId,runtime);assert(details.quote.quoteHash===input.quoteHash,'TEST_QUOTE_CHANGED','报价已变化，请重新查看并确认',409);assert(input.maxCostMicros>=details.quote.requiredReservationMicros,'TEST_LIMIT_TOO_LOW','确认的费用上限不足以覆盖所需暂预占',409);
 assert(details.config.secret_ciphertext,'INTEGRATION_NOT_CONFIGURED','测试密钥尚未配置',503);const secret=JSON.parse(await decryptSecret(details.config.secret_ciphertext,env.ENCRYPTION_KEY,configId));assert(typeof secret.apiKey==='string','INTEGRATION_NOT_CONFIGURED','测试密钥尚未配置',503);
 if(!job){assert(details.quote.canReserve,'OPERATIONS_BUDGET_INSUFFICIENT','运营预算或供应商余额不足，本次未派发',409);const testId=id('functional'),time=stamp(runtime);try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO integration_function_tests(id,config_id,actor_id,provider_id,request_key,payload_hash,quote_hash,config_fingerprint,state,reserved_micros,request_json,pricing_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,'created',?,?,?,?,?) ON CONFLICT(actor_id,request_key) DO UPDATE SET payload_hash=CASE WHEN integration_function_tests.payload_hash=excluded.payload_hash THEN integration_function_tests.payload_hash ELSE NULL END`).bind(testId,configId,actor.id,details.pricing.providerPoolId,input.requestKey,hash,input.quoteHash,details.configFingerprint,details.quote.requiredReservationMicros,JSON.stringify(details.request),JSON.stringify(details.pricing),time,time),
  auditStatement(env.DB,actor.id,'integration.functional_test_confirmed','integration',configId,{testId,quoteHash:input.quoteHash,maxCostMicros:input.maxCostMicros,requiredReservationMicros:details.quote.requiredReservationMicros}),
  env.DB.prepare('UPDATE integration_configs SET capability_test_id=NULL,capability_tested_at=NULL WHERE id=? AND EXISTS(SELECT 1 FROM integration_function_tests WHERE id=?)').bind(configId,testId),
 ]);}catch(error){if(String(error).includes('integration_function_tests.payload_hash'))throw new AppError('IDEMPOTENCY_CONFLICT','该请求编号已用于其他测试',409);throw error;}job=(await env.DB.prepare('SELECT * FROM integration_function_tests WHERE actor_id=? AND request_key=?').bind(actor.id,input.requestKey).first<TestRow>())!;assert(job.payload_hash===hash,'IDEMPOTENCY_CONFLICT','该请求编号已用于其他测试',409);}
 let dispatched=false;
 try{
  if(job.state==='created')await reserveTest(env,job,runtime);
  const claimed=await env.DB.prepare(`UPDATE integration_function_tests SET state='running',updated_at=? WHERE id=? AND state='reserved' AND accounting_state='held'
   AND EXISTS(SELECT 1 FROM provider_pools WHERE provider_id=integration_function_tests.provider_id AND enabled=1)
   AND EXISTS(SELECT 1 FROM users WHERE id=? AND role='owner') RETURNING id`).bind(stamp(runtime),job.id,actor.id).first();
  if(!claimed)return view(await testRow(env,job.id));dispatched=true;
  const rawPricing=JSON.parse(job.pricing_json),isImage=rawPricing.protocol==='images',pricing=rawPricing as Pricing,startedAtMs=Date.now();
  const response=await fetchWithoutRedirect(pricing.baseUrl+(isImage?'/images/generations':textProvider(pricing)==='moonshot'?'/chat/completions':'/responses'),{method:'POST',headers:{Authorization:`Bearer ${secret.apiKey}`,'Content-Type':'application/json','X-Client-Request-Id':job.id},body:job.request_json,signal:AbortSignal.timeout(isImage?180000:120000)},runtime.fetch??fetch);
  assert(response.ok,'TEST_PROVIDER_UNCERTAIN','模型结果或费用尚未确认',502);
  if(isImage){
   const imagePricing=verifiedImagePricing(rawPricing,details.config.provider);let result:any;
   try{result=JSON.parse(new TextDecoder().decode(await boundedBytes(response.body,17*1024*1024)));}catch{throw new AppError('IMAGE_RESPONSE_INVALID','图片测试响应格式无效，费用待核对',502);}
   const metering=imageResponseUsage(imagePricing,result);
   await env.DB.prepare('UPDATE integration_function_tests SET response_json=?,usage_json=?,provider_response_id=?,updated_at=? WHERE id=?').bind(JSON.stringify(metering.metadata),JSON.stringify(metering.usage),response.headers.get('x-request-id'),stamp(runtime),job.id).run();
   let outputError:string|null=null;try{await validateImageTestResponse(imagePricing,result);}catch(error){outputError=error instanceof AppError?error.code:'TEST_CAPABILITY_FAILED';}
   await finalizeTest(env,job,metering.actualMicros,outputError?'failed':'passed',false,outputError,runtime);
   return view(await testRow(env,job.id));
  }
  const result=await readTextProviderResponse(response,pricing,startedAtMs);
  await env.DB.prepare('UPDATE integration_function_tests SET response_json=?,usage_json=?,provider_response_id=?,updated_at=? WHERE id=?').bind(JSON.stringify(result),result.usage?JSON.stringify(result.usage):null,typeof result.id==='string'?result.id:null,stamp(runtime),job.id).run();
  assertTextProviderResponse(pricing,result);
  const actual=textProviderUsageCost(pricing,result),output=(Array.isArray(result.output)?result.output:[]).flatMap((x:any)=>x.type==='message'&&Array.isArray(x.content)?x.content:[]).filter((x:any)=>x.type==='output_text').map((x:any)=>x.text).join('');
  const passed=result.status==='completed'&&output.trim()==='BENOS_TEST_OK';await finalizeTest(env,job,actual,passed?'passed':'failed',false,passed?null:'TEST_CAPABILITY_FAILED',runtime);
 }catch(error){
  const current=await testRow(env,job.id);if(current.accounting_state==='settled'||current.accounting_state==='released')return view(current);
  const code=error instanceof AppError?error.code:dispatched?'TEST_PROVIDER_UNCERTAIN':'TEST_STORAGE_UNCONFIRMED';
  const held=current.accounting_state==='held';await env.DB.prepare('UPDATE integration_function_tests SET state=?,error_code=?,updated_at=? WHERE id=? AND accounting_state IN (\'none\',\'held\')').bind(held?'uncertain':'failed',code,stamp(runtime),job.id).run();
  if(dispatched&&['AI_USAGE_INVALID','AI_PRICING_MISMATCH','TEST_PRICING_MISMATCH','IMAGE_USAGE_INVALID','IMAGE_PRICING_MISMATCH','IMAGE_CONTRACT_BREACH','COST_EXCEEDS_RESERVATION'].includes(code))await env.DB.prepare('UPDATE provider_pools SET enabled=0,updated_at_ms=? WHERE provider_id=?').bind(runtime.nowMs??Date.now(),job.provider_id).run();
 }
 return view(await testRow(env,job.id));
}
export async function reconcileFunctionalTest(env:Env,actor:User,configId:string,testId:string,input:z.infer<typeof functionalReconciliationInput>,runtime:IntegrationTestRuntime={}){
 assert(actor.role==='owner','FORBIDDEN','只有所有者可以核对运营测试费用',403);input=functionalReconciliationInput.parse(input);const job=await testRow(env,testId,configId);
 assert(job.state==='uncertain'||(['running','reserved'].includes(job.state)&&(runtime.nowMs??Date.now())-Date.parse(job.updated_at)>180000)||job.error_code==='TEST_COST_RECONCILED','TEST_RECONCILIATION_STATE','该测试仍在运行或无需人工费用核对',409);
 await auditStatement(env.DB,actor.id,'integration.functional_cost_reconciliation','integration_test',job.id,input).run();
 await finalizeTest(env,job,input.outcome==='confirmed_unused'?0:input.actualMicros,'failed',input.outcome==='confirmed_unused','TEST_COST_RECONCILED',runtime);return view(await testRow(env,job.id));
}
