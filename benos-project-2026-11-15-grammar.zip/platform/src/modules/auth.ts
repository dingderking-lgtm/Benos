import { Hono } from 'hono';
import { z } from 'zod';
import type { MiddlewareHandler, Context } from 'hono';
import type { User, AuthContext, Env } from '../env';
import { AppError, assert } from '../lib/errors';
import { body, ok, type App } from '../lib/http';
import { id, randomToken, sha256, hashPassword, verifyPassword, constantTimeEqual } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { registrationStatus } from '../lib/registration-policies';

const identity = z.object({email:z.string().trim().email('请输入有效邮箱').max(254).transform(v=>v.toLowerCase()),password:z.string().min(12,'密码至少 12 位').max(128,'密码不能超过 128 位')});
const registration = identity.extend({name:z.string().trim().min(1,'请输入姓名').max(80)});
const userColumns='id,email,name,role,status,email_verified_at,created_at';
function cookieName(env: Env) { return env.APP_ENV==='production'?'__Host-benos_session':'benos_session'; }
function readCookie(c: Context<App>): string|null {
  const name=cookieName(c.env);
  for(const part of (c.req.header('cookie')||'').split(';')) {
    const i=part.indexOf('='); if(part.slice(0,i).trim()===name) return part.slice(i+1).trim();
  }
  return null;
}
function sessionCookie(env: Env, token: string, expires: Date): string {
  return `${cookieName(env)}=${token}; Path=/; HttpOnly; SameSite=Lax; Expires=${expires.toUTCString()}${env.APP_ENV==='production'?'; Secure':''}`;
}
export async function restricted(db: D1Database,userId: string,scope: string): Promise<boolean> {
  const now=new Date().toISOString();
  return !!await db.prepare('SELECT id FROM user_restrictions WHERE user_id=? AND scope=? AND revoked_at IS NULL AND starts_at<=? AND (ends_at IS NULL OR ends_at>?) LIMIT 1').bind(userId,scope,now,now).first();
}
export async function enforceScope(c: Context<App>,scope: string) {
  if(await restricted(c.env.DB,c.get('auth').user.id,scope)) throw new AppError('ACCOUNT_RESTRICTED','该操作暂时受限，请联系支持',403);
}
export async function rateLimit(c: Context<App>, category: string, maximum: number, periodSeconds: number, subject?: string) {
  assert(c.env.SESSION_SECRET?.length>=32,'SERVER_NOT_CONFIGURED','平台安全配置尚未完成',503);
  const key=await sha256(`${c.env.SESSION_SECRET}:${category}:${subject||c.req.header('cf-connecting-ip')||'local'}`);
  const now=Math.floor(Date.now()/1000), windowStart=Math.floor(now/periodSeconds)*periodSeconds;
  const row=await c.env.DB.prepare('INSERT INTO rate_limits(key,window_start,count) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window_start=excluded.window_start THEN count+1 ELSE 1 END,window_start=excluded.window_start RETURNING count').bind(key,windowStart).first<{count:number}>();
  if(!row||row.count>maximum) throw new AppError('RATE_LIMITED','操作频繁，请稍后再试',429);
}
async function getAuth(c: Context<App>): Promise<AuthContext|null> {
  const token=readCookie(c); if(!token||!/^[A-Za-z0-9_-]{43}$/.test(token))return null;
  const session=await c.env.DB.prepare('SELECT id,user_id,csrf_token FROM sessions WHERE token_hash=? AND revoked_at IS NULL AND expires_at>?').bind(await sha256(token),new Date().toISOString()).first<{id:string;user_id:string;csrf_token:string}>();
  if(!session)return null;
  const user=await c.env.DB.prepare(`SELECT ${userColumns} FROM users WHERE id=?`).bind(session.user_id).first<User>();
  if(!user||await restricted(c.env.DB,user.id,'login')) return null;
  return {user,sessionId:session.id,csrfToken:session.csrf_token};
}
export const requireAuth: MiddlewareHandler<App>=async(c,next)=>{
  const auth=await getAuth(c); if(!auth)throw new AppError('UNAUTHENTICATED','请先登录',401);
  c.set('auth',auth);
  if(!['GET','HEAD','OPTIONS'].includes(c.req.method)) {
    assert(constantTimeEqual(c.req.header('X-CSRF-Token')||'',auth.csrfToken),'CSRF','页面会话已变化，请刷新后再试',403);
  }
  await next();
};
export function requireRole(...roles: User['role'][]): MiddlewareHandler<App> {
  return async(c,next)=>{assert(roles.includes(c.get('auth').user.role),'FORBIDDEN','没有该操作权限',403);await next();};
}
async function createSession(c: Context<App>,user: User) {
  const token=randomToken(), csrfToken=randomToken(), sessionId=id('ses');
  const expires=new Date(Date.now()+7*24*60*60*1000);
  const ipHash=await sha256(`${c.env.SESSION_SECRET}:${c.req.header('cf-connecting-ip')||'local'}`);
  await c.env.DB.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').bind(sessionId,await sha256(token),user.id,csrfToken,new Date().toISOString(),expires.toISOString(),ipHash).run();
  c.header('Set-Cookie',sessionCookie(c.env,token,expires));
  return {user,csrfToken};
}
export const authRoutes=new Hono<App>();
authRoutes.get('/auth/registration-status',async c=>{c.header('Cache-Control','no-store');return ok(c,await registrationStatus(c.env));});
authRoutes.get('/session',async c=>{const auth=await getAuth(c);return ok(c,auth?{user:auth.user,csrfToken:auth.csrfToken}:{user:null});});
authRoutes.get('/bootstrap',async c=>{
  const owner=await c.env.DB.prepare("SELECT id FROM users WHERE role='owner' LIMIT 1").first();
  return ok(c,{required:!owner,configured:!!(c.env.BOOTSTRAP_TOKEN||c.env.VERIFIED_BOOTSTRAP_EMAIL)&&c.env.SESSION_SECRET?.length>=32,...(!owner&&c.env.VERIFIED_BOOTSTRAP_EMAIL?{trustedOwnerEmail:c.env.VERIFIED_BOOTSTRAP_EMAIL}:{})});
});
authRoutes.post('/bootstrap',async c=>{
  await rateLimit(c,'bootstrap',5,900);
  const input=await body(c,registration.extend({token:z.string().optional()}));
  const verifiedOwner=!!c.env.VERIFIED_BOOTSTRAP_EMAIL&&input.email===c.env.VERIFIED_BOOTSTRAP_EMAIL.toLowerCase();
  assert(verifiedOwner||(c.env.BOOTSTRAP_TOKEN&&input.token&&constantTimeEqual(input.token,c.env.BOOTSTRAP_TOKEN)),'BOOTSTRAP_DENIED','初始化凭据无效',403);
  assert(!await c.env.DB.prepare("SELECT id FROM users WHERE role='owner'").first(),'ALREADY_INITIALIZED','平台已完成初始化',409);
  const userId=id('usr'), now=new Date().toISOString();
  try {
    await c.env.DB.batch([
      c.env.DB.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,?,'owner','active',?,?)").bind(userId,input.email,input.name,await hashPassword(input.password),now,now),
      auditStatement(c.env.DB,userId,'platform.bootstrap','user',userId,{},c.get('requestId'))
    ]);
  } catch { throw new AppError('BOOTSTRAP_CONFLICT','平台已初始化或邮箱已存在',409); }
  const user=await c.env.DB.prepare(`SELECT ${userColumns} FROM users WHERE id=?`).bind(userId).first<User>();
  assert(user,'STORAGE_ERROR','暂时无法读取账号',503);
  return ok(c,await createSession(c,user),201);
});
authRoutes.post('/auth/register',async c=>{
  assert(c.env.REGISTRATION_ENABLED==='true','REGISTRATION_DISABLED','注册暂未开放',403);
  assert((await registrationStatus(c.env)).ready,'POLICIES_UNAVAILABLE','服务条款或隐私说明暂不可用，暂时无法创建账号',503);
  await rateLimit(c,'register',5,3600);
  const input=await body(c,registration), userId=id('usr'),now=new Date().toISOString();
  const existing=await c.env.DB.prepare('SELECT id FROM users WHERE email=?').bind(input.email).first();
  assert(!existing,'EMAIL_EXISTS','该邮箱已注册，请登录或找回密码',409);
  const passwordHash=await hashPassword(input.password);
  await c.env.DB.batch([
    c.env.DB.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,?,'user','active',?,?)").bind(userId,input.email,input.name,passwordHash,now,now),
    auditStatement(c.env.DB,userId,'user.register','user',userId,{},c.get('requestId'))
  ]);
  const user=await c.env.DB.prepare(`SELECT ${userColumns} FROM users WHERE id=?`).bind(userId).first<User>();
  assert(user,'STORAGE_ERROR','暂时无法读取账号',503);
  return ok(c,await createSession(c,user),201);
});
authRoutes.post('/auth/login',async c=>{
  await rateLimit(c,'login-ip',30,900);
  const input=await body(c,identity);
  await rateLimit(c,'login-account',10,900,input.email);
  const row=await c.env.DB.prepare(`SELECT ${userColumns},password_hash FROM users WHERE email=?`).bind(input.email).first<User&{password_hash:string}>();
  const valid=row?await verifyPassword(input.password,row.password_hash):(await hashPassword(input.password,'benos-invalid-account'),false);
  assert(row&&valid,'LOGIN_FAILED','邮箱或密码不正确',401);
  assert(!await restricted(c.env.DB,row.id,'login'),'ACCOUNT_RESTRICTED','账户登录暂时受限，请联系支持',403);
  const {password_hash:_,...user}=row;
  await auditStatement(c.env.DB,user.id,'user.login','user',user.id,{},c.get('requestId')).run();
  return ok(c,await createSession(c,user));
});
authRoutes.post('/auth/logout',requireAuth,async c=>{
  await c.env.DB.prepare('UPDATE sessions SET revoked_at=? WHERE id=?').bind(new Date().toISOString(),c.get('auth').sessionId).run();
  c.header('Set-Cookie',sessionCookie(c.env,'',new Date(0)));return ok(c,{signedOut:true});
});
authRoutes.get('/profile',requireAuth,c=>ok(c,c.get('auth').user));
authRoutes.patch('/profile',requireAuth,async c=>{
  const input=await body(c,z.object({name:z.string().trim().min(1).max(80)}));
  const user=c.get('auth').user;
  await c.env.DB.batch([c.env.DB.prepare('UPDATE users SET name=?,updated_at=? WHERE id=?').bind(input.name,new Date().toISOString(),user.id),auditStatement(c.env.DB,user.id,'user.profile','user',user.id,{name:input.name},c.get('requestId'))]);
  return ok(c,{...user,name:input.name});
});
