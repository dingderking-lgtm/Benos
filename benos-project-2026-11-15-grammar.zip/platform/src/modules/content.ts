import { Hono } from 'hono';
import { z } from 'zod';
import { type App,body,ok } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole } from './auth';
import type { Env } from '../env';
import { contentMediaRoutes,contentMediaId,contentMediaGuard,publicMediaPath,readContentMedia } from './content-media';
import { queryContent,type ContentQuery } from './content-query';
import { draftPreview } from './content-preview';
import { contentDependencies,dependencyMessage } from './content-references';
import { sanitizeRichText } from '../lib/rich-text';

const kind=z.enum(['page','post','faq','navigation','banner','category','tag']);
function safeUrl(value:string){if(!value)return true;if(/[\\\x00-\x20\x7f]/.test(value))return false;if(/^\/(?!\/)/.test(value))return true;try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password;}catch{return false;}}
const link=z.string().max(2000).refine(safeUrl,'链接必须是安全站内路径或 HTTPS 地址');
const ref=z.string().regex(/^cnt_[a-f0-9]{32}$/).nullable().optional();
const content=z.object({body:z.string().max(100_000),bodyFormat:z.enum(['html']).optional(),publicationDate:z.string().datetime().optional(),description:z.string().max(1000).optional(),url:link.optional(),seoTitle:z.string().max(200).optional(),seoDescription:z.string().max(320).optional(),coverUrl:link.optional(),coverAlt:z.string().max(200).optional(),categoryId:ref,targetId:ref,tagIds:z.array(z.string().regex(/^cnt_[a-f0-9]{32}$/)).max(30).refine(v=>new Set(v).size===v.length).optional(),coverMediaId:contentMediaId.nullable().optional(),position:z.number().int().min(0).max(100000).optional(),placement:z.enum(['header','footer','home']).optional()}).strict();
const entrySchema=z.object({kind,slug:z.string().regex(/^[a-z0-9]+(?:[-/][a-z0-9]+)*$/).max(180),title:z.string().trim().min(1).max(200),content}).strict();
function normalizeEntry<T extends z.infer<typeof entrySchema>>(input:T):T{
 assert(!input.content.tagIds?.length||input.kind==='post','VALIDATION','只有文章可关联标签');
 assert(!input.content.categoryId||input.kind==='post','VALIDATION','只有文章可关联分类');
 if(input.kind==='navigation')assert(!input.content.placement||['header','footer'].includes(input.content.placement),'VALIDATION','导航位置仅支持页首或页脚');
 if(input.kind==='banner')assert(!input.content.placement||input.content.placement==='home','VALIDATION','横幅位置仅支持首页');
 // Rich text is rebuilt from the allow-list before it is stored; nothing else of what was sent is kept.
 if(input.content.bodyFormat==='html'){assert(input.kind==='post'||input.kind==='page','VALIDATION','只有文章和页面可使用富文本正文');input.content.body=sanitizeRichText(input.content.body);assert(input.content.body.length<=100_000,'VALIDATION','正文过长');}
 if(input.content.coverMediaId)input.content.coverUrl=publicMediaPath(input.content.coverMediaId);
 else assert(!input.content.coverUrl?.includes('/api/content/media/'),'VALIDATION','受管素材必须通过素材库关联');
 if(input.kind==='navigation'&&!input.content.placement)input.content.placement='header';
 return input;
}
type Row={id:string;kind:string;kind_override:string|null;slug:string;title:string;draft_json:string;published_json:string|null;state:string;revision:number;created_at:string;updated_at:string;published_at:string|null;deleted_at:string|null};
function safeRow(r:Row){return {id:r.id,kind:r.kind_override||r.kind,slug:r.kind_override==='tag'?JSON.parse(r.draft_json).slug:r.slug,title:r.title,content:JSON.parse(r.draft_json),published:r.published_json?JSON.parse(r.published_json):null,state:r.state,revision:r.revision,createdAt:r.created_at,updatedAt:r.updated_at,publishedAt:r.published_at,deletedAt:r.deleted_at};}
function referenceGuard(env:Env,data:z.infer<typeof content>,entry:string,published:boolean){
 const guard=id('guard'),checks:Array<{id:string;kind:string|null}>=[];
 if(data.categoryId)checks.push({id:data.categoryId,kind:'category'});if(data.targetId)checks.push({id:data.targetId,kind:null});for(const tag of data.tagIds||[])checks.push({id:tag,kind:'tag'});
 return [env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN NOT EXISTS(SELECT 1 FROM json_each(?) x WHERE json_extract(x.value,'$.id')=? OR NOT EXISTS(SELECT 1 FROM content_entries e WHERE e.id=json_extract(x.value,'$.id') AND e.state<>'trashed' AND (?=0 OR e.state='published') AND (json_extract(x.value,'$.kind') IS NULL OR COALESCE(e.kind_override,e.kind)=json_extract(x.value,'$.kind')))) THEN 1 ELSE 0 END`).bind(guard,JSON.stringify(checks),entry,published?1:0),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard),...contentMediaGuard(env,data.coverMediaId)];
}
export const contentRoutes=new Hono<App>();
contentRoutes.use('*',requireAuth,requireRole('owner','admin','editor'));
contentRoutes.route('/media',contentMediaRoutes);
contentRoutes.get('/options',async c=>{
 const rows=await c.env.DB.prepare("SELECT id,COALESCE(kind_override,kind) AS kind,title,state,json_extract(draft_json,'$.slug') AS slug FROM content_entries WHERE state<>'trashed' AND COALESCE(kind_override,kind) IN ('category','tag','page','post','faq') ORDER BY title LIMIT 1000").all<{id:string;kind:string;title:string;state:string;slug:string}>();return ok(c,{categories:rows.results.filter(r=>r.kind==='category'),tags:rows.results.filter(r=>r.kind==='tag'),targets:rows.results});
});
contentRoutes.get('/',async c=>{const result=await queryContent<Row>(c.env,c.req.query());return ok(c,{...result,items:result.items.map(safeRow)});});
contentRoutes.get('/:id/preview',async c=>{const row=await c.env.DB.prepare('SELECT * FROM content_entries WHERE id=?').bind(c.req.param('id')).first<Row>();assert(row&&row.state!=='trashed','NOT_FOUND','草稿不存在',404);return draftPreview({title:row.title,kind:row.kind,revision:row.revision,content:JSON.parse(row.draft_json)});});
contentRoutes.post('/bulk',async c=>{
 const input=await body(c,z.object({action:z.enum(['publish','unpublish','restore','trash']),items:z.array(z.object({id:z.string().regex(/^cnt_[a-f0-9]{32}$/),revision:z.number().int().positive()}).strict()).min(1).max(100).refine(items=>new Set(items.map(item=>item.id)).size===items.length)}).strict());const results=[];
 for(const item of input.items){try{results.push({id:item.id,ok:true,data:await changeContentState(c,item.id,item.revision,input.action)});}catch(error){results.push({id:item.id,ok:false,error:{code:error instanceof AppError?error.code:'OPERATION_FAILED',message:error instanceof AppError?error.message:'操作未完成，请刷新核对'}});}}
 return ok(c,{items:results});
});
contentRoutes.get('/:id/references',async c=>{assert(await c.env.DB.prepare('SELECT id FROM content_entries WHERE id=?').bind(c.req.param('id')).first(),'NOT_FOUND','内容不存在',404);return ok(c,{items:await contentDependencies(c.env,c.req.param('id'))});});
contentRoutes.get('/:id',async c=>{const row=await c.env.DB.prepare('SELECT * FROM content_entries WHERE id=?').bind(c.req.param('id')).first<Row>();assert(row,'NOT_FOUND','内容不存在',404);return ok(c,safeRow(row));});
contentRoutes.post('/',async c=>{
 const input=normalizeEntry(await body(c,entrySchema)),entryId=id('cnt'),actor=c.get('auth').user.id,now=new Date().toISOString();
 assert(!await c.env.DB.prepare('SELECT 1 FROM content_entries WHERE COALESCE(kind_override,kind)=? AND slug=?').bind(input.kind,input.kind==='tag'?'@tag/'+input.slug:input.slug).first(),'SLUG_EXISTS','该内容路径已存在',409);
 const draft=JSON.stringify({...input.content,title:input.title,slug:input.slug});
 try{await c.env.DB.batch([...referenceGuard(c.env,input.content,entryId,false),c.env.DB.prepare('INSERT INTO content_entries(id,kind,kind_override,slug,title,draft_json,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(entryId,input.kind==='tag'?'category':input.kind,input.kind==='tag'?'tag':null,input.kind==='tag'?'@tag/'+input.slug:input.slug,input.title,draft,actor,now,now),c.env.DB.prepare('INSERT INTO content_revisions(id,entry_id,revision,content_json,actor_id,created_at) VALUES(?,?,1,?,?,?)').bind(id('rev'),entryId,draft,actor,now),auditStatement(c.env.DB,actor,'content.create','content',entryId,{kind:input.kind},c.get('requestId'))]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('CONTENT_REFERENCE_INVALID','分类或链接目标已失效，请重新选择',409);if(String(error).includes('UNIQUE'))throw new AppError('SLUG_EXISTS','该内容路径已存在',409);throw error;}
 return ok(c,safeRow((await c.env.DB.prepare('SELECT * FROM content_entries WHERE id=?').bind(entryId).first<Row>())!),201);
});
async function mutate(c:any,entry:string,revision:number,action:string,statements:D1PreparedStatement[]){
 const guard=id('guard');
 const row=await c.env.DB.prepare('SELECT id FROM content_entries WHERE id=?').bind(entry).first();assert(row,'NOT_FOUND','内容不存在',404);
 try{await c.env.DB.batch([
  c.env.DB.prepare('INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM content_entries WHERE id=? AND revision=?) THEN 1 ELSE 0 END').bind(guard,entry,revision),
  ...statements,
  c.env.DB.prepare('INSERT INTO content_revisions(id,entry_id,revision,content_json,actor_id,created_at) SELECT ?,id,revision,draft_json,?,? FROM content_entries WHERE id=?').bind(id('rev'),c.get('auth').user.id,new Date().toISOString(),entry),
  auditStatement(c.env.DB,c.get('auth').user.id,'content.'+action,'content',entry,{previousRevision:revision},c.get('requestId')),
  c.env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
 ]);}catch(error){if(String(error).includes('mutation_revision_ok')){if(['trash','unpublish'].includes(action)){const dependencies=await contentDependencies(c.env,entry);if(dependencies.length)throw new AppError('CONTENT_REFERENCED',dependencyMessage(dependencies),409);}throw new AppError('REVISION_CONFLICT','内容版本或引用已变化，请刷新核对',409);}if(String(error).includes('UNIQUE'))throw new AppError('SLUG_EXISTS','该内容路径已被其他草稿或发布版本占用',409);throw error;}
 return safeRow((await c.env.DB.prepare('SELECT * FROM content_entries WHERE id=?').bind(entry).first())!);
}
contentRoutes.patch('/:id',async c=>{
 const input=normalizeEntry(await body(c,entrySchema.extend({revision:z.number().int().positive()}))),draft=JSON.stringify({...input.content,title:input.title,slug:input.slug});
 const row=await c.env.DB.prepare('SELECT COALESCE(kind_override,kind) AS kind,state FROM content_entries WHERE id=?').bind(c.req.param('id')).first<{kind:string;state:string}>();assert(row,'NOT_FOUND','内容不存在',404);assert(row.kind===input.kind&&row.state!=='trashed','INVALID_STATE','请先恢复内容；内容类型不可修改',409);
 return ok(c,await mutate(c,c.req.param('id'),input.revision,'update',[...referenceGuard(c.env,input.content,c.req.param('id'),false),c.env.DB.prepare('UPDATE content_entries SET slug=?,title=?,draft_json=?,revision=revision+1,updated_at=? WHERE id=?').bind(input.kind==='tag'?'@tag/'+input.slug:input.slug,input.title,draft,new Date().toISOString(),c.req.param('id'))]));
});
type StateAction='publish'|'unpublish'|'restore'|'trash';
async function changeContentState(c:any,entry:string,revision:number,action:StateAction){
 const now=new Date().toISOString(),row=await c.env.DB.prepare('SELECT kind,state,draft_json,published_at FROM content_entries WHERE id=?').bind(entry).first();assert(row,'NOT_FOUND','内容不存在',404);
 assert(action==='restore'?row.state==='trashed':row.state!=='trashed','INVALID_STATE','该操作不适用于当前内容状态',409);
 const sets=action==='publish'?"published_json=draft_json,state='published',published_at=?,deleted_at=NULL":action==='unpublish'?"state='unpublished',published_json=NULL,deleted_at=NULL":action==='restore'?"state='draft',deleted_at=NULL,published_json=NULL":"state='trashed',deleted_at=?,published_json=NULL";
 const draft=JSON.parse(row.draft_json),publicationDate=draft.publicationDate||row.published_at||now;
 if(action==='publish')assert(Number.isFinite(Date.parse(publicationDate))&&Date.parse(publicationDate)<=Date.parse(now),'PUBLICATION_DATE_FUTURE','发布时间不能晚于当前时间；保存草稿不会自动定时发布');
 const values=action==='publish'?[publicationDate,now,entry]:action==='trash'?[now,now,entry]:[now,entry],guards:D1PreparedStatement[]=[];
 if(action==='publish')guards.push(...referenceGuard(c.env,JSON.parse(row.draft_json),entry,true));
 if(action==='trash'||action==='unpublish'){
  const guard=id('guard');guards.push(c.env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN NOT EXISTS(SELECT 1 FROM content_entries WHERE id<>? AND state<>'trashed' AND (json_extract(draft_json,'$.categoryId')=? OR json_extract(draft_json,'$.targetId')=? OR json_extract(published_json,'$.categoryId')=? OR json_extract(published_json,'$.targetId')=? OR EXISTS(SELECT 1 FROM json_each(draft_json,'$.tagIds') t WHERE t.value=?) OR EXISTS(SELECT 1 FROM json_each(published_json,'$.tagIds') t WHERE t.value=?))) THEN 1 ELSE 0 END`).bind(guard,...Array(7).fill(entry)),c.env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard));
 }
 return mutate(c,entry,revision,action,[...guards,c.env.DB.prepare(`UPDATE content_entries SET ${sets},revision=revision+1,updated_at=? WHERE id=?`).bind(...values)]);
}
for(const action of ['publish','unpublish','restore','trash'] as const){
 const handler=async(c:any)=>{const input=await body(c,z.object({revision:z.number().int().positive()}).strict());return ok(c,await changeContentState(c,c.req.param('id'),input.revision,action));};
 if(action==='trash')contentRoutes.delete('/:id',handler);else contentRoutes.post('/:id/'+action,handler);
}

export const publicContentRoutes=new Hono<App>();
publicContentRoutes.get('/media/:id',c=>readContentMedia(c.env,c.req.param('id'),true));
export type PublishedContent={id:string;kind:string;title:string;slug:string;body:string;bodyFormat?:'html';description?:string;seoTitle?:string;seoDescription?:string;coverUrl?:string;coverAlt?:string;categoryId?:string|null;targetId?:string|null;tagIds?:string[];coverMediaId?:string|null;url?:string;position?:number;placement?:string;publishedAt:string};
export async function listPublishedContent(env:Env,options:ContentQuery={}){
 const result=await queryContent<Row>(env,options,true);return {...result,items:result.items.map(r=>({id:r.id,kind:r.kind_override||r.kind,...JSON.parse(r.published_json!),publishedAt:r.published_at})) as PublishedContent[]};
}
export async function findPublishedContent(env:Env,selected:string,slug:string){const row=await env.DB.prepare("SELECT id,COALESCE(kind_override,kind) AS kind,published_json,published_at FROM content_entries WHERE state='published' AND COALESCE(kind_override,kind)=? AND json_extract(published_json,'$.slug')=?").bind(selected,slug).first<{id:string;kind:string;published_json:string;published_at:string}>();return row?{id:row.id,kind:row.kind,...JSON.parse(row.published_json),publishedAt:row.published_at} as PublishedContent:null;}
publicContentRoutes.get('/',async c=>{
 const selected=c.req.query('kind');assert(!selected||kind.safeParse(selected).success,'VALIDATION','内容类型无效');
 return ok(c,await listPublishedContent(c.env,{kind:selected,categoryId:c.req.query('categoryId'),tagId:c.req.query('tagId'),q:c.req.query('q'),sort:c.req.query('sort'),cursor:c.req.query('cursor')}));
});
publicContentRoutes.get('/:kind/:slug{.+}',async c=>{assert(kind.safeParse(c.req.param('kind')).success,'VALIDATION','内容类型无效');const item=await findPublishedContent(c.env,c.req.param('kind'),c.req.param('slug'));assert(item,'NOT_FOUND','内容不存在',404);return ok(c,item);});
