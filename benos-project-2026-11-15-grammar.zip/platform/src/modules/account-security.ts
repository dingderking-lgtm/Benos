import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { AppError,assert } from '../lib/errors';
import { encryptSecret,id,randomToken,sha256,hashPassword,verifyPassword } from '../lib/crypto';
import { requireAuth } from './auth';
import { loadEmailConfiguration,processEmailOutbox,type EmailRuntime } from './email';

const emailSchema=z.string().trim().email('请输入有效邮箱').max(254).transform(value=>value.toLowerCase());
const passwordSchema=z.string().min(12,'密码至少 12 位').max(128,'密码不能超过 128 位');
const tokenSchema=z.string().regex(/^[A-Za-z0-9_-]{43}$/,'链接无效或已失效');
interface SecurityRuntime extends EmailRuntime {ip?:string;}
const FORGOT_RESULT={accepted:true,message:'请求已受理；如果此邮箱已注册，系统会尝试发送重置链接。请检查邮箱。'};
function time(runtime:SecurityRuntime):number{return runtime.nowMs??Date.now();}
async function securityLimit(env:Env,category:string,subject:string,maximum:number,period:number,runtime:SecurityRuntime):Promise<void>{
 assert(env.SESSION_SECRET?.length>=32,'SERVER_NOT_CONFIGURED','平台安全配置尚未完成',503);
 const key=await sha256(`${env.SESSION_SECRET}:account:${category}:${subject}`),stamp=Math.floor(time(runtime)/1000),window=Math.floor(stamp/period)*period;
 const row=await env.DB.prepare('INSERT INTO rate_limits(key,window_start,count) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window_start=excluded.window_start THEN count+1 ELSE 1 END,window_start=excluded.window_start RETURNING count').bind(key,window).first<{count:number}>();
 assert(row&&row.count<=maximum,'RATE_LIMITED','操作频繁，请稍后再试',429);
}
function safeOrigin(env:Env):string {
 const origin=new URL(env.APP_ORIGIN);assert(origin.protocol==='https:'||(env.APP_ENV!=='production'&&origin.protocol==='http:'),'SERVER_NOT_CONFIGURED','平台链接配置尚未完成',503);return origin.origin;
}
async function issueEmailToken(env:Env,user:{id:string;email:string},purpose:'verify_email'|'password_reset',runtime:SecurityRuntime){
 const config=await loadEmailConfiguration(env),stamp=time(runtime),created=new Date(stamp).toISOString(),expires=new Date(stamp+(purpose==='password_reset'?30*60_000:60*60_000)).toISOString();
 const token=randomToken(),tokenId=id('act'),jobId=id('mail'),tokenHash=await sha256(token);
 const path=purpose==='password_reset'?'/account/reset-password':'/account/verify-email';
 const url=`${safeOrigin(env)}${path}#token=${encodeURIComponent(token)}`;
 const action=purpose==='password_reset'?'重置密码':'验证邮箱';
 const payload={from:`${config.fromName} <${config.fromEmail}>`,to:[user.email],subject:`Benos ${action}`,
  text:`请使用以下链接${action}：\n${url}\n\n链接仅可使用一次，并于 ${expires} 失效。如果并非你本人操作，请忽略此邮件。`,
  ...(config.replyTo?{reply_to:config.replyTo}:{})};
 const encrypted=await encryptSecret(JSON.stringify(payload),env.ENCRYPTION_KEY,jobId);
 await env.DB.batch([
  env.DB.prepare('INSERT INTO account_tokens(id,user_id,token_hash,purpose,email_snapshot,created_at,expires_at) VALUES(?,?,?,?,?,?,?)').bind(tokenId,user.id,tokenHash,purpose,user.email,created,expires),
  env.DB.prepare('INSERT INTO email_outbox(id,user_id,token_id,config_version_id,purpose,payload_ciphertext,created_at,updated_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(jobId,user.id,tokenId,config.id,purpose,encrypted,created,created,expires),
 ]);
 return {jobId};
}
export async function requestPasswordReset(env:Env,email:string,runtime:SecurityRuntime={}){
 const normalized=emailSchema.parse(email);
 await securityLimit(env,'forgot-ip',runtime.ip??'local',20,3600,runtime);
 await securityLimit(env,'forgot-email',normalized,3,3600,runtime);
 // Every address gets the same explicit configuration failure, avoiding both
 // enumeration and a misleading claim that mail was sent when it cannot be.
 await loadEmailConfiguration(env);
 const user=await env.DB.prepare('SELECT id,email FROM users WHERE email=?').bind(normalized).first<{id:string;email:string}>();
 if(user)await issueEmailToken(env,user,'password_reset',runtime);
 else {await sha256(randomToken());await encryptSecret('unregistered-request',env.ENCRYPTION_KEY,id('dummy'));}
 return {...FORGOT_RESULT};
}
export async function requestEmailVerification(env:Env,userId:string,runtime:SecurityRuntime={}){
 await securityLimit(env,'verify-user',userId,3,3600,runtime);
 const user=await env.DB.prepare('SELECT id,email,email_verified_at FROM users WHERE id=?').bind(userId).first<{id:string;email:string;email_verified_at:string|null}>();
 assert(user,'ACCOUNT_NOT_FOUND','账号不存在',404);
 if(user.email_verified_at)return {verified:true,queued:false,deliveryState:null,requestId:null};
 const {jobId}=await issueEmailToken(env,user,'verify_email',runtime);
 return {verified:false,queued:true,deliveryState:'queued',requestId:jobId};
}
function tokenError(error:unknown):never {
 if(String(error).includes('account_token_valid'))throw new AppError('TOKEN_INVALID','链接无效、已使用或已到期，请重新申请',400);throw error;
}
export async function resetPassword(env:Env,token:string,password:string,runtime:SecurityRuntime={}){
 tokenSchema.parse(token);passwordSchema.parse(password);
 await securityLimit(env,'reset-ip',runtime.ip??'local',20,900,runtime);
 const tokenHash=await sha256(token);await securityLimit(env,'reset-token',tokenHash,6,900,runtime);
 const stamp=new Date(time(runtime)).toISOString(),operation=id('security'),passwordHash=await hashPassword(password);
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO account_security_operations(id,action,user_id,valid_ok,created_at)
   SELECT ?1,'password.reset',(SELECT user_id FROM account_tokens WHERE token_hash=?2),CASE WHEN EXISTS(
    SELECT 1 FROM account_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=?2 AND t.purpose='password_reset'
    AND t.used_at IS NULL AND t.expires_at>?3 AND t.email_snapshot=u.email) THEN 1 ELSE 0 END,?3`).bind(operation,tokenHash,stamp),
  env.DB.prepare('UPDATE users SET password_hash=?,updated_at=? WHERE id=(SELECT user_id FROM account_security_operations WHERE id=?)').bind(passwordHash,stamp,operation),
  env.DB.prepare('UPDATE account_tokens SET used_at=COALESCE(used_at,?) WHERE user_id=(SELECT user_id FROM account_security_operations WHERE id=?)').bind(stamp,operation),
  env.DB.prepare('UPDATE sessions SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=(SELECT user_id FROM account_security_operations WHERE id=?)').bind(stamp,operation),
  env.DB.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,created_at) SELECT ?1,user_id,'account.password_reset','user',user_id,'{}',?2 FROM account_security_operations WHERE id=?1").bind(operation,stamp),
 ]);}catch(error){tokenError(error);}
 return {changed:true,signInRequired:true};
}
export async function verifyEmail(env:Env,token:string,runtime:SecurityRuntime={}){
 tokenSchema.parse(token);await securityLimit(env,'email-token-ip',runtime.ip??'local',20,900,runtime);
 const tokenHash=await sha256(token),stamp=new Date(time(runtime)).toISOString(),operation=id('security');
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO account_security_operations(id,action,user_id,valid_ok,created_at)
   SELECT ?1,'email.verify',(SELECT user_id FROM account_tokens WHERE token_hash=?2),CASE WHEN EXISTS(
    SELECT 1 FROM account_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=?2 AND t.purpose='verify_email'
    AND t.used_at IS NULL AND t.expires_at>?3 AND t.email_snapshot=u.email) THEN 1 ELSE 0 END,?3`).bind(operation,tokenHash,stamp),
  env.DB.prepare('UPDATE users SET email_verified_at=COALESCE(email_verified_at,?),updated_at=? WHERE id=(SELECT user_id FROM account_security_operations WHERE id=?)').bind(stamp,stamp,operation),
  env.DB.prepare("UPDATE account_tokens SET used_at=COALESCE(used_at,?) WHERE purpose='verify_email' AND user_id=(SELECT user_id FROM account_security_operations WHERE id=?)").bind(stamp,operation),
  env.DB.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,created_at) SELECT ?1,user_id,'account.email_verified','user',user_id,'{}',?2 FROM account_security_operations WHERE id=?1").bind(operation,stamp),
 ]);}catch(error){tokenError(error);}
 return {verified:true};
}
export async function changePassword(env:Env,userId:string,sessionId:string,currentPassword:string,newPassword:string,runtime:SecurityRuntime={}){
 passwordSchema.parse(newPassword);assert(typeof currentPassword==='string'&&currentPassword.length<=128,'VALIDATION','请填写当前密码');
 await securityLimit(env,'password-change',userId,6,900,runtime);
 const user=await env.DB.prepare('SELECT password_hash FROM users WHERE id=?').bind(userId).first<{password_hash:string}>();
 assert(user&&await verifyPassword(currentPassword,user.password_hash),'CURRENT_PASSWORD_INVALID','当前密码不正确',403);
 const hash=await hashPassword(newPassword),stamp=new Date(time(runtime)).toISOString(),operation=id('security');
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO account_security_operations(id,action,user_id,valid_ok,created_at) VALUES(?1,'password.change',?2,
   CASE WHEN EXISTS(SELECT 1 FROM users WHERE id=?2 AND password_hash=?3) AND EXISTS(SELECT 1 FROM sessions WHERE id=?4 AND user_id=?2 AND revoked_at IS NULL AND expires_at>?5)
    THEN 1 ELSE 0 END,?5)`).bind(operation,userId,user.password_hash,sessionId,stamp),
  env.DB.prepare('UPDATE users SET password_hash=?,updated_at=? WHERE id=?').bind(hash,stamp,userId),
  env.DB.prepare('UPDATE sessions SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=?').bind(stamp,userId),
  env.DB.prepare('UPDATE account_tokens SET used_at=COALESCE(used_at,?) WHERE user_id=?').bind(stamp,userId),
  env.DB.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,created_at) VALUES(?,?,'account.password_changed','user',?,'{}',?)").bind(operation,userId,userId,stamp),
 ]);}catch(error){if(String(error).includes('account_token_valid'))throw new AppError('SESSION_CHANGED','账号安全状态已变化，请重新登录后重试',409);throw error;}
 return {changed:true,signInRequired:true};
}
export async function listSessions(env:Env,userId:string,currentSession:string,runtime:SecurityRuntime={}){
 const rows=(await env.DB.prepare('SELECT id,created_at,expires_at FROM sessions WHERE user_id=? AND revoked_at IS NULL AND expires_at>? ORDER BY created_at DESC').bind(userId,new Date(time(runtime)).toISOString()).all<{id:string;created_at:string;expires_at:string}>()).results;
 return {items:rows.map(row=>({id:row.id,createdAt:row.created_at,expiresAt:row.expires_at,current:row.id===currentSession}))};
}
export async function revokeSessions(env:Env,userId:string,currentSession:string,target:'others'|string,runtime:SecurityRuntime={}){
 const stamp=new Date(time(runtime)).toISOString();
 const update=target==='others'?env.DB.prepare('UPDATE sessions SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=? AND id<>? RETURNING id').bind(stamp,userId,currentSession):env.DB.prepare('UPDATE sessions SET revoked_at=COALESCE(revoked_at,?) WHERE user_id=? AND id=? RETURNING id').bind(stamp,userId,target);
 const results=await env.DB.batch([update,env.DB.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,created_at) VALUES(?,?,'account.sessions_revoked','user',?,?,?)").bind(id('audit'),userId,userId,JSON.stringify({target:target==='others'?'others':target}),stamp)]);
 const result=results[0];
 if(target!=='others')assert(result.results.length,'SESSION_NOT_FOUND','会话不存在',404);
 return {revoked:result.results.length,signInRequired:target===currentSession};
}
function clearCookie(env:Env):string{return `${env.APP_ENV==='production'?'__Host-benos_session':'benos_session'}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${env.APP_ENV==='production'?'; Secure':''}`;}
export const accountSecurityRoutes=new Hono<App>();
accountSecurityRoutes.post('/password/forgot',async c=>{
 const input=await body(c,z.object({email:emailSchema}).strict()),result=await requestPasswordReset(c.env,input.email,{ip:c.req.header('cf-connecting-ip')??'local'});
 // The response is identical for registered and unknown addresses. Sending runs
 // after response; the scheduled outbox worker recovers process interruptions.
 try{c.executionCtx.waitUntil(processEmailOutbox(c.env,{limit:5}));}catch{/* A local test runner may not provide an execution context. */}
 return ok(c,result,202);
});
accountSecurityRoutes.post('/password/reset',async c=>{
 const input=await body(c,z.object({token:tokenSchema,password:passwordSchema}).strict()),result=await resetPassword(c.env,input.token,input.password,{ip:c.req.header('cf-connecting-ip')??'local'});
 c.header('Set-Cookie',clearCookie(c.env));return ok(c,result);
});
accountSecurityRoutes.post('/email/verify',async c=>{
 const input=await body(c,z.object({token:tokenSchema}).strict());return ok(c,await verifyEmail(c.env,input.token,{ip:c.req.header('cf-connecting-ip')??'local'}));
});
accountSecurityRoutes.post('/email/verify/request',requireAuth,async c=>{
 const result=await requestEmailVerification(c.env,c.get('auth').user.id);
 if(result.requestId)try{c.executionCtx.waitUntil(processEmailOutbox(c.env,{limit:1,onlyId:result.requestId}));}catch{/* Scheduled worker will retry. */}
 return ok(c,result,202);
});
accountSecurityRoutes.post('/password/change',requireAuth,async c=>{
 const input=await body(c,z.object({currentPassword:z.string().min(1).max(128),newPassword:passwordSchema}).strict()),auth=c.get('auth');
 const result=await changePassword(c.env,auth.user.id,auth.sessionId,input.currentPassword,input.newPassword);c.header('Set-Cookie',clearCookie(c.env));return ok(c,result);
});
accountSecurityRoutes.get('/sessions',requireAuth,async c=>ok(c,await listSessions(c.env,c.get('auth').user.id,c.get('auth').sessionId)));
accountSecurityRoutes.post('/sessions/revoke-others',requireAuth,async c=>ok(c,await revokeSessions(c.env,c.get('auth').user.id,c.get('auth').sessionId,'others')));
accountSecurityRoutes.post('/sessions/:id/revoke',requireAuth,async c=>{
 const result=await revokeSessions(c.env,c.get('auth').user.id,c.get('auth').sessionId,c.req.param('id'));if(result.signInRequired)c.header('Set-Cookie',clearCookie(c.env));return ok(c,result);
});
