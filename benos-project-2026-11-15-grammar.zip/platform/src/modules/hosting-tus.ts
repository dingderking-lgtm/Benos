import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { AppError,assert } from '../lib/errors';
import { sha256 } from '../lib/crypto';

// Hostinger's official file upload grant is scoped to username + domain.
// https://github.com/hostinger/api-php-sdk/blob/main/docs/Api/HostingFilesApi.md
// The caller must hold the provisioning job lease and have verified ownership
// of a newly provisioned website. We never use the destructive override flag.
export interface TusCheckpoint {
  version:1; fingerprint:string; endpointFingerprint:string|null;
  attempted:boolean; offset:number;
}
export interface TusUploadInput {
  apiToken:string; accountUsername:string; domain:string; relativePath:string;
  bytes:Uint8Array; sha256:string; checkpoint?:TusCheckpoint|null;
  persist:(checkpoint:TusCheckpoint)=>Promise<void>;
}
export interface TusRuntime {fetch?:typeof fetch;maxChunks?:number;chunkBytes?:number;}
export interface TusUploadResult {complete:boolean;checkpoint:TusCheckpoint;retryAfterSeconds?:number;}
const API='https://developers.hostinger.com/api/hosting/v1/files/upload-urls';
function endpoint(value:unknown):URL {
  assert(typeof value==='string','TUS_GRANT_INVALID','托管文件连接返回无效',502);
  let url:URL;try{url=new URL(value);}catch{throw new AppError('TUS_GRANT_INVALID','托管文件连接返回无效',502);}
  const host=url.hostname.toLowerCase();
  assert(url.protocol==='https:'&&!url.username&&!url.password&&!url.hash&&!url.search&&(!url.port||url.port==='443')&&host.includes('.')&&!/^[\d.]+$/.test(host)&&!host.includes(':')&&!/(^|\.)(localhost|local|internal|lan|test|invalid|example)$/.test(host),'TUS_GRANT_INVALID','托管文件连接不符合安全要求',502);
  return url;
}
function numericHeader(response:Response,name:string,max:number):number {
  const value=response.headers.get(name);
  assert(value!==null&&/^\d+$/.test(value),'TUS_STATE_INVALID','托管文件进度尚无法确认',502);
  const n=Number(value);assert(Number.isSafeInteger(n)&&n>=0&&n<=max,'TUS_STATE_INVALID','托管文件进度尚无法确认',502);return n;
}
async function smallJson(response:Response):Promise<Record<string,unknown>> {
  const reader=response.body?.getReader();assert(reader,'TUS_GRANT_INVALID','托管文件连接返回为空',502);
  const parts:Uint8Array[]=[];let total=0;
  while(true){const part=await reader.read();if(part.done)break;total+=part.value.length;if(total>16_384){await reader.cancel();throw new AppError('TUS_GRANT_INVALID','托管文件连接返回无效',502);}parts.push(part.value);}
  const bytes=new Uint8Array(total);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
  try{const json=JSON.parse(new TextDecoder().decode(bytes));assert(json&&typeof json==='object'&&!Array.isArray(json),'TUS_GRANT_INVALID','托管文件连接返回无效',502);return json;}catch{throw new AppError('TUS_GRANT_INVALID','托管文件连接返回无效',502);}
}
export async function ensureTusUpload(input:TusUploadInput,runtime:TusRuntime={}):Promise<TusUploadResult> {
  assert(/^u[0-9]{3,20}$/.test(input.accountUsername)&&/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(input.domain),'TUS_TARGET_INVALID','托管目标信息无效');
  // Only these platform-owned, collision-resistant files can be transported.
  assert(/^(benos-bootstrap-[a-f0-9]{32}\.php|benos-release-[a-f0-9]{64}\.zip)$/.test(input.relativePath),'TUS_TARGET_INVALID','安装文件路径无效');
  assert(/^[a-f0-9]{64}$/.test(input.sha256)&&input.bytes.byteLength>0&&input.bytes.byteLength<=48*1024*1024,'TUS_ARTIFACT_INVALID','安装文件大小或校验信息无效');
  const actualHash=await sha256(input.bytes);assert(actualHash===input.sha256,'TUS_ARTIFACT_INVALID','安装文件校验失败');
  if(input.relativePath.endsWith('.zip'))assert(input.relativePath===`benos-release-${actualHash}.zip`,'TUS_ARTIFACT_INVALID','安装包名称与校验值不匹配');
  const fingerprint=await sha256(JSON.stringify([input.accountUsername,input.domain,input.relativePath,input.sha256,input.bytes.byteLength]));
  let checkpoint:TusCheckpoint=input.checkpoint?{...input.checkpoint}:{version:1,fingerprint,endpointFingerprint:null,attempted:false,offset:0};
  assert(checkpoint.version===1&&checkpoint.fingerprint===fingerprint&&typeof checkpoint.attempted==='boolean'&&Number.isSafeInteger(checkpoint.offset)&&checkpoint.offset>=0&&checkpoint.offset<=input.bytes.length&&(checkpoint.endpointFingerprint===null||/^[a-f0-9]{64}$/.test(checkpoint.endpointFingerprint)),'TUS_CHECKPOINT_MISMATCH','安装任务与已有传输记录不一致',409);
  const persist=async(update:Partial<TusCheckpoint>)=>{checkpoint={...checkpoint,...update};await input.persist({...checkpoint});};
  const result=(complete=false,retryAfterSeconds?:number):TusUploadResult=>({complete,checkpoint:{...checkpoint},...(retryAfterSeconds?{retryAfterSeconds}:{})});
  const send=runtime.fetch??fetch;
  const grant=await fetchWithoutRedirect(API,{method:'POST',headers:{Authorization:`Bearer ${input.apiToken}`,'Content-Type':'application/json'},body:JSON.stringify({username:input.accountUsername,domain:input.domain}),signal:AbortSignal.timeout(20_000)},send);
  if(grant.status===409||grant.status===429){const retry=Number(grant.headers.get('Retry-After'));return result(false,Number.isSafeInteger(retry)&&retry>0?Math.min(retry,3600):60);}
  assert(grant.ok,'TUS_GRANT_UNAVAILABLE','托管文件连接暂不可用',502);
  const raw=await smallJson(grant),base=endpoint(raw.url);
  assert(typeof raw.auth_key==='string'&&raw.auth_key.length>0&&raw.auth_key.length<=8192&&typeof raw.rest_auth_key==='string'&&raw.rest_auth_key.length>0&&raw.rest_auth_key.length<=8192,'TUS_GRANT_INVALID','托管文件凭据返回无效',502);
  const target=new URL(base.toString().replace(/\/$/,'')+'/'+input.relativePath),targetFingerprint=await sha256(target.toString());
  assert(!checkpoint.endpointFingerprint||checkpoint.endpointFingerprint===targetFingerprint,'TUS_ENDPOINT_CHANGED','托管文件入口发生变化，需核对原传输记录',409);
  await persist({endpointFingerprint:targetFingerprint});
  const headers={'Tus-Resumable':'1.0.0','X-Auth':raw.auth_key,'X-Auth-Rest':raw.rest_auth_key};
  const call=(method:string,extra:Record<string,string>={},body?:Uint8Array<ArrayBuffer>)=>fetchWithoutRedirect(target.toString(),{method,headers:{...headers,...extra},...(body?{body}:{}),signal:AbortSignal.timeout(30_000)},send);
  const inspect=async()=>{
    const response=await call('HEAD');
    if(response.status===404)return null;
    assert(response.status===200||response.status===204,'TUS_STATE_UNAVAILABLE','托管文件进度暂不可用',502);
    assert(response.headers.get('Tus-Resumable')==='1.0.0','TUS_STATE_INVALID','托管文件协议无法确认',502);
    const offset=numericHeader(response,'Upload-Offset',input.bytes.length),length=numericHeader(response,'Upload-Length',input.bytes.length);
    assert(length===input.bytes.length&&offset>=checkpoint.offset,'TUS_STATE_INVALID','托管文件进度与安装记录不一致',409);return offset;
  };
  const before=await inspect();
  if(before!==null){
    assert(checkpoint.attempted,'TUS_DESTINATION_EXISTS','安装位置已存在文件，需核对归属后处理',409);
    await persist({offset:before});if(before===input.bytes.length)return result(true);
  }else{
    assert(!checkpoint.attempted,'TUS_CREATION_UNKNOWN','先前文件创建结果尚无法确认，请核对后恢复',409);
    // Persist intent before POST. Lost acknowledgements must never replay create.
    await persist({attempted:true});
    let created:Response;try{created=await call('POST',{'Upload-Length':String(input.bytes.length),'Upload-Offset':'0'});}catch{return result();}
    assert(created.status===201,'TUS_CREATE_UNCONFIRMED','安装文件创建结果待核对',409);
    const location=created.headers.get('Location');
    assert(!location||new URL(location,target).toString()===target.toString(),'TUS_LOCATION_CHANGED','安装文件返回了不同位置，需核对后处理',409);
    const observed=await inspect();assert(observed!==null,'TUS_CREATION_UNKNOWN','安装文件创建结果尚无法确认',409);await persist({offset:observed});
  }
  const chunks=runtime.maxChunks??4,chunkBytes=runtime.chunkBytes??1024*1024;
  assert(Number.isSafeInteger(chunks)&&chunks>=1&&chunks<=16&&Number.isSafeInteger(chunkBytes)&&chunkBytes>=1&&chunkBytes<=4*1024*1024,'TUS_OPTIONS_INVALID','传输参数无效');
  for(let i=0;i<chunks&&checkpoint.offset<input.bytes.length;i++){
    const start=checkpoint.offset,end=Math.min(start+chunkBytes,input.bytes.length),chunk=new Uint8Array(input.bytes.subarray(start,end));
    let patched:Response;try{patched=await call('PATCH',{'Content-Type':'application/offset+octet-stream','Upload-Offset':String(start)},chunk);}catch{return result();}
    if(patched.status===409||patched.status===429||patched.status>=500)return result();
    assert(patched.status===204,'TUS_PATCH_UNCONFIRMED','文件传输结果待核对',409);
    assert(numericHeader(patched,'Upload-Offset',input.bytes.length)===end,'TUS_STATE_INVALID','文件传输进度需核对',409);
    await persist({offset:end});
  }
  if(checkpoint.offset<input.bytes.length)return result();
  const final=await inspect();assert(final===input.bytes.length,'TUS_STATE_INVALID','文件完整传输尚未确认',409);
  // This receipt proves acknowledged byte length. The bootstrap independently
  // hashes the uploaded archive before extraction; TUS alone is not a hash proof.
  return result(true);
}
