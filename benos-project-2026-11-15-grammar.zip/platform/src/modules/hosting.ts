import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App, body, ok } from '../lib/http';
import { AppError, assert } from '../lib/errors';
import { base64url, constantTimeEqual, decryptSecret, encryptSecret, id, randomToken, sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { enforceScope, requireAuth, requireRole,restricted, rateLimit } from './auth';
import { activeSubscription,createOrder,hostingSubscription,type Order } from './commerce';
import { BUILTIN_CATALOG_ID,currentCatalog } from './billing-catalog';
import { anchorAnnualActivations,annualRenewalPlan,auditWhen,deferAccountAnnualYears,extendUnopenedAnnualYears,PARKED_SITE_TTL_MS,processDeferralRequests,rescheduleUncoveredAnnualYears,runDeferralRequest } from './hosting-billing';
import { ensureHpanelResources,hpanelConfiguration,testHpanelConfiguration,type HpanelResult } from './hosting-hostinger';
import { bootstrapConfiguration,prepareBootstrap,trustedRelease } from './hosting-bootstrap';
import { ensureInitialHostingHttps } from './hosting-domain-readiness';
import { allocateHostingJob,availableHostingPool } from './hosting-pools';
import { recordHostingRetention,siteRetention } from './hosting-retention';

type Site = { id:string; user_id:string; project_id:string|null; name:string; domain:string; cms_admin_email:string; state:string; created_at:string; updated_at:string;preview_version_id?:string|null };
type Job = { id:string;site_id:string;user_id:string;kind:string;state:string;step:string;idempotency_key:string;payload_hash:string;config_version_id:string|null;secret_ciphertext:string|null;secret_expires_at:string|null;result_json:string|null;error_code:string|null;attempt_count:number;lease_until:string|null;lease_token:string|null;created_at:string;updated_at:string };
type Integration = {id:string;provider:string;public_config_json:string;secret_ciphertext:string|null;status?:string;test_status?:string};
type BridgeSecret = {signingSecret?:string;hostingerApiToken?:string};
type BridgeConfig = { endpoint:string; keyId:string;adapter?:'managed-server'|'hostinger-hpanel';deploymentMode?:'registered-php-bridge'|'hostinger-tus-bootstrap';hostingOrderId?:number;accountUsername?:string };
type Protocol = 'BENOS-BRIDGE-V1'|'BENOS-CMS-V1';
const keySchema=z.string().regex(/^[A-Za-z0-9_-]{8,128}$/,'请求标识格式无效');
const inputSchema=z.object({
  name:z.string().trim().min(1).max(120),domain:z.string().trim().min(3).max(253),
  cmsAdminEmail:z.string().email().max(190).transform(value=>value.toLowerCase()),
  cmsAdminPassword:z.string().min(12,'CMS 密码至少 12 位').max(256),
  projectId:z.string().regex(/^prj_[a-f0-9]{32}$/).optional(),
  // 'annual' = pay-first $30/站/年 for a site beyond the membership slots (D16).
  billing:z.enum(['membership','annual']).optional(),
  catalogVersionId:z.string().max(128).optional(),
}).strict();
/** Deterministic outcomes: retrying the same input cannot succeed, so the job
 * stops instead of being retried every minute. Customer-facing codes are
 * neutral; the internal code stays in result_json (never returned). */
const TERMINAL_JOB_ERRORS:Record<string,string>={HOSTINGER_DOMAIN_UNSUPPORTED:'DOMAIN_UNSUPPORTED',HOSTINGER_WEBSITE_EXISTS:'DOMAIN_ALREADY_HOSTED'};
/** Need the platform team: configuration, recorded-intent conflicts and definite
 * provider rejections (a 4xx other than auth/rate-limit/not-ready). INVALID_DOMAIN
 * here can only come from the configured endpoint (customer domains are checked
 * at creation), so it is an operator problem, not the customer's domain. */
const OPERATOR_JOB_ERRORS=new Set(['HOSTINGER_INTENT_CONFLICT','HOSTINGER_DATABASE_CONFLICT','HOSTINGER_ROOT_UNAVAILABLE','HOSTINGER_ACCOUNT_SCOPE_INVALID','HOSTINGER_REQUEST_REJECTED','INVALID_DOMAIN','BOOTSTRAP_EXPIRED','BOOTSTRAP_INTENT_CONFLICT','BOOTSTRAP_SOURCE_CHANGED','HOSTING_DNS_TARGETS_REQUIRED','HOSTING_SSL_REVIEW_REQUIRED']);
// DNS/payment can outlast a browser session. Keep the encrypted install-only
// password for at most one day, erase it on success/expiry, and never extend its
// lifetime merely because the scheduler retries the same job.
const PROVISIONING_PASSWORD_TTL_MS=24*3600_000;
const AWAITING_PAYMENT='awaiting_payment';
/** A site whose pay-first job is still parked (never paid) never takes a membership slot. */
const SITE_NOT_PARKED="NOT EXISTS(SELECT 1 FROM provisioning_jobs j WHERE j.site_id=s.id AND j.state='awaiting_input' AND j.step='awaiting_payment')";
/** Unpaid pay-first sites per account; each holds a domain until paid, cancelled or released. */
const MAX_PARKED_SITES=3;
/** Lifetime of one hosting checkout (commerce createOrder opens orders for 2 h).
 * A re-parked claim always keeps at least this long to pay (R3-M1, R3-S2). */
const PARKED_CHECKOUT_MS=2*3600_000;
/** S1: after an account's unpaid claim on a domain was released (cancelled,
 * expired or displaced), the same account cannot park that domain again for this long. */
const PARKED_DOMAIN_COOLDOWN_MS=24*3600_000;
/** White-label: provider-named internal codes never reach customers. */
export function customerErrorCode(code:string|null):string|null{return code?code.replace(/^(?:HOSTINGER|HPANEL)_/,'HOSTING_').replace(/^TUS_/,'HOSTING_UPLOAD_'):code;}
const bridgeResponse=z.object({
  jobId:z.string(),siteId:z.string(),state:z.enum(['awaiting_input','running','failed','succeeded']),step:z.string().max(80),
  cmsInstalled:z.boolean().default(false),errorCode:z.string().max(80).nullable().optional(),cmsVersion:z.string().max(40).optional(),
  connection:z.object({origin:z.string(),keyId:z.string().regex(/^[A-Za-z0-9_-]{1,80}$/),healthPath:z.literal('/benos-health.php'),signingSecret:z.string().min(43).max(100)}).optional(),
});

function parseJson(value:string|null):Record<string,unknown>{try{return JSON.parse(value||'{}') as Record<string,unknown>;}catch{return {};}}
export function normalizeHostingDomain(input:string):string {
  assert(!/[\s:/\\@?#%]/.test(input),'INVALID_DOMAIN','请输入完整域名，不要填写协议、端口或路径');
  let domain:string;
  try{domain=new URL('https://'+input).hostname.toLowerCase();}catch{throw new AppError('INVALID_DOMAIN','域名格式无效');}
  const labels=domain.split('.');
  assert(domain.length<=253&&labels.length>=2&&labels.every(label=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label)),'INVALID_DOMAIN','域名格式无效');
  assert(!/^\d+(?:\.\d+){3}$/.test(domain)&&!['localhost','local','internal','test','invalid'].includes(labels.at(-1)!)&&!domain.endsWith('.localhost'),'INVALID_DOMAIN','请使用可公开验证的正式域名');
  return domain;
}
function publicHttps(value:string):URL {
  let url:URL;try{url=new URL(value);}catch{throw new AppError('HOSTING_CONFIGURATION_INVALID','托管连接配置无效',503);}
  assert(url.protocol==='https:'&&!url.username&&!url.password&&!url.search&&!url.hash&&(!url.port||url.port==='443'),'HOSTING_CONFIGURATION_INVALID','托管连接仅支持标准 HTTPS 地址',503);
  normalizeHostingDomain(url.hostname);return url;
}
function configuration(config:Integration):BridgeConfig {
  assert(config.provider==='benos-bridge','HOSTING_PROVIDER_UNSUPPORTED','托管连接类型暂不支持',503);
  const raw=parseJson(config.public_config_json);
  if(raw.deploymentMode==='hostinger-tus-bootstrap'){const checked=bootstrapConfiguration.parse(raw);return {...checked,endpoint:'',keyId:'bootstrap'} as BridgeConfig;}
  const checked=z.object({endpoint:z.string(),keyId:z.string().regex(/^[A-Za-z0-9_-]{1,80}$/)}).passthrough().safeParse(parseJson(config.public_config_json));
  assert(checked.success,'HOSTING_CONFIGURATION_INVALID','托管连接配置不完整',503);
  const url=publicHttps(checked.data.endpoint);
  assert(/^\/[A-Za-z0-9/_-]*$/.test(url.pathname)&&!url.pathname.includes('//')&&!url.pathname.includes('..'),'HOSTING_CONFIGURATION_INVALID','托管连接路径无效',503);
  return {...checked.data,endpoint:url.href.replace(/\/$/,''),keyId:checked.data.keyId} as BridgeConfig;
}
async function hmac(secret:string,value:string):Promise<string>{
  const raw=new TextEncoder().encode(secret);
  assert(raw.length>=32,'HOSTING_CONFIGURATION_INVALID','托管签名密钥长度不足',503);
  const key=await crypto.subtle.importKey('raw',raw,{name:'HMAC',hash:'SHA-256'},false,['sign']);
  return base64url(new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(value))));
}
export async function signHostingRequest(url:string,method:string,rawBody:string,secret:string,keyId:string,siteId:string,idempotencyKey='',protocol:Protocol='BENOS-BRIDGE-V1',now=Date.now()):Promise<Record<string,string>>{
  const parsed=new URL(url),timestamp=String(Math.floor(now/1000)),nonce=randomToken(18);
  const canonical=[protocol,keyId,siteId,timestamp,nonce,method.toUpperCase(),parsed.pathname+parsed.search,await sha256(rawBody),idempotencyKey].join('\n');
  return {'X-Benos-Key-Id':keyId,'X-Benos-Site-Id':siteId,'X-Benos-Timestamp':timestamp,'X-Benos-Nonce':nonce,'X-Benos-Signature':await hmac(secret,canonical),'Idempotency-Key':idempotencyKey,'Content-Type':'application/json'};
}
export async function signedHostingFetch(url:string,method:string,bodyData:unknown,secret:string,keyId:string,siteId:string,idempotencyKey='',protocol:Protocol='BENOS-BRIDGE-V1',responseLimit=131072){
  assert(Number.isSafeInteger(responseLimit)&&responseLimit>=131072&&responseLimit<=12*1048576,'HOSTING_RESPONSE_LIMIT_INVALID','托管响应限制无效');
  publicHttps(url);
  const raw=method==='GET'?'':JSON.stringify(bodyData),headers=await signHostingRequest(url,method,raw,secret,keyId,siteId,idempotencyKey,protocol);
  const response=await fetch(url,{method,headers,body:method==='GET'?undefined:raw,redirect:'manual',signal:AbortSignal.timeout(20000)});
  assert(response.status<300||response.status>=400,'HOSTING_REDIRECT_DENIED','托管连接地址发生重定向',502);
  assert(Number(response.headers.get('content-length')||0)<=responseLimit,'HOSTING_RESPONSE_INVALID','托管响应过大',502);
  const text=await response.text();assert(new TextEncoder().encode(text).byteLength<=responseLimit,'HOSTING_RESPONSE_INVALID','托管响应过大',502);
  const timestamp=response.headers.get('X-Benos-Timestamp')||'',signature=response.headers.get('X-Benos-Signature')||'';
  assert(/^\d{10,12}$/.test(timestamp)&&Math.abs(Date.now()/1000-Number(timestamp))<=120,'HOSTING_RESPONSE_INVALID','托管响应时间无效',502);
  const expected=await hmac(secret,[protocol+'-RESPONSE',headers['X-Benos-Nonce'],String(response.status),timestamp,await sha256(text)].join('\n'));
  assert(constantTimeEqual(signature,expected),'HOSTING_RESPONSE_INVALID','托管响应签名无效',502);
  let data:unknown;try{data=JSON.parse(text);}catch{throw new AppError('HOSTING_RESPONSE_INVALID','托管响应格式无效',502);}
  return {status:response.status,data};
}
const signedFetch=signedHostingFetch;
export async function testHostingConfiguration(_env:Env,config:Integration,secret:BridgeSecret):Promise<{passed:boolean;capabilities:string[];cmsVersion:string|null}>{
  const cfg=configuration(config);
  if(cfg.adapter==='hostinger-hpanel')await testHpanelConfiguration(hpanelConfiguration.parse(cfg),secret.hostingerApiToken||'');
  if(cfg.deploymentMode==='hostinger-tus-bootstrap'){await trustedRelease(_env,bootstrapConfiguration.parse(cfg));return {passed:true,capabilities:['hpanel-rest-access','private-release-checksum','tus-bootstrap-configured'],cmsVersion:'1.9.21'};}
  assert(secret.signingSecret,'HOSTING_NOT_CONFIGURED','托管签名配置尚未完成',503);
  const response=await signedFetch(cfg.endpoint+'/capabilities','GET',null,secret.signingSecret,cfg.keyId,'platform');
  const parsed=z.object({protocol:z.literal('benos-bridge-v1'),capabilities:z.array(z.string()),cmsVersion:z.string().nullable()}).safeParse(response.data);
  assert(response.status===200&&parsed.success,'HOSTING_TEST_FAILED','托管桥能力检查未通过',502);
  assert(parsed.data.capabilities.includes('isolated-cms-initialize'),'HOSTING_TEST_FAILED','托管桥不支持独立 CMS 初始化',502);
  if(cfg.adapter==='hostinger-hpanel')assert(parsed.data.capabilities.includes('hpanel-scoped-install'),'HOSTING_TEST_FAILED','托管桥尚未配置 hPanel 账号范围',502);
  return {passed:true,capabilities:parsed.data.capabilities,cmsVersion:parsed.data.cmsVersion};
}
function safeSite(site:Site){return {id:site.id,name:site.name,domain:site.domain,cmsAdminEmail:site.cms_admin_email,projectId:site.project_id,state:site.state,createdAt:site.created_at,updatedAt:site.updated_at,previewVersionId:site.preview_version_id??null};}
function safeJob(job:Job){
  const result=parseJson(job.result_json);
  return {id:job.id,siteId:job.site_id,kind:job.kind,state:job.state,step:job.step,errorCode:customerErrorCode(job.error_code),attemptCount:job.attempt_count,createdAt:job.created_at,updatedAt:job.updated_at,secretExpiresAt:job.secret_expires_at,
    requiresPassword:!result.cmsInstalled&&(!job.secret_ciphertext||!job.secret_expires_at||job.secret_expires_at<=new Date().toISOString()),
    awaitingPayment:job.step===AWAITING_PAYMENT&&job.state==='awaiting_input',
    result:{cmsInstalled:result.cmsInstalled===true,domainVerified:result.domainVerified===true,httpsVerified:result.httpsVerified===true,...(typeof result.requiredDnsTxt==='string'?{requiredDnsTxt:result.requiredDnsTxt}:{})}};
}
async function ownedSite(env:Env,userId:string,siteId:string){const site=await env.DB.prepare('SELECT * FROM sites WHERE id=? AND user_id=?').bind(siteId,userId).first<Site>();assert(site,'NOT_FOUND','托管网站不存在',404);return site;}
async function ownedJob(env:Env,userId:string,jobId:string){const job=await env.DB.prepare('SELECT * FROM provisioning_jobs WHERE id=? AND user_id=?').bind(jobId,userId).first<Job>();assert(job,'NOT_FOUND','连接任务不存在',404);return job;}
async function eligibleSites(env:Env,userId:string,limit:number,now:string){
  return (await env.DB.prepare(`SELECT s.id FROM sites s WHERE s.user_id=? AND NOT EXISTS(SELECT 1 FROM hosting_entitlements h WHERE h.site_id=s.id AND h.user_id=s.user_id AND h.source IN ('annual','gift') AND h.state='active' AND h.starts_at<=? AND h.ends_at>?) AND ${SITE_NOT_PARKED} ORDER BY s.created_at,s.id LIMIT ?`).bind(userId,now,now,limit).all<{id:string}>()).results;
}
export async function hasHostingAccess(env:Env,userId:string,siteId:string):Promise<boolean>{
  const now=new Date().toISOString();
  if(await env.DB.prepare("SELECT h.id FROM hosting_entitlements h JOIN sites s ON s.id=h.site_id AND s.user_id=h.user_id WHERE h.site_id=? AND h.user_id=? AND h.source IN ('annual','gift') AND h.state='active' AND h.starts_at<=? AND h.ends_at>? LIMIT 1").bind(siteId,userId,now,now).first())return true;
  const sub=await hostingSubscription(env.DB,userId,now);if(!sub)return false;
  return (await eligibleSites(env,userId,sub.included_sites,now)).some(site=>site.id===siteId);
}
export async function hostingEntitlementEnd(env:Env,userId:string,siteId:string):Promise<string|null>{
  const now=new Date().toISOString(),annual=await env.DB.prepare("SELECT MAX(h.ends_at) AS ends_at FROM hosting_entitlements h JOIN sites s ON s.id=h.site_id AND s.user_id=h.user_id WHERE h.site_id=? AND h.user_id=? AND h.source IN ('annual','gift') AND h.state='active' AND h.starts_at<=? AND h.ends_at>?").bind(siteId,userId,now,now).first<{ends_at:string|null}>();
  let end=annual?.ends_at||null;const sub=await hostingSubscription(env.DB,userId,now);
  if(sub&&(await eligibleSites(env,userId,sub.included_sites,now)).some(row=>row.id===siteId)&&(!end||end<sub.ends_at))end=sub.ends_at;
  return end;
}
async function syncEntitlement(env:Env,siteId:string):Promise<void>{
  const site=await env.DB.prepare('SELECT s.*,c.origin,c.key_id,c.secret_ciphertext AS connection_secret FROM sites s JOIN site_connections c ON c.site_id=s.id WHERE s.id=?').bind(siteId).first<Site&{origin:string;key_id:string;connection_secret:string}>();assert(site,'NOT_FOUND','CMS 连接不存在',404);
  const end=await hostingEntitlementEnd(env,site.user_id,site.id),nowSeconds=Math.floor(Date.now()/1000),manuallyPaused=!!await env.DB.prepare('SELECT 1 FROM hosting_site_controls WHERE site_id=? AND paused=1').bind(site.id).first(),active=!manuallyPaused&&!!end&&Date.parse(end)>Date.now(),publish=active&&!await restricted(env.DB,site.user_id,'publish');
  const record=await env.DB.prepare("INSERT INTO hosting_lease_sync(site_id,last_issued_at,state,updated_at) VALUES(?,?,'pending',?) ON CONFLICT(site_id) DO UPDATE SET last_issued_at=MAX(hosting_lease_sync.last_issued_at+1,excluded.last_issued_at),state='pending',updated_at=excluded.updated_at RETURNING last_issued_at").bind(site.id,nowSeconds,new Date().toISOString()).first<{last_issued_at:number}>();
  assert(record&&record.last_issued_at<=nowSeconds+110,'HOSTING_SYNC_RATE_LIMITED','托管权益同步过于频繁',429);
  const issued=record.last_issued_at,until=active?Math.max(issued,Math.min(Math.floor(Date.parse(end!)/1000),issued+21600)):issued;
  try{
    assert(site.origin==='https://'+site.domain,'CMS_CONNECTION_INVALID','CMS 连接身份不匹配',409);
    const secret=await decryptSecret(site.connection_secret,env.ENCRYPTION_KEY,site.id);
    const response=await signedFetch(site.origin+'/benos-connect.php','POST',{operation:'entitlement',issuedAt:issued,validUntil:until,hostingActive:active,publishAllowed:publish},secret,site.key_id,site.id,'entitlement_'+issued,'BENOS-CMS-V1');
    const verified=z.object({siteId:z.literal(site.id),issuedAt:z.literal(issued),validUntil:z.literal(until),hostingActive:z.literal(active),publishAllowed:z.literal(publish)}).safeParse(response.data);
    assert(response.status===200&&verified.success,'HOSTING_LEASE_UNVERIFIED','CMS 托管权益尚未确认同步',502);
    const now=new Date().toISOString();await env.DB.batch([
      env.DB.prepare("UPDATE hosting_lease_sync SET state='synced',valid_until=?,hosting_active=?,publish_allowed=?,error_code=NULL,last_synced_at=?,updated_at=? WHERE site_id=? AND last_issued_at=?").bind(until,active?1:0,publish?1:0,now,now,site.id,issued),
      env.DB.prepare("UPDATE sites SET state=CASE WHEN ?=0 THEN 'suspended' WHEN state='suspended' THEN 'connected' ELSE state END,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM hosting_lease_sync WHERE site_id=? AND last_issued_at=? AND state='synced')").bind(active?1:0,now,site.id,site.id,issued)
    ]);
    await recordHostingRetention(env,site.id);
    // A provisional annual year bought while suspended counts from this resumption.
    if(active)try{if((await env.DB.prepare('SELECT state FROM sites WHERE id=?').bind(site.id).first<{state:string}>())?.state==='connected')await anchorAnnualActivations(env.DB,site.id);}catch{/* retried on the next sync */}
  }catch(error){await env.DB.prepare("UPDATE hosting_lease_sync SET state='uncertain',error_code=?,updated_at=? WHERE site_id=? AND last_issued_at=?").bind(error instanceof AppError?error.code:'HOSTING_LEASE_UNCERTAIN',new Date().toISOString(),site.id,issued).run();throw error;}
}
/** Server-side cron renewal. Expired leases independently fail closed at CMS. */
export async function reconcileHostingEntitlements(env:Env,siteId?:string):Promise<{synced:number;failed:number}>{
 const rows=siteId?[{id:siteId}]:(await env.DB.prepare('SELECT c.site_id AS id FROM site_connections c LEFT JOIN hosting_lease_sync l ON l.site_id=c.site_id ORDER BY COALESCE(l.updated_at,\'\') LIMIT 50').all<{id:string}>()).results;
 let synced=0,failed=0;for(const row of rows){try{await syncEntitlement(env,row.id);synced++;}catch{failed++;}}return {synced,failed};
}
async function requireHosting(env:Env,userId:string,siteId:string){assert(!await restricted(env.DB,userId,'publish'),'ACCOUNT_RESTRICTED','当前账号的网站连接和发布权限已冻结',403);assert(await hasHostingAccess(env,userId,siteId),'HOSTING_EXPIRED','请续费会员或该网站的年度托管服务',403);}
export async function purgeExpiredProvisioningSecrets(env:Env):Promise<void>{
  await env.DB.prepare('UPDATE provisioning_jobs SET secret_ciphertext=NULL,secret_expires_at=NULL WHERE secret_expires_at<=?').bind(new Date().toISOString()).run();
}
async function completeJobState(env:Env,job:Job,token:string,state:string,step:string,errorCode:string|null,result:Record<string,unknown>,siteState:string){
  const now=new Date().toISOString(),clear=result.cmsInstalled===true;
  await env.DB.batch([
    env.DB.prepare('UPDATE provisioning_jobs SET state=?,step=?,error_code=?,result_json=?,secret_ciphertext=CASE WHEN ? THEN NULL ELSE secret_ciphertext END,secret_expires_at=CASE WHEN ? THEN NULL ELSE secret_expires_at END,lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(state,step,errorCode,JSON.stringify(result),clear?1:0,clear?1:0,now,job.id,token),
    env.DB.prepare('UPDATE sites SET state=?,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND lease_token=?)').bind(siteState,now,job.site_id,job.id,token),
    // Jobs that stop for the platform team (or fail for good) leave an audit record, written only when this lease applied the change.
    ...(state==='failed'||step==='operator_action'?[auditWhen(env.DB,'EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND lease_token=? AND step=? AND updated_at=?)',[job.id,token,step,now],null,step==='operator_action'?'hosting.job.operator_review':'hosting.job.failed','site',job.site_id,{jobId:job.id,step,errorCode,internalErrorCode:typeof result.internalErrorCode==='string'?result.internalErrorCode:null,previousStep:job.step})]:[])
  ]);
  // A pay-first annual year counts from the site's actual opening.
  if(state==='succeeded'&&siteState==='connected')try{await anchorAnnualActivations(env.DB,job.site_id);}catch{/* the next lease sync retries */}
}
/** Neutral, non-retrying outcome for deterministic errors; null when retryable. */
function deterministicOutcome(code:string):{state:'failed'|'awaiting_input';step:string;errorCode:string}|null{
  if(TERMINAL_JOB_ERRORS[code])return {state:'failed',step:'failed',errorCode:TERMINAL_JOB_ERRORS[code]};
  if(OPERATOR_JOB_ERRORS.has(code))return {state:'awaiting_input',step:'operator_action',errorCode:'HOSTING_OPERATOR_REVIEW'};
  return null;
}
async function finalizeBootstrapEntry(env:Env,job:Job,site:Site):Promise<boolean>{
 const intent=await env.DB.prepare('SELECT secret_ciphertext,expires_at FROM hosting_bootstrap_intents WHERE job_id=?').bind(job.id).first<{secret_ciphertext:string;expires_at:number}>();if(!intent)return true;
 // The bootstrap itself enforces this timestamp on every request.
 if(intent.expires_at+120<=Date.now()/1000)return true;
 try{const secret=await decryptSecret(intent.secret_ciphertext,env.ENCRYPTION_KEY,'bootstrap:'+job.id),response=await signedFetch('https://'+site.domain+'/benos-bootstrap-'+job.id.slice(4)+'.php','POST',{operation:'finalize',schemaVersion:1,jobId:job.id,siteId:site.id,domain:site.domain},secret,'bootstrap',site.id,job.id+'_finalize');return response.status===200&&z.object({jobId:z.literal(job.id),siteId:z.literal(site.id),finalized:z.literal(true)}).safeParse(response.data).success;}catch{return false;}
}

/** HTTP work is bounded; uncertain outcomes reconcile the original remote job before retrying. */
export async function runProvisioningJob(env:Env,userId:string,jobId:string):Promise<void>{
  await purgeExpiredProvisioningSecrets(env);
  let job=await ownedJob(env,userId,jobId);const site=await ownedSite(env,userId,job.site_id);
  if(job.state==='succeeded')return;
  await requireHosting(env,userId,site.id);
  const now=new Date().toISOString(),token=randomToken(24);
  const lease=await env.DB.prepare("UPDATE provisioning_jobs SET state='running',lease_token=?,lease_until=?,attempt_count=attempt_count+1,updated_at=? WHERE id=? AND (lease_until IS NULL OR lease_until<?) AND state!='succeeded' RETURNING *").bind(token,new Date(Date.now()+300000).toISOString(),now,job.id,now).first<Job>();
  if(!lease)return;job=lease;
  try{
    const installedConnection=parseJson(job.result_json).cmsInstalled?await env.DB.prepare('SELECT origin,key_id,secret_ciphertext,health_path FROM site_connections WHERE site_id=?').bind(site.id).first<{origin:string;key_id:string;secret_ciphertext:string;health_path:string}>():null;
    if(installedConnection){
      try{
        assert(installedConnection.origin==='https://'+site.domain&&installedConnection.health_path==='/benos-health.php','CMS_CONNECTION_INVALID','CMS 连接身份不匹配',409);
        const secret=await decryptSecret(installedConnection.secret_ciphertext,env.ENCRYPTION_KEY,site.id),health=await signedFetch(installedConnection.origin+installedConnection.health_path,'GET',null,secret,installedConnection.key_id,site.id,'','BENOS-CMS-V1');
        const verified=z.object({siteId:z.literal(site.id),installed:z.literal(true),database:z.literal('ready')}).safeParse(health.data);assert(health.status===200&&verified.success,'CMS_HEALTH_UNVERIFIED','CMS 公网检查尚未通过',502);
        await env.DB.prepare('UPDATE site_connections SET last_verified_at=? WHERE site_id=?').bind(new Date().toISOString(),site.id).run();const entitlement=await reconcileHostingEntitlements(env,site.id);
        if(entitlement.failed){await completeJobState(env,job,token,'awaiting_input','activate_hosting_entitlement','HOSTING_LEASE_UNVERIFIED',{cmsInstalled:true,domainVerified:true,httpsVerified:true},'provisioning');return;}
        if(!await finalizeBootstrapEntry(env,job,site)){await completeJobState(env,job,token,'awaiting_input','finalize_installation','BOOTSTRAP_FINALIZATION_UNVERIFIED',{cmsInstalled:true,domainVerified:true,httpsVerified:true},'provisioning');return;}
        await completeJobState(env,job,token,'succeeded','connected',null,{cmsInstalled:true,domainVerified:true,httpsVerified:true},'connected');return;
      }catch{await completeJobState(env,job,token,'awaiting_input','verify_domain_https','DOMAIN_HTTPS_REQUIRED',{cmsInstalled:true,domainVerified:false,httpsVerified:false},'awaiting_dns');return;}
    }
    const configId=await allocateHostingJob(env,job.id,token);
    const config=configId?await env.DB.prepare("SELECT * FROM integration_configs WHERE id=? AND kind='hosting'").bind(configId).first<Integration>():null;
    if(!config||config.status==='disabled'){
      await completeJobState(env,job,token,'awaiting_input','configure_hosting','HOSTING_NOT_CONFIGURED',parseJson(job.result_json),'pending');return;
    }
    const cfg=configuration(config);
    assert(config.secret_ciphertext,'HOSTING_NOT_CONFIGURED','托管签名配置尚未完成',503);
    const secret=z.object({signingSecret:z.string().min(32).optional(),hostingerApiToken:z.string().optional()}).parse(JSON.parse(await decryptSecret(config.secret_ciphertext,env.ENCRYPTION_KEY,config.id)));
    let hpanel:HpanelResult|undefined,bootstrap:Awaited<ReturnType<typeof prepareBootstrap>>|undefined;
    let response:{status:number;data:unknown};
    if(cfg.deploymentMode==='hostinger-tus-bootstrap'){
      hpanel=await ensureHpanelResources(env,config.id,hpanelConfiguration.parse(cfg),secret.hostingerApiToken||'',{id:job.id,siteId:site.id,domain:site.domain});
      if(!hpanel.ready){await completeJobState(env,job,token,hpanel.state||'pending',hpanel.step||'wait_provider_setup',hpanel.errorCode||null,{cmsInstalled:false,...(hpanel.requiredDnsTxt?{requiredDnsTxt:hpanel.requiredDnsTxt}:{})},'pending');return;}
      const https=await ensureInitialHostingHttps(env,hpanelConfiguration.parse(cfg),secret.hostingerApiToken||'',{id:job.id,siteId:site.id,domain:site.domain,leaseToken:token});
      if(!https.ready){await completeJobState(env,job,token,https.state||'pending',https.step,https.errorCode||null,{cmsInstalled:false},'awaiting_dns');return;}
      bootstrap=await prepareBootstrap(env,config.id,bootstrapConfiguration.parse(cfg),secret.hostingerApiToken||'',{id:job.id,siteId:site.id,domain:site.domain,leaseToken:token});
      if(!bootstrap.ready){await completeJobState(env,job,token,'pending',bootstrap.step,null,{cmsInstalled:false},'provisioning');return;}
      // Never send DB/admin passwords until this exact uploaded bootstrap proves
      // its identity over the site's own verified HTTPS origin.
      response=await signedFetch(bootstrap.endpoint!,'POST',{operation:'probe',schemaVersion:1,jobId:job.id,siteId:site.id,domain:site.domain},bootstrap.signingSecret!,bootstrap.keyId!,site.id,job.id+'_probe_'+job.attempt_count);
      const probe=z.object({jobId:z.literal(job.id),siteId:z.literal(site.id),bootstrapReady:z.literal(true),releaseSha256:z.literal(bootstrap.releaseSha256!)}).safeParse(response.data);
      assert(response.status===200&&probe.success,'BOOTSTRAP_HTTPS_REQUIRED','域名尚未连接到已验证的安装入口',409);
      if(!bridgeResponse.safeParse(response.data).success)response={status:404,data:{}};
    }else{assert(secret.signingSecret,'HOSTING_NOT_CONFIGURED','托管签名配置尚未完成',503);response=await signedFetch(cfg.endpoint+'/jobs/'+job.id,'GET',null,secret.signingSecret,cfg.keyId,site.id);}
    let checked=response.status===200?bridgeResponse.safeParse(response.data):null;
    if(response.status===404||(checked?.success&&!checked.data.cmsInstalled&&checked.data.state==='awaiting_input')){
      if(cfg.adapter==='hostinger-hpanel'&&!hpanel){
        hpanel=await ensureHpanelResources(env,config.id,hpanelConfiguration.parse(cfg),secret.hostingerApiToken||'',{id:job.id,siteId:site.id,domain:site.domain});
        if(!hpanel.ready){await completeJobState(env,job,token,hpanel.state||'pending',hpanel.step||'wait_provider_setup',hpanel.errorCode||null,{cmsInstalled:false,...(hpanel.requiredDnsTxt?{requiredDnsTxt:hpanel.requiredDnsTxt}:{})},'pending');return;}
      }
      if(!job.secret_ciphertext||!job.secret_expires_at||job.secret_expires_at<=new Date().toISOString()){
        await env.DB.prepare('UPDATE provisioning_jobs SET secret_ciphertext=NULL,secret_expires_at=NULL WHERE id=? AND lease_token=?').bind(job.id,token).run();
        await completeJobState(env,job,token,'awaiting_input','enter_cms_password','CMS_PASSWORD_REQUIRED',{},'pending');return;
      }
      const password=await decryptSecret(job.secret_ciphertext,env.ENCRYPTION_KEY,job.id);
      await requireHosting(env,userId,site.id);
      // Provider paths are obtained from the official API and independently
      // constrained by the server-owned bridge account registry. User input
      // cannot select a filesystem path, SQL statement, host, or database name.
      response=await signedFetch(bootstrap?.endpoint||cfg.endpoint+'/jobs','POST',{schemaVersion:1,jobId:job.id,siteId:site.id,name:site.name,domain:site.domain,cmsAdminEmail:site.cms_admin_email,cmsAdminPassword:password,passwordExpiresAt:job.secret_expires_at,...(hpanel?.ready?{...(bootstrap?{}:{deployment:hpanel.deployment}),database:hpanel.database}:{})},bootstrap?.signingSecret||secret.signingSecret!,bootstrap?.keyId||cfg.keyId,site.id,job.id+'_'+job.attempt_count);
      checked=bridgeResponse.safeParse(response.data);
    }
    assert((response.status===200||response.status===202)&&checked?.success,'HOSTING_RESPONSE_INVALID','连接服务未返回有效任务结果',502);
    const result=checked.data;assert(result.siteId===site.id&&result.jobId===job.id,'HOSTING_RESPONSE_INVALID','连接任务身份不匹配',502);
    if(!result.cmsInstalled){await completeJobState(env,job,token,result.state==='failed'?'failed':result.state==='running'?'uncertain':'awaiting_input',result.step,result.errorCode||null,{cmsInstalled:false},'pending');return;}
    assert(result.connection&&result.cmsVersion,'HOSTING_RESPONSE_INVALID','已安装结果缺少站点连接身份',502);
    const connection=result.connection;
    assert(connection.origin==='https://'+site.domain,'HOSTING_RESPONSE_INVALID','CMS 连接域名不匹配',502);
    const connectionId=id('conn'),cipher=await encryptSecret(connection.signingSecret,env.ENCRYPTION_KEY,site.id);
    await env.DB.batch([
      env.DB.prepare('INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(site_id) DO UPDATE SET origin=excluded.origin,key_id=excluded.key_id,secret_ciphertext=excluded.secret_ciphertext,cms_version=excluded.cms_version,updated_at=excluded.updated_at').bind(connectionId,site.id,connection.origin,connection.keyId,cipher,connection.healthPath,result.cmsVersion,now,now),
      env.DB.prepare('UPDATE sites SET connection_id=(SELECT id FROM site_connections WHERE site_id=?) WHERE id=?').bind(site.id,site.id),
      env.DB.prepare("UPDATE provisioning_jobs SET secret_ciphertext=NULL,secret_expires_at=NULL,result_json=? WHERE id=? AND lease_token=?").bind(JSON.stringify({cmsInstalled:true}),job.id,token)
    ]);
    // Installation alone does not prove DNS, HTTPS or the public site's identity.
    try{
      const health=await signedFetch(connection.origin+connection.healthPath,'GET',null,connection.signingSecret,connection.keyId,site.id,'','BENOS-CMS-V1');
      const evidence=z.object({siteId:z.literal(site.id),installed:z.literal(true),database:z.literal('ready'),cmsVersion:z.string()}).safeParse(health.data);
      assert(health.status===200&&evidence.success,'CMS_HEALTH_UNVERIFIED','CMS 公网检查尚未通过',502);
      await requireHosting(env,userId,site.id);
      await env.DB.prepare('UPDATE site_connections SET last_verified_at=? WHERE site_id=?').bind(new Date().toISOString(),site.id).run();
      const entitlement=await reconcileHostingEntitlements(env,site.id);
      if(entitlement.failed){await completeJobState(env,job,token,'awaiting_input','activate_hosting_entitlement','HOSTING_LEASE_UNVERIFIED',{cmsInstalled:true,domainVerified:true,httpsVerified:true},'provisioning');return;}
      if(!await finalizeBootstrapEntry(env,job,site)){await completeJobState(env,job,token,'awaiting_input','finalize_installation','BOOTSTRAP_FINALIZATION_UNVERIFIED',{cmsInstalled:true,domainVerified:true,httpsVerified:true},'provisioning');return;}
      await completeJobState(env,job,token,'succeeded','connected',null,{cmsInstalled:true,domainVerified:true,httpsVerified:true},'connected');
    }catch{
      await completeJobState(env,job,token,'awaiting_input','verify_domain_https','DOMAIN_HTTPS_REQUIRED',{cmsInstalled:true,domainVerified:false,httpsVerified:false},'awaiting_dns');
    }
  }catch(error){
    const errorCode=error instanceof AppError?error.code:'HOSTING_RESULT_UNCERTAIN',stored=parseJson((await ownedJob(env,userId,job.id)).result_json),siteState=site.state==='connected'?'connected':'pending';
    const outcome=deterministicOutcome(errorCode);
    if(outcome){await completeJobState(env,job,token,outcome.state,outcome.step,outcome.errorCode,{...stored,internalErrorCode:errorCode},siteState);return;}
    await completeJobState(env,job,token,'uncertain','reconcile_remote_job',errorCode,stored,siteState);
  }
}

/** Safety net for pay-first sites: if the payment was fulfilled but the
 * follow-up that starts provisioning did not run (worker stopped in between),
 * the scheduler starts the job as soon as the site's own paid or gifted
 * hosting is in force. Guarded by the parked step, so it can only fire once. */
async function releasePaidParkedJobs(env:Env,now:string):Promise<void>{
  const released=(await env.DB.prepare("UPDATE provisioning_jobs SET state='pending',step='configure_hosting',error_code=NULL,updated_at=?1 WHERE state='awaiting_input' AND step=?2 AND EXISTS(SELECT 1 FROM hosting_entitlements h WHERE h.site_id=provisioning_jobs.site_id AND h.user_id=provisioning_jobs.user_id AND h.source IN ('annual','gift') AND h.state='active' AND h.starts_at<=?1 AND h.ends_at>?1) RETURNING id,site_id").bind(now,AWAITING_PAYMENT).all<{id:string;site_id:string}>()).results;
  for(const row of released)await auditStatement(env.DB,null,'hosting.annual.provisioning_started','site',row.site_id,{jobId:row.id,via:'maintenance'}).run();
}
/** An unpaid pay-first site must not hold a domain, a project binding or a
 * place in the account forever. Released only while it was never paid, never
 * provisioned and every order for it is closed (open checkouts are expired at
 * the provider first). Guarded in one batch; also used by the customer cancel. */
export async function releaseParkedSite(env:Env,userId:string,jobId:string,via:'customer'|'expired',requestId:string|null=null,runtime:import('./payments').PaymentRuntime={}):Promise<{siteId:string;domain:string}>{
  const job=await env.DB.prepare('SELECT j.id,j.site_id,j.state,j.step,j.created_at,s.domain FROM provisioning_jobs j JOIN sites s ON s.id=j.site_id AND s.user_id=j.user_id WHERE j.id=? AND j.user_id=?').bind(jobId,userId).first<{id:string;site_id:string;state:string;step:string;created_at:string;domain:string}>();
  assert(job,'NOT_FOUND','连接任务不存在',404);
  assert(job.state==='awaiting_input'&&job.step===AWAITING_PAYMENT,'HOSTING_CANCEL_UNAVAILABLE','只能取消尚未付款、尚未开通的网站',409);
  const {closeUnpaidOrder}=await import('./payments');
  const orders=(await env.DB.prepare("SELECT id,checkout_id FROM orders WHERE user_id=? AND kind='hosting' AND hosting_site_id=? ORDER BY created_at").bind(userId,job.site_id).all<{id:string;checkout_id:string|null}>()).results;
  for(const order of orders)assert(await closeUnpaidOrder(env,userId,order.id,runtime)==='closed','HOSTING_PAYMENT_RECEIVED','该网站已收到付款，付款确认后会自动开始开通',409);
  const guard="EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND site_id=? AND state='awaiting_input' AND step='awaiting_payment' AND attempt_count=0) AND NOT EXISTS(SELECT 1 FROM hosting_entitlements WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_annual_activations WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM site_connections WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM orders WHERE hosting_site_id=? AND kind='hosting' AND state NOT IN ('expired','failed')) AND NOT EXISTS(SELECT 1 FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id WHERE o.hosting_site_id=?)";
  const binds=[job.id,job.site_id,job.site_id,job.site_id,job.site_id,job.site_id,job.site_id];
  const results=await env.DB.batch([
    auditWhen(env.DB,guard,binds,via==='customer'?userId:null,'hosting.annual.unpaid_site_released','site',job.site_id,{jobId:job.id,domain:job.domain,via,userId,claimCreatedAt:job.created_at,hadCheckout:orders.some(order=>!!order.checkout_id)},requestId),
    env.DB.prepare(`DELETE FROM hosting_domains WHERE site_id=? AND ${guard}`).bind(job.site_id,...binds),
    env.DB.prepare(`DELETE FROM provisioning_jobs WHERE id=? AND ${guard}`).bind(job.id,...binds),
    env.DB.prepare("DELETE FROM sites WHERE id=? AND user_id=? AND state='pending' AND NOT EXISTS(SELECT 1 FROM provisioning_jobs WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_domains WHERE site_id=?)").bind(job.site_id,userId,job.site_id,job.site_id)
  ]);
  assert(Number(results[3]?.meta?.changes||0)>0,'HOSTING_CANCEL_UNAVAILABLE','该网站的付款或开通状态已变化，请刷新后核对',409);
  return {siteId:job.site_id,domain:job.domain};
}
type ParkedClaim={jobId:string;siteId:string;userId:string;domain:string;createdAt:string;orders:{id:string;state:string;created_at:string;expires_at:string}[]};
/** Another account's unpaid pay-first claim on `domain` (never paid, never provisioned). */
async function parkedClaimOn(env:Env,domain:string,exceptUserId:string):Promise<ParkedClaim|null>{
  const row=await env.DB.prepare("SELECT j.id,j.site_id,j.user_id,j.created_at FROM hosting_domains d JOIN sites s ON s.id=d.site_id JOIN provisioning_jobs j ON j.site_id=s.id AND j.user_id=s.user_id WHERE d.domain=? AND s.user_id<>? AND j.state='awaiting_input' AND j.step=? AND j.attempt_count=0 LIMIT 1").bind(domain,exceptUserId,AWAITING_PAYMENT).first<{id:string;site_id:string;user_id:string;created_at:string}>();
  if(!row)return null;
  const orders=(await env.DB.prepare("SELECT id,state,created_at,expires_at FROM orders WHERE user_id=? AND kind='hosting' AND hosting_site_id=?").bind(row.user_id,row.site_id).all<{id:string;state:string;created_at:string;expires_at:string}>()).results;
  return {jobId:row.id,siteId:row.site_id,userId:row.user_id,domain,createdAt:row.created_at,orders};
}
/** The TXT value that proves control of `domain` for this account
 * (record `_benos-verification.<domain>`, the name domain changes use too). */
export async function domainOwnershipToken(env:Env,userId:string,domain:string):Promise<string>{
  return 'benos-owner-'+(await hmac(env.ENCRYPTION_KEY,'domain-owner\n'+userId+'\n'+domain)).slice(0,32);
}
async function domainOwnershipProven(env:Env,userId:string,domain:string):Promise<boolean>{
  try{
    const response=await fetchWithoutRedirect('https://cloudflare-dns.com/dns-query?name='+encodeURIComponent('_benos-verification.'+domain)+'&type=TXT',{headers:{accept:'application/dns-json'},signal:AbortSignal.timeout(10000)});
    if(!response.ok)return false;const raw=await response.text();if(raw.length>65536)return false;
    const result=JSON.parse(raw) as {Status?:number;Answer?:{type:number;data:string}[]},token=await domainOwnershipToken(env,userId,domain);
    return result.Status===0&&Array.isArray(result.Answer)&&result.Answer.some(answer=>answer.type===16&&String(answer.data).replace(/"\s*"/g,'').replace(/^"|"$/g,'')===token);
  }catch{return false;}
}
const PAID_ORDER_STATES=['paid','review','refunded'],OPEN_ORDER_STATES=['created','pending'];
type DisplacementPath='membership'|'pay_first'|'domain_change';
/** S1 (round 3): another account's unpaid claim on the domain gives way only
 * - to an account that proves control of the domain with the TXT record
 *   `_benos-verification.<domain>` = its own token. A free membership slot, a
 *   live site (domain change) or the claim's age prove nothing about the domain
 *   (requirement: 域名归属 is part of the create check; typing a domain is no
 *   proof), so an unproven account never takes a domain, whatever path it uses
 *   (R3-S1a, R3-S1b), and a concurrent unproven create cannot slip in after the
 *   prover closed the claim's checkout (R3-S1c);
 * - when the creation that displaces it can actually go through (`ready`: slot,
 *   cap, restriction, project and request key are checked first, R2-S1); the
 *   release itself is a guarded part of the same batch as the insert, so a create
 *   that still fails leaves the claim untouched;
 * - never once a payment arrived (or is in flight at the provider).
 * Every checkout closed on a displacement attempt is audited, and the release
 * names the account that displaced it (R2-S5).
 * Returns a builder of the release statements (prepended to the insert batch,
 * each guarded by the insert's own condition), or null. */
export async function claimDisplacement(env:Env,userId:string,domain:string,path:DisplacementPath,options:{ready:()=>Promise<boolean>;requestId:string|null;runtime:import('./payments').PaymentRuntime;actorId?:string}):Promise<((condition:string,binds:unknown[])=>D1PreparedStatement[])|null>{
  const claim=await parkedClaimOn(env,domain,userId);if(!claim)return unverifiedHoldDisplacement(env,userId,domain,path,options);
  if(claim.orders.some(order=>PAID_ORDER_STATES.includes(order.state)))return null;
  if(!await options.ready())return null;
  const proven=await domainOwnershipProven(env,userId,domain);
  if(!proven)throw new AppError('DOMAIN_OWNERSHIP_PROOF_REQUIRED','该域名已有其他账号尚未付款的开通申请。如果域名属于你，请按“域名归属验证”添加 TXT 记录后重试',409);
  const {closeUnpaidOrder}=await import('./payments');
  const closeAudit=(orderId:string,outcome:string)=>auditStatement(env.DB,options.actorId??userId,'hosting.annual.unpaid_checkout_closed','site',claim.siteId,{orderId,jobId:claim.jobId,domain,userId:claim.userId,displacedBy:userId,path,outcome},options.requestId).run().catch(()=>undefined);
  try{for(const order of claim.orders)if(OPEN_ORDER_STATES.includes(order.state)){
    const outcome=await closeUnpaidOrder(env,claim.userId,order.id,options.runtime);await closeAudit(order.id,outcome);
    if(outcome!=='closed')return null;
  }}
  catch{return null;/* checkout state unconfirmed: the claim stays and the create answers SITE_CONFLICT */}
  const guard="EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND site_id=? AND state='awaiting_input' AND step='awaiting_payment' AND attempt_count=0) AND NOT EXISTS(SELECT 1 FROM hosting_entitlements WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_annual_activations WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM site_connections WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM orders WHERE hosting_site_id=? AND kind='hosting' AND state NOT IN ('expired','failed')) AND NOT EXISTS(SELECT 1 FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id WHERE o.hosting_site_id=?)";
  const guardBinds=[claim.jobId,claim.siteId,claim.siteId,claim.siteId,claim.siteId,claim.siteId,claim.siteId];
  return (condition,binds)=>{
    const when=`${guard} AND ${condition}`,all=[...guardBinds,...binds];
    return [
      auditWhen(env.DB,when,all,options.actorId??userId,'hosting.annual.unpaid_site_released','site',claim.siteId,{jobId:claim.jobId,domain,via:'displaced',userId:claim.userId,displacedBy:userId,path,ownershipProven:proven,hadCheckout:claim.orders.length>0,claimCreatedAt:claim.createdAt},options.requestId),
      env.DB.prepare(`DELETE FROM hosting_domains WHERE site_id=? AND ${when}`).bind(claim.siteId,...all),
      env.DB.prepare(`DELETE FROM provisioning_jobs WHERE id=? AND ${when}`).bind(claim.jobId,...all),
      env.DB.prepare("DELETE FROM sites WHERE id=? AND user_id=? AND state='pending' AND NOT EXISTS(SELECT 1 FROM provisioning_jobs WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_domains WHERE site_id=?)").bind(claim.siteId,claim.userId,claim.siteId,claim.siteId),
    ];
  };
}
/** R4-S1 (b): a domain change that never passed its ownership check. Shared with
 * the 7-day expiry and the customer cancel (hosting-management). A change whose TXT
 * check passed (ownership_verified_at, R4-m4) is never treated as unverified. */
export const UNVERIFIED_CHANGE="provider_attempted=0 AND ssl_attempted=0 AND ownership_verified_at IS NULL AND (state='awaiting_ownership' OR (state='uncertain' AND error_code='DOMAIN_CHANGE_RESTRICTED'))";
/** R4-S1 (a): a membership-path site stopped at the host's ownership gate. The host
 * creates nothing before that gate passes (hosting-hostinger ensureHpanelResources),
 * so such a site has no website, database, connection, payment or published data. */
const UNVERIFIED_SITE_GUARD=`EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND site_id=? AND state='awaiting_input' AND step='verify_domain_ownership' AND (lease_until IS NULL OR lease_until<?))
 AND NOT EXISTS(SELECT 1 FROM provisioning_jobs WHERE site_id=? AND id<>?)
 AND NOT EXISTS(SELECT 1 FROM hosting_provider_intents WHERE site_id=? AND (website_create_attempted=1 OR website_ready=1 OR database_create_attempted=1 OR database_ready=1))
 AND NOT EXISTS(SELECT 1 FROM site_connections WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_entitlements WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_annual_activations WHERE site_id=?)
 AND NOT EXISTS(SELECT 1 FROM orders WHERE hosting_site_id=? AND kind='hosting' AND state NOT IN ('expired','failed')) AND NOT EXISTS(SELECT 1 FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id WHERE o.hosting_site_id=?)
 AND NOT EXISTS(SELECT 1 FROM hosting_bootstrap_intents WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM publication_releases WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_lease_sync WHERE site_id=?)
 AND NOT EXISTS(SELECT 1 FROM site_retention_periods WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_site_controls WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_control_requests WHERE site_id=?)
 AND NOT EXISTS(SELECT 1 FROM hosting_domain_changes WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM cms_bundle_transfers WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM native_preview_jobs WHERE site_id=?)`;
const unverifiedSiteBinds=(jobId:string,siteId:string,now:string)=>[jobId,siteId,now,siteId,jobId,...Array<string>(15).fill(siteId)];
const UNVERIFIED_HOLD_MESSAGE='该域名已有其他账号尚未通过域名归属验证的网站开通或域名变更。如果域名属于你，请按“域名归属验证”添加 TXT 记录后重试';
/** R4-S1: a hold on `domain` by another account that never proved the domain (a
 * membership site at the host's ownership gate, or a pending domain change) gives
 * way to an account that proves it by TXT, in the same guarded batch as that
 * account's insert, with an audit row and a notice for the holder. Without the
 * proof the answer is DOMAIN_OWNERSHIP_PROOF_REQUIRED, as for a parked claim. */
async function unverifiedHoldDisplacement(env:Env,userId:string,domain:string,path:DisplacementPath,options:{ready:()=>Promise<boolean>;requestId:string|null;actorId?:string}):Promise<((condition:string,binds:unknown[])=>D1PreparedStatement[])|null>{
  const now=new Date().toISOString();
  const holdSite=await env.DB.prepare("SELECT s.id AS site_id,s.user_id,j.id AS job_id,j.created_at FROM hosting_domains d JOIN sites s ON s.id=d.site_id AND s.domain=d.domain JOIN provisioning_jobs j ON j.site_id=s.id AND j.user_id=s.user_id WHERE d.domain=? AND s.user_id<>? AND j.state='awaiting_input' AND j.step='verify_domain_ownership' LIMIT 1").bind(domain,userId).first<{site_id:string;user_id:string;job_id:string;created_at:string}>();
  const changeCondition=UNVERIFIED_CHANGE.replace(/\b(provider_attempted|ssl_attempted|ownership_verified_at|state|error_code)\b/g,'c.$1');
  const change=holdSite?null:await env.DB.prepare(`SELECT c.id,c.site_id,s.user_id,c.old_domain,c.created_at FROM hosting_domains d JOIN hosting_domain_changes c ON c.site_id=d.site_id AND c.new_domain=d.domain JOIN sites s ON s.id=c.site_id WHERE d.domain=? AND s.user_id<>? AND ${changeCondition} LIMIT 1`).bind(domain,userId).first<{id:string;site_id:string;user_id:string;old_domain:string;created_at:string}>();
  if(!holdSite&&!change)return null;
  if(!await options.ready())return null;
  if(!await domainOwnershipProven(env,userId,domain))throw new AppError('DOMAIN_OWNERSHIP_PROOF_REQUIRED',UNVERIFIED_HOLD_MESSAGE,409);
  const actor=options.actorId??userId;
  if(holdSite){
    const guardBinds=unverifiedSiteBinds(holdSite.job_id,holdSite.site_id,now),siteId=holdSite.site_id;
    return (condition,binds)=>{
      const when=`${UNVERIFIED_SITE_GUARD} AND ${condition}`,all=[...guardBinds,...binds];
      return [
        auditWhen(env.DB,when,all,actor,'hosting.unverified_site_released','site',siteId,{jobId:holdSite.job_id,domain,via:'displaced',userId:holdSite.user_id,displacedBy:userId,path,ownershipProven:true,claimCreatedAt:holdSite.created_at},options.requestId),
        env.DB.prepare(`UPDATE service_notifications SET state='superseded',site_id=NULL WHERE site_id=? AND ${when}`).bind(siteId,...all),
        env.DB.prepare(`DELETE FROM hosting_allocations WHERE site_id=? AND ${when}`).bind(siteId,...all),
        env.DB.prepare(`DELETE FROM hosting_provider_intents WHERE site_id=? AND ${when}`).bind(siteId,...all),
        env.DB.prepare(`DELETE FROM hosting_domains WHERE site_id=? AND ${when}`).bind(siteId,...all),
        env.DB.prepare(`DELETE FROM provisioning_jobs WHERE id=? AND ${when}`).bind(holdSite.job_id,...all),
        env.DB.prepare("DELETE FROM sites WHERE id=? AND user_id=? AND NOT EXISTS(SELECT 1 FROM provisioning_jobs WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM hosting_domains WHERE site_id=?) AND NOT EXISTS(SELECT 1 FROM site_connections WHERE site_id=?)").bind(siteId,holdSite.user_id,siteId,siteId,siteId),
      ];
    };
  }
  const held=change!,guard=`EXISTS(SELECT 1 FROM hosting_domain_changes WHERE id=? AND site_id=? AND new_domain=? AND ${UNVERIFIED_CHANGE} AND (lease_until IS NULL OR lease_until<?))`,guardBinds=[held.id,held.site_id,domain,now];
  return (condition,binds)=>{
    const when=`${guard} AND ${condition}`,all=[...guardBinds,...binds];
    return [
      auditWhen(env.DB,when,all,actor,'hosting.domain.change_displaced','site',held.site_id,{changeId:held.id,oldDomain:held.old_domain,newDomain:domain,domain,via:'displaced',userId:held.user_id,displacedBy:userId,path,ownershipProven:true,requestedAt:held.created_at},options.requestId),
      env.DB.prepare(`DELETE FROM hosting_domains WHERE domain=? AND site_id=? AND NOT EXISTS(SELECT 1 FROM sites WHERE id=? AND domain=?) AND ${when}`).bind(domain,held.site_id,held.site_id,domain,...all),
      env.DB.prepare(`DELETE FROM hosting_domain_changes WHERE id=? AND ${when}`).bind(held.id,...all),
    ];
  };
}
/** S1: an account whose unpaid claim on this domain expired (it had the full 24 h
 * to pay) cannot park the same domain again during the cool-down. A displaced
 * claim never counts (R2-S2); a cancelled one is re-parked with its original age
 * (parkedClaimCreatedAt), capped so one checkout lifetime remains (R3-M1). */
async function parkedDomainCoolingDown(env:Env,userId:string,domain:string):Promise<boolean>{
  return !!await env.DB.prepare("SELECT 1 FROM audit_logs WHERE action='hosting.annual.unpaid_site_released' AND created_at>? AND json_extract(details_json,'$.domain')=? AND json_extract(details_json,'$.via')='expired' AND json_extract(details_json,'$.userId')=? LIMIT 1").bind(new Date(Date.now()-PARKED_DOMAIN_COOLDOWN_MS).toISOString(),domain,userId).first();
}
/** R2-S6: the creation time a re-parked claim inherits from this account's claim
 * on the same domain that it cancelled in the last 24 h (null when none). */
async function parkedClaimCreatedAt(env:Env,userId:string,domain:string):Promise<string|null>{
  const row=await env.DB.prepare("SELECT MIN(json_extract(details_json,'$.claimCreatedAt')) AS created FROM audit_logs WHERE action='hosting.annual.unpaid_site_released' AND created_at>? AND json_extract(details_json,'$.domain')=? AND json_extract(details_json,'$.via')='customer' AND json_extract(details_json,'$.userId')=?").bind(new Date(Date.now()-PARKED_DOMAIN_COOLDOWN_MS).toISOString(),domain,userId).first<{created:string|null}>();
  return typeof row?.created==='string'&&Number.isFinite(Date.parse(row.created))?row.created:null;
}
/** R2-S2: neutral notices for the account whose unpaid claims were released by
 * the platform in the last 7 days (displaced by another account, or expired). */
async function releasedClaims(env:Env,userId:string){
  const rows=(await env.DB.prepare("SELECT action,created_at,details_json FROM audit_logs WHERE action IN ('hosting.annual.unpaid_site_released','hosting.unverified_site_released','hosting.domain.change_displaced') AND created_at>? AND json_extract(details_json,'$.userId')=? AND json_extract(details_json,'$.via') IN ('displaced','expired') ORDER BY created_at DESC LIMIT 5").bind(new Date(Date.now()-7*86400000).toISOString(),userId).all<{action:string;created_at:string;details_json:string}>()).results;
  // R3-S3: the notice says only what happened: who took the domain (a site
  // creation or a domain change; by ownership proof when the record says so) and
  // whether this claim ever had a payment link.
  return rows.map(row=>{const details=parseJson(row.details_json),displaced=details.via==='displaced';
    // R4-S1: a hold that never passed domain verification, taken over by an account that proved the domain.
    if(row.action==='hosting.unverified_site_released')return {domain:String(details.domain||''),releasedAt:row.created_at,reason:'claimed_by_other_account' as const,
      message:'该域名的网站开通尚未通过域名归属验证，另一个账号已完成域名归属验证并为此域名提交了网站开通，你的这项开通已取消，未产生费用。'};
    if(row.action==='hosting.domain.change_displaced')return {domain:String(details.domain||''),releasedAt:row.created_at,reason:'claimed_by_other_account' as const,
      message:'你为网站提交的域名变更尚未通过域名归属验证，另一个账号已完成该域名的归属验证，此变更已取消；网站继续使用原域名。'};
    const taker=details.path==='domain_change'?'为此域名提交了域名变更':details.path==='membership'||details.path==='pay_first'?'为此域名提交了网站开通':'为此域名提交了网站开通或域名变更';
    const who=details.ownershipProven?'另一个账号完成了域名归属验证，并'+taker:'另一个账号已'+taker;
    const payment=details.hadCheckout===false?'该开通未生成有效付款链接，不会扣款。':details.hadCheckout===true?'未完成的付款链接已关闭，不会扣款；如已付款，平台会核对后退款。':'未完成的付款不会扣款；如已付款，平台会核对后退款。';
    return {domain:String(details.domain||''),releasedAt:row.created_at,reason:displaced?'claimed_by_other_account':'expired',
      message:displaced?'该域名的待付款开通已释放：'+who+'。'+payment
        :'该域名的待付款开通超过保留时间，已自动释放；'+(details.hadCheckout===false?'该开通未生成有效付款链接，不会扣款。':details.hadCheckout===true?'未完成的付款链接已关闭，不会扣款。':'未完成的付款不会扣款。')};});
}
async function releaseAbandonedParkedSites(env:Env,nowMs:number):Promise<{released:number;failed:number}>{
  const now=new Date(nowMs).toISOString();
  const rows=(await env.DB.prepare("SELECT j.id,j.user_id FROM provisioning_jobs j WHERE j.state='awaiting_input' AND j.step=? AND j.created_at<? AND NOT EXISTS(SELECT 1 FROM orders o WHERE o.hosting_site_id=j.site_id AND o.kind='hosting' AND (o.expires_at>? OR o.state IN ('paid','review','refunded'))) AND NOT EXISTS(SELECT 1 FROM hosting_entitlements h WHERE h.site_id=j.site_id) ORDER BY j.updated_at LIMIT 5").bind(AWAITING_PAYMENT,new Date(nowMs-PARKED_SITE_TTL_MS).toISOString(),now).all<{id:string;user_id:string}>()).results;
  let released=0,failed=0;
  for(const row of rows){try{await releaseParkedSite(env,row.user_id,row.id,'expired');released++;}catch{failed++;await env.DB.prepare('UPDATE provisioning_jobs SET updated_at=? WHERE id=? AND step=?').bind(now,row.id,AWAITING_PAYMENT).run();}}
  return {released,failed};
}
/** Years scheduled after coverage that ended early start when it actually ended. */
async function rescheduleGapYears(env:Env,nowMs:number):Promise<number>{
  const now=new Date(nowMs).toISOString();
  const rows=(await env.DB.prepare("SELECT DISTINCT e.site_id,e.user_id FROM hosting_entitlements e WHERE e.source='annual' AND e.state='active' AND e.starts_at>? AND NOT EXISTS(SELECT 1 FROM hosting_entitlements c WHERE c.site_id=e.site_id AND c.source IN ('annual','gift') AND c.state='active' AND c.starts_at<=? AND c.ends_at>?) ORDER BY RANDOM() LIMIT 20").bind(now,now,now).all<{site_id:string;user_id:string}>()).results;
  let moved=0;for(const row of rows)try{moved+=await rescheduleUncoveredAnnualYears(env.DB,row.user_id,row.site_id,nowMs);}catch{/* next pass */}
  return moved;
}
/** M3: future annual years whose start falls in idle membership-slot capacity
 * move behind it (never while the account's membership is frozen). Per account,
 * oldest site first (the order slots are given in), so two sites of one account
 * are never deferred into the same capacity (N6); queued deferral requests
 * (term created, unfreeze, anchoring) are retried here too (N1, N2, N7). */
async function deferIdleSlotYears(env:Env,nowMs:number):Promise<number>{
  const now=new Date(nowMs).toISOString();
  const queued=await processDeferralRequests(env.DB).catch(()=>0);
  const rows=(await env.DB.prepare("SELECT DISTINCT e.user_id FROM hosting_entitlements e WHERE e.source='annual' AND e.state='active' AND e.starts_at>? AND EXISTS(SELECT 1 FROM subscriptions s WHERE s.user_id=e.user_id AND s.state IN ('active','cancelled') AND s.ends_at>?) ORDER BY RANDOM() LIMIT 20").bind(now,now).all<{user_id:string}>()).results;
  let moved=queued;for(const row of rows)try{moved+=await deferAccountAnnualYears(env.DB,row.user_id,nowMs);}catch{/* next pass */}
  return moved;
}
/** Called by scheduled maintenance; each remote job keeps its own bounded lease. */
export async function processPendingHostingJobs(env:Env,limit=10):Promise<{processed:number;deferred:number;released:number;rescheduled:number;extended:number}>{
  await purgeExpiredProvisioningSecrets(env);
  const nowMs=Date.now(),now=new Date(nowMs).toISOString();
  const released=(await releaseAbandonedParkedSites(env,nowMs).catch(()=>({released:0}))).released;
  const rescheduled=await rescheduleGapYears(env,nowMs).catch(()=>0)+await deferIdleSlotYears(env,nowMs).catch(()=>0);
  const extended=(await extendUnopenedAnnualYears(env.DB,nowMs).catch(()=>({extended:0}))).extended;
  await releasePaidParkedJobs(env,now);
  const rows=(await env.DB.prepare("SELECT id,user_id FROM provisioning_jobs WHERE state IN ('pending','running','uncertain','awaiting_input') AND (lease_until IS NULL OR lease_until<?) AND (step NOT IN ('enter_cms_password','operator_action','review_website_setup','awaiting_payment')) ORDER BY updated_at LIMIT ?").bind(now,Math.max(1,Math.min(limit,25))).all<{id:string;user_id:string}>()).results;
  let processed=0,deferred=0;
  // A job that cannot run now (no hosting coverage, account frozen) moves to the back of the queue instead of holding its head.
  for(const row of rows){try{await runProvisioningJob(env,row.user_id,row.id);processed++;}catch{deferred++;await env.DB.prepare('UPDATE provisioning_jobs SET updated_at=? WHERE id=? AND (lease_until IS NULL OR lease_until<?)').bind(new Date().toISOString(),row.id,new Date().toISOString()).run();}}
  return {processed,deferred,released,rescheduled,extended};
}

export const hostingRoutes=new Hono<App>();
hostingRoutes.use('*',requireAuth);
hostingRoutes.post('/admin/sites/:id/reconcile-entitlement',requireRole('owner','admin'),async c=>{
  const result=await reconcileHostingEntitlements(c.env,c.req.param('id'));
  await auditStatement(c.env.DB,c.get('auth').user.id,'hosting.entitlement.reconcile','site',c.req.param('id'),result,c.get('requestId')).run();return ok(c,result,result.failed?202:200);
});
hostingRoutes.get('/sites',async c=>{
  await purgeExpiredProvisioningSecrets(c.env);
  const userId=c.get('auth').user.id,now=new Date().toISOString();
  const [rows,sub,bridge,isFrozen,catalog,payment]=await Promise.all([c.env.DB.prepare('SELECT s.*,p.current_version_id AS preview_version_id FROM sites s LEFT JOIN projects p ON p.id=s.project_id AND p.user_id=s.user_id AND p.archived_at IS NULL WHERE s.user_id=? ORDER BY s.created_at DESC').bind(userId).all<Site>(),activeSubscription(c.env.DB,userId,now),availableHostingPool(c.env),restricted(c.env.DB,userId,'publish'),currentCatalog(c.env.DB),paymentReady(c.env)]);
  const eligible=(await eligibleSites(c.env,userId,100000,now)).length,included=sub?.included_sites||0,used=Math.min(eligible,included),slotFree=!!sub&&eligible<included;
  return ok(c,{items:rows.results.map(safeSite),entitlement:{includedSites:sub?.included_sites||0,subscriptionEndsAt:sub?.ends_at||null,canCreate:slotFree&&!isFrozen,
    membershipSitesUsed:used,sitesOverLimit:Math.max(0,eligible-included),canCreateAnnual:!slotFree&&!isFrozen&&catalog.enabled&&payment&&!!catalog.catalog.cnyPricing,annualPriceCents:catalog.catalog.cnyPricing?.hostingAnnualPriceCents??null,currency:'CNY',pricingReady:!!catalog.catalog.cnyPricing,catalogVersionId:catalog.id},bridgeReady:!!bridge,
    releasedClaims:await releasedClaims(c.env,userId)});
});
/** R2-S2: the TXT record that proves this account controls a domain held by
 * another account's unpaid claim (also accepted while that claim's checkout is open). */
hostingRoutes.get('/domain-ownership',async c=>{
  const userId=c.get('auth').user.id,domain=normalizeHostingDomain(c.req.query('domain')||'');
  return ok(c,{domain,record:{type:'TXT',name:'_benos-verification.'+domain,value:await domainOwnershipToken(c.env,userId,domain),purpose:'验证域名属于你；添加后重新创建网站'}});
});
async function paymentReady(env:Env):Promise<boolean>{return (await(await import('./commerce')).publicPaymentAvailability(env)).ready;}
type PaymentState={orderId:string|null;state:string|null;amountCents:number|null;currency:'USD'|'CNY';expiresAt:string|null;checkoutUrl:string|null;checkoutState:string|null;errorCode:string|null};
/** The pay-first order is an ordinary hosting order with a request key derived
 * from the job, so replays of the create request return the same order and the
 * same checkout session; it can never produce a second charge for this site. */
async function annualCheckout(env:Env,runtime:import('./payments').PaymentRuntime,userId:string,job:Job,catalogVersionId?:string):Promise<PaymentState>{
  const requestKey='site-annual-'+job.id.slice(4);let result:{orderId:string;checkoutUrl:string|null;checkoutState:string}|null=null,errorCode:string|null=null;
  try{result=await (await import('./payments')).createCheckout(env,userId,{kind:'hosting',siteId:job.site_id,requestKey,...(catalogVersionId?{catalogVersionId}:{})},runtime);}
  catch(error){errorCode=error instanceof AppError?error.code:'PAYMENT_PROVIDER_UNCONFIRMED';}
  const order=await env.DB.prepare("SELECT id,state,amount_cents,currency,expires_at FROM orders WHERE user_id=? AND idempotency_key=? AND kind='hosting'").bind(userId,requestKey).first<Pick<Order,'id'|'state'|'amount_cents'|'currency'|'expires_at'>>();
  return {orderId:order?.id??null,state:order?.state??null,amountCents:order?.amount_cents??null,currency:order?.currency??'CNY',expiresAt:order?.expires_at??null,checkoutUrl:result?.checkoutUrl??null,checkoutState:result?.checkoutState??null,errorCode};
}
/** Payment confirmed for a site's annual hosting: start a pay-first site's
 * provisioning and refresh the CMS lease so a suspended site recovers now
 * instead of waiting for the per-minute maintenance pass. Idempotent. */
export async function afterAnnualHostingFulfilled(env:Env,userId:string,siteId:string,waitUntil?:(work:Promise<unknown>)=>void):Promise<void>{
  let resumed:{id:string}|null=null;
  if(await hasHostingAccess(env,userId,siteId)){
    resumed=await env.DB.prepare("UPDATE provisioning_jobs SET state='pending',step='configure_hosting',error_code=NULL,updated_at=? WHERE site_id=? AND user_id=? AND state='awaiting_input' AND step=? RETURNING id").bind(new Date().toISOString(),siteId,userId,AWAITING_PAYMENT).first<{id:string}>();
    if(resumed)await auditStatement(env.DB,null,'hosting.annual.provisioning_started','site',siteId,{jobId:resumed.id}).run();
  }
  // M3: this purchase can leave slot capacity idle where another site's year was
  // placed; that year moves behind it (the request was queued with the payment).
  try{await runDeferralRequest(env.DB,userId);}catch{/* maintenance retries the queued request */}
  const connected=!!await env.DB.prepare('SELECT 1 FROM site_connections WHERE site_id=?').bind(siteId).first();
  if(!waitUntil||(!resumed&&!connected))return;
  waitUntil((async()=>{
    if(connected)try{await reconcileHostingEntitlements(env,siteId);}catch{/* cron retries */}
    if(resumed)try{await runProvisioningJob(env,userId,resumed.id);}catch{/* cron retries */}
  })());
}
/** Every refusal the create batch can produce, checked before another account's
 * claim is touched (R2-S1): the slot/cap/restriction condition of the insert, the
 * request key and an already bound project. */
async function createReady(env:Env,condition:string,binds:unknown[],userId:string,key:string,projectId?:string):Promise<boolean>{
  return !!await env.DB.prepare(`SELECT 1 WHERE ${condition} AND NOT EXISTS(SELECT 1 FROM provisioning_jobs WHERE user_id=? AND idempotency_key=?)${projectId?' AND NOT EXISTS(SELECT 1 FROM sites WHERE project_id=?)':''}`).bind(...binds,userId,key,...(projectId?[projectId]:[])).first();
}
hostingRoutes.post('/sites',async c=>{
  const userId=c.get('auth').user.id;await enforceScope(c,'publish');await rateLimit(c,'hosting-create',15,3600,userId);
  const input=await body(c,inputSchema),domain=normalizeHostingDomain(input.domain),key=keySchema.safeParse(c.req.header('Idempotency-Key'));
  assert(key.success,'IDEMPOTENCY_REQUIRED','请提供稳定的请求标识');
  const annual=input.billing==='annual',runtime=(await import('./payments')).backgroundRuntime(c);
  const fingerprint=await hmac(c.env.ENCRYPTION_KEY,JSON.stringify([userId,input.cmsAdminPassword]));
  const payloadHash=await sha256(JSON.stringify([input.name,domain,input.cmsAdminEmail,input.projectId||null,fingerprint,...(annual?['annual']:[])]));
  let job=await c.env.DB.prepare('SELECT * FROM provisioning_jobs WHERE user_id=? AND idempotency_key=?').bind(userId,key.data).first<Job>();
  if(job){assert(job.payload_hash===payloadHash,'IDEMPOTENCY_CONFLICT','同一请求标识不能用于不同的网站资料',409);return ok(c,{site:safeSite(await ownedSite(c.env,userId,job.site_id)),job:safeJob(job),...(annual?{payment:await annualCheckout(c.env,runtime,userId,job,input.catalogVersionId)}:{})},202);}
  // The managed host opens sites on the main domain; www is bound later as an
  // alias. Checked after the replay lookup so an existing job is still returned.
  assert(!domain.startsWith('www.'),'INVALID_DOMAIN','请使用网站主域名（不要以 www. 开头），www 地址可在开通后作为别名绑定');
  if(input.projectId)assert(await c.env.DB.prepare('SELECT id FROM projects WHERE id=? AND user_id=? AND archived_at IS NULL').bind(input.projectId,userId).first(),'NOT_FOUND','网站项目不存在',404);
  if(annual)return createAnnualSite(c,userId,input,domain,key.data,payloadHash,runtime);
  const sub=await activeSubscription(c.env.DB,userId);assert(sub,'MEMBERSHIP_REQUIRED','创建新托管网站需要有效会员套餐，或为该网站单独购买年付托管',403);
  const siteId=id('site'),jobId=id('job'),now=new Date().toISOString(),expiry=new Date(Date.now()+PROVISIONING_PASSWORD_TTL_MS).toISOString();
  const cipher=await encryptSecret(input.cmsAdminPassword,c.env.ENCRYPTION_KEY,jobId);
  const slot=`(SELECT COUNT(*) FROM sites s WHERE s.user_id=? AND NOT EXISTS(SELECT 1 FROM hosting_entitlements h WHERE h.site_id=s.id AND h.user_id=s.user_id AND h.source IN ('annual','gift') AND h.state='active' AND h.starts_at<=? AND h.ends_at>?) AND ${SITE_NOT_PARKED}) < COALESCE((SELECT included_sites FROM subscriptions WHERE user_id=? AND membership_frozen_by IS NULL AND state IN ('active','cancelled') AND starts_at<=? AND ends_at>? ORDER BY CASE tier WHEN 'pro' THEN 0 ELSE 1 END,ends_at DESC LIMIT 1),0) AND NOT EXISTS(SELECT 1 FROM user_restrictions WHERE user_id=? AND scope='publish' AND revoked_at IS NULL AND starts_at<=? AND (ends_at IS NULL OR ends_at>?))`;
  const slotBinds=[userId,now,now,userId,now,now,userId,now,now];
  // S1 (round 2): an unpaid claim of another account on this domain gives way only
  // as part of this batch, and only when this create can go through.
  const displace=await claimDisplacement(c.env,userId,domain,'membership',{ready:()=>createReady(c.env,slot,slotBinds,userId,key.data,input.projectId),requestId:c.get('requestId'),runtime});
  try{
    await c.env.DB.batch([
      ...(displace?displace(slot,slotBinds):[]),
      c.env.DB.prepare(`INSERT INTO sites(id,user_id,project_id,name,domain,cms_admin_email,state,created_at,updated_at) SELECT ?,?,?,?,?,?,'pending',?,? WHERE ${slot}`).bind(siteId,userId,input.projectId||null,input.name,domain,input.cmsAdminEmail,now,now,...slotBinds),
      c.env.DB.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,state,step,idempotency_key,payload_hash,secret_ciphertext,secret_expires_at,created_at,updated_at) SELECT ?,?,?,'create','pending','configure_hosting',?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM sites WHERE id=?)").bind(jobId,siteId,userId,key.data,payloadHash,cipher,expiry,now,now,siteId)
    ]);
  }catch{
    const existing=await c.env.DB.prepare('SELECT * FROM provisioning_jobs WHERE user_id=? AND idempotency_key=?').bind(userId,key.data).first<Job>();
    if(existing){assert(existing.payload_hash===payloadHash,'IDEMPOTENCY_CONFLICT','同一请求标识不能用于不同资料',409);return ok(c,{site:safeSite(await ownedSite(c.env,userId,existing.site_id)),job:safeJob(existing)},202);}
    throw new AppError('SITE_CONFLICT','域名或网站项目已经建立连接任务',409);
  }
  job=await c.env.DB.prepare('SELECT * FROM provisioning_jobs WHERE id=?').bind(jobId).first<Job>();
  assert(job,'SITE_LIMIT_REACHED','当前套餐可托管的网站名额已用完，可为新网站单独购买年付托管',409);
  await auditStatement(c.env.DB,userId,'hosting.create','site',siteId,{domain},c.get('requestId')).run();
  await runProvisioningJob(c.env,userId,job.id);
  return ok(c,{site:safeSite(await ownedSite(c.env,userId,siteId)),job:safeJob(await ownedJob(c.env,userId,job.id))},202);
});
type CreateInput=z.infer<typeof inputSchema>;
/** D16 pay-first: a site beyond the membership slots is created in 'pending'
 * with its job parked at 'awaiting_payment' (never provisioned, never retried
 * by cron) plus one hosting order. Payment fulfilment starts provisioning. */
async function createAnnualSite(c:import('hono').Context<App>,userId:string,input:CreateInput,domain:string,key:string,payloadHash:string,runtime:import('./payments').PaymentRuntime){
  const env=c.env,catalog=await currentCatalog(env.DB);
  assert(catalog.enabled,'PURCHASES_PAUSED','平台暂时停止新订单，已有权益不受影响',503);
  assert((input.catalogVersionId??BUILTIN_CATALOG_ID)===catalog.id,'CATALOG_CHANGED','套餐版本已变化，请刷新并确认最新价格后重新下单',409);
  assert(await paymentReady(env),'PAYMENT_NOT_CONFIGURED','支付尚未配置完成，请稍后再试',503);
  assert(catalog.catalog.cnyPricing,'ALIPAY_PRICING_NOT_CONFIGURED','管理员尚未设置人民币托管价格，暂不能付款',503);
  assert(!await parkedDomainCoolingDown(env,userId,domain),'HOSTING_UNPAID_DOMAIN_COOLDOWN','该域名的未付款网站已超过保留时间并释放，24 小时内不能再次以待付款方式创建；有会员名额时可直接创建网站',409);
  const siteId=id('site'),jobId=id('job'),now=new Date().toISOString(),expiry=new Date(Date.now()+PROVISIONING_PASSWORD_TTL_MS).toISOString();
  const cipher=await encryptSecret(input.cmsAdminPassword,env.ENCRYPTION_KEY,jobId);
  // R2-S6: a re-park of a claim this account cancelled keeps the original age, so
  // cancelling never renews the 24 h lifetime. R3-M1 / R3-S2: the inherited age is
  // capped so that one full checkout can still be opened and paid; a re-park that
  // is accepted is always payable (and only its own expiry starts a cool-down).
  const inherited=await parkedClaimCreatedAt(env,userId,domain),payableFrom=new Date(Date.now()-PARKED_SITE_TTL_MS+PARKED_CHECKOUT_MS).toISOString();
  const claimedAt=inherited?(inherited>payableFrom?inherited:payableFrom):now;
  // Only when no membership slot is free (otherwise the normal path applies) and not publish-frozen.
  // Capped per account: an unpaid site holds its domain until it is paid, cancelled or released.
  const slot=`(SELECT COUNT(*) FROM sites s WHERE s.user_id=? AND NOT EXISTS(SELECT 1 FROM hosting_entitlements h WHERE h.site_id=s.id AND h.user_id=s.user_id AND h.source IN ('annual','gift') AND h.state='active' AND h.starts_at<=? AND h.ends_at>?) AND ${SITE_NOT_PARKED}) >= COALESCE((SELECT included_sites FROM subscriptions WHERE user_id=? AND membership_frozen_by IS NULL AND state IN ('active','cancelled') AND starts_at<=? AND ends_at>? ORDER BY CASE tier WHEN 'pro' THEN 0 ELSE 1 END,ends_at DESC LIMIT 1),0) AND NOT EXISTS(SELECT 1 FROM user_restrictions WHERE user_id=? AND scope='publish' AND revoked_at IS NULL AND starts_at<=? AND (ends_at IS NULL OR ends_at>?)) AND (SELECT COUNT(*) FROM provisioning_jobs WHERE user_id=? AND state='awaiting_input' AND step='awaiting_payment')<?`;
  const slotBinds=[userId,now,now,userId,now,now,userId,now,now,userId,MAX_PARKED_SITES];
  const displace=await claimDisplacement(env,userId,domain,'pay_first',{ready:()=>createReady(env,slot,slotBinds,userId,key,input.projectId),requestId:c.get('requestId'),runtime});
  try{
    await env.DB.batch([
      ...(displace?displace(slot,slotBinds):[]),
      env.DB.prepare(`INSERT INTO sites(id,user_id,project_id,name,domain,cms_admin_email,state,created_at,updated_at) SELECT ?,?,?,?,?,?,'pending',?,? WHERE ${slot}`).bind(siteId,userId,input.projectId||null,input.name,domain,input.cmsAdminEmail,now,now,...slotBinds),
      env.DB.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,state,step,idempotency_key,payload_hash,secret_ciphertext,secret_expires_at,result_json,error_code,created_at,updated_at) SELECT ?,?,?,'create','awaiting_input',?,?,?,?,?,?,'HOSTING_PAYMENT_REQUIRED',?,? WHERE EXISTS(SELECT 1 FROM sites WHERE id=?)").bind(jobId,siteId,userId,AWAITING_PAYMENT,key,payloadHash,cipher,expiry,JSON.stringify({cmsInstalled:false,billing:'annual'}),claimedAt,now,siteId)
    ]);
  }catch{
    const existing=await env.DB.prepare('SELECT * FROM provisioning_jobs WHERE user_id=? AND idempotency_key=?').bind(userId,key).first<Job>();
    if(existing){assert(existing.payload_hash===payloadHash,'IDEMPOTENCY_CONFLICT','同一请求标识不能用于不同资料',409);return ok(c,{site:safeSite(await ownedSite(env,userId,existing.site_id)),job:safeJob(existing),payment:await annualCheckout(env,runtime,userId,existing,input.catalogVersionId)},202);}
    throw new AppError('SITE_CONFLICT','域名或网站项目已经建立连接任务',409);
  }
  const job=await env.DB.prepare('SELECT * FROM provisioning_jobs WHERE id=?').bind(jobId).first<Job>();
  if(!job){const parked=await env.DB.prepare('SELECT COUNT(*) AS n FROM provisioning_jobs WHERE user_id=? AND state=? AND step=?').bind(userId,'awaiting_input',AWAITING_PAYMENT).first<{n:number}>();
    assert(Number(parked?.n||0)<MAX_PARKED_SITES,'HOSTING_UNPAID_SITE_LIMIT','待付款的新网站已达上限，请先完成付款或取消未付款的网站',409);}
  assert(job,'HOSTING_SLOT_AVAILABLE','当前会员仍有可用托管名额，请直接创建网站，无需单独购买年付托管',409);
  await auditStatement(env.DB,userId,'hosting.create','site',siteId,{domain,billing:'annual'},c.get('requestId')).run();
  return ok(c,{site:safeSite(await ownedSite(env,userId,siteId)),job:safeJob(job),payment:await annualCheckout(env,runtime,userId,job,input.catalogVersionId)},202);
}
hostingRoutes.get('/sites/:id',async c=>{
  const userId=c.get('auth').user.id,site=await ownedSite(c.env,userId,c.req.param('id'));
  const job=await c.env.DB.prepare('SELECT * FROM provisioning_jobs WHERE site_id=? AND user_id=? ORDER BY created_at DESC LIMIT 1').bind(site.id,userId).first<Job>();
  const access=await hasHostingAccess(c.env,userId,site.id),frozen=await restricted(c.env.DB,userId,'publish');
  const manualHold=!!await c.env.DB.prepare('SELECT 1 FROM hosting_site_controls WHERE site_id=? AND paused=1').bind(site.id).first();
  const lease=await c.env.DB.prepare('SELECT state,valid_until,hosting_active,publish_allowed,error_code,last_synced_at FROM hosting_lease_sync WHERE site_id=?').bind(site.id).first<{state:string;valid_until:number|null;hosting_active:number;publish_allowed:number;error_code:string|null;last_synced_at:string|null}>();
  const open=await c.env.DB.prepare("SELECT id,state,amount_cents,currency,expires_at FROM orders WHERE user_id=? AND kind='hosting' AND hosting_site_id=? AND state IN ('created','pending') AND expires_at>? ORDER BY created_at DESC LIMIT 1").bind(userId,site.id,new Date().toISOString()).first<Pick<Order,'id'|'state'|'amount_cents'|'currency'|'expires_at'>>();
  return ok(c,{site:safeSite(site),pendingPayment:open?{orderId:open.id,state:open.state,amountCents:open.amount_cents,currency:open.currency,expiresAt:open.expires_at}:null,management:await (await import('./hosting-management')).hostingManagementDetail(c.env,site,c.get('auth').user.role),retention:await siteRetention(c.env,site.id),job:job?safeJob(job):null,canManageHosting:access&&!frozen,canPublish:access&&!frozen&&!manualHold&&site.state==='connected'&&lease?.state==='synced'&&lease.hosting_active===1&&lease.publish_allowed===1&&(lease.valid_until||0)>Date.now()/1000,hostingLease:lease?{state:lease.state,validUntil:lease.valid_until,errorCode:customerErrorCode(lease.error_code),lastSyncedAt:lease.last_synced_at}:null});
});
/** What renewing this site for one year would charge now and the coverage it
 * would buy (requirement: 本次应付金额和续费后到期日). Read-only; the actual
 * period is fixed by the same rule when the payment is confirmed. */
hostingRoutes.get('/sites/:id/renewal-quote',async c=>{
  const userId=c.get('auth').user.id,site=await ownedSite(c.env,userId,c.req.param('id'));
  const [catalog,payment,plan]=await Promise.all([currentCatalog(c.env.DB),paymentReady(c.env),annualRenewalPlan(c.env.DB,userId,site.id)]);
  assert(plan,'NOT_FOUND','托管网站不存在',404);
  return ok(c,{siteId:site.id,amountCents:catalog.catalog.cnyPricing?.hostingAnnualPriceCents??null,currency:'CNY',pricingReady:!!catalog.catalog.cnyPricing,catalogVersionId:catalog.id,purchasable:catalog.enabled&&payment&&!!catalog.catalog.cnyPricing,
    startsAt:plan.startsAt,endsAt:plan.endsAt,basis:plan.basis,estimated:plan.estimated,currentCoverageEndsAt:plan.coverageEndsAt,asOf:new Date().toISOString()});
});
hostingRoutes.get('/jobs/:id',async c=>ok(c,safeJob(await ownedJob(c.env,c.get('auth').user.id,c.req.param('id')))));
hostingRoutes.patch('/sites/:id',async c=>{
  const userId=c.get('auth').user.id,site=await ownedSite(c.env,userId,c.req.param('id'));await requireHosting(c.env,userId,site.id);
  const input=await body(c,z.object({projectId:z.string().regex(/^prj_[a-f0-9]{32}$/)}).strict());
  assert(!site.project_id||site.project_id===input.projectId,'PROJECT_ALREADY_BOUND','网站已关联项目，不能改绑以覆盖其他设计',409);
  assert(await c.env.DB.prepare('SELECT id FROM projects WHERE id=? AND user_id=? AND archived_at IS NULL').bind(input.projectId,userId).first(),'NOT_FOUND','网站项目不存在',404);
  try{await c.env.DB.prepare('UPDATE sites SET project_id=?,updated_at=? WHERE id=? AND (project_id IS NULL OR project_id=?)').bind(input.projectId,new Date().toISOString(),site.id,input.projectId).run();}catch{throw new AppError('PROJECT_ALREADY_BOUND','该项目已经关联其他托管网站',409);}
  return ok(c,{site:safeSite(await ownedSite(c.env,userId,site.id))});
});
hostingRoutes.post('/jobs/:id/retry',async c=>{
  const userId=c.get('auth').user.id,input=await body(c,z.object({cmsAdminPassword:z.string().min(12).max(256).optional()}).strict()),job=await ownedJob(c.env,userId,c.req.param('id'));
  if(job.step===AWAITING_PAYMENT&&job.state==='awaiting_input'){
    assert(!await restricted(c.env.DB,userId,'publish'),'ACCOUNT_RESTRICTED','当前账号的网站连接和发布权限已冻结',403);
    await rateLimit(c,'hosting-retry',30,3600,userId);
    await startParkedJob(c.env,userId,job,c.get('requestId'),(await import('./payments')).backgroundRuntime(c));
  }else await rateLimit(c,'hosting-retry',30,3600,userId);
  await requireHosting(c.env,userId,job.site_id);
  if(input.cmsAdminPassword&&!parseJson(job.result_json).cmsInstalled&&job.state!=='succeeded'){
    const cipher=await encryptSecret(input.cmsAdminPassword,c.env.ENCRYPTION_KEY,job.id);
    await c.env.DB.prepare('UPDATE provisioning_jobs SET secret_ciphertext=?,secret_expires_at=? WHERE id=? AND (lease_until IS NULL OR lease_until<?)').bind(cipher,new Date(Date.now()+PROVISIONING_PASSWORD_TTL_MS).toISOString(),job.id,new Date().toISOString()).run();
  }
  await runProvisioningJob(c.env,userId,job.id);
  return ok(c,{site:safeSite(await ownedSite(c.env,userId,job.site_id)),job:safeJob(await ownedJob(c.env,userId,job.id))},202);
});
/** Starts a parked pay-first job when the site's own paid/gifted year is in
 * force, or when a membership slot is free (the customer bought a plan after
 * creating it). The slot check and the start are one guarded statement, and
 * the audit commits with it. Unpaid checkouts of a slot-covered site are closed
 * so the plan's site is never charged $30 as well. */
async function startParkedJob(env:Env,userId:string,job:Job,requestId:string|null,runtime:import('./payments').PaymentRuntime):Promise<void>{
  const now=new Date().toISOString(),own="EXISTS(SELECT 1 FROM hosting_entitlements h WHERE h.site_id=?2 AND h.user_id=?3 AND h.source IN ('annual','gift') AND h.state='active' AND h.starts_at<=?1 AND h.ends_at>?1)";
  const freeSlot=`(SELECT COUNT(*) FROM sites s WHERE s.user_id=?3 AND NOT EXISTS(SELECT 1 FROM hosting_entitlements h WHERE h.site_id=s.id AND h.user_id=s.user_id AND h.source IN ('annual','gift') AND h.state='active' AND h.starts_at<=?1 AND h.ends_at>?1) AND ${SITE_NOT_PARKED}) < COALESCE((SELECT included_sites FROM subscriptions WHERE user_id=?3 AND membership_frozen_by IS NULL AND state IN ('active','cancelled') AND starts_at<=?1 AND ends_at>?1 ORDER BY CASE tier WHEN 'pro' THEN 0 ELSE 1 END,ends_at DESC LIMIT 1),0)`;
  const covered=!!await env.DB.prepare(`SELECT 1 WHERE ${own}`).bind(now,job.site_id,userId).first();
  const results=await env.DB.batch([
    env.DB.prepare(`UPDATE provisioning_jobs SET state='pending',step='configure_hosting',error_code=NULL,updated_at=?1 WHERE id=?4 AND user_id=?3 AND state='awaiting_input' AND step=?5 AND (${own} OR ${freeSlot})`).bind(now,job.site_id,userId,job.id,AWAITING_PAYMENT),
    auditWhen(env.DB,"EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND step='configure_hosting' AND updated_at=?)",[job.id,now],userId,'hosting.annual.provisioning_started','site',job.site_id,{jobId:job.id,via:'retry',coveredBy:covered?'annual':'membership'},requestId)
  ]);
  assert(Number(results[0]?.meta?.changes||0)>0,'HOSTING_PAYMENT_REQUIRED','请先完成该网站的年付托管付款，付款确认后会自动开始开通',409);
  if(covered)return;
  const {closeUnpaidOrder}=await import('./payments');
  const open=(await env.DB.prepare("SELECT id FROM orders WHERE user_id=? AND kind='hosting' AND hosting_site_id=? AND state IN ('created','pending')").bind(userId,job.site_id).all<{id:string}>()).results;
  for(const order of open)try{await closeUnpaidOrder(env,userId,order.id,runtime);}catch{/* the checkout expires on its own; a payment then extends after the plan */}
}
/** Customer cancels an unpaid pay-first site: the open checkout is closed and
 * the domain and project binding are released immediately. */
hostingRoutes.post('/jobs/:id/cancel',async c=>{
  const userId=c.get('auth').user.id;await body(c,z.object({}).strict());await ownedJob(c.env,userId,c.req.param('id'));
  await rateLimit(c,'hosting-cancel',30,3600,userId);
  const released=await releaseParkedSite(c.env,userId,c.req.param('id'),'customer',c.get('requestId'),(await import('./payments')).backgroundRuntime(c));
  return ok(c,{cancelled:true,siteId:released.siteId,domain:released.domain});
});
hostingRoutes.post('/sites/:id/publish',async c=>{
  const userId=c.get('auth').user.id,site=await ownedSite(c.env,userId,c.req.param('id'));await requireHosting(c.env,userId,site.id);
  throw new AppError('CONNECTOR_CAPABILITY_REQUIRED','CMS 非破坏发布能力尚未启用；当前不会覆盖网站页面或草稿',409);
});
