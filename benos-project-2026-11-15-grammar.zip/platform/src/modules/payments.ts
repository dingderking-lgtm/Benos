import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { Hono } from 'hono';
import type { Env } from '../env';
import { type App, ok } from '../lib/http';
import { AppError, assert } from '../lib/errors';
import { constantTimeEqual, decryptSecret, id, sha256 } from '../lib/crypto';
import { canTopup, createOrder, getOrder, PLANS, type Order, type OrderInput } from './commerce';
import { grantCredit } from './ledger';
import { orderPlanSnapshot } from './billing-catalog';

export const STRIPE_API_VERSION='2026-10-28.endive';
const STRIPE_ORIGIN='https://api.stripe.com';
type Json=Record<string,unknown>;
export interface PaymentConfig {id:string;mode:'test'|'live';apiVersion:string;secretKey:string;webhookSecret:string;}
/** waitUntil lets fulfilment schedule follow-up work (hosting lease re-sync,
 * resumed provisioning) after the response; without it the cron picks it up. */
export interface PaymentRuntime {fetch?:typeof fetch;nowMs?:number;checkoutChannel?:'page'|'wap';waitUntil?:(work:Promise<unknown>)=>void;}
/** Request runtime for routes: background work rides the Worker's waitUntil. */
export function backgroundRuntime(c:{readonly executionCtx:{waitUntil(promise:Promise<unknown>):void}}):PaymentRuntime{
 try{const ctx=c.executionCtx;return {waitUntil:work=>ctx.waitUntil(work.catch(()=>undefined))};}catch{return {};}
}
interface Agreement {id:string;user_id:string;origin_order_id:string;config_version_id:string;provider_subscription_id:string;tier:'go'|'pro';state:string;cancel_requested:number;provider_event_at:number;}
interface Fulfillment {id:string;order_id:string;provider_reference:string;snapshot_hash:string;starts_at:string;ends_at:string|null;state:string;}
function record(value:unknown):Json {return value!==null&&typeof value==='object'&&!Array.isArray(value)?value as Json:{};}
function objectId(value:unknown):string {const candidate=typeof value==='string'?value:record(value).id;return typeof candidate==='string'?candidate:'';}
function providerId(value:unknown,prefix:string):string {const result=objectId(value);assert(new RegExp(`^${prefix}_[A-Za-z0-9_]+$`).test(result),'PAYMENT_DATA_INVALID','支付服务返回了无效标识',502);return result;}
function seconds(value:unknown):number {assert(Number.isSafeInteger(value)&&Number(value)>0,'PAYMENT_DATA_INVALID','支付时间无效',502);return Number(value);}
function isoSeconds(value:unknown):string {return new Date(seconds(value)*1000).toISOString();}
function now(runtime:PaymentRuntime):number{return runtime.nowMs??Date.now();}
function parseConfiguration(publicConfig:unknown,secret:unknown):Omit<PaymentConfig,'id'> {
 const config=record(publicConfig), secrets=record(secret);
 assert(config.mode==='test'||config.mode==='live','PAYMENT_CONFIG_INVALID','请选择支付测试或正式环境',503);
 assert((config.apiVersion??STRIPE_API_VERSION)===STRIPE_API_VERSION,'PAYMENT_CONFIG_INVALID','支付 API 版本尚未适配',503);
 const key=secrets.secretKey, webhook=secrets.webhookSecret;
 assert(typeof key==='string'&&key.startsWith(config.mode==='live'?'sk_live_':'sk_test_')&&key.length>=16,'PAYMENT_CONFIG_INVALID','支付密钥与环境不匹配',503);
 assert(typeof webhook==='string'&&webhook.startsWith('whsec_')&&webhook.length>=16,'PAYMENT_CONFIG_INVALID','请配置支付回调签名密钥',503);
 return {mode:config.mode,apiVersion:STRIPE_API_VERSION,secretKey:key,webhookSecret:webhook};
}
export async function loadPaymentConfiguration(env:Env,configId?:string):Promise<PaymentConfig> {
 const row=await env.DB.prepare(`SELECT id,public_config_json,secret_ciphertext FROM integration_configs WHERE kind='payment' AND provider='stripe'
  ${configId?'AND id=?':"AND status='active' AND test_status='passed'"} LIMIT 1`).bind(...(configId?[configId]:[])).first<{id:string;public_config_json:string;secret_ciphertext:string|null}>();
 assert(row?.secret_ciphertext,'PAYMENT_NOT_CONFIGURED','支付尚未配置完成，请稍后再试',503);
 let publicConfig:unknown,secret:unknown;
 try {publicConfig=JSON.parse(row.public_config_json);secret=JSON.parse(await decryptSecret(row.secret_ciphertext,env.ENCRYPTION_KEY,row.id));}
 catch {throw new AppError('PAYMENT_NOT_CONFIGURED','支付配置无法读取',503);}
 return {id:row.id,...parseConfiguration(publicConfig,secret)};
}
export async function stripeRequest(config:PaymentConfig,path:string,method:'GET'|'POST'='GET',params?:URLSearchParams,key?:string,runtime:PaymentRuntime={}):Promise<Json> {
 assert(path.startsWith('/v1/')&&!path.includes('..'),'PAYMENT_PATH_INVALID','支付接口无效',500);
 const headers:Record<string,string>={Authorization:`Bearer ${config.secretKey}`,'Stripe-Version':config.apiVersion};
 if(params)headers['Content-Type']='application/x-www-form-urlencoded';
 if(key)headers['Idempotency-Key']=key;
 let response:Response;
 try {response=await fetchWithoutRedirect(STRIPE_ORIGIN+path,{method,headers,body:params?.toString(),signal:AbortSignal.timeout(15_000)},runtime.fetch??fetch);}
 catch {throw new AppError('PAYMENT_PROVIDER_UNCONFIRMED','支付服务响应待确认，请查询原订单，勿重复付款',503);}
 let result:unknown;try {result=await response.json();}catch{throw new AppError('PAYMENT_PROVIDER_UNCONFIRMED','支付服务返回无效响应',503);}
 assert(response.ok,'PAYMENT_PROVIDER_ERROR','支付服务暂时无法处理，请查询原订单后重试',503);
 return record(result);
}
export async function probePaymentConfiguration(publicConfig:unknown,secret:unknown,runtime:PaymentRuntime={}):Promise<void> {
 const config={id:'probe',...parseConfiguration(publicConfig,secret)};
 const result=await stripeRequest(config,'/v1/balance','GET',undefined,undefined,runtime);
 assert(result.object==='balance'&&result.livemode===(config.mode==='live'),'PAYMENT_PROBE_FAILED','支付账户或环境校验失败',503);
}
function matchesMode(config:PaymentConfig,object:Json):void {
 assert(object.livemode===(config.mode==='live'),'PAYMENT_MODE_MISMATCH','支付环境不匹配',409);
}
export async function createCheckout(env:Env,userId:string,input:OrderInput,runtime:PaymentRuntime={}) {
 // Existing request keys retain their original merchant, currency and provider.
 const existing=await env.DB.prepare('SELECT id FROM orders WHERE user_id=? AND idempotency_key=?').bind(userId,input.requestKey).first<{id:string}>();
 if(existing){const prior=await getOrder(env.DB,existing.id,userId);await createOrder(env.DB,userId,input,prior.config_version_id,now(runtime),prior.provider==='alipay'?'alipay':'stripe');return resumeCheckout(env,userId,prior.id,{...runtime,checkoutChannel:input.checkoutChannel??runtime.checkoutChannel});}
 return (await import('./alipay')).createAlipayCheckout(env,userId,input,runtime);
}
/** Compatibility fixture/import boundary; new public sales use createCheckout. */
export async function createLegacyStripeCheckout(env:Env,userId:string,input:OrderInput,runtime:PaymentRuntime={}) {
 const active=await loadPaymentConfiguration(env), order=await createOrder(env.DB,userId,input,active.id,now(runtime));
 return resumeCheckout(env,userId,order.id,runtime);
}
function checkoutUrl(value:unknown):string {
 let parsed:URL;try{assert(typeof value==='string','PAYMENT_CHECKOUT_INVALID','支付页面地址无效',502);parsed=new URL(value);}catch{throw new AppError('PAYMENT_CHECKOUT_INVALID','支付页面地址无效',502);}
 assert(parsed.origin==='https://checkout.stripe.com'&&!parsed.username&&!parsed.password,'PAYMENT_CHECKOUT_INVALID','支付页面地址无效',502);return value as string;
}
async function assertCheckoutEligibility(env:Env,order:Order,runtime:PaymentRuntime){
 assert(await env.DB.prepare("SELECT 1 FROM users WHERE id=? AND status='active'").bind(order.user_id).first(),'PURCHASE_NOT_ALLOWED','当前账户不能继续付款',403);
 if(order.kind==='topup')assert(await canTopup(env.DB,order.user_id,new Date(now(runtime)).toISOString()),'TOPUP_MEMBERSHIP_REQUIRED','续充 AI 用量需要有效付费会员',403);
 if(order.kind==='subscription')assert(!await env.DB.prepare("SELECT 1 FROM membership_freezes WHERE user_id=? AND state<>'completed'").bind(order.user_id).first(),'MEMBERSHIP_FROZEN','会员暂停期间不能继续购买月租',409);
}
async function createOriginalCheckout(env:Env,order:Order,config:PaymentConfig,runtime:PaymentRuntime):Promise<string>{
 assert(Date.parse(order.expires_at)>now(runtime),'ORDER_EXPIRED','订单已到期，请先核对原订单',409);
 await assertCheckoutEligibility(env,order,runtime);
 const origin=new URL(env.APP_ORIGIN);
 assert(origin.protocol==='https:'||(env.APP_ENV!=='production'&&origin.protocol==='http:'),'PAYMENT_ORIGIN_INVALID','平台支付回跳域名尚未配置',503);
 const expiry=Math.floor(new Date(order.expires_at).getTime()/1000);
 // Keep the original body and expiry when recovering a lost response. Stripe
 // rejects a genuinely new session with <30m left; it can replay an existing
 // idempotent result. Never extend an order or switch merchants on retry.
 const name='Benos '+orderPlanSnapshot(order).name;
 const params=new URLSearchParams({mode:order.kind==='subscription'?'subscription':'payment',
  success_url:`${origin.origin}/app/billing?order=${encodeURIComponent(order.id)}`,cancel_url:`${origin.origin}/app/billing?order=${encodeURIComponent(order.id)}&cancelled=1`,
  client_reference_id:order.id,'line_items[0][price_data][currency]':'usd','line_items[0][price_data][unit_amount]':String(order.amount_cents),
  'line_items[0][price_data][product_data][name]':name,'line_items[0][quantity]':'1','payment_method_types[0]':'card',expires_at:String(expiry)});
 const metadata={benos_order_id:order.id,benos_user_id:order.user_id,benos_config_id:config.id};
 for(const [key,value] of Object.entries(metadata)){
  params.set(`metadata[${key}]`,value);
  params.set(`${order.kind==='subscription'?'subscription_data':'payment_intent_data'}[metadata][${key}]`,value);
 }
 if(order.kind==='subscription')params.set('line_items[0][price_data][recurring][interval]','month');
 const checkout=await stripeRequest(config,'/v1/checkout/sessions','POST',params,`benos:checkout:${order.id}`,runtime);
 const checkoutId=providerId(checkout.id,'cs');matchesMode(config,checkout);
 await env.DB.prepare("UPDATE orders SET checkout_id=?,checkout_url=?,state=CASE WHEN state='created' THEN 'pending' ELSE state END WHERE id=? AND (checkout_id IS NULL OR checkout_id=?)")
  .bind(checkoutId,typeof checkout.url==='string'?checkoutUrl(checkout.url):null,order.id,checkoutId).run();
 const stored=await getOrder(env.DB,order.id,order.user_id);
 assert(stored.checkout_id===checkoutId,'CHECKOUT_CONFLICT','订单支付链接待核对',409);
 return checkoutId;
}
export async function resumeCheckout(env:Env,userId:string,orderId:string,runtime:PaymentRuntime={}){
 const order=await getOrder(env.DB,orderId,userId);
 if(order.provider==='alipay')return (await import('./alipay')).resumeAlipayCheckout(env,userId,orderId,runtime);
 if(order.state==='paid'&&order.fulfilled_at)return {orderId:order.id,state:'paid',checkoutUrl:null,checkoutState:'paid' as const};
 assert(['created','pending','expired'].includes(order.state),'ORDER_NOT_PAYABLE','订单当前不能继续支付，请核对原订单',409);
 const config=await loadPaymentConfiguration(env,order.config_version_id);
 const sessionId=order.checkout_id??await createOriginalCheckout(env,order,config,runtime);
 const session=await stripeRequest(config,`/v1/checkout/sessions/${providerId(sessionId,'cs')}?expand%5B%5D=line_items`,'GET',undefined,undefined,runtime);
 checkOrderObject(order,config,session);
 assert(session.id===sessionId&&session.client_reference_id===order.id&&session.mode===(order.kind==='subscription'?'subscription':'payment'),'PAYMENT_IDENTITY_MISMATCH','支付链接与订单不一致',409);
 const lines=record(session.line_items),items=Array.isArray(lines.data)?lines.data.map(record):[];
 assert(lines.has_more===false&&items.length===1&&items[0].quantity===1&&items[0].amount_total===order.amount_cents,'PAYMENT_AMOUNT_MISMATCH','支付项目与订单不一致',409);
 assert(['open','complete','expired'].includes(String(session.status)),'PAYMENT_PROVIDER_UNCONFIRMED','支付会话状态尚待确认',503);
 if(session.status==='complete'){
  const paid=await reconcileOrder(env,userId,order.id,runtime);
  return {orderId:paid.id,state:paid.state,checkoutUrl:null,checkoutState:paid.state==='paid'?'paid' as const:'complete' as const};
 }
 if(session.status==='expired'){
  assert(session.payment_status==='unpaid','PAYMENT_PROVIDER_UNCONFIRMED','已过期会话的付款状态需要核对',503);
  await env.DB.prepare("UPDATE orders SET state='expired',checkout_url=NULL WHERE id=? AND state IN ('created','pending')").bind(order.id).run();
  const stored=await getOrder(env.DB,order.id,userId);
  return {orderId:stored.id,state:stored.state,checkoutUrl:null,checkoutState:'expired' as const};
 }
 assert(session.payment_status==='unpaid','PAYMENT_PROVIDER_UNCONFIRMED','付款状态需要核对，不能继续付款',503);
 assert(seconds(session.expires_at)===Math.floor(Date.parse(order.expires_at)/1000),'PAYMENT_EXPIRY_MISMATCH','付款有效期与原订单不一致',409);
 assert(Number(session.expires_at)*1000>now(runtime),'ORDER_EXPIRED','原支付会话到期状态需要核对，请稍后刷新',409);
 assert(order.state!=='expired','ORDER_NOT_PAYABLE','原订单已关闭，不能继续付款',409);
 await assertCheckoutEligibility(env,order,runtime);
 const url=checkoutUrl(session.url);
 // Concurrent fulfillment/review cannot be replaced with a payable state.
 const stored=await getOrder(env.DB,order.id,userId);
 if(stored.state==='paid')return {orderId:stored.id,state:stored.state,checkoutUrl:null,checkoutState:'paid' as const};
 assert(['created','pending'].includes(stored.state),'ORDER_NOT_PAYABLE','订单状态已变化，请刷新核对',409);
 return {orderId:stored.id,state:stored.state,checkoutUrl:url,checkoutState:'open' as const};
}

/** Verify the exact raw body before parsing. Timestamp tolerance also rejects replayed signatures. */
export async function verifyStripeSignature(raw:string,header:string|undefined,secret:string,nowMs=Date.now()):Promise<void> {
 assert(typeof header==='string'&&header.length<=4096,'WEBHOOK_SIGNATURE','支付回调签名无效',400);
 const parts=header.split(',').map(p=>p.trim().split('=')), timestamps=parts.filter(p=>p[0]==='t');
 assert(timestamps.length===1&&/^\d+$/.test(timestamps[0][1]??''),'WEBHOOK_SIGNATURE','支付回调签名无效',400);
 const timestamp=Number(timestamps[0][1]);
 assert(Number.isSafeInteger(timestamp)&&Math.abs(Math.floor(nowMs/1000)-timestamp)<=300,'WEBHOOK_EXPIRED','支付回调签名已过期',400);
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 const signature=await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(`${timestamp}.${raw}`));
 const expected=Array.from(new Uint8Array(signature),b=>b.toString(16).padStart(2,'0')).join('');
 assert(parts.some(([kind,value])=>kind==='v1'&&/^[a-f0-9]{64}$/.test(value??'')&&constantTimeEqual(value,expected)),'WEBHOOK_SIGNATURE','支付回调签名无效',400);
}

async function review(env:Env,eventId:string,orderId:string|null,reason:string,runtime:PaymentRuntime):Promise<void> {
 const time=new Date(now(runtime)).toISOString();
 await (await import('./payment-reviews')).recordPaymentReview(env,eventId,orderId,reason,runtime);
 await env.DB.batch([
  env.DB.prepare("INSERT INTO payment_review_cases(id,event_id,order_id,reason,created_at) VALUES(?,?,?,?,?) ON CONFLICT(event_id) DO NOTHING").bind(`review_${eventId}`,eventId,orderId,reason,time),
  env.DB.prepare("UPDATE payment_events SET state='review',error_code=?,processed_at=? WHERE event_id=? AND provider='stripe'").bind(reason,time,eventId),
  env.DB.prepare("UPDATE orders SET state='review' WHERE id=? AND state<>'paid'").bind(orderId),
 ]);
}
function checkOrderObject(order:Order,config:PaymentConfig,object:Json):void {
 matchesMode(config,object);
 const metadata=record(object.metadata);
 assert(order.config_version_id===config.id&&metadata.benos_order_id===order.id&&metadata.benos_user_id===order.user_id&&metadata.benos_config_id===config.id,'PAYMENT_IDENTITY_MISMATCH','订单支付归属不匹配',409);
 assert(object.currency==='usd'&&object.amount_total===order.amount_cents,'PAYMENT_AMOUNT_MISMATCH','到账金额与订单不一致',409);
}
class VerifiedPaymentReview extends AppError {
 constructor(public readonly orderId:string,code:string,message:string){super(code,message,409);}
}
export async function completeFulfillment(env:Env,order:Order,reference:string,startsAt:string,endsAt:string|null,runtime:PaymentRuntime,extra:{activation?:'create'|'resume'|null;paidAt?:string;autoRenew?:boolean}={}):Promise<void> {
 const activation=extra.activation??null;
 const time=new Date(now(runtime)).toISOString(), fulfillmentId=`ful_${await sha256(reference)}`, requestedStart=startsAt;
 const chained=order.kind==='hosting'||(order.kind==='subscription'&&order.provider==='alipay');
 const snapshot=await sha256(JSON.stringify([order.id,reference,chained?null:startsAt,chained?null:endsAt,order.amount_cents,order.credit_micros]));
 if(order.kind==='hosting') {
  // Concurrent annual purchases must reserve successive coverage periods in SQL.
  // Include durable pending fulfillments so a retry cannot lose an already-paid year.
  // A completed year counts through its entitlement (the source of truth: it may have been
  // re-anchored, pulled forward or revoked since); a refunded order never counts.
  await env.DB.prepare(`WITH prior AS (SELECT MAX(ends_at) AS ends FROM (
    SELECT ends_at FROM hosting_entitlements WHERE site_id=?1 AND source='annual' AND state='active' AND (order_id IS NULL OR order_id<>?2)
    UNION ALL SELECT f.ends_at FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id
      WHERE o.hosting_site_id=?1 AND f.order_id<>?2 AND f.state='pending' AND o.state<>'refunded'
   )), coverage AS (SELECT CASE WHEN ends>?3 THEN ends ELSE ?3 END AS starts FROM prior)
   INSERT INTO payment_fulfillments(id,order_id,provider_reference,snapshot_hash,starts_at,ends_at,created_at)
   SELECT ?4,?2,?5,?6,starts,strftime('%Y-%m-%dT%H:%M:%fZ',starts,'+1 year',
    CASE WHEN substr(starts,6,5)='02-29' THEN '-1 day' ELSE '+0 day' END),?7 FROM coverage WHERE 1
   ON CONFLICT(order_id) DO NOTHING`).bind(order.hosting_site_id,order.id,startsAt,fulfillmentId,reference,snapshot,time).run();
 }else {
  // The durable intent and the freeze exclusion commit together. Freezing uses
  // the reciprocal guard, so it cannot pass between this intent and grant+sub.
  const guard=id('fulfillment_guard');
  try{await env.DB.batch([
   env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN
    NOT EXISTS(SELECT 1 FROM membership_freezes WHERE user_id=? AND state<>'completed')
    OR EXISTS(SELECT 1 FROM payment_fulfillments WHERE order_id=? AND state='completed') THEN 1 ELSE 0 END`).bind(guard,order.user_id,order.id),
   order.kind==='subscription'&&order.provider==='alipay'
    ?env.DB.prepare(`WITH prior AS (SELECT MAX(ends_at) AS ends FROM (
      SELECT ends_at FROM subscriptions WHERE user_id=?1 AND state IN ('active','cancelled') AND membership_frozen_by IS NULL AND (order_id IS NULL OR order_id<>?2)
      UNION ALL SELECT f.ends_at FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id WHERE o.user_id=?1 AND o.kind='subscription' AND f.order_id<>?2 AND f.state='pending' AND o.state<>'refunded'
     )),coverage AS (SELECT CASE WHEN ends>?3 THEN ends ELSE ?3 END AS starts FROM prior)
     INSERT INTO payment_fulfillments(id,order_id,provider_reference,snapshot_hash,starts_at,ends_at,created_at)
     SELECT ?4,?2,?5,?6,starts,strftime('%Y-%m-%dT%H:%M:%fZ',starts,'+1 month',
      '-'||MAX(0,CAST(strftime('%d',starts) AS INTEGER)-CAST(strftime('%d',date(starts,'start of month','+2 month','-1 day')) AS INTEGER))||' days'),?7 FROM coverage WHERE 1 ON CONFLICT(order_id) DO NOTHING`)
     .bind(order.user_id,order.id,startsAt,fulfillmentId,reference,snapshot,time)
    :env.DB.prepare(`INSERT INTO payment_fulfillments(id,order_id,provider_reference,snapshot_hash,starts_at,ends_at,created_at)
     VALUES(?,?,?,?,?,?,?) ON CONFLICT(order_id) DO NOTHING`).bind(fulfillmentId,order.id,reference,snapshot,startsAt,endsAt,time),
   env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard),
  ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new VerifiedPaymentReview(order.id,'FROZEN_MEMBERSHIP_PAYMENT','会员正在暂停或恢复，到账权益需要人工核对，尚未发放新额度');throw error;}
 }
 const fulfillment=await env.DB.prepare('SELECT * FROM payment_fulfillments WHERE order_id=?').bind(order.id).first<Fulfillment>();
 assert(fulfillment&&fulfillment.snapshot_hash===snapshot,'FULFILLMENT_CONFLICT','支付权益待核对',409);
 startsAt=fulfillment.starts_at;endsAt=fulfillment.ends_at;
 if(fulfillment.state==='completed')return;
 assert(fulfillment.state==='pending','FULFILLMENT_REVIEW','支付权益正在核对',409);
 // A durable intent exists before granting. Retry uses the same business reference
 // even when a previous request committed but its acknowledgement was lost.
 if(order.credit_micros>0)await grantCredit(env.DB,{id:`credit_${fulfillment.id}`,userId:order.user_id,
  source:order.kind==='subscription'?'subscription':'topup',amountMicros:order.credit_micros,
  startsAtMs:new Date(startsAt).getTime(),...(order.kind==='subscription'?{expiresAtMs:new Date(endsAt!).getTime()}:{}),
  referenceId:reference,nowMs:now(runtime)});
 const statements:D1PreparedStatement[]=[];
 if(order.kind==='subscription') {
  const plan=orderPlanSnapshot(order);
  statements.push(env.DB.prepare(`INSERT INTO subscriptions(id,user_id,tier,source,order_id,starts_at,ends_at,auto_renew,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at)
   VALUES(?,?,?,'paid',?,?,?,?,?,?,1,?,?) ON CONFLICT(order_id) DO NOTHING`).bind(`sub_${fulfillment.id}`,order.user_id,order.plan_tier,order.id,startsAt,endsAt,extra.autoRenew===false?0:1,plan.includedSites,order.credit_micros,reference,time));
 }else if(order.kind==='hosting') {
  statements.push(env.DB.prepare(`INSERT INTO hosting_entitlements(id,user_id,site_id,source,order_id,starts_at,ends_at,created_at)
   VALUES(?,?,?,'annual',?,?,?,?) ON CONFLICT(site_id,order_id) DO NOTHING`).bind(`host_${fulfillment.id}`,order.user_id,order.hosting_site_id,order.id,startsAt,endsAt,time));
  // A year bought for a site that is not yet open, or is suspended, counts from
  // the actual opening/resumption. Chained years (start moved by a concurrent
  // purchase) are continuations and are never re-anchored.
  if(activation&&startsAt===requestedStart)statements.push(env.DB.prepare(`INSERT INTO hosting_annual_activations(order_id,site_id,user_id,reason,provisional_starts_at,provisional_ends_at,created_at,updated_at)
   VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(order_id) DO NOTHING`).bind(order.id,order.hosting_site_id,order.user_id,activation,startsAt,endsAt,time,time));
 }
 // N1 / M3: a new membership term (first payment or cycle renewal, which Stripe
 // usually posts after the period started) or a new hosting year can leave slot
 // capacity idle where an annual year was placed. The request to move such years
 // commits with the grant, so a failed follow-up is retried by maintenance.
 const billing=await import('./hosting-billing');
 if(order.kind==='subscription'||order.kind==='hosting')statements.push(billing.deferralRequestStatement(env.DB,order.user_id,order.kind==='subscription'?startsAt:time,order.kind==='subscription'?'membership_term':'hosting_year',
  "NOT EXISTS(SELECT 1 FROM payment_fulfillments WHERE id=? AND state='completed')",[fulfillment.id]));
 statements.push(
  env.DB.prepare("UPDATE orders SET state='paid',payment_id=?,paid_at=COALESCE(paid_at,?),fulfilled_at=? WHERE id=? AND state NOT IN ('refunded')").bind(reference,extra.paidAt??startsAt,time,order.id),
  env.DB.prepare("UPDATE payment_fulfillments SET state='completed',completed_at=? WHERE id=? AND state='pending'").bind(time,fulfillment.id),
 );
 await env.DB.batch(statements);
 if(order.kind==='subscription')try{await billing.runDeferralRequest(env.DB,order.user_id);}catch{/* maintenance retries the queued request */}
 // The paid year is durable at this point. Follow-up work (start a pay-first
 // site, refresh the lease) must not fail the payment confirmation; scheduled
 // maintenance repeats it if it did not run.
 if(order.kind==='hosting'&&order.hosting_site_id)try{await (await import('./hosting')).afterAnnualHostingFulfilled(env,order.user_id,order.hosting_site_id,runtime.waitUntil);}catch{/* maintenance retries */}
}

/** Closes an unpaid order so it can no longer be paid: an open checkout page is
 * expired at the provider first. Returns 'paid' when the payment had already
 * completed (it is then fulfilled as usual), otherwise 'closed'. */
export async function closeUnpaidOrder(env:Env,userId:string,orderId:string,runtime:PaymentRuntime={}):Promise<'paid'|'closed'>{
 let order=await getOrder(env.DB,orderId,userId);
 if(order.provider==='alipay')return (await import('./alipay')).closeAlipayOrder(env,userId,orderId,runtime);
 if(['paid','review','refunded'].includes(order.state))return 'paid';
 if(!['created','pending'].includes(order.state))return 'closed';
 if(!order.checkout_id){
  const closed=await env.DB.prepare("UPDATE orders SET state='expired',checkout_url=NULL WHERE id=? AND state IN ('created','pending') AND checkout_id IS NULL RETURNING id").bind(order.id).first();
  if(closed)return 'closed';
  order=await getOrder(env.DB,orderId,userId);if(!order.checkout_id)return closeUnpaidOrder(env,userId,orderId,runtime);
 }
 const config=await loadPaymentConfiguration(env,order.config_version_id),path=`/v1/checkout/sessions/${providerId(order.checkout_id,'cs')}`;
 let session=await stripeRequest(config,path,'GET',undefined,undefined,runtime);
 assert(session.id===order.checkout_id&&session.client_reference_id===order.id,'PAYMENT_IDENTITY_MISMATCH','支付链接与订单不一致',409);
 if(session.status==='open')session=await stripeRequest(config,path+'/expire','POST',new URLSearchParams(),`benos:expire:${order.id}`,runtime);
 if(session.status==='complete'||session.payment_status!=='unpaid'){try{await reconcileOrder(env,userId,order.id,runtime);}catch{/* the webhook or reconcile completes it */}return 'paid';}
 assert(session.status==='expired','PAYMENT_PROVIDER_UNCONFIRMED','支付会话状态尚待确认',503);
 await env.DB.prepare("UPDATE orders SET state='expired',checkout_url=NULL WHERE id=? AND state IN ('created','pending')").bind(order.id).run();
 return ['paid','review','refunded'].includes((await getOrder(env.DB,orderId,userId)).state)?'paid':'closed';
}

function addYear(iso:string):string {const date=new Date(iso), month=date.getUTCMonth();date.setUTCFullYear(date.getUTCFullYear()+1);if(date.getUTCMonth()!==month)date.setUTCDate(0);return date.toISOString();}
async function fulfillCheckout(env:Env,config:PaymentConfig,sessionId:string,runtime:PaymentRuntime):Promise<string|null> {
 const session=await stripeRequest(config,`/v1/checkout/sessions/${providerId(sessionId,'cs')}?expand%5B%5D=line_items`,'GET',undefined,undefined,runtime);
 const orderId=record(session.metadata).benos_order_id;
 assert(typeof orderId==='string','PAYMENT_IDENTITY_MISMATCH','回调缺少订单标识',409);
 const order=await getOrder(env.DB,orderId);checkOrderObject(order,config,session);
 assert(session.id===sessionId&&session.client_reference_id===order.id&&(order.checkout_id===null||order.checkout_id===sessionId),'PAYMENT_IDENTITY_MISMATCH','支付链接与订单不一致',409);
 const lines=record(session.line_items), lineItems=Array.isArray(lines.data)?lines.data.map(record):[];
 assert(lines.has_more===false&&lineItems.length===1&&lineItems[0].quantity===1&&lineItems[0].amount_total===order.amount_cents,'PAYMENT_AMOUNT_MISMATCH','支付项目与订单不一致',409);
 if(session.payment_status!=='paid')return order.id;
 if(order.state==='paid'&&order.fulfilled_at)return order.id;
 if(order.state==='refunded'||order.state==='review')throw new AppError('PAYMENT_REVIEW','订单需要人工核对',409);
 await env.DB.prepare('UPDATE orders SET checkout_id=COALESCE(checkout_id,?) WHERE id=?').bind(sessionId,order.id).run();
 if(order.kind==='subscription') {
  const subId=providerId(session.subscription,'sub');
  const subscription=await stripeRequest(config,`/v1/subscriptions/${subId}`,'GET',undefined,undefined,runtime);
  await registerAgreement(env,config,order,subscription,runtime);
  const invoiceId=providerId(subscription.latest_invoice,'in');
  return await fulfillInvoice(env,config,invoiceId,runtime);
 }
 assert(session.mode==='payment','PAYMENT_MODE_MISMATCH','支付模式不匹配',409);
 const paymentId=providerId(session.payment_intent,'pi');
 const payment=await stripeRequest(config,`/v1/payment_intents/${paymentId}?expand%5B%5D=latest_charge.balance_transaction`,'GET',undefined,undefined,runtime);
 matchesMode(config,payment);
 assert(payment.status==='succeeded'&&payment.amount_received===order.amount_cents&&payment.currency==='usd','PAYMENT_NOT_SETTLED','付款尚未确认',409);
 const charge=record(payment.latest_charge),transaction=record(charge.balance_transaction);
 assert(charge.paid===true&&charge.captured===true&&charge.payment_intent===paymentId
  &&transaction.type==='charge'&&transaction.amount===order.amount_cents,'PAYMENT_NOT_SETTLED','付款入账时间尚待确认',409);
 (await import('./payment-reviews')).assertUnrefundedCharge(charge);
 // PaymentIntent.created is the attempt creation time, not proof that the user
 // paid before membership expiry. Use the captured charge's balance transaction.
 const paidAt=isoSeconds(transaction.created);
 if(order.kind==='topup') {
  assert(order.eligible_until!==null&&paidAt<order.eligible_until,'TOPUP_MEMBERSHIP_EXPIRED','付款时充值资格已到期，需核对或退款',409);
  assert(await canTopup(env.DB,order.user_id,paidAt),'TOPUP_MEMBERSHIP_EXPIRED','付款时充值资格无效，需核对或退款',409);
 }
 let starts=paidAt, ends:string|null=null, activation:'create'|'resume'|null=null;
 if(order.kind==='hosting') {
  // Requirement 托管续费与到期处理: the year continues after the site's current
  // coverage (annual, gift or an already-granted membership slot) so no covered
  // period is charged twice; an unopened or suspended site counts from opening
  // or resumption (provisional until then, see hosting_annual_activations).
  const existing=await env.DB.prepare('SELECT starts_at,ends_at FROM payment_fulfillments WHERE order_id=?').bind(order.id).first<Fulfillment>();
  // A pay-first site released unpaid (checkout expired, or cancelled) no longer exists: the payment needs review or a refund.
  if(!existing&&!await env.DB.prepare('SELECT 1 FROM sites WHERE id=? AND user_id=?').bind(order.hosting_site_id,order.user_id).first())
   throw new VerifiedPaymentReview(order.id,'HOSTING_SITE_RELEASED','该网站的待付款开通已取消，本次付款需要人工核对或退款');
  const billing=await import('./hosting-billing');
  // Years scheduled after a coverage gap first move to the actual coverage end, so the new year follows real coverage.
  // A concurrent move of the account's years (AnnualMoveConflict) is retried once; the plan below treats such years as pulled forward anyway.
  // Any other failure never blocks a confirmed payment (R4-M2): maintenance repeats the pull-forward.
  if(!existing)for(let attempt=0;attempt<2;attempt++)try{await billing.rescheduleUncoveredAnnualYears(env.DB,order.user_id,order.hosting_site_id!,Date.parse(paidAt));break;}catch(error){if(!(error instanceof billing.AnnualMoveConflict)){console.warn('hosting pull-forward before placement failed; maintenance will retry',String(error));break;}}
  const plan=await billing.annualRenewalPlan(env.DB,order.user_id,order.hosting_site_id!,Date.parse(paidAt),order.id);
  if(plan){starts=plan.startsAt;activation=plan.activation;}
  if(existing){if(existing.starts_at!==starts)activation=null;starts=existing.starts_at;ends=existing.ends_at;}else ends=addYear(starts);
 }
 await completeFulfillment(env,order,`stripe:${paymentId}`,starts,ends,runtime,{activation,paidAt});return order.id;
}

async function registerAgreement(env:Env,config:PaymentConfig,order:Order,subscription:Json,runtime:PaymentRuntime):Promise<Agreement> {
 matchesMode(config,subscription);const subscriptionId=providerId(subscription.id,'sub'),metadata=record(subscription.metadata);
 assert(order.kind==='subscription'&&metadata.benos_order_id===order.id&&metadata.benos_user_id===order.user_id&&metadata.benos_config_id===config.id&&order.config_version_id===config.id,'PAYMENT_IDENTITY_MISMATCH','订阅归属不匹配',409);
 const conflict=await env.DB.prepare("SELECT id FROM payment_agreements WHERE user_id=? AND provider_subscription_id<>? AND state<>'cancelled'").bind(order.user_id,subscriptionId).first();
 assert(!conflict,'SUBSCRIPTION_CONFLICT','检测到重复订阅，需核对后处理',409);
 const time=new Date(now(runtime)).toISOString(), state=subscription.status==='canceled'?'cancelled':subscription.cancel_at_period_end===true?'cancel_scheduled':subscription.status==='past_due'?'past_due':'active';
 try {
  await env.DB.prepare(`INSERT INTO payment_agreements(id,user_id,origin_order_id,config_version_id,provider_subscription_id,tier,state,created_at,updated_at)
   VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(provider_subscription_id) DO NOTHING`).bind(`agr_${subscriptionId}`,order.user_id,order.id,config.id,subscriptionId,order.plan_tier,state,time,time).run();
 }catch(error){
  if(String(error).includes('payment_agreements.user_id'))throw new AppError('SUBSCRIPTION_CONFLICT','检测到重复订阅，需核对后处理',409);
  throw error;
 }
 const result=await env.DB.prepare('SELECT * FROM payment_agreements WHERE provider_subscription_id=?').bind(subscriptionId).first<Agreement>();
 assert(result&&result.origin_order_id===order.id,'SUBSCRIPTION_CONFLICT','订阅状态待核对',409);
 await env.DB.prepare('UPDATE orders SET payment_agreement_id=? WHERE id=? AND (payment_agreement_id IS NULL OR payment_agreement_id=?)').bind(result.id,order.id,result.id).run();return result;
}
async function fulfillInvoice(env:Env,config:PaymentConfig,invoiceId:string,runtime:PaymentRuntime):Promise<string|null> {
 const invoice=await stripeRequest(config,`/v1/invoices/${providerId(invoiceId,'in')}`,'GET',undefined,undefined,runtime);matchesMode(config,invoice);
 const details=record(record(invoice.parent).subscription_details), metadata=record(details.metadata);
 const originId=metadata.benos_order_id;
 assert(typeof originId==='string','PAYMENT_IDENTITY_MISMATCH','账单缺少平台订单标识',409);
 const originOrder=await getOrder(env.DB,originId), subscriptionId=providerId(details.subscription,'sub');
 const subscription=await stripeRequest(config,`/v1/subscriptions/${subscriptionId}`,'GET',undefined,undefined,runtime);
 const agreement=await registerAgreement(env,config,originOrder,subscription,runtime);
 if(invoice.status!=='paid')return originOrder.id;
 const fulfilled=await env.DB.prepare("SELECT id FROM orders WHERE payment_id=? AND state='paid' AND fulfilled_at IS NOT NULL").bind(`stripe:${invoiceId}`).first<{id:string}>();
 if(fulfilled)return fulfilled.id;
 // Moving the renewal date via a trial can generate a zero-value maintenance
 // invoice. It grants no new paid membership or AI credit.
 if(invoice.amount_paid===0&&invoice.total===0)return originOrder.id;
 const frozen=await env.DB.prepare("SELECT id FROM membership_freezes WHERE user_id=? AND state IN ('frozen','pending_unfreeze')").bind(originOrder.user_id).first();
 assert(!frozen,'FROZEN_MEMBERSHIP_PAYMENT','冻结会员出现新到账，需要核对后处理',409);
 assert(['subscription_create','subscription_cycle'].includes(String(invoice.billing_reason)),'INVOICE_REVIEW_REQUIRED','变更或折算账单需要核对',409);
 assert(invoice.currency==='usd'&&invoice.amount_paid===originOrder.amount_cents&&invoice.total===originOrder.amount_cents,'PAYMENT_AMOUNT_MISMATCH','订阅到账金额不匹配',409);
 await (await import('./payment-reviews')).assertInvoiceUnrefunded(config,invoiceId,originOrder.amount_cents,runtime);
 const lines=record(invoice.lines),lineItems=Array.isArray(lines.data)?lines.data.map(record):[];
 assert(lines.has_more===false&&lineItems.length===1&&lineItems[0].amount===originOrder.amount_cents&&lineItems[0].quantity===1,'PAYMENT_AMOUNT_MISMATCH','订阅账单项目不匹配',409);
 const line=lineItems[0],parent=record(record(line.parent).subscription_item_details);
 assert(parent.subscription===subscriptionId&&parent.proration===false,'INVOICE_REVIEW_REQUIRED','非完整月度账单需要核对',409);
 const period=record(line.period), starts=isoSeconds(period.start), ends=isoSeconds(period.end);
 assert(ends>starts&&seconds(period.end)-seconds(period.start)>=27*86400&&seconds(period.end)-seconds(period.start)<=32*86400,'INVOICE_PERIOD_INVALID','订阅周期无效',409);
 let order=originOrder;
 if(invoice.billing_reason==='subscription_cycle') {
  const renewalId=`renew_${invoiceId}`,time=new Date(now(runtime)).toISOString();
  await env.DB.prepare(`INSERT INTO orders(id,user_id,kind,plan_tier,amount_cents,credit_micros,currency,state,provider,idempotency_key,payload_hash,created_at,expires_at,config_version_id,catalog_version_id,plan_snapshot_json)
   VALUES(?,?,'subscription',?,?,?,'USD','pending','stripe',?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING`)
   .bind(renewalId,originOrder.user_id,originOrder.plan_tier,originOrder.amount_cents,originOrder.credit_micros,`stripe:${invoiceId}`,await sha256(JSON.stringify([subscriptionId,invoiceId,starts,ends])),time,ends,config.id,originOrder.catalog_version_id,JSON.stringify(orderPlanSnapshot(originOrder))).run();
  order=await getOrder(env.DB,renewalId);
 }
 assert(order.state!=='refunded'&&order.state!=='review','PAYMENT_REVIEW','订单需要人工核对',409);
 await env.DB.prepare('UPDATE orders SET payment_agreement_id=? WHERE id=? AND (payment_agreement_id IS NULL OR payment_agreement_id=?)').bind(agreement.id,order.id,agreement.id).run();
 await completeFulfillment(env,order,`stripe:${invoiceId}`,starts,ends,runtime);
 if(agreement.cancel_requested||subscription.cancel_at_period_end===true||subscription.status==='canceled') {
  await env.DB.prepare("UPDATE subscriptions SET auto_renew=0,state='cancelled' WHERE order_id=? AND state<>'revoked'").bind(order.id).run();
 }
 return order.id;
}

export async function cancelRenewal(env:Env,userId:string,agreementId:string,runtime:PaymentRuntime={}) {
 const agreement=await env.DB.prepare('SELECT * FROM payment_agreements WHERE id=? AND user_id=?').bind(agreementId,userId).first<Agreement>();
 assert(agreement,'SUBSCRIPTION_NOT_FOUND','订阅不存在',404);
 if(agreement.state==='cancelled')return {id:agreement.id,state:'cancelled',cancelRequested:true};
 const config=await loadPaymentConfiguration(env,agreement.config_version_id),time=new Date(now(runtime)).toISOString();
 // Persist intent before the external mutation. Lost responses can safely retry the same key.
 await env.DB.prepare('UPDATE payment_agreements SET cancel_requested=1,updated_at=? WHERE id=?').bind(time,agreement.id).run();
 const subscription=await stripeRequest(config,`/v1/subscriptions/${providerId(agreement.provider_subscription_id,'sub')}`,'POST',new URLSearchParams({cancel_at_period_end:'true'}),`benos:cancel:${agreement.id}`,runtime);
 assert(subscription.cancel_at_period_end===true||subscription.status==='canceled','CANCELLATION_UNCONFIRMED','取消续费状态待确认',503);
 const state=subscription.status==='canceled'?'cancelled':'cancel_scheduled';
 await env.DB.batch([
  env.DB.prepare('UPDATE payment_agreements SET state=?,updated_at=? WHERE id=?').bind(state,time,agreement.id),
  env.DB.prepare("UPDATE subscriptions SET auto_renew=0,state='cancelled' WHERE user_id=? AND source='paid' AND state='active'").bind(userId),
 ]);
 return {id:agreement.id,state,cancelRequested:true};
}

async function syncAgreement(env:Env,config:PaymentConfig,subscriptionId:string,eventCreated:number,runtime:PaymentRuntime):Promise<void> {
 const subscription=await stripeRequest(config,`/v1/subscriptions/${providerId(subscriptionId,'sub')}`,'GET',undefined,undefined,runtime);
 matchesMode(config,subscription);
 const orderId=record(subscription.metadata).benos_order_id;
 if(typeof orderId!=='string')return;
 const order=await getOrder(env.DB,orderId),agreement=await registerAgreement(env,config,order,subscription,runtime);
 const cancel=subscription.cancel_at_period_end===true||subscription.status==='canceled';
 const state=subscription.status==='canceled'?'cancelled':cancel?'cancel_scheduled':['past_due','unpaid','incomplete','incomplete_expired'].includes(String(subscription.status))?'past_due':'active';
 await env.DB.prepare('UPDATE payment_agreements SET state=?,provider_event_at=?,updated_at=? WHERE id=? AND provider_event_at<=?')
  .bind(state,eventCreated,new Date(now(runtime)).toISOString(),agreement.id,eventCreated).run();
 if(cancel)await env.DB.prepare("UPDATE subscriptions SET auto_renew=0,state='cancelled' WHERE user_id=? AND source='paid' AND state='active'").bind(order.user_id).run();
}
export async function reconcileOrder(env:Env,userId:string,orderId:string,runtime:PaymentRuntime={}) {
 const order=await getOrder(env.DB,orderId,userId);
 if(order.provider==='alipay')return (await import('./alipay')).reconcileAlipayOrder(env,userId,orderId,runtime);
 if(order.state==='paid'&&order.fulfilled_at)return order;
 const config=await loadPaymentConfiguration(env,order.config_version_id);
 if(order.checkout_id)await fulfillCheckout(env,config,order.checkout_id,runtime);
 else if(order.payment_id?.startsWith('stripe:in_'))await fulfillInvoice(env,config,order.payment_id.slice(7),runtime);
 else throw new AppError('CHECKOUT_UNCONFIRMED','支付链接尚待确认，请使用原请求标识重新获取',409);
 return getOrder(env.DB,orderId,userId);
}

export async function handleStripeWebhook(env:Env,configId:string,raw:string,signature:string|undefined,runtime:PaymentRuntime={}) {
 assert(new TextEncoder().encode(raw).byteLength<=1024*1024,'REQUEST_TOO_LARGE','回调内容过大',413);
 const config=await loadPaymentConfiguration(env,configId);await verifyStripeSignature(raw,signature,config.webhookSecret,now(runtime));
 let event:Json;try{event=record(JSON.parse(raw));}catch{throw new AppError('WEBHOOK_INVALID','回调内容无效');}
 const eventId=providerId(event.id,'evt');matchesMode(config,event);
 assert(typeof event.type==='string'&&record(event.data).object,'WEBHOOK_INVALID','回调事件无效');
 const hash=await sha256(raw),time=new Date(now(runtime)).toISOString(),object=record(record(event.data).object);
 await env.DB.prepare(`INSERT INTO payment_events(id,provider,event_id,event_type,payload_hash,state,received_at,config_version_id,payload_json)
  VALUES(?,'stripe',?,?,?,'received',?,?,?) ON CONFLICT(provider,event_id) DO UPDATE SET payload_hash=CASE WHEN payment_events.payload_hash=excluded.payload_hash THEN payment_events.payload_hash ELSE NULL END`)
  .bind(`event_${eventId}`,eventId,event.type,hash,time,configId,raw).run();
 const stored=await env.DB.prepare("SELECT state,config_version_id FROM payment_events WHERE provider='stripe' AND event_id=?").bind(eventId).first<{state:string;config_version_id:string}>();
 assert(stored?.config_version_id===configId,'WEBHOOK_CONFIG_MISMATCH','回调配置不匹配',409);
 if(stored.state==='processed'||stored.state==='review')return {received:true,state:stored.state};
 let orderId:string|null=null;
 try {
  if(event.type==='checkout.session.completed'||event.type==='checkout.session.async_payment_succeeded')orderId=await fulfillCheckout(env,config,providerId(object.id,'cs'),runtime);
  else if(event.type==='invoice.paid')orderId=await fulfillInvoice(env,config,providerId(object.id,'in'),runtime);
  else if(['customer.subscription.updated','customer.subscription.deleted','invoice.payment_failed'].includes(event.type)) {
   const subscriptionId=event.type==='invoice.payment_failed'?objectId(record(record(object.parent).subscription_details).subscription):objectId(object.id);
   if(subscriptionId)await syncAgreement(env,config,subscriptionId,seconds(event.created),runtime);
  }else if(event.type==='checkout.session.expired'||event.type==='checkout.session.async_payment_failed') {
   const sessionId=providerId(object.id,'cs');
   await env.DB.prepare("UPDATE orders SET state=? WHERE checkout_id=? AND state IN ('created','pending')").bind(event.type==='checkout.session.expired'?'expired':'failed',sessionId).run();
  }else {
   const reviews=await import('./payment-reviews');
   if(reviews.isFinancialEvent(event.type)){
    const cases=await reviews.recordFinancialEvent(env,config,eventId,event.type,object,runtime);
    const orderIds=[...new Set(cases.map(item=>item.orderId).filter(Boolean))];orderId=orderIds.length===1?orderIds[0]!:null;
   }
  }
  await env.DB.prepare("UPDATE payment_events SET state='processed',order_id=?,processed_at=? WHERE provider='stripe' AND event_id=? AND state='received'").bind(orderId,time,eventId).run();
  return {received:true,state:'processed'};
 }catch(error) {
  if(error instanceof AppError&&error.status===409){
   const metadata=record(object.metadata),hinted=metadata.benos_order_id;
   const exists=typeof hinted==='string'&&typeof metadata.benos_user_id==='string'&&metadata.benos_config_id===configId?await env.DB.prepare('SELECT id FROM orders WHERE id=? AND user_id=? AND config_version_id=?').bind(hinted,metadata.benos_user_id,configId).first<{id:string}>():null;
   await review(env,eventId,error instanceof VerifiedPaymentReview?error.orderId:orderId??exists?.id??null,error.code,runtime);return {received:true,state:'review'};
  }
  // Return non-2xx on transient failures. Stripe retries; durable fulfillment and
  // ledger references make the replay safe after any intermediate commit.
  throw error;
 }
}
export const paymentWebhookRoutes=new Hono<App>();
paymentWebhookRoutes.post('/:configId',async c=>ok(c,await handleStripeWebhook(c.env,c.req.param('configId'),await c.req.text(),c.req.header('stripe-signature'),backgroundRuntime(c))));
