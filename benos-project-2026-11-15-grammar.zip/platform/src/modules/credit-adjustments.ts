import { z } from 'zod';
import type { Env,User } from '../env';
import { assert,AppError } from '../lib/errors';
import { id,sha256 } from '../lib/crypto';

export const creditAdjustmentSchema=z.object({direction:z.enum(['reverse','restore']),grantId:z.string().min(1).max(200),amountMicros:z.number().int().positive().max(100_000_000_000),parentId:z.string().min(1).max(200).optional(),reason:z.string().trim().min(3).max(500),evidence:z.string().trim().min(10).max(2000),requestKey:z.string().min(8).max(128),expectedRevision:z.number().int().positive(),confirmImpact:z.literal(true)}).strict().refine(v=>v.direction==='restore'?!!v.parentId:!v.parentId,{message:'恢复必须关联原冲销流水；新冲销不能指定恢复来源'});
type Input=z.infer<typeof creditAdjustmentSchema>;
export async function caseCredits(env:Env,caseId:string){
 const row=await env.DB.prepare('SELECT id,order_id,user_id FROM financial_cases WHERE id=?').bind(caseId).first<{id:string;order_id:string|null;user_id:string|null}>();assert(row,'NOT_FOUND','审核记录不存在',404);
 const [grants,adjustments]=await Promise.all([
  env.DB.prepare(`SELECT g.id,g.source,g.amount_micros AS amountMicros,g.consumed_micros AS consumedMicros,g.reserved_micros AS heldMicros,g.reversed_micros AS reversedMicros,
   g.amount_micros-g.consumed_micros-g.reserved_micros-g.reversed_micros AS adjustableMicros,g.starts_at_ms AS startsAtMs,g.expires_at_ms AS expiresAtMs,g.membership_frozen_by IS NOT NULL AS membershipFrozen
   FROM credit_grants g JOIN payment_fulfillments p ON p.provider_reference=g.reference_id JOIN orders o ON o.id=p.order_id
   WHERE p.order_id=? AND g.user_id=? AND o.user_id=g.user_id AND g.source=CASE o.kind WHEN 'subscription' THEN 'subscription' ELSE 'topup' END`).bind(row.order_id,row.user_id).all(),
  env.DB.prepare(`SELECT a.id,a.grant_id AS grantId,a.direction,a.parent_id AS parentId,a.amount_micros AS amountMicros,a.reason,a.evidence,a.actor_id AS actorId,a.created_at AS createdAt,
   CASE WHEN a.direction='reverse' THEN a.amount_micros-COALESCE((SELECT SUM(r.amount_micros) FROM financial_credit_adjustments r WHERE r.parent_id=a.id),0) ELSE 0 END AS restorableMicros
   FROM financial_credit_adjustments a WHERE a.case_id=? ORDER BY a.created_at DESC,a.id`).bind(caseId).all(),
 ]);return {grants:grants.results,adjustments:adjustments.results};
}
/** An explicit correction of the original source. It never fabricates an AI
 * consumption or changes upstream provider funds; held amounts remain held. */
export async function adjustCaseCredit(env:Env,caseId:string,actor:User,input:Input,nowMs=Date.now()){
 assert(actor.role==='owner','FORBIDDEN','只有平台所有者可以调整额度',403);
 input=creditAdjustmentSchema.parse(input);
 const row=await env.DB.prepare('SELECT order_id FROM financial_cases WHERE id=?').bind(caseId).first<{order_id:string|null}>();assert(row?.order_id,'CASE_UNMAPPED','尚未确认原订单归属，不能调整额度',409);
 const adjustmentId=id('credit_adjustment'),nonce=id('attempt'),guard=id('credit_guard'),time=new Date(nowMs).toISOString(),hash=await sha256(JSON.stringify({caseId,...input}));
 const stmt=(sql:string,...values:(string|number|null)[])=>env.DB.prepare(sql).bind(...values),fresh='EXISTS(SELECT 1 FROM financial_credit_adjustments WHERE id=?1 AND attempt_nonce=?2)';
 try{await env.DB.batch([
  stmt(`INSERT INTO financial_credit_adjustments(id,case_id,order_id,grant_id,actor_id,direction,parent_id,amount_micros,request_key,payload_hash,attempt_nonce,reason,evidence,created_at)
   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(actor_id,request_key) DO UPDATE SET payload_hash=CASE WHEN financial_credit_adjustments.payload_hash=excluded.payload_hash THEN financial_credit_adjustments.payload_hash ELSE NULL END`,adjustmentId,caseId,row.order_id,input.grantId,actor.id,input.direction,input.parentId??null,input.amountMicros,input.requestKey,hash,nonce,input.reason,input.evidence,time),
  stmt(`INSERT INTO mutation_guards(id,permitted) SELECT ?3,CASE WHEN NOT ${fresh} OR EXISTS(
   SELECT 1 FROM financial_cases f JOIN orders o ON o.id=f.order_id JOIN payment_fulfillments p ON p.order_id=o.id JOIN credit_grants g ON g.reference_id=p.provider_reference AND g.user_id=o.user_id
   WHERE f.id=?4 AND f.revision=?5 AND f.user_id=o.user_id AND g.id=?6 AND g.source=CASE o.kind WHEN 'subscription' THEN 'subscription' ELSE 'topup' END
   AND EXISTS(SELECT 1 FROM users WHERE id=?7 AND role='owner') AND (
    (?8='reverse' AND ((f.kind='refund' AND f.provider_state='succeeded') OR (f.kind='dispute' AND f.provider_state='lost')) AND g.amount_micros-g.consumed_micros-g.reserved_micros-g.reversed_micros>=?9)
    OR (?8='restore' AND g.reversed_micros>=?9 AND EXISTS(SELECT 1 FROM financial_credit_adjustments parent WHERE parent.id=?10 AND parent.case_id=f.id AND parent.grant_id=g.id AND parent.direction='reverse'
     AND parent.amount_micros-COALESCE((SELECT SUM(a.amount_micros) FROM financial_credit_adjustments a WHERE a.parent_id=parent.id AND a.id<>?1),0)>=?9)))) THEN 1 ELSE 0 END`,adjustmentId,nonce,guard,caseId,input.expectedRevision,input.grantId,actor.id,input.direction,input.amountMicros,input.parentId??null),
  stmt(`UPDATE credit_grants SET reversed_micros=reversed_micros+?3 WHERE id=?4 AND ${fresh}`,adjustmentId,nonce,input.direction==='reverse'?input.amountMicros:-input.amountMicros,input.grantId),
  stmt(`UPDATE financial_cases SET credit_adjustment_micros=credit_adjustment_micros+?3,revision=revision+1,updated_at=?4 WHERE id=?5 AND ${fresh}`,adjustmentId,nonce,input.direction==='reverse'?input.amountMicros:-input.amountMicros,time,caseId),
  stmt(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?3,?4,?5,'financial_case',?6,?7,?8,?9 WHERE ${fresh}`,adjustmentId,nonce,id('audit'),actor.id,`payment.credit.${input.direction}`,caseId,JSON.stringify({...input,adjustmentId,orderId:row.order_id}),input.requestKey,time),
  stmt('DELETE FROM mutation_guards WHERE id=?',guard),
 ]);}catch(error){if(String(error).includes('financial_credit_adjustments.payload_hash'))throw new AppError('IDEMPOTENCY_CONFLICT','该请求标识已用于其他额度调整',409);if(/mutation_revision_ok|ledger_grant_reversal_balance/.test(String(error)))throw new AppError('CREDIT_ADJUSTMENT_CONFLICT','记录已变化、渠道结果未确认或可调整金额不足；已消耗和预占中的额度必须另行核对',409);throw error;}
 return caseCredits(env,caseId);
}
