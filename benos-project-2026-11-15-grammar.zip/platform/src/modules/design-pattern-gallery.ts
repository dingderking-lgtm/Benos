import { Hono, type Context } from 'hono';
import { z } from 'zod';
import { body, ok, type App } from '../lib/http';
import { assert } from '../lib/errors';
import { requireAuth, requireRole } from './auth';
import { PATTERN_GALLERY_ASSETS } from '../contracts/pattern-gallery-assets';
import { PATTERN_SKINS, type PatternSkin } from '../contracts/section-patterns';
import { getSectionPatternCatalog, createSectionPatternFixture, renderSectionPattern, compilePageComposition } from '../lib/page-composer';
import { patternReviewInputSchema, readPatternReviews, recordPatternReview } from '../lib/pattern-approvals';
import { resolveSiteHeader, compileSiteHeader, type SiteHeaderContext } from '../contracts/site-header';
import { compileDesignOrder, createDesignOrder } from '../contracts/design-order';

const scenarioSchema=z.enum(['standard','minimal','maximal','english','rtl','no-images','failed-images','no-facts']);
const escape=(text:string)=>text.replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]!));
export const designPatternGalleryRoutes=new Hono<App>();
designPatternGalleryRoutes.use('*',requireAuth,requireRole('owner','admin'));

designPatternGalleryRoutes.get('/',async c=>{
 const [catalog,reviews]=await Promise.all([getSectionPatternCatalog(),readPatternReviews(c.env.DB)]);
 return ok(c,{version:catalog.version,skins:catalog.skins.map(s=>({id:s.id,name:s.label})),sourceLabel:'既有生成概念图，仅用于画廊示例；未发起新的模型请求。',patterns:catalog.families.map(p=>({id:p.id,name:p.label,code:p.code,role:p.group,variants:p.variants.map(v=>({id:v.id,name:v.label,revision:p.revision,compiledHash:v.compiledHash,skins:v.allowedSkins,reviews:Object.fromEntries(v.allowedSkins.map(s=>[s,reviews.find(r=>r.patternId===p.id&&r.variantId===v.id&&r.revision===p.revision&&r.compiledHash===v.compiledHash&&r.skin===s)?.state||'draft']))}))}))});
});
designPatternGalleryRoutes.post('/review',requireRole('owner'),async c=>{
 const input=await body(c,patternReviewInputSchema),catalog=await getSectionPatternCatalog();
 const family=catalog.families.find(p=>p.id===input.patternId),variant=family?.variants.find(v=>v.id===input.variantId);
 assert(family&&variant&&family.revision===input.revision&&variant.compiledHash===input.compiledHash&&variant.allowedSkins.some(s=>s===input.skin),'PATTERN_REVIEW_STALE','模式已更新，请刷新并查看新版后再审核',409);
 return ok(c,await recordPatternReview(c.env,c.get('auth').user.id,input,c.get('requestId')));
});
function skinFor(c:Context<App>):PatternSkin { const value=PATTERN_SKINS.find(s=>s===c.req.query('skin'));assert(value,'VALIDATION','请选择有效皮肤');return value; }
function documentResponse(c:Context<App>,html:string,css:string,options:{lang?:string;dir?:string;title:string;collection?:boolean}){
 c.header('X-Frame-Options','SAMEORIGIN');
 c.header('Cache-Control','private, no-store');c.header('X-Robots-Tag','noindex,nofollow');
 c.header('Referrer-Policy','no-referrer');
 c.header('Content-Security-Policy',"sandbox allow-same-origin; default-src 'none'; script-src 'none'; style-src 'unsafe-inline' https://fonts.googleapis.com; img-src 'self' data:; font-src https://fonts.gstatic.com; connect-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'");
 const base='html{scroll-behavior:auto}body{margin:0}*,*::before,*::after{box-sizing:border-box}.bpg-fixture-label{font:600 13px/1.5 system-ui,sans-serif;letter-spacing:.04em;padding:16px 24px;color:#475569;background:#eef1f6;border-block:1px solid #dce2ea}';
 const order=compileDesignOrder(createDesignOrder({request:'',language:options.lang||'zh-CN'}));
 return c.html(`<!doctype html><html lang="${escape(options.lang||'zh-CN')}" dir="${options.dir==='rtl'?'rtl':'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>${escape(options.title)}</title><style>${(base+order+css).replace(/<\/style/gi,'<\\/style')}</style></head><body data-pattern-preview="bns-1">${html}</body></html>`);
}
designPatternGalleryRoutes.get('/preview',async c=>{
 const patternId=c.req.query('pattern')||'',variantId=c.req.query('variant')||'',skin=skinFor(c);
 const catalog=await getSectionPatternCatalog(),pattern=catalog.families.find(p=>p.id===patternId),variant=pattern?.variants.find(v=>v.id===variantId);
 assert(pattern&&variant,'NOT_FOUND','模式不存在',404);
 const scenario=scenarioSchema.parse(c.req.query('fixture')||'standard');
 const fixture=createSectionPatternFixture(patternId,variantId,{skin,scenario,imageBaseUrl:'/api/admin/design-patterns/assets'});
 const rendered=await renderSectionPattern(fixture.input,fixture.context);
 return documentResponse(c,rendered.html,rendered.css,{lang:fixture.lang,dir:fixture.dir,title:pattern.label+' · '+variant.label});
});
function galleryHeader(skin:PatternSkin){
 const context:SiteHeaderContext={seed:'pattern-gallery:'+skin,homeHref:'#orientation',language:'zh-CN',allowFixedOverlay:true,menus:[{id:1,items:[{id:'explore',label:'空间与细节',url:'#gallery'},{id:'method',label:'旅居节奏',url:'#process'},{id:'questions',label:'常见问题',url:'#questions'}]}]};
 const resolved=resolveSiteHeader({version:'bnh-1',pattern:skin==='bold-outline'?'capsule':'classic',brand:{text:'山间来信',logo:null},menuId:1,actions:[{label:'探索旅居',href:'#gallery',style:'primary'}],options:{mobileMode:'dropdown',sticky:false,allowFixedOverlay:true}},context);
 return compileSiteHeader(resolved,context);
}
designPatternGalleryRoutes.get('/page',async c=>{
 const skin=skinFor(c),hero=skin==='soft-gradient'?['hero-stage','product-stage']:skin==='bold-outline'?['hero-centered','wide-stage']:['hero-cover','scene-cover'];
 const choices=[['orientation',...hero],['highlights','features-icons','feature-band'],['gallery','media-mosaic',skin==='bold-outline'?'bento':'one-large-two-small'],['details','media-story','lead-image-list'],['process','process-path','image-steps'],['choices','features-ledger','numbered'],['questions','faq-details','accordion'],['next','action-panel','accent-band'],['footer','footer-directory','directory']];
 const introductions:Record<string,string>={orientation:'把时间留给窗外，也留给自己。沿着山色、自然光与日常片段，想象一段轻盈的旅居。',highlights:'从光线、材质、相处方式到一天的节奏，找到你在意的停留体验。',gallery:'窗外有山色，窗内有生活。远景与细节，共同构成对一处空间的感受。',details:'有人喜欢安静地读书，有人想在桌边聊到傍晚。让空间回应不同的相处方式。',process:'先确定最想留下的体验，再安排必要的信息和行程。简单几步，让出发更从容。',choices:'不必把每个小时排满。给阅读、散步和相聚各留一点空间。',questions:'关于节奏、准备与同行，先从这些问题开始。',next:'从一个想看的角落开始，找到适合自己的旅居节奏。',footer:'山间有四季，停留有自己的节奏。把日常里略过的光线与细节，重新看一遍。'};
 const steps=[['选择节奏','先想好这次最想体验的事情，给停留定下一个轻松的起点。'],['了解空间','从房间、公共区域与周边环境，判断是否适合同行人的需要。'],['确认安排','向实际经营者核实入住条件、交通与预订规则，再做决定。'],['留出空白','在必要的安排之外，给天气、心情与临时发现留一点时间。']];
 const perspectives=[['独处','给阅读、记录或发呆一个完整时段，暂时放下待办清单。'],['同行','提前聊聊彼此的期待，安排共同的时刻，也尊重各自的节奏。'],['漫步','从窗外的一条小路开始，留意光线、声音和沿途的变化。'],['慢下来','少安排一个目的地，多留一点停下来的时间。']];
 const fixtures=choices.map(([id,p,v])=>{const f=createSectionPatternFixture(p,v,{skin,imageBaseUrl:'/api/admin/design-patterns/assets'});f.input.id=id;f.input.content.lead=introductions[id];if(id==='process'||id==='choices'){const items=id==='process'?steps:perspectives;f.input.content.items=(f.input.content.items??[]).map((item,i)=>({...item,title:items[i%items.length][0],text:items[i%items.length][1]}));}return f;});
 const composed=await compilePageComposition({version:'compose-1',skin,sections:fixtures.map(f=>f.input)},fixtures[0].context),header=galleryHeader(skin);
 return documentResponse(c,header.html+composed.html,header.css+composed.css,{title:'山间来信 · 模式画廊组合示例'});
});
/** A long-form index for visual review/export, using the very same renderer. */
designPatternGalleryRoutes.get('/collection',async c=>{
 const skin=skinFor(c),catalog=await getSectionPatternCatalog(),all=c.req.query('variants')==='all';
 const parts: string[]=[],styles=new Set<string>();
 for(const p of catalog.families)for(const v of all?p.variants:p.variants.slice(0,1)){
  const fixture=createSectionPatternFixture(p.id,v.id,{skin,imageBaseUrl:'/api/admin/design-patterns/assets'});fixture.input.id=p.code.toLowerCase()+'-v'+(p.variants.indexOf(v)+1);
  const rendered=await renderSectionPattern(fixture.input,fixture.context);
  parts.push(`<div class="bpg-fixture-label">${escape(p.code+' · '+p.label+' / '+v.label)} — 画廊示例 · 待审</div>`+rendered.html);styles.add(rendered.css);
 }
 return documentResponse(c,parts.join('\n'),[...styles].join('\n'),{title:'Benos 设计模式 · '+skin,collection:true});
});
async function asset(c:Context<App>,file:string){
 const item=PATTERN_GALLERY_ASSETS.find(a=>a.file===file);assert(item,'NOT_FOUND','素材不存在',404);
 const response=await c.env.ASSETS.fetch(new Request(new URL(item.path,c.req.url)));
 assert(response.ok,'ASSET_UNAVAILABLE','画廊素材尚未就绪',503);
 c.header('Content-Type','image/png');c.header('Cache-Control','private, no-store');c.header('ETag','"'+item.sha256+'"');c.header('X-Content-Type-Options','nosniff');
 return new Response(response.body,{headers:{'Content-Type':'image/png','Cache-Control':'private, no-store','ETag':'"'+item.sha256+'"','X-Content-Type-Options':'nosniff'}});
}
designPatternGalleryRoutes.get('/assets/:file',c=>asset(c,c.req.param('file')));
/** Protect the static backing path as well as its API alias. */
export const designPatternAssetRoutes=new Hono<App>();
designPatternAssetRoutes.use('*',requireAuth,requireRole('owner','admin'));
designPatternAssetRoutes.get('/:file',c=>asset(c,c.req.param('file')));
