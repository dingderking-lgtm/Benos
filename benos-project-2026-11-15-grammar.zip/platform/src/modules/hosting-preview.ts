import type { Env } from '../env';
import { assert } from '../lib/errors';
import { decryptSecret,sha256,base64url,constantTimeEqual } from '../lib/crypto';
import { AppError } from '../lib/errors';
import { resolveProjectAssets } from './media';
import { validateSiteManifest } from './template-contract';
import { signedHostingFetch,signHostingRequest,normalizeHostingDomain } from './hosting';

export type NativePreviewConnection={siteId:string;origin:string;keyId:string;secret:string;identityHash:string};
export async function nativePreviewConnection(env:Env,userId:string,projectId:string,siteId?:string):Promise<NativePreviewConnection>{
 const row=await env.DB.prepare("SELECT s.id,s.domain,c.origin,c.key_id,c.secret_ciphertext,c.cms_version FROM sites s JOIN projects p ON p.id=s.project_id JOIN site_connections c ON c.site_id=s.id WHERE s.project_id=? AND s.user_id=? AND p.user_id=? AND p.archived_at IS NULL AND s.state='connected' AND c.last_verified_at IS NOT NULL AND (? IS NULL OR s.id=?) ORDER BY s.created_at,s.id LIMIT 1").bind(projectId,userId,userId,siteId??null,siteId??null).first<{id:string;domain:string;origin:string;key_id:string;secret_ciphertext:string;cms_version:string}>();
 assert(row,'NATIVE_PREVIEW_NOT_CONNECTED','请先连接此项目的 CMS，再执行原生预览',409);assert(row.origin==='https://'+normalizeHostingDomain(row.domain)&&row.cms_version==='1.9.21','NATIVE_PREVIEW_BASELINE_INVALID','目标 CMS 连接或版本不符合预览基线',409);
 return {siteId:row.id,origin:row.origin,keyId:row.key_id,secret:await decryptSecret(row.secret_ciphertext,env.ENCRYPTION_KEY,row.id),identityHash:await sha256(JSON.stringify(row))};
}
/** Native v2 control messages stay small. Artifact responses are at most one
 * MiB and their exact binary bytes, status, nonce and time are authenticated. */
export async function nativePreviewRequest(connection:NativePreviewConnection,input:Record<string,unknown>,requestKey:string,binary=false,health=false){
 const url=new URL(connection.origin);assert(url.origin===connection.origin&&url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&normalizeHostingDomain(url.hostname)===url.hostname,'NATIVE_PREVIEW_CONNECTION_INVALID','原生预览连接无效',503);
 const target=connection.origin+(health?'/benos-health.php':'/benos-connect.php'),raw=health?'':JSON.stringify(input),method=health?'GET':'POST';assert(new TextEncoder().encode(raw).length<=16384,'NATIVE_PREVIEW_REQUEST_LIMIT','原生预览控制请求过大',413);const headers=await signHostingRequest(target,method,raw,connection.secret,connection.keyId,connection.siteId,requestKey,'BENOS-CMS-V1');
 const response=await fetch(target,{method,headers,body:health?undefined:raw,redirect:'manual',signal:AbortSignal.timeout(20000)}),limit=binary?1048576:65536;assert(response.status<300||response.status>=400,'NATIVE_PREVIEW_REDIRECT','原生预览连接发生重定向',502);assert(Number(response.headers.get('content-length')||0)<=limit,'NATIVE_PREVIEW_RESPONSE_INVALID','原生预览响应超限',502);
 const reader=response.body?.getReader(),parts:Uint8Array[]=[];let size=0;if(reader)while(true){const item=await reader.read();if(item.done)break;size+=item.value.length;if(size>limit){await reader.cancel();throw new AppError('NATIVE_PREVIEW_RESPONSE_INVALID','原生预览响应超限',502);}parts.push(item.value);}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}const timestamp=response.headers.get('X-Benos-Timestamp')??'',signature=response.headers.get('X-Benos-Signature')??'';assert(/^\d{10,12}$/.test(timestamp)&&Math.abs(Date.now()/1000-Number(timestamp))<=120,'NATIVE_PREVIEW_RESPONSE_INVALID','原生预览响应已过期',502);
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(connection.secret),{name:'HMAC',hash:'SHA-256'},false,['sign']),canonical=['BENOS-CMS-V1-RESPONSE',headers['X-Benos-Nonce'],String(response.status),timestamp,await sha256(bytes)].join('\n'),expected=base64url(new Uint8Array(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(canonical))));assert(constantTimeEqual(signature,expected),'NATIVE_PREVIEW_RESPONSE_INVALID','原生预览响应签名无效',502);
 if(binary&&response.status===200){assert(response.headers.get('content-type')?.split(';')[0]==='application/octet-stream','NATIVE_PREVIEW_RESPONSE_INVALID','原生预览资源响应类型无效',502);return {status:response.status,data:null,bytes};}
 let data:unknown;try{data=JSON.parse(new TextDecoder().decode(bytes));}catch{throw new AppError('NATIVE_PREVIEW_RESPONSE_INVALID','原生预览控制响应无效',502);}return {status:response.status,data,bytes:null};
}

export async function renderNativeManifestPreview(env:Env,userId:string,projectId:string,manifest:unknown,pageKey:string){
 assert(validateSiteManifest(manifest).valid,'TEMPLATE_INVALID','设计未通过模板合同校验',422);
 const target=await env.DB.prepare('SELECT s.id,s.domain,c.origin,c.key_id,c.secret_ciphertext,c.cms_version FROM sites s JOIN projects p ON p.id=s.project_id JOIN site_connections c ON c.site_id=s.id WHERE s.project_id=? AND s.user_id=? AND p.user_id=? AND p.archived_at IS NULL AND c.last_verified_at IS NOT NULL ORDER BY s.created_at,s.id LIMIT 1').bind(projectId,userId,userId).first<{id:string;domain:string;origin:string;key_id:string;secret_ciphertext:string;cms_version:string}>();
 assert(target,'NATIVE_PREVIEW_NOT_CONNECTED','请先连接此项目的 CMS，再执行原生预览；当前设计预览尚未完成 CMS 渲染验证',409);
 assert(target.origin==='https://'+target.domain&&target.cms_version==='1.9.21','NATIVE_PREVIEW_BASELINE_INVALID','目标 CMS 连接或版本不符合预览基线',409);
 const resolved=await resolveProjectAssets(env,userId,projectId,manifest),total=resolved.files.reduce((sum,file)=>sum+file.bytes.byteLength,0);assert(total<=6*1048576,'PREVIEW_ASSETS_TOO_LARGE','原生预览的素材总量目前最多 6 MiB',413);
 const assets=resolved.files.map(file=>{let raw='';for(let i=0;i<file.bytes.length;i+=8192)raw+=String.fromCharCode(...file.bytes.subarray(i,i+8192));return {file:file.file,base64:btoa(raw)};});
 const manifestJson=JSON.stringify(manifest),manifestSha256=await sha256(manifestJson),secret=await decryptSecret(target.secret_ciphertext,env.ENCRYPTION_KEY,target.id);
 const result=await signedHostingFetch(target.origin+'/benos-connect.php','POST',{operation:'preview',manifestJson,pageKey,assets},secret,target.key_id,target.id,'preview_'+manifestSha256.slice(0,32),'BENOS-CMS-V1',12*1048576);
 const data=result.data as any;assert(result.status===200&&data?.cmsVersion==='1.9.21'&&data.manifestSha256===manifestSha256&&data.pageKey===pageKey&&typeof data.html==='string'&&data.html.length<=8*1048576&&data.businessWrites===false&&Array.isArray(data.sanitizationChanges),'NATIVE_PREVIEW_UNVERIFIED','CMS 原生预览尚未验证，请确认目标站已安装兼容连接版本',502);
 return {siteId:target.id,cmsVersion:data.cmsVersion as string,manifestSha256,html:data.html as string,sanitizationChanges:data.sanitizationChanges as Array<{templateId:number;field:string;beforeSha256:string;afterSha256:string}>,usesSampleData:data.usesSampleData===true};
}
