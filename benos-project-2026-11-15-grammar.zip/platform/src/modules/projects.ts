import { Hono } from 'hono';
import { z } from 'zod';
import { body,ok,type App } from '../lib/http';
import { assert } from '../lib/errors';
import { id,base64url,unbase64url } from '../lib/crypto';
import { requireAuth,rateLimit } from './auth';
import { auditStatement } from '../lib/audit';
const projectInput=z.object({name:z.string().trim().min(1,'请输入网站名称').max(120),description:z.string().max(12000).default('')});
// PATCH has its own schema without defaults: a missing field must stay undefined so COALESCE keeps the stored value.
const projectPatch=z.object({name:z.string().trim().min(1,'请输入网站名称').max(120).optional(),description:z.string().max(12000).optional()});
export const projectRoutes=new Hono<App>();
projectRoutes.use('*',requireAuth);
projectRoutes.get('/',async c=>{
  const cursor=c.req.query('cursor'),userId=c.get('auth').user.id;
  let time='9999-12-31T23:59:59.999Z',lastId='~';
  if(cursor){
    let parsed:unknown;try{parsed=JSON.parse(new TextDecoder().decode(unbase64url(cursor)));}catch{parsed=null;}
    const checked=z.object({time:z.string().datetime(),id:z.string().regex(/^prj_[a-f0-9]{32}$/)}).safeParse(parsed);
    assert(checked.success,'INVALID_CURSOR','分页位置无效');time=checked.data.time;lastId=checked.data.id;
  }
  const rows=await c.env.DB.prepare('SELECT id,name,description,status,direction_json,current_version_id,published_version_id,created_at,updated_at FROM projects WHERE user_id=? AND archived_at IS NULL AND (updated_at<? OR (updated_at=? AND id<?)) ORDER BY updated_at DESC,id DESC LIMIT 51').bind(userId,time,time,lastId).all();
  const last=rows.results[49];
  return ok(c,{items:rows.results.slice(0,50),nextCursor:rows.results.length>50?base64url(new TextEncoder().encode(JSON.stringify({time:last.updated_at,id:last.id}))):null});
});
projectRoutes.post('/',async c=>{
  const userId=c.get('auth').user.id;await rateLimit(c,'new-project',30,3600,userId);
  const input=await body(c,projectInput),projectId=id('prj'),now=new Date().toISOString();
  await c.env.DB.batch([
    c.env.DB.prepare("INSERT INTO projects(id,user_id,name,description,status,created_at,updated_at) VALUES(?,?,?,?,'draft',?,?)").bind(projectId,userId,input.name,input.description,now,now),
    auditStatement(c.env.DB,userId,'project.create','project',projectId,{name:input.name},c.get('requestId'))
  ]);
  return ok(c,{id:projectId,name:input.name,description:input.description,status:'draft',created_at:now,updated_at:now},201);
});
projectRoutes.get('/:id',async c=>{
  const project=await c.env.DB.prepare('SELECT id,name,description,status,direction_json,current_version_id,published_version_id,created_at,updated_at FROM projects WHERE id=? AND user_id=?').bind(c.req.param('id'),c.get('auth').user.id).first();
  assert(project,'NOT_FOUND','网站项目不存在',404);return ok(c,project);
});
projectRoutes.patch('/:id',async c=>{
  const input=await body(c,projectPatch),userId=c.get('auth').user.id;
  assert(input.name!==undefined||input.description!==undefined,'VALIDATION','没有需要保存的修改');
  const result=await c.env.DB.prepare('UPDATE projects SET name=COALESCE(?,name),description=COALESCE(?,description),updated_at=? WHERE id=? AND user_id=? AND archived_at IS NULL RETURNING id,name,description,status,created_at,updated_at').bind(input.name??null,input.description??null,new Date().toISOString(),c.req.param('id'),userId).first();
  assert(result,'NOT_FOUND','网站项目不存在',404);
  await auditStatement(c.env.DB,userId,'project.update','project',c.req.param('id'),{},c.get('requestId')).run();return ok(c,result);
});
/**
 * Deleting a design takes it off the customer's lists for good. The record itself stays (its versions, media and
 * AI usage are part of the account's history and billing), so nothing that was charged or published loses its trail.
 * A design that is live on a website must be taken offline first; one with a step still being answered must finish.
 */
projectRoutes.delete('/:id',async c=>{
  const userId=c.get('auth').user.id,projectId=c.req.param('id');
  const project=await c.env.DB.prepare('SELECT id,name,published_version_id FROM projects WHERE id=? AND user_id=? AND archived_at IS NULL').bind(projectId,userId).first<{id:string;name:string;published_version_id:string|null}>();
  assert(project,'NOT_FOUND','网站项目不存在',404);
  assert(!project.published_version_id,'PROJECT_PUBLISHED','这个设计已经发布到网站，请先在 CMS 托管中下线，再删除设计',409);
  const running=await c.env.DB.prepare("SELECT 1 FROM ai_workflows WHERE project_id=? AND user_id=? AND state='processing' AND COALESCE(lease_until_ms,0)>?").bind(projectId,userId,Date.now()).first();
  assert(!running,'PROJECT_BUSY','这个设计还有一步正在生成，请等它完成后再删除',409);
  const now=new Date().toISOString();
  await c.env.DB.batch([
    c.env.DB.prepare("UPDATE projects SET archived_at=?,status='archived',updated_at=? WHERE id=? AND user_id=? AND archived_at IS NULL").bind(now,now,projectId,userId),
    auditStatement(c.env.DB,userId,'project.delete','project',projectId,{name:project.name},c.get('requestId'))
  ]);
  return ok(c,{deleted:true});
});
