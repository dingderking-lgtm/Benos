import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { body,ok,type App } from '../lib/http';
import { assert } from '../lib/errors';
import { id,sha256 } from '../lib/crypto';
import { requireAuth,rateLimit } from './auth';
import { ownedDesignProject,readDesignVersion,readDesignCandidate } from './design-workspace';
import { renderNativeManifestPreview } from './hosting-preview';
import { readNativePreviewJobHtml } from './native-preview-jobs';

const TTL=30*60_000;
export const NATIVE_PREVIEW_CSP="sandbox allow-scripts; default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline' https://fonts.googleapis.com; img-src data:; font-src data: https://fonts.gstatic.com; connect-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'; object-src 'none'";
const selection=z.object({versionId:z.string().max(100).optional(),candidateId:z.string().max(100).optional(),pageKey:z.string().regex(/^[a-zA-Z0-9_-]{1,80}$/)}).strict().refine(v=>!!v.versionId!==!!v.candidateId,'请选择一个设计版本或候选方案');
type Selection=z.infer<typeof selection>;
type Render=typeof renderNativeManifestPreview;
type Cached={id:string;object_key:string;html_sha256:string;byte_size:number;metadata_json:string;expires_at:string};

export function nativePreviewPageKeys(manifest:{site:{pages:Array<{key:string;type?:string}>;blog?:Record<string,unknown>|null}}){
 const {pages,blog}=manifest.site,hasBlog=!!blog&&typeof blog==='object'&&!Array.isArray(blog);
 // The pinned PHP inspector defaults an omitted enabled field to true. Preview.php
 // creates its sample article whenever a blog object has no actual article page,
 // including disabled-blog design previews; it never replaces real article keys.
 return [...pages.map(page=>page.key),...(hasBlog&&blog.enabled!==false?['__blog_archive','__blog_author']:[]),...(hasBlog&&!pages.some(page=>page.type==='article')?['__blog_article']:[])];
}
export async function createNativePreview(env:Env,userId:string,projectId:string,input:Selection,runtime:{render?:Render;now?:number}={}){
 await ownedDesignProject(env,userId,projectId);assert(env.BUCKET,'MEDIA_NOT_CONFIGURED','预览存储尚未配置',503);
 const manifest=input.versionId?await readDesignVersion(env,userId,projectId,input.versionId):JSON.parse((await readDesignCandidate(env,userId,projectId,input.candidateId!)).manifest_json);
 const available=nativePreviewPageKeys(manifest);
 assert(available.includes(input.pageKey),'NOT_FOUND','预览页面不存在',404);
 const rendered=await (runtime.render??renderNativeManifestPreview)(env,userId,projectId,manifest,input.pageKey),bytes=new TextEncoder().encode(rendered.html);
 assert(bytes.byteLength>0&&bytes.byteLength<=8*1048576,'NATIVE_PREVIEW_TOO_LARGE','原生预览内容超过限制',413);
 const now=runtime.now??Date.now(),previewId=id('native'),objectKey=`private/previews/${userId}/${projectId}/${previewId}.html`,expiresAt=new Date(now+TTL).toISOString(),htmlSha256=await sha256(bytes);
 const metadata={cmsVersion:rendered.cmsVersion,manifestSha256:rendered.manifestSha256,pageKey:input.pageKey,versionId:input.versionId??null,candidateId:input.candidateId??null,sanitizationChanges:rendered.sanitizationChanges,usesSampleData:rendered.usesSampleData,expiresAt};
 // Index before storage: even a lost PUT acknowledgement is tracked for expiry.
 // No URL is returned until the write succeeds; missing/corrupt objects fail closed.
 await env.DB.prepare('INSERT INTO native_previews(id,user_id,project_id,object_key,html_sha256,byte_size,metadata_json,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?)').bind(previewId,userId,projectId,objectKey,htmlSha256,bytes.byteLength,JSON.stringify(metadata),new Date(now).toISOString(),expiresAt).run();
 await env.BUCKET.put(objectKey,bytes,{httpMetadata:{contentType:'text/html; charset=utf-8',cacheControl:'private, no-store'},customMetadata:{sha256:htmlSha256,expiresAt}});
 return {...metadata,previewUrl:`/preview/native/${encodeURIComponent(projectId)}/${previewId}`};
}
export async function readNativePreview(env:Env,userId:string,projectId:string,previewId:string,now=Date.now()){
 if(/^preview_[a-f0-9]{32}$/.test(previewId))return readNativePreviewJobHtml(env,userId,projectId,previewId,now);
 await ownedDesignProject(env,userId,projectId);
 const row=await env.DB.prepare('SELECT id,object_key,html_sha256,byte_size,metadata_json,expires_at FROM native_previews WHERE id=? AND user_id=? AND project_id=?').bind(previewId,userId,projectId).first<Cached>();
 assert(row,'NOT_FOUND','原生预览不存在',404);assert(Date.parse(row.expires_at)>now,'NATIVE_PREVIEW_EXPIRED','原生预览已过期，请重新生成',410);assert(env.BUCKET,'MEDIA_NOT_CONFIGURED','预览存储尚未配置',503);
 const object=await env.BUCKET.get(row.object_key);assert(object&&object.size===row.byte_size,'NATIVE_PREVIEW_MISSING','原生预览副本暂不可用，请重新生成',503);
 const bytes=new Uint8Array(await object.arrayBuffer());assert(await sha256(bytes)===row.html_sha256,'NATIVE_PREVIEW_CORRUPT','原生预览副本校验失败，请重新生成',503);return {bytes,metadata:JSON.parse(row.metadata_json),csp:NATIVE_PREVIEW_CSP};
}
export async function purgeNativePreviews(env:Env,now=Date.now()){
 if(!env.BUCKET)return {removed:0};
 const rows=await env.DB.prepare('SELECT id,object_key FROM native_previews WHERE expires_at<=? ORDER BY expires_at LIMIT 100').bind(new Date(now).toISOString()).all<{id:string;object_key:string}>();let removed=0;
 for(const row of rows.results){await env.BUCKET.delete(row.object_key);await env.DB.prepare('DELETE FROM native_previews WHERE id=?').bind(row.id).run();removed++;}return {removed};
}
export const nativePreviewApiRoutes=new Hono<App>();nativePreviewApiRoutes.use('*',requireAuth);
nativePreviewApiRoutes.post('/projects/:project/native-previews',async c=>{await rateLimit(c,'native-preview',30,3600,c.get('auth').user.id);const input=await body(c,selection);return ok(c,await createNativePreview(c.env,c.get('auth').user.id,c.req.param('project'),input),201);});
export const nativePreviewPageRoutes=new Hono<App>();nativePreviewPageRoutes.use('*',requireAuth);
nativePreviewPageRoutes.get('/native/:project/:preview',async c=>{
 const result=await readNativePreview(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('preview'));
 const response=c.body(result.bytes as Uint8Array<ArrayBuffer>,200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'private, no-store','Content-Security-Policy':result.csp,'Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','X-Frame-Options':'SAMEORIGIN'});
 // Native menus keep their local interaction. Page changes use the parent page picker;
 // a preview cannot navigate away, submit a form or load external resources.
 return new HTMLRewriter().on('a[href]',{element(e){if(!(e.getAttribute('href')||'').startsWith('#')){e.removeAttribute('href');e.setAttribute('aria-disabled','true');e.setAttribute('title','请使用预览页面选择器切换页面');}e.removeAttribute('target');e.removeAttribute('download');}}).on('base',{element(e){e.remove();}}).on('meta[http-equiv]',{element(e){e.remove();}}).transform(response);
});
