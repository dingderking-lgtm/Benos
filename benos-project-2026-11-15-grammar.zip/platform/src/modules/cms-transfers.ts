import { z } from 'zod';
import type { Env } from '../env';
import { assert,AppError } from '../lib/errors';
import { id,sha256,decryptSecret } from '../lib/crypto';
import { designManifestObjectKey,type ManifestStorageRow,type ManifestObjectRow } from '../lib/design-storage';
import { CMS_BUNDLE_CHUNK_BYTES,cmsBundleRequest,encodeCmsBundleChunk,type CmsBundleCredentials,type CmsBundleMetadata,type CmsBundleState } from '../lib/cms-bundle';
import { restricted } from './auth';
import { hasHostingAccess } from './hosting';

type Transfer={id:string;user_id:string;site_id:string;project_id:string;version_id:string;request_key:string;request_hash:string;purpose:'preview'|'publish';metadata_json:string;sources_json:string;state:string;progress_json:string|null;error_code:string|null;lease_token:string|null;lease_until_ms:number|null;expires_at_ms:number;created_at:string;updated_at:string};
type Source={file:string;size:number;sha256:string;kind:'manifest'|'media';mediaId?:string;manifestObjectId?:string|null};
type Version=ManifestStorageRow&{project_id:string;content_hash:string};
type Runtime={send?:typeof cmsBundleRequest;readChunk?:(source:Source,offset:number,length:number)=>Promise<Uint8Array>;now?:()=>number;authorize?:()=>Promise<void>};
const fileSchema=z.object({file:z.string(),size:z.number().int().positive(),sha256:z.string().regex(/^[a-f0-9]{64}$/),received:z.number().int().nonnegative()}).strict();
const stateSchema=z.object({protocol:z.literal('benos-bundle-v2'),bundleId:z.string(),siteId:z.string(),purpose:z.enum(['preview','publish']),projectId:z.string(),versionId:z.string(),state:z.enum(['receiving','sealed','discarded','expired']),expiresAt:z.number().int().positive(),expired:z.boolean(),pinned:z.boolean(),chunkBytes:z.literal(CMS_BUNDLE_CHUNK_BYTES),zipBytes:z.number().int().positive(),zipSha256:z.string().regex(/^[a-f0-9]{64}$/).nullable(),nativeValidated:z.literal(false),files:z.array(fileSchema).max(65)}).strict();
function transferView(row:Transfer){const progress=row.progress_json?JSON.parse(row.progress_json) as CmsBundleState:null;return {id:row.id,state:row.state,bytesSent:progress?.files.reduce((sum,f)=>sum+f.received,0)??0,totalBytes:(JSON.parse(row.sources_json) as Source[]).reduce((sum,f)=>sum+f.size,0),errorCode:row.error_code,expiresAt:new Date(row.expires_at_ms).toISOString(),sealed:row.state==='sealed'};}
async function ownedTransfer(env:Env,userId:string,transferId:string){const row=await env.DB.prepare('SELECT * FROM cms_bundle_transfers WHERE id=? AND user_id=?').bind(transferId,userId).first<Transfer>();assert(row,'NOT_FOUND','CMS 资源传输不存在',404);return row;}
async function authorizeTransfer(env:Env,row:Transfer,runtime:Runtime){
 assert(await env.DB.prepare("SELECT 1 FROM users WHERE id=? AND status='active'").bind(row.user_id).first(),'ACCOUNT_RESTRICTED','账户已暂停',403);
 assert(!await restricted(env.DB,row.user_id,row.purpose==='publish'?'publish':'ai'),'ACCOUNT_RESTRICTED','该账户的设计或发布权限已暂停',403);
 if(row.purpose==='publish'){
  assert(!await env.DB.prepare('SELECT 1 FROM hosting_site_controls WHERE site_id=? AND paused=1').bind(row.site_id).first(),'HOSTING_MANUALLY_PAUSED','网站托管已暂停',403);
  assert(await hasHostingAccess(env,row.user_id,row.site_id),'HOSTING_EXPIRED','请续费会员或该网站的年度托管服务',403);
 }await runtime.authorize?.();
}
async function credentials(env:Env,row:Pick<Transfer,'site_id'|'user_id'|'project_id'>):Promise<CmsBundleCredentials>{
 const site=await env.DB.prepare('SELECT s.domain,c.origin,c.key_id,c.secret_ciphertext FROM sites s JOIN projects p ON p.id=s.project_id JOIN site_connections c ON c.site_id=s.id WHERE s.id=? AND s.user_id=? AND s.project_id=? AND p.user_id=? AND p.archived_at IS NULL AND s.state=\'connected\' AND c.last_verified_at IS NOT NULL').bind(row.site_id,row.user_id,row.project_id,row.user_id).first<{domain:string;origin:string;key_id:string;secret_ciphertext:string}>();
 assert(site&&site.origin==='https://'+site.domain,'CMS_CONNECTION_INVALID','CMS 连接身份不可用',409);return {url:site.origin+'/benos-bundle.php',siteId:row.site_id,keyId:site.key_id,secret:await decryptSecret(site.secret_ciphertext,env.ENCRYPTION_KEY,row.site_id)};
}
/** Metadata-only preparation. Full manifests and media are never placed in this
 * task row, and no remote mutation happens before the durable identity exists. */
export async function ensureCmsBundleTransfer(env:Env,userId:string,siteId:string,versionId:string,requestKey:string,purpose:'preview'|'publish',nowMs=Date.now()){
 assert(/^[a-zA-Z0-9:_-]{8,160}$/.test(requestKey),'VALIDATION','CMS 传输请求编号无效',422);
 const version=await env.DB.prepare('SELECT v.manifest_json,v.manifest_object_id,v.content_hash,v.project_id FROM design_versions v JOIN projects p ON p.id=v.project_id JOIN sites s ON s.project_id=p.id WHERE v.id=? AND p.user_id=? AND p.archived_at IS NULL AND s.id=? AND s.user_id=?').bind(versionId,userId,siteId,userId).first<Version>();assert(version,'NOT_FOUND','设计版本与 CMS 网站不匹配',404);
 const hash=await sha256(JSON.stringify({siteId,versionId,purpose,contentHash:version.content_hash})),existing=await env.DB.prepare('SELECT * FROM cms_bundle_transfers WHERE user_id=? AND request_key=?').bind(userId,requestKey).first<Transfer>();
 if(existing){assert(existing.request_hash===hash,'IDEMPOTENCY_CONFLICT','传输请求编号已用于其他版本',409);return transferView(existing);}
 const stored=JSON.parse(version.manifest_json),sources:Source[]=[];
 let manifestSize:number;
 if(version.manifest_object_id){const object=await env.DB.prepare('SELECT * FROM design_manifest_objects WHERE id=? AND user_id=? AND project_id=? AND state=\'ready\'').bind(version.manifest_object_id,userId,version.project_id).first<ManifestObjectRow>();assert(object&&object.index_json===version.manifest_json&&object.sha256===version.content_hash,'DESIGN_STORAGE_CORRUPT','设计清单索引不一致',503);manifestSize=object.byte_size;}
 else {manifestSize=new TextEncoder().encode(version.manifest_json).byteLength;assert(await sha256(version.manifest_json)===version.content_hash,'DESIGN_STORAGE_CORRUPT','设计清单摘要不一致',503);}
 sources.push({kind:'manifest',file:'manifest.json',size:manifestSize,sha256:version.content_hash,manifestObjectId:version.manifest_object_id??null});
 for(const asset of stored.assets as Array<{file:string;size:number;sha256:string}>){const ext=asset.file.split('.').at(-1),media=await env.DB.prepare("SELECT id FROM project_media_inventory WHERE user_id=? AND project_id=? AND state='ready' AND sha256=? AND byte_size=? AND extension=? ORDER BY created_at LIMIT 1").bind(userId,version.project_id,asset.sha256,asset.size,ext==='jpeg'?'jpg':ext!).first<{id:string}>();assert(media,'MEDIA_NOT_FOUND','模板素材不可用',422);sources.push({...asset,kind:'media',mediaId:media.id});}
 const metadata:CmsBundleMetadata={schemaVersion:2,bundleId:id('bundle'),purpose,projectId:version.project_id,versionId,expiresAt:Math.floor(nowMs/1000)+86400,manifest:{file:'manifest.json',size:manifestSize,sha256:version.content_hash},assets:sources.slice(1).map(({file,size,sha256})=>({file,size,sha256}))};
 const total=sources.reduce((sum,f)=>sum+f.size,0),zip=22+sources.reduce((sum,f)=>sum+f.size+76+2*f.file.length,0);assert(sources.length<=65&&manifestSize<=10*1048576&&total-manifestSize<=64*1048576&&zip<=74*1048576,'CMS_BUNDLE_TOO_LARGE','模板资源超过 CMS 传输容量',413);
 const now=new Date(nowMs).toISOString();await env.DB.prepare("INSERT INTO cms_bundle_transfers(id,user_id,site_id,project_id,version_id,request_key,request_hash,purpose,metadata_json,sources_json,expires_at_ms,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(metadata.bundleId,userId,siteId,version.project_id,versionId,requestKey,hash,purpose,JSON.stringify(metadata),JSON.stringify(sources),metadata.expiresAt*1000,now,now).run();
 const saved=await env.DB.prepare('SELECT * FROM cms_bundle_transfers WHERE user_id=? AND request_key=?').bind(userId,requestKey).first<Transfer>();assert(saved&&saved.request_hash===hash,'IDEMPOTENCY_CONFLICT','传输请求状态已变化',409);return transferView(saved);
}
function verifiedState(data:unknown,row:Transfer):CmsBundleState{
 const parsed=stateSchema.safeParse(data);assert(parsed.success,'CMS_BUNDLE_RESPONSE_INVALID','CMS 分块状态格式无效',502);const state=parsed.data,meta=JSON.parse(row.metadata_json) as CmsBundleMetadata,expected=[meta.manifest,...meta.assets].sort((a,b)=>a.file.localeCompare(b.file)),actual=[...state.files].sort((a,b)=>a.file.localeCompare(b.file)),zip=22+expected.reduce((sum,f)=>sum+f.size+76+2*f.file.length,0);
 assert(state.bundleId===row.id&&state.siteId===row.site_id&&state.projectId===row.project_id&&state.versionId===row.version_id&&state.purpose===row.purpose&&state.expiresAt===meta.expiresAt&&state.zipBytes===zip&&actual.length===expected.length&&actual.every((f,i)=>f.file===expected[i].file&&f.size===expected[i].size&&f.sha256===expected[i].sha256&&f.received<=f.size&&(f.received===f.size||f.received%CMS_BUNDLE_CHUNK_BYTES===0)),'CMS_BUNDLE_IDENTITY_INVALID','CMS 资源传输身份或进度不一致',502);
 assert(state.state!=='sealed'||state.zipSha256&&state.files.every(f=>f.received===f.size),'CMS_BUNDLE_RESPONSE_INVALID','CMS 封包尚未完整',502);return state;
}
async function sourceChunk(env:Env,row:Transfer,source:Source,offset:number,length:number){
 assert(env.BUCKET,'MEDIA_NOT_CONFIGURED','素材存储尚未配置',503);let key:string;
 if(source.kind==='manifest'){
  const version=await env.DB.prepare('SELECT manifest_json,manifest_object_id,content_hash FROM design_versions WHERE id=? AND project_id=?').bind(row.version_id,row.project_id).first<ManifestStorageRow>();assert(version&&version.content_hash===source.sha256&&version.manifest_object_id===source.manifestObjectId,'DESIGN_STORAGE_CORRUPT','传输清单身份不一致',503);
  if(!source.manifestObjectId){const bytes=new TextEncoder().encode(version.manifest_json);assert(bytes.length===source.size&&await sha256(bytes)===source.sha256,'DESIGN_STORAGE_CORRUPT','传输清单副本不一致',503);return bytes.slice(offset,offset+length);}
  const object=await env.DB.prepare('SELECT * FROM design_manifest_objects WHERE id=?').bind(source.manifestObjectId).first<ManifestObjectRow>();assert(object&&object.user_id===row.user_id&&object.project_id===row.project_id&&object.state==='ready'&&object.sha256===source.sha256&&object.byte_size===source.size&&object.index_json===version.manifest_json&&object.object_key===designManifestObjectKey({userId:row.user_id,projectId:row.project_id},object.id,object.sha256),'DESIGN_STORAGE_CORRUPT','传输清单存储身份不一致',503);key=object.object_key;
 }else {const media=await env.DB.prepare("SELECT object_key,sha256,byte_size FROM project_media_inventory WHERE id=? AND user_id=? AND project_id=? AND state='ready'").bind(source.mediaId!,row.user_id,row.project_id).first<{object_key:string;sha256:string;byte_size:number}>();assert(media&&media.sha256===source.sha256&&media.byte_size===source.size,'MEDIA_NOT_FOUND','传输素材已变更或不可用',409);key=media.object_key;}
 const head=await env.BUCKET.head(key);assert(head&&head.size===source.size,'MEDIA_CORRUPT','传输资源大小不一致',503);const object=await env.BUCKET.get(key,{range:{offset,length},onlyIf:{etagMatches:head.etag}});assert(object&&'body' in object&&object.etag===head.etag&&object.size===source.size,'MEDIA_CORRUPT','传输资源读取期间发生变化',503);const bytes=new Uint8Array(await object.arrayBuffer());assert(bytes.length===length,'MEDIA_CORRUPT','资源分块长度不完整',503);return bytes;
}
/** Each call performs at most two 1 MiB pushes. Every retry first reconciles the
 * signed remote offset; an unknown acknowledgement never advances local bytes. */
export async function advanceCmsBundleTransfer(env:Env,userId:string,transferId:string,runtime:Runtime={}){
 let row=await ownedTransfer(env,userId,transferId);if(row.state==='discarded')return transferView(row);
 const now=runtime.now??Date.now,at=now(),token=id('bundle_lease');if(at>=row.expires_at_ms){await env.DB.prepare("UPDATE cms_bundle_transfers SET state='expired',error_code='CMS_BUNDLE_EXPIRED',updated_at=? WHERE id=? AND state<>'discarded'").bind(new Date(at).toISOString(),row.id).run();return transferView(await ownedTransfer(env,userId,transferId));}
 const claimed=await env.DB.prepare('UPDATE cms_bundle_transfers SET lease_token=?,lease_until_ms=?,updated_at=? WHERE id=? AND (lease_until_ms IS NULL OR lease_until_ms<=?) RETURNING *').bind(token,at+150000,new Date(at).toISOString(),row.id,at).first<Transfer>();if(!claimed)return transferView(row);row=claimed;
 try{
  await authorizeTransfer(env,row,runtime);const credential=await credentials(env,row),send=runtime.send??cmsBundleRequest,meta=JSON.parse(row.metadata_json) as CmsBundleMetadata;
  const beforeMutation=async()=>{
   await authorizeTransfer(env,row,runtime);const current=await credentials(env,row);assert(current.url===credential.url&&current.keyId===credential.keyId&&current.secret===credential.secret,'CMS_CONNECTION_CHANGED','CMS 连接已变更，请继续原任务重新核对',409);
   const lease=await env.DB.prepare("SELECT 1 FROM cms_bundle_transfers WHERE id=? AND lease_token=? AND lease_until_ms>? AND state IN ('pending','transferring','sealed') AND expires_at_ms>?").bind(row.id,token,now()+25000,now()).first();assert(lease,'CMS_BUNDLE_RETRY','本轮传输已到期或被接管，请继续原任务',503);
  };
  const status=await send(credential,{operation:'bundle-status',bundleId:row.id},row.id+'_status');let remote:CmsBundleState;
  if(status.status===404){await beforeMutation();const response=await send(credential,{operation:'bundle-begin',...meta},row.id+'_begin');assert(response.status===200,'CMS_BUNDLE_UNAVAILABLE','CMS 尚未支持资源分块或暂不可用',502);remote=verifiedState(response.data,row);}
  else {assert(status.status===200,'CMS_BUNDLE_UNAVAILABLE','CMS 传输状态暂不可用',502);remote=verifiedState(status.data,row);}
  if(remote.expired||['expired','discarded'].includes(remote.state)){
   await env.DB.prepare('UPDATE cms_bundle_transfers SET state=?,progress_json=?,error_code=?,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(remote.state==='discarded'?'discarded':'expired',JSON.stringify(remote),remote.state==='discarded'?'CMS_BUNDLE_DISCARDED':'CMS_BUNDLE_EXPIRED',new Date(now()).toISOString(),row.id,token).run();return transferView(await ownedTransfer(env,userId,transferId));
  }
  const sources=JSON.parse(row.sources_json) as Source[];
  for(let n=0;n<2&&remote.state==='receiving'&&!remote.expired;n++){
   const file=remote.files.find(f=>f.received<f.size);if(!file)break;
   await authorizeTransfer(env,row,runtime);assert(now()+25000<(row.lease_until_ms??0),'CMS_BUNDLE_RETRY','本轮传输即将超时，请继续原任务',503);
   const source=sources.find(s=>s.file===file.file)!;const length=Math.min(CMS_BUNDLE_CHUNK_BYTES,file.size-file.received),bytes=await (runtime.readChunk?runtime.readChunk(source,file.received,length):sourceChunk(env,row,source,file.received,length));assert(bytes.length===length,'MEDIA_CORRUPT','资源分块长度不完整',503);
   const frame=await encodeCmsBundleChunk(row.id,file.file,file.received,bytes);await beforeMutation();const response=await send(credential,frame,row.id+'_chunk_'+sources.indexOf(source)+'_'+file.received);assert(response.status===200,'CMS_BUNDLE_PUSH_UNCERTAIN','CMS 资源分块确认待核对',502);remote=verifiedState(response.data,row);
  }
  if(remote.state==='receiving'&&!remote.expired&&remote.files.every(f=>f.received===f.size)){await beforeMutation();const response=await send(credential,{operation:'bundle-seal',bundleId:row.id},row.id+'_seal');assert(response.status===200,'CMS_BUNDLE_SEAL_UNCERTAIN','CMS 封包确认待核对',502);remote=verifiedState(response.data,row);}
  const closed=remote.expired||remote.state==='expired'||remote.state==='discarded',state=closed?(remote.state==='discarded'?'discarded':'expired'):remote.state==='sealed'?'sealed':'transferring';
  await env.DB.prepare('UPDATE cms_bundle_transfers SET state=?,progress_json=?,error_code=?,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(state,JSON.stringify(remote),closed?(state==='discarded'?'CMS_BUNDLE_DISCARDED':'CMS_BUNDLE_EXPIRED'):null,new Date(now()).toISOString(),row.id,token).run();
 }catch(error){await env.DB.prepare('UPDATE cms_bundle_transfers SET error_code=?,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(error instanceof AppError?error.code:'CMS_BUNDLE_UNCERTAIN',new Date(now()).toISOString(),row.id,token).run();}
 return transferView(await ownedTransfer(env,userId,transferId));
}
export async function cmsBundleTransferStatus(env:Env,userId:string,transferId:string){return transferView(await ownedTransfer(env,userId,transferId));}
/** Cancels staging only. A remote publication pin is authoritative and must
 * never be overridden by a local cancel request or an unknown response. */
export async function discardCmsBundleTransfer(env:Env,userId:string,transferId:string,runtime:Runtime={}){
 let row=await ownedTransfer(env,userId,transferId);if(row.state==='discarded')return transferView(row);const now=runtime.now??Date.now,at=now(),token=id('bundle_cancel');
 const claimed=await env.DB.prepare('UPDATE cms_bundle_transfers SET lease_token=?,lease_until_ms=?,updated_at=? WHERE id=? AND (lease_until_ms IS NULL OR lease_until_ms<=?) RETURNING *').bind(token,at+90000,new Date(at).toISOString(),row.id,at).first<Transfer>();if(!claimed)return transferView(row);row=claimed;
 try{
  await authorizeTransfer(env,row,runtime);const credential=await credentials(env,row),send=runtime.send??cmsBundleRequest,status=await send(credential,{operation:'bundle-status',bundleId:row.id},row.id+'_cancel_status');let remote:CmsBundleState|null=null;
  if(status.status===200){remote=verifiedState(status.data,row);assert(!remote.pinned,'CMS_BUNDLE_IN_USE','CMS 已开始处理该资源包，请先核对发布记录',409);
   if(!['expired','discarded'].includes(remote.state)){
    await authorizeTransfer(env,row,runtime);const current=await credentials(env,row);assert(current.url===credential.url&&current.keyId===credential.keyId&&current.secret===credential.secret,'CMS_CONNECTION_CHANGED','CMS 连接已变更，请继续原任务重新核对',409);
    assert(await env.DB.prepare('SELECT 1 FROM cms_bundle_transfers WHERE id=? AND lease_token=? AND lease_until_ms>?').bind(row.id,token,now()+25000).first(),'CMS_BUNDLE_RETRY','取消请求正在核对，请重试原任务',503);
    const response=await send(credential,{operation:'bundle-discard',bundleId:row.id},row.id+'_discard');assert(response.status===200,'CMS_BUNDLE_CANCEL_UNCERTAIN','CMS 取消状态待核对',502);remote=verifiedState(response.data,row);assert(['expired','discarded'].includes(remote.state)&&!remote.pinned,'CMS_BUNDLE_CANCEL_UNCERTAIN','CMS 尚未确认取消资源接收',502);
   }
  }else assert(status.status===404,'CMS_BUNDLE_CANCEL_UNCERTAIN','CMS 资源接收状态待核对',502);
  await env.DB.prepare("UPDATE cms_bundle_transfers SET state='discarded',progress_json=?,error_code=NULL,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?").bind(remote?JSON.stringify(remote):row.progress_json,new Date(now()).toISOString(),row.id,token).run();
 }catch(error){await env.DB.prepare('UPDATE cms_bundle_transfers SET error_code=?,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(error instanceof AppError?error.code:'CMS_BUNDLE_CANCEL_UNCERTAIN',new Date(now()).toISOString(),row.id,token).run();}
 return transferView(await ownedTransfer(env,userId,transferId));
}
