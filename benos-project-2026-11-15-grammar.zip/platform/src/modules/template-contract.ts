import { stripManagedFontImports } from '../contracts/design-web-fonts';
/**
 * Benos authoring preflight for AACMS 1.9.21, source commit
 * 2152113a4ef6ac07e119074dfdbf40f79647d109.
 *
 * This is a non-mutating JSON/dependency/asset-byte check, NOT an HTML sanitizer,
 * ZIP parser, image decoder, CMS import, or publication acceptance test. The
 * receiving CMS must still run SitePackageService::inspect on the actual ZIP.
 * Benos deliberately rejects dangerous/unsupported authoring data which AACMS
 * would silently strip or normalize. Codes prefixed policy_ identify that stricter
 * authoring policy. Never render untrusted HTML because this preflight passed.
 */
import { pdfVisualReferences } from '../lib/media-usage.ts';
export const TEMPLATE_CONTRACT_BASELINE = Object.freeze({
  cmsVersion: '1.9.21',
  sourceCommit: '2152113a4ef6ac07e119074dfdbf40f79647d109',
  format: 'aacms-site-package',
  version: 1,
  scope: 'manifest-and-asset-preflight',
  requiredAcceptance: [
    'actual-zip-boundary-validation',
    'target-cms-inspect-and-media-decode',
    'sanitized-html-css-review',
    'isolated-cms-import-save-publish',
    'desktop-mobile-browser-acceptance',
  ],
} as const);

export type TemplateContractIssue = {
  code: string;
  path: string;
  message: string;
  severity: 'error' | 'warning';
};

export type TemplateValidationResult = {
  valid: boolean;
  issues: TemplateContractIssue[];
};

/** Assets only; manifest.json is supplied separately as the parsed input. */
export type SiteAssetFile = {
  file: string;
  bytes: Uint8Array;
  /** A ZIP reader must inspect external attributes before supplying this flag. */
  symlink?: boolean;
};

type Obj = Record<string, unknown>;
type Report = (code: string, path: string, message: string, severity?: 'error' | 'warning') => void;
const MIB = 1_048_576;
const encoder = new TextEncoder();
const assetFile = /^assets\/[0-9]{1,2}\.(?:jpe?g|png|webp|gif|svg|pdf)$/;
const assetPath = /^\/uploads\/\d{4}\/\d{2}\/[a-f0-9]{32,64}(?:-(?:320|960))?\.(?:jpe?g|png|webp|gif|svg|pdf)$/i;
const templateTypes = ['page', 'single', 'archive', 'search', 'error404', 'section', 'header', 'footer', 'popup'];
const brandKeys = ['site_name', 'site_tagline', 'site_description', 'company_name', 'company_logo', 'favicon', 'footer_text', 'site_language'];
const themeKeys = ['brand_color', 'brand_background', 'font_family', 'container_width', 'global_css'];
const blogReserved = ['admin', 'api', 'install', 'assets', 'vendor', 'uploads', 'storage', 'config', 'scripts', 'search', 'health', 'preview', 'sitemap', 'robots', 'llms'];
const pageReserved = ['admin', 'api', 'install', 'assets', 'vendor', 'uploads', 'storage', 'config', 'scripts', 'robots.txt', 'sitemap.xml', 'search', 'health', 'favicon.ico'];
const controls = /[\x00-\x1f\x7f]/u;
const refPattern = /^[a-zA-Z0-9_-]{1,64}$/;

function object(value: unknown): value is Obj {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}
function str(value: unknown): string { return typeof value === 'string' ? value : ''; }
function length(value: string): number { return Array.from(value).length; }
function integer(value: unknown, minimum = 1, maximum = Number.MAX_SAFE_INTEGER): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= minimum && value <= maximum;
}
function jsonSize(value: unknown): number { return encoder.encode(JSON.stringify(value)).byteLength; }
function done(issues: TemplateContractIssue[]): TemplateValidationResult {
  return { valid: !issues.some((item) => item.severity === 'error'), issues };
}
function requiredText(value: unknown, max: number, path: string, report: Report): value is string {
  if (typeof value !== 'string' || !value.trim() || length(value) > max || controls.test(value)) {
    report('invalid_text', path, `需为非空文本，最多 ${max} 个字符，且不能包含控制字符。`);
    return false;
  }
  return true;
}
function keys(value: Obj, allowed: readonly string[], path: string, report: Report): void {
  for (const key of Object.keys(value)) if (!allowed.includes(key)) {
    report('policy_unsupported_field', `${path}.${key}`, '当前模板合同不支持此字段；不能用模板导入系统设置或未支持的业务数据。');
  }
}
function list(value: unknown, minimum: number, maximum: number, path: string, report: Report): unknown[] {
  if (!Array.isArray(value) || value.length < minimum || value.length > maximum) {
    report('invalid_list', path, `需为包含 ${minimum}–${maximum} 项的数组。`);
    return [];
  }
  return value;
}
function decodeText(value: string): string {
  let text = value.replace(/\\\//g, '/').replace(/&#(x[0-9a-f]+|[0-9]+);?/gi, (match, code: string) => {
    const cp = code[0].toLowerCase() === 'x' ? parseInt(code.slice(1), 16) : parseInt(code, 10);
    return cp > 0 && cp <= 0x10ffff && !(cp >= 0xd800 && cp <= 0xdfff) ? String.fromCodePoint(cp) : match;
  }).replace(/&(quot|apos|amp|sol|colon|Tab|NewLine);/gi, (_, name: string) => ({
    quot: '"', apos: "'", amp: '&', sol: '/', colon: ':', tab: '\t', newline: '\n',
  })[name.toLowerCase()] ?? '');
  // Decode malformed percent strings one byte at a time so one bad sequence
  // cannot hide a second, correctly encoded /uploads reference.
  text = text.replace(/(?:%[0-9a-f]{2})+/gi, (part) => {
    try { return decodeURIComponent(part); } catch { return part.replace(/%([0-9a-f]{2})/gi, (_, hex: string) => String.fromCharCode(parseInt(hex, 16))); }
  });
  return text.replace(/\\([0-9a-f]{1,6})\s?/gi, (match, hex: string) => {
    const cp = parseInt(hex, 16);
    return cp > 0 && cp <= 0x10ffff && !(cp >= 0xd800 && cp <= 0xdfff) ? String.fromCodePoint(cp) : match;
  });
}

/** Validate plain JSON before recursively inspecting untrusted input. */
function jsonBoundary(input: unknown, report: Report): boolean {
  const stack = new WeakSet<object>();
  let valid = true;
  let nodes = 0;
  const visit = (value: unknown, path: string, depth: number): void => {
    if (!valid) return;
    if (depth >= 128 || ++nodes > 250_000) {
      report('json_complexity', path, '清单层级或节点数量超限。'); valid = false; return;
    }
    if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
    if (typeof value === 'number' && Number.isFinite(value)) return;
    if (!Array.isArray(value) && !object(value)) {
      report('invalid_json', path, '只接受 JSON 对象、数组、有限数字、字符串、布尔值或 null。'); valid = false; return;
    }
    if (stack.has(value)) { report('invalid_json', path, '清单不能包含循环引用。'); valid = false; return; }
    stack.add(value);
    for (const [key, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(value))) {
      if (Array.isArray(value) && key === 'length') continue;
      if (!('value' in descriptor) || !descriptor.enumerable || ['__proto__', 'constructor', 'prototype'].includes(key)) {
        report('invalid_json', `${path}.${key}`, '清单不能包含访问器或原型修改字段。'); valid = false; break;
      }
      visit(descriptor.value, `${path}.${key}`, depth + 1);
    }
    stack.delete(value);
  };
  visit(input, '$', 0);
  return valid;
}

function walk(value: unknown, fn: (value: unknown, path: string, key: string) => void, path: string, key = ''): void {
  fn(value, path, key);
  if (Array.isArray(value)) value.forEach((item, i) => walk(item, fn, `${path}[${i}]`, String(i)));
  else if (object(value)) for (const [name, item] of Object.entries(value)) walk(item, fn, `${path}.${name}`, name);
}

function authoringSafety(input: unknown, report: Report, embeddedDepth = 0): void {
  walk(input, (value, path, key) => {
    // FormService defaults include blank webhook_secret. Blank values carry no
    // credential and are permitted; any nonblank secret is rejected without echo.
    if (/(?:^|_)(?:password|passwd|api_?key|secret|private_?key|access_?token|refresh_?token|smtp|database|db_password)(?:_|$)/i.test(key)
      && value !== '' && value !== null && value !== false) {
      report('policy_sensitive_data', path, '模板不能包含账号凭据、邮件配置、数据库配置或 API 密钥。');
    }
    if (typeof value !== 'string') return;
    if (/^\s*[{[]/.test(value)) {
      try {
        const embedded: unknown = JSON.parse(value);
        if (object(embedded) || Array.isArray(embedded)) {
          const nestedReport: Report = (code, nestedPath, message, severity) => report(code, `${path}<json>${nestedPath.slice(1)}`, message, severity);
          if (embeddedDepth >= 4) nestedReport('json_complexity', '$', '编辑器中的嵌套 JSON 字符串层级超限。');
          else if (jsonBoundary(embedded, nestedReport)) authoringSafety(embedded, nestedReport, embeddedDepth + 1);
        }
      } catch { /* Ordinary text is scanned below. */ }
    }
    const text = decodeText(value);
    if (/-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----|\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}/.test(text)) {
      report('policy_sensitive_data', path, '检测到疑似密钥；请移除后重新提交。');
    }
    if (/<\?(?:php|=)|<%[=@]|<\s*script\b|\bon[a-z]+\s*=\s*["']?/i.test(text)
      || /(?:javascript|vbscript)\s*:/i.test(text.replace(/[\x00-\x20\x7f]/g, ''))
      || /\bdata\s*:\s*(?:text\/html|image\/svg\+xml|application\/(?:javascript|xhtml\+xml))/i.test(text)
      // `behavior:` is the legacy script-binding property; scroll-behavior / overscroll-behavior are ordinary CSS.
      || /expression\s*\(|-moz-binding\s*:|(?<![\w-])behavior\s*:/i.test(text)) {
      report('policy_script', path, '模板不能携带执行脚本、内联事件或主动执行 URL。');
    }
    if (/(?:https?:)?\/\/(?:localhost|127(?:\.\d{1,3}){3}|\[?::1\]?)(?=[:/\s"']|$)|\bfile:\/\/|\b[A-Z]:[\\/]/i.test(text)) {
      report('policy_local_reference', path, '不能引用本机、开发磁盘或本地预览地址。');
    }
    if (/^(?:script|script-export|scripts)$/i.test(key) && value.trim()) {
      report('policy_script', path, '编辑器 project 也不能携带脚本。');
    }
    if (/^(?:html|content)$/i.test(key) && /<\s*\/?\s*(?:html|head|body|style|object|embed|applet|base|link|meta|form|textarea|select|option|svg|math|noscript|template)\b/i.test(text)) {
      report('policy_unsupported_html', path, '使用 CMS 原生组件和 HTML 片段；这些标签会被目标渲染器移除或不受模板合同支持。');
    }
    if (/^(?:css|customCss|global_css)$/i.test(key) && /@(?:import|font-face)\b/i.test(stripManagedFontImports(text))) {
      report('policy_unsupported_css', path, '模板不支持 @import 或 @font-face；字体需由系统单独提供。');
    }
  }, '$');
}

type References = { template: Set<number>; menu: Set<number>; form: Set<string>; media: Set<number>; paths: Set<string> };
function references(value: unknown, path: string, report: Report): References {
  const refs: References = { template: new Set(), menu: new Set(), form: new Set(), media: new Set(), paths: new Set() };
  const add = (kind: string, raw: unknown, at: string): void => {
    const text = typeof raw === 'number' ? String(raw) : decodeText(str(raw));
    if (kind === 'form') {
      if (!refPattern.test(text) || text === '0') report('invalid_reference', at, '表单引用必须是非零的 1–64 位字母数字标识。');
      else refs.form.add(text);
    } else {
      if (!/^[1-9][0-9]*$/.test(text) || !Number.isSafeInteger(Number(text))) report('invalid_reference', at, '组件和媒体引用必须是正整数。');
      else refs[kind as 'template' | 'menu' | 'media'].add(Number(text));
    }
  };
  const read = (item: unknown, at: string, key: string): void => {
    const keyLower = key.toLowerCase();
    if (keyLower === 'data-template') add('template', item, at);
    if (keyLower === 'data-form') add('form', item, at);
    if (keyLower === 'data-aacms-menu') add('menu', item, at);
    if (/(?:media|asset|image)_?id$/i.test(key) || ['data-media-id', 'data-asset-id'].includes(keyLower)) add('media', item, at);
    if (typeof item !== 'string') return;
    // Editor project data can itself contain serialized JSON.
    if (/^\s*[{[]/.test(item)) {
      try {
        const nested: unknown = JSON.parse(item);
        if (nested && (Array.isArray(nested) || object(nested))) {
          // Do not recursively decode JSON strings without a bound.
          walk(nested, (part, nestedPath, nestedKey) => {
            if (typeof part === 'string') scan(part, nestedPath);
            const normalized = nestedKey.toLowerCase();
            if (normalized === 'data-template') add('template', part, nestedPath);
            if (normalized === 'data-form') add('form', part, nestedPath);
            if (normalized === 'data-aacms-menu') add('menu', part, nestedPath);
            if (/(?:media|asset|image)_?id$/i.test(nestedKey) || ['data-media-id', 'data-asset-id'].includes(normalized)) add('media', part, nestedPath);
          }, `${at}<json>`);
        }
      } catch { /* Not embedded JSON; ordinary text is still scanned below. */ }
    }
    scan(item, at);
  };
  const scan = (item: string, at: string): void => {
    const text = decodeText(item);
    const attributes = /(?:^|[\s<])data-(template|form|aacms-menu|media-id|asset-id)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/gi;
    for (const match of text.matchAll(attributes)) {
      const kind = match[1].toLowerCase();
      add(kind === 'aacms-menu' ? 'menu' : kind.endsWith('-id') ? 'media' : kind, match[2] ?? match[3] ?? match[4], at);
    }
    // Require portable media even when a source host was included. The target
    // CMS sees its own host, so its inspector alone cannot prove source portability.
    for (const match of text.matchAll(/\/uploads\/[^\s"'<>?#),]+/gi)) refs.paths.add(match[0]);
  };
  walk(value, read, path);
  return refs;
}

function safeMenuUrl(value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const url = value.trim();
  const decoded = decodeText(url);
  if (!url || encoder.encode(url).byteLength > 2048 || /[\s\x00-\x1f\x7f<>"'\\]/.test(url) || /[\x00-\x1f\x7f\\]/.test(decoded)) return false;
  if (url.startsWith('#')) return true;
  if (url.startsWith('/')) return !url.startsWith('//') && !decoded.startsWith('//');
  if (/^https?:\/\//i.test(url)) {
    try { const parsed = new URL(url); return Boolean(parsed.hostname) && !parsed.username && !parsed.password; } catch { return false; }
  }
  if (/^mailto:/i.test(url)) return /^mailto:[^\s@?]+@[^\s@?]+\.[^\s@?]+(?:\?.*)?$/i.test(decoded);
  return /^tel:\+?[0-9().-]{2,40}$/i.test(url);
}

function validateMenu(menu: Obj, at: string, report: Report): void {
  requiredText(menu.name, 190, `${at}.name`, report);
  const items = list(menu.items, 0, 100, `${at}.items`, report);
  const parents = new Map<string, string | null>();
  items.forEach((item, index) => {
    const path = `${at}.items[${index}]`;
    if (!object(item)) { report('invalid_menu', path, '菜单项必须是对象。'); return; }
    if (!refPattern.test(str(item.id)) || parents.has(str(item.id))) report('invalid_menu_id', `${path}.id`, '菜单项标识无效或重复。');
    requiredText(item.label, 190, `${path}.label`, report);
    if (item.type !== 'custom' || (item.page_id !== null && item.page_id !== undefined)) report('menu_source_page', path, '可移植菜单必须使用 custom URL，不能保留源站页面编号。');
    if (!safeMenuUrl(item.url)) report('invalid_menu_url', `${path}.url`, '菜单 URL 不是支持的相对路径、HTTP(S)、锚点、邮箱或电话。');
    const parent = item.parent_id === '' || item.parent_id === undefined ? null : item.parent_id;
    if (parent !== null && !refPattern.test(str(parent))) report('invalid_menu_parent', `${path}.parent_id`, '父菜单标识无效。');
    parents.set(str(item.id), parent === null ? null : str(parent));
    if (item.target !== undefined && !['_self', '_blank'].includes(str(item.target))) report('invalid_menu_target', `${path}.target`, '菜单打开方式仅支持 _self / _blank。');
    if (item.rel !== undefined && (typeof item.rel !== 'string' || item.rel.length > 120 || item.rel.trim().toLowerCase().split(/\s+/).filter(Boolean).some((token) => !['nofollow', 'sponsored', 'ugc', 'noopener', 'noreferrer'].includes(token)))) report('invalid_menu_rel', `${path}.rel`, '菜单 rel 值不受支持。');
    if (item.children !== undefined) report('policy_unsupported_field', `${path}.children`, '菜单使用平铺数组和 parent_id，不能嵌套 children。');
  });
  for (const [id, parent] of parents) {
    const seen = new Set([id]);
    let current = parent;
    while (current !== null) {
      if (!parents.has(current)) { report('menu_parent_missing', at, '菜单父项目不存在。'); break; }
      if (seen.has(current)) { report('menu_cycle', at, '菜单层级不能循环。'); break; }
      seen.add(current);
      if (seen.size > 3) { report('menu_depth', at, '菜单最多支持 3 级。'); break; }
      current = parents.get(current) ?? null;
    }
  }
}

function validateFormDefinition(definition: Obj, at: string, report: Report): void {
  if (definition.schema_version !== undefined && definition.schema_version !== 1) report('form_version', `${at}.schema_version`, '表单 schema_version 必须是整数 1。');
  const fields = list(definition.fields, 1, 80, `${at}.fields`, report);
  const prior = new Map<string, number>();
  fields.forEach((field, index) => {
    const path = `${at}.fields[${index}]`;
    if (!object(field)) { report('invalid_form_field', path, '字段必须是对象。'); return; }
    const id = str(field.id), type = field.type ?? 'text';
    if (!/^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/.test(id) || prior.has(id)) report('form_field_id', `${path}.id`, '表单字段 ID 必须唯一并以英文字母开头。');
    if (!['text', 'textarea', 'email', 'tel', 'number', 'url', 'date', 'select', 'radio', 'checkbox', 'file', 'hidden', 'consent', 'heading'].includes(str(type))) report('form_field_type', `${path}.type`, '表单字段类型不受支持。');
    requiredText(field.label, 200, `${path}.label`, report);
    const step = field.step ?? 1;
    if (!integer(step, 1, 10)) report('policy_form_step', `${path}.step`, '表单步骤须在 1–10 内。');
    if (['select', 'radio', 'checkbox'].includes(str(type))) {
      const options = typeof field.options === 'string' ? field.options.split(/\r?\n/) : field.options;
      const entries = list(options, 1, 100, `${path}.options`, report);
      if (!entries.some((entry) => str(object(entry) ? entry.value ?? entry.label : entry).trim())) report('form_options', `${path}.options`, '选择字段至少需要一个有效选项。');
    }
    if (type === 'number' && field.min !== undefined && field.max !== undefined && Number(field.min) > Number(field.max)) report('form_bounds', path, '最小值不能大于最大值。');
    if (type === 'file' && field.accept !== undefined && (!str(field.accept).split(',').some((ext) => ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'txt', 'csv', 'docx', 'xlsx', 'pptx', 'zip', 'dwg', 'dxf', 'step', 'stp', 'igs', 'iges'].includes(ext.trim().toLowerCase())))) report('form_file_types', `${path}.accept`, '表单文件字段没有支持的文件类型。');
    if (object(field.condition) && field.condition.field) {
      const target = str(field.condition.field);
      if (!prior.has(target) || (prior.get(target) ?? 0) > Number(step)) report('form_condition_reference', `${path}.condition`, '条件只能引用前面且不在后续步骤的字段。');
      if (!['eq', 'neq', 'contains', 'not_empty', 'empty'].includes(str(field.condition.operator ?? 'eq'))) report('form_condition_operator', `${path}.condition.operator`, '条件运算符不受支持。');
    }
    prior.set(id, Number(step));
  });
  if (definition.settings !== undefined && !object(definition.settings)) report('form_settings', `${at}.settings`, '表单设置必须是对象。');
  if (object(definition.settings)) {
    for (const key of ['notify_emails', 'webhook_url', 'webhook_secret', 'redirect_url']) {
      if (definition.settings[key] !== undefined && definition.settings[key] !== '') report('policy_form_destination', `${at}.settings.${key}`, '随包表单的通知、Webhook 和跳转配置必须留空，由接收站自行配置。');
    }
    for (const key of ['auto_reply', 'captcha_enabled']) {
      if (definition.settings[key] !== undefined && definition.settings[key] !== false) report('policy_form_activation', `${at}.settings.${key}`, '随包表单不能预先开启自动回复或验证码。');
    }
  }
}

/** Validate a parsed manifest without mutation, I/O or network access. */
export function validateSiteManifest(input: unknown): TemplateValidationResult {
  const issues: TemplateContractIssue[] = [];
  const report: Report = (code, path, message, severity = 'error') => { if (issues.length < 200) issues.push({ code, path, message, severity }); };
  if (!jsonBoundary(input, report)) return done(issues);
  if (!object(input)) { report('manifest_object', '$', '网站清单必须是 JSON 对象。'); return done(issues); }
  if (jsonSize(input) > 10 * MIB) { report('manifest_size', '$', 'manifest.json 最多 10 MiB。'); return done(issues); }
  authoringSafety(input, report);
  for(const path of pdfVisualReferences(input))report('policy_pdf_visual_reference',path,'PDF 只能用作下载链接，不能用于图片、背景、标志或头像。');
  keys(input, ['format', 'version', 'created_at', 'source_url', 'root_id', 'templates', 'assets', 'forms', 'menus', 'site'], '$', report);
  if (input.format !== 'aacms-site-package') report('manifest_format', '$.format', '必须是 aacms-site-package 完整网站模板。');
  if (input.version !== 1) report('manifest_version', '$.version', '清单 version 必须是整数 1。');
  const templates = new Map<number, Obj>();
  const dependencyRefs: Array<{ path: string; refs: References }> = [];
  list(input.templates, 1, 72, '$.templates', report).forEach((template, index) => {
    const path = `$.templates[${index}]`;
    if (!object(template)) { report('invalid_template', path, '模板必须是对象。'); return; }
    if (!integer(template.id) || templates.has(template.id)) report('template_id', `${path}.id`, '模板 ID 必须是唯一正整数。');
    else templates.set(template.id, template);
    requiredText(template.name, 190, `${path}.name`, report);
    if (!templateTypes.includes(str(template.type))) report('template_type', `${path}.type`, '模板类型不受 AACMS 1.9.21 支持。');
    if (!object(template.document)) report('template_document', `${path}.document`, 'document 必须是对象。');
    else {
      const doc = template.document;
      if (doc.version !== undefined && doc.version !== 1 && doc.version !== '1') report('document_version', `${path}.document.version`, '页面文档版本仅支持 1。');
      if (jsonSize(doc) > 8 * MIB) report('document_size', `${path}.document`, '单模板 document JSON 最多 8 MiB。');
      for (const key of ['html', 'css', 'customCss']) if (doc[key] !== undefined && typeof doc[key] !== 'string') report('document_field', `${path}.document.${key}`, 'HTML / CSS 字段必须是字符串。');
      dependencyRefs.push({ path: `${path}.document`, refs: references(doc, `${path}.document`, report) });
    }
  });
  if (!integer(input.root_id) || !templates.has(input.root_id)) report('root_template', '$.root_id', 'root_id 必须引用包内模板。');
  const paths = new Set<string>(), mediaIds = new Set<number>(), assetFiles = new Set<string>();
  const assetsByPath = new Map<string, Obj>();
  let declaredBytes = 0;
  list(input.assets, 0, 64, '$.assets', report).forEach((asset, index) => {
    const path = `$.assets[${index}]`;
    if (!object(asset)) { report('invalid_asset', path, '媒体条目必须是对象。'); return; }
    if (!assetFile.test(str(asset.file)) || assetFiles.has(str(asset.file))) report('asset_file', `${path}.file`, '媒体 file 必须为唯一的 assets/一至两位数字.允许扩展名。');
    assetFiles.add(str(asset.file));
    if (!assetPath.test(str(asset.path)) || paths.has(str(asset.path))) report('asset_path', `${path}.path`, '媒体逻辑路径无效或重复。');
    paths.add(str(asset.path)); assetsByPath.set(str(asset.path), asset);
    if (!/^[a-f0-9]{64}$/.test(str(asset.sha256))) report('asset_sha256', `${path}.sha256`, 'SHA256 必须是 64 位小写十六进制摘要。');
    if (!integer(asset.size, 1, 12 * MIB)) report('asset_size', `${path}.size`, '单媒体字节数必须为 1–12 MiB 的整数。');
    else declaredBytes += asset.size;
    if (asset.media_id !== undefined && asset.media_id !== null && asset.media_id !== 0) {
      if (!integer(asset.media_id) || mediaIds.has(asset.media_id)) report('asset_media_id', `${path}.media_id`, '非空媒体 ID 必须是唯一正整数。');
      else mediaIds.add(asset.media_id);
    }
  });
  if (declaredBytes + jsonSize(input) > 74 * MIB) report('package_size', '$.assets', '清单和媒体声明总量超过 74 MiB。');
  const formIds = new Set<string>();
  list(input.forms, 0, 10, '$.forms', report).forEach((form, index) => {
    const ref = object(form) ? String(form.ref ?? form.id ?? '') : '';
    if (!object(form) || !refPattern.test(ref) || ref === '0' || formIds.has(ref)) report('form_ref', `$.forms[${index}]`, '表单引用清单标识无效或重复。');
    else formIds.add(ref);
  });
  const menus = new Set<number>();
  list(input.menus ?? [], 0, 100, '$.menus', report).forEach((menu, index) => {
    const path = `$.menus[${index}]`;
    if (!object(menu)) { report('invalid_menu', path, '菜单必须是对象。'); return; }
    if (!integer(menu.id) || menus.has(menu.id)) report('menu_id', `${path}.id`, '菜单 ID 必须是唯一正整数。');
    else menus.add(menu.id);
    validateMenu(menu, path, report);
  });
  if (!object(input.site)) { report('site_object', '$.site', '完整网站包必须包含 site 对象。'); return done(issues); }
  const site = input.site;
  keys(site, ['name', 'slug', 'version', 'description', 'home', 'header_template_id', 'footer_template_id', 'navigation_menu_id', 'pages', 'blog', 'theme', 'settings', 'author', 'forms', 'preview'], '$.site', report);
  requiredText(site.name, 190, '$.site.name', report);
  if (!/^[a-z0-9][a-z0-9-]{1,99}$/.test(str(site.slug))) report('site_slug', '$.site.slug', '网站模板标识需为 2–100 位小写字母数字和短横线。');
  requiredText(site.version ?? '1.0.0', 40, '$.site.version', report);
  for (const [key, type] of [['header_template_id', 'header'], ['footer_template_id', 'footer']]) {
    if (!integer(site[key]) || templates.get(site[key] as number)?.type !== type) report('site_shell_reference', `$.site.${key}`, `必须引用包内的 ${type} 类型模板。`);
  }
  if (!integer(site.navigation_menu_id) || !menus.has(site.navigation_menu_id)) report('site_menu_reference', '$.site.navigation_menu_id', '主导航必须引用包内菜单。');
  const blog = site.blog;
  let blogBase = 'blog';
  if (blog !== undefined && blog !== null) {
    if (!object(blog)) report('blog_object', '$.site.blog', '博客模块必须是对象。');
    else {
      keys(blog, ['enabled', 'title', 'description', 'page_size', 'base_path', 'language', 'archive_template_id', 'single_template_id'], '$.site.blog', report);
      if (blog.enabled !== undefined && typeof blog.enabled !== 'boolean') report('blog_enabled', '$.site.blog.enabled', '博客开关必须为布尔值。');
      if (blog.base_path !== undefined) {
        blogBase = str(blog.base_path).trim();
        if (!/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/.test(blogBase) || blogBase.length > 80 || blogReserved.includes(blogBase)) report('blog_base_path', '$.site.blog.base_path', '博客路径必须是 1–80 位非保留的小写单段路径。');
      }
      if (blog.language !== undefined && !['en', 'zh-CN'].includes(str(blog.language))) report('blog_language', '$.site.blog.language', '博客语言仅支持 en / zh-CN。');
      if (blog.page_size !== undefined && !integer(blog.page_size, 3, 24)) report('blog_page_size', '$.site.blog.page_size', '博客每页文章数必须为 3–24。');
      if (blog.title !== undefined) requiredText(blog.title, 255, '$.site.blog.title', report);
      if (blog.description !== undefined && (typeof blog.description !== 'string' || length(blog.description) > 4000 || controls.test(blog.description))) report('blog_description', '$.site.blog.description', '博客介绍格式无效。');
      for (const [key, type] of [['archive_template_id', 'archive'], ['single_template_id', 'single']]) {
        const template = templates.get(blog[key] as number);
        if (!integer(blog[key]) || template?.type !== type) report('blog_template_reference', `$.site.blog.${key}`, `必须引用包内 ${type} 模板。`);
        else if (!object(template.document) || !/data-aacms\s*=\s*(["'])page-content\1/.test(str(template.document.html))) report('blog_content_slot', `$.site.blog.${key}`, '博客外壳必须包含 data-aacms="page-content" 原生内容插槽。');
      }
    }
  }
  const pageKeys = new Set<string>(), slugs = new Set<string>();
  const pages = list(site.pages, 2, 64, '$.site.pages', report);
  pages.forEach((page, index) => {
    const path = `$.site.pages[${index}]`;
    if (!object(page)) { report('page_object', path, '页面必须是对象。'); return; }
    keys(page, ['key', 'title', 'slug', 'type', 'template_id', 'seo', 'excerpt', 'blog', 'featured_image'], path, report);
    if (!/^[a-z][a-z0-9_-]{0,63}$/.test(str(page.key)) || pageKeys.has(str(page.key))) report('page_key', `${path}.key`, '页面 key 无效或重复。');
    pageKeys.add(str(page.key));
    requiredText(page.title, 255, `${path}.title`, report);
    requiredText(page.slug, 180, `${path}.slug`, report);
    const slug = str(page.slug).trim().replace(/^\/+|\/+$/g, '').toLowerCase().replace(/\s+/gu, '-');
    if (!/^[\p{L}\p{N}][\p{L}\p{N}/_-]*$/u.test(slug) || slug.includes('//') || pageReserved.includes(slug.split('/')[0]) || slug === 'blog' || slugs.has(slug)) report('page_slug', `${path}.slug`, '页面网址无效、重复或占用系统保留路径。');
    slugs.add(slug);
    if (/^blog\/(?:category|tag|author|feed\.xml)(?:\/|$)/.test(slug)
      || (object(blog) && (slug === blogBase || (slug.startsWith(`${blogBase}/`) && /^(?:category|tag|author|feed\.xml)(?:\/|$)/.test(slug.slice(blogBase.length + 1)))))) report('page_blog_path', `${path}.slug`, '页面不能占用博客根目录、分类、标签、作者或 feed 系统目录。');
    const type = page.type ?? 'page';
    if (type !== 'page' && type !== 'article') report('page_type', `${path}.type`, '整站页面 type 只能为 page 或 article。');
    if (!integer(page.template_id) || templates.get(page.template_id)?.type !== 'page') report('page_template_reference', `${path}.template_id`, '页面和种子文章正文都必须引用 page 类型模板。');
    if (page.key === site.home && type !== 'page') report('home_page_type', `${path}.type`, '首页必须是普通页面。');
    const seo = page.seo ?? {};
    if (!object(seo) || jsonSize(seo) > 100_000) report('page_seo', `${path}.seo`, 'SEO 必须是最多 100,000 字节的对象。');
    else {
      for (const [key, value] of Object.entries(seo)) {
        const scalar = (item: unknown) => item === null || ['string', 'boolean', 'number'].includes(typeof item);
        if (!scalar(value) && !(key === 'robots' && Array.isArray(value) && value.every(scalar))) report('page_seo_field', `${path}.seo.${key}`, 'SEO 只接受标量或 null，robots 可使用简单数组。');
        if (typeof value === 'string' && length(value) > 10_000) report('page_seo_field', `${path}.seo.${key}`, '单个 SEO 文本最多 10,000 字符。');
        if (['canonical', 'og_url', 'url'].includes(key) && value) report('source_seo_url', `${path}.seo.${key}`, '接收站会清空源站 URL 并重新生成。', 'warning');
      }
      dependencyRefs.push({ path: `${path}.seo`, refs: references(seo, `${path}.seo`, report) });
    }
    if (type === 'article') {
      if (!object(blog) || blog.enabled === false) report('article_blog_required', path, '种子文章需要启用原生博客。');
      const article = page.blog ?? {};
      if (!object(article)) report('article_metadata', `${path}.blog`, '种子文章资料必须是对象。');
      else {
        keys(article, ['published_at', 'featured'], `${path}.blog`, report);
        if (article.featured !== undefined && typeof article.featured !== 'boolean') report('article_featured', `${path}.blog.featured`, '精选状态必须是布尔值。');
        if (article.published_at !== undefined) {
          const date = str(article.published_at), parsed = new Date(`${date.replace(' ', 'T')}Z`);
          if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(date) || Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 19).replace('T', ' ') !== date) report('article_date', `${path}.blog.published_at`, '文章日期必须是有效 UTC YYYY-MM-DD HH:MM:SS。');
        }
      }
      if (page.featured_image !== undefined && (typeof page.featured_image !== 'string' || (page.featured_image !== '' && !paths.has(page.featured_image)))) report('article_image', `${path}.featured_image`, '文章封面必须引用包内媒体 path。');
    } else if (page.blog !== undefined || page.featured_image !== undefined) report('page_article_metadata', path, '只有 article 可携带 blog / featured_image。');
  });
  if (!pageKeys.has(str(site.home))) report('site_home', '$.site.home', '首页必须引用有效的 page key。');
  const theme = site.theme ?? {};
  if (!object(theme)) report('theme_object', '$.site.theme', '主题必须是对象。');
  else {
    keys(theme, themeKeys, '$.site.theme', report);
    for (const key of ['brand_color', 'brand_background']) if (theme[key] !== undefined && !/^#[a-f0-9]{6}$/i.test(str(theme[key]))) report('theme_color', `$.site.theme.${key}`, '主题颜色必须为六位 HEX。');
    if (theme.font_family !== undefined && !['system', 'serif', 'sans-serif'].includes(str(theme.font_family))) report('theme_font', '$.site.theme.font_family', '主题字体仅支持 system / serif / sans-serif。');
    if (theme.container_width !== undefined && !integer(theme.container_width, 720, 1800)) report('theme_width', '$.site.theme.container_width', '主题宽度必须为 720–1800px。');
    if (theme.global_css !== undefined && (typeof theme.global_css !== 'string' || encoder.encode(theme.global_css).byteLength > 100_000)) report('theme_css', '$.site.theme.global_css', '主题 CSS 必须是最多 100,000 字节的字符串。');
    dependencyRefs.push({ path: '$.site.theme', refs: references(theme, '$.site.theme', report) });
  }
  const settings = site.settings ?? {};
  if (!object(settings)) report('settings_object', '$.site.settings', '品牌设置必须是对象。');
  else {
    keys(settings, brandKeys, '$.site.settings', report);
    for (const [key, value] of Object.entries(settings)) {
      if (typeof value !== 'string' || length(value) > (key === 'site_description' ? 4000 : 2000)) report('brand_value', `$.site.settings.${key}`, '品牌设置文本超限或格式无效。');
      if (['company_logo', 'favicon'].includes(key) && value !== '' && !paths.has(str(value))) report('brand_image', `$.site.settings.${key}`, '品牌图片必须引用包内媒体 path。');
    }
    if (settings.site_language !== undefined && !['en', 'zh-CN'].includes(str(settings.site_language))) report('brand_language', '$.site.settings.site_language', '网站语言仅支持 en / zh-CN。');
  }
  if (site.author !== undefined && site.author !== null) {
    if (!object(site.author)) report('author_object', '$.site.author', '作者档案必须是对象。');
    else {
      const author = site.author;
      keys(author, ['slug', 'name', 'kind', 'title', 'brief', 'bio', 'avatar'], '$.site.author', report);
      if (!/^[a-z0-9][a-z0-9-]{0,159}$/.test(str(author.slug))) report('author_slug', '$.site.author.slug', '编辑部 slug 无效。');
      requiredText(author.name, 120, '$.site.author.name', report);
      if (author.kind !== undefined && author.kind !== 'organization') report('author_kind', '$.site.author.kind', '模板作者只能是公开编辑部 organization，不是登录账号。');
      for (const [key, limit] of Object.entries({ name: 120, title: 160, brief: 500, bio: 12000 })) if (author[key] !== undefined && (typeof author[key] !== 'string' || length(author[key]) > limit || /<[^>]*>|[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(author[key]))) report('author_text', `$.site.author.${key}`, '编辑部名称和介绍必须是规定长度内的纯文本。');
      const avatar = assetsByPath.get(str(author.avatar));
      if (!avatar || !/\.(?:jpe?g|png|webp|gif)$/i.test(str(avatar.file))) report('author_avatar', '$.site.author.avatar', '作者头像必须是随包提供的位图。');
    }
  }
  list(site.preview ?? [], 0, 64, '$.site.preview', report).forEach((path, index) => { if (!paths.has(str(path))) report('preview_image', `$.site.preview[${index}]`, '预览图必须引用包内媒体 path。'); });
  const definedForms = new Set<string>();
  list(site.forms ?? [], 0, 10, '$.site.forms', report).forEach((form, index) => {
    const path = `$.site.forms[${index}]`;
    if (!object(form)) { report('form_definition', path, '表单定义必须是对象。'); return; }
    const ref = str(form.ref);
    if (!formIds.has(ref) || definedForms.has(ref)) report('form_definition_ref', `${path}.ref`, '表单定义 ref 必须逐一对应顶层 forms。');
    definedForms.add(ref);
    requiredText(form.name, 180, `${path}.name`, report);
    if (!object(form.definition)) report('form_definition', `${path}.definition`, '缺少可独立部署的表单定义。');
    else validateFormDefinition(form.definition, `${path}.definition`, report);
  });
  for (const id of formIds) if (!definedForms.has(id)) report('form_definition_missing', '$.site.forms', '模板缺少已声明表单的完整定义。');
  const usedMenus = new Set<number>();
  for (const { path, refs } of dependencyRefs) {
    for (const id of refs.template) if (!templates.has(id)) report('template_reference_missing', path, '关联模板未随包声明。');
    for (const id of refs.menu) { if (path.startsWith('$.templates[')) usedMenus.add(id); if (!menus.has(id)) report('menu_reference_missing', path, '引用的菜单未随包声明。'); }
    for (const id of refs.form) if (!formIds.has(id)) report('form_reference_missing', path, '引用的表单未随包声明。');
    for (const id of refs.media) if (!mediaIds.has(id)) report('media_reference_missing', path, '引用的媒体 ID 未随包声明。');
    for (const localPath of refs.paths) if (!paths.has(localPath)) report('asset_reference_missing', path, 'HTML、CSS、编辑器或 SEO 引用了未声明的上传媒体。');
  }
  for (const id of menus) if (!usedMenus.has(id)) report('menu_unreferenced', '$.menus', '声明的菜单也必须被模板引用。');
  return done(issues);
}

/**
 * Checks exact asset inventory, byte length and SHA256 with WebCrypto.
 * Basic signatures/active-content checks are defense in depth, not MIME proof or
 * image decoding. Accepts already bounded, safely read asset entries, NOT a ZIP.
 * The ZIP reader must independently reject duplicate names, symlinks, compression
 * bombs, oversized raw manifest bytes, and entries other than the supplied files.
 */
export async function validateSiteAssets(input: unknown, files: readonly SiteAssetFile[]): Promise<TemplateValidationResult> {
  const result = validateSiteManifest(input);
  if (!result.valid || !object(input) || !Array.isArray(input.assets)) return result;
  const report: Report = (code, path, message, severity = 'error') => { if (result.issues.length < 200) result.issues.push({ code, path, message, severity }); };
  if (!Array.isArray(files) || files.length > 64) { report('asset_inventory', '$files', '实际媒体最多 64 项。'); return done(result.issues); }
  const byName = new Map<string, SiteAssetFile>();
  let total = jsonSize(input);
  for (const [index, file] of files.entries()) {
    const path = `$files[${index}]`;
    if (!file || !assetFile.test(file.file) || !(file.bytes instanceof Uint8Array)) { report('asset_inventory', path, '实际资产路径或字节格式无效。'); continue; }
    if (file.symlink) report('asset_symlink', path, '不允许符号链接。');
    if (byName.has(file.file)) report('asset_duplicate', path, '实际资产文件不能重复。');
    byName.set(file.file, file);
    total += file.bytes.byteLength;
    if (!file.bytes.byteLength || file.bytes.byteLength > 12 * MIB) report('asset_actual_size', path, '实际资产需为 1–12 MiB。');
  }
  if (total > 74 * MIB) report('package_actual_size', '$files', '实际清单和媒体总量超过 74 MiB。');
  const declared = new Set(input.assets.filter(object).map((asset) => str(asset.file)));
  for (const name of byName.keys()) if (!declared.has(name)) report('asset_undeclared', '$files', '实际文件未在清单声明。');
  for (const [index, asset] of input.assets.entries()) {
    if (!object(asset)) continue;
    const path = `$.assets[${index}]`, file = byName.get(str(asset.file));
    if (!file) { report('asset_missing', path, '清单媒体缺少实际文件。'); continue; }
    if (file.bytes.byteLength !== asset.size) report('asset_length_mismatch', `${path}.size`, '声明 size 与实际字节数不一致。');
    if (file.bytes.byteLength > 12 * MIB) continue;
    // Copy just this view; do not accidentally hash unrelated buffer bytes.
    const digest = await crypto.subtle.digest('SHA-256', new Uint8Array(file.bytes));
    const sha256 = Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, '0')).join('');
    if (sha256 !== asset.sha256) report('asset_hash_mismatch', `${path}.sha256`, 'SHA256 与实际字节不一致。');
    checkMediaBytes(file, path, report);
  }
  return done(result.issues);
}

function checkMediaBytes(file: SiteAssetFile, path: string, report: Report): void {
  const bytes = file.bytes;
  const extension = file.file.split('.').pop() ?? '';
  const ascii = (start: number, end: number) => String.fromCharCode(...bytes.subarray(start, end));
  const prefix = ascii(0, Math.min(bytes.length, 32));
  let signature = true;
  if (extension === 'png') signature = bytes.length >= 24 && ascii(0, 8) === '\x89PNG\r\n\x1a\n' && ascii(12, 16) === 'IHDR';
  if (extension === 'jpg' || extension === 'jpeg') signature = bytes.length >= 4 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  if (extension === 'gif') signature = bytes.length >= 10 && /^GIF8[79]a/.test(prefix);
  if (extension === 'webp') signature = bytes.length >= 20 && prefix.startsWith('RIFF') && prefix.slice(8, 12) === 'WEBP';
  if (extension === 'pdf') signature = prefix.startsWith('%PDF-') && new TextDecoder().decode(bytes.subarray(Math.max(0, bytes.length - 2048))).includes('%%EOF');
  if (extension === 'svg') {
    const text = new TextDecoder().decode(bytes);
    signature = /<svg(?:\s|>)/i.test(text);
    if (bytes.length > MIB) report('svg_size', path, 'SVG 最多 1 MiB。');
    if (/<\s*(?:script|foreignObject|iframe|object|embed)\b|\bon\w+\s*=|<!DOCTYPE|<!ENTITY|(?:javascript|vbscript)\s*:/i.test(decodeText(text))) report('policy_svg_active_content', path, 'SVG 包含主动内容或外部实体；必须移除并经过目标 CMS 清洗。');
  }
  if (!signature) report('asset_signature', path, '文件头与声明扩展名不匹配；仍须由 CMS 检查真实 MIME 并解码。');
  if (['svg', 'pdf', 'gif'].includes(extension)) {
    const text = new TextDecoder().decode(bytes);
    if (/<\?(?:php|=)|<%[=@]/i.test(text)) report('policy_asset_script', path, '媒体中不允许包含服务端脚本标记。');
    if (extension === 'pdf' && /\/\s*(?:JavaScript|JS|Launch|EmbeddedFile|RichMedia|OpenAction)\b/i.test(text)) report('policy_pdf_active_content', path, 'PDF 包含不允许的主动内容。');
  }
  if (signature && (extension === 'png' || extension === 'gif')) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const width = extension === 'png' ? view.getUint32(16) : view.getUint16(6, true);
    const height = extension === 'png' ? view.getUint32(20) : view.getUint16(8, true);
    if (width < 1 || height < 1 || width > 8192 || height > 8192 || width * height > 16_000_000) report('asset_dimensions', path, '位图边长必须为 1–8192，像素总数不超过 1600 万。');
  }
}
