import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { AppError, assert } from '../lib/errors';
import { id, sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { type App, body, ok } from '../lib/http';
import { requireAuth, requireRole } from './auth';
import { PLANS } from './commerce';
import { currentCatalog,catalogPlans,makePlanSnapshot,DEFAULT_CATALOG,BUILTIN_CATALOG_ID,type PlanSnapshot } from './billing-catalog';
import { grantCredit } from './ledger';
import { loadPaymentConfiguration, stripeRequest, type PaymentRuntime } from './payments';
import { creditGiftSchema,creditGiftQuery,giftAiCredit,listCreditGifts,findCreditGift } from './credit-gifts';

const operationSchema=z.object({reason:z.string().trim().min(3).max(500),requestKey:z.string().min(8).max(128)}).strict();
const giftSchema=operationSchema.extend({tier:z.enum(['go','pro']),months:z.number().int().min(1).max(12).default(1),startsAt:z.string().datetime().optional(),catalogVersionId:z.string().max(128).optional()});
export type MembershipOperationInput=z.infer<typeof operationSchema>;
export type GiftMembershipInput=z.input<typeof giftSchema>;
type FreezeState='pending_billing_change'|'frozen'|'pending_unfreeze'|'completed';
interface Freeze {id:string;user_id:string;request_key:string;reason:string;unfreeze_reason:string|null;state:FreezeState;frozen_at_ms:number|null;requested_at_ms:number;unfreeze_requested_at_ms:number|null;unfrozen_at_ms:number|null;compensated_ms:number;lease_token:string|null;error_code:string|null;payload_hash:string;unfreeze_payload_hash:string|null;unfreeze_request_key:string|null;}
interface Gift {id:string;user_id:string;tier:'go'|'pro';months:number;state:string;payload_hash:string;periods_json:string;plan_snapshot_json:string|null;catalog_version_id:string|null;}
interface Period {startsAtMs:number;expiresAtMs:number;}
interface Agreement {id:string;config_version_id:string;provider_subscription_id:string;state:string;cancel_requested:number;}
function now(runtime:PaymentRuntime):number{return runtime.nowMs??Date.now();}
function record(value:unknown):Record<string,unknown>{return value!==null&&typeof value==='object'?value as Record<string,unknown>:{};}
function errorCode(error:unknown):string {return error instanceof AppError?error.code:'MEMBERSHIP_OPERATION_UNCONFIRMED';}
export function giftPeriods(startsAtMs:number,months:number):Period[] {
 const initial=new Date(startsAtMs),day=initial.getUTCDate();
 const anniversary=(offset:number)=>{
  const target=new Date(Date.UTC(initial.getUTCFullYear(),initial.getUTCMonth()+offset,1,initial.getUTCHours(),initial.getUTCMinutes(),initial.getUTCSeconds(),initial.getUTCMilliseconds()));
  const maxDay=new Date(Date.UTC(target.getUTCFullYear(),target.getUTCMonth()+1,0)).getUTCDate();target.setUTCDate(Math.min(day,maxDay));return target.getTime();
 };
 return Array.from({length:months},(_,index)=>({startsAtMs:anniversary(index),expiresAtMs:anniversary(index+1)}));
}
async function authorize(env:Env,actorId:string,userId:string,freeze=false):Promise<void>{
 const actor=await env.DB.prepare('SELECT role FROM users WHERE id=?').bind(actorId).first<{role:string}>();
 const target=await env.DB.prepare('SELECT role FROM users WHERE id=?').bind(userId).first<{role:string}>();
 assert(actor&&['owner','admin'].includes(actor.role),'FORBIDDEN','没有会员管理权限',403);
 assert(target,'MEMBER_NOT_FOUND','会员不存在',404);
 assert(actor.role==='owner'||target.role==='user','FORBIDDEN','不能修改同级管理员的会员权益',403);
 if(freeze)assert(actorId!==userId&&target.role!=='owner','PROTECTED_ACCOUNT','不能冻结当前账号或平台所有者',403);
}
export async function getMembershipStatus(db:D1Database,userId:string){
 const [subscriptions,gifts,freeze,catalog]=await Promise.all([
  db.prepare('SELECT id,tier,source,starts_at,ends_at,state,auto_renew,included_sites,credit_micros,topup_allowed,membership_frozen_by FROM subscriptions WHERE user_id=? ORDER BY starts_at DESC').bind(userId).all(),
  db.prepare('SELECT id,tier,months,state,reason,request_key,starts_at_ms,catalog_version_id,plan_snapshot_json,created_at,completed_at FROM membership_gifts WHERE user_id=? ORDER BY created_at DESC LIMIT 50').bind(userId).all(),
  db.prepare('SELECT * FROM membership_freezes WHERE user_id=? ORDER BY requested_at_ms DESC LIMIT 1').bind(userId).first<Freeze>(),
  currentCatalog(db),
 ]);
 const changes=freeze?await db.prepare('SELECT agreement_id,action,target_end_ms,state,error_code,confirmed_at FROM membership_billing_changes WHERE freeze_id=? ORDER BY created_at').bind(freeze.id).all():{results:[]};
 return {items:subscriptions.results,gifts:gifts.results,giftPlans:catalogPlans(catalog.catalog),catalogVersionId:catalog.id,freeze:freeze?{
  id:freeze.id,state:freeze.state,frozenAtMs:freeze.frozen_at_ms,unfrozenAtMs:freeze.unfrozen_at_ms,
  requestKey:freeze.request_key,reason:freeze.reason,unfreezeRequestKey:freeze.unfreeze_request_key,unfreezeReason:freeze.unfreeze_reason,
  compensatedMs:freeze.compensated_ms,errorCode:freeze.error_code,
  frozen:freeze.state==='frozen'||freeze.state==='pending_unfreeze',billingChanges:changes.results,
 }:null};
}
export async function giftMembership(env:Env,actorId:string,userId:string,input:GiftMembershipInput,runtime:PaymentRuntime={}){
 await authorize(env,actorId,userId);const parsed=giftSchema.parse(input),time=now(runtime),giftId=id('gift');
 const payloadParts:Array<string|number>=[userId,parsed.tier,parsed.months,parsed.reason];if(parsed.startsAt)payloadParts.push(parsed.startsAt);
 const payload=await sha256(JSON.stringify(payloadParts));
 const existing=await env.DB.prepare('SELECT * FROM membership_gifts WHERE user_id=? AND request_key=?').bind(userId,parsed.requestKey).first<Gift>();
 if(existing)assert(existing.payload_hash===payload&&(!parsed.catalogVersionId||parsed.catalogVersionId===(existing.catalog_version_id??BUILTIN_CATALOG_ID)),'IDEMPOTENCY_CONFLICT','相同请求标识不能用于不同赠送或套餐权益',409);
 if(!existing){
  const catalog=await currentCatalog(env.DB),snapshot=makePlanSnapshot(catalog,'subscription',parsed.tier);
  assert((parsed.catalogVersionId??BUILTIN_CATALOG_ID)===catalog.id,'CATALOG_CHANGED','套餐版本已变化，请刷新后确认赠送权益',409);
  const startsAt=parsed.startsAt?Date.parse(parsed.startsAt):time;
  assert(startsAt>=time&&startsAt<=time+366*24*3600_000,'INVALID_GIFT_START','赠送开始时间须为现在至未来一年内');
  try{
   await env.DB.prepare(`INSERT INTO membership_gifts(id,user_id,actor_id,tier,months,request_key,payload_hash,reason,starts_at_ms,periods_json,created_at,eligibility_ok,catalog_version_id,plan_snapshot_json)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,CASE WHEN NOT EXISTS(SELECT 1 FROM membership_freezes WHERE user_id=? AND state<>'completed') AND COALESCE((SELECT version_id FROM billing_catalog_active WHERE singleton=1),'benos-default-2026-11-07')=? THEN 1 ELSE 0 END,?,?)
    ON CONFLICT(user_id,request_key) DO UPDATE SET payload_hash=CASE WHEN membership_gifts.payload_hash=excluded.payload_hash THEN membership_gifts.payload_hash ELSE NULL END`)
    .bind(giftId,userId,actorId,parsed.tier,parsed.months,parsed.requestKey,payload,parsed.reason,startsAt,JSON.stringify(giftPeriods(startsAt,parsed.months)),new Date(time).toISOString(),userId,catalog.id,catalog.id,JSON.stringify(snapshot)).run();
  }catch(error){if(String(error).includes('membership_gift_eligible'))throw new AppError('MEMBERSHIP_FROZEN','请先完成会员解冻，再赠送新会员',409);throw error;}
 }
 const gift=await env.DB.prepare('SELECT * FROM membership_gifts WHERE user_id=? AND request_key=?').bind(userId,parsed.requestKey).first<Gift>();
 assert(gift&&gift.payload_hash===payload&&(!parsed.catalogVersionId||parsed.catalogVersionId===(gift.catalog_version_id??BUILTIN_CATALOG_ID)),'IDEMPOTENCY_CONFLICT','赠送状态待核对',409);
 if(gift.state==='completed')return getMembershipStatus(env.DB,userId);
 const periods=JSON.parse(gift.periods_json) as Period[],plan=gift.plan_snapshot_json?JSON.parse(gift.plan_snapshot_json) as PlanSnapshot:DEFAULT_CATALOG[gift.tier];
 assert(periods.at(-1)!.expiresAtMs>time,'GIFT_EXPIRED','赠送履约期已到期，请核对记录后重新赠送',409);
 for(let index=0;index<periods.length;index++){
  const period=periods[index];
  await grantCredit(env.DB,{id:`credit_${gift.id}_${index}`,userId,source:'gift',amountMicros:plan.creditMicros,
   startsAtMs:period.startsAtMs,expiresAtMs:period.expiresAtMs,referenceId:`membership:${gift.id}:${index}`,nowMs:time});
 }
 const statements=periods.map((period,index)=>env.DB.prepare(`INSERT INTO subscriptions
  (id,user_id,tier,source,starts_at,ends_at,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at)
  VALUES(?,?,?,'gift',?,?,?,?,0,?,?) ON CONFLICT(grant_reference_id) DO NOTHING`)
  .bind(`gift_sub_${gift.id}_${index}`,userId,gift.tier,new Date(period.startsAtMs).toISOString(),new Date(period.expiresAtMs).toISOString(),plan.includedSites,plan.creditMicros,`membership:${gift.id}:${index}`,new Date(time).toISOString()));
 statements.push(env.DB.prepare("UPDATE membership_gifts SET state='completed',completed_at=? WHERE id=? AND state='pending'").bind(new Date(time).toISOString(),gift.id),
  env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,created_at)
   VALUES(?,?,'member.gift','user',?,?,?) ON CONFLICT(id) DO NOTHING`).bind(`audit_${gift.id}`,actorId,userId,JSON.stringify({tier:gift.tier,months:gift.months,reason:parsed.reason,monthlyCreditMicros:plan.creditMicros,topupAllowed:false}),new Date(time).toISOString()));
 // N1: a gifted term can leave slot capacity idle where an annual year was placed;
 // the request to move such years commits with the gift (retried by maintenance).
 const billing=await import('./hosting-billing');
 statements.push(billing.deferralRequestStatement(env.DB,userId,new Date(periods[0].startsAtMs).toISOString(),'membership_gift',"EXISTS(SELECT 1 FROM membership_gifts WHERE id=? AND state='completed')",[gift.id]));
 await env.DB.batch(statements);
 try{await billing.runDeferralRequest(env.DB,userId);}catch{/* maintenance retries the queued request */}
 return getMembershipStatus(env.DB,userId);
}
async function readFreeze(db:D1Database,freezeId:string):Promise<Freeze>{const value=await db.prepare('SELECT * FROM membership_freezes WHERE id=?').bind(freezeId).first<Freeze>();assert(value,'FREEZE_NOT_FOUND','会员冻结记录不存在',404);return value;}
async function claimLease(db:D1Database,freezeId:string,runtime:PaymentRuntime,action:'freeze'|'unfreeze'):Promise<string|null>{
 const token=id('lease'),time=now(runtime);
 const row=await db.prepare(`UPDATE membership_freezes SET lease_token=?,lease_until_ms=? WHERE id=?
  AND ${action==='freeze'?"state='pending_billing_change'":"state IN ('frozen','pending_unfreeze')"}
  AND (lease_until_ms IS NULL OR lease_until_ms<=?) RETURNING id`)
  .bind(token,time+90_000,freezeId,time).first();return row?token:null;
}
async function pendingFailure(env:Env,freezeId:string,token:string,error:unknown,runtime:PaymentRuntime){
 await env.DB.prepare('UPDATE membership_freezes SET error_code=?,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?')
  .bind(errorCode(error),new Date(now(runtime)).toISOString(),freezeId,token).run();
}
async function agreements(env:Env,userId:string):Promise<Agreement[]>{return (await env.DB.prepare("SELECT id,config_version_id,provider_subscription_id,state,cancel_requested FROM payment_agreements WHERE user_id=? AND state<>'cancelled'").bind(userId).all<Agreement>()).results;}
async function pauseBilling(env:Env,freeze:Freeze,runtime:PaymentRuntime):Promise<void>{
 for(const agreement of await agreements(env,freeze.user_id)){
  const changeId=`pause_${freeze.id}_${agreement.id}`,time=new Date(now(runtime)).toISOString();
  await env.DB.prepare("INSERT INTO membership_billing_changes(id,freeze_id,agreement_id,action,created_at) VALUES(?,?,?,'pause',?) ON CONFLICT(id) DO NOTHING").bind(changeId,freeze.id,agreement.id,time).run();
  const config=await loadPaymentConfiguration(env,agreement.config_version_id),subId=encodeURIComponent(agreement.provider_subscription_id);
  let subscription=await stripeRequest(config,`/v1/subscriptions/${subId}`,'GET',undefined,undefined,runtime);
  if(subscription.status!=='canceled'){
   if(record(subscription.pause_collection).behavior!=='void')subscription=await stripeRequest(config,`/v1/subscriptions/${subId}`,'POST',new URLSearchParams({'pause_collection[behavior]':'void'}),`benos:pause:${freeze.id}:${agreement.id}`,runtime);
   assert(record(subscription.pause_collection).behavior==='void','BILLING_PAUSE_UNCONFIRMED','自动扣款暂停状态待确认',503);
   // Old invoices keep retrying even after pause_collection is set. Never report
   // a successful freeze while any old open/draft invoice can still collect money.
   for(const status of ['open','draft']){
    const invoices=await stripeRequest(config,`/v1/invoices?subscription=${subId}&status=${status}&limit=100`,'GET',undefined,undefined,runtime);
    assert(invoices.has_more===false&&Array.isArray(invoices.data)&&invoices.data.length===0,'BILLING_INVOICE_REVIEW','仍有待处理账单，暂停会员需先核对账单',409);
   }
  }
  await env.DB.prepare("UPDATE membership_billing_changes SET state='confirmed',confirmed_at=?,error_code=NULL WHERE id=?").bind(new Date(now(runtime)).toISOString(),changeId).run();
 }
}
export async function freezeMembership(env:Env,actorId:string,userId:string,input:MembershipOperationInput,runtime:PaymentRuntime={}){
 await authorize(env,actorId,userId,true);const parsed=operationSchema.parse(input),time=now(runtime),payload=await sha256(JSON.stringify([userId,parsed.reason]));
 let freeze=await env.DB.prepare('SELECT * FROM membership_freezes WHERE user_id=? AND request_key=?').bind(userId,parsed.requestKey).first<Freeze>();
 if(freeze)assert(freeze.payload_hash===payload,'IDEMPOTENCY_CONFLICT','相同请求标识不能用于不同冻结',409);
 if(!freeze){
  const open=await env.DB.prepare("SELECT id FROM membership_freezes WHERE user_id=? AND state<>'completed'").bind(userId).first();
  assert(!open,'MEMBERSHIP_ALREADY_PAUSING','已有会员暂停操作，请查询并重试原操作',409);
  try{
   await env.DB.prepare(`INSERT INTO membership_freezes(id,user_id,actor_id,request_key,payload_hash,reason,requested_at_ms,updated_at,eligibility_ok)
    VALUES(?,?,?,?,?,?,?,?,CASE WHEN EXISTS(SELECT 1 FROM subscriptions WHERE user_id=? AND state IN ('active','cancelled') AND ends_at>?)
     AND NOT EXISTS(SELECT 1 FROM membership_gifts WHERE user_id=? AND state='pending')
     AND NOT EXISTS(SELECT 1 FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id
      WHERE o.user_id=? AND o.kind IN ('subscription','topup') AND f.state='pending') THEN 1 ELSE 0 END)
     ON CONFLICT(user_id,request_key) DO UPDATE SET payload_hash=CASE WHEN membership_freezes.payload_hash=excluded.payload_hash THEN membership_freezes.payload_hash ELSE NULL END`)
    .bind(id('freeze'),userId,actorId,parsed.requestKey,payload,parsed.reason,time,new Date(time).toISOString(),userId,new Date(time).toISOString(),userId,userId).run();
  }catch(error){if(String(error).includes('membership_freeze_eligible'))throw new AppError('MEMBERSHIP_NOT_READY','没有可暂停的会员期，或赠送/已付款权益仍在入账，请先核对原权益',409);throw error;}
  freeze=await env.DB.prepare('SELECT * FROM membership_freezes WHERE user_id=? AND request_key=?').bind(userId,parsed.requestKey).first<Freeze>();
 }
 assert(freeze,'FREEZE_UNCONFIRMED','暂停操作状态待确认',503);
 if(freeze.state!=='pending_billing_change')return getMembershipStatus(env.DB,userId);
 const token=await claimLease(env.DB,freeze.id,runtime,'freeze');if(!token)return getMembershipStatus(env.DB,userId);
 try{
  await pauseBilling(env,freeze,runtime);const frozenAt=now(runtime),frozenIso=new Date(frozenAt).toISOString();
  await env.DB.batch([
   env.DB.prepare("UPDATE membership_freezes SET eligibility_ok=CASE WHEN lease_token=? AND state='pending_billing_change' THEN 1 ELSE 0 END WHERE id=?").bind(token,freeze.id),
   env.DB.prepare(`INSERT INTO membership_freeze_subscriptions(freeze_id,subscription_id,starts_at,ends_at)
    SELECT ?,id,starts_at,ends_at FROM subscriptions WHERE user_id=? AND state IN ('active','cancelled') AND ends_at>? AND membership_frozen_by IS NULL
    AND EXISTS(SELECT 1 FROM membership_freezes WHERE id=? AND lease_token=? AND state='pending_billing_change')
    ON CONFLICT(freeze_id,subscription_id) DO NOTHING`).bind(freeze.id,userId,frozenIso,freeze.id,token),
   env.DB.prepare(`UPDATE membership_freezes SET eligibility_ok=CASE WHEN EXISTS(SELECT 1 FROM membership_freeze_subscriptions WHERE freeze_id=?) THEN 1 ELSE 0 END WHERE id=? AND lease_token=?`).bind(freeze.id,freeze.id,token),
   env.DB.prepare('UPDATE subscriptions SET membership_frozen_by=? WHERE id IN(SELECT subscription_id FROM membership_freeze_subscriptions WHERE freeze_id=?)').bind(freeze.id,freeze.id),
   env.DB.prepare(`INSERT INTO membership_freeze_grants(freeze_id,grant_id,starts_at_ms,expires_at_ms)
    SELECT ?,g.id,g.starts_at_ms,g.expires_at_ms FROM credit_grants g JOIN subscriptions s ON s.user_id=g.user_id AND s.grant_reference_id=g.reference_id
    WHERE s.membership_frozen_by=? AND g.expires_at_ms>? AND g.source IN ('subscription','gift') ON CONFLICT(freeze_id,grant_id) DO NOTHING`).bind(freeze.id,freeze.id,frozenAt),
   env.DB.prepare('UPDATE credit_grants SET membership_frozen_by=? WHERE id IN(SELECT grant_id FROM membership_freeze_grants WHERE freeze_id=?)').bind(freeze.id,freeze.id),
   env.DB.prepare("UPDATE membership_freezes SET state='frozen',frozen_at_ms=?,error_code=NULL,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?").bind(frozenAt,frozenIso,freeze.id,token),
   auditStatement(env.DB,actorId,'member.freeze','user',userId,{freezeId:freeze.id,reason:parsed.reason,frozenAtMs:frozenAt}),
  ]);
 }catch(error){await pendingFailure(env,freeze.id,token,error,runtime);}
 return getMembershipStatus(env.DB,userId);
}
async function resumeBilling(env:Env,freeze:Freeze,resumeAt:number,runtime:PaymentRuntime):Promise<void>{
 const duration=resumeAt-freeze.frozen_at_ms!;
 for(const agreement of await agreements(env,freeze.user_id)){
  const config=await loadPaymentConfiguration(env,agreement.config_version_id),subId=encodeURIComponent(agreement.provider_subscription_id);
  const subscription=await stripeRequest(config,`/v1/subscriptions/${subId}`,'GET',undefined,undefined,runtime);
  if(subscription.status==='canceled')continue;
  const remaining=await env.DB.prepare(`SELECT MAX(snap.ends_at) AS ends FROM membership_freeze_subscriptions snap
   JOIN subscriptions s ON s.id=snap.subscription_id WHERE snap.freeze_id=? AND s.source='paid'`).bind(freeze.id).first<{ends:string|null}>();
  assert(remaining?.ends,'BILLING_RESUME_REVIEW','没有可恢复的已付会员期，请核对订阅后恢复',409);
  const targetEnd=Math.ceil((new Date(remaining.ends).getTime()+duration)/1000),changeId=`resume_${freeze.id}_${agreement.id}_${targetEnd}`;
  assert(targetEnd>Math.floor(resumeAt/1000),'BILLING_RESUME_REVIEW','已付周期需要核对',409);
  const time=new Date(now(runtime)).toISOString();
  await env.DB.prepare("INSERT INTO membership_billing_changes(id,freeze_id,agreement_id,action,target_end_ms,created_at) VALUES(?,?,?,'resume',?,?) ON CONFLICT(id) DO NOTHING")
   .bind(changeId,freeze.id,agreement.id,targetEnd*1000,time).run();
  const params=new URLSearchParams({pause_collection:'',trial_end:String(targetEnd),proration_behavior:'none','metadata[benos_membership_resume]':freeze.id});
  if(agreement.cancel_requested||agreement.state==='cancel_scheduled')params.set('cancel_at_period_end','true');
  const result=await stripeRequest(config,`/v1/subscriptions/${subId}`,'POST',params,`benos:${changeId}`,runtime);
  assert(result.pause_collection===null&&result.trial_end===targetEnd,'BILLING_RESUME_UNCONFIRMED','下次扣费日期尚未完成对齐，会员保持冻结',503);
  await env.DB.prepare("UPDATE membership_billing_changes SET state='confirmed',confirmed_at=?,error_code=NULL WHERE id=?").bind(new Date(now(runtime)).toISOString(),changeId).run();
 }
}
export async function unfreezeMembership(env:Env,actorId:string,userId:string,input:MembershipOperationInput,runtime:PaymentRuntime={}){
 await authorize(env,actorId,userId,true);const parsed=operationSchema.parse(input),payload=await sha256(JSON.stringify([userId,parsed.reason]));
 const prior=await env.DB.prepare('SELECT * FROM membership_freezes WHERE user_id=? AND unfreeze_request_key=?').bind(userId,parsed.requestKey).first<Freeze>();
 if(prior){assert(prior.unfreeze_payload_hash===payload,'IDEMPOTENCY_CONFLICT','相同请求标识不能用于不同解冻',409);if(prior.state==='completed')return getMembershipStatus(env.DB,userId);}
 let freeze=await env.DB.prepare("SELECT * FROM membership_freezes WHERE user_id=? AND state IN ('frozen','pending_unfreeze') ORDER BY requested_at_ms DESC LIMIT 1").bind(userId).first<Freeze>();
 if(!freeze){
  freeze=await env.DB.prepare("SELECT * FROM membership_freezes WHERE user_id=? AND state='completed' AND unfreeze_request_key=?").bind(userId,parsed.requestKey).first<Freeze>();
  assert(freeze&&freeze.unfreeze_payload_hash===payload,'MEMBERSHIP_NOT_FROZEN','会员尚未成功冻结，无法解冻',409);return getMembershipStatus(env.DB,userId);
 }
 assert(!freeze.unfreeze_request_key||freeze.unfreeze_request_key===parsed.requestKey&&freeze.unfreeze_payload_hash===payload,'IDEMPOTENCY_CONFLICT','解冻正在处理中，请重试原请求',409);
 const token=await claimLease(env.DB,freeze.id,runtime,'unfreeze');if(!token)return getMembershipStatus(env.DB,userId);
 const resumeAt=now(runtime);
 try{
  await env.DB.prepare(`UPDATE membership_freezes SET state='pending_unfreeze',unfreeze_request_key=?,unfreeze_payload_hash=?,unfreeze_actor_id=?,unfreeze_reason=?,unfreeze_requested_at_ms=?,updated_at=? WHERE id=? AND lease_token=?`)
   .bind(parsed.requestKey,payload,actorId,parsed.reason,resumeAt,new Date(resumeAt).toISOString(),freeze.id,token).run();
  freeze=await readFreeze(env.DB,freeze.id);await resumeBilling(env,freeze,resumeAt,runtime);
  const duration=resumeAt-freeze.frozen_at_ms!;assert(duration>=0,'CLOCK_ERROR','服务端时间异常',503);
  const subs=(await env.DB.prepare('SELECT subscription_id,starts_at,ends_at FROM membership_freeze_subscriptions WHERE freeze_id=?').bind(freeze.id).all<{subscription_id:string;starts_at:string;ends_at:string}>()).results;
  const grants=(await env.DB.prepare('SELECT grant_id,starts_at_ms,expires_at_ms FROM membership_freeze_grants WHERE freeze_id=?').bind(freeze.id).all<{grant_id:string;starts_at_ms:number;expires_at_ms:number}>()).results;
  const statements:D1PreparedStatement[]=[env.DB.prepare("UPDATE membership_freezes SET eligibility_ok=CASE WHEN lease_token=? AND state='pending_unfreeze' THEN 1 ELSE 0 END WHERE id=?").bind(token,freeze.id)];
  for(const sub of subs){const start=new Date(sub.starts_at).getTime();statements.push(env.DB.prepare('UPDATE subscriptions SET starts_at=?,ends_at=?,membership_frozen_by=NULL WHERE id=? AND membership_frozen_by=?')
   .bind(new Date(start>freeze.frozen_at_ms!?start+duration:start).toISOString(),new Date(new Date(sub.ends_at).getTime()+duration).toISOString(),sub.subscription_id,freeze.id));}
  for(const grant of grants)statements.push(env.DB.prepare('UPDATE credit_grants SET starts_at_ms=?,expires_at_ms=?,membership_frozen_by=NULL WHERE id=? AND membership_frozen_by=?')
   .bind(grant.starts_at_ms>freeze.frozen_at_ms!?grant.starts_at_ms+duration:grant.starts_at_ms,grant.expires_at_ms+duration,grant.grant_id,freeze.id));
  const billing=await import('./hosting-billing');
  statements.push(env.DB.prepare("UPDATE membership_freezes SET state='completed',unfrozen_at_ms=?,compensated_ms=?,error_code=NULL,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?")
   .bind(resumeAt,duration,new Date(resumeAt).toISOString(),freeze.id,token),auditStatement(env.DB,actorId,'member.unfreeze','user',userId,{freezeId:freeze.id,reason:parsed.reason,compensatedMs:duration}),
   // 解冻顺延 (M1, N7): annual years that were to follow the paused membership move
   // behind the restored membership. The request commits with the unfreeze, so a
   // failed follow-up is retried by maintenance instead of being lost.
   billing.deferralRequestStatement(env.DB,userId,new Date(freeze.frozen_at_ms!).toISOString(),'membership_unfreeze',"EXISTS(SELECT 1 FROM membership_freezes WHERE id=? AND state='completed' AND unfrozen_at_ms=?)",[freeze.id,resumeAt]));
  await env.DB.batch(statements);
  if((await readFreeze(env.DB,freeze.id)).state==='completed')try{await billing.runDeferralRequest(env.DB,userId);}catch{/* maintenance retries the queued request */}
 }catch(error){await pendingFailure(env,freeze.id,token,error,runtime);}
 return getMembershipStatus(env.DB,userId);
}
export const membershipRoutes=new Hono<App>();
membershipRoutes.use('*',requireAuth,requireRole('owner','admin'));
membershipRoutes.get('/:userId',async c=>{await authorize(c.env,c.get('auth').user.id,c.req.param('userId'));return ok(c,await getMembershipStatus(c.env.DB,c.req.param('userId')));});
membershipRoutes.post('/:userId/gifts',async c=>ok(c,await giftMembership(c.env,c.get('auth').user.id,c.req.param('userId'),await body(c,giftSchema)),201));
membershipRoutes.get('/:userId/credit-gifts',async c=>{const query=creditGiftQuery.safeParse(c.req.query());assert(query.success,'VALIDATION','分页参数无效');return ok(c,await listCreditGifts(c.env,c.get('auth').user.id,c.req.param('userId'),query.data));});
membershipRoutes.get('/:userId/credit-gifts/requests/:requestKey',async c=>ok(c,await findCreditGift(c.env,c.get('auth').user.id,c.req.param('userId'),c.req.param('requestKey'))));
membershipRoutes.post('/:userId/credit-gifts',async c=>ok(c,await giftAiCredit(c.env,c.get('auth').user.id,c.req.param('userId'),await body(c,creditGiftSchema)),201));
membershipRoutes.post('/:userId/freeze',async c=>{const result=await freezeMembership(c.env,c.get('auth').user.id,c.req.param('userId'),await body(c,operationSchema));return ok(c,result,result.freeze?.state==='pending_billing_change'?202:200);});
membershipRoutes.post('/:userId/unfreeze',async c=>{const result=await unfreezeMembership(c.env,c.get('auth').user.id,c.req.param('userId'),await body(c,operationSchema));return ok(c,result,result.freeze?.state==='pending_unfreeze'?202:200);});
