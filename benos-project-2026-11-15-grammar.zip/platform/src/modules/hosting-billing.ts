import { id } from '../lib/crypto';
type Site={id:string;name:string;domain:string;state:string;created_at:string};
type Term={id:string;tier:string;starts_at:string;ends_at:string;included_sites:number;membership_frozen_by:string|null};
type Grant={site_id:string;source:'annual'|'gift';starts_at:string;ends_at:string};
type Source='annual'|'gift'|'membership';
export type HostingCoverageRange={startsAt:string;endsAt:string;sources:Source[]};
type Segment={start:number;end:number;sources:Set<Source>};
const iso=(time:number)=>new Date(time).toISOString();
/** A pay-first site whose job is still parked waiting for its first payment. */
export const PARKED_JOB="state='awaiting_input' AND step='awaiting_payment'";
/** An unpaid pay-first site is released (domain and project freed) this long
 * after creation, once its checkout has closed; after it no new hosting order
 * can be opened for the site (R-M1a), so the release cannot be postponed. */
export const PARKED_SITE_TTL_MS=24*3600_000;
/** Audit row written only when `condition` holds inside the same batch, so the
 * record and the state change it describes commit (or not) together. */
export function auditWhen(db:D1Database,condition:string,binds:unknown[],actorId:string|null,action:string,entityType:string,entityId:string|null,details:unknown={},requestId:string|null=null):D1PreparedStatement{
 return db.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?,?,?,?,?,?,?,? WHERE ${condition}`)
  .bind(id('audit'),actorId,action,entityType,entityId,JSON.stringify(details),requestId,new Date().toISOString(),...binds);
}

/** True while a membership freeze of the account is in force (frozen, or its
 * unfreeze is still being applied). Requirement 会员赠送与冻结: a freeze pauses
 * the membership; it is not "coverage that ended early", so annual years are
 * never moved because of it. */
export async function membershipFreezeOpen(db:D1Database,userId:string):Promise<boolean>{
 return !!await db.prepare("SELECT 1 FROM membership_freezes WHERE user_id=? AND state IN ('frozen','pending_unfreeze') UNION ALL SELECT 1 FROM subscriptions WHERE user_id=? AND membership_frozen_by IS NOT NULL LIMIT 1").bind(userId,userId).first();
}
/** Everything the slot allocation of an account depends on (its sites, unpaid
 * parked sites, membership terms, annual/gift rows, pending reservations and
 * activations), as one string. A batch that moves annual years first checks that
 * this is still what it read (N4, N5, N6): if another request changed any of it
 * in between, the whole batch rolls back and nothing is moved or audited. */
// One ordered scalar subquery per table, joined with ||. No compound SELECT:
// D1 refuses one with more than 5 terms (R4-M2), and this used to have 7.
const ACCOUNT_STATE_PARTS=[
 `SELECT 'e:'||h.id||':'||h.site_id||':'||h.source||':'||h.state||':'||h.starts_at||':'||h.ends_at AS v FROM hosting_entitlements h WHERE h.user_id=?2`,
 `SELECT 'f:'||f.id||':'||f.state||':'||o.state||':'||COALESCE(f.starts_at,'')||':'||COALESCE(f.ends_at,'') AS v FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id WHERE o.user_id=?2 AND o.kind='hosting' AND f.state='pending'`,
 `SELECT 's:'||s.id||':'||s.tier||':'||s.starts_at||':'||s.ends_at||':'||s.state||':'||s.included_sites||':'||COALESCE(s.membership_frozen_by,'') AS v FROM subscriptions s WHERE s.user_id=?2`,
 `SELECT 'w:'||w.id||':'||w.state||':'||w.created_at AS v FROM sites w WHERE w.user_id=?2`,
 `SELECT 'j:'||j.id||':'||j.site_id AS v FROM provisioning_jobs j WHERE j.user_id=?2 AND j.state='awaiting_input' AND j.step='awaiting_payment'`,
 `SELECT 'a:'||a.order_id||':'||a.state||':'||COALESCE(a.anchored_ends_at,'') AS v FROM hosting_annual_activations a WHERE a.user_id=?2`,
 `SELECT 'z:'||m.id||':'||m.state AS v FROM membership_freezes m WHERE m.user_id=?2 AND m.state<>'completed'`,
];
const ACCOUNT_STATE=`(${ACCOUNT_STATE_PARTS.map(part=>`(SELECT COALESCE(group_concat(v,'|'),'') FROM (${part} ORDER BY 1))`).join(`||'#'||`)})`;
async function accountState(db:D1Database,userId:string):Promise<string>{
 return String((await db.prepare(`SELECT ${ACCOUNT_STATE} AS state`).bind(null,userId).first<{state:string}>())?.state??'');
}
/** First statement of a year-moving batch: fails the whole batch (CHECK on
 * mutation_guards) unless the account is still in the state that was read. */
function accountStateGuard(db:D1Database,guardId:string,userId:string,state:string):D1PreparedStatement{
 return db.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?1,CASE WHEN ${ACCOUNT_STATE}=?3 THEN 1 ELSE 0 END`).bind(guardId,userId,state);
}
/** Raised when a year-moving batch lost a race; the caller (maintenance or the
 * deferral request) runs it again on fresh data. */
export class AnnualMoveConflict extends Error{constructor(){super('ANNUAL_MOVE_CONFLICT');}}
async function guardedBatch(db:D1Database,statements:D1PreparedStatement[]){
 try{return await db.batch(statements);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AnnualMoveConflict();throw error;}
}
type Idle={start:number;end:number;free:number};
/** Oldest-site allocation over time. `projectFrozenAt` (planning only) treats a
 * frozen term as paused: its dates are those an unfreeze at that moment would
 * give (end moved by the time frozen so far), the same rule as unfreezeMembership. */
async function allocate(db:D1Database,userId:string,options:{projectFrozenAt?:number}={}){
 const [siteRows,termRows,grantRows,parkedRows]=await Promise.all([
  db.prepare('SELECT id,name,domain,state,created_at FROM sites WHERE user_id=? ORDER BY created_at,id').bind(userId).all<Site>(),
  db.prepare("SELECT s.id,s.tier,s.starts_at,s.ends_at,s.included_sites,s.membership_frozen_by,f.frozen_at_ms FROM subscriptions s LEFT JOIN membership_freezes f ON f.id=s.membership_frozen_by WHERE s.user_id=? AND s.state IN ('active','cancelled') ORDER BY CASE s.tier WHEN 'pro' THEN 0 ELSE 1 END,s.ends_at DESC").bind(userId).all<Term&{frozen_at_ms:number|null}>(),
  db.prepare("SELECT h.site_id,h.source,h.starts_at,h.ends_at FROM hosting_entitlements h JOIN sites s ON s.id=h.site_id AND s.user_id=h.user_id WHERE s.user_id=? AND h.user_id=? AND h.source IN ('annual','gift') AND h.state='active'").bind(userId,userId).all<Grant>(),
  // A pay-first site that was never paid (job parked at awaiting_payment) never takes a membership slot.
  db.prepare(`SELECT DISTINCT site_id FROM provisioning_jobs WHERE user_id=? AND ${PARKED_JOB}`).bind(userId).all<{site_id:string}>(),
 ]);
 const parked=new Set(parkedRows.results.map(row=>row.site_id)),projectAt=options.projectFrozenAt;
 let terms:Term[];
 if(projectAt===undefined)terms=termRows.results.filter(term=>!term.membership_frozen_by);
 else{
  terms=termRows.results.map(term=>{
   if(!term.membership_frozen_by||term.frozen_at_ms===null)return term;
   const elapsed=Math.max(0,projectAt-term.frozen_at_ms),start=Date.parse(term.starts_at);
   return {...term,starts_at:iso(start>term.frozen_at_ms?start+elapsed:start),ends_at:iso(Date.parse(term.ends_at)+elapsed)};
  }).sort((a,b)=>(a.tier==='pro'?0:1)-(b.tier==='pro'?0:1)||(a.ends_at<b.ends_at?1:a.ends_at>b.ends_at?-1:0));
 }
 const sites=siteRows.results,grants=grantRows.results;
 const boundaries=new Set<number>();
 for(const site of sites)boundaries.add(Date.parse(site.created_at));
 for(const row of [...terms,...grants]){boundaries.add(Date.parse(row.starts_at));boundaries.add(Date.parse(row.ends_at));}
 const points=[...boundaries].filter(Number.isFinite).sort((a,b)=>a-b),ranges=new Map(sites.map(site=>[site.id,[] as Segment[]])),parts=new Map(sites.map(site=>[site.id,[] as Segment[]])),idle:Idle[]=[];
 for(let index=0;index<points.length-1;index++){
  const start=points[index],end=points[index+1];
  const independent=new Map<string,Set<Source>>();
  for(const grant of grants)if(Date.parse(grant.starts_at)<=start&&Date.parse(grant.ends_at)>start){const sources=independent.get(grant.site_id)||new Set<Source>();sources.add(grant.source);independent.set(grant.site_id,sources);}
  // One slot rule everywhere (M2): the single current term, Pro first, then the latest end (as activeSubscription).
  const term=terms.find(term=>Date.parse(term.starts_at)<=start&&Date.parse(term.ends_at)>start);
  let remaining=term?.included_sites||0;
  for(const site of sites){
   if(Date.parse(site.created_at)>start)continue;
   const sources=independent.get(site.id)||(!parked.has(site.id)&&remaining>0?(remaining--,new Set<Source>(['membership'])):null);
   if(!sources)continue;
   const items=ranges.get(site.id)!,last=items.at(-1);
   if(last?.end===start){last.end=end;for(const source of sources)last.sources.add(source);}
   else items.push({start,end,sources:new Set(sources)});
   parts.get(site.id)!.push({start,end,sources:new Set(sources)});
  }
  if(remaining>0)idle.push({start,end,free:remaining});
 }
 return {sites,ranges,parts,idle,parked,membershipFrozen:termRows.results.some(term=>!!term.membership_frozen_by)};
}

/** Billing is one row per owned site. Project only already granted intervals;
 * automatic renewals are not future entitlements until confirmed paid.
 * At each boundary use the same priority and oldest-site allocation as hosting:
 * independent annual/gift coverage first, then the effective membership quota. */
export async function hostingBillingSummary(db:D1Database,userId:string,nowMs=Date.now(),options:{projectFrozenAt?:number}={}){
 const {sites,ranges,parts,membershipFrozen}=await allocate(db,userId,options);
 const publicRange=(segment:Segment):HostingCoverageRange=>({startsAt:iso(segment.start),endsAt:iso(segment.end),sources:[...segment.sources].sort()});
 return sites.map(site=>{
  const items=ranges.get(site.id)!,current=items.find(range=>range.start<=nowMs&&range.end>nowMs),upcoming=items.filter(range=>range.start>nowMs),ended=items.filter(range=>range.end<=nowMs).at(-1);
  // R3-5: the current range is labelled by what covers it from now on (the part
  // containing asOf and the rest of the range), never by a part already in the
  // past, so a slot that is idle under a paid year is not shown as membership.
  const currentSources=current?new Set(parts.get(site.id)!.filter(part=>part.end>nowMs&&part.start<current.end&&part.end<=current.end).flatMap(part=>[...part.sources])):null;
  return {id:site.id,name:site.name,domain:site.domain,state:site.state,endsAt:current?iso(current.end):null,
   coverage:{asOf:iso(nowMs),state:current?'active':upcoming.length?'scheduled':ended?'expired':'none',current:current?publicRange({...current,sources:currentSources!}):null,upcoming:upcoming.map(publicRange),lastEndedAt:ended?iso(ended.end):null,membershipFrozen}};
 });
}

/** Same calendar rule as the fulfilment SQL: one year later, Feb 29 -> Feb 28. */
export function addHostingYear(value:string):string{const date=new Date(value),month=date.getUTCMonth();date.setUTCFullYear(date.getUTCFullYear()+1);if(date.getUTCMonth()!==month)date.setUTCDate(0);return date.toISOString();}
export type AnnualBasis='extend_annual'|'after_gift'|'after_membership'|'on_activation'|'on_resume'|'immediate';
export type AnnualPlan={startsAt:string;endsAt:string;basis:AnnualBasis;estimated:boolean;coverageEndsAt:string|null;activation:'create'|'resume'|null};
const LIVE_SITE_STATES=['connected','active','publishing'];
type OwnRow={id:string;kind:'grant'|'reserved';orderId:string|null;source:'annual'|'gift';starts_at:string;ends_at:string};

/** The site's own (annual/gift) coverage: active grants plus paid years whose
 * grant has not completed yet. A revoked year, or a year whose order was
 * refunded, never counts (requirement: a re-purchase must not be stacked
 * behind coverage the site does not have). */
async function ownCoverage(db:D1Database,userId:string,siteId:string,excludeOrderId=''):Promise<OwnRow[]>{
 const [grants,reserved]=await Promise.all([
  db.prepare("SELECT id,order_id,source,starts_at,ends_at FROM hosting_entitlements WHERE site_id=? AND user_id=? AND source IN ('annual','gift') AND state='active' AND (order_id IS NULL OR order_id<>?)").bind(siteId,userId,excludeOrderId).all<{id:string;order_id:string|null;source:'annual'|'gift';starts_at:string;ends_at:string}>(),
  db.prepare("SELECT f.id,f.order_id,f.starts_at,f.ends_at FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id WHERE o.hosting_site_id=? AND o.kind='hosting' AND f.order_id<>? AND f.state='pending' AND f.ends_at IS NOT NULL AND o.state<>'refunded'").bind(siteId,excludeOrderId).all<{id:string;order_id:string;starts_at:string;ends_at:string}>(),
 ]);
 return [...grants.results.map(row=>({id:row.id,kind:'grant' as const,orderId:row.order_id,source:row.source,starts_at:row.starts_at,ends_at:row.ends_at})),
  ...reserved.results.map(row=>({id:row.id,kind:'reserved' as const,orderId:row.order_id,source:'annual' as const,starts_at:row.starts_at,ends_at:row.ends_at}))];
}
/** Follows the site's own rows from `from` while they continue without a gap. */
function chainFrom(rows:OwnRow[],from:string):{end:string;source:'annual'|'gift'|null}{
 let end=from,source:'annual'|'gift'|null=null;
 for(let moved=true;moved;){moved=false;for(const row of rows)if(row.starts_at<=end&&row.ends_at>end){end=row.ends_at;source=row.source;moved=true;}}
 return {end,source};
}
/** End of the site's continuous coverage from `at` (own years, gift and the
 * already-granted membership slot, merged by the billing summary) and the
 * annual years scheduled after a gap. A gap appears only when coverage ended
 * earlier than planned (membership revoked, refunded, frozen or downgraded; a
 * year revoked). Requirement 托管续费与到期处理: a year bought to follow coverage
 * starts when that coverage actually ends, so such years are pulled forward. */
function coverageGap(rows:OwnRow[],at:string,summaryCurrentEnd:string|null){
 let end=summaryCurrentEnd&&summaryCurrentEnd>at?summaryCurrentEnd:at;
 for(let next=chainFrom(rows,end).end;next>end;next=chainFrom(rows,end).end)end=next;
 const later=rows.filter(row=>row.source==='annual'&&row.starts_at>end).sort((a,b)=>a.starts_at<b.starts_at?-1:a.starts_at>b.starts_at?1:0);
 return {coveredUntil:end,later,delta:later.length?Date.parse(later[0].starts_at)-Date.parse(end):0};
}
async function currentCoverageEnd(db:D1Database,userId:string,siteId:string,atMs:number,options:{projectFrozenAt?:number}={}){
 return (await hostingBillingSummary(db,userId,atMs,options)).find(row=>row.id===siteId)?.coverage.current?.endsAt??null;
}

/** Requirement 托管续费与到期处理: an annual year never overlaps coverage the
 * site already has. It continues after the site's own annual/gift chain when
 * that covers now ("顺延"), otherwise after the current continuous coverage
 * through the membership slot (as already granted — unpaid auto-renewals are
 * never projected). A site without coverage that is not yet open (pay-first
 * new site) or is suspended counts its year from the moment it actually opens
 * or resumes; until then the start/end are provisional. Years scheduled after
 * a gap are treated as pulled forward to the coverage end, which
 * rescheduleUncoveredAnnualYears does in the database before a payment is placed. */
export async function annualRenewalPlan(db:D1Database,userId:string,siteId:string,atMs=Date.now(),excludeOrderId=''):Promise<AnnualPlan|null>{
 const site=await db.prepare('SELECT id,state,created_at FROM sites WHERE id=? AND user_id=?').bind(siteId,userId).first<{id:string;state:string;created_at:string}>();if(!site)return null;
 // A payment time is floored to the second: never evaluate before the site existed.
 atMs=Math.max(atMs,Date.parse(site.created_at)||0);
 // During a membership freeze the frozen term is paused, not ended (M1): the
 // year is placed after the paused term as an unfreeze now would restore it, and
 // the unfreeze moves it again by the remaining frozen time (deferAnnualYearsBehindIdleSlot).
 const frozen=await membershipFreezeOpen(db,userId);
 const at=iso(atMs),[rows,coverageEndsAt,anchoring]=await Promise.all([ownCoverage(db,userId,siteId,excludeOrderId),currentCoverageEnd(db,userId,siteId,atMs,frozen?{projectFrozenAt:atMs}:{}),
  db.prepare("SELECT 1 FROM hosting_annual_activations WHERE site_id=? AND state='pending' AND order_id<>? LIMIT 1").bind(siteId,excludeOrderId).first()]);
 const live=LIVE_SITE_STATES.includes(site.state),gap=coverageGap(rows,at,coverageEndsAt);
 // A year still waiting for the site's opening/resumption (or one pulled forward
 // for a suspended/unopened site) is re-anchored then, which moves this year too.
 const pulled=frozen||!!anchoring||gap.later.length>0&&gap.coveredUntil===at&&!live;
 // While frozen the coverage end is that of the paused term (projected), so a
 // gap here is real coverage that ended (N3), never the freeze itself.
 for(const row of gap.later){row.starts_at=iso(Date.parse(row.starts_at)-gap.delta);row.ends_at=iso(Date.parse(row.ends_at)-gap.delta);}
 const own=chainFrom(rows,at);
 let startsAt=at,basis:AnnualBasis,viaMembership=false;
 if(own.end>at){startsAt=own.end;basis=own.source==='gift'?'after_gift':'extend_annual';}
 else if(coverageEndsAt&&coverageEndsAt>at){
  // Membership coverage, possibly followed without a gap by years already bought.
  startsAt=chainFrom(rows,coverageEndsAt).end;viaMembership=true;
  const ending=rows.filter(row=>row.ends_at===startsAt).map(row=>row.source);
  basis=ending.includes('annual')?'extend_annual':ending.includes('gift')?'after_gift':'after_membership';
 }else basis=site.state==='suspended'?'on_resume':live?'immediate':'on_activation';
 // Never overlap an annual year that is already bought (safety net; the chain above already follows it).
 const annualEnd=rows.filter(row=>row.source==='annual').reduce<string|null>((max,row)=>!max||row.ends_at>max?row.ends_at:max,null);
 if(annualEnd&&annualEnd>startsAt){startsAt=annualEnd;basis='extend_annual';}
 const activation=basis==='on_activation'?'create':basis==='on_resume'?'resume':null;
 // N1: a membership that renews automatically before the quoted start would keep
 // the slot, and the year then moves behind the renewed term; the date is an estimate.
 const renewing=viaMembership&&!!await db.prepare("SELECT 1 FROM subscriptions WHERE user_id=? AND state='active' AND auto_renew=1 AND membership_frozen_by IS NULL AND ends_at<=? LIMIT 1").bind(userId,startsAt).first();
 return {startsAt,endsAt:addHostingYear(startsAt),basis,estimated:!!activation||pulled||renewing,coverageEndsAt,activation};
}

/** Statements that move the site's annual years (and paid-but-not-granted
 * reservations) starting at or after `fromIso` by `deltaMs`. Every update is
 * guarded by the exact old values plus `guard`, so concurrent callers cannot
 * shift twice. */
async function shiftLaterYears(db:D1Database,siteId:string,excludeEntitlementId:string,excludeOrderId:string,fromIso:string,deltaMs:number,guard:string,guardBinds:unknown[]):Promise<D1PreparedStatement[]>{
 const statements:D1PreparedStatement[]=[];
 const later=(await db.prepare("SELECT id,starts_at,ends_at FROM hosting_entitlements WHERE site_id=? AND source='annual' AND state='active' AND id<>? AND starts_at>=?").bind(siteId,excludeEntitlementId,fromIso).all<{id:string;starts_at:string;ends_at:string}>()).results;
 for(const next of later)statements.push(db.prepare(`UPDATE hosting_entitlements SET starts_at=?,ends_at=? WHERE id=? AND starts_at=? AND ends_at=? ${guard}`).bind(iso(Date.parse(next.starts_at)+deltaMs),iso(Date.parse(next.ends_at)+deltaMs),next.id,next.starts_at,next.ends_at,...guardBinds));
 const reserved=(await db.prepare("SELECT f.id,f.starts_at,f.ends_at FROM payment_fulfillments f JOIN orders o ON o.id=f.order_id WHERE o.hosting_site_id=? AND f.order_id<>? AND f.state='pending' AND f.ends_at IS NOT NULL AND f.starts_at>=?").bind(siteId,excludeOrderId,fromIso).all<{id:string;starts_at:string;ends_at:string}>()).results;
 for(const next of reserved)statements.push(db.prepare(`UPDATE payment_fulfillments SET starts_at=?,ends_at=? WHERE id=? AND state='pending' AND starts_at=? AND ends_at=? ${guard}`).bind(iso(Date.parse(next.starts_at)+deltaMs),iso(Date.parse(next.ends_at)+deltaMs),next.id,next.starts_at,next.ends_at,...guardBinds));
 return statements;
}

/** Pulls annual years that were scheduled after a coverage gap forward to the
 * end of the site's actual coverage (now, when the site has none). Used by the
 * fulfilment (before a new year is placed) and by scheduled maintenance. A
 * pulled year of a suspended or unopened site is registered for re-anchoring
 * at the actual resumption/opening. Returns the number of rows moved. */
export async function rescheduleUncoveredAnnualYears(db:D1Database,userId:string,siteId:string,atMs=Date.now(),requestId:string|null=null):Promise<number>{
 const state=await accountState(db,userId);
 const site=await db.prepare('SELECT id,state,created_at FROM sites WHERE id=? AND user_id=?').bind(siteId,userId).first<{id:string;state:string;created_at:string}>();if(!site)return 0;
 // A freeze pauses the membership; its coverage has not ended (M1 / R-M3a). The
 // frozen term is therefore projected as paused (it still covers its sites), and
 // only a gap that has another cause (a revoked year, N3) is closed: independent
 // annual hosting keeps running during a freeze.
 const frozen=await membershipFreezeOpen(db,userId);
 const atTime=Math.max(atMs,Date.parse(site.created_at)||0),at=iso(atTime),[rows,coverageEndsAt]=await Promise.all([ownCoverage(db,userId,siteId),currentCoverageEnd(db,userId,siteId,atTime,frozen?{projectFrozenAt:atTime}:{})]);
 const gap=coverageGap(rows,at,coverageEndsAt);if(!gap.later.length||gap.delta<=0)return 0;
 const guardId=id('guard'),statements:D1PreparedStatement[]=[accountStateGuard(db,guardId,userId,state)],moves:number[]=[],first=gap.later[0],now=iso(Date.now());
 for(const row of gap.later){
  const starts=iso(Date.parse(row.starts_at)-gap.delta),ends=iso(Date.parse(row.ends_at)-gap.delta);
  moves.push(statements.length);statements.push(moveStatement(db,row,starts,ends));
  if(row.kind==='grant'&&row.orderId)statements.push(db.prepare("UPDATE hosting_annual_activations SET anchored_ends_at=?,updated_at=? WHERE order_id=? AND state='anchored' AND anchored_ends_at=?").bind(ends,now,row.orderId,row.ends_at));
 }
 const firstStarts=iso(Date.parse(first.starts_at)-gap.delta),firstEnds=iso(Date.parse(first.ends_at)-gap.delta);
 if(gap.coveredUntil===at&&!LIVE_SITE_STATES.includes(site.state)&&first.kind==='grant'&&first.orderId)
  statements.push(db.prepare(`INSERT INTO hosting_annual_activations(order_id,site_id,user_id,reason,state,provisional_starts_at,provisional_ends_at,created_at,updated_at)
   VALUES(?,?,?,?,'pending',?,?,?,?)
   ON CONFLICT(order_id) DO UPDATE SET reason=excluded.reason,state='pending',provisional_starts_at=excluded.provisional_starts_at,provisional_ends_at=excluded.provisional_ends_at,activated_at=NULL,anchored_ends_at=NULL,updated_at=excluded.updated_at`)
   .bind(first.orderId,siteId,userId,site.state==='suspended'?'resume':'create',firstStarts,firstEnds,now,now));
 // The guard makes the batch all-or-nothing on the state that was read, so the
 // audit row is written exactly once per move (N5).
 statements.push(auditWhen(db,'1',[],null,'hosting.annual.rescheduled','site',siteId,{coverageEndedAt:gap.coveredUntil,previousStartsAt:first.starts_at,startsAt:firstStarts,years:gap.later.length},requestId),
  db.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guardId));
 const results=await guardedBatch(db,statements);
 return moves.reduce((sum,index)=>sum+Number(results[index]?.meta?.changes||0),0);
}
function moveStatement(db:D1Database,row:OwnRow,starts:string,ends:string):D1PreparedStatement{
 return row.kind==='grant'
  ?db.prepare("UPDATE hosting_entitlements SET starts_at=?,ends_at=? WHERE id=? AND state='active' AND starts_at=? AND ends_at=?").bind(starts,ends,row.id,row.starts_at,row.ends_at)
  :db.prepare("UPDATE payment_fulfillments SET starts_at=?,ends_at=? WHERE id=? AND state='pending' AND starts_at=? AND ends_at=?").bind(starts,ends,row.id,row.starts_at,row.ends_at);
}

/** Requirement 不重复收取同一覆盖期 (M3, and M1 after an unfreeze): a paid annual
 * year must not run while a membership slot that could cover the same site sits
 * idle. When the account's slot has free capacity at the start of one of the
 * site's years starting at or after `fromMs` (an older site renewed and no longer
 * takes the slot back, a membership term was renewed or gifted, or an unfreeze
 * restored the membership), those years move later to the end of that idle
 * capacity, followed by the site's own fixed coverage (a gift). Only capacity no
 * other site uses is taken, so no site loses its slot. Never while a freeze is
 * open or a year waits for re-anchoring. The batch first checks that the whole
 * account is still in the state that was read (AnnualMoveConflict otherwise), so
 * a concurrent purchase, move or deferral of another site cannot interleave
 * (N4, N6), and the move is audited exactly once (N5). */
export async function deferAnnualYearsBehindIdleSlot(db:D1Database,userId:string,siteId:string,fromMs=Date.now(),requestId:string|null=null,options:{strict?:boolean}={}):Promise<number>{
 const state=await accountState(db,userId);
 const site=await db.prepare('SELECT id,state,created_at FROM sites WHERE id=? AND user_id=?').bind(siteId,userId).first<{id:string;state:string;created_at:string}>();if(!site)return 0;
 // R3-1: while a freeze is open nothing is checked, which is not "nothing to
 // move": a durable request (strict) stays queued until the freeze is over.
 if(await membershipFreezeOpen(db,userId)){if(options.strict)throw new DeferralPostponed();return 0;}
 // A year still waiting for its opening/resumption is skipped: its anchoring
 // queues a request from that year's start, which covers this site again.
 if(await db.prepare("SELECT 1 FROM hosting_annual_activations WHERE site_id=? AND state='pending' LIMIT 1").bind(siteId).first())return 0;
 const from=iso(fromMs),rows=await ownCoverage(db,userId,siteId);
 const later=rows.filter(row=>row.source==='annual'&&row.starts_at>=from).sort((a,b)=>a.starts_at<b.starts_at?-1:a.starts_at>b.starts_at?1:0);
 if(!later.length)return 0;
 const {idle,parked}=await allocate(db,userId);if(parked.has(siteId))return 0;
 const first=later[0],start=Date.parse(first.starts_at);if(!(Date.parse(site.created_at)<=start))return 0;
 const fixed=rows.filter(row=>!later.includes(row));
 // A year that continues the site's own annual/gift coverage is a 顺延 renewal
 // (requirement: 仍在有效期内续费的，从原托管到期时间顺延一年) and stays where it is;
 // only a year that was placed to follow membership coverage moves.
 if(fixed.some(row=>row.starts_at<first.starts_at&&row.ends_at>=first.starts_at))return 0;
 let end=start;
 for(let moved=true;moved;){
  moved=false;
  const segment=idle.find(item=>item.start<=end&&item.end>end&&item.free>0);if(segment){end=segment.end;moved=true;continue;}
  for(const row of fixed)if(Date.parse(row.starts_at)<=end&&Date.parse(row.ends_at)>end){end=Date.parse(row.ends_at);moved=true;}
 }
 const delta=end-start;if(delta<=0)return 0;
 const guardId=id('guard'),now=iso(Date.now()),statements:D1PreparedStatement[]=[accountStateGuard(db,guardId,userId,state)],moves:number[]=[];
 const anchored=new Map((await db.prepare("SELECT order_id,activated_at,anchored_ends_at FROM hosting_annual_activations WHERE site_id=? AND state='anchored' AND activated_at IS NOT NULL").bind(siteId).all<{order_id:string;activated_at:string;anchored_ends_at:string|null}>()).results.map(row=>[row.order_id,row]));
 let shift=delta,trimmedMs=0;
 for(const row of later){
  const startsMs=Date.parse(row.starts_at)+shift;let endsMs=Date.parse(row.ends_at)+shift;
  // R3-4: an anchored pay-first year still holds its pre-opening days (it ran from
  // the payment; anchoring only moved its end to opening + 1 year). Moved behind
  // the slot, it keeps one year from max(new start, opening), never more; years
  // chained after it follow its new end.
  const activation=row.kind==='grant'&&row.orderId?anchored.get(row.orderId):undefined;
  if(activation&&activation.anchored_ends_at===row.ends_at&&activation.activated_at>row.starts_at){
   const opened=Date.parse(activation.activated_at),from=Math.max(startsMs,opened),oneYear=Date.parse(addHostingYear(iso(from)))-from;
   const trimmed=Math.min(endsMs,from+oneYear);if(trimmed<endsMs){trimmedMs+=endsMs-trimmed;shift-=endsMs-trimmed;endsMs=trimmed;}
  }
  const starts=iso(startsMs),ends=iso(endsMs);
  moves.push(statements.length);statements.push(moveStatement(db,row,starts,ends));
  // N2: an anchored year's activation record follows the entitlement it describes.
  if(row.kind==='grant'&&row.orderId)statements.push(db.prepare("UPDATE hosting_annual_activations SET anchored_ends_at=?,updated_at=? WHERE order_id=? AND state='anchored' AND anchored_ends_at=?").bind(ends,now,row.orderId,row.ends_at));
 }
 const firstStarts=iso(start+delta);
 statements.push(auditWhen(db,'1',[],null,'hosting.annual.deferred','site',siteId,{previousStartsAt:first.starts_at,startsAt:firstStarts,slotCoveredUntil:iso(end),years:later.length,...(trimmedMs?{preOpeningDaysRemoved:Math.round(trimmedMs/864000)/100}:{})},requestId),
  db.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guardId));
 const results=await guardedBatch(db,statements);
 return moves.reduce((sum,index)=>sum+Number(results[index]?.meta?.changes||0),0);
}
/** Runs the deferral for every site of the account that has an annual year
 * starting at or after `fromMs`, oldest site first (the order slots are given
 * in). With `strict`, a site that could not be checked (a lost race or a D1
 * error) makes the call throw after the others ran, so a durable deferral
 * request stays queued for the next attempt. */
export async function deferAccountAnnualYears(db:D1Database,userId:string,fromMs=Date.now(),requestId:string|null=null,options:{strict?:boolean}={}):Promise<number>{
 const rows=(await db.prepare("SELECT h.site_id FROM hosting_entitlements h JOIN sites s ON s.id=h.site_id AND s.user_id=h.user_id WHERE h.user_id=? AND h.source='annual' AND h.state='active' AND h.starts_at>=? GROUP BY h.site_id ORDER BY MIN(s.created_at),h.site_id LIMIT 50").bind(userId,iso(fromMs)).all<{site_id:string}>()).results;
 let moved=0,failure:unknown=null;
 for(const row of rows)try{moved+=await deferAnnualYearsBehindIdleSlot(db,userId,row.site_id,fromMs,requestId,{strict:options.strict});}catch(error){failure??=error;}
 if(failure&&options.strict)throw failure;
 return moved;
}

/** Statement that records (or widens to an earlier start) the account's durable
 * deferral request; put it in the same batch as the event that can leave slot
 * capacity idle, guarded by `condition` when the event itself is conditional. */
export function deferralRequestStatement(db:D1Database,userId:string,fromIso:string,reason:string,condition='1',binds:unknown[]=[]):D1PreparedStatement{
 const now=iso(Date.now());
 // R3-2: every write gets a fresh random revision (below 2^53, exact in JS), so a
 // runner that read an older row never deletes a row re-inserted after it (ABA).
 return db.prepare(`INSERT INTO hosting_deferral_requests(user_id,from_at,reason,revision,created_at,updated_at) SELECT ?,?,?,random()&9007199254740991,?,? WHERE ${condition}
  ON CONFLICT(user_id) DO UPDATE SET from_at=MIN(hosting_deferral_requests.from_at,excluded.from_at),reason=excluded.reason,revision=random()&9007199254740991,updated_at=excluded.updated_at`).bind(userId,fromIso,reason,now,now,...binds);
}
/** Raised by a strict deferral that could not check the account yet (a freeze is
 * open); the durable request stays queued and is retried after the freeze (R3-1). */
export class DeferralPostponed extends Error{constructor(){super('DEFERRAL_POSTPONED');}}
/** Runs the account's pending deferral request; it is cleared only when every
 * site was checked and nothing re-queued it meanwhile (revision unchanged). */
export async function runDeferralRequest(db:D1Database,userId:string):Promise<number>{
 const row=await db.prepare('SELECT from_at,revision FROM hosting_deferral_requests WHERE user_id=?').bind(userId).first<{from_at:string;revision:number}>();if(!row)return 0;
 try{
  const moved=await deferAccountAnnualYears(db,userId,Date.parse(row.from_at),null,{strict:true});
  await db.prepare('DELETE FROM hosting_deferral_requests WHERE user_id=? AND revision=?').bind(userId,row.revision).run();
  return moved;
 }catch(error){
  try{await db.prepare('UPDATE hosting_deferral_requests SET attempts=attempts+1,updated_at=? WHERE user_id=?').bind(iso(Date.now()),userId).run();}catch{/* stays queued as it is */}
  throw error;
 }
}
/** Maintenance: retries queued deferral requests (oldest first). */
export async function processDeferralRequests(db:D1Database,limit=10):Promise<number>{
 const rows=(await db.prepare('SELECT user_id FROM hosting_deferral_requests ORDER BY updated_at LIMIT ?').bind(limit).all<{user_id:string}>()).results;
 let moved=0;for(const row of rows)try{moved+=await runDeferralRequest(db,row.user_id);}catch{/* next pass */}
 return moved;
}

type PendingActivation={order_id:string;site_id:string;user_id:string;reason:string;entitlement_id:string;starts_at:string;ends_at:string};
const PENDING_ACTIVATION="SELECT a.order_id,a.site_id,a.user_id,a.reason,e.id AS entitlement_id,e.starts_at,e.ends_at FROM hosting_annual_activations a JOIN hosting_entitlements e ON e.order_id=a.order_id AND e.site_id=a.site_id AND e.source='annual' AND e.state='active'";
const PENDING_GUARD="AND EXISTS(SELECT 1 FROM hosting_annual_activations WHERE order_id=? AND state='pending')";
/** Called when a site actually becomes connected (first opening or resumption).
 * Re-anchors a provisional annual year to that moment, moving any annual years
 * already chained after it by the same amount. Only ever extends; idempotent
 * through the pending-state guard, so concurrent callers cannot shift twice.
 * Each row is re-read inside the loop, since anchoring one year moves the next. */
export async function anchorAnnualActivations(db:D1Database,siteId:string,atMs=Date.now(),requestId:string|null=null):Promise<number>{
 const connected=`${PENDING_ACTIVATION} JOIN sites s ON s.id=a.site_id AND s.state='connected' WHERE a.site_id=? AND a.state='pending'`;
 const orders=(await db.prepare(`${connected} ORDER BY e.starts_at LIMIT 5`).bind(siteId).all<PendingActivation>()).results.map(row=>row.order_id);
 let anchored=0;const users=new Set<string>();
 for(const orderId of orders){
  const row=await db.prepare(`${connected} AND a.order_id=?`).bind(siteId,orderId).first<PendingActivation>();if(!row)continue;
  const at=iso(Math.max(atMs,Date.parse(row.starts_at))),target=addHostingYear(at),now=iso(Date.now()),statements:D1PreparedStatement[]=[];
  let endsAt=row.ends_at;
  if(target>row.ends_at){
   endsAt=target;
   statements.push(...await shiftLaterYears(db,siteId,row.entitlement_id,row.order_id,row.ends_at,Date.parse(target)-Date.parse(row.ends_at),PENDING_GUARD,[row.order_id]));
   statements.push(db.prepare(`UPDATE hosting_entitlements SET ends_at=? WHERE id=? AND ends_at=? ${PENDING_GUARD}`).bind(target,row.entitlement_id,row.ends_at,row.order_id));
  }
  statements.push(db.prepare("UPDATE hosting_annual_activations SET state='anchored',activated_at=?,anchored_ends_at=?,updated_at=? WHERE order_id=? AND state='pending'").bind(at,endsAt,now,row.order_id));
  const index=statements.length-1;
  // The audit commits with the anchoring itself (never a year moved without its record).
  const anchoredNow="EXISTS(SELECT 1 FROM hosting_annual_activations WHERE order_id=? AND state='anchored' AND activated_at=? AND updated_at=?)";
  statements.push(auditWhen(db,anchoredNow,[row.order_id,at,now],null,'hosting.annual.anchored','site',siteId,{orderId:row.order_id,reason:row.reason,activatedAt:at,previousEndsAt:row.ends_at,endsAt},requestId),
   // N2: an anchored year that started inside capacity a membership slot can now
   // cover (bought during a freeze, opened after the unfreeze) moves behind it.
   deferralRequestStatement(db,row.user_id,row.starts_at,'annual_anchored',anchoredNow,[row.order_id,at,now]));
  const results=await db.batch(statements);
  if(Number(results[index]?.meta?.changes||0)>0){anchored++;users.add(row.user_id);}
 }
 for(const userId of users)try{await runDeferralRequest(db,userId);}catch{/* maintenance retries the queued request */}
 return anchored;
}

/** A pay-first year counts from the site's first opening. While the site has
 * never opened, its provisional year must not run out (the customer would
 * lose a year never used): maintenance keeps it at least 30 days ahead, moving
 * the years chained after it. Anchoring at the opening still decides the end. */
export async function extendUnopenedAnnualYears(db:D1Database,nowMs=Date.now(),limit=10):Promise<{extended:number}>{
 const rows=(await db.prepare(`${PENDING_ACTIVATION} JOIN sites s ON s.id=a.site_id AND s.state IN ('pending','provisioning','awaiting_dns','error') WHERE a.state='pending' AND a.reason='create' AND e.ends_at<? AND NOT EXISTS(SELECT 1 FROM site_connections c WHERE c.site_id=a.site_id) ORDER BY e.ends_at LIMIT ?`).bind(iso(nowMs+30*86400000),limit).all<PendingActivation>()).results;
 let extended=0;
 for(const row of rows){
  const target=addHostingYear(iso(nowMs));if(target<=row.ends_at)continue;
  const now=iso(Date.now()),statements=[...await shiftLaterYears(db,row.site_id,row.entitlement_id,row.order_id,row.ends_at,Date.parse(target)-Date.parse(row.ends_at),PENDING_GUARD,[row.order_id]),
   db.prepare(`UPDATE hosting_entitlements SET ends_at=? WHERE id=? AND ends_at=? ${PENDING_GUARD}`).bind(target,row.entitlement_id,row.ends_at,row.order_id)];
  const index=statements.length-1,extendedRow="EXISTS(SELECT 1 FROM hosting_entitlements WHERE id=? AND ends_at=?) AND EXISTS(SELECT 1 FROM hosting_annual_activations WHERE order_id=? AND updated_at=?)";
  statements.push(db.prepare("UPDATE hosting_annual_activations SET provisional_ends_at=?,updated_at=? WHERE order_id=? AND state='pending' AND EXISTS(SELECT 1 FROM hosting_entitlements WHERE id=? AND ends_at=?)").bind(target,now,row.order_id,row.entitlement_id,target));
  statements.push(auditWhen(db,extendedRow,[row.entitlement_id,target,row.order_id,now],null,'hosting.annual.provisional_extended','site',row.site_id,{orderId:row.order_id,previousEndsAt:row.ends_at,endsAt:target}));
  const results=await db.batch(statements);
  if(Number(results[index]?.meta?.changes||0)>0)extended++;
 }
 return {extended};
}
