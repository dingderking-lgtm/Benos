import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { id } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole,rateLimit } from './auth';
import { processEmailOutbox } from './email';
import { purgeExpiredProvisioningSecrets,processPendingHostingJobs,reconcileHostingEntitlements } from './hosting';
import { refreshHostingPools } from './hosting-pools';
import { processServiceNotifications } from './notifications';
import { recordHostingRetention } from './hosting-retention';
import { reconcilePendingDomainChanges } from './hosting-management';
import { purgeNativePreviews } from './native-previews';
import { continuePendingNativePreviewJobs,purgeNativePreviewJobs } from './native-preview-jobs';
import { purgeUnreferencedDesignManifests } from '../lib/design-storage';
import { continuePublicationPreparations } from './publishing';
import { purgePackageUploads,continuePendingPackageUploads } from './package-uploads';
import { purgeManifestEdits,continuePendingManifestEdits } from './manifest-edits';
import { purgeDesignEditWorkspaces } from './design-editing';
import { reconcilePendingAlipay } from './alipay';

type Task={name:string;run:()=>Promise<unknown>};
export async function maintenance(env:Env,runtime:{tasks?:Task[]}={}){
 if(env.RECOVERY_MODE==='true')return {state:'recovery_mode' as const};
 const token=id('tick'),now=Date.now();
 const claim=await env.DB.prepare(`INSERT INTO maintenance_runs(name,lease_token,lease_expires_at_ms,last_started_at)
 VALUES('periodic',?,?,?) ON CONFLICT(name) DO UPDATE SET lease_token=excluded.lease_token,
 lease_expires_at_ms=excluded.lease_expires_at_ms,last_started_at=excluded.last_started_at
 WHERE maintenance_runs.lease_expires_at_ms<=? RETURNING name`).bind(token,now+15*60_000,new Date(now).toISOString(),now).first();
 if(!claim)return {state:'already_running' as const};
 const tasks=runtime.tasks??[
  {name:'email_delivery',run:()=>processEmailOutbox(env,{limit:10})},
  {name:'alipay_reconciliation',run:()=>reconcilePendingAlipay(env)},
  {name:'hosting_inventory',run:()=>refreshHostingPools(env)},
  {name:'service_notifications',run:()=>processServiceNotifications(env)},
  {name:'hosting_retention',run:()=>recordHostingRetention(env)},
  {name:'provisioning_secrets',run:()=>purgeExpiredProvisioningSecrets(env)},
  {name:'provisioning_jobs',run:()=>processPendingHostingJobs(env,10)},
  {name:'hosting_entitlements',run:()=>reconcileHostingEntitlements(env)},
  {name:'domain_changes',run:()=>reconcilePendingDomainChanges(env)},
  {name:'native_previews',run:()=>purgeNativePreviews(env)},
  {name:'native_preview_jobs',run:()=>continuePendingNativePreviewJobs(env)},
  {name:'native_preview_cleanup',run:async()=>{const result=await purgeNativePreviewJobs(env);return {...result,failed:result.uncertain};}},
  {name:'design_manifest_staging',run:async()=>{const result=await purgeUnreferencedDesignManifests(env);return {...result,failed:result.uncertain};}},
  {name:'publication_preparation',run:()=>continuePublicationPreparations(env)},
  {name:'package_upload_cleanup',run:async()=>{const result=await purgePackageUploads(env);return {...result,failed:result.uncertain};}},
  {name:'package_upload_processing',run:()=>continuePendingPackageUploads(env)},
  {name:'manifest_edit_cleanup',run:async()=>{const result=await purgeManifestEdits(env);return {...result,failed:result.uncertain};}},
  {name:'manifest_edit_processing',run:()=>continuePendingManifestEdits(env)},
  {name:'design_edit_cleanup',run:()=>purgeDesignEditWorkspaces(env)}
 ];
 const outcomes=await Promise.allSettled(tasks.map(task=>task.run()));
 const results=outcomes.map((outcome,index)=>{
  if(outcome.status==='rejected')return {task:tasks[index].name,state:'failed',counts:{}};
  const value=outcome.value,counts:Record<string,number>={};
  // Persist operational counters only, never provider errors, credentials or mail.
  if(value&&typeof value==='object')for(const [key,n] of Object.entries(value))if(/^[a-zA-Z]{1,40}$/.test(key)&&typeof n==='number'&&Number.isSafeInteger(n)&&n>=0)counts[key]=n;
  return {task:tasks[index].name,state:counts.failed?'partial':'succeeded',counts};
 });
 const result={state:results.some(r=>r.state!=='succeeded')?'partial':'succeeded',tasks:results};
 await env.DB.prepare("UPDATE maintenance_runs SET lease_token=NULL,lease_expires_at_ms=0,last_finished_at=?,last_result_json=? WHERE name='periodic' AND lease_token=?").bind(new Date().toISOString(),JSON.stringify(result),token).run();
 return result;
}
export const maintenanceRoutes=new Hono<App>();
maintenanceRoutes.use('*',requireAuth,requireRole('owner','admin'));
maintenanceRoutes.get('/',async c=>{
 const record=await c.env.DB.prepare("SELECT last_started_at,last_finished_at,last_result_json,lease_expires_at_ms FROM maintenance_runs WHERE name='periodic'").first<{last_started_at:string|null;last_finished_at:string|null;last_result_json:string|null;lease_expires_at_ms:number}>();
 const lastFinished=record?.last_finished_at??null;
 return ok(c,{lastStartedAt:record?.last_started_at??null,lastFinishedAt:lastFinished,running:(record?.lease_expires_at_ms??0)>Date.now(),lastResult:record?.last_result_json?JSON.parse(record.last_result_json):null,needsAttention:!lastFinished||Date.now()-Date.parse(lastFinished)>5*60_000});
});
maintenanceRoutes.post('/run',requireRole('owner'),async c=>{
 await body(c,z.object({}).strict());await rateLimit(c,'manual-maintenance',3,60,c.get('auth').user.id);
 await auditStatement(c.env.DB,c.get('auth').user.id,'maintenance.requested','system','periodic',{},c.get('requestId')).run();
 c.executionCtx.waitUntil(maintenance(c.env));return ok(c,{state:'queued'},202);
});
