import { z } from 'zod';
import type { Env } from '../env';
import { id,sha256 } from '../lib/crypto';
import { AppError,assert } from '../lib/errors';
import { grantCredit,getWallet } from './ledger';

export const creditGiftSchema=z.object({
 amountMicros:z.number().int().positive().max(100_000_000_000),
 expiresInDays:z.number().int().min(1).max(366).nullable(),
 reason:z.string().trim().min(3).max(500),requestKey:z.string().min(8).max(128),
}).strict();
export type CreditGiftInput=z.infer<typeof creditGiftSchema>;
export const creditGiftQuery=z.object({page:z.coerce.number().int().min(1).max(100000).default(1),limit:z.coerce.number().int().min(1).max(100).default(20)}).strict();
interface GiftRow {id:string;user_id:string;actor_id:string;request_key:string;payload_hash:string;amount_micros:number;expires_in_days:number|null;starts_at_ms:number;expires_at_ms:number|null;reason:string;state:'pending'|'completed';grant_id:string|null;created_at:string;completed_at:string|null;}
function view(row:GiftRow){return {id:row.id,userId:row.user_id,actorId:row.actor_id,requestKey:row.request_key,amountMicros:row.amount_micros,expiresInDays:row.expires_in_days,startsAtMs:row.starts_at_ms,expiresAtMs:row.expires_at_ms,reason:row.reason,state:row.state,grantId:row.grant_id,createdAt:row.created_at,completedAt:row.completed_at};}

async function authorize(env:Env,actorId:string,userId:string){
 const actor=await env.DB.prepare('SELECT role,status FROM users WHERE id=?').bind(actorId).first<{role:string;status:string}>();
 assert(actor?.status==='active'&&['owner','admin'].includes(actor.role),'FORBIDDEN','没有赠送额度权限',403);
 const user=await env.DB.prepare('SELECT role FROM users WHERE id=?').bind(userId).first<{role:string}>();
 assert(user,'MEMBER_NOT_FOUND','会员不存在',404);
 assert(actor.role==='owner'||user.role==='user','FORBIDDEN','不能修改同级管理员的额度',403);
}
export async function listCreditGifts(env:Env,actorId:string,userId:string,raw:unknown){
 await authorize(env,actorId,userId);const query=creditGiftQuery.parse(raw);
 const rows=await env.DB.prepare('SELECT * FROM admin_credit_gifts WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT ? OFFSET ?').bind(userId,query.limit+1,(query.page-1)*query.limit).all<GiftRow>();
 return {items:rows.results.slice(0,query.limit).map(view),page:query.page,limit:query.limit,hasMore:rows.results.length>query.limit};
}
export async function findCreditGift(env:Env,actorId:string,userId:string,requestKey:string){
 await authorize(env,actorId,userId);
 assert(requestKey.length>=8&&requestKey.length<=128,'VALIDATION','请求编号无效');
 const row=await env.DB.prepare('SELECT * FROM admin_credit_gifts WHERE actor_id=? AND request_key=? AND user_id=?').bind(actorId,requestKey,userId).first<GiftRow>();
 return {gift:row?view(row):null};
}
export async function giftAiCredit(env:Env,actorId:string,userId:string,raw:CreditGiftInput,nowMs=Date.now()){
 await authorize(env,actorId,userId);const input=creditGiftSchema.parse(raw),hash=await sha256(JSON.stringify([userId,input.amountMicros,input.expiresInDays,input.reason]));
 let gift=await env.DB.prepare('SELECT * FROM admin_credit_gifts WHERE actor_id=? AND request_key=?').bind(actorId,input.requestKey).first<GiftRow>();
 if(!gift){
  const giftId=id('creditgift'),created=new Date(nowMs).toISOString(),expires=input.expiresInDays===null?null:nowMs+input.expiresInDays*86400000;
  // A durable receipt fixes start/expiry on the first attempt. A conflicting or
  // delayed retry can never reset the validity period or create a second grant.
  await env.DB.batch([
   env.DB.prepare(`INSERT INTO admin_credit_gifts(id,user_id,actor_id,request_key,payload_hash,amount_micros,expires_in_days,starts_at_ms,expires_at_ms,reason,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(actor_id,request_key) DO NOTHING`).bind(giftId,userId,actorId,input.requestKey,hash,input.amountMicros,input.expiresInDays,nowMs,expires,input.reason,created),
   env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,created_at)
    SELECT ?,?,'member.credit_gift_requested','user',?,?,? WHERE EXISTS(SELECT 1 FROM admin_credit_gifts WHERE id=?)`).bind('audit_requested_'+giftId,actorId,userId,JSON.stringify({giftId,amountMicros:input.amountMicros,expiresInDays:input.expiresInDays,reason:input.reason}),created,giftId),
  ]);
  gift=await env.DB.prepare('SELECT * FROM admin_credit_gifts WHERE actor_id=? AND request_key=?').bind(actorId,input.requestKey).first<GiftRow>();
 }
 assert(gift&&gift.user_id===userId&&gift.payload_hash===hash,'IDEMPOTENCY_CONFLICT','相同请求编号不能用于不同赠送',409);
 if(gift.state!=='completed'){
  const guard=id('credit_gift_guard'),grantId='credit_'+gift.id,completed=new Date(nowMs).toISOString();
  // Permission, the ledger credit, completion receipt and audit commit together.
  // Supplier funds, orders and membership/top-up privileges are never modified.
  try{await grantCredit(env.DB,{id:grantId,userId,source:'gift',amountMicros:gift.amount_micros,startsAtMs:gift.starts_at_ms,...(gift.expires_at_ms===null?{}:{expiresAtMs:gift.expires_at_ms}),referenceId:'admin-gift:'+gift.id,nowMs}, {
   before:[env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(
    SELECT 1 FROM users a JOIN users u ON u.id=? JOIN admin_credit_gifts g ON g.user_id=u.id
    WHERE a.id=? AND a.status='active' AND (a.role='owner' OR (a.role='admin' AND u.role='user'))
    AND g.id=? AND g.actor_id=a.id AND g.payload_hash=?) THEN 1 ELSE 0 END`).bind(guard,userId,actorId,gift.id,hash)],
   after:[
    env.DB.prepare("UPDATE admin_credit_gifts SET state='completed',grant_id=?,completed_at=? WHERE id=? AND state='pending'").bind(grantId,completed,gift.id),
    env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,created_at)
     VALUES(?,?,'member.credit_gift','user',?,?,?) ON CONFLICT(id) DO NOTHING`).bind('audit_'+gift.id,actorId,userId,JSON.stringify({giftId:gift.id,grantId,source:'gift',amountMicros:gift.amount_micros,startsAtMs:gift.starts_at_ms,expiresAtMs:gift.expires_at_ms,reason:gift.reason}),completed),
    env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard),
   ],
  });}catch(error){
   if(String(error).includes('mutation_revision_ok')||String((error as Error)?.cause).includes('mutation_revision_ok'))throw new AppError('FORBIDDEN','赠送权限已变化，请刷新后重试',403);
   throw error;
  }
  gift=(await env.DB.prepare('SELECT * FROM admin_credit_gifts WHERE id=?').bind(gift.id).first<GiftRow>())!;
 }
 return {gift:view(gift),wallet:await getWallet(env.DB,userId,nowMs)};
}
