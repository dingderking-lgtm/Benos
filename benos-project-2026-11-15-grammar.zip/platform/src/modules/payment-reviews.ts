import { Hono } from 'hono';
import { z } from 'zod';
import type { Env, User } from '../env';
import { type App, body, ok } from '../lib/http';
import { AppError, assert } from '../lib/errors';
import { id, sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth, requireRole } from './auth';
import { loadPaymentConfiguration, stripeRequest, type PaymentConfig, type PaymentRuntime } from './payments';
import { debitProvider, releaseConfirmedUnused, settle } from './ledger';
import { caseCredits,adjustCaseCredit,creditAdjustmentSchema } from './credit-adjustments';
import { caseEntitlements,adjustCaseEntitlement,entitlementAdjustmentSchema,resumeEntitlementOperation } from './entitlement-adjustments';

type Json=Record<string,unknown>;
type CaseRow={id:string;kind:'refund'|'dispute'|'payment_review';provider_object_id:string;config_version_id:string|null;order_id:string|null;user_id:string|null;provider_state:string;amount_cents:number|null;currency:string|null;reason:string|null;review_state:string;financial_effect_state:string;revision:number;updated_at:string;snapshot_hash:string;credit_adjustment_micros:number;};
const record=(v:unknown):Json=>v!==null&&typeof v==='object'&&!Array.isArray(v)?v as Json:{};
const objectId=(v:unknown):string=>typeof v==='string'?v:String(record(v).id??'');
const iso=(runtime:PaymentRuntime)=>new Date(runtime.nowMs??Date.now()).toISOString();
function checkedId(v:unknown,pattern:RegExp):string {const value=objectId(v);assert(pattern.test(value),'PAYMENT_DATA_INVALID','支付记录标识无效',502);return value;}
function mode(config:PaymentConfig,value:Json){assert(value.livemode===(config.mode==='live'),'PAYMENT_MODE_MISMATCH','渠道记录与支付环境不匹配',502);}
function cents(value:unknown):number{assert(Number.isSafeInteger(value)&&Number(value)>=0,'PAYMENT_DATA_INVALID','渠道金额无效',502);return Number(value);}
function caseView(c:CaseRow){return {id:c.id,kind:c.kind,providerObjectId:c.provider_object_id,providerState:c.provider_state,amountCents:c.amount_cents,currency:c.currency,reason:c.reason,orderId:c.order_id,userId:c.user_id,reviewState:c.review_state,revision:c.revision,updatedAt:c.updated_at,financialEffectState:c.credit_adjustment_micros>0?'credit_adjusted':c.financial_effect_state,creditAdjustedMicros:c.credit_adjustment_micros};}
async function readCase(db:D1Database,caseId:string){const row=await db.prepare('SELECT * FROM financial_cases WHERE id=?').bind(caseId).first<CaseRow>();assert(row,'NOT_FOUND','审核记录不存在',404);return row;}

/** Exhaust a bounded provider list; an incomplete page is never treated as complete evidence. */
async function listProvider(config:PaymentConfig,path:string,params:URLSearchParams,runtime:PaymentRuntime):Promise<Json[]> {
 const rows:Json[]=[];params.set('limit','100');
 for(let page=0;page<10;page++){
  const result=await stripeRequest(config,`${path}?${params}`,'GET',undefined,undefined,runtime);
  assert(Array.isArray(result.data)&&typeof result.has_more==='boolean','PAYMENT_DATA_INVALID','渠道列表尚未确认',502);
  const entries=result.data.map(record);rows.push(...entries);if(!result.has_more)return rows;
  const cursor=objectId(entries.at(-1));assert(/^[A-Za-z0-9_]+$/.test(cursor),'PAYMENT_DATA_INVALID','渠道分页标识无效',502);params.set('starting_after',cursor);
 }
 throw new AppError('PAYMENT_RECONCILIATION_LIMIT','渠道记录较多，请联系运营分批核对',503);
}
/** Refunded-before-delivery payments require support review. Dispute status is
 * intentionally not used as an automatic suspension policy. */
export function assertUnrefundedCharge(charge:Json){
 assert(charge.refunded===false&&charge.amount_refunded===0,'PAYMENT_REFUNDED_BEFORE_FULFILLMENT','付款退款状态需人工核对，尚未发放新权益',409);
}
export async function assertInvoiceUnrefunded(config:PaymentConfig,invoiceId:string,amount:number,runtime:PaymentRuntime){
 const payments=await listProvider(config,'/v1/invoice_payments',new URLSearchParams({invoice:invoiceId,status:'paid'}),runtime);
 assert(payments.length===1,'INVOICE_PAYMENT_REVIEW','订阅付款来源需要人工核对，尚未发放新权益',409);
 const item=payments[0];mode(config,item);
 assert(objectId(item.invoice)===invoiceId&&item.status==='paid'&&item.amount_paid===amount&&item.currency==='usd'&&record(item.payment).type==='payment_intent','INVOICE_PAYMENT_REVIEW','订阅付款关联需要人工核对',409);
 const pi=checkedId(record(item.payment).payment_intent,/^pi_[A-Za-z0-9_]+$/),payment=await stripeRequest(config,`/v1/payment_intents/${pi}?expand%5B%5D=latest_charge`,'GET',undefined,undefined,runtime);mode(config,payment);
 const charge=record(payment.latest_charge);
 assert(objectId(payment.id)===pi&&payment.status==='succeeded'&&payment.currency==='usd'&&payment.amount_received===amount&&charge.paid===true&&charge.captured===true&&objectId(charge.payment_intent)===pi,'INVOICE_PAYMENT_REVIEW','订阅扣款需要人工核对',409);
 assertUnrefundedCharge(charge);
}
/** Modern Stripe invoices use invoice_payments, not legacy invoice.payment_intent. */
async function resolveOriginal(env:Env,config:PaymentConfig,chargeId:string,paymentIntentId:string,runtime:PaymentRuntime){
 const charge=await stripeRequest(config,`/v1/charges/${checkedId(chargeId,/^ch_[A-Za-z0-9_]+$/)}`,'GET',undefined,undefined,runtime);
 mode(config,charge);assert(objectId(charge.id)===chargeId,'PAYMENT_DATA_INVALID','渠道扣款标识不一致',502);
 const pi=checkedId(charge.payment_intent,/^pi_[A-Za-z0-9_]+$/);
 assert(!paymentIntentId||paymentIntentId===pi,'PAYMENT_DATA_INVALID','渠道扣款与付款标识不一致',502);
 const direct=await env.DB.prepare('SELECT id,user_id,config_version_id FROM orders WHERE payment_id=?').bind(`stripe:${pi}`).all<{id:string;user_id:string;config_version_id:string}>();
 let matches=direct.results,invoiceId:string|null=null;
 if(!matches.length){
  const payments=await listProvider(config,'/v1/invoice_payments',new URLSearchParams({'payment[type]':'payment_intent','payment[payment_intent]':pi}),runtime);
  for(const item of payments){mode(config,item);assert(record(item.payment).type==='payment_intent'&&objectId(record(item.payment).payment_intent)===pi,'PAYMENT_DATA_INVALID','发票付款关联不一致',502);
   const invoice=checkedId(item.invoice,/^in_[A-Za-z0-9_]+$/),order=await env.DB.prepare('SELECT id,user_id,config_version_id FROM orders WHERE payment_id=?').bind(`stripe:${invoice}`).first<{id:string;user_id:string;config_version_id:string}>();
   if(order){matches.push(order);invoiceId=invoice;}
  }
 }
 if(!matches.length){
  const intent=await stripeRequest(config,`/v1/payment_intents/${pi}`,'GET',undefined,undefined,runtime);mode(config,intent);
  assert(objectId(intent.id)===pi,'PAYMENT_DATA_INVALID','渠道付款标识不一致',502);
  const metadata=record(intent.metadata),hint=metadata.benos_order_id;
  if(typeof hint==='string'){
   const order=await env.DB.prepare('SELECT id,user_id,config_version_id,kind,payment_id FROM orders WHERE id=?').bind(hint).first<{id:string;user_id:string;config_version_id:string;kind:string;payment_id:string|null}>();
   if(order&&order.kind!=='subscription'&&(!order.payment_id||order.payment_id===`stripe:${pi}`)&&order.user_id===metadata.benos_user_id&&order.config_version_id===metadata.benos_config_id)matches.push(order);
  }
 }
 const unique=[...new Map(matches.map(o=>[o.id,o])).values()];
 // Do not infer ownership from a webhook metadata hint or ambiguous split payments.
 const order=unique.length===1&&unique[0].config_version_id===config.id?unique[0]:null;
 return {orderId:order?.id??null,userId:order?.user_id??null,invoiceId:order?invoiceId:null,paymentIntentId:pi,chargeId,chargeAmount:cents(charge.amount),currency:String(charge.currency??'')};
}

export function isFinancialEvent(type:string){return type==='charge.refunded'||['refund.created','refund.updated','refund.failed','charge.refund.updated','charge.dispute.created','charge.dispute.updated','charge.dispute.closed','charge.dispute.funds_withdrawn','charge.dispute.funds_reinstated'].includes(type);}
async function syncObject(env:Env,config:PaymentConfig,kind:'refund'|'dispute',providerObjectId:string,eventId:string,eventType:string,runtime:PaymentRuntime){
 checkedId(providerObjectId,kind==='refund'?/^re_[A-Za-z0-9_]+$/:/^(?:dp|du)_[A-Za-z0-9_]+$/);
 const caseId=`case_${kind}_${providerObjectId}`,prior=await env.DB.prepare('SELECT * FROM financial_cases WHERE id=?').bind(caseId).first<CaseRow>();
 assert(!prior||prior.config_version_id===config.id,'CASE_CONFIG_MISMATCH','此渠道记录已关联其他支付配置，请用原配置核对',503);
 const object=await stripeRequest(config,`/v1/${kind==='refund'?'refunds':'disputes'}/${providerObjectId}`,'GET',undefined,undefined,runtime);
 assert(objectId(object.id)===providerObjectId,'PAYMENT_DATA_INVALID','渠道事件对象不一致',502);
 if(kind==='dispute')mode(config,object);
 const source=await resolveOriginal(env,config,checkedId(object.charge,/^ch_[A-Za-z0-9_]+$/),objectId(object.payment_intent),runtime);
 const amount=cents(object.amount),currency=String(object.currency??''),state=String(object.status??'');
 assert(amount<=source.chargeAmount&&currency===source.currency&&/^[a-z_]{2,80}$/.test(state),'PAYMENT_DATA_INVALID','渠道金额或状态不一致',502);
 const snapshot={kind,providerObjectId,state,amountCents:amount,reason:typeof object.reason==='string'?object.reason:null,...source};
 const serialized=JSON.stringify(snapshot),hash=await sha256(serialized),time=iso(runtime),guard=id('case_guard');
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN NOT EXISTS(SELECT 1 FROM financial_cases WHERE id=?) AND ?=0 OR EXISTS(SELECT 1 FROM financial_cases WHERE id=? AND (revision=? OR snapshot_hash=?)) THEN 1 ELSE 0 END`).bind(guard,caseId,prior?.revision??0,caseId,prior?.revision??0,hash),
  env.DB.prepare(`INSERT INTO financial_cases(id,kind,provider_object_id,config_version_id,order_id,user_id,payment_intent_id,charge_id,invoice_id,provider_state,amount_cents,currency,reason,snapshot_json,snapshot_hash,created_at,updated_at)
   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(provider,kind,provider_object_id) DO UPDATE SET
   order_id=excluded.order_id,user_id=excluded.user_id,invoice_id=excluded.invoice_id,provider_state=excluded.provider_state,amount_cents=excluded.amount_cents,currency=excluded.currency,reason=excluded.reason,
   review_state=CASE WHEN financial_cases.snapshot_hash<>excluded.snapshot_hash THEN 'open' ELSE financial_cases.review_state END,
   revision=financial_cases.revision+CASE WHEN financial_cases.snapshot_hash<>excluded.snapshot_hash THEN 1 ELSE 0 END,
   snapshot_json=excluded.snapshot_json,snapshot_hash=excluded.snapshot_hash,updated_at=excluded.updated_at`).bind(caseId,kind,providerObjectId,config.id,source.orderId,source.userId,source.paymentIntentId,source.chargeId,source.invoiceId,state,amount,currency,snapshot.reason,serialized,hash,time,time),
  env.DB.prepare('INSERT INTO financial_case_events(case_id,event_id,event_type,provider_state,snapshot_json,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(case_id,event_id) DO NOTHING').bind(caseId,eventId,eventType,state,serialized,time),
  env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard),
 ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('CASE_REFRESH_CONFLICT','渠道状态正在更新，请重试核对',503);throw error;}
 return caseView(await readCase(env.DB,caseId));
}
export async function recordFinancialEvent(env:Env,config:PaymentConfig,eventId:string,eventType:string,object:Json,runtime:PaymentRuntime={}){
 if(eventType==='charge.refunded'){
  const chargeId=checkedId(object.id,/^ch_[A-Za-z0-9_]+$/),refunds=await listProvider(config,'/v1/refunds',new URLSearchParams({charge:chargeId}),runtime),items=[];
  for(const refund of refunds){assert(objectId(refund.charge)===chargeId,'PAYMENT_DATA_INVALID','退款扣款关联不一致',502);items.push(await syncObject(env,config,'refund',objectId(refund.id),eventId,eventType,runtime));}return items;
 }
 return [await syncObject(env,config,eventType.includes('dispute')?'dispute':'refund',objectId(object.id),eventId,eventType,runtime)];
}
export async function recordPaymentReview(env:Env,eventId:string,orderId:string|null,reason:string,runtime:PaymentRuntime={}){
 const time=iso(runtime);
 await env.DB.prepare(`INSERT INTO financial_cases(id,kind,provider_object_id,config_version_id,order_id,user_id,provider_state,reason,snapshot_json,snapshot_hash,created_at,updated_at)
 SELECT ?,'payment_review',?,e.config_version_id,?,o.user_id,'unreconciled',?,'{}','review',?,? FROM payment_events e LEFT JOIN orders o ON o.id=? WHERE e.provider='stripe' AND e.event_id=?
 ON CONFLICT(provider,kind,provider_object_id) DO NOTHING`).bind(`review_${eventId}`,eventId,orderId,reason,time,time,orderId,eventId).run();
}
export async function refreshFinancialCase(env:Env,caseId:string,runtime:PaymentRuntime={}){
 const row=await readCase(env.DB,caseId);assert(row.config_version_id&&row.kind!=='payment_review','CASE_MANUAL_REVIEW','此记录需要客服核对原订单；没有可直接查询的退款或争议对象',409);
 const provider=await env.DB.prepare('SELECT provider FROM financial_cases WHERE id=?').bind(caseId).first<{provider:string}>();
 if(provider?.provider==='alipay'){assert(row.kind==='refund','CASE_MANUAL_REVIEW','此支付宝记录需要核对原订单',409);await(await import('./alipay')).resumeAlipayRefund(env,row.provider_object_id,runtime);return caseView(await readCase(env.DB,caseId));}
 return syncObject(env,await loadPaymentConfiguration(env,row.config_version_id),row.kind,row.provider_object_id,id('refresh'),'operator.refresh',runtime);
}

const evidence=z.string().trim().min(10,'请填写至少 10 个字符的核对依据').max(2000),requestKey=z.string().min(8).max(128),reason=z.string().trim().min(3).max(500);
const scopesSchema=z.array(z.enum(['login','ai','topup','publish'])).min(1).max(4);
const decisionSchema=z.object({decision:z.enum(['acknowledged','needs_follow_up']),evidence,requestKey,expectedRevision:z.number().int().positive()}).strict();
const restrictionSchema=z.object({scopes:scopesSchema,reason,evidence,requestKey,expectedRevision:z.number().int().positive(),confirmImpact:z.literal(true),endsAt:z.string().datetime().nullable().default(null)}).strict();
const revokeSchema=z.object({reason,evidence,requestKey,confirmImpact:z.literal(true)}).strict();
type ActionInput={action:'acknowledged'|'needs_follow_up'|'restrict'|'revoke';evidence:string;requestKey:string;expectedRevision?:number;scopes?:string[];reason?:string;endsAt?:string|null;restrictionId?:string};
/** Immutable idempotent action plus CAS guard and permissions all commit in one D1 batch. */
export async function applyCaseAction(env:Env,caseId:string,actor:User,input:ActionInput,nowMs=Date.now()){
 await readCase(env.DB,caseId);
 assert(['owner','admin','support'].includes(actor.role),'FORBIDDEN','没有审核权限',403);
 const restriction=input.action==='restrict'||input.action==='revoke';assert(!restriction||actor.role==='owner'||actor.role==='admin','FORBIDDEN','只有管理员可以限制或恢复权限',403);
 const payload={caseId,action:input.action,evidence:input.evidence,expectedRevision:input.expectedRevision??null,scopes:[...new Set(input.scopes??[])].sort(),reason:input.reason??null,endsAt:input.endsAt??null,restrictionId:input.restrictionId??null};
 const time=new Date(nowMs).toISOString(),nonce=id('attempt'),actionId=id('case_action'),guard=id('case_guard'),hash=await sha256(JSON.stringify(payload));
 assert(!input.endsAt||input.endsAt>time,'VALIDATION','解除时间必须晚于当前时间');
 const stmt=(sql:string,...values:(string|number|null)[])=>env.DB.prepare(sql).bind(...values);
 const fresh=`EXISTS(SELECT 1 FROM financial_case_actions WHERE id=?1 AND attempt_nonce=?2)`;
 const statements=[stmt(`INSERT INTO financial_case_actions(id,case_id,actor_id,request_key,payload_hash,attempt_nonce,action,evidence,payload_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)
 ON CONFLICT(actor_id,request_key) DO UPDATE SET payload_hash=CASE WHEN financial_case_actions.payload_hash=excluded.payload_hash THEN financial_case_actions.payload_hash ELSE NULL END`,actionId,caseId,actor.id,input.requestKey,hash,nonce,input.action,input.evidence,JSON.stringify(payload),time),
 stmt(`INSERT INTO mutation_guards(id,permitted) SELECT ?3,CASE WHEN NOT ${fresh} OR EXISTS(SELECT 1 FROM financial_cases f WHERE f.id=?4 AND (?5 IS NULL OR f.revision=?5)
 AND (?6=0 OR EXISTS(SELECT 1 FROM users u WHERE u.id=f.user_id AND u.id<>?7 AND u.role<>'owner' AND (?8='owner' OR u.role='user')))
 AND (?9 IS NULL OR EXISTS(SELECT 1 FROM financial_case_restrictions r WHERE r.case_id=f.id AND r.restriction_id=?9))) THEN 1 ELSE 0 END`,actionId,nonce,guard,caseId,input.expectedRevision??null,restriction?1:0,actor.id,actor.role,input.restrictionId??null)];
 if(input.action==='acknowledged'||input.action==='needs_follow_up')statements.push(stmt(`UPDATE financial_cases SET review_state=?3,revision=revision+1,updated_at=?4 WHERE id=?5 AND ${fresh}`,actionId,nonce,input.action==='acknowledged'?'acknowledged':'open',time,caseId));
 if(input.action==='restrict')for(const scope of payload.scopes){const restrictionId=id('rst');statements.push(
  stmt(`INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,ends_at,actor_id,created_at) SELECT ?3,user_id,?4,?5,?6,?7,?8,?6 FROM financial_cases WHERE id=?9 AND ${fresh}`,actionId,nonce,restrictionId,scope,input.reason!,time,input.endsAt??null,actor.id,caseId),
  stmt(`INSERT INTO financial_case_restrictions(case_id,restriction_id,action_id) SELECT ?3,?4,?1 WHERE ${fresh}`,actionId,nonce,caseId,restrictionId));}
 if(input.action==='revoke')statements.push(stmt(`UPDATE user_restrictions SET revoked_at=COALESCE(revoked_at,?3) WHERE id=?4 AND ${fresh}`,actionId,nonce,time,input.restrictionId!));
 if(restriction)statements.push(stmt(`UPDATE financial_cases SET revision=revision+1,updated_at=?3 WHERE id=?4 AND ${fresh}`,actionId,nonce,time,caseId));
 statements.push(stmt(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?3,?4,?5,'financial_case',?6,?7,?8,?9 WHERE ${fresh}`,actionId,nonce,id('audit'),actor.id,`payment.case.${input.action}`,caseId,JSON.stringify(payload),input.requestKey,time),stmt('DELETE FROM mutation_guards WHERE id=?',guard));
 try{await env.DB.batch(statements);}catch(error){if(String(error).includes('financial_case_actions.payload_hash'))throw new AppError('IDEMPOTENCY_CONFLICT','该请求标识已用于其他审核内容',409);if(String(error).includes('mutation_revision_ok'))throw new AppError('CASE_CHANGED','记录已更新或权限不符合，请刷新后重试',409);throw error;}
 return caseView(await readCase(env.DB,caseId));
}

export const financialRoutes=new Hono<App>();
for(const path of ['/payment-cases','/payment-cases/*','/image-jobs','/image-jobs/*','/budgets/:provider/debit','/budgets/:provider/debits'])financialRoutes.use(path,requireAuth,requireRole('owner','admin','support'));
export async function importLegacyPaymentReviews(env:Env,actor:User){
 assert(actor.role==='owner','FORBIDDEN','只有平台所有者可以迁移旧审核记录',403);
 const results=await env.DB.batch([
  env.DB.prepare(`INSERT INTO financial_cases(id,kind,provider_object_id,config_version_id,order_id,user_id,provider_state,reason,review_state,snapshot_json,snapshot_hash,created_at,updated_at)
   SELECT r.id,'payment_review',r.event_id,e.config_version_id,r.order_id,o.user_id,'unreconciled',r.reason,CASE WHEN r.state='resolved' THEN 'acknowledged' ELSE 'open' END,'{}','legacy',r.created_at,r.created_at
   FROM payment_review_cases r LEFT JOIN payment_events e ON e.event_id=r.event_id AND e.provider='stripe' LEFT JOIN orders o ON o.id=r.order_id
   WHERE NOT EXISTS(SELECT 1 FROM financial_cases f WHERE f.kind='payment_review' AND f.provider_object_id=r.event_id) ORDER BY r.created_at LIMIT 100 ON CONFLICT DO NOTHING`),
  auditStatement(env.DB,actor.id,'payment.case.import_legacy','financial_case',null,{batchLimit:100}),
 ]);
 const remaining=await env.DB.prepare("SELECT COUNT(*) n FROM payment_review_cases r WHERE NOT EXISTS(SELECT 1 FROM financial_cases f WHERE f.kind='payment_review' AND f.provider_object_id=r.event_id)").first<{n:number}>();return {importedCount:results[0].meta.changes,remainingCount:remaining?.n??0};
}
financialRoutes.post('/payment-cases/import-legacy',requireRole('owner'),async c=>{await body(c,z.object({}).strict());return ok(c,await importLegacyPaymentReviews(c.env,c.get('auth').user));});
financialRoutes.get('/payment-cases',async c=>{
 const state=c.req.query('state')??'open';assert(['open','acknowledged','all'].includes(state),'VALIDATION','审核状态无效');
 const result=await c.env.DB.prepare(`SELECT * FROM financial_cases ${state==='all'?'':'WHERE review_state=?'} ORDER BY updated_at DESC LIMIT 100`).bind(...(state==='all'?[]:[state])).all<CaseRow>();
 const legacy=await c.env.DB.prepare("SELECT r.id,r.event_id AS eventId,r.order_id AS orderId,o.user_id AS userId,r.reason,r.state,r.created_at AS createdAt FROM payment_review_cases r LEFT JOIN orders o ON o.id=r.order_id WHERE NOT EXISTS(SELECT 1 FROM financial_cases f WHERE f.kind='payment_review' AND f.provider_object_id=r.event_id) ORDER BY r.created_at LIMIT 100").all();
 return ok(c,{items:result.results.map(caseView),legacyItems:legacy.results});
});
financialRoutes.get('/payment-cases/:id',async c=>{
 const row=await readCase(c.env.DB,c.req.param('id'));
 const [events,actions,restrictions]=await Promise.all([
  c.env.DB.prepare('SELECT event_id AS eventId,event_type AS eventType,provider_state AS providerState,created_at AS createdAt FROM financial_case_events WHERE case_id=? ORDER BY created_at DESC LIMIT 100').bind(row.id).all(),
  c.env.DB.prepare('SELECT id,actor_id AS actorId,action,evidence,created_at AS createdAt,payload_json FROM financial_case_actions WHERE case_id=? ORDER BY created_at DESC LIMIT 100').bind(row.id).all<Json>(),
  c.env.DB.prepare('SELECT r.id,r.scope,r.reason,r.starts_at AS startsAt,r.ends_at AS endsAt,r.revoked_at AS revokedAt FROM user_restrictions r JOIN financial_case_restrictions l ON l.restriction_id=r.id WHERE l.case_id=? ORDER BY r.created_at DESC').bind(row.id).all(),
 ]);
 return ok(c,{case:caseView(row),events:events.results,decisions:actions.results.map(a=>{const p=record(JSON.parse(String(a.payload_json)));return {id:a.id,actorId:a.actorId,action:a.action,evidence:a.evidence,createdAt:a.createdAt,scopes:p.scopes,reason:p.reason,restrictionId:p.restrictionId};}),restrictions:restrictions.results});
});
financialRoutes.post('/payment-cases/:id/reconcile',requireRole('owner','admin'),async c=>{await body(c,z.object({}).strict());await auditStatement(c.env.DB,c.get('auth').user.id,'payment.case.refresh','financial_case',c.req.param('id'),{},c.get('requestId')).run();return ok(c,await refreshFinancialCase(c.env,c.req.param('id')));});
financialRoutes.post('/payment-cases/:id/decision',async c=>{const input=await body(c,decisionSchema);return ok(c,await applyCaseAction(c.env,c.req.param('id'),c.get('auth').user,{...input,action:input.decision}));});
financialRoutes.get('/payment-cases/:id/credits',async c=>ok(c,await caseCredits(c.env,c.req.param('id'))));
financialRoutes.post('/payment-cases/:id/credits',requireRole('owner'),async c=>ok(c,await adjustCaseCredit(c.env,c.req.param('id'),c.get('auth').user,await body(c,creditAdjustmentSchema))));
financialRoutes.get('/payment-cases/:id/entitlements',async c=>ok(c,await caseEntitlements(c.env,c.req.param('id'))));
financialRoutes.post('/payment-cases/:id/entitlements',requireRole('owner'),async c=>ok(c,await adjustCaseEntitlement(c.env,c.req.param('id'),c.get('auth').user,await body(c,entitlementAdjustmentSchema))));
financialRoutes.post('/payment-cases/:id/entitlements/:operationId/retry',requireRole('owner'),async c=>{await body(c,z.object({}).strict());return ok(c,await resumeEntitlementOperation(c.env,c.req.param('id'),c.req.param('operationId'),c.get('auth').user));});
financialRoutes.post('/payment-cases/:id/restrictions',requireRole('owner','admin'),async c=>{const input=await body(c,restrictionSchema);return ok(c,await applyCaseAction(c.env,c.req.param('id'),c.get('auth').user,{...input,action:'restrict'}));});
financialRoutes.post('/payment-cases/:id/restrictions/:restrictionId/revoke',requireRole('owner','admin'),async c=>{const input=await body(c,revokeSchema);return ok(c,await applyCaseAction(c.env,c.req.param('id'),c.get('auth').user,{...input,action:'revoke',restrictionId:c.req.param('restrictionId')}));});
financialRoutes.get('/image-jobs',requireRole('owner','admin'),async c=>{const rows=await c.env.DB.prepare('SELECT id,user_id,project_id,reservation_id,state,usage_json,error_code,provider_request_id AS provider_response_id,created_at FROM image_jobs ORDER BY created_at DESC LIMIT 100').all();return ok(c,{items:rows.results});});
financialRoutes.post('/image-jobs/:id/reconcile',requireRole('owner'),async c=>{
 const input=await body(c,z.discriminatedUnion('outcome',[z.object({outcome:z.literal('confirmed_unused'),evidence}),z.object({outcome:z.literal('confirmed_cost'),actualMicros:z.number().int().min(0).max(100_000_000_000),evidence})]));
 const job=await c.env.DB.prepare('SELECT id,reservation_id,state,error_code FROM image_jobs WHERE id=?').bind(c.req.param('id')).first<{id:string;reservation_id:string|null;state:string;error_code:string|null}>();
 assert(job?.reservation_id,'NOT_FOUND','未找到需核对的图片用量记录',404);assert(job.state==='uncertain'||job.error_code==='COST_RECONCILED','INVALID_STATE','该任务不需要人工费用核对',409);
 await auditStatement(c.env.DB,c.get('auth').user.id,'image.reconciliation_requested','image_job',job.id,input,c.get('requestId')).run();
 const reservation=input.outcome==='confirmed_unused'?await releaseConfirmedUnused(c.env.DB,job.reservation_id):await settle(c.env.DB,{reservationId:job.reservation_id,actualMicros:input.actualMicros});
 await c.env.DB.prepare("UPDATE image_jobs SET state='failed',error_code='COST_RECONCILED',updated_at=? WHERE id=? AND state IN ('uncertain','failed')").bind(new Date().toISOString(),job.id).run();return ok(c,{reconciled:true,reservationState:reservation.state});
});
financialRoutes.post('/budgets/:provider/debit',requireRole('owner'),async c=>{
 const input=await body(c,z.object({amountMicros:z.number().int().positive().max(100_000_000_000),referenceId:z.string().trim().min(3).max(200),reason,confirmedProviderWithdrawal:z.literal(true)}).strict());
 assert(/^[a-zA-Z0-9_-]{1,100}$/.test(c.req.param('provider')),'VALIDATION','额度池名称无效');
 await auditStatement(c.env.DB,c.get('auth').user.id,'budget.withdrawal_requested','provider',c.req.param('provider'),input,c.get('requestId')).run();
 return ok(c,await debitProvider(c.env.DB,{id:id('debit'),providerId:c.req.param('provider'),amountMicros:input.amountMicros,referenceId:input.referenceId,reason:input.reason,actorId:c.get('auth').user.id}),201);
});
financialRoutes.get('/budgets/:provider/debits',requireRole('owner','admin'),async c=>{const result=await c.env.DB.prepare('SELECT * FROM provider_debits WHERE provider_id=? ORDER BY created_at_ms DESC LIMIT 100').bind(c.req.param('provider')).all();return ok(c,{items:result.results});});
