import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { z } from 'zod';
import type { Env } from '../env';
import { AppError,assert } from '../lib/errors';
import type { HpanelConfiguration } from './hosting-hostinger';

export type HostingDnsTarget={type:'A'|'AAAA';value:string};
const targetsSchema=z.array(z.object({type:z.enum(['A','AAAA']),value:z.string()})).min(1).max(8);
type Job={id:string;siteId:string;domain:string;leaseToken:string};
/** Canonical public IP literals; no DNS lookup or URL inference. */
export function normalizedHostingIp(input:string):string|null {
 if(input.includes(':')){
  try{const ip=new URL('http://['+input+']/').hostname.slice(1,-1).toLowerCase();return /^[23][0-9a-f:]+$/.test(ip)&&!/^2001:(?:db8|0):/.test(ip)?ip:null;}catch{return null;}
 }
 if(!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(input))return null;
 const p=input.split('.').map(Number);if(p.some(v=>v>255)||[0,10,127].includes(p[0])||p[0]>=224||p[0]===169&&p[1]===254||p[0]===172&&p[1]>=16&&p[1]<=31||p[0]===192&&[0,168].includes(p[1])||p[0]===100&&p[1]>=64&&p[1]<=127||p[0]===198&&[18,19].includes(p[1]))return null;
 return p.join('.');
}
function parseTargets(raw:string):HostingDnsTarget[]{
 let value:unknown;try{value=JSON.parse(raw);}catch{throw new AppError('HOSTING_DNS_TARGETS_REQUIRED','平台需先核对该主机的域名解析目标',409);}
 const parsed=targetsSchema.safeParse(value);
 assert(parsed.success&&parsed.data.every(row=>normalizedHostingIp(row.value)&&row.value.includes(':')===(row.type==='AAAA')),'HOSTING_DNS_TARGETS_REQUIRED','平台需先核对该主机的域名解析目标',409);
 return parsed.data;
}
/** Explicit operator targets take precedence, so an operator can repair stale
 * provider DNS without altering a customer's immutable provisioning identity. */
export async function readHostingDnsTargets(env:Env,siteId:string):Promise<{records:HostingDnsTarget[];source:'operator'|'provider-zone'}|null>{
 const pool=await env.DB.prepare('SELECT d.records_json FROM hosting_allocations a JOIN hosting_pool_dns_targets d ON d.pool_id=a.pool_id WHERE a.site_id=?').bind(siteId).first<{records_json:string}>();
 if(pool)return {records:parseTargets(pool.records_json),source:'operator'};
 const site=await env.DB.prepare('SELECT records_json FROM hosting_site_dns_targets WHERE site_id=?').bind(siteId).first<{records_json:string}>();
 return site?{records:parseTargets(site.records_json),source:'provider-zone'}:null;
}
async function zoneRecords(token:string,domain:string):Promise<unknown[]|null>{
 assert(token.length>=16&&!/[\r\n]/.test(token),'HOSTINGER_TOKEN_REQUIRED','托管供应商凭据尚未配置',503);
 let response:Response;try{response=await fetchWithoutRedirect('https://developers.hostinger.com/api/dns/v1/zones/'+encodeURIComponent(domain),{headers:{Authorization:'Bearer '+token,Accept:'application/json'},signal:AbortSignal.timeout(12000)});}catch{throw new AppError('HOSTINGER_RESULT_UNCERTAIN','解析目标暂未读取完成，请稍后继续',502);}
 if(response.status===404||response.status===403)return null;
 assert(response.ok,response.status===401?'HOSTINGER_AUTH_REQUIRED':response.status===429?'HOSTINGER_RATE_LIMITED':'HOSTINGER_RESULT_UNCERTAIN','解析目标暂未读取完成，请稍后继续',502);
 const raw=await response.text();assert(raw.length<=2*1048576,'HOSTINGER_RESPONSE_INVALID','解析目标响应无效',502);
 let value:any;try{value=JSON.parse(raw);}catch{throw new AppError('HOSTINGER_RESPONSE_INVALID','解析目标响应无效',502);}
 const rows=Array.isArray(value)?value:value?.data;assert(Array.isArray(rows)&&rows.length<=10000,'HOSTINGER_RESPONSE_INVALID','解析目标响应无效',502);return rows;
}
const host=(name:string)=>name.toLowerCase().replace(/\.$/,'');
/** A subdomain's parent zone comes from the DNS SOA, not a guessed eTLD+1. */
async function parentZone(domain:string):Promise<string|null>{
 let response:Response;try{response=await fetchWithoutRedirect('https://cloudflare-dns.com/dns-query?name='+encodeURIComponent(domain)+'&type=SOA',{headers:{accept:'application/dns-json'},signal:AbortSignal.timeout(10000)});}catch{return null;}
 if(!response.ok)return null;const raw=await response.text();if(raw.length>65536)return null;
 let data:any;try{data=JSON.parse(raw);}catch{return null;}if(data?.Status!==0&&data?.Status!==3)return null;
 const rows=[...(Array.isArray(data.Answer)?data.Answer:[]),...(Array.isArray(data.Authority)?data.Authority:[])];
 const names=rows.filter((row:any)=>row?.type===6&&typeof row.name==='string').map((row:any)=>host(row.name)).filter((name:string)=>name.includes('.')&&domain.endsWith('.'+name));
 return names.sort((a:string,b:string)=>b.length-a.length)[0]??null;
}
/** Only exact A/AAAA records are candidates. Wildcards, CNAMEs and disabled or
 * private addresses do not prove where this site's origin should be reached. */
function exactTargets(rows:unknown[],zone:string,domain:string):HostingDnsTarget[]{
 const targets:HostingDnsTarget[]=[];
 for(const item of rows){
  assert(item&&typeof item==='object'&&!Array.isArray(item),'HOSTINGER_RESPONSE_INVALID','解析目标响应无效',502);
  const row=item as Record<string,unknown>;if(typeof row.name!=='string'||typeof row.type!=='string')continue;
  const name=host(row.name),full=name==='@'?zone:name===zone||name.endsWith('.'+zone)?name:name+'.'+zone;
  if(full!==domain)continue;
  if(row.type==='CNAME'&&Array.isArray(row.records)&&row.records.some((r:any)=>r&&!(r.is_disabled??r.isDisabled)))return [];
  if(row.type!=='A'&&row.type!=='AAAA')continue;
  assert(Array.isArray(row.records),'HOSTINGER_RESPONSE_INVALID','解析目标响应无效',502);
  for(const record of row.records){
   assert(record&&typeof record==='object'&&!Array.isArray(record),'HOSTINGER_RESPONSE_INVALID','解析目标响应无效',502);
   const disabled=record.is_disabled??record.isDisabled;assert(disabled===undefined||typeof disabled==='boolean','HOSTINGER_RESPONSE_INVALID','解析目标响应无效',502);
   if(disabled)continue;
   const ip=typeof record.content==='string'?normalizedHostingIp(record.content):null;
   if(!ip||ip.includes(':')!==(row.type==='AAAA'))return [];
   if(!targets.some(target=>target.type===row.type&&target.value===ip))targets.push({type:row.type,value:ip});
  }
 }
 return targets.length<=8?targets:[];
}
/** A newly provisioned website's official DNS zone gives candidate targets.
 * No DNS mutation occurs here. A matching public DNS answer and SSL certificate
 * still cannot substitute for the signed bootstrap identity check. */
export async function ensureHostedSiteDnsTargets(env:Env,config:HpanelConfiguration,token:string,job:Job):Promise<HostingDnsTarget[]>{
 const existing=await readHostingDnsTargets(env,job.siteId);if(existing)return existing.records;
 const owned=await env.DB.prepare(`SELECT 1 FROM hosting_provider_intents i JOIN provisioning_jobs j ON j.id=i.job_id
  WHERE i.job_id=? AND i.site_id=? AND i.domain=? AND i.account_username=? AND i.hosting_order_id=?
  AND i.website_create_attempted=1 AND i.website_ready=1 AND j.lease_token=? AND j.lease_until>?`).bind(job.id,job.siteId,job.domain,config.accountUsername,config.hostingOrderId,job.leaseToken,new Date().toISOString()).first();
 assert(owned,'HOSTINGER_INTENT_CONFLICT','解析目标与本次新建网站身份不符',409);
 let zone=job.domain,rows=await zoneRecords(token,zone);
 if(rows===null){const parent=await parentZone(job.domain);if(parent){zone=parent;rows=await zoneRecords(token,zone);}}
 const targets=rows?exactTargets(rows,zone,job.domain):[];
 assert(targets.length>0,'HOSTING_DNS_TARGETS_REQUIRED','未取得该网站的解析目标，请平台核对该主机的域名解析配置',409);
 const stamp=new Date().toISOString();
 const saved=await env.DB.prepare(`INSERT INTO hosting_site_dns_targets(site_id,job_id,config_version_id,records_json,source_zone,observed_at)
  SELECT i.site_id,i.job_id,i.config_version_id,?,?,? FROM hosting_provider_intents i JOIN provisioning_jobs j ON j.id=i.job_id
  WHERE i.job_id=? AND i.site_id=? AND j.lease_token=? AND j.lease_until>?
  ON CONFLICT(site_id) DO NOTHING RETURNING site_id`).bind(JSON.stringify(targets),zone,stamp,job.id,job.siteId,job.leaseToken,stamp).first();
 if(!saved){const raced=await readHostingDnsTargets(env,job.siteId);assert(raced,'HOSTING_LEASE_LOST','安装任务已由其他工作进程接管',409);return raced.records;}
 return targets;
}
