import { Hono } from 'hono';
import { z } from 'zod';
import { type App,body,ok } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id,encryptSecret,decryptSecret } from '../lib/crypto';
import { probeModelAccess,safeProbeFailure } from '../lib/integration-probe';
import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole,rateLimit } from './auth';
import type { Env } from '../env';
import { testHostingConfiguration } from './hosting';
import { discoverHostinger,hostingerDiscoveryInput } from './hosting-connect';
import { probeEmailConfiguration } from './email';
import { imageConfigSchema } from './images';
import { verifiedImagePricing } from '../lib/image-billing';
import { TEXT_BILLING_PROFILES,verifiedTextPricing } from './ai-billing';
import { validateAlipayConfiguration,probeAlipayConfiguration } from './alipay';
import { assertIntegrationCapability,functionalTestQuote,runFunctionalTest,listFunctionalTests,operationsBudgetInput,listOperationsBudgets,setOperationsBudget,functionalTestInput,functionalReconciliationInput,reconcileFunctionalTest } from './integration-tests';
export { imageConfigSchema } from './images';

export type IntegrationRow={id:string;kind:string;name:string;provider:string;version:number;status:string;public_config_json:string;secret_ciphertext:string|null;test_status:string;tested_at:string|null;created_at:string;capability_test_id?:string|null;capability_tested_at?:string|null;secret_hint?:string|null;deleted_at?:string|null;deleted_by?:string|null;deleted_reason?:string|null};
// Masked identifier (D3): the last 4 characters of the primary credential, kept only
// when the credential is long enough (>= 12) that 4 characters reveal little, and only
// when they are printable ASCII. Computed once at creation; never derived on read.
const PRIMARY_SECRET_KEYS=['apiKey','secretKey','hostingerApiToken','signingSecret'] as const;
export function secretHint(secret:Record<string,string>):string|null{const value=PRIMARY_SECRET_KEYS.map(key=>secret[key]).find(v=>typeof v==='string'&&v.length>0);if(!value)return null;const chars=Array.from(value);if(chars.length<12)return null;const tail=chars.slice(-4).join('');return /^[\x21-\x7e]{4}$/.test(tail)?tail:null;}
export function publicIntegration(row:IntegrationRow){return {id:row.id,kind:row.kind,name:row.name,provider:row.provider,version:row.version,status:row.status,publicConfig:JSON.parse(row.public_config_json),hasSecret:!!row.secret_ciphertext,secretHint:row.secret_ciphertext?row.secret_hint??null:null,testStatus:row.test_status,testedAt:row.tested_at,createdAt:row.created_at,capabilityTestId:row.capability_test_id??null,capabilityTestedAt:row.capability_tested_at??null};}
export async function integrationSecret(env:Env,row:IntegrationRow):Promise<Record<string,string>>{
 assert(!row.deleted_at,'CONFIG_DELETED','此服务配置已删除',409);
 assert(row.secret_ciphertext,'INTEGRATION_NOT_CONFIGURED','服务密钥尚未配置',503);
 return JSON.parse(await decryptSecret(row.secret_ciphertext,env.ENCRYPTION_KEY,row.id));
}
export function publicHttpsEndpoint(value:string):string {
 let url:URL;try{url=new URL(value);}catch{throw new AppError('INVALID_ENDPOINT','请输入有效的 HTTPS 服务地址');}
 const host=url.hostname.toLowerCase();
 assert(url.protocol==='https:'&&!url.username&&!url.password&&!url.hash&&!url.search&&(!url.port||url.port==='443'),'INVALID_ENDPOINT','服务地址必须使用 HTTPS，不含账号、查询参数或自定义端口');
 assert(host.includes('.')&&!/^[\d.]+$/.test(host)&&!host.includes(':')&&!/(^|\.)(localhost|local|internal|lan|test|invalid|example)$/.test(host),'INVALID_ENDPOINT','服务地址必须是公开域名');
 return url.toString().replace(/\/$/,'');
}
const secretValue=z.string().min(8).max(8192);
const microRate=z.number().int().min(0).max(1_000_000_000);
export const textProviderSchema=z.enum(['openai','deepseek','moonshot']);
export const textConfigSchema=z.object({baseUrl:z.string(),model:z.string().regex(/^[a-zA-Z0-9._:/-]{1,200}$/),provider:textProviderSchema.optional(),protocol:z.enum(['responses','chat-completions']),providerPoolId:z.string().regex(/^[a-zA-Z0-9_-]{1,100}$/),inputMicrosPerMillion:microRate,cachedInputMicrosPerMillion:microRate,outputMicrosPerMillion:microRate,contextTokens:z.number().int().min(1024).max(2_000_000),maxOutputTokens:z.number().int().min(16).max(384_000),pricingConfirmedAt:z.string().datetime(),billingProfile:z.enum(['unverified',...TEXT_BILLING_PROFILES]).default('unverified'),cacheTtl:z.enum(['30m','12h','5m','1h','automatic']).default('30m'),stream:z.boolean().optional()}).strict();

/** Resolve exactly the selected configuration. A disabled selection never falls
 * back to a different vendor or cost profile. Legacy clients get a stable default. */
export async function resolveActiveTextConfiguration(env:Env,configId?:string):Promise<IntegrationRow>{
 if(configId!==undefined)assert(/^[A-Za-z0-9_-]{1,120}$/.test(configId),'INVALID_CONFIG','请选择有效的 AI 模型',400);
 const row=await env.DB.prepare(`SELECT * FROM integration_configs WHERE kind='text' AND deleted_at IS NULL AND status='active' AND test_status='passed' ${configId!==undefined?'AND id=?':''} ORDER BY created_at DESC,id DESC LIMIT 1`).bind(...(configId!==undefined?[configId]:[])).first<IntegrationRow>();
 assert(row,'AI_NOT_CONFIGURED',configId!==undefined?'所选 AI 模型已停用或尚未配置，请重新选择':'AI 设计服务尚未配置',503);return row;
}
export function textConfigurationPricing(row:Pick<IntegrationRow,'provider'|'public_config_json'>):z.infer<typeof textConfigSchema>{
 const parsed=textConfigSchema.parse(JSON.parse(row.public_config_json));
 assert(parsed.provider===undefined||parsed.provider===row.provider,'AI_BILLING_UNVERIFIED','AI 供应商与费用配置不一致',503);
 const provider=textProviderSchema.safeParse(row.provider);assert(provider.success,'AI_BILLING_UNVERIFIED','该供应商尚未完成收费适配',503);
 const pricing={...parsed,provider:provider.data};verifiedTextPricing(pricing,row.provider);return pricing;
}
export function validateConfiguration(kind:string,provider:string,config:unknown,secret:unknown):{config:Record<string,unknown>;secret:Record<string,string>} {
 let configSchema:z.ZodType,secretSchema:z.ZodType;
 if(kind==='text'||kind==='image'){
  assert((kind==='text'?['openai','deepseek','moonshot','openai-compatible']:['openai','openai-compatible']).includes(provider),'PROVIDER_UNSUPPORTED','请选择支持的 API 协议提供方');
  configSchema=kind==='text'?textConfigSchema:imageConfigSchema;secretSchema=z.object({apiKey:secretValue}).strict();
 }else if(kind==='payment'){
  if(provider==='alipay'){const checked=validateAlipayConfiguration(config,secret);return {config:checked.publicConfig,secret:checked.secret};}
  assert(provider==='stripe','PROVIDER_UNSUPPORTED','当前支持支付宝和历史 Stripe 支付适配器');
  configSchema=z.object({mode:z.enum(['test','live']),apiVersion:z.literal('2026-10-28.endive')}).strict();
  secretSchema=z.object({secretKey:z.string().regex(/^sk_(test|live)_[a-zA-Z0-9]+$/),webhookSecret:z.string().regex(/^whsec_[a-zA-Z0-9]+$/)}).strict();
 }else if(kind==='hosting'){
  assert(provider==='benos-bridge','PROVIDER_UNSUPPORTED','请选择 Benos 托管连接器');
  configSchema=z.object({adapter:z.enum(['hostinger-hpanel','managed-server']),endpoint:z.string().optional(),keyId:z.string().regex(/^[a-zA-Z0-9_-]{1,80}$/).optional(),deploymentMode:z.enum(['registered-php-bridge','hostinger-tus-bootstrap']),hostingOrderId:z.number().int().positive().safe().optional(),accountUsername:z.string().regex(/^u[0-9]{3,20}$/).optional(),cmsReleaseObjectKey:z.string().regex(/^private\/cms-releases\/[A-Za-z0-9/_-]+\.zip$/).max(300).optional(),cmsReleaseSha256:z.string().regex(/^[a-f0-9]{64}$/).optional(),cmsReleaseSize:z.number().int().positive().max(48*1048576).optional()}).strict();secretSchema=z.object({signingSecret:z.string().min(32).max(512).optional(),hostingerApiToken:z.string().min(16).max(8192).optional()}).strict();
 }else if(kind==='email'){
  assert(provider==='resend','PROVIDER_UNSUPPORTED','当前支持 Resend 邮件适配器');
  configSchema=z.object({fromEmail:z.string().email(),fromName:z.string().trim().min(1).max(80).default('Benos'),replyTo:z.string().email().optional()}).strict();secretSchema=z.object({apiKey:z.string().regex(/^re_[a-zA-Z0-9_-]{8,}$/)}).strict();
 }else {throw new AppError('PROVIDER_UNSUPPORTED','该类服务适配器尚未配置，不能启用',409);}
 const c=configSchema.safeParse(config),s=secretSchema.safeParse(secret);
 assert(c.success&&s.success,'INVALID_CONFIG','服务配置或密钥格式不正确');
 const parsed=c.data as Record<string,unknown>,privateData=s.data as Record<string,string>;
 if(parsed.baseUrl){parsed.baseUrl=publicHttpsEndpoint(String(parsed.baseUrl));const origins:Record<string,string>={openai:'https://api.openai.com/v1',deepseek:'https://api.deepseek.com',moonshot:'https://api.moonshot.ai/v1'};if(origins[provider])assert(parsed.baseUrl===origins[provider],'INVALID_ENDPOINT',`该供应商的已适配接口地址必须是 ${origins[provider]}`);}
 if(parsed.endpoint)parsed.endpoint=publicHttpsEndpoint(String(parsed.endpoint));
 if(kind==='hosting'&&parsed.adapter==='hostinger-hpanel')assert(parsed.hostingOrderId&&parsed.accountUsername&&privateData.hostingerApiToken,'INVALID_CONFIG','请填写托管订单、账号和官方 API 凭据');
 if(kind==='hosting'&&parsed.deploymentMode==='registered-php-bridge')assert(parsed.endpoint&&parsed.keyId&&privateData.signingSecret,'INVALID_CONFIG','请填写部署桥地址、密钥编号和签名密钥');
 if(kind==='hosting'&&parsed.deploymentMode==='hostinger-tus-bootstrap')assert(parsed.adapter==='hostinger-hpanel'&&parsed.cmsReleaseObjectKey&&parsed.cmsReleaseSha256&&parsed.cmsReleaseSize,'INVALID_CONFIG','自动安装需配置已核验的私有 CMS 发行包');
 if(kind==='text')assert(Number(parsed.inputMicrosPerMillion)>0&&Number(parsed.outputMicrosPerMillion)>0&&Number(parsed.maxOutputTokens)<Number(parsed.contextTokens)&&Number(parsed.cachedInputMicrosPerMillion)<=Number(parsed.inputMicrosPerMillion),'INVALID_PRICING','请填写有效价格及模型上下文上限');
 if(kind==='text'){
  assert(parsed.provider===undefined||parsed.provider===provider,'INVALID_CONFIG','模型配置与供应商不一致');
  if(provider!=='openai-compatible')parsed.provider=provider;
  if(parsed.billingProfile!=='unverified')verifiedTextPricing(parsed as unknown as Parameters<typeof verifiedTextPricing>[0],provider);
 }
 if(kind==='image'&&(parsed.billingContract as {kind?:string})?.kind==='metered-reserve-v1')verifiedImagePricing(parsed,provider);
 if(kind==='payment'&&provider==='stripe')assert(privateData.secretKey.startsWith('sk_'+parsed.mode+'_'),'INVALID_CONFIG','支付密钥与测试/正式模式不一致');
 return {config:parsed,secret:privateData};
}

export const integrationRoutes=new Hono<App>();
integrationRoutes.use('*',requireAuth,requireRole('owner','admin'));
export const integrationDeleteInput=z.object({reason:z.string().trim().min(3).max(500)}).strict();
/** Soft deletion keeps cost evidence and references; its database guard prevents
 * deletion while any paid operation can still dispatch or needs reconciliation. */
export async function deleteAiConfiguration(env:Env,actorId:string,configId:string,input:z.infer<typeof integrationDeleteInput>){
 input=integrationDeleteInput.parse(input);
 const actor=await env.DB.prepare('SELECT role,status FROM users WHERE id=?').bind(actorId).first<{role:string;status:string}>();
 assert(actor?.role==='owner'&&actor.status==='active','FORBIDDEN','只有平台所有者可以删除 API 配置',403);
 const row=await env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(configId).first<IntegrationRow>();assert(row,'NOT_FOUND','服务配置不存在',404);
 assert(row.kind==='text'||row.kind==='image','DELETE_KIND_UNSUPPORTED','此处仅支持删除代码和图片 API 配置',409);
 if(row.deleted_at)return {deleted:true,id:row.id,alreadyDeleted:true};
 assert(row.status!=='active','CONFIG_ACTIVE','请先停用此配置，再删除',409);
 const guard=id('delete_config_guard'),now=new Date().toISOString();
 try{
  const results=await env.DB.batch([
   env.DB.prepare("INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM users WHERE id=? AND role='owner' AND status='active') THEN 1 ELSE 0 END").bind(guard,actorId),
   env.DB.prepare('UPDATE integration_configs SET deleted_at=?,deleted_by=?,deleted_reason=?,secret_ciphertext=NULL,secret_hint=NULL WHERE id=? AND deleted_at IS NULL RETURNING id').bind(now,actorId,input.reason,row.id),
   env.DB.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,created_at) SELECT ?,deleted_by,'integration.delete','integration',id,json_object('kind',kind,'provider',provider,'version',version,'reason',deleted_reason),deleted_at FROM integration_configs WHERE id=? AND deleted_at IS NOT NULL ON CONFLICT(id) DO NOTHING").bind('audit_delete_'+row.id,row.id),
   env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard),
  ]);
  return {deleted:true,id:row.id,alreadyDeleted:results[1].results.length===0};
 }catch(error){
  const message=String(error)+' '+String((error as Error)?.cause??'');
  if(message.includes('config_in_use'))throw new AppError('CONFIG_IN_USE','此配置仍有关联任务或待核对费用，请处理完成后再删除',409);
  if(message.includes('config_active'))throw new AppError('CONFIG_ACTIVE','请先停用此配置，再删除',409);
  if(message.includes('mutation_revision_ok'))throw new AppError('FORBIDDEN','删除权限已变化，请刷新后重试',403);
  throw error;
 }
}
integrationRoutes.delete('/:id',requireRole('owner'),async c=>ok(c,await deleteAiConfiguration(c.env,c.get('auth').user.id,c.req.param('id'),await body(c,integrationDeleteInput))));
integrationRoutes.post('/hostinger/discover',requireRole('owner'),async c=>{
 await rateLimit(c,'hostinger-discovery',10,15*60,c.get('auth').user.id);
 const input=await body(c,hostingerDiscoveryInput),result=await discoverHostinger(input.hostingerApiToken);
 await auditStatement(c.env.DB,c.get('auth').user.id,'hosting.connection.discover','integration',null,{count:result.items.length,scope:result.scope},c.get('requestId')).run();
 return ok(c,result);
});
integrationRoutes.get('/operations-budgets',async c=>ok(c,await listOperationsBudgets(c.env)));
integrationRoutes.put('/operations-budgets/:provider',requireRole('owner'),async c=>ok(c,await setOperationsBudget(c.env,c.get('auth').user,c.req.param('provider'),await body(c,operationsBudgetInput))));
integrationRoutes.get('/:id/functional-test-quote',async c=>ok(c,await functionalTestQuote(c.env,c.req.param('id'))));
integrationRoutes.get('/:id/functional-tests',async c=>ok(c,await listFunctionalTests(c.env,c.req.param('id'))));
integrationRoutes.post('/:id/functional-tests',requireRole('owner'),async c=>{await rateLimit(c,'functional-test',10,3600,c.get('auth').user.id);return ok(c,await runFunctionalTest(c.env,c.get('auth').user,c.req.param('id'),await body(c,functionalTestInput)));});
integrationRoutes.post('/:id/functional-tests/:testId/reconcile',requireRole('owner'),async c=>ok(c,await reconcileFunctionalTest(c.env,c.get('auth').user,c.req.param('id'),c.req.param('testId'),await body(c,functionalReconciliationInput))));
integrationRoutes.get('/',async c=>{const rows=await c.env.DB.prepare('SELECT * FROM integration_configs WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 200').all<IntegrationRow>();return ok(c,{items:rows.results.map(publicIntegration)});});
integrationRoutes.get('/:id',async c=>{const row=await c.env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(c.req.param('id')).first<IntegrationRow>();assert(row,'NOT_FOUND','服务配置不存在',404);return ok(c,{...publicIntegration(row),deletedAt:row.deleted_at??null,deletedBy:row.deleted_by??null,deletionReason:row.deleted_reason??null});});
integrationRoutes.post('/',requireRole('owner'),async c=>{
 const input=await body(c,z.object({kind:z.enum(['text','image','payment','hosting','email','dns']),name:z.string().trim().min(1).max(80),provider:z.string().min(1).max(50),publicConfig:z.unknown(),secret:z.unknown().optional(),secretSourceConfigId:z.string().regex(/^[A-Za-z0-9_-]{1,120}$/).optional()}).strict());
 let privateInput=input.secret;
 if(input.secretSourceConfigId){
  assert((input.kind==='text'||input.kind==='image')&&input.secret===undefined,'INVALID_CONFIG','请选择复用已有密钥或填写新密钥，不能同时使用');
  const source=await c.env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(input.secretSourceConfigId).first<IntegrationRow>();
  assert(!source?.deleted_at,'CONFIG_DELETED','此服务配置已删除，不能复用密钥',409);
  assert(source&&(source.kind==='text'||source.kind==='image')&&source.provider===input.provider&&source.secret_ciphertext,'INVALID_SECRET_SOURCE','请选择相同服务商已保存的 AI 密钥',409);
  // Compatible is a protocol label, not an identity for a credential recipient.
  // Reuse must stay on the same normalized API base, including its path.
  if(input.provider==='openai-compatible'){
   const sourceConfig=JSON.parse(source.public_config_json),targetConfig=input.publicConfig as {baseUrl?:unknown}|null;
   assert(typeof sourceConfig?.baseUrl==='string'&&typeof targetConfig?.baseUrl==='string','INVALID_SECRET_SOURCE','复用自定义服务密钥需要相同的 API 地址',409);
   assert(publicHttpsEndpoint(sourceConfig.baseUrl)===publicHttpsEndpoint(targetConfig.baseUrl),'INVALID_SECRET_SOURCE','自定义服务密钥仅可复用于相同的 API 地址',409);
  }
  const stored=await integrationSecret(c.env,source);privateInput={apiKey:stored.apiKey};
 }
 const checked=validateConfiguration(input.kind,input.provider,input.publicConfig,privateInput),configId=id('cfg'),actor=c.get('auth').user.id,now=new Date().toISOString();
 const secret=await encryptSecret(JSON.stringify(checked.secret),c.env.ENCRYPTION_KEY,configId);
 const sourceGuard=id('reuse_config_guard');
 try{
 await c.env.DB.batch([...(input.secretSourceConfigId?[c.env.DB.prepare("INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM integration_configs WHERE id=? AND deleted_at IS NULL AND secret_ciphertext IS NOT NULL) THEN 1 ELSE 0 END").bind(sourceGuard,input.secretSourceConfigId)]:[]),c.env.DB.prepare(`INSERT INTO integration_configs(id,kind,name,provider,version,public_config_json,secret_ciphertext,secret_hint,created_by,created_at) SELECT ?,?,?,?,COALESCE(MAX(version),0)+1,?,?,?,?,? FROM integration_configs WHERE kind=? AND name=?`).bind(configId,input.kind,input.name,input.provider,JSON.stringify(checked.config),secret,secretHint(checked.secret),actor,now,input.kind,input.name),auditStatement(c.env.DB,actor,'integration.create','integration',configId,{kind:input.kind,provider:input.provider,...(input.secretSourceConfigId?{secretSourceConfigId:input.secretSourceConfigId}:{})},c.get('requestId')),...(input.secretSourceConfigId?[c.env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(sourceGuard)]:[])]);
 }catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('CONFIG_DELETED','原服务配置已删除，不能复用密钥',409);throw error;}
 return ok(c,publicIntegration((await c.env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(configId).first<IntegrationRow>())!),201);
});
// The name is what customers see in the model picker, so the owner may change it at any time.
// It is not part of pricing, quotes or the secret, and a deleted configuration stays immutable.
integrationRoutes.put('/:id/name',requireRole('owner'),async c=>{
 const input=await body(c,z.object({name:z.string().trim().min(1).max(80)}).strict()),configId=c.req.param('id');
 const row=await c.env.DB.prepare('SELECT id,name FROM integration_configs WHERE id=? AND deleted_at IS NULL').bind(configId).first<{id:string;name:string}>();
 assert(row,'NOT_FOUND','配置不存在',404);
 if(row.name!==input.name)await c.env.DB.batch([c.env.DB.prepare('UPDATE integration_configs SET name=? WHERE id=? AND deleted_at IS NULL').bind(input.name,configId),auditStatement(c.env.DB,c.get('auth').user.id,'integration.renamed','integration',configId,{from:row.name,to:input.name},c.get('requestId'))]);
 return ok(c,{id:configId,name:input.name});
});
integrationRoutes.post('/:id/test',requireRole('owner'),async c=>{
 await body(c,z.object({}).strict());
 await rateLimit(c,'integration-test',20,15*60);
 const row=await c.env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(c.req.param('id')).first<IntegrationRow>();assert(row,'NOT_FOUND','服务配置不存在',404);assert(!row.deleted_at,'CONFIG_DELETED','此服务配置已删除',409);
 assert(row.status!=='active','CONFIG_ACTIVE','请创建新版本进行测试，避免改变正在使用的配置',409);
 const checked=validateConfiguration(row.kind,row.provider,JSON.parse(row.public_config_json),await integrationSecret(c.env,row));
 let outcome='passed',failure:ReturnType<typeof safeProbeFailure>|undefined;
 try {
  if(row.kind==='text'||row.kind==='image'){
   await probeModelAccess({baseUrl:String(checked.config.baseUrl),model:String(checked.config.model),listing:row.provider==='deepseek'||row.provider==='moonshot'},checked.secret.apiKey);
  }else if(row.kind==='payment'){
   if(row.provider==='alipay'){await probeAlipayConfiguration(checked.config,checked.secret);}else{
   const response=await fetchWithoutRedirect('https://api.stripe.com/v1/balance',{headers:{Authorization:`Bearer ${checked.secret.secretKey}`,'Stripe-Version':String(checked.config.apiVersion)},signal:AbortSignal.timeout(15_000)});
   assert(response.ok,'PROBE_FAILED','支付商户访问验证失败',409);const data=await boundedProbeJson(response);assert(data.livemode===(checked.config.mode==='live'),'PROBE_FAILED','支付环境不匹配',409);}
  }else if(row.kind==='hosting'){
   const result=await testHostingConfiguration(c.env,row,{signingSecret:checked.secret.signingSecret,hostingerApiToken:checked.secret.hostingerApiToken});assert(result.passed,'PROBE_FAILED','托管连接器验证未通过',409);
  }else if(row.kind==='email'){
   await probeEmailConfiguration(checked.config,checked.secret);
  }else {throw new AppError('PROBE_UNAVAILABLE','连接器验证尚未完成，暂不能启用',409);}
 }catch(error){outcome='failed';failure=safeProbeFailure(error);}
 const diagnostics=failure?{failureCode:failure.code,...(failure.upstreamStatus!==undefined?{upstreamStatus:failure.upstreamStatus}:{}),...(failure.networkReason?{networkReason:failure.networkReason}:{})}:{};
 const now=new Date().toISOString();await c.env.DB.batch([c.env.DB.prepare("UPDATE integration_configs SET test_status=?,tested_at=?,status=CASE WHEN ?='passed' THEN 'tested' ELSE 'draft' END WHERE id=? AND status<>'active'").bind(outcome,now,outcome,row.id),auditStatement(c.env.DB,c.get('auth').user.id,'integration.test','integration',row.id,{outcome,scope:'access_only_no_generation',...diagnostics},c.get('requestId'))]);
 if(failure)throw new AppError(failure.code,failure.message,409);
 return ok(c,{tested:true,scope:'access_only',billableGenerationTested:false});
});
integrationRoutes.post('/:id/activate',requireRole('owner'),async c=>{
 await body(c,z.object({}).strict());const row=await c.env.DB.prepare('SELECT * FROM integration_configs WHERE id=?').bind(c.req.param('id')).first<IntegrationRow>();assert(row,'NOT_FOUND','服务配置不存在',404);assert(!row.deleted_at,'CONFIG_DELETED','此服务配置已删除',409);
 assert(row.test_status==='passed'&&row.tested_at&&Date.now()-Date.parse(row.tested_at)<24*3600_000,'TEST_REQUIRED','请先在 24 小时内完成服务访问验证',409);
 await assertIntegrationCapability(c.env.DB,row.id,row.kind);
 const guard=id('capability_guard'),cutoff=new Date(Date.now()-24*3600_000).toISOString();
 try{await c.env.DB.batch([
  c.env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM integration_configs c WHERE c.id=? AND c.deleted_at IS NULL AND c.test_status='passed' AND c.tested_at>?) THEN 1 ELSE 0 END`).bind(guard,row.id,cutoff),
  ...(row.kind==='hosting'?[]:(row.kind==='text'||row.kind==='image')?[c.env.DB.prepare("UPDATE integration_configs SET status='disabled' WHERE kind=? AND provider=? AND status='active' AND id<>?").bind(row.kind,row.provider,row.id)]:[c.env.DB.prepare("UPDATE integration_configs SET status='disabled' WHERE kind=? AND status='active' AND id<>?").bind(row.kind,row.id)]),c.env.DB.prepare("UPDATE integration_configs SET status='active' WHERE id=?").bind(row.id),auditStatement(c.env.DB,c.get('auth').user.id,'integration.activate','integration',row.id,{kind:row.kind,provider:row.provider,version:row.version},c.get('requestId')),c.env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
 ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('TEST_REQUIRED','验证状态已变化，请刷新后重新验证',409);throw error;}return ok(c,{active:true});
});

async function boundedProbeJson(response:Response):Promise<Record<string,unknown>>{
 const reader=response.body?.getReader();assert(reader,'PROBE_FAILED','服务响应为空',409);let size=0;const chunks:Uint8Array[]=[];
 while(true){const chunk=await reader.read();if(chunk.done)break;size+=chunk.value.byteLength;if(size>1024*1024){await reader.cancel();throw new AppError('PROBE_FAILED','服务响应超出验证上限',409);}chunks.push(chunk.value);}
 const bytes=new Uint8Array(size);let at=0;for(const chunk of chunks){bytes.set(chunk,at);at+=chunk.byteLength;}
 let data:unknown;try{data=JSON.parse(new TextDecoder().decode(bytes));}catch{throw new AppError('PROBE_FAILED','服务响应格式无效',409);}
 assert(data!==null&&typeof data==='object'&&!Array.isArray(data),'PROBE_FAILED','服务响应格式无效',409);return data as Record<string,unknown>;
}
integrationRoutes.post('/:id/disable',requireRole('owner'),async c=>{
 const input=await body(c,z.object({reason:z.string().trim().min(3).max(500)}));const row=await c.env.DB.prepare('SELECT deleted_at FROM integration_configs WHERE id=?').bind(c.req.param('id')).first<{deleted_at:string|null}>();assert(row,'NOT_FOUND','服务配置不存在',404);assert(!row.deleted_at,'CONFIG_DELETED','此服务配置已删除',409);const result=await c.env.DB.batch([c.env.DB.prepare("UPDATE integration_configs SET status='disabled' WHERE id=? RETURNING id").bind(c.req.param('id')),auditStatement(c.env.DB,c.get('auth').user.id,'integration.disable','integration',c.req.param('id'),{reason:input.reason},c.get('requestId'))]);assert(result[0].results.length,'NOT_FOUND','服务配置不存在',404);return ok(c,{disabled:true});
});
