import { z } from 'zod';
import type { Env } from '../env';
import { base64url, id, unbase64url } from '../lib/crypto';
import { assert, AppError } from '../lib/errors';
import { editObjectKey } from '../lib/design-edit-storage';
import { sha256 } from '../lib/crypto';
import { workflowImageTotalsMany } from '../lib/workflow-image-costs';

type Receipt={id:string;state:string;workflow_id:string|null;project_id:string;request_hash:string;error_code:string|null;error_message:string|null;error_status:number|null};
type Entry={transcript_id:string;user_id:string;project_id:string;created_at:string;request_key:string;prompt:string|null;style:string|null;reference_ids_json:string;workflow_id:string|null;legacy_job_id:string|null;scope_json:string;base_version_id:string|null;state:string;error_code:string|null;candidate_state:string|null;candidate_id:string|null;version_id:string|null;updated_at:string};
const encoder=new TextEncoder();

export async function receipt(env:Env,user:string,key:string){return env.DB.prepare('SELECT * FROM design_conversation_turns WHERE user_id=? AND request_key=?').bind(user,key).first<Receipt>();}
export function checkReceipt(row:Receipt,project:string,hash:string){
 assert(row.project_id===project&&row.request_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他设计消息',409);
 if(row.state==='failed')throw new AppError(row.error_code!,Object.hasOwn(PLATFORM_CONDITIONS,row.error_code!)?PLATFORM_CONDITIONS[row.error_code!]:row.error_message!,row.error_status!);
}
export async function receiveMessage(env:Env,user:string,project:string,hash:string,input:{requestKey:string;prompt:string;style?:string;scope:unknown;baseVersionId:string|null;referenceMediaIds:string[]}){
 const prior=await receipt(env,user,input.requestKey);if(prior){checkReceipt(prior,project,hash);return;}
 assert(new Set(input.referenceMediaIds).size===input.referenceMediaIds.length,'VALIDATION','参考图片不能重复');
 if(input.referenceMediaIds.length){
  const rows=await env.DB.prepare(`SELECT mime_type,byte_size FROM project_media_inventory WHERE user_id=? AND project_id=? AND state='ready' AND id IN (SELECT value FROM json_each(?))`).bind(user,project,JSON.stringify(input.referenceMediaIds)).all<{mime_type:string;byte_size:number}>();
  assert(rows.results.length===input.referenceMediaIds.length,'MEDIA_NOT_FOUND','参考图必须属于当前项目且处于可用状态',404);
  assert(rows.results.every(r=>['image/png','image/jpeg','image/webp'].includes(r.mime_type)),'REFERENCE_IMAGE_TYPE','参考图仅支持 PNG、JPEG、WebP',422);
  assert(rows.results.reduce((n,r)=>n+r.byte_size,0)<=6*1024*1024,'REFERENCE_IMAGE_LIMIT','参考图合计最多 6 MiB');
 }
 const now=new Date().toISOString(),turnId=id('turn');
 // The audit row is written only when this request actually created the turn
 // (a replay of the same key hits ON CONFLICT and leaves no second record).
 // A key that already belongs to a workflow (a quoted request that won a race,
 // or a message sent before turns existed) gets no turn: the workflow is the
 // single history entry for that key and decides replay or conflict.
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO design_conversation_turns(id,user_id,project_id,request_key,request_hash,prompt,style,scope_json,base_version_id,reference_ids_json,created_at,updated_at) SELECT ?,?,?,?,?,?,?,?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM ai_workflows w WHERE w.user_id=? AND w.request_key=?) ON CONFLICT(user_id,request_key) DO NOTHING`).bind(turnId,user,project,input.requestKey,hash,input.prompt,input.style??null,JSON.stringify(input.scope),input.baseVersionId,JSON.stringify(input.referenceMediaIds),now,now,user,input.requestKey),
  env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?,?,'ai.message_received','design_conversation_turn',?,?,?,? WHERE EXISTS(SELECT 1 FROM design_conversation_turns WHERE id=?)`).bind(id('audit'),user,turnId,JSON.stringify({projectId:project,requestKey:input.requestKey,scope:(input.scope as {kind?:string})?.kind??null,referenceCount:input.referenceMediaIds.length,style:!!input.style}),input.requestKey,now,turnId),
 ]);}
 catch(error){if(String(error).includes('conversation_reference_unavailable')||String((error as Error)?.cause).includes('conversation_reference_unavailable'))throw new AppError('MEDIA_NOT_FOUND','参考图或项目已变化',409);throw error;}
 const stored=await receipt(env,user,input.requestKey);if(stored)checkReceipt(stored,project,hash);
}
/** Refusals that are never stored: the turn stays `received` and the same key
 * can be resent. These are local transient failures and an idempotency
 * conflict (the key belongs to another request; that request is the record). */
export const TRANSIENT_REFUSALS=['DESIGN_MEMORY_BUSY','EDIT_WORKSPACE_BUSY','EDIT_OBJECT_UNCONFIRMED','EDIT_OBJECT_UNAVAILABLE','STORAGE_FAILURE','MEDIA_MISSING','IDEMPOTENCY_CONFLICT'];
const SERVICE_PAUSED='AI 设计服务正在维护，暂时无法处理新消息，请稍后重新发送';
// Platform-side conditions (billing review, capability tests, vision billing)
// carry operator wording. A customer gets a neutral text with the same code and
// status, and the condition is never stored as the answer to the message.
const PLATFORM_CONDITIONS:Record<string,string>={AI_BILLING_UNVERIFIED:SERVICE_PAUSED,CAPABILITY_TEST_REQUIRED:SERVICE_PAUSED,VISION_BILLING_UNVERIFIED:'当前暂不支持参考图输入，请移除参考图后重新发送'};
/** A refusal is final for its key only when it is a definitive answer about the
 * request itself: a 4xx that is neither a retry-later status nor a platform-side
 * condition. Every 5xx means the platform could not decide (service not
 * configured, billing review pending, storage unavailable); clients treat that
 * as an unknown outcome and retry with the SAME key, so it must not stick. */
export function finalRefusal(error:unknown):error is AppError{
 return error instanceof AppError&&error.status>=400&&error.status<500&&![408,425,429].includes(error.status)&&!TRANSIENT_REFUSALS.includes(error.code)&&!Object.hasOwn(PLATFORM_CONDITIONS,error.code);
}
/** The error a customer may see for a message, live and in the stored history. */
export function customerRefusal(error:unknown):unknown{
 return error instanceof AppError&&Object.hasOwn(PLATFORM_CONDITIONS,error.code)?new AppError(error.code,PLATFORM_CONDITIONS[error.code],error.status):error;
}
export async function rejectMessage(env:Env,user:string,project:string,key:string,hash:string,error:unknown){
 if(finalRefusal(error)){
  const now=new Date().toISOString(),row=await receipt(env,user,key);
  if(row&&row.state==='received'&&row.project_id===project&&row.request_hash===hash)await env.DB.batch([
   env.DB.prepare("UPDATE design_conversation_turns SET state='failed',error_code=?,error_message=?,error_status=?,updated_at=? WHERE id=? AND state='received'").bind(error.code,error.message,error.status,now,row.id),
   env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?,?,'ai.message_refused','design_conversation_turn',?,?,?,? WHERE EXISTS(SELECT 1 FROM design_conversation_turns WHERE id=? AND state='failed') AND NOT EXISTS(SELECT 1 FROM audit_logs WHERE actor_id=? AND entity_type='design_conversation_turn' AND entity_id=? AND action='ai.message_refused')`).bind(id('audit'),user,row.id,JSON.stringify({projectId:project,requestKey:key,code:error.code,status:error.status}),key,now,row.id,user,row.id),
  ]);
 }
 const row=await receipt(env,user,key);if(row)checkReceipt(row,project,hash);
}

// White-label. Assistant prose is the only model-written text customers read, so
// a sentence that names the model, its vendor, the hosting provider or the
// server's location, an API endpoint, an internal tool or a provider artefact is
// removed entirely. Words that are also ordinary brand names or design terms
// (Gemini, Llama, 豆包, Google, Meta, a host name) only count in a sentence that
// is about the assistant itself or about where the service runs (R2-WL1).
const PRIVATE_TERMS=new RegExp([
 // Model vendors, model families and AI products that are never ordinary words
 // (people called Claude are allowed first, see ALLOWED_PHRASES).
 String.raw`open[\s._·-]*ai(?![a-z])`,'gpt','anthropic','claude','克劳德','deepseek','deepmind','qwen','chatglm',String.raw`\bglm-?\d`,'doubao','文心一言','ernie bot',
 String.raw`\bo[1-9]-(?:mini|pro|preview|high)\b`,String.raw`dall[\s·._-]*e(?![a-z])`,'midjourney','stable diffusion',String.raw`\bxai\b`,'googleapis','generativelanguage',
 'openrouter',String.raw`hugging\s*face`,String.raw`\bcodex\b`,'腾讯元宝',
 '深度求索','通义','千问','月之暗面','智谱','混元','零一万物','讯飞星火','星火大模型','商汤','百川智能','阶跃星辰',String.raw`\bminimax\b`,String.raw`海螺\s*ai`,
 // Hosting and infrastructure providers, their product names and infrastructure hosts.
 'hostinger',String.raw`h[\s-]?panel`,'hstgr','main-hosting','dns-parking',String.raw`workers\.dev`,String.raw`r2\.dev`,'microsoft azure','amazon web services','amazon bedrock','google cloud','vercel',
 String.raw`cloudflare\s*(?:workers?|pages|r2|d1|kv|durable)`,String.raw`\bcf\b[^。！？.!?\n]{0,6}\bworkers?\b`,
 String.raw`durable\s+objects?`,String.raw`workers?\s+kv`,String.raw`\bworkers?\b[^。.!?\n]{0,40}\b(?:kv|durable)\b`,
 String.raw`\br2\b[^。.!?\n]{0,6}(?:存储|bucket|storage)`,String.raw`(?:存储桶|bucket)[^。.!?\n]{0,4}\br2\b`,String.raw`\bd1\b[^。.!?\n]{0,6}(?:数据库|database)`,String.raw`(?:数据库|database)[^。.!?\n]{0,4}\bd1\b`,
 // Internal tool names and provider artefacts (a CSS class such as .msg_box is not an id).
 '(?:read_project|read_rules|list_files|read_file|read_fragment|find_text|propose_files|propose_edits|check_preview)',
 String.raw`(?<![.#\w-])(?:call|resp|fc|rs|msg)_(?=[a-z0-9]*\d)[a-z0-9]{6,}`,String.raw`\bsk-(?:live|test|proj|ant|or)-[a-z0-9_-]{4,}`,String.raw`\bsk-[a-z0-9_-]{16,}`,'call_id','encrypted_content','input_image',
 // API endpoints, server names and addresses (also an IPv4 written in hex; 0xFF… is an ARGB colour).
 String.raw`\bapi\.[a-z0-9-]+\.[a-z]{2,}`,String.raw`\bsrv\d+`,String.raw`\b\d{1,3}(?:\.\d{1,3}){3}\b`,String.raw`\b0x(?!ff)[0-9a-f]{8}\b`,
 // IPv6: compressed with "::", or all eight groups ("a::before" in CSS advice is not an address).
 String.raw`(?<![0-9a-z:])(?:[0-9a-f]{1,4}:){1,7}:(?:[0-9a-f]{1,4}(?::[0-9a-f]{1,4}){0,6})?(?![0-9a-z:])`,String.raw`(?<![0-9a-z:])::[0-9a-f]{1,4}(?![0-9a-z:])`,String.raw`\b(?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}\b`,
 // Active link schemes: replies are plain text and never carry script or data links.
 // R4-WL2: only in a link position (an encoded colon, a colon directly followed by
 // code or a path, or after href=/src=/](/</a quote); "JavaScript：延迟加载" and
 // "Structured data: application/ld+json" are labels in ordinary advice.
 String.raw`(?:java|vb)[\s\x00-\x1f]*script\s*(?:&#x?0*(?:58|3a);?|&colon;)`,
 String.raw`(?:java|vb)[\s\x00-\x1f]*script\s*:(?=[a-z0-9_$(/\\%&#!'"\[{~+\x60])`,
 String.raw`(?:(?:href|src|action|formaction)\s*=\s*|\]\(|<|["'\x60])\s*(?:(?:java|vb)[\s\x00-\x1f]*script|data)\s*:`,
 String.raw`\bdata:(?:text|application|image)\/`,
].join('|'),'i');
// R3-WL1: public hosts a site legitimately embeds or links (Google Fonts and Maps,
// WhatsApp and Telegram contact links) and people who happen to be called Claude
// are removed before the checks, so they never empty design or SEO advice.
const ALLOWED_PHRASES=/\b(?:fonts|maps|ajax)\.googleapis\.com\b|\bfonts\.gstatic\.com\b|\bapi\.(?:whatsapp\.com|telegram\.org)\b|\bwa\.me\b|\bclaude\s+(?:monet|garamond|debussy|shannon|lorrain|bernard|chabrol|lelouch|nougaro|makelele|cahun|bolling|van\s+damme|l[eé]vi-strauss)\b|克劳德\s*[·・.]?\s*(?:莫奈|加拉蒙|德彪西|香农|洛兰|贝尔纳)/gi;
// Names that are private only next to AI wording ("Llama Coffee", "Gemini Trading",
// 豆包 the bun, 《文心雕龙》, "sonnet", the O3 ozone generator, 日日新 the classic).
const AMBIGUOUS_NAMES=String.raw`\bgemini\b|双子座|\bllama\b|\bmistral\b|豆包|文心|\bkimi\b|\bernie\b|\bbard\b|\bsora\b|\bgrok\b|\bcopilot\b|\bsonnet\b|\bopus\b|\bhaiku\b|\bmeta\s*ai\b|海螺|星火|\bbedrock\b|\bperplexity\b|\bcohere\b|\bo[1-9]\b|日日新`;
const AMBIGUOUS=new RegExp(AMBIGUOUS_NAMES,'i');
// AI wording, or the assistant speaking about itself. Everyday product words (模型,
// models, 生成, 基于, 驱动) are not enough on their own (R3-WL1); a name directly
// followed by model wording ("Llama 3 模型", "由 Sora 生成") still is (nearModel).
const AI_CONTEXT=/(?:大模型|语言模型|推理模型|人工智能|\bai\b|助手|训练|\bllms?\b|language model|assistant|chatbot|trained|powered by|built on|我是|我来自|我基于|我由|本助手|\bi am\b|\bi'm\b|\bi was\b)/i;
const nearModel=(names:string)=>new RegExp(String.raw`(?:${names})\s*(?:[\w.-]{1,8}\s*){0,2}(?:推理|图像|图片|视频|语言|文本|大)?\s*(?:模型|生成|\bmodels?\b|\bgenerated\b)|(?:由|by|用|using)\s*(?:${names})\s*(?:[\w.-]{1,8}\s*){0,2}(?:生成|写成|写的|generated|wrote|written)|\b(?:generated|written|created|produced)\s+(?:by|with|using)\s+(?:${names})`,'i');
const NEAR_MODEL=nearModel(AMBIGUOUS_NAMES);
// A company name is private only when the sentence says it made, trained or runs the assistant.
const MAKER_NAMES=String.raw`google|谷歌|meta|microsoft|微软|amazon|亚马逊|百度|阿里巴巴|阿里|字节跳动|字节|腾讯|华为|baidu|alibaba|bytedance|tencent|huawei|azure|iflytek|讯飞|sensetime`;
// The company's public products are not the assistant's maker ("Google Material", "谷歌地图").
const NOT_MAKER_ZH=String.raw`(?![^，。！？\n]{0,8}(?:material|地图|maps?|fonts?|字体|图标|icons?|规范|设计|design|配色|颜色|colou?rs?|风格|style|商店|store|搜索|search|翻译|translate|统计|指数|广告|推广|站长|index|ads|analytics|fluent))`;
const NOT_MAKER_EN=String.raw`(?!(?:'s)?\s*(?:material|maps?|fonts?|icons?|symbols?|design|colou?rs?|style|guidelines|search|analytics|sheets|docs|drive|translate|lens|play|store|edge|office|word|excel|ads|keyword|business\s+profile|index|trends|console|tongji|statistics|fluent))`;
const MAKER_RULES=[
 new RegExp(String.raw`\b(?:i|i'm|i am|i was|this assistant|the assistant)\b[^.!?。！？\n]{0,30}\b(?:made|built|created|trained|developed|powered|run|runs|running|hosted|based|from)\b[^.!?。！？\n]{0,20}(?:${MAKER_NAMES})${NOT_MAKER_EN}`,'i'),
 new RegExp(String.raw`\b(?:i'm|i am)\s+(?:an?\s+)?(?:${MAKER_NAMES})${NOT_MAKER_EN}`,'i'),
 new RegExp(String.raw`(?:我(?!们)|本助手|本\s*ai)(?:\s*是)?\s*(?:由|来自|基于|属于|出自)\s*(?:${MAKER_NAMES})${NOT_MAKER_ZH}`,'i'),
 new RegExp(String.raw`(?:我(?!们)|本助手)\s*是\s*(?:${MAKER_NAMES})`,'i'),
 new RegExp(String.raw`(?:${MAKER_NAMES})[^，。！？\n]{0,8}(?:训练|开发|研发)的(?:大型)?(?:语言)?(?:模型|助手|ai)`,'i'),
 new RegExp(String.raw`由\s*(?:${MAKER_NAMES})[^，。！？\n]{0,10}(?:训练|开发|研发|驱动)的?(?:大型)?(?:语言)?(?:模型|助手|ai|人工智能)`,'i'),
 new RegExp(String.raw`\b(?:powered|trained)\s+by\s+(?:the\s+)?(?:${MAKER_NAMES})(?!\s*(?:fonts?|maps?|analytics|search|ads|tag|sheets|forms|calendar|pay|edge|store|translate|lens)\b)`,'i'),
 // R3-WL2: the maker as subject or object ("Google created me", "my developer is
 // Microsoft", "谷歌是我的开发者", "支撑我的是微软的技术").
 new RegExp(String.raw`(?:${MAKER_NAMES})\s+(?:made|created|built|developed|trained|designed|programmed|owns)\s+me\b`,'i'),
 new RegExp(String.raw`\bmy\s+(?:developer|creator|maker|vendor|provider|owner|company)\s+is\s+(?:${MAKER_NAMES})`,'i'),
 new RegExp(String.raw`我的(?:开发者|开发商|创造者|制造者|提供方|提供者|厂商|东家)是\s*(?:${MAKER_NAMES})`,'i'),
 new RegExp(String.raw`(?:${MAKER_NAMES})\s*是我的(?:开发者|开发商|创造者|制造者|提供方|提供者|厂商|东家)`,'i'),
 new RegExp(String.raw`(?:支撑|驱动|支持|训练)我的是\s*(?:${MAKER_NAMES})`,'i'),
 new RegExp(String.raw`我的\s*(?:底层|基础)?\s*(?:模型|大模型|引擎|内核)\s*(?:来自|是|由|基于|出自|属于)\s*(?:${MAKER_NAMES})`,'i'),
 new RegExp(String.raw`由\s*(?:${MAKER_NAMES})\s*的?\s*(?:大?模型|ai|人工智能)\s*(?:生成|写成|回答|驱动)`,'i'),
 new RegExp(String.raw`\bmy\s+(?:underlying\s+|base\s+)?(?:model|engine|llm)\s+(?:comes?\s+from|is\s+(?:from|made\s+by|built\s+by|by)|was\s+(?:made|built|trained|developed)\s+by)\s+(?:${MAKER_NAMES})`,'i'),
 new RegExp(String.raw`\bunder\s+the\s+hood,?\s+(?:i|this\s+assistant)\s+(?:use|uses|run\s+on|runs\s+on|am)\b[^.!?\n]{0,20}(?:${MAKER_NAMES})${NOT_MAKER_EN}`,'i'),
];
// Where the service runs. Requirement line 160: no server location or data-centre region.
const HOST_CONTEXT=/(?:服务器|主机|部署在|部署于|托管在|托管于|运行在|运行于|跑在|后端|机房|数据中心|server|backend|hosted on|hosted at|deployed on|deployed to|running on|runs? on|data ?cent(?:er|re))/i;
// R4-WL1: the customer's DNS servers (DNS 服务器, 域名服务器, nameservers) are DNS
// advice, not where the service runs; they are removed before the HOST_CONTEXT test.
const DNS_SERVERS=/(?:dns|域名|解析)\s*服务器|\bname\s*-?\s*servers?\b|\bdns\s+servers?\b/gi;
// Infrastructure vendors that are also the customer's own registrar or DNS
// ("请在阿里云域名控制台添加 CNAME", "If your domain uses Cloudflare DNS"), and
// certifications (AWS D1.1, GCP): private only where the service runs or with AI wording.
const INFRA_VENDORS=/(?:cloudflare|阿里云|腾讯云|华为云|\baws\b|\bgcp\b|\bcf\b)/i;
const INFRA_PRODUCTS=/(?:(?<!service[\s-]?)\bworkers?\b|\bkv\b|\bd1\b|\br2\b)/i;
const HOST_TOKEN=/\b[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,}\b/gi;
const FILE_SUFFIX=/\.(?:css|js|mjs|ts|html?|php|json|xml|txt|md|png|jpe?g|webp|avif|gif|svg|ico|woff2?|ttf|otf|mp4|webm|pdf|zip)$/i;
const INFRA_LABEL=/^(?:srv|server|servers|node|vps|host|hosting|edge|cdn|origin|db|mysql|cloud|cluster|pool|worker)\d*$/i;
/** An infrastructure host name: an infra label with a number (srv12, node-5), or one
 * below the first label ("x.cdn.provider.net"); "cdn.yourbrand.com" is the customer's own. */
const infraHost=(host:string)=>host.split('.').some((part,index)=>part.split('-').some(label=>INFRA_LABEL.test(label)&&(/\d/.test(label)||index>0)));
const PLACES_ZH='新加坡|美国|美西|美东|英国|德国|法国|荷兰|立陶宛|日本|韩国|香港|台湾|印度|巴西|加拿大|澳大利亚|澳洲|爱尔兰|芬兰|瑞典|波兰|西班牙|意大利|阿姆斯特丹|法兰克福|伦敦|巴黎|东京|大阪|首尔|硅谷|弗吉尼亚|俄勒冈|加州|洛杉矶|纽约|芝加哥|达拉斯|悉尼|孟买|圣保罗|维尔纽斯|欧洲|北美|亚太|中国';
const PLACES_EN=String.raw`singapore|united states|the us|usa|america|united kingdom|the uk|england|germany|france|the netherlands|netherlands|holland|lithuania|japan|korea|hong kong|taiwan|india|brazil|canada|australia|ireland|finland|sweden|poland|spain|italy|amsterdam|frankfurt|london|paris|tokyo|osaka|seoul|virginia|oregon|california|los angeles|new york|chicago|dallas|sydney|mumbai|s[aã]o paulo|vilnius|europe|the eu|north america|asia`;
const LOCATION=[
 /(?:托管|部署|运行)(?:在|于)?[^，。！？；\n]{0,12}(?:机房|数据中心|服务器|可用区)/,
 /(?:机房|数据中心)(?:位于|设在|在)[^，。！？；\n]{0,8}/,
 /服务器(?:位于|设在|放在)[^，。！？；\n]{0,8}/,
 /(?:部署|托管|运行)(?:在|于)\s*\S+?\s*的?(?:节点|服务器|主机|机房)/,
 /\b(?:[Ss]ervers?|[Dd]ata ?cent(?:er|re)s?|[Hh]osting)\s+(?:is\s+|are\s+)?(?:located\s+|based\s+)?in\s+(?:the\s+)?(?:[A-Z][a-z]|(?:US|UK|EU|USA|UAE)\b)/,
 new RegExp(String.raw`\b[Rr]egion\s+(?:is\s+)?(?:located\s+|based\s+)?in\s+(?:${PLACES_EN})\b`,'i'),
 // R4-m2: 服务器在美国, 放在美国的服务器上, "We host your site in Lithuania".
 new RegExp(`服务器[^，。！？；\\n]{0,4}(?:在|位于)\\s*(?:${PLACES_ZH})`),
 new RegExp(`(?:放|部署|托管|运行|跑)在\\s*(?:${PLACES_ZH})[^，。！？；\\n]{0,4}的?(?:服务器|机房|节点|主机|数据中心)`),
 new RegExp(String.raw`\b(?:we|they)\s+host\b[^.!?\n]{0,24}\b(?:in|from|out of)\s+(?:${PLACES_EN})\b`,'i'),
 // R3-WL2: a place name after a hosting verb, without 机房 ("托管在新加坡",
 // "托管地点：荷兰", "Your pages are served from Frankfurt").
 new RegExp(`(?:托管|部署|运行)(?:在|于)\\s*(?:${PLACES_ZH})`),
 new RegExp(`(?:网站|站点|页面|服务器|后端|服务|主机|系统)[^，。！？；\\n]{0,6}在\\s*(?:${PLACES_ZH})[^，。！？；\\n]{0,8}(?:机房|数据中心|运行|托管|部署)`),
 new RegExp(`(?:托管|服务器|机房|部署|数据中心|主机)(?:所在)?(?:地点|位置|地区|区域|所在地)\\s*(?:[:：是为在]\\s*)?(?:${PLACES_ZH})`),
 new RegExp(String.raw`\b(?:sites?|websites?|pages?|servers?|backend|service|app|hosting|it)\b[^.!?\n]{0,24}\b(?:hosted|runs?|running|served|deployed|lives?)\s+(?:in|from|out of|at)\s+(?:(?:a|our|the)\s+)?(?:data ?cent(?:er|re)s?\s+in\s+)?(?:${PLACES_EN})\b`,'i'),
];
// Latin look-alikes (Greek, Cyrillic, Armenian, Cherokee, IPA and small capitals), folded before matching.
const CONFUSABLES:Record<string,string>={'А':'A','В':'B','Е':'E','К':'K','М':'M','Н':'H','О':'O','Р':'P','С':'C','Т':'T','Х':'X','У':'Y','І':'I','Ј':'J','Ѕ':'S','Ԁ':'D','а':'a','в':'b','е':'e','к':'k','м':'m','н':'h','о':'o','р':'p','с':'c','т':'t','х':'x','у':'y','і':'i','ј':'j','ѕ':'s','ԁ':'d','ӏ':'l','ԛ':'q','ԝ':'w','ɡ':'g','Α':'A','Β':'B','Ε':'E','Ζ':'Z','Η':'H','Ι':'I','Κ':'K','Μ':'M','Ν':'N','Ο':'O','Ρ':'P','Τ':'T','Υ':'Y','Χ':'X','α':'a','ε':'e','ι':'i','κ':'k','ν':'v','ο':'o','ρ':'p','τ':'t','υ':'u','χ':'x','ω':'w',
 'օ':'o','ս':'u','հ':'h','ո':'n','ց':'g','ք':'p','ա':'w','զ':'q','Օ':'O','Ս':'U','Ꭺ':'A','Ᏼ':'B','Ꮯ':'C','Ꭰ':'D','Ꭼ':'E','Ꮐ':'G','Ꮋ':'H','Ꭵ':'i','Ꭻ':'J','Ꮶ':'K','Ꮮ':'L','Ꮇ':'M','Ꮲ':'P','Ꮢ':'R','Ꮪ':'S','Ꭲ':'T','Ꮩ':'V','Ꮃ':'W','Ꮤ':'W','Ꮓ':'Z',
 'ɑ':'a','ı':'i','ɩ':'i','ɪ':'i','ʟ':'l','ɴ':'n','ʀ':'r','ʏ':'y','ᴀ':'a','ᴄ':'c','ᴅ':'d','ᴇ':'e','ᴏ':'o','ᴘ':'p','ᴛ':'t','ᴜ':'u','ɢ':'g','ʜ':'h','ꞵ':'b','ȷ':'j','ℓ':'l'};
/** Percent-encoding decoded, NFKC, every format or default-ignorable character
 * removed (bidi marks, U+061C, musical format characters, tags, variation
 * selectors), regional-indicator letters read as letters, diacritics dropped and
 * look-alike letters folded. */
function foldText(part:string){
 return part.replace(/%([0-9a-f]{2})/gi,(match,hex:string)=>{const code=parseInt(hex,16);return code>=0x20&&code<0x7f?String.fromCharCode(code):match;})
  .replace(/[\u{1F1E6}-\u{1F1FF}]/gu,ch=>String.fromCharCode(0x61+(ch.codePointAt(0)!-0x1F1E6)))
  .normalize('NFKC').replace(/[\p{Cf}\p{Default_Ignorable_Code_Point}\u1160\u3164\uFFA0]/gu,'')
  .normalize('NFKD').replace(/\p{M}/gu,'').replace(/[^\x00-\x7f]/g,ch=>CONFUSABLES[ch]??ch);
}
/** "O p e n A I", "G.P.T" or "(o)(p)(e)(n)(a)(i)": runs of single letters are joined, so spacing cannot hide a name. */
function joinSpacedLetters(text:string){return text.replace(/(?<![A-Za-z])[A-Za-z](?:[\s._·*\-/()]+[A-Za-z](?![A-Za-z])){2,}/g,run=>run.replace(/[^A-Za-z]/g,''));}
// Critical names also match with digits for letters (0penAI), one separator
// between letters (Clau de, Anth-ropic) or an unknown letter from another script.
// Cloudflare is also a registrar and DNS host, so a fuzzy match of it only counts
// where the service runs (see INFRA_VENDORS).
const LEET:Record<string,string>={a:'a4@',e:'e3',i:'i1!|',l:'l1|',o:'o0',s:'s5$',t:'t7',g:'g9',b:'b8'};
const FUZZY=['openai','anthropic','claude','deepseek','chatgpt','hostinger','hpanel','cloudflare'].map(name=>({name,pattern:new RegExp(String.raw`(?<![a-z0-9])`+[...name].map(ch=>'['+(LEET[ch]??ch).replace(/[\\\]^-]/g,'\\$&')+'?]').join(String.raw`[\s\-·_.*]?`)+String.raw`(?![a-z])`,'gi')}));
function fuzzyNames(text:string):string[]{
 const marked=text.replace(/[^\x00-\x7f]/gu,ch=>/\p{L}/u.test(ch)&&!/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u.test(ch)?'?':ch).toLowerCase();
 return FUZZY.filter(({name,pattern})=>[...marked.matchAll(pattern)].some(match=>{const letters=match[0].replace(/[\s\-·_.*]/g,'');if(letters.length!==name.length)return false;
  let misses=0;for(let index=0;index<name.length;index++)if(letters[index]!==name[index])misses++;return misses<=Math.max(1,Math.floor(name.length/3));})).map(({name})=>name);
}
// Sentences end at CJK terminators; a Latin terminator only before a space or the
// end, so "4.5", "theme.css" and "send?phone=…" in a URL stay whole (R3-WL1).
const SENTENCE=/(?:[^。！？；!?;.\n]|[.!?;](?!\s|$))+(?:[。！？；]+|[.!?;]+(?=\s|$))?\s*|[。！？；.!?;]+\s*/g;
/** A configured pool or billing-profile id that is an ordinary word ("main",
 * "small") identifies nothing and would empty ordinary advice, so it is not a term. */
const plainWord=(value:unknown)=>typeof value==='string'&&/^[a-z]+$/i.test(value);
/** Identifiers of the configuration a workflow ran with (model id, API host,
 * pool and billing profile names): extra deny terms for that workflow's text. */
export function pricingTerms(pricingJson:string|null|undefined):string[]{
 try{
  const p=JSON.parse(pricingJson??'null');if(!p||typeof p!=='object')return [];
  let host='';try{host=new URL(String(p.baseUrl)).hostname;}catch{/* No host. */}
  return [...new Set([p.model,plainWord(p.providerPoolId)?null:p.providerPoolId,plainWord(p.billingProfile)?null:p.billingProfile,host,host.replace(/^api\./,'')].filter((v):v is string=>typeof v==='string'&&v.length>=3))];
 }catch{return [];}
}
const escapeRegExp=(value:string)=>value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
/** Removes every sentence that contains a private term. Idempotent, so it runs
 * both when a reply is stored and again whenever one is read. */
export function whiteLabel(text:string,extra:readonly string[]=[]){
 const terms=extra.map(term=>term.trim().toLowerCase()).filter(term=>term.length>=3);
 // R3-WL1: configured terms match whole tokens only ("main" never empties "domain").
 const termPatterns=terms.map(term=>new RegExp(String.raw`(?<![a-z0-9])${escapeRegExp(term)}(?![a-z0-9])`,'i'));
 // R3-WL2: the short codename of a configured model id ("gpt-6.1-sol" -> "sol")
 // counts like an ambiguous model name: next to model wording or AI wording.
 const codenames=[...new Set(terms.flatMap(term=>{const last=term.split(/[-/]/).at(-1)??'';return term!==last&&/^[a-z][a-z0-9]{2,}$/.test(last)?[last]:[];}))];
 const codenamePattern=codenames.length?new RegExp(codenames.map(name=>String.raw`\b${escapeRegExp(name)}\b`).join('|'),'i'):null;
 const codenameNear=codenames.length?nearModel(codenames.map(name=>String.raw`\b${escapeRegExp(name)}\b`).join('|')):null;
 const prepared=(part:string)=>{const plain=foldText(part).replace(ALLOWED_PHRASES,' ');return {plain,joined:joinSpacedLetters(plain)};};
 // Context-free checks: a name, artefact or address that is private wherever it appears.
 const strict=(part:string)=>{
  const {plain,joined}=prepared(part),dotted=plain.replace(/[。．｡]/g,'.');
  if(PRIVATE_TERMS.test(plain)||PRIVATE_TERMS.test(joined)||PRIVATE_TERMS.test(dotted)||fuzzyNames(plain).some(name=>name!=='cloudflare'))return true;
  return termPatterns.some(pattern=>pattern.test(plain)||pattern.test(joined));
 };
 const denied=(part:string)=>{
  if(strict(part))return true;
  const {plain,joined}=prepared(part),host=HOST_CONTEXT.test(plain.replace(DNS_SERVERS,' ')),ai=AI_CONTEXT.test(joined);
  if(AMBIGUOUS.test(joined)&&(ai||NEAR_MODEL.test(joined)))return true;
  if(codenamePattern?.test(joined)&&(ai||codenameNear!.test(joined)))return true;
  if((INFRA_VENDORS.test(joined)||fuzzyNames(plain).includes('cloudflare'))&&(host||ai))return true;
  if(host&&INFRA_PRODUCTS.test(plain))return true;
  if(MAKER_RULES.some(rule=>rule.test(joined)))return true;
  if(LOCATION.some(rule=>rule.test(plain.replace(DNS_SERVERS,' '))))return true;
  return host&&[...plain.matchAll(HOST_TOKEN)].some(([name])=>!FILE_SUFFIX.test(name)&&infraHost(name));
 };
 if(!denied(text))return text;
 let lines=text.split('\n');
 // A name split across two lines: both lines go.
 if(strict(text)&&!lines.some(strict))for(let index=0;index<lines.length-1;index++)if(strict(lines[index]+lines[index+1])){lines[index]='';lines[index+1]='';}
 lines=lines.map(line=>{
  if(!denied(line))return line;
  const kept=(line.match(SENTENCE)??[]).filter(part=>!denied(part)).join('').trim();
  // A private term that only shows across sentence boundaries ("203。0。113。5"): the whole line goes.
  return kept===line.trim()&&strict(line)?'':kept;
 });
 return lines.join('\n').replace(/\n{3,}/g,'\n\n').trim();
}
/** Only conversation messages are public. Tool arguments, reasoning, arbitrary
 * output objects and the full provider receipt never enter the public model. */
export function publicText(text:string,extra:readonly string[]=[]){return whiteLabel(structuralText(text),extra);}
function structuralText(text:string){
 const clean=text.replace(/(^|\n)[ \t]{0,3}(`{3,}|~{3,})[^\n]*(?:\n[\s\S]*?(?:\n[ \t]{0,3}\2[ \t]*(?=\n|$)|$)|$)/g,'$1')
  .replace(/<(script|style|pre|code|html|svg)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'').replace(/`[^`\n]*`/g,'');
 return clean.split(/\r?\n/).filter(line=>!/^\s*(?:[\[{"}]|[\]}][,;]?$|[.#][\w-]+\s*\{|(?:import|export|const|let|var|function|class|return|async function)\s|\/\/|<!doctype)/i.test(line)&&!/<\/?[a-z][\w:-]*[\s\/>]/i.test(line)&&!/(?:"(?:arguments|type|call_id|encrypted_content|tool_results_json)"\s*:)/.test(line)).join('\n').replace(/\n{3,}/g,'\n\n').trim();
}
export function publicOutput(response:any,extra:readonly string[]=[]):string{
 if(!Array.isArray(response?.output))return '';
 const terms=typeof response.model==='string'?[...extra,response.model]:extra;
 return response.output.filter((item:any)=>item?.type==='message'&&item.role==='assistant'&&Array.isArray(item.content)).flatMap((item:any)=>item.content.filter((part:any)=>part?.type==='output_text'&&typeof part.text==='string').map((part:any)=>publicText(part.text,terms))).filter(Boolean).join('\n\n');
}
const pos=z.object({p:z.string().max(150),t:z.string().max(50),i:z.string().min(1).max(150)}).strict();
function cursor(project:string,entry:Entry){return base64url(encoder.encode(JSON.stringify({p:project,t:entry.created_at,i:entry.transcript_id})));}
function before(project:string,value:string){try{if(value.length>900)throw Error();const v=pos.parse(JSON.parse(new TextDecoder().decode(unbase64url(value))));if(v.p!==project)throw Error();return v;}catch{throw new AppError('INVALID_CURSOR','对话分页位置无效',400);}}
type Options={limit:number;before?:string;key?:string;entryId?:string;query?:string;exclude?:string;anchor?:{created_at:string;transcript_id:string}};
async function entries(env:Env,user:string,project:string,options:Options){
 const clauses=['user_id=?','project_id=?'],args:(string|number)[]=[user,project];
 function earlier(t:string,i:string){clauses.push('(created_at,transcript_id)<(?,?)');args.push(t,i);}
 if(options.before){const v=before(project,options.before);earlier(v.t,v.i);}
 if(options.anchor)earlier(options.anchor.created_at,options.anchor.transcript_id);
 if(options.key){clauses.push('request_key=?');args.push(options.key);}
 if(options.entryId){clauses.push('transcript_id=?');args.push(options.entryId);}
 if(options.exclude){clauses.push('request_key<>?');args.push(options.exclude);}
 if(options.query){clauses.push(`(instr(lower(coalesce(prompt,'')||' '||coalesce(style,'')), lower(?))>0 OR EXISTS(SELECT 1 FROM ai_workflow_steps s WHERE s.workflow_id=design_conversation_index.workflow_id AND instr(lower(s.public_reply),lower(?))>0))`);args.push(options.query,options.query);}
 return (await env.DB.prepare('SELECT * FROM design_conversation_index WHERE '+clauses.join(' AND ')+' ORDER BY created_at DESC,transcript_id DESC LIMIT ?').bind(...args,options.limit).all<Entry>()).results;
}
const MAX_PUBLIC_REPLY=8000;
type StepView={id:string;workflow_id:string;ordinal:number;state:string;reservation_id:string;error_code:string|null;public_reply:string|null;legacy_text:string;tools:string;actual:number;held:number;object_key:string|null;oid:string|null;digest:string|null;size:number|null;workspace_id:string|null;receipt_id:string|null;has_response:number;pricing:string|null};
/** Reads the reply of a round from its private receipt. `null` means storage
 * could not be reached (try again later); `''` means the receipt is missing or
 * fails verification, which will not change, so nothing is shown for it. */
async function receiptReply(env:Env,user:string,project:string,s:StepView,terms:string[]):Promise<string|null>{
 if(s.object_key!==editObjectKey({user_id:user,project_id:project,id:s.workspace_id!},s.oid!,s.digest!)||!(s.size!<=600000))return '';
 if(!env.BUCKET)return null;
 let bytes:Uint8Array;
 try{const object=await env.BUCKET.get(s.object_key!);if(!object||object.size!==s.size)return '';bytes=new Uint8Array(await object.arrayBuffer());}catch{return null;}
 if(await sha256(bytes)!==s.digest)return '';
 try{return publicOutput(JSON.parse(new TextDecoder().decode(bytes)),terms);}catch{return '';}
}
/** The single loader of public assistant text, used by the conversation and by
 * the workflow view. A round stores its reply when it completes. For a round
 * recorded before that, the reply is derived once (from the inline response or
 * the verified private receipt) and stored, including an empty result, so later
 * reads never parse the response or touch storage again. Stored text passes the
 * white-label filter again on every read. */
export async function stepReplies(env:Env,user:string,project:string,ids:string[]){
 if(!ids.length)return [];
 const result=await env.DB.prepare(`SELECT s.id,s.workflow_id,s.ordinal,s.state,s.reservation_id,s.error_code,s.public_reply,s.response_object_id receipt_id,s.response_json IS NOT NULL has_response,w.pricing_json pricing,
 CASE WHEN s.public_reply IS NULL AND s.response_object_id IS NULL THEN (SELECT json_group_array(json_extract(c.value,'$.text')) FROM json_each(s.response_json,'$.output') m,json_each(m.value,'$.content') c WHERE json_extract(m.value,'$.type')='message' AND json_extract(m.value,'$.role')='assistant' AND json_extract(c.value,'$.type')='output_text') ELSE '[]' END legacy_text,
 (SELECT json_group_array(json_object('name',json_extract(t.value,'$.name'),'ok',coalesce(json_extract(t.value,'$.result.ok'),1),'code',json_extract(t.value,'$.result.code'),'layoutSaved',CASE WHEN json_extract(t.value,'$.name')='prepare_layout' AND json_type(t.value,'$.result.images')='array' AND json_type(t.value,'$.result.changedFiles')='array' THEN 1 ELSE 0 END,'reviewPassed',CASE WHEN json_extract(t.value,'$.result.check.passed')=1 OR (json_extract(t.value,'$.name')='check_preview' AND json_extract(t.value,'$.result.ok')=1) THEN 1 ELSE 0 END,'imageFailures',(SELECT count(*) FROM json_each(t.value,'$.result.images') i WHERE json_extract(i.value,'$.ok')=0))) FROM json_each(s.tool_results_json) t) tools,
 CASE WHEN r.state IN ('settled','released') THEN r.actual_micros ELSE 0 END+COALESCE(s.retired_micros,0) actual,CASE WHEN r.state IN ('reserved','dispatching','uncertain') THEN r.amount_micros ELSE 0 END held,
 o.object_key,o.id oid,o.sha256 digest,o.byte_size size,w.workspace_id FROM ai_workflow_steps s JOIN ai_workflows w ON w.id=s.workflow_id LEFT JOIN api_reservations r ON r.id=s.reservation_id LEFT JOIN design_edit_objects o ON o.id=s.response_object_id AND o.workspace_id=w.workspace_id AND o.kind='response' AND o.logical_key='response:'||s.id AND o.state='ready' WHERE w.user_id=? AND w.project_id=? AND w.id IN (SELECT value FROM json_each(?)) ORDER BY s.ordinal`).bind(user,project,JSON.stringify(ids)).all<StepView>();
 for(const s of result.results){
  const terms=pricingTerms(s.pricing);
  if(s.public_reply!==null){s.public_reply=whiteLabel(s.public_reply,terms);continue;}
  let reply:string|null=null;
  if(s.receipt_id){
   // The receipt row of a completed round is final: without a ready object
   // there is nothing left to verify.
   if(s.oid&&s.workspace_id)reply=await receiptReply(env,user,project,s,terms);
   else if(s.state==='completed')reply='';
  }else if(s.has_response)reply=(JSON.parse(s.legacy_text) as unknown[]).filter((v):v is string=>typeof v==='string').map(text=>publicText(text,terms)).filter(Boolean).join('\n\n');
  if(reply===null)continue;
  s.public_reply=reply.slice(0,MAX_PUBLIC_REPLY);
  // Completing the round later overwrites this with the full reply.
  await env.DB.prepare('UPDATE ai_workflow_steps SET public_reply=? WHERE id=? AND public_reply IS NULL').bind(s.public_reply,s.id).run();
 }
 return result.results;
}
function publicSteps(env:Env,user:string,project:string,rows:Entry[]){return stepReplies(env,user,project,rows.flatMap(r=>r.workflow_id?[r.workflow_id]:[]));}
async function views(env:Env,user:string,project:string,rows:Entry[]){
 const steps=await publicSteps(env,user,project,rows),wids=rows.map(r=>r.workflow_id).filter(Boolean),jids=rows.map(r=>r.legacy_job_id).filter(Boolean);
 const workflows=wids.length?(await env.DB.prepare(`SELECT w.id,w.max_steps,w.max_cost_micros,w.per_step_micros,w.lease_until_ms,w.workspace_id,e.revision,json_extract(w.requirements_json,'$.origin') origin FROM ai_workflows w LEFT JOIN design_edit_workspaces e ON e.id=w.workspace_id WHERE w.user_id=? AND w.project_id=? AND w.id IN(SELECT value FROM json_each(?))`).bind(user,project,JSON.stringify(wids)).all<{id:string;max_steps:number;max_cost_micros:number;per_step_micros:number;lease_until_ms:number|null;workspace_id:string|null;revision:number|null;origin:string|null}>()).results:[];
 const jobs=jids.length?(await env.DB.prepare(`SELECT j.id,r.state,r.amount_micros,r.actual_micros FROM ai_jobs j LEFT JOIN api_reservations r ON r.id=j.reservation_id WHERE j.user_id=? AND j.project_id=? AND j.id IN(SELECT value FROM json_each(?))`).bind(user,project,JSON.stringify(jids)).all<{id:string;state:string;amount_micros:number;actual_micros:number}>()).results:[];
 const imageCosts=await workflowImageTotalsMany(env,workflows.map(w=>({id:w.id,user_id:user})));
 // A refused message never reached a workflow; its stored refusal text is the
 // same user-facing message the original request returned.
 const refusedIds=rows.filter(r=>!r.workflow_id&&!r.legacy_job_id&&r.state==='failed').map(r=>r.transcript_id);
 const refusals=refusedIds.length?(await env.DB.prepare(`SELECT id,error_message FROM design_conversation_turns WHERE user_id=? AND project_id=? AND state='failed' AND id IN(SELECT value FROM json_each(?))`).bind(user,project,JSON.stringify(refusedIds)).all<{id:string;error_message:string|null}>()).results:[];
 return rows.map(t=>{const w=workflows.find(x=>x.id===t.workflow_id),job=jobs.find(x=>x.id===t.legacy_job_id),ss=steps.filter(s=>s.workflow_id===t.workflow_id),refs=JSON.parse(t.reference_ids_json) as string[],refusal=refusals.find(x=>x.id===t.transcript_id),errorMessage=refusal?(t.error_code&&Object.hasOwn(PLATFORM_CONDITIONS,t.error_code)?PLATFORM_CONDITIONS[t.error_code]:refusal.error_message):null;
  const assistantReplies=ss.filter(s=>s.public_reply).map(s=>({ordinal:s.ordinal,text:s.public_reply!}));
  const images=w?imageCosts.get(w.id):null,textMicros=ss.reduce((n,s)=>n+s.actual,0),textHeld=ss.reduce((n,s)=>n+s.held,0);
  const cost=images?{textMicros,imageMicros:images.consumed,settledMicros:textMicros+images.consumed,heldMicros:textHeld+images.held,estimatedImageMicros:images.estimated,pendingImageAdjustmentMicros:images.pendingAdjustment,basis:'settled-ledger-including-audited-estimates' as const}:undefined;
  return {...(cost?{cost}:{}),id:t.workflow_id??t.transcript_id,transcriptId:t.transcript_id,workflowId:t.workflow_id,recordKind:w?'workflow':job?'legacy_job':'message',requestOrigin:w?(w.origin==='account-design-message-v1'?'account':'quoted'):job?'legacy':'account',projectId:project,requestKey:t.request_key,requestPrompt:t.prompt,style:t.style,scope:JSON.parse(t.scope_json),baseVersionId:t.base_version_id,referenceMediaIds:refs,referenceMode:refs.length?(w?'model-input-image':'attached'):'none',assistantReplies,assistantReply:assistantReplies.map(r=>r.text).join('\n\n')||null,state:t.state,errorCode:t.error_code,errorMessage,candidateId:t.candidate_id,candidateState:t.candidate_state,versionId:t.version_id,previewUrl:t.candidate_id?'/preview/'+encodeURIComponent(project)+'/candidate/'+encodeURIComponent(t.candidate_id):null,workspaceId:w?.workspace_id??null,workspaceRevision:w?.revision??null,stepsUsed:ss.length,maxSteps:w?.max_steps??0,maxCostMicros:w?.max_cost_micros??0,perStepReservationMicros:w?.per_step_micros??0,recoverable:t.state==='received'||(t.state==='processing'&&(w?.lease_until_ms??0)<=Date.now()),consumedMicros:job?(job.state==='settled'?job.actual_micros:0):ss.reduce((n,s)=>n+s.actual,0),heldMicros:job?(['reserved','dispatching','uncertain'].includes(job.state)?job.amount_micros:0):ss.reduce((n,s)=>n+s.held,0),steps:ss.map(s=>({id:s.id,ordinal:s.ordinal,state:s.state,reservationId:s.reservation_id,errorCode:s.error_code,tools:(JSON.parse(s.tools) as {name:string;ok:number;code:string|null}[]).map(t=>({...t,ok:!!t.ok}))})),createdAt:t.created_at,updatedAt:t.updated_at};
 });
}
export async function projectConversation(env:Env,user:string,project:string,limit=20,previous?:string){
 assert(Number.isSafeInteger(limit)&&limit>=1&&limit<=50,'VALIDATION','每页可读取 1 至 50 条消息');
 const rows=await entries(env,user,project,{limit:limit+1,before:previous});const page=rows.slice(0,limit);
 return {items:await views(env,user,project,page),nextCursor:rows.length>limit?cursor(project,page.at(-1)!):null};
}
export async function conversationByKey(env:Env,user:string,project:string,key:string){const rows=await entries(env,user,project,{limit:2,key});const row=rows.find(r=>!r.legacy_job_id)??rows[0];assert(row,'NOT_FOUND','此项目尚无该消息记录',404);return (await views(env,user,project,[row]))[0];}

export const memorySchema=z.object({query:z.string().max(128),before:z.string().max(900).nullable(),messageId:z.string().max(150).nullable(),offset:z.number().int().min(0).max(4000000)}).strict();
export async function conversationMemory(env:Env,user:string,project:string,key:string,args?:z.infer<typeof memorySchema>){
 const anchor=(await entries(env,user,project,{limit:1,key}))[0];
 const limit=args?.messageId?1:args?6:20;
 const found=await entries(env,user,project,{limit:limit+1,anchor,exclude:key,entryId:args?.messageId??undefined,query:args?.query,before:args?.before??undefined});
 const page=found.slice(0,limit),ss=await publicSteps(env,user,project,page);let remaining=args?12000:20000;
 const previousRequests=[];let nextCursor:string|null=null;
 for(const r of page){const reply=ss.filter(s=>s.workflow_id===r.workflow_id&&s.public_reply).map(s=>s.public_reply).join('\n\n');const text=r.prompt??'',style=r.style??'',combined=[text,style,reply].join('\n');
  const offset=args?.messageId?args.offset:0,length=Math.min(remaining,args?.messageId?10000:remaining),record={id:r.transcript_id,request:text.slice(offset,offset+length),style:style.slice(Math.max(0,offset-text.length-1),Math.max(0,offset+length-text.length-1)),assistantReply:reply.slice(Math.max(0,offset-text.length-style.length-2),Math.max(0,offset+length-text.length-style.length-2)),nextOffset:offset+length<combined.length?offset+length:null,workflowState:r.state,candidateState:r.candidate_state,candidateId:r.candidate_id,versionId:r.version_id,errorCode:r.error_code,referenceMediaIds:JSON.parse(r.reference_ids_json)};
  previousRequests.push(record);remaining-=Math.min(length,Math.max(0,combined.length-offset));nextCursor=cursor(project,r);if(remaining<=0)break;
 }
 return {previousRequests:previousRequests.reverse(),nextCursor:previousRequests.length<found.length?nextCursor:null};
}
