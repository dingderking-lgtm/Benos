import type { Env } from '../env';
import { assert } from '../lib/errors';
import { validateSiteManifest } from './template-contract';
import { listMedia,readMedia,inspectMediaBytes } from './media';
import { MAX_TEMPLATE_ASSET_BYTES } from '../lib/template-archive';

export type IndexedProjectAsset={file:string;path:string;sha256:string;size:number;mediaId:string;mimeType:string};
/** Resolve metadata first; never hold every asset's bytes at once. */
export async function indexProjectAssets(env:Env,userId:string,projectId:string,manifest:unknown){
 assert(validateSiteManifest(manifest).valid,'TEMPLATE_INVALID','模板结构校验失败',422);
 const declared=(manifest as {assets:Array<{file:string;path:string;sha256:string;size:number}>}).assets;
 assert(declared.reduce((sum,item)=>sum+item.size,0)<=MAX_TEMPLATE_ASSET_BYTES,'MEDIA_TRANSFER_LIMIT','模板素材总量最多 64 MiB',413);
 const inventory=await listMedia(env,userId,projectId),items:IndexedProjectAsset[]=[],mapping:Record<string,string>={};
 for(const asset of declared){const extension=asset.file.split('.').at(-1),media=inventory.find(m=>m.sha256===asset.sha256&&m.byteSize===asset.size&&m.extension===(extension==='jpeg'?'jpg':extension));
  assert(media,'MEDIA_NOT_FOUND','模板引用了未上传、已删除或不属于该项目的素材',422);items.push({...asset,mediaId:media.id,mimeType:media.mimeType});mapping[asset.path]=media.contentUrl;
 }return {items,mapping};
}
export async function readIndexedAsset(env:Env,userId:string,item:IndexedProjectAsset){
 const {row,bytes}=await readMedia(env,userId,item.mediaId);assert(row.sha256===item.sha256&&row.byte_size===item.size&&row.mime_type===item.mimeType,'MEDIA_CORRUPT','素材索引与存储副本不一致',503);
 await inspectMediaBytes(bytes,item.mimeType);return bytes;
}
export async function verifyProjectAssets(env:Env,userId:string,projectId:string,manifest:unknown){
 const index=await indexProjectAssets(env,userId,projectId,manifest);for(const item of index.items)await readIndexedAsset(env,userId,item);return index;
}
