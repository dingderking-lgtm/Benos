import { Hono,type Context } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole,rateLimit } from './auth';
import { getWallet } from './ledger';
import { canTopup,activeSubscription } from './commerce';
import { getMembershipStatus } from './memberships';
import { listCatalog,createCatalogVersion,activateCatalog,catalogSchema } from './billing-catalog';
import { textReservationCost } from './ai-billing';

const paging={page:z.coerce.number().int().min(1).max(100000).default(1),limit:z.coerce.number().int().min(1).max(100).default(30)};
const pageSchema=z.object(paging);
function paged<T>(rows:T[],page:number,limit:number){return {items:rows.slice(0,limit),page,limit,hasMore:rows.length>limit};}
function like(q:string){return '%'+q.replace(/[\\%_]/g,'\\$&')+'%';}
// Query strings are user input: an invalid filter is a 400 VALIDATION, never a 500.
export function parseQuery<T>(schema:z.ZodType<T>,raw:unknown):T{const parsed=schema.safeParse(raw);if(parsed.success)return parsed.data;const field=(parsed.error.issues[0]?.path??[]).map(String).join('.');throw new AppError('VALIDATION',field?`筛选条件无效：${field}`:'筛选条件无效');}
function exact(value:unknown){const n=Number(value??0);assert(Number.isSafeInteger(n),'ACCOUNTING_RANGE','汇总金额超出精确核算范围',503);return n;}
export const memberSearchSchema=z.object({...paging,q:z.string().trim().max(160).default(''),role:z.enum(['owner','admin','support','editor','user']).optional(),status:z.enum(['active','restricted']).optional(),tier:z.enum(['go','pro','none']).optional()});
// One statement per page: the page of users, their spendable AI credit (same rules as
// ledger.getWallet availableMicros) and their current unfrozen tier. No per-member
// follow-up queries. topTierSql = current unfrozen tier, pro first (same order as
// commerce.activeSubscription); it feeds both the `tier` column and the `tier` filter,
// so a filtered list never shows a different tier from the one filtered on.
const topTierSql=(user:string)=>`(SELECT s.tier FROM subscriptions s WHERE s.user_id=${user}.id AND s.membership_frozen_by IS NULL AND s.state IN ('active','cancelled') AND s.starts_at<=? AND s.ends_at>? ORDER BY CASE s.tier WHEN 'pro' THEN 0 ELSE 1 END,s.ends_at DESC LIMIT 1)`;
export async function searchMembers(db:D1Database,raw:unknown,nowMs=Date.now()){const q=parseQuery(memberSearchSchema,raw),now=new Date(nowMs).toISOString(),where:string[]=[],values:(string|number)[]=[];
 if(q.q){where.push("(u.email LIKE ? ESCAPE '\\' OR u.name LIKE ? ESCAPE '\\' OR u.id=?)");values.push(like(q.q),like(q.q),q.q);}if(q.role){where.push('u.role=?');values.push(q.role);}if(q.status){where.push('u.status=?');values.push(q.status);}
 if(q.tier){where.push(q.tier==='none'?`${topTierSql('u')} IS NULL`:`${topTierSql('u')}=?`);values.push(now,now,...(q.tier==='none'?[]:[q.tier]));}
 const rows=await db.prepare(`WITH page AS (SELECT u.id,u.email,u.name,u.role,u.status,u.email_verified_at,u.created_at FROM users u WHERE ${where.join(' AND ')||'1=1'} ORDER BY u.created_at DESC,u.id DESC LIMIT ? OFFSET ?),
  credit AS (SELECT g.user_id,SUM(CASE WHEN g.entitlement_revoked_by IS NULL AND g.membership_frozen_by IS NULL AND (g.expires_at_ms IS NULL OR g.expires_at_ms>?) AND g.starts_at_ms<=? THEN g.amount_micros-g.consumed_micros-g.reserved_micros-g.reversed_micros ELSE 0 END) available FROM credit_grants g JOIN page m ON m.id=g.user_id GROUP BY g.user_id)
  SELECT m.*,(SELECT COUNT(*) FROM projects p WHERE p.user_id=m.id AND p.archived_at IS NULL) project_count,
   ${topTierSql('m')} tier,
   COALESCE(c.available,0) available_micros FROM page m LEFT JOIN credit c ON c.user_id=m.id ORDER BY m.created_at DESC,m.id DESC`).bind(...values,q.limit+1,(q.page-1)*q.limit,nowMs,nowMs,now,now).all<{id:string;email:string;name:string;role:string;status:string;email_verified_at:string|null;created_at:string;project_count:number;tier:'go'|'pro'|null;available_micros:number}>();
 return {...paged(rows.results.map(({available_micros,...r})=>({...r,tier:r.tier??null,availableMicros:exact(available_micros)})),q.page,q.limit),filters:q};}
export async function memberFinancials(env:Env,userId:string){
 const user=await env.DB.prepare('SELECT id,email,name,role,status,email_verified_at,created_at FROM users WHERE id=?').bind(userId).first();assert(user,'NOT_FOUND','会员不存在',404);
 const [wallet,subscription,topupAllowed,membership,restrictions]=await Promise.all([getWallet(env.DB,userId),activeSubscription(env.DB,userId),canTopup(env.DB,userId),getMembershipStatus(env.DB,userId),env.DB.prepare('SELECT id,scope,reason,starts_at,ends_at,revoked_at,created_at FROM user_restrictions WHERE user_id=? ORDER BY created_at DESC').bind(userId).all()]);
 return {user,wallet,subscription,canTopup:topupAllowed,membership,restrictions:restrictions.results};
}
export async function walletLiabilities(db:D1Database,nowMs=Date.now()){
 // Each unspent micro-dollar belongs to one exclusive bucket. Unknown holds
 // remain obligations even when the original period expired or was revoked.
 const rows=await db.prepare(`WITH amounts AS (SELECT *,amount_micros-consumed_micros-reserved_micros-reversed_micros remaining FROM credit_grants),classified AS (SELECT *,CASE WHEN entitlement_revoked_by IS NOT NULL THEN 'revoked' WHEN membership_frozen_by IS NOT NULL THEN 'paused' WHEN expires_at_ms IS NOT NULL AND expires_at_ms<=?1 THEN 'expired' WHEN starts_at_ms>?1 THEN 'future' ELSE 'available' END bucket FROM amounts)
  SELECT source,COUNT(*) grants,COUNT(DISTINCT user_id) users,COALESCE(SUM(amount_micros),0) grantedMicros,COALESCE(SUM(consumed_micros),0) consumedMicros,COALESCE(SUM(reversed_micros),0) reversedMicros,COALESCE(SUM(reserved_micros),0) heldMicros,
   COALESCE(SUM(CASE WHEN bucket='available' THEN remaining ELSE 0 END),0) availableMicros,COALESCE(SUM(CASE WHEN bucket='future' THEN remaining ELSE 0 END),0) futureMicros,COALESCE(SUM(CASE WHEN bucket='paused' THEN remaining ELSE 0 END),0) pausedMicros,COALESCE(SUM(CASE WHEN bucket='expired' THEN remaining ELSE 0 END),0) expiredMicros,COALESCE(SUM(CASE WHEN bucket='revoked' THEN remaining ELSE 0 END),0) revokedMicros FROM classified GROUP BY source`).bind(nowMs).all<Record<string,any>>();
 const keys=['grantedMicros','consumedMicros','reversedMicros','heldMicros','availableMicros','futureMicros','pausedMicros','expiredMicros','revokedMicros'] as const;const total=Object.fromEntries(keys.map(k=>[k,0])) as Record<typeof keys[number],number>;for(const row of rows.results)for(const key of keys){assert(Number.isSafeInteger(row[key]),'ACCOUNTING_RANGE','汇总金额超出精确核算范围',503);total[key]+=row[key];assert(Number.isSafeInteger(total[key]),'ACCOUNTING_RANGE','汇总金额超出精确核算范围',503);}
 const obligationMicros=total.availableMicros+total.futureMicros+total.pausedMicros+total.heldMicros;assert(Number.isSafeInteger(obligationMicros),'ACCOUNTING_RANGE','汇总金额超出精确核算范围',503);
 const pools=await db.prepare('SELECT provider_id,funded_micros,consumed_micros,reserved_micros,safety_micros,enabled FROM provider_pools ORDER BY provider_id').all<{provider_id:string;funded_micros:number;consumed_micros:number;reserved_micros:number;safety_micros:number;enabled:number}>(),configs=await db.prepare("SELECT public_config_json FROM integration_configs WHERE kind='text' AND status='active'").all<{public_config_json:string}>(),ceilings=new Map<string,number>();
 for(const c of configs.results){try{const p=JSON.parse(c.public_config_json),cost=textReservationCost(p);ceilings.set(p.providerPoolId,Math.max(ceilings.get(p.providerPoolId)??0,cost));}catch{/* Do not estimate an unaudited model's request ceiling. */}}
 let registeredNetRemainingMicros=0;for(const p of pools.results){registeredNetRemainingMicros+=p.funded_micros-p.consumed_micros;assert(Number.isSafeInteger(registeredNetRemainingMicros),'ACCOUNTING_RANGE','汇总金额超出精确核算范围',503);}
 return {asOfMs:nowMs,total:{...total,obligationMicros},bySource:rows.results.map(r=>({...r,obligationMicros:r.availableMicros+r.futureMicros+r.pausedMicros+r.heldMicros})),pools:pools.results.map(p=>{const availableMicros=p.funded_micros-p.consumed_micros-p.reserved_micros-p.safety_micros,requiredReservationMicros=ceilings.get(p.provider_id)??null;return {...p,availableMicros,requiredReservationMicros,coverageState:!p.enabled?'paused':availableMicros<=0?'empty':requiredReservationMicros!==null&&availableMicros<requiredReservationMicros?'below_request_ceiling':requiredReservationMicros===null?'ceiling_unverified':'available'};}),fundingReference:{registeredNetRemainingMicros,referenceFundingGapMicros:Math.max(0,obligationMicros-registeredNetRemainingMicros),poolsInterchangeable:false},basis:'unconsumed-ai-service-credit',supplierBalanceVerified:false};
}
const orderFilters=z.object({...paging,userId:z.string().max(128).optional(),kind:z.enum(['subscription','topup','hosting']).optional(),state:z.enum(['created','pending','paid','failed','expired','refunded','review']).optional(),q:z.string().max(128).optional()});
export async function queryOrders(db:D1Database,raw:unknown){const q=parseQuery(orderFilters,raw),where:string[]=[],values:(string|number)[]=[];for(const [key,column] of [['userId','o.user_id'],['kind','o.kind'],['state','o.state']] as const)if(q[key]){where.push(column+'=?');values.push(q[key]!);}if(q.q){where.push("(o.id=? OR o.payment_id=? OR u.email LIKE ? ESCAPE '\\')");values.push(q.q,q.q,like(q.q));}const rows=await db.prepare(`SELECT o.id,o.user_id,u.email,o.kind,o.plan_tier,o.amount_cents,o.credit_micros,o.currency,o.state,o.hosting_site_id,o.created_at,o.paid_at,o.fulfilled_at,o.payment_id,o.catalog_version_id,o.plan_snapshot_json FROM orders o JOIN users u ON u.id=o.user_id WHERE ${where.join(' AND ')||'1=1'} ORDER BY o.created_at DESC,o.id DESC LIMIT ? OFFSET ?`).bind(...values,q.limit+1,(q.page-1)*q.limit).all<Record<string,any>>();return paged(rows.results.map(r=>{const {plan_snapshot_json,...safe}=r;return {...safe,planSnapshot:plan_snapshot_json?JSON.parse(plan_snapshot_json):null};}),q.page,q.limit);}
const usageFilters=z.object({...paging,userId:z.string().max(128).optional(),state:z.enum(['reserved','dispatching','uncertain','settled','released']).optional(),providerId:z.string().max(128).optional(),from:z.string().datetime().optional(),to:z.string().datetime().optional()});
export async function queryUsage(db:D1Database,raw:unknown){const q=parseQuery(usageFilters,raw),where:string[]=[],values:(string|number)[]=[];assert(!q.from||!q.to||Date.parse(q.from)<=Date.parse(q.to),'VALIDATION','开始时间不能晚于结束时间');for(const [key,column] of [['userId','r.user_id'],['state','r.state'],['providerId','r.provider_id']] as const)if(q[key]){where.push(column+'=?');values.push(q[key]!);}if(q.from){where.push('r.created_at_ms>=?');values.push(Date.parse(q.from));}if(q.to){where.push('r.created_at_ms<=?');values.push(Date.parse(q.to));}
 const rows=await db.prepare(`SELECT r.*,u.email,CASE WHEN w.id IS NOT NULL THEN 'workflow' WHEN i.id IS NOT NULL THEN 'image' WHEN a.id IS NOT NULL THEN 'text' ELSE 'ledger' END task_kind,COALESCE(w.id,i.id,a.id) task_id,COALESCE(f.project_id,i.project_id,a.project_id) project_id,COALESCE(f.pricing_json,i.pricing_json,a.pricing_json) pricing_json,COALESCE(json_extract(w.response_json,'$.usage'),i.usage_json,a.usage_json) usage_json FROM api_reservations r JOIN users u ON u.id=r.user_id LEFT JOIN ai_workflow_steps w ON w.reservation_id=r.id LEFT JOIN ai_workflows f ON f.id=w.workflow_id LEFT JOIN image_jobs i ON i.reservation_id=r.id LEFT JOIN ai_jobs a ON a.reservation_id=r.id WHERE ${where.join(' AND ')||'1=1'} ORDER BY r.created_at_ms DESC,r.id DESC LIMIT ? OFFSET ?`).bind(...values,q.limit+1,(q.page-1)*q.limit).all<Record<string,any>>();return paged(rows.results.map(r=>({id:r.id,userId:r.user_id,email:r.email,providerId:r.provider_id,state:r.state,reservedMicros:r.amount_micros,actualMicros:r.actual_micros,taskKind:r.task_kind,taskId:r.task_id,projectId:r.project_id,pricing:r.pricing_json?JSON.parse(r.pricing_json):null,usage:r.usage_json?JSON.parse(r.usage_json):null,createdAtMs:r.created_at_ms,completedAtMs:r.completed_at_ms})),q.page,q.limit);}
export const auditFilters=z.object({...paging,actorId:z.string().max(128).optional(),action:z.string().max(128).optional(),entityType:z.string().max(128).optional(),entityId:z.string().max(128).optional(),from:z.string().datetime().optional(),to:z.string().datetime().optional()});
function safeDetails(value:unknown,depth=0):unknown{if(depth>10)return '[depth limit]';if(Array.isArray(value))return value.map(v=>safeDetails(v,depth+1));if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,/password|secret|api.?key|access.?token|refresh.?token|csrf|authorization|ciphertext/i.test(k)?'[redacted]':safeDetails(v,depth+1)]));return value;}
// Compare instants, not strings: `…00Z` and `…00.000Z` are the same time.
export function parseAuditFilters(raw:unknown){const q=parseQuery(auditFilters,raw);assert(!q.from||!q.to||Date.parse(q.from)<=Date.parse(q.to),'VALIDATION','开始时间不能晚于结束时间');return q;}
export async function queryAudit(db:D1Database,raw:unknown,exportAll=false){const q=parseAuditFilters(raw);const where:string[]=[],values:(string|number)[]=[];for(const [key,column] of [['actorId','a.actor_id'],['action','a.action'],['entityType','a.entity_type'],['entityId','a.entity_id']] as const)if(q[key]){where.push(column+'=?');values.push(q[key]!);}if(q.from){where.push('a.created_at>=?');values.push(new Date(Date.parse(q.from)).toISOString());}if(q.to){where.push('a.created_at<=?');values.push(new Date(Date.parse(q.to)).toISOString());}
 const limit=exportAll?5000:q.limit,offset=exportAll?0:(q.page-1)*q.limit,rows=await db.prepare(`SELECT a.id,a.actor_id,u.email actor_email,a.action,a.entity_type,a.entity_id,a.details_json,a.request_id,a.created_at FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id WHERE ${where.join(' AND ')||'1=1'} ORDER BY a.created_at DESC,a.id DESC LIMIT ? OFFSET ?`).bind(...values,limit+1,offset).all<Record<string,any>>();if(exportAll)assert(rows.results.length<=5000,'EXPORT_TOO_LARGE','本次导出超过 5000 条，请缩小时间或操作筛选范围',413);
 return paged(rows.results.map(r=>{let details:unknown;try{details=safeDetails(JSON.parse(r.details_json));}catch{details='[invalid legacy details]';}const {details_json,...rest}=r;return {...rest,details,details_json:JSON.stringify(details)};}),q.page,limit);
}
export function auditCsv(rows:Record<string,any>[]){const columns=['id','actor_id','actor_email','action','entity_type','entity_id','details_json','request_id','created_at'];const cell=(value:unknown)=>{let s=String(value??'');if(/^[\s\x00-\x1f]*[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};return '\ufeff'+[columns.map(cell).join(','),...rows.map(r=>columns.map(k=>cell(r[k])).join(','))].join('\r\n');}

// Revenue = money actually collected on paid orders (gross, selected currency minor units), grouped by the
// time the payment was confirmed. Gifts never create orders, and no cost or margin is
// estimated here. Refunds and lost disputes are reported beside it, never netted.
// Keep this expression identical to the orders_revenue_time index (0050_admin_fixes.sql).
export const REVENUE_TIME_SQL='(CASE WHEN fulfilled_at IS NOT NULL AND fulfilled_at<paid_at THEN fulfilled_at ELSE paid_at END)';
const DAY_MS=86_400_000,MAX_DAY_SPAN=366,MAX_MONTH_SPAN=36;
export const revenueQuery=z.object({from:z.string().datetime().optional(),to:z.string().datetime().optional(),bucket:z.enum(['day','month']).default('day'),mode:z.enum(['all','live','test']).default('all'),currency:z.enum(['USD','CNY']).default('USD')});
const ORDER_KINDS=['subscription','topup','hosting'] as const;
function periodKey(ms:number,bucket:'day'|'month'){return new Date(ms).toISOString().slice(0,bucket==='day'?10:7);}
// Number of buckets [from,to) touches, computed arithmetically so an absurd range is
// rejected before any key is generated (Workers isolates have 128 MB).
export function revenueBucketCount(fromMs:number,toMs:number,bucket:'day'|'month'){
 if(bucket==='day'){const first=Math.floor(fromMs/DAY_MS)*DAY_MS;return Math.ceil((toMs-first)/DAY_MS);}
 const from=new Date(fromMs),to=new Date(toMs),toMonthStart=Date.UTC(to.getUTCFullYear(),to.getUTCMonth(),1);
 return (to.getUTCFullYear()-from.getUTCFullYear())*12+(to.getUTCMonth()-from.getUTCMonth())+(toMs>toMonthStart?1:0);}
function revenuePeriods(fromMs:number,toMs:number,bucket:'day'|'month'){const keys:string[]=[],cursor=new Date(fromMs);cursor.setUTCHours(0,0,0,0);if(bucket==='month')cursor.setUTCDate(1);
 while(cursor.getTime()<toMs){keys.push(periodKey(cursor.getTime(),bucket));if(bucket==='day')cursor.setUTCDate(cursor.getUTCDate()+1);else cursor.setUTCMonth(cursor.getUTCMonth()+1);}return keys;}
const REVENUE_MODE_SQL="(CASE WHEN json_extract(c.public_config_json,'$.mode')='sandbox' THEN 'test' ELSE COALESCE(json_extract(c.public_config_json,'$.mode'),'unknown') END)";
// The exact statement revenueSeries runs (exported so tests can EXPLAIN it).
export function revenueOrdersSql(mode:'all'|'live'|'test'){const time=REVENUE_TIME_SQL.replace(/(fulfilled_at|paid_at)/g,'o.$1');
 return `SELECT substr(${time},1,?) period,o.kind,o.currency,${REVENUE_MODE_SQL} mode,COUNT(*) orders,COALESCE(SUM(o.amount_cents),0) cents FROM orders o LEFT JOIN integration_configs c ON c.id=o.config_version_id WHERE o.state IN ('paid','refunded') AND o.paid_at IS NOT NULL AND ${time}>=? AND ${time}<?${mode==='all'?'':` AND ${REVENUE_MODE_SQL}=?`} GROUP BY period,o.kind,o.currency,mode`;}
export async function revenueSeries(db:D1Database,raw:unknown,nowMs=Date.now()){
 const q=parseQuery(revenueQuery,raw),toMs=q.to?Date.parse(q.to):nowMs,start=new Date(toMs-1);start.setUTCHours(0,0,0,0);
 if(q.bucket==='day')start.setUTCDate(start.getUTCDate()-29);else{start.setUTCDate(1);start.setUTCMonth(start.getUTCMonth()-11);}
 const fromMs=q.from?Date.parse(q.from):start.getTime();
 assert(fromMs<toMs,'VALIDATION','开始时间必须早于结束时间');
 assert(revenueBucketCount(fromMs,toMs,q.bucket)<=(q.bucket==='day'?MAX_DAY_SPAN:MAX_MONTH_SPAN),'VALIDATION',q.bucket==='day'?'按日统计最多 366 天，请缩小时间范围或按月统计':'按月统计最多 36 个月，请缩小时间范围');
 const periods=revenuePeriods(fromMs,toMs,q.bucket);
 assert(periods.length<=(q.bucket==='day'?MAX_DAY_SPAN:MAX_MONTH_SPAN),'VALIDATION','统计范围无效');
 const from=new Date(fromMs).toISOString(),to=new Date(toMs).toISOString(),modeSql=REVENUE_MODE_SQL,modeFilter=q.mode==='all'?'':` AND ${modeSql}=?`,modeValues=q.mode==='all'?[]:[q.mode];
 const [orders,cases]=await Promise.all([
  db.prepare(revenueOrdersSql(q.mode)).bind(q.bucket==='day'?10:7,from,to,...modeValues).all<{period:string;kind:typeof ORDER_KINDS[number];currency:string;mode:string;orders:number;cents:number}>(),
  db.prepare(`SELECT f.kind,COUNT(*) cases,COALESCE(SUM(f.amount_cents),0) cents,SUM(CASE WHEN f.amount_cents IS NULL THEN 1 ELSE 0 END) unknown FROM financial_cases f LEFT JOIN integration_configs c ON c.id=f.config_version_id WHERE ((f.kind='refund' AND f.provider_state='succeeded') OR (f.kind='dispute' AND f.provider_state='lost')) AND f.created_at>=? AND f.created_at<? AND upper(COALESCE(f.currency,'USD'))=?${modeFilter} GROUP BY f.kind`).bind(from,to,q.currency,...modeValues).all<{kind:string;cases:number;cents:number;unknown:number}>()
 ]);
 const empty=()=>({subscriptionCents:0,topupCents:0,hostingCents:0,totalCents:0,orders:0}),series=new Map(periods.map(period=>[period,{period,...empty()}])),totals=empty(),byMode:Record<'live'|'test'|'unknown',{cents:number;orders:number}>={live:{cents:0,orders:0},test:{cents:0,orders:0},unknown:{cents:0,orders:0}};
 for(const row of orders.results){if(row.currency!==q.currency)continue;const cents=exact(row.cents),count=exact(row.orders),point=series.get(row.period);assert(point&&ORDER_KINDS.includes(row.kind),'ACCOUNTING_RANGE','收入记录超出统计范围，请核对订单时间',503);
  for(const target of [point,totals]){target[`${row.kind}Cents`]=exact(target[`${row.kind}Cents`]+cents);target.totalCents=exact(target.totalCents+cents);target.orders+=count;}
  const mode=row.mode==='live'||row.mode==='test'?row.mode:'unknown';byMode[mode].cents=exact(byMode[mode].cents+cents);byMode[mode].orders+=count;}
 const caseTotal=(kind:string)=>{const row=cases.results.find(r=>r.kind===kind);return {cases:exact(row?.cases),amountCents:exact(row?.cents),unknownAmountCases:exact(row?.unknown)};};
 return {from,to,bucket:q.bucket,mode:q.mode,currency:q.currency,timezone:'UTC',series:[...series.values()],totals,byMode,refunds:caseTotal('refund'),disputesLost:caseTotal('dispute'),
  basis:{revenue:'paid_orders_gross',time:'payment_confirmed_utc',giftsIncluded:false,costIncluded:false,refundsDeducted:false}};
}
// Every field carries a Chinese message for missing or wrong-type values; catalogInput()
// covers what is left (nested catalogue fields, unknown keys) so no English text is returned.
const reasonInput=z.string({error:'请填写变更原因'}).trim().min(3,'请填写 3–500 字的变更原因').max(500,'变更原因最多 500 字');
const catalogCreateInput=z.object({catalog:catalogSchema,reason:reasonInput,requestKey:z.string({error:'缺少请求编号'}).regex(/^[\w:-]{16,128}$/,'请求编号格式无效')}).strict();
const catalogActivateInput=z.object({expectedVersionId:z.string({error:'缺少当前版本编号'}).min(1,'缺少当前版本编号').max(128,'当前版本编号无效'),enabled:z.boolean({error:'请选择启用或停用'}),reason:reasonInput,confirmedFutureOrdersOnly:z.literal(true,{error:'请确认此变更仅影响之后的新订单'})}).strict();
async function catalogInput<T>(c:Context<App>,schema:z.ZodType<T>):Promise<T>{
 const parsed=schema.safeParse(await body(c,z.unknown()));if(parsed.success)return parsed.data;
 const issue=parsed.error.issues[0],message=issue?.message??'',field=(issue?.path??[]).map(String).join('.');
 throw new AppError('VALIDATION',/[一-鿿]/.test(message)?message:issue?.code==='unrecognized_keys'?'提交内容包含不支持的字段':field?`请检查填写内容：${field}`:'请检查填写内容');}

export const adminOperationsRoutes=new Hono<App>();adminOperationsRoutes.use('*',requireAuth,requireRole('owner','admin','support'));
adminOperationsRoutes.get('/members',async c=>ok(c,await searchMembers(c.env.DB,c.req.query())));
adminOperationsRoutes.get('/members/:id',async c=>ok(c,await memberFinancials(c.env,c.req.param('id'))));
adminOperationsRoutes.get('/revenue',requireRole('owner','admin'),async c=>ok(c,await revenueSeries(c.env.DB,c.req.query())));
adminOperationsRoutes.get('/members/:id/adjustments',async c=>{const q=parseQuery(pageSchema,c.req.query());const rows=await c.env.DB.prepare('SELECT a.id,a.case_id,a.order_id,a.grant_id,a.actor_id,a.direction,a.parent_id,a.amount_micros,a.reason,a.evidence,a.created_at FROM financial_credit_adjustments a JOIN credit_grants g ON g.id=a.grant_id WHERE g.user_id=? ORDER BY a.created_at DESC,a.id DESC LIMIT ? OFFSET ?').bind(c.req.param('id'),q.limit+1,(q.page-1)*q.limit).all();return ok(c,paged(rows.results,q.page,q.limit));});
adminOperationsRoutes.get('/orders',async c=>ok(c,await queryOrders(c.env.DB,c.req.query())));
adminOperationsRoutes.get('/usage',async c=>ok(c,await queryUsage(c.env.DB,c.req.query())));
adminOperationsRoutes.get('/liabilities',requireRole('owner','admin'),async c=>ok(c,await walletLiabilities(c.env.DB)));
adminOperationsRoutes.get('/catalog',requireRole('owner','admin'),async c=>ok(c,await listCatalog(c.env.DB)));
adminOperationsRoutes.post('/catalog',requireRole('owner'),async c=>ok(c,await createCatalogVersion(c.env,c.get('auth').user.id,await catalogInput(c,catalogCreateInput)),201));
adminOperationsRoutes.post('/catalog/:id/activate',requireRole('owner'),async c=>ok(c,await activateCatalog(c.env,c.get('auth').user.id,c.req.param('id'),await catalogInput(c,catalogActivateInput))));
adminOperationsRoutes.get('/audit',requireRole('owner','admin'),async c=>ok(c,await queryAudit(c.env.DB,c.req.query())));
adminOperationsRoutes.get('/audit/export',requireRole('owner','admin'),async c=>{const filters=parseAuditFilters(c.req.query());await rateLimit(c,'audit-export',10,3600,c.get('auth').user.id);const data=await queryAudit(c.env.DB,filters,true);await auditStatement(c.env.DB,c.get('auth').user.id,'audit.exported','audit',null,{filters,rowCount:data.items.length},c.get('requestId')).run();return new Response(auditCsv(data.items),{headers:{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="benos-audit.csv"','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});});


