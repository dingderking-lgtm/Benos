import { Hono } from 'hono';
import { patchHeroAlignment } from '../lib/hero-alignment';
import { z } from 'zod';
import { inlineTextPartsSchema } from './design-text-parts';
import type { Env } from '../env';
import { body,ok,type App } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id,sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,rateLimit } from './auth';
import { validateSiteManifest } from './template-contract';
import { listMedia,mediaReferencesAvailableStatement } from './media';
import { DESIGN_FONTS,describeDesignNodes,assertDesignScope,patchDesignStyle,patchDesignText,patchDesignInlineText,patchDesignImage,type DesignScope,type DesignManifest } from './design-nodes';
import { starterManifest } from '../contracts/starter-library';
import { starterCatalogue,isStarterPackage } from '../lib/starter-packages';
import { importStarterPackage } from './template-import';
import { streamTemplateZip } from '../lib/template-archive';
import { verifyProjectAssets,indexProjectAssets,readIndexedAsset } from './project-assets';
import { loadTypographySnapshot,typographySnapshotStatement,copyTypographySnapshotStatement,isTypographyMutation,patchTypographySelection,enforceTypographySnapshot } from '../lib/design-typography';
import { type TypographySnapshot } from '../contracts/design-typography';
import { typographyScopeProjection } from '../lib/header-typography';
import { prepareDesignManifestStorage,readStoredManifest,readStoredManifestJson,serializeDesignManifest,storedManifestSummary } from '../lib/design-storage';
export { describeDesignNodes,assertDesignScope,type DesignScope } from './design-nodes';
type Candidate={id:string;user_id:string;project_id:string;request_key:string;request_hash:string;base_version_id:string|null;manifest_json:string;manifest_object_id:string|null;scope_json:string;state:string;adopted_version_id:string|null;source:'manual'|'ai'|'template';created_at:string;updated_at:string};
export async function ownedDesignProject(env:Env,userId:string,projectId:string){const row=await env.DB.prepare('SELECT id,name,description,current_version_id FROM projects WHERE id=? AND user_id=? AND archived_at IS NULL').bind(projectId,userId).first<{id:string;name:string;description:string;current_version_id:string|null}>();assert(row,'NOT_FOUND','项目不存在',404);return row;}
export async function readDesignVersion(env:Env,userId:string,projectId:string,versionId:string,maxBytes?:number){await ownedDesignProject(env,userId,projectId);const row=await env.DB.prepare('SELECT manifest_json,manifest_object_id,content_hash FROM design_versions WHERE id=? AND project_id=?').bind(versionId,projectId).first<{manifest_json:string;manifest_object_id:string|null;content_hash:string}>();assert(row,'NOT_FOUND','设计版本不存在',404);if(maxBytes!==undefined){const byteSize=row.manifest_object_id?JSON.parse(row.manifest_json).byteSize:new TextEncoder().encode(row.manifest_json).byteLength;assert(Number.isSafeInteger(byteSize)&&byteSize<=maxBytes,'WORKSPACE_TOO_LARGE','该设计清单超过当前 AI 工作流处理上限，请使用模板编辑或导入流程',413);}return await readStoredManifest(env,row,{userId,projectId}) as DesignManifest;}
const view=(row:Candidate)=>({id:row.id,state:row.state,baseVersionId:row.base_version_id,versionId:row.adopted_version_id,previewUrl:`/preview/${encodeURIComponent(row.project_id)}/candidate/${encodeURIComponent(row.id)}`,scope:JSON.parse(row.scope_json) as DesignScope,createdAt:row.created_at});
async function readCandidateIndex(env:Env,userId:string,projectId:string,candidateId:string){await ownedDesignProject(env,userId,projectId);const row=await env.DB.prepare('SELECT * FROM design_candidates WHERE id=? AND user_id=? AND project_id=?').bind(candidateId,userId,projectId).first<Candidate>();assert(row,'NOT_FOUND','设计方案不存在',404);return row;}
export async function readDesignCandidate(env:Env,userId:string,projectId:string,candidateId:string){const row=await readCandidateIndex(env,userId,projectId,candidateId);return {...row,stored_manifest_json:row.manifest_json,manifest_json:await readStoredManifestJson(env,row,{userId,projectId})};}
export async function saveDesignCandidate(env:Env,input:{userId:string;projectId:string;requestKey:string;baseVersionId:string|null;scope:DesignScope;manifest:unknown;source:'manual'|'ai'|'template';workflowId?:string;typography?:TypographySnapshot|null}){
 const project=await ownedDesignProject(env,input.userId,input.projectId),typography=input.typography??(input.baseVersionId?await loadTypographySnapshot(env,input.userId,input.projectId,'version',input.baseVersionId):null),hash=await sha256(JSON.stringify({base:input.baseVersionId,scope:input.scope,manifest:input.manifest,source:input.source,workflowId:input.workflowId??null,...(typography?{typography}:{})}));
 const previous=await env.DB.prepare('SELECT * FROM design_candidates WHERE user_id=? AND request_key=?').bind(input.userId,input.requestKey).first<Candidate>();
 if(previous){assert(previous.project_id===input.projectId&&previous.request_hash===hash,'IDEMPOTENCY_CONFLICT','方案编号已用于其他修改',409);return view(previous);}
 assert(project.current_version_id===input.baseVersionId,'VERSION_CONFLICT','设计已有更新，请刷新后重新选择修改范围',409);
 const checked=validateSiteManifest(input.manifest);assert(checked.valid,'TEMPLATE_INVALID','设计方案未通过结构检查',422);
 serializeDesignManifest(input.manifest);
 const base=input.baseVersionId?await readDesignVersion(env,input.userId,input.projectId,input.baseVersionId):null;
 if(input.source==='ai'&&typography)assert(JSON.stringify(enforceTypographySnapshot(input.manifest,typography))===JSON.stringify(input.manifest),'TYPOGRAPHY_CONFLICT','AI 修改必须保留已保存的字体设置',409);
 // Replacing an existing site with a starter would silently discard content.
 if(input.source==='template')assert(base===null,'TEMPLATE_PROJECT_NOT_EMPTY','起步模板仅可应用到尚未设计的项目，已有网站请通过保留数据的设计流程修改',409);
 assertDesignScope(base,base&&input.source==='manual'&&input.typography?typographyScopeProjection(base,input.manifest,input.typography):input.manifest,input.scope);await verifyProjectAssets(env,input.userId,input.projectId,input.manifest);
 const storage=await prepareDesignManifestStorage(env,input.userId,input.projectId,input.manifest);
 const candidateId=id('candidate'),guard=id('guard'),mediaGuard=id('guard'),now=new Date().toISOString();
 try{await env.DB.batch([
  env.DB.prepare('INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM projects WHERE id=? AND user_id=? AND archived_at IS NULL AND current_version_id IS ?) THEN 1 ELSE 0 END').bind(guard,input.projectId,input.userId,input.baseVersionId),
  mediaReferencesAvailableStatement(env.DB,input.userId,input.projectId,input.manifest,mediaGuard),
  env.DB.prepare("INSERT INTO design_candidates(id,user_id,project_id,request_key,request_hash,base_version_id,scope_json,manifest_json,manifest_object_id,source,workflow_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,request_key) DO NOTHING").bind(candidateId,input.userId,input.projectId,input.requestKey,hash,input.baseVersionId,JSON.stringify(input.scope),storage.manifestJson,storage.objectId,input.source,input.workflowId??null,now,now),
  ...(typography?[typographySnapshotStatement(env.DB,{kind:'candidate',sourceId:candidateId,userId:input.userId,projectId:input.projectId,manifestHash:await sha256(JSON.stringify(input.manifest)),profile:typography,now})]:[]),
  env.DB.prepare('DELETE FROM mutation_guards WHERE id IN (?,?)').bind(guard,mediaGuard)
 ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('VERSION_CONFLICT','设计或素材已更新，请刷新后重试',409);throw error;}
 const saved=await env.DB.prepare('SELECT * FROM design_candidates WHERE user_id=? AND request_key=?').bind(input.userId,input.requestKey).first<Candidate>();assert(saved&&saved.project_id===input.projectId&&saved.request_hash===hash,'IDEMPOTENCY_CONFLICT','方案编号已用于其他修改',409);return view(saved);
}
export async function adoptDesignCandidate(env:Env,userId:string,projectId:string,candidateId:string){
 const row=await readDesignCandidate(env,userId,projectId,candidateId);if(row.state==='adopted')return {versionId:row.adopted_version_id};assert(row.state==='draft','CANDIDATE_CLOSED','此方案已经放弃',409);
 const manifest=JSON.parse(row.manifest_json);await verifyProjectAssets(env,userId,projectId,manifest);
 const versionId=id('ver'),guard=id('guard'),mediaGuard=id('guard'),now=new Date().toISOString();
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM projects p JOIN design_candidates d ON d.project_id=p.id WHERE p.id=? AND p.user_id=? AND p.archived_at IS NULL AND p.current_version_id IS d.base_version_id AND d.id=? AND d.state='draft') THEN 1 ELSE 0 END`).bind(guard,projectId,userId,candidateId),
  mediaReferencesAvailableStatement(env.DB,userId,projectId,manifest,mediaGuard),
  env.DB.prepare('INSERT INTO design_versions(id,project_id,parent_id,version,source,manifest_json,manifest_object_id,content_hash,created_by,created_at) SELECT ?,?,?,COALESCE(MAX(version),0)+1,?,?,?,?,?,? FROM design_versions WHERE project_id=?').bind(versionId,projectId,row.base_version_id,row.source==='template'?'import':row.source,row.stored_manifest_json,row.manifest_object_id,await sha256(row.manifest_json),userId,now,projectId),
  copyTypographySnapshotStatement(env.DB,{fromKind:'candidate',fromId:candidateId,toKind:'version',toId:versionId,userId,projectId,manifestHash:await sha256(row.manifest_json),now}),
  env.DB.prepare("UPDATE projects SET current_version_id=?,status=CASE WHEN published_version_id IS NULL THEN 'draft' ELSE 'modified' END,updated_at=? WHERE id=?").bind(versionId,now,projectId),
  env.DB.prepare("UPDATE design_candidates SET state='adopted',adopted_version_id=?,updated_at=? WHERE id=?").bind(versionId,now,candidateId),
  auditStatement(env.DB,userId,'design.candidate_adopted','project',projectId,{candidateId,versionId,scope:JSON.parse(row.scope_json)},candidateId),env.DB.prepare('DELETE FROM mutation_guards WHERE id IN (?,?)').bind(guard,mediaGuard)
 ]);}catch(error){if(String(error).includes('mutation_revision_ok')){const current=await readDesignCandidate(env,userId,projectId,candidateId);if(current.state==='adopted')return {versionId:current.adopted_version_id};throw new AppError('VERSION_CONFLICT','当前设计或素材已变化，原方案保留供对照',409);}throw error;}
 return {versionId};
}
const scopeSchema=z.discriminatedUnion('kind',[z.object({kind:z.literal('node'),templateId:z.number().int().positive(),nodeKey:z.string().regex(/^n\d{1,9}$/)}).strict(),z.object({kind:z.literal('site')}).strict()]);
const requestKey=z.string().regex(/^[a-zA-Z0-9:_-]{16,128}$/);
export const designWorkspaceRoutes=new Hono<App>();designWorkspaceRoutes.use('*',requireAuth);
designWorkspaceRoutes.get('/templates',c=>ok(c,{items:starterCatalogue.map(t=>({...t,previewUrl:'/preview/starter/'+t.id}))}));
designWorkspaceRoutes.post('/projects/:project/templates/:template',async c=>{const input=await body(c,z.object({requestKey,baseVersionId:z.string().nullable()}).strict());if(isStarterPackage(c.req.param('template')))return ok(c,await importStarterPackage(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('template')),201);const project=await ownedDesignProject(c.env,c.get('auth').user.id,c.req.param('project')),manifest=starterManifest(c.req.param('template'),project.name);assert(manifest,'NOT_FOUND','起步模板不存在',404);return ok(c,await saveDesignCandidate(c.env,{userId:c.get('auth').user.id,projectId:project.id,requestKey:input.requestKey,baseVersionId:input.baseVersionId,scope:{kind:'site'},manifest,source:'template'}),201);});
designWorkspaceRoutes.get('/projects/:project/versions/:version/package',async c=>{const user=c.get('auth').user.id,manifest=await readDesignVersion(c.env,user,c.req.param('project'),c.req.param('version')),assets=await indexProjectAssets(c.env,user,c.req.param('project'),manifest),archive=streamTemplateZip(manifest,assets.items.map(item=>({file:item.file,size:item.size,load:()=>readIndexedAsset(c.env,user,item)})));return new Response(archive.stream,{headers:{'Content-Type':'application/zip','Content-Disposition':'attachment; filename="benos-site-package.zip"','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Length':String(archive.byteSize)}});});
designWorkspaceRoutes.get('/projects/:project/nodes',async c=>{const version=c.req.query('version');assert(version,'VERSION_REQUIRED','请选择设计版本');return ok(c,{items:describeDesignNodes(await readDesignVersion(c.env,c.get('auth').user.id,c.req.param('project'),version)),styleOptions:{fonts:DESIGN_FONTS}});});
designWorkspaceRoutes.get('/projects/:project/candidates',async c=>{await ownedDesignProject(c.env,c.get('auth').user.id,c.req.param('project'));const rows=await c.env.DB.prepare("SELECT id,state,base_version_id,adopted_version_id,project_id,scope_json,created_at FROM design_candidates WHERE project_id=? AND user_id=? AND state='draft' ORDER BY created_at DESC LIMIT 30").bind(c.req.param('project'),c.get('auth').user.id).all<Candidate>();return ok(c,{items:rows.results.map(view)});});
designWorkspaceRoutes.get('/projects/:project/candidates/:candidate',async c=>{if(c.req.query('projection')==='summary'){const row=await readCandidateIndex(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('candidate'));return ok(c,{...view(row),summary:storedManifestSummary(row)});}const row=await readDesignCandidate(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('candidate'));return ok(c,{...view(row),manifest:JSON.parse(row.manifest_json)});});
designWorkspaceRoutes.post('/projects/:project/candidates',async c=>{
 await rateLimit(c,'design-candidate',90,60,c.get('auth').user.id);
 const input=await body(c,z.object({requestKey,baseVersionId:z.string(),scope:scopeSchema,operation:z.discriminatedUnion('kind',[z.object({kind:z.literal('heroAlignment')}).strict(),z.object({kind:z.literal('style'),properties:z.record(z.string(),z.union([z.string(),z.number()]))}).strict(),z.object({kind:z.literal('image'),assetPath:z.string().max(300),alt:z.string().max(300).optional(),presentation:z.object({fit:z.enum(['cover','contain']),focalPoint:z.enum(['center','left','right','top','bottom'])}).strict().optional()}).strict(),z.object({kind:z.literal('text'),text:z.string().max(8000).optional(),slots:inlineTextPartsSchema.shape.slots.optional(),children:inlineTextPartsSchema.shape.children.optional()}).strict()])}).strict());
 const base=await readDesignVersion(c.env,c.get('auth').user.id,c.req.param('project'),input.baseVersionId);let manifest:unknown,typography:TypographySnapshot|undefined;
 if(input.operation.kind==='heroAlignment')manifest=patchHeroAlignment(base,input.scope);
 else if(input.operation.kind==='style'){
  if(isTypographyMutation(input.operation.properties)){
   const previous=await loadTypographySnapshot(c.env,c.get('auth').user.id,c.req.param('project'),'version',input.baseVersionId),changed=await patchTypographySelection(base,input.scope,input.operation.properties,previous,input.requestKey);manifest=changed.manifest;typography=changed.profile;
  }else manifest=patchDesignStyle(base,input.scope,input.operation.properties);
 }
 else if(input.operation.kind==='text'){const operation=input.operation;assert(typeof operation.text==='string'?!operation.slots&&!operation.children:!!operation.slots&&!!operation.children,'VALIDATION','文字修改参数无效',422);manifest=typeof operation.text==='string'?patchDesignText(base,input.scope,operation.text):patchDesignInlineText(base,input.scope,{slots:operation.slots!,children:operation.children!});}
 else{const operation=input.operation,media=(await listMedia(c.env,c.get('auth').user.id,c.req.param('project'))).find(m=>m.assetPath===operation.assetPath&&m.mimeType.startsWith('image/'));assert(media,'MEDIA_NOT_FOUND','请选择此项目已上传的图片，PDF 仅用于下载链接',422);let asset=base.assets.find(a=>a.path===media.assetPath);if(!asset){const used=new Set(base.assets.map(a=>a.file));let n=0;while(n<100&&used.has(`assets/${n}.${media.extension}`))n++;assert(n<100,'ASSET_LIMIT','图片清单已满');asset={file:`assets/${n}.${media.extension}`,path:media.assetPath,sha256:media.sha256,size:media.byteSize};}manifest=patchDesignImage(base,input.scope,asset,operation.alt,operation.presentation?{dimensions:{width:media.width,height:media.height},presentation:operation.presentation}:undefined);}
 return ok(c,await saveDesignCandidate(c.env,{userId:c.get('auth').user.id,projectId:c.req.param('project'),requestKey:input.requestKey,baseVersionId:input.baseVersionId,scope:input.scope,manifest,source:'manual',...(typography?{typography}:{})}),201);
});
designWorkspaceRoutes.post('/projects/:project/candidates/:candidate/adopt',async c=>{await body(c,z.object({}).strict());return ok(c,await adoptDesignCandidate(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('candidate')));});
designWorkspaceRoutes.post('/projects/:project/candidates/:candidate/discard',async c=>{await body(c,z.object({}).strict());const row=await readDesignCandidate(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('candidate'));assert(row.state!=='adopted','CANDIDATE_ADOPTED','已采用方案请通过版本恢复撤销，不能抹除历史',409);await c.env.DB.batch([c.env.DB.prepare("UPDATE design_candidates SET state='discarded',updated_at=? WHERE id=? AND state='draft'").bind(new Date().toISOString(),row.id),auditStatement(c.env.DB,c.get('auth').user.id,'design.candidate_discarded','candidate',row.id,{},c.get('requestId'))]);return ok(c,{discarded:true});});
