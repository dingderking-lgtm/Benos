import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { AppError,assert } from '../lib/errors';
import { id } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole } from './auth';
import { contentMediaId,contentMediaGuard,publicMediaPath,readContentMedia } from './content-media';

const plain=(max:number,min=0)=>z.string().trim().min(min).max(max).refine(value=>!/[<>\x00-\x1f\x7f]/.test(value),'请使用普通文本');
const configuration=z.object({
 brandName:plain(80,1),tagline:plain(240),logoMediaId:contentMediaId.nullable(),
 contactEmail:z.union([z.literal(''),z.string().email().max(254)]),
 contactPhone:plain(100),contactAddress:plain(500),
 contactUrl:z.union([z.literal(''),z.string().url().max(2000).refine(value=>{try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password;}catch{return false;}},'联系链接必须为 HTTPS 地址')])
}).strict();
export type PlatformBrand=z.infer<typeof configuration>;
export const defaultPlatformBrand:PlatformBrand={brandName:'Benos',tagline:'让每个想法拥有自己的空间。',logoMediaId:null,contactEmail:'',contactPhone:'',contactAddress:'',contactUrl:''};
type Version={id:string;version:number;configuration_json:string;state:string;actor_id:string;reason:string;created_at:string;tested_at:string|null};
const reason=z.object({reason:plain(1000,3)}).strict();
function view(row:Version){const config=JSON.parse(row.configuration_json) as PlatformBrand;return {id:row.id,version:row.version,state:row.state,configuration:config,logoUrl:config.logoMediaId?publicMediaPath(config.logoMediaId):'/assets/brand/benos-logo.svg',createdAt:row.created_at,testedAt:row.tested_at,reason:row.reason};}
export async function activePlatformBrand(env:Env){const row=await env.DB.prepare("SELECT * FROM platform_brand_versions WHERE state='active'").first<Version>();const brand=row?JSON.parse(row.configuration_json) as PlatformBrand:defaultPlatformBrand;return {...brand,versionId:row?.id||null,logoUrl:brand.logoMediaId?publicMediaPath(brand.logoMediaId):'/assets/brand/benos-logo.svg'};}
export const platformBrandRoutes=new Hono<App>();platformBrandRoutes.get('/',async c=>ok(c,await activePlatformBrand(c.env)));
export const adminSettingsRoutes=new Hono<App>();adminSettingsRoutes.use('*',requireAuth,requireRole('owner','admin'));
adminSettingsRoutes.get('/branding',async c=>ok(c,{active:await activePlatformBrand(c.env),items:(await c.env.DB.prepare('SELECT * FROM platform_brand_versions ORDER BY version DESC LIMIT 100').all<Version>()).results.map(view),canManage:c.get('auth').user.role==='owner'}));
adminSettingsRoutes.post('/branding',requireRole('owner'),async c=>{
 const input=await body(c,z.object({configuration,reason:reason.shape.reason}).strict()),versionId=id('brand'),user=c.get('auth').user.id,time=new Date().toISOString();
 try{await c.env.DB.batch([...contentMediaGuard(c.env,input.configuration.logoMediaId),c.env.DB.prepare("INSERT INTO platform_brand_versions(id,version,configuration_json,actor_id,reason,created_at) SELECT ?,COALESCE(MAX(version),0)+1,?,?,?,? FROM platform_brand_versions").bind(versionId,JSON.stringify(input.configuration),user,input.reason,time),auditStatement(c.env.DB,user,'settings.brand.create','brand_version',versionId,{configuration:input.configuration,reason:input.reason},c.get('requestId'))]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('BRAND_LOGO_UNAVAILABLE','所选 Logo 素材不可用',409);throw error;}
 return ok(c,view((await c.env.DB.prepare('SELECT * FROM platform_brand_versions WHERE id=?').bind(versionId).first<Version>())!),201);
});
for(const operation of ['test','activate','disable'] as const)adminSettingsRoutes.post('/branding/:id/'+operation,requireRole('owner'),async c=>{
 const input=await body(c,reason),row=await c.env.DB.prepare('SELECT * FROM platform_brand_versions WHERE id=?').bind(c.req.param('id')).first<Version>();assert(row,'NOT_FOUND','品牌配置版本不存在',404);const config=configuration.parse(JSON.parse(row.configuration_json)),time=new Date().toISOString(),user=c.get('auth').user.id;
 if(operation==='test'){
  if(config.logoMediaId){const response=await readContentMedia(c.env,config.logoMediaId);assert(response.ok,'BRAND_LOGO_UNAVAILABLE','Logo 素材未通过实际字节校验',409);}
  await c.env.DB.batch([c.env.DB.prepare("UPDATE platform_brand_versions SET state=CASE WHEN state='active' THEN 'active' ELSE 'tested' END,tested_at=? WHERE id=?").bind(time,row.id),auditStatement(c.env.DB,user,'settings.brand.test','brand_version',row.id,{reason:input.reason,logoBytesVerified:!!config.logoMediaId},c.get('requestId'))]);
 }else if(operation==='activate'){
  assert(row.tested_at&&['tested','disabled','active'].includes(row.state),'BRAND_TEST_REQUIRED','请先校验配置与 Logo 素材',409);
  const guard=id('guard');try{await c.env.DB.batch([
   ...contentMediaGuard(c.env,config.logoMediaId),
   c.env.DB.prepare("INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM platform_brand_versions WHERE id=? AND tested_at IS NOT NULL) THEN 1 ELSE 0 END").bind(guard,row.id),
   c.env.DB.prepare("UPDATE platform_brand_versions SET state='disabled' WHERE state='active' AND id<>?").bind(row.id),c.env.DB.prepare("UPDATE platform_brand_versions SET state='active' WHERE id=?").bind(row.id),
   auditStatement(c.env.DB,user,'settings.brand.activate','brand_version',row.id,{reason:input.reason,version:row.version},c.get('requestId')),c.env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
  ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('BRAND_LOGO_UNAVAILABLE','Logo 素材状态已变化，请重新校验',409);throw error;}
 }else await c.env.DB.batch([c.env.DB.prepare("UPDATE platform_brand_versions SET state='disabled' WHERE id=?").bind(row.id),auditStatement(c.env.DB,user,'settings.brand.disable','brand_version',row.id,{reason:input.reason,fallsBackToDefault:row.state==='active'},c.get('requestId'))]);
 return ok(c,view((await c.env.DB.prepare('SELECT * FROM platform_brand_versions WHERE id=?').bind(row.id).first<Version>())!));
});
