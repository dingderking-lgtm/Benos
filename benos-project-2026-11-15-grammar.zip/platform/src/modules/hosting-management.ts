import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { AppError,assert } from '../lib/errors';
import { decryptSecret,id,randomToken,sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole,restricted } from './auth';
import { UNVERIFIED_CHANGE,claimDisplacement,customerErrorCode,hasHostingAccess,normalizeHostingDomain,reconcileHostingEntitlements,signedHostingFetch } from './hosting';
import { readHostingDnsTargets } from './hosting-dns-targets';

type Site={id:string;user_id:string;domain:string;name:string;state:string};
type Change={id:string;site_id:string;user_id:string;request_key:string;payload_hash:string;old_domain:string;new_domain:string;challenge:string;reason:string;state:string;provider_attempted:number;ssl_attempted:number;ownership_verified_at?:string|null;lease_token:string|null;lease_until:string|null;error_code:string|null;dns_json:string;created_at:string;updated_at:string};
type DnsRecord={type:'TXT'|'CNAME'|'A'|'AAAA';name:string;value:string;purpose:string};
const request=z.object({reason:z.string().trim().min(3).max(1000),requestKey:z.string().regex(/^[A-Za-z0-9_-]{8,128}$/)}).strict();
const now=()=>new Date().toISOString();
async function siteFor(env:Env,siteId:string,userId:string,role:string){const site=await env.DB.prepare('SELECT id,user_id,domain,name,state FROM sites WHERE id=?').bind(siteId).first<Site>();assert(site&&(site.user_id===userId||role==='owner'),'NOT_FOUND','网站不存在',404);return site;}
/** R-WL2: the stored code can be a provider code; only the neutral form is returned. */
function safeChange(row:Change|null){if(!row)return null;return {id:row.id,oldDomain:row.old_domain,newDomain:row.new_domain,state:row.state,errorCode:customerErrorCode(row.error_code),dnsRecords:JSON.parse(row.dns_json),createdAt:row.created_at,updatedAt:row.updated_at};}
const CUSTOMER_PAUSE_TEXT='网站已由平台暂停，请联系支持';
export async function hostingManagementDetail(env:Env,site:Site,role:string){
 const [connection,control,lease,change,job]=await Promise.all([
  env.DB.prepare('SELECT last_verified_at,origin FROM site_connections WHERE site_id=?').bind(site.id).first<{last_verified_at:string|null;origin:string}>(),
  env.DB.prepare('SELECT paused,reason,revision,updated_at FROM hosting_site_controls WHERE site_id=?').bind(site.id).first<{paused:number;reason:string;revision:number;updated_at:string}>(),
  env.DB.prepare('SELECT state,hosting_active,error_code,last_synced_at FROM hosting_lease_sync WHERE site_id=?').bind(site.id).first<{state:string;hosting_active:number;error_code:string|null;last_synced_at:string|null}>(),
  env.DB.prepare('SELECT * FROM hosting_domain_changes WHERE site_id=? ORDER BY created_at DESC,id DESC LIMIT 1').bind(site.id).first<Change>(),
  env.DB.prepare('SELECT required_dns_txt FROM hosting_provider_intents WHERE site_id=?').bind(site.id).first<{required_dns_txt:string|null}>()
 ]);
 const verified=!!connection?.last_verified_at&&connection.origin==='https://'+site.domain,staff=role==='owner'||role==='admin';
 const targets=await siteDnsTargets(env,site.id,site.domain);
 return {siteId:site.id,publicUrl:verified?'https://'+site.domain:null,adminUrl:verified?'https://'+site.domain+'/admin':null,canOperate:role==='owner',canChangeDomain:!!connection&&await hasHostingAccess(env,site.user_id,site.id)&&!await restricted(env.DB,site.user_id,'publish')&&!control?.paused,
  // S4: the operator's free-text pause note is staff-only; customers see a fixed neutral text.
  operation:{paused:!!control?.paused,reason:staff?control?.reason||null:control?.paused?CUSTOMER_PAUSE_TEXT:null,revision:control?.revision||0,syncState:lease?.state||'unavailable',effectivePaused:lease?.state==='synced'&&lease.hosting_active===0,errorCode:customerErrorCode(lease?.error_code||null),lastSyncedAt:lease?.last_synced_at||null},
  dnsRecords:[...(job?.required_dns_txt?[{type:'TXT',name:site.domain,value:job.required_dns_txt,purpose:'域名归属验证；按域名服务商的 TXT 提示填写'}]:[]),...targets],dnsTargetConfigured:targets.length>0,domainChange:safeChange(change)};
}
async function siteDnsTargets(env:Env,siteId:string,domain:string):Promise<DnsRecord[]>{const found=await readHostingDnsTargets(env,siteId);if(!found)return [];return found.records.map(record=>({...record,name:domain,purpose:found.source==='operator'?'平台管理员已核对的站点解析目标；保留现有邮件和验证记录':'系统已读取的站点解析记录；连接后仍会验证网站身份，请保留现有邮件和验证记录'}));}
async function connectionFor(env:Env,siteId:string){const connection=await env.DB.prepare('SELECT origin,key_id,secret_ciphertext FROM site_connections WHERE site_id=?').bind(siteId).first<{origin:string;key_id:string;secret_ciphertext:string}>();assert(connection,'CMS_NOT_CONNECTED','网站尚未完成连接',409);return {...connection,secret:await decryptSecret(connection.secret_ciphertext,env.ENCRYPTION_KEY,siteId)};}
async function dns(name:string,type:'TXT'|'A'|'AAAA'):Promise<string[]>{
 const url='https://cloudflare-dns.com/dns-query?name='+encodeURIComponent(name)+'&type='+type;
 const response=await fetchWithoutRedirect(url,{headers:{accept:'application/dns-json'},signal:AbortSignal.timeout(10000)});
 assert(response.ok,'DNS_UNAVAILABLE','域名解析暂未核对完成',502);const raw=await response.text();assert(raw.length<=65536,'DNS_UNAVAILABLE','域名解析响应无效',502);
 const result=JSON.parse(raw);assert(result.Status===0||result.Status===3,'DNS_UNAVAILABLE','域名解析暂未核对完成',502);
 return (Array.isArray(result.Answer)?result.Answer:[]).filter((v:any)=>v.type===({TXT:16,A:1,AAAA:28})[type]).map((v:any)=>String(v.data));
}
function publicIp(value:string):boolean {
 if(value.includes(':')){try{new URL('http://['+value+']');}catch{return false;}return /^[23][0-9a-f:]+$/i.test(value)&&!/^2001:(?:db8|0):/i.test(value);}
 const parts=value.split('.').map(Number);return parts.length===4&&parts.every(v=>Number.isInteger(v)&&v>=0&&v<=255)&&!([0,10,127].includes(parts[0])||parts[0]>=224||parts[0]===169&&parts[1]===254||parts[0]===172&&parts[1]>=16&&parts[1]<=31||parts[0]===192&&[0,168].includes(parts[1])||parts[0]===100&&parts[1]>=64&&parts[1]<=127||parts[0]===198&&[18,19].includes(parts[1]));
}
async function provider(token:string,method:'GET'|'POST',path:string,payload?:unknown){
 assert(token.length>=16,'DOMAIN_CONNECTION_UNAVAILABLE','域名连接服务尚未就绪',503);
 const response=await fetchWithoutRedirect('https://developers.hostinger.com'+path,{method,headers:{Authorization:'Bearer '+token,Accept:'application/json','Content-Type':'application/json'},body:method==='POST'?JSON.stringify(payload??{}):undefined,signal:AbortSignal.timeout(12000)});
 assert(response.ok,'DOMAIN_PROVIDER_UNCERTAIN','域名配置尚未确认，请稍后重新核对',502);const raw=await response.text();assert(raw.length<=2*1048576,'DOMAIN_PROVIDER_UNCERTAIN','域名服务响应无效',502);return raw?JSON.parse(raw):{};
}
async function aliasConfiguration(env:Env,siteId:string){
 const row=await env.DB.prepare('SELECT i.domain,i.account_username,i.hosting_order_id,c.id,c.public_config_json,c.secret_ciphertext FROM hosting_provider_intents i JOIN hosting_allocations a ON a.site_id=i.site_id JOIN hosting_pools p ON p.id=a.pool_id JOIN integration_configs c ON c.id=p.config_version_id WHERE i.site_id=?').bind(siteId).first<{domain:string;account_username:string;hosting_order_id:number;id:string;public_config_json:string;secret_ciphertext:string}>();
 assert(row,'DOMAIN_CONNECTION_UNAVAILABLE','域名连接服务尚未就绪',503);const cfg=JSON.parse(row.public_config_json),secret=JSON.parse(await decryptSecret(row.secret_ciphertext,env.ENCRYPTION_KEY,row.id));
 assert(cfg.adapter==='hostinger-hpanel'&&cfg.accountUsername===row.account_username&&cfg.hostingOrderId===row.hosting_order_id,'DOMAIN_CONNECTION_UNAVAILABLE','域名连接配置的账户范围不匹配',503);
 return {...row,token:String(secret.hostingerApiToken||'')};
}
/** Adds an alias on the same physical site; never creates or removes a website/database. */
export async function reconcileDomainChange(env:Env,changeId:string){
 let change=await env.DB.prepare('SELECT * FROM hosting_domain_changes WHERE id=?').bind(changeId).first<Change>();assert(change,'NOT_FOUND','域名变更不存在',404);if(change.state==='succeeded')return;
 const lease=randomToken(20),time=now();change=await env.DB.prepare('UPDATE hosting_domain_changes SET lease_token=?,lease_until=?,updated_at=? WHERE id=? AND state<>\'succeeded\' AND (lease_until IS NULL OR lease_until<?) RETURNING *').bind(lease,new Date(Date.now()+120000).toISOString(),time,change.id,time).first<Change>();if(!change)return;
 const set=async(state:string,error:string|null=null)=>env.DB.prepare('UPDATE hosting_domain_changes SET state=?,error_code=?,lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(state,error,now(),change!.id,lease).run();
 try{
  const site=await env.DB.prepare('SELECT id,user_id,domain,name,state FROM sites WHERE id=?').bind(change.site_id).first<Site>();assert(site,'NOT_FOUND','网站不存在',404);
  assert(await hasHostingAccess(env,site.user_id,site.id)&&!await restricted(env.DB,site.user_id,'publish')&&!await env.DB.prepare('SELECT 1 FROM hosting_site_controls WHERE site_id=? AND paused=1').bind(site.id).first(),'DOMAIN_CHANGE_RESTRICTED','当前网站无法变更域名',403);
  assert(site.domain===change.old_domain,'DOMAIN_CHANGE_CONFLICT','网站域名已发生其他变更',409);
  const ownership=await dns('_benos-verification.'+change.new_domain,'TXT');
  if(!ownership.some(v=>v.replace(/"\s*"/g,'').replace(/^"|"$/g,'')===change!.challenge)){await set('awaiting_ownership','DOMAIN_OWNERSHIP_REQUIRED');return;}
  // R4-m4: the new domain is proven; this change no longer counts as unverified.
  if(!change.ownership_verified_at)await env.DB.prepare('UPDATE hosting_domain_changes SET ownership_verified_at=COALESCE(ownership_verified_at,?) WHERE id=? AND lease_token=?').bind(now(),change.id,lease).run();
  const cfg=await aliasConfiguration(env,site.id),path='/api/hosting/v1/accounts/'+encodeURIComponent(cfg.account_username)+'/websites/'+encodeURIComponent(cfg.domain)+'/parked-domains';
  const listed=await provider(cfg.token,'GET',path),rows=Array.isArray(listed)?listed:listed.data;
  assert(Array.isArray(rows),'DOMAIN_PROVIDER_UNCERTAIN','域名绑定清单无效',502);
  const alias=rows.find((row:any)=>row.domain===change!.new_domain);
  if(!alias){
   if(change.provider_attempted){await set('awaiting_provider','DOMAIN_BINDING_UNCONFIRMED');return;}
   // Persist intent before mutation; a lost POST is reconciled by exact GET, never blindly repeated.
   await env.DB.prepare('UPDATE hosting_domain_changes SET provider_attempted=1 WHERE id=? AND lease_token=?').bind(change.id,lease).run();
   await provider(cfg.token,'POST',path,{parked_domain:change.new_domain});await set('awaiting_provider');return;
  }
  assert(alias.username===cfg.account_username&&(alias.parent_domain??alias.parentDomain)===cfg.domain,'DOMAIN_BINDING_CONFLICT','域名未绑定到原网站',409);
  const ips=[...await dns(change.new_domain,'A'),...await dns(change.new_domain,'AAAA')];if(!ips.length||!ips.every(publicIp)){await set('awaiting_dns','DOMAIN_PUBLIC_DNS_REQUIRED');return;}
  const connection=await connectionFor(env,site.id),origin='https://'+change.new_domain;
  let health;try{health=await signedHostingFetch(origin+'/benos-health.php','GET',null,connection.secret,connection.key_id,site.id,'','BENOS-CMS-V1');}catch{
   if(!change.ssl_attempted){await env.DB.prepare('UPDATE hosting_domain_changes SET ssl_attempted=1 WHERE id=? AND lease_token=?').bind(change.id,lease).run();try{await provider(cfg.token,'POST','/api/hosting/v1/accounts/'+encodeURIComponent(cfg.account_username)+'/websites/'+encodeURIComponent(change.new_domain)+'/ssl/setup');}catch{}}
   await set('awaiting_https','DOMAIN_HTTPS_REQUIRED');return;
  }
  assert(health.status===200&&(health.data as any).siteId===site.id&&(health.data as any).installed===true,'DOMAIN_SITE_IDENTITY_MISMATCH','新域名未连接至此网站',409);
  const result=await signedHostingFetch(origin+'/benos-connect.php','POST',{operation:'change-domain',changeId:change.id,expectedOrigin:'https://'+change.old_domain,origin},connection.secret,connection.key_id,site.id,change.id,'BENOS-CMS-V1');
  assert(result.status===200&&(result.data as any).siteId===site.id&&(result.data as any).origin===origin&&(result.data as any).changeId===change.id,'DOMAIN_SWITCH_UNCONFIRMED','CMS 地址变更尚未确认',502);
  await env.DB.batch([
   env.DB.prepare('UPDATE site_connections SET origin=?,last_verified_at=?,updated_at=? WHERE site_id=? AND origin=?').bind(origin,now(),now(),site.id,'https://'+change.old_domain),
   env.DB.prepare('UPDATE sites SET domain=?,updated_at=? WHERE id=? AND domain=?').bind(change.new_domain,now(),site.id,change.old_domain),
   env.DB.prepare("UPDATE hosting_domain_changes SET state='succeeded',error_code=NULL,lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?").bind(now(),change.id,lease),
   auditStatement(env.DB,change.user_id,'hosting.domain.changed','site',site.id,{changeId:change.id,oldDomain:change.old_domain,newDomain:change.new_domain})
  ]);
 }catch(error){await set('uncertain',error instanceof AppError?error.code:'DOMAIN_RESULT_UNCERTAIN');}
}
/** R3-S1b: a domain change whose new domain was never proven (still waiting for
 * its TXT record, or stopped before the check) holds that domain for at most this
 * long; then the change and its domain row are removed in one guarded, audited batch. */
const UNVERIFIED_CHANGE_TTL_MS=7*86400000;

/** Removes a change that never got past the ownership check (customer cancel, or
 * expiry), freeing its new domain. Never touches a change the provider was asked
 * to act on. Returns whether it was removed. */
async function dropUnverifiedChange(env:Env,change:Change,via:'cancelled'|'expired',actorId:string|null,requestId:string|null,cutoff?:string):Promise<boolean>{
 const at=now(),guard=`EXISTS(SELECT 1 FROM hosting_domain_changes WHERE id=? AND site_id=? AND new_domain=? AND ${UNVERIFIED_CHANGE} AND (lease_until IS NULL OR lease_until<?)${cutoff?' AND created_at<?':''})`;
 const binds=[change.id,change.site_id,change.new_domain,at,...(cutoff?[cutoff]:[])];
 const results=await env.DB.batch([
  env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?,?,?,'site',?,?,?,? WHERE ${guard}`).bind(id('audit'),actorId,'hosting.domain.change_'+via,change.site_id,JSON.stringify({changeId:change.id,oldDomain:change.old_domain,newDomain:change.new_domain,via,state:change.state,requestedAt:change.created_at}),requestId,at,...binds),
  env.DB.prepare(`DELETE FROM hosting_domains WHERE domain=? AND site_id=? AND NOT EXISTS(SELECT 1 FROM sites WHERE id=? AND domain=?) AND ${guard}`).bind(change.new_domain,change.site_id,change.site_id,change.new_domain,...binds),
  env.DB.prepare(`DELETE FROM hosting_domain_changes WHERE id=? AND ${guard}`).bind(change.id,...binds),
 ]);
 return Number(results[2]?.meta?.changes||0)>0;
}
export async function expireUnverifiedDomainChanges(env:Env,nowMs=Date.now()):Promise<{expired:number}>{
 const cutoff=new Date(nowMs-UNVERIFIED_CHANGE_TTL_MS).toISOString();
 const rows=(await env.DB.prepare(`SELECT * FROM hosting_domain_changes WHERE ${UNVERIFIED_CHANGE} AND created_at<? ORDER BY created_at LIMIT 10`).bind(cutoff).all<Change>()).results;
 let expired=0;for(const row of rows)try{if(await dropUnverifiedChange(env,row,'expired',null,null,cutoff))expired++;}catch{/* next pass */}
 return {expired};
}
export async function reconcilePendingDomainChanges(env:Env){await expireUnverifiedDomainChanges(env).catch(()=>undefined);const rows=(await env.DB.prepare("SELECT id FROM hosting_domain_changes WHERE state<>'succeeded' AND (lease_until IS NULL OR lease_until<?) ORDER BY updated_at,id LIMIT 5").bind(now()).all<{id:string}>()).results;for(const row of rows)await reconcileDomainChange(env,row.id);return {processed:rows.length};}
export const hostingManagementRoutes=new Hono<App>();hostingManagementRoutes.use('*',requireAuth);
// D20: the admin role may read the hosted-site list (read-only; pause/resume stay owner-only).
hostingManagementRoutes.get('/sites',requireRole('owner','admin'),async c=>{const userId=c.req.query('userId')||'',after=c.req.query('after')||'';const items=(await c.env.DB.prepare('SELECT s.id,s.name,s.domain,s.state,s.user_id,u.email,COALESCE(h.paused,0) AS manually_paused FROM sites s JOIN users u ON u.id=s.user_id LEFT JOIN hosting_site_controls h ON h.site_id=s.id WHERE (?=\'\' OR s.user_id=?) AND s.id>? ORDER BY s.id LIMIT 51').bind(userId,userId,after).all()).results;return ok(c,{items:items.slice(0,50),nextCursor:items.length>50?items[49].id:null,canOperate:c.get('auth').user.role==='owner'});});
/** Jobs that stopped for the platform team (operator review, failed, or a
 * provider-side setup failure). Owner and admin read; only the owner releases. */
const ATTENTION="(j.state='failed' OR (j.state='awaiting_input' AND j.step IN ('operator_action','review_website_setup')))";
hostingManagementRoutes.get('/jobs',requireRole('owner','admin'),async c=>{
 const rows=(await c.env.DB.prepare(`SELECT j.id,j.site_id,j.user_id,j.state,j.step,j.error_code,j.result_json,j.attempt_count,j.created_at,j.updated_at,s.name,s.domain,u.email FROM provisioning_jobs j JOIN sites s ON s.id=j.site_id JOIN users u ON u.id=j.user_id WHERE ${ATTENTION} ORDER BY j.updated_at,j.id LIMIT 100`).all<{id:string;site_id:string;user_id:string;state:string;step:string;error_code:string|null;result_json:string|null;attempt_count:number;created_at:string;updated_at:string;name:string;domain:string;email:string}>()).results;
 const internal=(raw:string|null)=>{try{const value=JSON.parse(raw||'{}').internalErrorCode;return typeof value==='string'?value:null;}catch{return null;}};
 return ok(c,{items:rows.map(row=>({id:row.id,siteId:row.site_id,userId:row.user_id,email:row.email,siteName:row.name,domain:row.domain,state:row.state,step:row.step,errorCode:row.error_code,internalErrorCode:internal(row.result_json),attemptCount:row.attempt_count,createdAt:row.created_at,updatedAt:row.updated_at})),canOperate:c.get('auth').user.role==='owner'});
});
/** Owner releases a stopped job back to the scheduler after fixing the cause.
 * Idempotent per request key (a replay changes nothing); audited in the same batch. */
hostingManagementRoutes.post('/jobs/:id/release',requireRole('owner'),async c=>{
 const user=c.get('auth').user,input=await body(c,request),jobId=c.req.param('id')!;
 const job=await c.env.DB.prepare('SELECT id,site_id,state,step,error_code FROM provisioning_jobs WHERE id=?').bind(jobId).first<{id:string;site_id:string;state:string;step:string;error_code:string|null}>();assert(job,'NOT_FOUND','连接任务不存在',404);
 // S3: a request key belongs to one payload (job and reason); reusing it for another is refused, never silently replayed.
 const prior=await c.env.DB.prepare("SELECT json_extract(details_json,'$.jobId') AS job_id,json_extract(details_json,'$.reason') AS reason FROM audit_logs WHERE action='hosting.job.released' AND actor_id=? AND json_extract(details_json,'$.requestKey')=? LIMIT 1").bind(user.id,input.requestKey).first<{job_id:string|null;reason:string|null}>();
 assert(!prior||prior.job_id===job.id&&prior.reason===input.reason,'IDEMPOTENCY_CONFLICT','相同请求标识不能用于不同的任务或原因',409);
 const replay=!!prior;
 if(!replay){
  const at=now(),results=await c.env.DB.batch([
   c.env.DB.prepare(`UPDATE provisioning_jobs SET state='pending',step='configure_hosting',error_code=NULL,lease_until=NULL,updated_at=? WHERE id=? AND (lease_until IS NULL OR lease_until<?) AND EXISTS(SELECT 1 FROM provisioning_jobs j WHERE j.id=provisioning_jobs.id AND ${ATTENTION})`).bind(at,job.id,at),
   c.env.DB.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?,?,'hosting.job.released','site',?,?,?,? WHERE EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND step='configure_hosting' AND updated_at=?)").bind(id('audit'),user.id,job.site_id,JSON.stringify({jobId:job.id,reason:input.reason,requestKey:input.requestKey,previousState:job.state,previousStep:job.step,previousErrorCode:job.error_code}),c.get('requestId'),at,job.id,at)
  ]);
  assert(Number(results[0]?.meta?.changes||0)>0,'HOSTING_JOB_NOT_RELEASABLE','该任务当前不需要平台处理，或正在执行',409);
 }
 const current=await c.env.DB.prepare('SELECT id,state,step,error_code,updated_at FROM provisioning_jobs WHERE id=?').bind(job.id).first<{id:string;state:string;step:string;error_code:string|null;updated_at:string}>();
 return ok(c,{job:{id:current!.id,state:current!.state,step:current!.step,errorCode:current!.error_code,updatedAt:current!.updated_at},replayed:replay},202);
});
hostingManagementRoutes.get('/dns-targets',requireRole('owner'),async c=>ok(c,{items:(await c.env.DB.prepare('SELECT p.id,p.name,d.records_json,d.reason,d.confirmed_at FROM hosting_pools p LEFT JOIN hosting_pool_dns_targets d ON d.pool_id=p.id WHERE p.archived_at IS NULL ORDER BY p.name LIMIT 200').all()).results.map(row=>({id:row.id,name:row.name,records:JSON.parse(String(row.records_json||'[]')),reason:row.reason,confirmedAt:row.confirmed_at}))}));
hostingManagementRoutes.put('/pools/:id/dns-targets',requireRole('owner'),async c=>{
 const input=await body(c,z.object({reason:z.string().trim().min(3).max(1000),records:z.array(z.object({type:z.enum(['A','AAAA']),value:z.string().trim().max(80)}).strict()).min(1).max(8)}).strict());
 assert(input.records.every(record=>publicIp(record.value)&&record.value.includes(':')===(record.type==='AAAA')),'DNS_TARGET_INVALID','解析目标必须是已核对的公网 IPv4 或 IPv6 地址');
 const poolId=c.req.param('id'),actor=c.get('auth').user.id,at=now();
 assert(await c.env.DB.prepare('SELECT id FROM hosting_pools WHERE id=? AND archived_at IS NULL').bind(poolId).first(),'HOSTING_POOL_UNAVAILABLE','托管连接不存在或已经移除，不能修改解析目标',409);
 const results=await c.env.DB.batch([
  c.env.DB.prepare(`INSERT INTO hosting_pool_dns_targets(pool_id,records_json,actor_id,reason,confirmed_at)
   SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM hosting_pools WHERE id=? AND archived_at IS NULL)
   ON CONFLICT(pool_id) DO UPDATE SET records_json=excluded.records_json,actor_id=excluded.actor_id,reason=excluded.reason,confirmed_at=excluded.confirmed_at
   WHERE EXISTS(SELECT 1 FROM hosting_pools WHERE id=excluded.pool_id AND archived_at IS NULL) RETURNING pool_id`).bind(poolId,JSON.stringify(input.records),actor,input.reason,at,poolId),
  c.env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at)
   SELECT ?,?,'hosting.dns_targets.confirmed','hosting_pool',?,?,?,?
   WHERE EXISTS(SELECT 1 FROM hosting_pool_dns_targets d JOIN hosting_pools p ON p.id=d.pool_id WHERE d.pool_id=? AND d.confirmed_at=? AND p.archived_at IS NULL)`)
   .bind(id('audit'),actor,poolId,JSON.stringify(input),c.get('requestId')||null,at,poolId,at)
 ]);
 assert(results[0].results.length,'HOSTING_POOL_UNAVAILABLE','托管连接已移除，请刷新后重试',409);return ok(c,{saved:true});
});
// Read-only detail: platform admins may view any site (canOperate stays owner-only).
hostingManagementRoutes.get('/sites/:id',async c=>{const user=c.get('auth').user,site=await siteFor(c.env,c.req.param('id'),user.id,user.role==='admin'?'owner':user.role);return ok(c,await hostingManagementDetail(c.env,site,user.role));});
for(const operation of ['pause','resume'] as const)hostingManagementRoutes.post('/sites/:id/'+operation,requireRole('owner'),async c=>{
 const user=c.get('auth').user,site=await siteFor(c.env,c.req.param('id')!,user.id,user.role),input=await body(c,request),paused=operation==='pause',hash=await sha256(JSON.stringify([site.id,paused,input.reason]));await connectionFor(c.env,site.id);
 const existing=await c.env.DB.prepare('SELECT payload_hash FROM hosting_control_requests WHERE actor_id=? AND request_key=?').bind(user.id,input.requestKey).first<{payload_hash:string}>();
 if(existing)assert(existing.payload_hash===hash,'IDEMPOTENCY_CONFLICT','同一请求标识不可用于不同操作',409);
 else try{await c.env.DB.batch([
  c.env.DB.prepare('INSERT INTO hosting_control_requests(id,site_id,actor_id,request_key,payload_hash,paused,reason,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(id('ctl'),site.id,user.id,input.requestKey,hash,paused?1:0,input.reason,now()),
  c.env.DB.prepare('INSERT INTO hosting_site_controls(site_id,paused,reason,actor_id,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(site_id) DO UPDATE SET paused=excluded.paused,reason=excluded.reason,actor_id=excluded.actor_id,revision=hosting_site_controls.revision+1,updated_at=excluded.updated_at').bind(site.id,paused?1:0,input.reason,user.id,now()),
  auditStatement(c.env.DB,user.id,'hosting.'+operation+'.requested','site',site.id,{reason:input.reason,explicitSiteOnly:true,requestKey:input.requestKey},c.get('requestId'))
 ]);}catch(error){const raced=await c.env.DB.prepare('SELECT payload_hash FROM hosting_control_requests WHERE actor_id=? AND request_key=?').bind(user.id,input.requestKey).first<{payload_hash:string}>();if(!raced)throw error;assert(raced.payload_hash===hash,'IDEMPOTENCY_CONFLICT','同一请求标识不可用于不同操作',409);}
 await reconcileHostingEntitlements(c.env,site.id);return ok(c,await hostingManagementDetail(c.env,site,user.role),202);
});
hostingManagementRoutes.post('/sites/:id/domain-changes',async c=>{
 const user=c.get('auth').user,site=await siteFor(c.env,c.req.param('id'),user.id,user.role),input=await body(c,request.extend({domain:z.string().max(253)})),domain=normalizeHostingDomain(input.domain),hash=await sha256(JSON.stringify([site.id,domain,input.reason]));
 assert(await hasHostingAccess(c.env,site.user_id,site.id)&&!await restricted(c.env.DB,site.user_id,'publish')&&!await c.env.DB.prepare('SELECT 1 FROM hosting_site_controls WHERE site_id=? AND paused=1').bind(site.id).first(),'DOMAIN_CHANGE_RESTRICTED','当前网站无法变更域名',403);await connectionFor(c.env,site.id);
 let change=await c.env.DB.prepare('SELECT * FROM hosting_domain_changes WHERE user_id=? AND request_key=?').bind(user.id,input.requestKey).first<Change>();
 if(change)assert(change.payload_hash===hash,'IDEMPOTENCY_CONFLICT','同一请求标识不可用于不同域名',409);
 else{assert(domain!==site.domain,'DOMAIN_UNCHANGED','请填写新的域名',409);const changeId=id('dom'),challenge='benos-domain-'+randomToken(32),dnsRecords:DnsRecord[]=[{type:'TXT',name:'_benos-verification.'+domain,value:challenge,purpose:'验证新域名属于你'},{type:'CNAME',name:domain,value:site.domain,purpose:'将新域名指向原网站；根域名需解析商支持 CNAME 扁平化，或由平台支持核对 A 记录'}];
  const targets=await siteDnsTargets(c.env,site.id,domain);if(targets.length)dnsRecords.splice(1,1,...targets);
  // R2-S4 / R3-S1b: another account's unpaid claim gives way in this batch, and
  // only when this account proves the domain by TXT (claimDisplacement).
  const displace=await claimDisplacement(c.env,site.user_id,domain,'domain_change',{ready:async()=>!await c.env.DB.prepare("SELECT 1 FROM hosting_domain_changes WHERE site_id=? AND state<>'succeeded'").bind(site.id).first(),requestId:c.get('requestId'),runtime:(await import('./payments')).backgroundRuntime(c),actorId:user.id});
  try{await c.env.DB.batch([
   ...(displace?displace('1',[]):[]),
   c.env.DB.prepare('INSERT INTO hosting_domains(domain,site_id,created_at) VALUES(?,?,?)').bind(domain,site.id,now()),
   c.env.DB.prepare('INSERT INTO hosting_domain_changes(id,site_id,user_id,request_key,payload_hash,old_domain,new_domain,challenge,reason,dns_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').bind(changeId,site.id,user.id,input.requestKey,hash,site.domain,domain,challenge,input.reason,JSON.stringify(dnsRecords),now(),now()),
   auditStatement(c.env.DB,user.id,'hosting.domain.requested','site',site.id,{oldDomain:site.domain,newDomain:domain,reason:input.reason},c.get('requestId'))
  ]);}catch{throw new AppError('DOMAIN_CHANGE_CONFLICT','域名已被占用，或此站已有等待核验的域名变更',409);}
  change=await c.env.DB.prepare('SELECT * FROM hosting_domain_changes WHERE id=?').bind(changeId).first<Change>();
 }
 return ok(c,{domainChange:safeChange(change)},202);
});
/** R3-S1b: the customer (or the owner) withdraws a domain change that has not
 * passed the ownership check yet; the new domain is freed at once. */
hostingManagementRoutes.post('/sites/:id/domain-changes/:changeId/cancel',async c=>{
 const user=c.get('auth').user,site=await siteFor(c.env,c.req.param('id'),user.id,user.role);await body(c,z.object({}).strict());
 const change=await c.env.DB.prepare("SELECT * FROM hosting_domain_changes WHERE id=? AND site_id=? AND state<>'succeeded'").bind(c.req.param('changeId'),site.id).first<Change>();assert(change,'NOT_FOUND','域名变更不存在',404);
 assert(await dropUnverifiedChange(c.env,change,'cancelled',user.id,c.get('requestId')),'DOMAIN_CHANGE_NOT_CANCELLABLE','该域名变更已开始配置或正在核对，暂不能取消，请稍后刷新或联系支持',409);
 return ok(c,await hostingManagementDetail(c.env,site,user.role));
});
hostingManagementRoutes.post('/sites/:id/domain-changes/:changeId/reconcile',async c=>{const user=c.get('auth').user,site=await siteFor(c.env,c.req.param('id'),user.id,user.role);const row=await c.env.DB.prepare('SELECT id FROM hosting_domain_changes WHERE id=? AND site_id=?').bind(c.req.param('changeId'),site.id).first();assert(row,'NOT_FOUND','域名变更不存在',404);await reconcileDomainChange(c.env,c.req.param('changeId'));return ok(c,await hostingManagementDetail(c.env,site,user.role),202);});
