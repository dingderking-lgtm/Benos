import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { assert } from '../lib/errors';
import { id } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole } from './auth';

export const RETENTION_DAYS=30;
/** Retention starts when suspension is recorded, never from an old billing
 * deadline. A delayed observation therefore preserves more than 30 days. */
export async function recordHostingRetention(env:Env,siteId?:string,nowMs=Date.now()){
 const now=new Date(nowMs).toISOString(),until=new Date(nowMs+RETENTION_DAYS*86400000).toISOString();
 const sites=(await env.DB.prepare(`SELECT id,state FROM sites ${siteId?'WHERE id=?':"WHERE (state='suspended' AND NOT EXISTS(SELECT 1 FROM site_retention_periods r WHERE r.site_id=sites.id AND r.restored_at IS NULL)) OR (state IN ('connected','active','publishing') AND EXISTS(SELECT 1 FROM site_retention_periods r WHERE r.site_id=sites.id AND r.restored_at IS NULL))"} ORDER BY updated_at,id LIMIT 100`).bind(...(siteId?[siteId]:[])).all<{id:string;state:string}>()).results;
 let created=0,restored=0;
 for(const site of sites){
  if(site.state==='suspended'){
   const result=await env.DB.prepare(`INSERT INTO site_retention_periods(id,site_id,suspended_at,review_after,created_at)
    SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM sites WHERE id=? AND state='suspended')
    AND NOT EXISTS(SELECT 1 FROM site_retention_periods WHERE site_id=? AND restored_at IS NULL) RETURNING id`).bind(id('retain'),site.id,now,until,now,site.id,site.id).first();if(result)created++;
  }else{
   const rows=await env.DB.prepare(`UPDATE site_retention_periods SET restored_at=? WHERE site_id=? AND restored_at IS NULL
    AND EXISTS(SELECT 1 FROM sites WHERE id=? AND state IN ('connected','active','publishing')) RETURNING id`).bind(now,site.id,site.id).all();restored+=rows.results.length;
  }
 }
 return {created,restored};
}
export async function siteRetention(env:Env,siteId:string){
 const row=await env.DB.prepare('SELECT suspended_at,review_after,reviewed_at FROM site_retention_periods WHERE site_id=? AND restored_at IS NULL').bind(siteId).first<{suspended_at:string;review_after:string;reviewed_at:string|null}>();
 return row?{minimumDays:RETENTION_DAYS,suspendedAt:row.suspended_at,retainAtLeastUntil:row.review_after,reviewDue:Date.parse(row.review_after)<=Date.now(),automaticDeletion:false}:null;
}
export const retentionRoutes=new Hono<App>();
retentionRoutes.use('*',requireAuth,requireRole('owner','admin'));
retentionRoutes.get('/',async c=>{
 const rows=await c.env.DB.prepare(`SELECT r.*,s.name,s.domain,s.user_id,u.email FROM site_retention_periods r
  JOIN sites s ON s.id=r.site_id JOIN users u ON u.id=s.user_id WHERE r.restored_at IS NULL
  ORDER BY (r.reviewed_at IS NOT NULL),r.review_after,r.id LIMIT 500`).all();return ok(c,{minimumDays:RETENTION_DAYS,automaticDeletion:false,items:rows.results});
});
retentionRoutes.post('/:id/review',requireRole('owner'),async c=>{
 const input=await body(c,z.object({decision:z.literal('retain'),reason:z.string().trim().min(3).max(1000)}).strict()),now=new Date().toISOString();
 const result=await c.env.DB.batch([
  c.env.DB.prepare(`UPDATE site_retention_periods SET reviewed_at=?,reviewed_by=?,review_reason=?
   WHERE id=? AND restored_at IS NULL AND review_after<=?
   AND EXISTS(SELECT 1 FROM sites WHERE sites.id=site_retention_periods.site_id AND sites.state='suspended') RETURNING id`).bind(now,c.get('auth').user.id,input.reason,c.req.param('id'),now),
  auditStatement(c.env.DB,c.get('auth').user.id,'hosting.retention.review_requested','retention',c.req.param('id'),input,c.get('requestId'))
 ]);assert(result[0].results.length,'RETENTION_REVIEW_NOT_DUE','网站已恢复、记录不存在或尚未达到保留期限',409);
 return ok(c,{reviewed:true,decision:'retain',deleted:false});
});
