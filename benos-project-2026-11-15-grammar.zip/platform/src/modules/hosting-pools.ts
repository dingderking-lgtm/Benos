import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id,decryptSecret } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole,rateLimit } from './auth';
import { hpanelConfiguration,inspectHpanelInventory } from './hosting-hostinger';

const FRESH_MS=15*60_000;
type Pool={id:string;name:string;account_username:string;hosting_order_id:number;config_version_id:string;state:string;priority:number;max_sites:number;max_databases:number;external_sites:number;external_databases:number;observed_at:string|null;sync_error:string|null;revision:number;archived_at:string|null};
type Config={id:string;public_config_json:string;secret_ciphertext:string|null;status:string;test_status:string};
type Inventory={domains:string[];databases:string[]};
type Runtime={nowMs?:number;inspect?:(config:z.infer<typeof hpanelConfiguration>,token:string)=>Promise<Inventory>};
// Pre-pool jobs already own their original account's capacity. Include them in
// every count before they are lazily adopted, including unknown/finished jobs.
// A credential rotation must never move a previous assignment to another pool.
const assignments=`SELECT a.job_id,a.site_id,a.pool_id,a.config_version_id,a.created_at FROM hosting_allocations a
 UNION ALL SELECT j.id,j.site_id,p.id,j.config_version_id,j.created_at FROM provisioning_jobs j
 JOIN integration_configs c ON c.id=j.config_version_id AND c.kind='hosting' AND c.provider='benos-bridge'
 JOIN hosting_pools p ON (p.config_version_id=c.id OR
  (json_extract(c.public_config_json,'$.accountUsername')=p.account_username
   AND json_extract(c.public_config_json,'$.hostingOrderId')=p.hosting_order_id))
 WHERE j.kind='create' AND NOT EXISTS(SELECT 1 FROM hosting_allocations a WHERE a.job_id=j.id)`;
const occupied=(pool:string)=>`(SELECT COUNT(*) FROM (${assignments}) a WHERE a.pool_id=${pool})`;
async function configFor(env:Env,configId:string){
 const row=await env.DB.prepare("SELECT * FROM integration_configs WHERE id=? AND kind='hosting' AND provider='benos-bridge'").bind(configId).first<Config>();
 assert(row&&row.test_status==='passed'&&row.status==='active','HOSTING_CONFIG_REQUIRED','请选择已经验证并启用的 Hostinger 配置版本',409);
 const config=hpanelConfiguration.parse(JSON.parse(row.public_config_json));return {row,config};
}
export async function syncHostingPool(env:Env,poolId:string,runtime:Runtime={}){
 const pool=await env.DB.prepare('SELECT * FROM hosting_pools WHERE id=?').bind(poolId).first<Pool>();assert(pool,'NOT_FOUND','托管连接不存在',404);
 assert(!pool.archived_at,'HOSTING_POOL_ARCHIVED','连接已归档，请先恢复连接再核对资源',409);
 const token=id('inventory'),started=runtime.nowMs??Date.now();
 const claim=await env.DB.prepare('UPDATE hosting_pools SET inventory_lease_token=?,inventory_lease_until_ms=?,updated_at=? WHERE id=? AND archived_at IS NULL AND (inventory_lease_until_ms IS NULL OR inventory_lease_until_ms<=?) RETURNING id').bind(token,started+180000,new Date(started).toISOString(),poolId,started).first();
 assert(claim,'HOSTING_INVENTORY_RUNNING','资源清单正在核对，请稍后刷新',409);
 try{
  const {row,config}=await configFor(env,pool.config_version_id);
  assert(config.accountUsername===pool.account_username&&config.hostingOrderId===pool.hosting_order_id,'HOSTING_SCOPE_CHANGED','配置版本不能改变此连接的账号与订单',409);
  assert(row.secret_ciphertext,'HOSTING_CONFIG_REQUIRED','托管凭据尚未配置',409);
  const secret=JSON.parse(await decryptSecret(row.secret_ciphertext,env.ENCRYPTION_KEY,row.id));
  const inventory=await (runtime.inspect??inspectHpanelInventory)(config,secret.hostingerApiToken||'');
  assert(inventory.domains.length<=100000&&inventory.databases.length<=100000,'HOSTING_INVENTORY_TOO_LARGE','资源清单超过可核对范围',409);
  // Count external resources at commit time. Every local allocation consumes a
  // slot even when its external operation timed out or its website is suspended.
  const result=await env.DB.prepare(`UPDATE hosting_pools SET external_sites=(SELECT COUNT(*) FROM json_each(?1) remote
   WHERE NOT EXISTS(SELECT 1 FROM (${assignments}) a JOIN sites s ON s.id=a.site_id WHERE a.pool_id=?3 AND s.domain=remote.value)),
   external_databases=(SELECT COUNT(*) FROM json_each(?2) remote WHERE NOT EXISTS(SELECT 1 FROM (${assignments}) a
    JOIN hosting_provider_intents i ON i.job_id=a.job_id WHERE a.pool_id=?3 AND i.database_name=remote.value)),
   observed_at=?4,sync_error=NULL,inventory_lease_token=NULL,inventory_lease_until_ms=NULL,updated_at=?4
   WHERE id=?3 AND config_version_id=?5 AND inventory_lease_token=?6 AND inventory_lease_until_ms>?7 AND revision=?8 RETURNING id`)
   .bind(JSON.stringify(inventory.domains),JSON.stringify(inventory.databases),poolId,new Date(started).toISOString(),row.id,token,runtime.nowMs??Date.now(),pool.revision).first();
  assert(result,'HOSTING_INVENTORY_CHANGED','核对期间连接发生变化，请重新核对',409);
  return {synced:true};
 }catch(error){await env.DB.prepare('UPDATE hosting_pools SET sync_error=?,inventory_lease_token=NULL,inventory_lease_until_ms=NULL WHERE id=? AND inventory_lease_token=?').bind(error instanceof AppError?error.code:'HOSTING_INVENTORY_UNCONFIRMED',poolId,token).run();throw error;}
}
/** One SQL INSERT chooses and reserves capacity. Subsequent credential changes
 * affect only new allocations. Lost acknowledgement retries return the same row. */
export async function allocateHostingJob(env:Env,jobId:string,leaseToken:string,nowMs=Date.now()):Promise<string|null>{
 const stamp=new Date(nowMs).toISOString(),fresh=new Date(nowMs-FRESH_MS).toISOString();
 await env.DB.batch([
  env.DB.prepare(`INSERT INTO hosting_allocations(job_id,site_id,pool_id,config_version_id,created_at)
   SELECT j.id,j.site_id,a.pool_id,j.config_version_id,?3 FROM provisioning_jobs j
   JOIN (${assignments}) a ON a.job_id=j.id JOIN hosting_pools p ON p.id=a.pool_id
   WHERE j.id=?1 AND j.lease_token=?2 AND j.config_version_id IS NOT NULL
   AND NOT EXISTS(SELECT 1 FROM hosting_allocations WHERE job_id=j.id)
   -- This adopts an existing assignment, including after a connection restore.
   -- Fresh inventory is required only for new assignments below.
   AND p.external_sites+(SELECT COUNT(*) FROM hosting_allocations WHERE pool_id=p.id)<p.max_sites
   AND p.external_databases+(SELECT COUNT(*) FROM hosting_allocations WHERE pool_id=p.id)<p.max_databases
   ON CONFLICT(job_id) DO NOTHING`).bind(jobId,leaseToken,stamp),
  env.DB.prepare(`INSERT INTO hosting_allocations(job_id,site_id,pool_id,config_version_id,created_at)
   SELECT j.id,j.site_id,p.id,p.config_version_id,?3 FROM provisioning_jobs j CROSS JOIN hosting_pools p
   JOIN integration_configs c ON c.id=p.config_version_id WHERE j.id=?1 AND j.lease_token=?2 AND j.kind='create'
   AND j.config_version_id IS NULL AND NOT EXISTS(SELECT 1 FROM hosting_allocations WHERE job_id=j.id)
   AND p.state='accepting' AND p.archived_at IS NULL AND p.observed_at>=?4 AND p.sync_error IS NULL AND c.status='active' AND c.test_status='passed'
   AND p.external_sites+${occupied('p.id')}<p.max_sites
   AND p.external_databases+${occupied('p.id')}<p.max_databases
   ORDER BY p.priority,p.created_at,p.id LIMIT 1 ON CONFLICT(job_id) DO NOTHING`).bind(jobId,leaseToken,stamp,fresh),
  env.DB.prepare(`UPDATE provisioning_jobs SET config_version_id=(SELECT config_version_id FROM hosting_allocations WHERE job_id=?1)
   WHERE id=?1 AND lease_token=?2 AND config_version_id IS NULL AND EXISTS(SELECT 1 FROM hosting_allocations WHERE job_id=?1)`).bind(jobId,leaseToken)
 ]);
 return (await env.DB.prepare(`SELECT a.config_version_id FROM provisioning_jobs j JOIN hosting_allocations a ON a.job_id=j.id
  AND a.config_version_id=j.config_version_id WHERE j.id=? AND j.lease_token=?`).bind(jobId,leaseToken).first<{config_version_id:string}>())?.config_version_id??null;
}
export async function availableHostingPool(env:Env,nowMs=Date.now()){
 return env.DB.prepare(`SELECT p.id FROM hosting_pools p JOIN integration_configs c ON c.id=p.config_version_id
  WHERE p.state='accepting' AND p.archived_at IS NULL AND p.observed_at>=? AND p.sync_error IS NULL AND c.status='active' AND c.test_status='passed'
  AND p.external_sites+${occupied('p.id')}<p.max_sites
  AND p.external_databases+${occupied('p.id')}<p.max_databases
  ORDER BY p.priority,p.created_at,p.id LIMIT 1`).bind(new Date(nowMs-FRESH_MS).toISOString()).first();
}
export async function refreshHostingPools(env:Env,runtime:Runtime={}){
 const now=runtime.nowMs??Date.now();
 // A failed observation must still yield its next batch slot to connections
 // attempted less recently. Active inventory leases never consume the batch.
 const rows=(await env.DB.prepare("SELECT id FROM hosting_pools WHERE state='accepting' AND archived_at IS NULL AND (observed_at IS NULL OR observed_at<? OR sync_error IS NOT NULL) AND (inventory_lease_until_ms IS NULL OR inventory_lease_until_ms<=?) ORDER BY updated_at,id LIMIT 3").bind(new Date(now-8*60_000).toISOString(),now).all<{id:string}>()).results;
 let synced=0,failed=0;for(const row of rows){try{await syncHostingPool(env,row.id,runtime);synced++;}catch{failed++;}}return {synced,failed};
}
export async function listHostingPools(env:Env){
 const rows=(await env.DB.prepare(`SELECT p.*,c.name AS config_name,c.version AS config_version,c.status AS config_status,
  ${occupied('p.id')} AS allocated,
  (SELECT COUNT(*) FROM (${assignments}) a JOIN provisioning_jobs j ON j.id=a.job_id WHERE a.pool_id=p.id AND j.state<>'succeeded') AS pending
  FROM hosting_pools p JOIN integration_configs c ON c.id=p.config_version_id ORDER BY (p.archived_at IS NOT NULL),p.priority,p.created_at,p.id LIMIT 500`).all<Pool&{config_name:string;config_version:number;config_status:string;allocated:number;pending:number}>()).results;
 return {items:rows.map(p=>({...p,available:p.archived_at?0:Math.max(0,Math.min(p.max_sites-p.external_sites-p.allocated,p.max_databases-p.external_databases-p.allocated)),inventoryFresh:!p.archived_at&&!!p.observed_at&&Date.parse(p.observed_at)>=Date.now()-FRESH_MS&&!p.sync_error})),inventoryMaxAgeSeconds:FRESH_MS/1000};
}
const editSchema=z.object({name:z.string().trim().min(1).max(80),configId:z.string().min(1).max(100),maxSites:z.number().int().min(1).max(100000),maxDatabases:z.number().int().min(1).max(100000),priority:z.number().int().min(0).max(10000),state:z.enum(['accepting','draining']),reason:z.string().trim().min(3).max(500),revision:z.number().int().positive().optional()}).strict();
export const hostingPoolRoutes=new Hono<App>();
hostingPoolRoutes.use('*',requireAuth,requireRole('owner','admin'));
hostingPoolRoutes.get('/',async c=>ok(c,await listHostingPools(c.env)));
hostingPoolRoutes.post('/',requireRole('owner'),async c=>{
 const input=await body(c,editSchema);assert(input.state==='draining','VERIFY_INVENTORY_FIRST','新连接先保存为停止新分配，核对资源清单后再开启',409);
 const {config}=await configFor(c.env,input.configId),poolId=id('hpool'),now=new Date().toISOString();
 try{await c.env.DB.batch([
  c.env.DB.prepare('INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,priority,max_sites,max_databases,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(poolId,input.name,config.accountUsername,config.hostingOrderId,input.configId,input.priority,input.maxSites,input.maxDatabases,now,now),
  auditStatement(c.env.DB,c.get('auth').user.id,'hosting.pool.create','hosting_pool',poolId,{name:input.name,maxSites:input.maxSites,maxDatabases:input.maxDatabases,reason:input.reason},c.get('requestId'))
 ]);}catch(error){if(String(error).includes('UNIQUE'))throw new AppError('HOSTING_POOL_EXISTS','此账号与托管订单已经登记，请更新原连接以免重复计算容量',409);throw error;}
 return ok(c,{id:poolId},201);
});
hostingPoolRoutes.patch('/:id',requireRole('owner'),async c=>{
 const input=await body(c,editSchema);assert(input.revision,'REVISION_REQUIRED','请刷新连接后重试',409);
 const pool=await c.env.DB.prepare('SELECT * FROM hosting_pools WHERE id=?').bind(c.req.param('id')).first<Pool>();assert(pool,'NOT_FOUND','托管连接不存在',404);
 assert(!pool.archived_at,'HOSTING_POOL_ARCHIVED','连接已归档，请先恢复连接再编辑',409);
 const {config}=await configFor(c.env,input.configId);
 assert(config.accountUsername===pool.account_username&&config.hostingOrderId===pool.hosting_order_id,'HOSTING_SCOPE_CHANGED','切换到 B 账号请添加独立连接；原 A 账号保留已有网站',409);
 const now=new Date().toISOString(),changing=input.configId!==pool.config_version_id;
 assert(!changing||input.state==='draining','VERIFY_INVENTORY_FIRST','更换密钥版本后，请核对资源清单再开启新分配',409);
 const result=await c.env.DB.batch([
  c.env.DB.prepare(`UPDATE hosting_pools SET name=?,config_version_id=?,max_sites=?,max_databases=?,priority=?,state=?,revision=revision+1,
   observed_at=CASE WHEN ? THEN NULL ELSE observed_at END,sync_error=CASE WHEN ? THEN NULL ELSE sync_error END,
   inventory_lease_token=CASE WHEN ? THEN NULL ELSE inventory_lease_token END,
   inventory_lease_until_ms=CASE WHEN ? THEN NULL ELSE inventory_lease_until_ms END,updated_at=?
   WHERE id=? AND revision=? AND archived_at IS NULL AND external_sites+${occupied('hosting_pools.id')}<=?
   AND external_databases+${occupied('hosting_pools.id')}<=?
   AND (?='draining' OR (observed_at>=? AND sync_error IS NULL)) RETURNING id`)
   .bind(input.name,input.configId,input.maxSites,input.maxDatabases,input.priority,input.state,changing?1:0,changing?1:0,changing?1:0,changing?1:0,now,pool.id,input.revision,input.maxSites,input.maxDatabases,input.state,new Date(Date.now()-FRESH_MS).toISOString()),
  auditStatement(c.env.DB,c.get('auth').user.id,'hosting.pool.update_requested','hosting_pool',pool.id,{...input,previousConfigId:pool.config_version_id},c.get('requestId'))
 ]);assert(result[0].results.length,'HOSTING_POOL_CHANGED','连接已变化、容量低于占用量或清单已过期，请刷新后核对',409);return ok(c,{updated:true});
});
hostingPoolRoutes.post('/:id/sync',requireRole('owner'),async c=>{
 await body(c,z.object({}).strict());await rateLimit(c,'hosting-inventory',20,3600,c.get('auth').user.id);
 const result=await syncHostingPool(c.env,c.req.param('id'));
 await auditStatement(c.env.DB,c.get('auth').user.id,'hosting.pool.sync','hosting_pool',c.req.param('id'),result,c.get('requestId')).run();return ok(c,result);
});
const archiveInput=z.object({revision:z.number().int().positive(),reason:z.string().trim().min(3).max(500)}).strict();
for(const operation of ['archive','restore'] as const)hostingPoolRoutes.post('/:id/'+operation,requireRole('owner'),async c=>{
 const input=await body(c,archiveInput),poolId=c.req.param('id')!,actor=c.get('auth').user.id;
 const pool=await c.env.DB.prepare('SELECT * FROM hosting_pools WHERE id=?').bind(poolId).first<Pool>();assert(pool,'NOT_FOUND','托管连接不存在',404);
 const archiving=operation==='archive';
 if(archiving&&pool.archived_at)return ok(c,{archived:true});
 if(!archiving&&!pool.archived_at)return ok(c,{restored:true});
 const stamp=new Date().toISOString(),guard=id('pool_guard');
 try{await c.env.DB.batch([
  c.env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM hosting_pools WHERE id=? AND revision=? AND (archived_at IS NOT NULL)=?) THEN 1 ELSE 0 END`).bind(guard,poolId,input.revision,archiving?0:1),
  c.env.DB.prepare(`UPDATE hosting_pools SET state='draining',archived_at=?,archived_by=?,archive_reason=?,revision=revision+1,
   observed_at=CASE WHEN ? THEN observed_at ELSE NULL END,sync_error=NULL,inventory_lease_token=NULL,inventory_lease_until_ms=NULL,updated_at=? WHERE id=?`).bind(archiving?stamp:null,archiving?actor:null,archiving?input.reason:null,archiving?1:0,stamp,poolId),
  auditStatement(c.env.DB,actor,'hosting.pool.'+operation,'hosting_pool',poolId,{reason:input.reason,preservesWebsites:true},c.get('requestId')),
  c.env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
 ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('HOSTING_POOL_CHANGED','连接已变化，请刷新后再操作',409);throw error;}
 return ok(c,archiving?{archived:true}:{restored:true});
});
hostingPoolRoutes.get('/:id/sites',async c=>{
 const items=await c.env.DB.prepare(`SELECT s.id,s.name,s.domain,s.state,s.user_id,u.email,j.id AS job_id,j.state AS job_state,
  a.config_version_id,a.created_at FROM (${assignments}) a JOIN sites s ON s.id=a.site_id JOIN users u ON u.id=s.user_id
  JOIN provisioning_jobs j ON j.id=a.job_id WHERE a.pool_id=? ORDER BY a.created_at DESC LIMIT 500`).bind(c.req.param('id')).all();return ok(c,{items:items.results});
});
