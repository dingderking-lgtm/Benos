import { parseFragment,type DefaultTreeAdapterMap } from 'parse5';

type Node=DefaultTreeAdapterMap['node'];
type Element=DefaultTreeAdapterMap['element'];
type Page={key:string;slug:string;template_id:number};
type Template={id:number;document:{html:string;[key:string]:unknown};[key:string]:unknown};
type Manifest={site:{home:string;pages:Page[];header_template_id?:number;footer_template_id?:number;[key:string]:unknown};templates:Template[];[key:string]:unknown};
export type SharedFragmentLinkRepair={templateId:number;from:string;to:string;targetPage:string;reason:'unique_cross_page_fragment'};
const HTML='http://www.w3.org/1999/xhtml';
const attr=(node:Element,name:string)=>node.attrs.find(value=>value.name===name&&!value.namespace)?.value;
const dynamic=(value:string)=>/\{\{|\}\}|\{%|%\}/.test(value);
const escape=(value:string)=>value.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

/** A shared fragment is only rewritten when its destination is unambiguous on
 * the complete rendered site. This does not invent targets or touch page bodies.
 * Source-span edits preserve all author markup except the affected href itself.
 * Callers must restrict this to new whole-site generation, never existing edits. */
export function normalizeSharedFragmentLinks<T>(input:T):{manifest:T;repairs:SharedFragmentLinkRepair[]}{
 const unchanged=()=>({manifest:input,repairs:[] as SharedFragmentLinkRepair[]});
 try{
  const manifest=input as Manifest,site=manifest?.site,pages=site?.pages,templates=manifest?.templates;
  if(!Array.isArray(pages)||pages.length<2||pages.length>100||!Array.isArray(templates)||templates.length>200)return unchanged();
  if(pages.some(page=>!page||typeof page.key!=='string'||typeof page.slug!=='string'||!Number.isSafeInteger(page.template_id)))return unchanged();
  if(new Set(pages.map(page=>page.key)).size!==pages.length||new Set(pages.map(page=>page.slug)).size!==pages.length||!pages.some(page=>page.key===site.home))return unchanged();
  const byId=new Map(templates.map(template=>[template?.id,template]));
  if(byId.size!==templates.length)return unchanged();
  const chrome=[site.header_template_id,site.footer_template_id].filter((id):id is number=>id!==undefined);
  const required=new Set([...chrome,...pages.map(page=>page.template_id)]);
  const indexed=new Map<number,{ids:Map<string,number>;uncertainIds:Set<string>;links:Array<{node:Element;href:string}>}>();
  let characters=0,visited=0;
  for(const id of required){
   const template=byId.get(id),html=template?.document?.html;
   if(typeof html!=='string'||(characters+=html.length)>600_000)return unchanged();
   const root=parseFragment(html,{sourceCodeLocationInfo:true}),ids=new Map<string,number>(),uncertainIds=new Set<string>(),links:Array<{node:Element;href:string}>=[];
   const stack:Array<{node:Node;bound:boolean}>=[{node:root,bound:false}];
   while(stack.length){
    const {node,bound:parentBound}=stack.pop()!;if(++visited>20_000)return unchanged();
    let bound=parentBound;
    if('tagName' in node){
     if(node.tagName==='template')continue; // Inert template content is not a rendered target.
     bound ||= node.attrs.some(attribute=>/^data-(?:aacms|template|form|menu)(?:-|$)/.test(attribute.name)||dynamic(attribute.value));
     const id=attr(node,'id');if(id&&!dynamic(id)){if(bound)uncertainIds.add(id);else ids.set(id,(ids.get(id)||0)+1);}
     const href=attr(node,'href');
     if(!bound&&attr(node,'download')===undefined&&node.namespaceURI===HTML&&node.tagName==='a'&&href?.startsWith('#')&&href.length>1&&href.length<=512&&node.sourceCodeLocation?.attrs?.href)links.push({node,href});
    }
    if('childNodes' in node)for(let i=node.childNodes.length-1;i>=0;i--)stack.push({node:node.childNodes[i],bound});
   }
   indexed.set(id,{ids,uncertainIds,links});
  }
  const rendered=pages.map(page=>{
   const ids=new Map<string,number>();
   for(const id of [site.header_template_id,page.template_id,site.footer_template_id]){
    if(id===undefined)continue;
    for(const [key,count] of indexed.get(id)!.ids)ids.set(key,(ids.get(key)||0)+count);
   }
   return {page,ids};
  });
  const repairs:SharedFragmentLinkRepair[]=[],changes=new Map<number,string>();
  for(const id of new Set(chrome)){
   const template=byId.get(id)!,edits:Array<{start:number;end:number;text:string}>=[];
   for(const {node,href} of indexed.get(id)!.links){
    let fragment:string;try{fragment=decodeURIComponent(href.slice(1));}catch{continue;}
    if(!fragment||dynamic(fragment))continue;
    if([...indexed.values()].some(entry=>entry.uncertainIds.has(fragment)))continue;
    const counts=rendered.map(row=>row.ids.get(fragment)||0);
    if(counts.every(count=>count===1)||counts.some(count=>count>1))continue;
    const destinations=rendered.filter((_row,index)=>counts[index]===1);
    if(destinations.length!==1)continue;
    const page=destinations[0].page;
    // Keep uncertain/noncanonical slugs for the normal contract validator.
    if(page.key!==site.home&&!/^[\p{L}\p{N}][\p{L}\p{N}/_-]*$/u.test(page.slug))continue;
    const path=page.key===site.home?'/':'/'+page.slug;
    if(path.includes('//'))continue;
    const to=path+href,location=node.sourceCodeLocation!.attrs!.href;
    edits.push({start:location.startOffset,end:location.endOffset,text:'href="'+escape(to)+'"'});
    repairs.push({templateId:id,from:href,to,targetPage:page.key,reason:'unique_cross_page_fragment'});
    if(repairs.length>128)return unchanged();
   }
   if(edits.length){let html=template.document.html;for(const edit of edits.sort((a,b)=>b.start-a.start))html=html.slice(0,edit.start)+edit.text+html.slice(edit.end);changes.set(id,html);}
  }
  if(!repairs.length)return unchanged();
  return {manifest:{...manifest,templates:templates.map(template=>changes.has(template.id)?{...template,document:{...template.document,html:changes.get(template.id)!}}:template)} as T,repairs};
 }catch{return unchanged();} // Optional normalization cannot make a valid candidate unsavable.
}
