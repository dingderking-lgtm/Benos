import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id,sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,rateLimit } from './auth';
import { validateSiteAssets,validateSiteManifest,type SiteAssetFile } from './template-contract';
import example from '../contracts/site-example.json';
import { inspectGif,inspectSvg,inspectPdf } from '../lib/extended-media';

export const MAX_MEDIA_BYTES=12*1024*1024;
/** Current signed CMS bridge transfer is single-request. Bound before any R2 read. */
export const MAX_PUBLICATION_ASSET_BYTES=6*1024*1024;
const MAX_PROJECT_BYTES=512*1024*1024,MAX_PROJECT_FILES=500;
type MediaRow={id:string;user_id:string;project_id:string;request_key:string;request_hash:string;object_key:string;filename:string;mime_type:string;extension:string;byte_size:number;width:number;height:number;sha256:string;source:string;generation_job_id:string|null;state:string;created_at:string;updated_at:string;deleted_at:string|null};
export type MediaInspection={sha256:string;mimeType:'image/png'|'image/jpeg'|'image/webp'|'image/gif'|'image/svg+xml'|'application/pdf';extension:'png'|'jpg'|'webp'|'gif'|'svg'|'pdf';byteSize:number;width:number;height:number};
function invalid(message='图片格式、文件结构或尺寸不受支持'):never{throw new AppError('MEDIA_INVALID',message,422);}
function ascii(bytes:Uint8Array,at:number,length:number){return String.fromCharCode(...bytes.subarray(at,at+length));}
function crc32(bytes:Uint8Array){let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;}

/** Bounded container/signature/dimension validation. GIF indices and safe SVG
 * are parsed independently; native CMS still validates/decode-checks imports. */
export async function inspectMediaBytes(bytes:Uint8Array,claimedMime?:string):Promise<MediaInspection>{
 if(!(bytes instanceof Uint8Array)||bytes.byteLength<12||bytes.byteLength>MAX_MEDIA_BYTES)invalid('单个素材需为 1 字节至 12 MiB');
 const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let width=0,height=0,extension:MediaInspection['extension'],mimeType:MediaInspection['mimeType'];
 if(ascii(bytes,0,8)==='\x89PNG\r\n\x1a\n'){
  extension='png';mimeType='image/png';let at=8,header=false,data=false,end=false;
  while(at+12<=bytes.length){const size=v.getUint32(at),type=ascii(bytes,at+4,4);if(size>MAX_MEDIA_BYTES||at+size+12>bytes.length)invalid();
   if(crc32(bytes.subarray(at+4,at+8+size))!==v.getUint32(at+8+size))invalid('PNG 校验和无效');
   if(!header){if(type!=='IHDR'||size!==13)invalid();width=v.getUint32(at+8);height=v.getUint32(at+12);header=true;
    const depth=bytes[at+16],color=bytes[at+17];if(!({0:[1,2,4,8,16],2:[8,16],3:[1,2,4,8],4:[8,16],6:[8,16]} as Record<number,number[]>)[color]?.includes(depth)||bytes[at+18]!==0||bytes[at+19]!==0||bytes[at+20]>1)invalid();
   }else if(type==='IHDR'||type==='acTL'||type==='fcTL'||type==='fdAT')invalid('不支持重复头或动画 PNG');
   if(type==='IDAT'){if(size===0)invalid();data=true;}
   if(type==='IEND'){if(size!==0||!data||at+12!==bytes.length)invalid();end=true;break;}
   if(!/^[a-zA-Z]{4}$/.test(type))invalid();at+=size+12;
  }if(!header||!end)invalid();
 }else if(bytes[0]===0xff&&bytes[1]===0xd8){
  extension='jpg';mimeType='image/jpeg';let at=2,frame=false,scan=false,end=false;
  while(at<bytes.length){if(bytes[at++]!==0xff)invalid();while(bytes[at]===0xff)at++;const marker=bytes[at++];
   if(marker===0xd9){end=true;break;}if(marker===0xd8||marker===0||marker===undefined)invalid();
   if(marker===0x01||(marker>=0xd0&&marker<=0xd7)){if(!scan)invalid();continue;}
   if(at+2>bytes.length)invalid();const size=v.getUint16(at);if(size<2||at+size>bytes.length)invalid();
   if([0xc0,0xc1,0xc2].includes(marker)){if(frame||size<8)invalid();height=v.getUint16(at+3);width=v.getUint16(at+5);if(bytes[at+2]!==8||![1,3,4].includes(bytes[at+7]))invalid();frame=true;}
   if(marker===0xda){if(!frame||size<6)invalid();scan=true;at+=size;while(at<bytes.length){if(bytes[at]!==0xff){at++;continue;}const next=bytes[at+1];if(next===0||next===0xff||(next>=0xd0&&next<=0xd7)){at+=2;continue;}break;}continue;}at+=size;
  }if(!frame||!scan||!end||at!==bytes.length)invalid('JPEG 文件截断或包含多余尾部内容');
 }else if(ascii(bytes,0,4)==='RIFF'&&ascii(bytes,8,4)==='WEBP'){
  extension='webp';mimeType='image/webp';if(v.getUint32(4,true)+8!==bytes.length)invalid();let at=12,frames=0,extended=false;
  while(at+8<=bytes.length){const type=ascii(bytes,at,4),length=v.getUint32(at+4,true),p=at+8;if(p+length+(length%2)>bytes.length)invalid();
   if(type==='ANIM'||type==='ANMF')invalid('暂不支持动画 WebP');
   if(type==='VP8X'){if(extended||at!==12||length!==10||(bytes[p]&2))invalid();extended=true;width=1+bytes[p+4]+(bytes[p+5]<<8)+(bytes[p+6]<<16);height=1+bytes[p+7]+(bytes[p+8]<<8)+(bytes[p+9]<<16);}
   if(type==='VP8 '){if(length<10||ascii(bytes,p+3,3)!=='\x9d\x01\x2a'||(bytes[p]&1))invalid();const w=v.getUint16(p+6,true)&0x3fff,h=v.getUint16(p+8,true)&0x3fff;if(extended&&(width!==w||height!==h))invalid();width=w;height=h;frames++;}
   if(type==='VP8L'){if(length<5||bytes[p]!==0x2f||(bytes[p+4]&0xe0))invalid();const bits=v.getUint32(p+1,true),w=(bits&0x3fff)+1,h=((bits>>>14)&0x3fff)+1;if(extended&&(width!==w||height!==h))invalid();width=w;height=h;frames++;}
   at=p+length+(length%2);
  }if(at!==bytes.length||frames!==1)invalid();
 }else if(/^GIF8[79]a$/.test(ascii(bytes,0,6))){({width,height,extension,mimeType}=inspectGif(bytes));}
 else if(ascii(bytes,0,5)==='%PDF-'){({width,height,extension,mimeType}=inspectPdf(bytes));}
 else {({width,height,extension,mimeType}=inspectSvg(bytes));}
 if(extension!=='pdf'&&(!Number.isSafeInteger(width)||!Number.isSafeInteger(height)||width<1||height<1||width>8192||height>8192||extension!=='svg'&&width*height>16_000_000))invalid('图片边长最多 8192，位图像素总数最多 1600 万');
 if(claimedMime&&claimedMime.toLowerCase().split(';')[0]!==mimeType)invalid('声明的图片类型与真实文件头不一致');
 const digest=await sha256(bytes),asset={file:'assets/0.'+extension,path:'/uploads/2026/01/'+digest+'.'+extension,sha256:digest,size:bytes.byteLength};
 const checked=await validateSiteAssets({...example,assets:[asset]},[{file:asset.file,bytes}]);if(!checked.valid)invalid(checked.issues.find(i=>i.severity==='error')?.message);
 return {sha256:digest,mimeType,extension,byteSize:bytes.byteLength,width,height};
}
export async function ownedMediaProject(env:Env,userId:string,projectId:string){const row=await env.DB.prepare('SELECT id FROM projects WHERE id=? AND user_id=? AND archived_at IS NULL').bind(projectId,userId).first();assert(row,'NOT_FOUND','项目不存在',404);}
function bucket(env:Env){assert(env.BUCKET,'MEDIA_NOT_CONFIGURED','素材存储尚未配置',503);return env.BUCKET;}
export function mediaView(row:MediaRow){return {id:row.id,projectId:row.project_id,fileName:row.filename,mimeType:row.mime_type,extension:row.extension,byteSize:row.byte_size,width:row.width,height:row.height,sha256:row.sha256,source:row.source,state:row.state,createdAt:row.created_at,deletedAt:row.deleted_at,contentUrl:'/api/media/assets/'+encodeURIComponent(row.id)+'/content',assetPath:'/uploads/'+row.created_at.slice(0,4)+'/'+row.created_at.slice(5,7)+'/'+row.sha256+'.'+row.extension};}
const mediaTable=(extension:string)=>['gif','svg','pdf'].includes(extension)?'project_media_extended':'project_media';
async function rowFor(env:Env,userId:string,mediaId:string){const row=await env.DB.prepare('SELECT m.* FROM project_media_inventory m JOIN projects p ON p.id=m.project_id AND p.user_id=m.user_id WHERE m.id=? AND m.user_id=? AND p.archived_at IS NULL').bind(mediaId,userId).first<MediaRow>();assert(row,'NOT_FOUND','素材不存在',404);return row;}
export async function saveMedia(env:Env,userId:string,projectId:string,input:{bytes:Uint8Array;fileName:string;mimeType?:string;requestKey:string;source?:'upload'|'generation';generationJobId?:string}){
 await ownedMediaProject(env,userId,projectId);const storage=bucket(env),info=await inspectMediaBytes(input.bytes,input.mimeType);
 const table=mediaTable(info.extension);assert(input.source!=='generation'||table==='project_media','MEDIA_INVALID','AI 生成只能保存受支持的位图',422);
 assert(/^[a-zA-Z0-9:_-]{8,160}$/.test(input.requestKey),'VALIDATION','请提供有效的上传请求编号');
 assert(input.fileName.length>=1&&input.fileName.length<=180&&!/[\x00-\x1f\x7f/\\]/.test(input.fileName),'VALIDATION','文件名无效');
 const hash=await sha256(JSON.stringify({projectId,sha256:info.sha256,fileName:input.fileName,source:input.source??'upload',generationJobId:input.generationJobId??null}));
 let existing=await env.DB.prepare('SELECT * FROM project_media_inventory WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<MediaRow>();
 if(existing){assert(existing.request_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他文件',409);if(existing.state!=='staging')return mediaView(existing);}
 else {
  const mediaId=id('media'),key='private/users/'+encodeURIComponent(userId)+'/projects/'+encodeURIComponent(projectId)+'/'+mediaId+'/original.'+info.extension,now=new Date().toISOString(),guard=id('guard');
  try{await env.DB.batch([
   env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM projects WHERE id=? AND user_id=? AND archived_at IS NULL) AND ((SELECT COUNT(*) FROM project_media_inventory WHERE project_id=?)<? AND (SELECT COALESCE(SUM(byte_size),0) FROM project_media_inventory WHERE project_id=?)+?<=? OR EXISTS(SELECT 1 FROM project_media_inventory WHERE user_id=? AND request_key=?)) THEN 1 ELSE 0 END`).bind(guard,projectId,userId,projectId,MAX_PROJECT_FILES,projectId,info.byteSize,MAX_PROJECT_BYTES,userId,input.requestKey),
   env.DB.prepare(`INSERT INTO ${table}(id,user_id,project_id,request_key,request_hash,object_key,filename,mime_type,extension,byte_size,width,height,sha256,source,generation_job_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,request_key) DO NOTHING`).bind(mediaId,userId,projectId,input.requestKey,hash,key,input.fileName,info.mimeType,info.extension,info.byteSize,info.width,info.height,info.sha256,input.source??'upload',input.generationJobId??null,now,now),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
  ]);}catch(error){if(String(error).includes('media_identity_conflict'))throw new AppError('IDEMPOTENCY_CONFLICT','请求编号已用于其他文件',409);if(String(error).includes('mutation_revision_ok'))throw new AppError('MEDIA_STORAGE_LIMIT','项目素材存储已达上限或项目状态已变更',409);throw error;}
  existing=await env.DB.prepare('SELECT * FROM project_media_inventory WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<MediaRow>();assert(existing,'MEDIA_WRITE_UNCERTAIN','上传状态待确认，请使用原请求编号重试',503);assert(existing.request_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他文件',409);
 }
 // Exact same bytes/key are safe to retry after an unknown PUT acknowledgement.
 await storage.put(existing.object_key,new Uint8Array(input.bytes),{httpMetadata:{contentType:info.mimeType,cacheControl:'private, no-store'},customMetadata:{sha256:info.sha256}});
 await env.DB.batch([env.DB.prepare(`UPDATE ${table} SET state='ready',updated_at=? WHERE id=? AND state='staging'`).bind(new Date().toISOString(),existing.id),auditStatement(env.DB,userId,'media.saved','media',existing.id,{sha256:info.sha256,bytes:info.byteSize},existing.id)]);
 return mediaView(await rowFor(env,userId,existing.id));
}
export async function listMedia(env:Env,userId:string,projectId:string,includeDeleted=false){await ownedMediaProject(env,userId,projectId);const rows=await env.DB.prepare(`SELECT * FROM project_media_inventory WHERE user_id=? AND project_id=? AND state IN (${includeDeleted?"'ready','deleted'":"'ready'"}) ORDER BY created_at DESC LIMIT 500`).bind(userId,projectId).all<MediaRow>();return rows.results.map(mediaView);}
export async function setMediaDeleted(env:Env,userId:string,mediaId:string,deleted:boolean){
 const row=await rowFor(env,userId,mediaId);assert(row.state!=='staging','MEDIA_NOT_READY','素材上传尚未完成',409);const now=new Date().toISOString(),guard=id('media_guard');
 try{await env.DB.batch([
  ...(deleted?[env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?1,CASE WHEN NOT EXISTS(SELECT 1 FROM design_versions v,json_each(v.manifest_json,'$.assets') a WHERE v.project_id=?2 AND json_extract(a.value,'$.sha256')=?3 AND json_extract(a.value,'$.size')=?4) AND NOT EXISTS(SELECT 1 FROM design_candidates d,json_each(d.manifest_json,'$.assets') a WHERE d.project_id=?2 AND d.state='draft' AND json_extract(a.value,'$.sha256')=?3 AND json_extract(a.value,'$.size')=?4) AND NOT EXISTS(SELECT 1 FROM design_edit_media_refs r JOIN design_edit_workspaces w ON w.id=r.workspace_id WHERE w.project_id=?2 AND w.state IN ('preparing','ready') AND r.sha256=?3 AND r.byte_size=?4) THEN 1 ELSE 0 END`).bind(guard,row.project_id,row.sha256,row.byte_size)]:[]),
  env.DB.prepare(`UPDATE ${mediaTable(row.extension)} SET state=?,deleted_at=?,updated_at=? WHERE id=? AND user_id=?`).bind(deleted?'deleted':'ready',deleted?row.deleted_at??now:null,now,mediaId,userId),auditStatement(env.DB,userId,deleted?'media.deleted':'media.restored','media',mediaId,{},mediaId),...(deleted?[env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)]:[])
 ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('MEDIA_IN_USE','这张素材已被设计版本引用，需保留以保障历史预览与回滚',409);throw error;}
 return mediaView(await rowFor(env,userId,mediaId));
}
/** Insert inside the SAME D1 batch that saves a design version, then delete this
 * guard ID at the batch's end. Serializes save-vs-delete without a TOCTOU gap. */
export function mediaReferencesAvailableStatement(db:D1Database,userId:string,projectId:string,manifest:unknown,guardId:string):D1PreparedStatement{
 return db.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN NOT EXISTS(SELECT 1 FROM json_each(?,'$.assets') a WHERE NOT EXISTS(SELECT 1 FROM project_media_inventory m WHERE m.user_id=? AND m.project_id=? AND m.state='ready' AND m.sha256=json_extract(a.value,'$.sha256') AND m.byte_size=json_extract(a.value,'$.size') AND (json_extract(a.value,'$.file') LIKE '%.'||m.extension OR (m.extension='jpg' AND json_extract(a.value,'$.file') LIKE '%.jpeg')))) THEN 1 ELSE 0 END`).bind(guardId,JSON.stringify({assets:(manifest as {assets:unknown[]}).assets}),userId,projectId);
}
export async function readMedia(env:Env,userId:string,mediaId:string){const row=await rowFor(env,userId,mediaId);assert(row.state==='ready','NOT_FOUND','素材不存在',404);const object=await bucket(env).get(row.object_key);assert(object,'MEDIA_MISSING','素材存储副本暂不可用',503);assert(object.size===row.byte_size,'MEDIA_CORRUPT','素材存储副本校验失败',503);const bytes=new Uint8Array(await object.arrayBuffer());assert(await sha256(bytes)===row.sha256,'MEDIA_CORRUPT','素材存储副本校验失败',503);return {row,bytes};}
export async function resolveProjectAssets(env:Env,userId:string,projectId:string,manifest:unknown):Promise<{files:SiteAssetFile[];mapping:Record<string,string>}>{
 await ownedMediaProject(env,userId,projectId);const checked=validateSiteManifest(manifest);assert(checked.valid,'TEMPLATE_INVALID','模板结构校验失败');const declared=(manifest as {assets:Array<{size:number}>}).assets.reduce((sum,asset)=>sum+asset.size,0);
 assert(declared<=MAX_PUBLICATION_ASSET_BYTES,'MEDIA_TRANSFER_LIMIT','当前发布通道每个模板的素材总量最多 6 MiB，请先压缩图片',413);
 const files:SiteAssetFile[]=[],mapping:Record<string,string>={};
 for(const asset of (manifest as {assets:Array<{file:string;path:string;sha256:string;size:number}>}).assets){const extension=asset.file.split('.').pop();const row=await env.DB.prepare("SELECT * FROM project_media_inventory WHERE user_id=? AND project_id=? AND sha256=? AND byte_size=? AND extension=? AND state='ready' ORDER BY created_at LIMIT 1").bind(userId,projectId,asset.sha256,asset.size,extension==='jpeg'?'jpg':extension!).first<MediaRow>();assert(row,'MEDIA_NOT_FOUND','模板引用了未上传、已删除或不属于该项目的素材',422);const {bytes}=await readMedia(env,userId,row.id);await inspectMediaBytes(bytes,row.mime_type);files.push({file:asset.file,bytes});mapping[asset.path]=mediaView(row).contentUrl;}
 const assets=await validateSiteAssets(manifest,files);assert(assets.valid,'MEDIA_INVALID','模板素材字节校验失败',422);return {files,mapping};
}
export async function boundedBytes(body:ReadableStream<Uint8Array>|null,maximum:number){assert(body,'REQUEST_EMPTY','文件不能为空');const reader=body.getReader(),chunks:Uint8Array[]=[];let size=0;while(true){const item=await reader.read();if(item.done)break;size+=item.value.byteLength;if(size>maximum){await reader.cancel();throw new AppError('REQUEST_TOO_LARGE','文件超过上传上限',413);}chunks.push(item.value);}const result=new Uint8Array(size);let at=0;for(const chunk of chunks){result.set(chunk,at);at+=chunk.length;}return result;}
export const mediaRoutes=new Hono<App>();mediaRoutes.use('*',requireAuth);
mediaRoutes.get('/projects/:project/assets',async c=>ok(c,{items:await listMedia(c.env,c.get('auth').user.id,c.req.param('project'),c.req.query('deleted')==='1')}));
mediaRoutes.post('/projects/:project/assets',async c=>{await rateLimit(c,'media-upload',60,3600,c.get('auth').user.id);await ownedMediaProject(c.env,c.get('auth').user.id,c.req.param('project'));bucket(c.env);let fileName='';try{fileName=decodeURIComponent(c.req.header('x-filename')??'');}catch{throw new AppError('VALIDATION','文件名编码无效');}return ok(c,await saveMedia(c.env,c.get('auth').user.id,c.req.param('project'),{bytes:await boundedBytes(c.req.raw.body,MAX_MEDIA_BYTES),fileName,mimeType:c.req.header('content-type'),requestKey:c.req.header('idempotency-key')??''}),201);});
mediaRoutes.get('/assets/:id/content',async c=>{const {row,bytes}=await readMedia(c.env,c.get('auth').user.id,c.req.param('id'));return new Response(bytes,{headers:{'Content-Type':row.mime_type,'Content-Length':String(bytes.length),'Cache-Control':'private, no-store','Content-Disposition':(row.extension==='pdf'?'attachment':'inline')+'; filename="asset.'+row.extension+'"','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox",'Cross-Origin-Resource-Policy':'same-origin','Referrer-Policy':'no-referrer'}});});
for(const action of ['delete','restore'] as const)mediaRoutes.post('/assets/:id/'+action,async c=>{await body(c,z.object({}).strict());return ok(c,await setMediaDeleted(c.env,c.get('auth').user.id,c.req.param('id')!,action==='delete'));});
