import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { assert } from '../lib/errors';
import { id,sha256 } from '../lib/crypto';
import { requireAuth,requireRole,rateLimit } from './auth';
import { textConfigSchema } from './integrations';
import { textReservationCost } from './ai-billing';
import { parseQuery } from './admin-operations';
type Pool={provider_id:string;funded_micros:number;consumed_micros:number;reserved_micros:number;safety_micros:number;enabled:number;};
export async function budgetAlerts(env:Env){
 const pools=(await env.DB.prepare('SELECT provider_id,funded_micros,consumed_micros,reserved_micros,safety_micros,enabled FROM provider_pools ORDER BY provider_id').all<Pool>()).results;
 const configs=(await env.DB.prepare("SELECT public_config_json FROM integration_configs WHERE kind='text' AND status='active' AND test_status='passed'").all<{public_config_json:string}>()).results;
 const minimums=new Map<string,number>();for(const c of configs){try{const p=textConfigSchema.parse(JSON.parse(c.public_config_json)),minimum=textReservationCost(p);minimums.set(p.providerPoolId,Math.max(minimums.get(p.providerPoolId)??0,minimum));}catch{/* Invalid configs cannot authorize requests. */}}
 const alerts:Array<{code:string;providerId:string|null;title:string;body:string}>=[];
 if(!pools.length)alerts.push({code:'NO_PROVIDER_BUDGET',providerId:null,title:'尚未登记 API 资金',body:'核实供应商实际到账后登记预算，未登记前不能接受收费调用。'});
 for(const p of pools){const available=p.funded_micros-p.consumed_micros-p.reserved_micros-p.safety_micros,minimum=minimums.get(p.provider_id)??1;
  if(!p.enabled)alerts.push({code:'PROVIDER_STOPPED',providerId:p.provider_id,title:'预算池已暂停新调用',body:'核对费用、价格和可用资金后，由平台所有者决定恢复。'});
  if(available<minimum)alerts.push({code:'PROVIDER_FUNDS_LOW',providerId:p.provider_id,title:'当前预算不足以保障下一次调用',body:'请补充并核实供应商资金。用户余额与已有设计保持不变，各供应商资金池不能互借。'});
 }
 const unknown=(await env.DB.prepare("SELECT provider_id,COUNT(*) count,SUM(amount_micros) held FROM api_reservations WHERE state='uncertain' GROUP BY provider_id").all<{provider_id:string;count:number;held:number}>()).results;
 for(const p of unknown)alerts.push({code:'UNKNOWN_PROVIDER_COST',providerId:p.provider_id,title:`${p.count} 个请求费用待核对`,body:'继续保留原请求预占，按供应商原始请求或账单核对；超时不代表免费。'});
 const differences=(await env.DB.prepare('SELECT r.provider_id,r.difference_micros FROM provider_balance_reviews r WHERE r.id=(SELECT x.id FROM provider_balance_reviews x WHERE x.provider_id=r.provider_id ORDER BY x.created_at DESC,x.id DESC LIMIT 1) AND r.difference_micros<>0').all<{provider_id:string;difference_micros:number}>()).results;
 for(const d of differences)alerts.push({code:'PROVIDER_BALANCE_DIFFERENCE',providerId:d.provider_id,title:'最近一次余额核对存在差异',body:'差异可能来自账单延迟、在途消费或站外用量；请根据凭据核对，记录不会自动增减预算。'});
 return {alerts,pools:pools.map(p=>({...p,availableMicros:p.funded_micros-p.consumed_micros-p.reserved_micros-p.safety_micros,requiredReservationMicros:minimums.get(p.provider_id)??null})),asOf:new Date().toISOString()};
}
export const balanceReviewSchema=z.object({requestKey:z.string().regex(/^[a-zA-Z0-9:_-]{16,128}$/),observedAt:z.string().datetime(),actualBalanceMicros:z.number().int().min(0).max(1_000_000_000_000),evidence:z.string().trim().min(10).max(2000)}).strict();
export async function recordBalanceReview(env:Env,actorId:string,providerId:string,raw:unknown){
 const checked=balanceReviewSchema.safeParse(raw);assert(checked.success,'VALIDATION','余额核对内容无效，请检查编号、时间、金额和凭据');const input=checked.data;assert(Date.parse(input.observedAt)<=Date.now()+5*60_000,'VALIDATION','余额观察时间不能晚于当前时间');
 assert(await env.DB.prepare("SELECT 1 FROM users WHERE id=? AND role='owner' AND status='active'").bind(actorId).first(),'FORBIDDEN','仅平台所有者可登记供应商余额核对',403);
 const hash=await sha256(JSON.stringify({providerId,...input})),existing=await env.DB.prepare('SELECT id,request_hash FROM provider_balance_reviews WHERE provider_id=? AND request_key=?').bind(providerId,input.requestKey).first<{id:string;request_hash:string}>();
 if(existing){assert(existing.request_hash===hash,'IDEMPOTENCY_CONFLICT','此核对编号已用于不同记录',409);return {id:existing.id};}
 assert(await env.DB.prepare('SELECT 1 FROM provider_pools WHERE provider_id=?').bind(providerId).first(),'NOT_FOUND','预算池不存在',404);
 const reviewId=id('balance_review'),now=new Date().toISOString();
 await env.DB.batch([
  env.DB.prepare(`INSERT INTO provider_balance_reviews(id,provider_id,actor_id,request_key,request_hash,observed_at,actual_balance_micros,local_net_micros,held_micros,safety_micros,difference_micros,evidence,created_at) SELECT ?,provider_id,?,?,?,?,?,funded_micros-consumed_micros,reserved_micros,safety_micros,?-(funded_micros-consumed_micros),?,? FROM provider_pools WHERE provider_id=? ON CONFLICT(provider_id,request_key) DO NOTHING`).bind(reviewId,actorId,input.requestKey,hash,input.observedAt,input.actualBalanceMicros,input.actualBalanceMicros,input.evidence,now,providerId),
  env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?,?,'budget.balance_review','provider',provider_id,json_object('reviewId',id,'actualBalanceMicros',actual_balance_micros,'localNetMicros',local_net_micros,'heldMicros',held_micros,'differenceMicros',difference_micros),?,? FROM provider_balance_reviews WHERE id=?`).bind(id('audit'),actorId,input.requestKey,now,reviewId)
 ]);
 const row=await env.DB.prepare('SELECT id,request_hash FROM provider_balance_reviews WHERE provider_id=? AND request_key=?').bind(providerId,input.requestKey).first<{id:string;request_hash:string}>();assert(row&&row.request_hash===hash,'IDEMPOTENCY_CONFLICT','此核对编号已用于不同记录',409);return {id:row.id};
}
export const budgetReviewRoutes=new Hono<App>();budgetReviewRoutes.use('*',requireAuth,requireRole('owner','admin'));
budgetReviewRoutes.get('/',async c=>{const page=parseQuery(z.object({page:z.coerce.number().int().min(1).max(10000).default(1)}),{page:c.req.query('page')||undefined}).page,reviews=await c.env.DB.prepare('SELECT r.*,u.email actor_email FROM provider_balance_reviews r JOIN users u ON u.id=r.actor_id ORDER BY r.created_at DESC,r.id DESC LIMIT 51 OFFSET ?').bind((page-1)*50).all<Record<string,unknown>>();return ok(c,{...await budgetAlerts(c.env),reviews:reviews.results.slice(0,50).map(({request_hash,...r})=>r),page,hasMore:reviews.results.length>50});});
budgetReviewRoutes.post('/:provider',requireRole('owner'),async c=>{await rateLimit(c,'balance-review',30,3600,c.get('auth').user.id);return ok(c,await recordBalanceReview(c.env,c.get('auth').user.id,c.req.param('provider'),await body(c,balanceReviewSchema)),201);});
