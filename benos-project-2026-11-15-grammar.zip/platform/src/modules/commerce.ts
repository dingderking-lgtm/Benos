import { Hono } from 'hono';
import type { Env } from '../env';
import { z } from 'zod';
import { type App, body, ok } from '../lib/http';
import { AppError, assert } from '../lib/errors';
import { id, sha256 } from '../lib/crypto';
import { requireAuth,rateLimit } from './auth';
import { getWallet } from './ledger';
import { currentCatalog,catalogPlans,makePlanSnapshot,makeCnyPlanSnapshot,BUILTIN_CATALOG_ID,type CatalogView } from './billing-catalog';
import { hostingBillingSummary,PARKED_JOB,PARKED_SITE_TTL_MS } from './hosting-billing';

export const PLANS = Object.freeze([
 { tier:'go', name:'Go', priceCents:2500, creditMicros:16_250_000, includedSites:1 },
 { tier:'pro', name:'Pro', priceCents:10000, creditMicros:65_000_000, includedSites:2 },
]);
export const orderInputSchema = z.discriminatedUnion('kind', [
 z.object({ kind:z.literal('subscription'), tier:z.enum(['go','pro']), requestKey:z.string().min(8).max(128),catalogVersionId:z.string().max(128).optional(),checkoutChannel:z.enum(['page','wap']).optional() }).strict(),
 z.object({ kind:z.literal('topup'), amountCents:z.number().int().min(1).max(99_999_999), requestKey:z.string().min(8).max(128),catalogVersionId:z.string().max(128).optional(),checkoutChannel:z.enum(['page','wap']).optional() }).strict(),
 z.object({ kind:z.literal('hosting'), siteId:z.string().min(1).max(128), requestKey:z.string().min(8).max(128),catalogVersionId:z.string().max(128).optional(),checkoutChannel:z.enum(['page','wap']).optional() }).strict(),
]);
export type OrderInput = z.infer<typeof orderInputSchema>;
export interface Order {
 id:string; user_id:string; kind:'subscription'|'topup'|'hosting'; plan_tier:'go'|'pro'|null;
 amount_cents:number; credit_micros:number; currency:'USD'|'CNY'; state:string;
 provider:string|null; checkout_id:string|null; checkout_url:string|null; payment_id:string|null;
 idempotency_key:string; payload_hash:string; hosting_site_id:string|null;
 created_at:string; expires_at:string; paid_at:string|null; fulfilled_at:string|null;
 config_version_id:string; eligible_until:string|null;
 catalog_version_id:string|null;plan_snapshot_json:string|null;
}
export interface Subscription {
 id:string; tier:string; source:string; starts_at:string; ends_at:string; included_sites:number;
 credit_micros:number; topup_allowed:number; auto_renew:number;
}
export function quoteOrder(input:OrderInput) {
 const parsed=orderInputSchema.parse(input);
 if(parsed.kind==='subscription') {
  const plan=PLANS.find(p=>p.tier===parsed.tier)!;
  return { amountCents:plan.priceCents, creditMicros:plan.creditMicros, tier:plan.tier, siteId:null };
 }
 if(parsed.kind==='topup'){assert(parsed.amountCents>=500,'VALIDATION','美元充值金额至少5美元');return {amountCents:parsed.amountCents,creditMicros:parsed.amountCents*6500,tier:null,siteId:null};}
 return {amountCents:3000,creditMicros:0,tier:null,siteId:parsed.siteId};
}
export async function activeSubscription(db:D1Database,userId:string,now=new Date().toISOString()) {
 return db.prepare("SELECT id,tier,source,starts_at,ends_at,included_sites,credit_micros,topup_allowed,auto_renew FROM subscriptions WHERE membership_frozen_by IS NULL AND user_id=? AND state IN ('active','cancelled') AND starts_at<=? AND ends_at>? ORDER BY CASE tier WHEN 'pro' THEN 0 ELSE 1 END,ends_at DESC LIMIT 1").bind(userId,now,now).first<Subscription>();
}
/** R4-M1: Stripe opens a renewal invoice at the period start and charges it about
 * an hour later (up to 72 h when its invoice.created delivery is retried). While
 * the account's agreement is still `active` (not cancel-requested, not past_due)
 * and the paid, auto-renewing term ended less than this long ago, its sites stay
 * hosted. It is hosting only: no credit, no top-up, no new site. The grace ends at
 * once when invoice.paid grants the next term, or when Stripe reports the renewal
 * failed (past_due) or cancelled. */
export const RENEWAL_GRACE_MS=72*3600000;
export async function renewalGraceTerm(db:D1Database,userId:string,now=new Date().toISOString()):Promise<Subscription|null> {
 const since=new Date(Date.parse(now)-RENEWAL_GRACE_MS).toISOString();
 return db.prepare(`SELECT s.id,s.tier,s.source,s.starts_at,s.ends_at,s.included_sites,s.credit_micros,s.topup_allowed,s.auto_renew FROM subscriptions s
  WHERE s.user_id=?1 AND s.source='paid' AND s.state='active' AND s.auto_renew=1 AND s.membership_frozen_by IS NULL AND s.ends_at<=?2 AND s.ends_at>?3
  AND EXISTS(SELECT 1 FROM payment_agreements a WHERE a.user_id=s.user_id AND a.state='active' AND a.cancel_requested=0)
  AND NOT EXISTS(SELECT 1 FROM membership_freezes f WHERE f.user_id=s.user_id AND f.state IN ('frozen','pending_unfreeze'))
  ORDER BY CASE s.tier WHEN 'pro' THEN 0 ELSE 1 END,s.ends_at DESC LIMIT 1`).bind(userId,now,since).first<Subscription>();
}
/** The membership term that decides hosting (site access, CMS lease, suspension):
 * the current term, or a term in its renewal grace with `ends_at` set to the
 * grace end (RENEWAL_GRACE_MS). */
export async function hostingSubscription(db:D1Database,userId:string,now=new Date().toISOString()):Promise<(Subscription&{renewalPending:boolean})|null> {
 const current=await activeSubscription(db,userId,now);if(current)return {...current,renewalPending:false};
 const grace=await renewalGraceTerm(db,userId,now);
 return grace?{...grace,ends_at:new Date(Date.parse(grace.ends_at)+RENEWAL_GRACE_MS).toISOString(),renewalPending:true}:null;
}
export async function canTopup(db:D1Database,userId:string,now=new Date().toISOString()):Promise<boolean> {
 const result=await db.prepare(`SELECT 1 FROM users u WHERE u.id=? AND u.status='active'
  AND EXISTS (SELECT 1 FROM subscriptions s WHERE s.user_id=u.id AND s.source='paid' AND s.membership_frozen_by IS NULL
   AND s.state IN ('active','cancelled') AND s.starts_at<=? AND s.ends_at>? AND s.topup_allowed=1)
  AND NOT EXISTS (SELECT 1 FROM user_restrictions r WHERE r.user_id=u.id AND r.scope='topup'
   AND r.revoked_at IS NULL AND r.starts_at<=? AND (r.ends_at IS NULL OR r.ends_at>?))`).bind(userId,now,now,now,now).first();
 return !!result;
}
export async function getOrder(db:D1Database,orderId:string,userId?:string):Promise<Order> {
 const row=await db.prepare(`SELECT * FROM orders WHERE id=?${userId?' AND user_id=?':''}`)
  .bind(...(userId?[orderId,userId]:[orderId])).first<Order>();
 assert(row,'ORDER_NOT_FOUND','订单不存在',404);return row;
}

/** Server-priced order creation. Eligibility and the insert share one SQL statement. */
export async function createOrder(db:D1Database,userId:string,input:OrderInput,configId:string,nowMs=Date.now(),provider:'stripe'|'alipay'='stripe'):Promise<Order> {
 const parsed=orderInputSchema.parse(input),now=new Date(nowMs).toISOString();
 const existing=await db.prepare('SELECT * FROM orders WHERE user_id=? AND idempotency_key=?').bind(userId,parsed.requestKey).first<Order>();
 if(existing){assert(existing.kind===parsed.kind&&(parsed.kind!=='subscription'||existing.plan_tier===parsed.tier)&&(parsed.kind!=='topup'||existing.amount_cents===parsed.amountCents)&&(parsed.kind!=='hosting'||existing.hosting_site_id===parsed.siteId)&&(!parsed.catalogVersionId||parsed.catalogVersionId===(existing.catalog_version_id??BUILTIN_CATALOG_ID)),'IDEMPOTENCY_CONFLICT','相同请求标识不能用于不同订单',409);return existing;}
 const catalog=await currentCatalog(db);assert(catalog.enabled,'PURCHASES_PAUSED','平台暂时停止新订单，已有权益不受影响',503);
 // R-M1a: an unpaid pay-first site past its lifetime takes no new checkout, so it is released once its last one closes.
 const parkedCutoff=new Date(nowMs-PARKED_SITE_TTL_MS).toISOString();
 if(parsed.kind==='hosting')assert(!await db.prepare(`SELECT 1 FROM provisioning_jobs WHERE site_id=? AND user_id=? AND ${PARKED_JOB} AND created_at<=? LIMIT 1`).bind(parsed.siteId,userId,parkedCutoff).first(),'HOSTING_UNPAID_SITE_EXPIRED','该未付款网站已超过保留时间，将自动释放；如仍需要，请稍后重新创建并付款',409);
 assert((parsed.catalogVersionId??BUILTIN_CATALOG_ID)===catalog.id,'CATALOG_CHANGED','套餐版本已变化，请刷新并确认最新价格后重新下单',409);
 if(provider==='stripe'&&parsed.kind==='topup')assert(parsed.amountCents>=500,'VALIDATION','美元充值金额至少5美元');
 const snapshot=(provider==='alipay'?makeCnyPlanSnapshot:makePlanSnapshot)(catalog,parsed.kind,parsed.kind==='subscription'?parsed.tier:null,parsed.kind==='topup'?parsed.amountCents:undefined),quote={amountCents:snapshot.amountCents,creditMicros:snapshot.creditMicros,tier:snapshot.tier,siteId:parsed.kind==='hosting'?parsed.siteId:null};
 // Bind the complete immutable entitlement snapshot, not merely the cash price.
 // Two catalog versions can charge the same amount for different credit/sites.
 const payloadHash=await sha256(JSON.stringify([snapshot,quote.siteId]));
 const orderId=id('ord'), expiry=new Date(nowMs+2*3600_000).toISOString();
 try {
  await db.prepare(`INSERT INTO orders
   (id,user_id,kind,plan_tier,amount_cents,credit_micros,idempotency_key,payload_hash,hosting_site_id,
    created_at,expires_at,provider,config_version_id,eligible_until,eligibility_ok,catalog_version_id,plan_snapshot_json,currency)
   SELECT ?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?16,?12,
    CASE WHEN ?3='topup' THEN (SELECT MAX(ends_at) FROM subscriptions WHERE user_id=?2 AND source='paid' AND membership_frozen_by IS NULL
      AND state IN ('active','cancelled') AND starts_at<=?10 AND ends_at>?10 AND topup_allowed=1) ELSE NULL END,
    CASE WHEN EXISTS (SELECT 1 FROM orders WHERE user_id=?2 AND idempotency_key=?7 AND payload_hash=?8) OR (
     EXISTS (SELECT 1 FROM users WHERE id=?2 AND status='active')
     AND COALESCE((SELECT version_id FROM billing_catalog_active WHERE singleton=1),'benos-default-2026-11-07')=?13
     AND COALESCE((SELECT enabled FROM billing_catalog_active WHERE singleton=1),1)=1
     AND EXISTS (SELECT 1 FROM integration_configs WHERE id=?12 AND kind='payment' AND provider=?16 AND status='active' AND test_status='passed')
     AND (?3<>'topup' OR (EXISTS (SELECT 1 FROM subscriptions WHERE user_id=?2 AND source='paid' AND membership_frozen_by IS NULL
       AND state IN ('active','cancelled') AND starts_at<=?10 AND ends_at>?10 AND topup_allowed=1)
       AND NOT EXISTS (SELECT 1 FROM user_restrictions WHERE user_id=?2 AND scope='topup' AND revoked_at IS NULL
        AND starts_at<=?10 AND (ends_at IS NULL OR ends_at>?10))))
     AND (?3<>'hosting' OR (EXISTS (SELECT 1 FROM sites WHERE id=?9 AND user_id=?2)
       AND NOT EXISTS (SELECT 1 FROM provisioning_jobs WHERE site_id=?9 AND state='awaiting_input' AND step='awaiting_payment' AND created_at<=?15)))
     AND (?3<>'subscription' OR (
       NOT EXISTS (SELECT 1 FROM membership_freezes WHERE user_id=?2 AND state<>'completed')
       AND
       NOT EXISTS (SELECT 1 FROM subscriptions WHERE user_id=?2 AND source='paid' AND membership_frozen_by IS NULL AND state IN ('active','cancelled') AND ends_at>?10 AND (?16<>'alipay' OR tier<>?4 OR auto_renew=1))
       AND NOT EXISTS (SELECT 1 FROM payment_agreements WHERE user_id=?2 AND state<>'cancelled')
       AND NOT EXISTS (SELECT 1 FROM orders WHERE user_id=?2 AND kind='subscription' AND state IN ('created','pending') AND expires_at>?10 AND idempotency_key<>?7)
     ))
    ) THEN 1 ELSE 0 END,?13,?14,?17
   ON CONFLICT(user_id,idempotency_key) DO UPDATE SET payload_hash=CASE WHEN orders.payload_hash=excluded.payload_hash THEN orders.payload_hash ELSE NULL END`)
   .bind(orderId,userId,parsed.kind,quote.tier,quote.amountCents,quote.creditMicros,parsed.requestKey,payloadHash,quote.siteId,now,expiry,configId,catalog.id,JSON.stringify(snapshot),parkedCutoff,provider,provider==='alipay'?'CNY':'USD').run();
 } catch(error) {
  const message=error instanceof Error?`${error.message} ${error.cause??''}`:String(error);
  if(message.includes('order_eligibility')){
   const raced=await db.prepare('SELECT payload_hash FROM orders WHERE user_id=? AND idempotency_key=?').bind(userId,parsed.requestKey).first<{payload_hash:string}>();
   if(raced&&raced.payload_hash!==payloadHash)throw new AppError('IDEMPOTENCY_CONFLICT','相同请求标识不能用于不同订单或套餐权益',409);
  }
  if(message.includes('orders.payload_hash'))throw new AppError('IDEMPOTENCY_CONFLICT','相同请求标识不能用于不同订单',409);
  if(message.includes('order_eligibility'))throw new AppError('PURCHASE_NOT_ALLOWED','当前账户无法购买此项目；充值需有效付费会员，已有月租请管理现有订阅',403);
  throw error;
 }
 const row=await db.prepare('SELECT * FROM orders WHERE user_id=? AND idempotency_key=?').bind(userId,parsed.requestKey).first<Order>();
 assert(row,'ORDER_UNCONFIRMED','订单状态待确认，请使用同一请求标识重试',503);return row;
}

/** A display hint only. The checkout endpoint verifies live provider state. */
export function orderCheckoutState(order:{state:string;expires_at:string},nowMs=Date.now()){
 return {canResumeCheckout:['created','pending'].includes(order.state)&&Date.parse(order.expires_at)>nowMs,checkoutExpiresAt:order.expires_at};
}

/** The sellable catalogue as customers see it. Shared by the signed-in summary and
 * the public catalogue so both always report identical prices for one version. */
export function publicCatalog(catalog:CatalogView){
 const cny=catalog.catalog.cnyPricing??null;
 return {plans:catalogPlans(catalog.catalog).map(plan=>({...plan,priceCents:cny?(plan.tier==='go'?cny.goPriceCents:cny.proPriceCents):null})),catalogVersionId:catalog.id,catalogEnabled:catalog.enabled,
  currency:'CNY' as const,billingMode:'manual' as const,pricingReady:!!cny,cnyPricing:cny,
  hostingAnnualPriceCents:cny?.hostingAnnualPriceCents??null,topupPolicy:{minimumCents:cny?.minimumTopupCents??null,creditMicrosPerCnyCent:cny?.topupCreditMicrosPerCnyCent??null,currency:'CNY' as const},enterprise:catalog.catalog.enterprise};
}
/** An admin freeze is customer-visible only once the membership is actually paused
 * (same rule as the hosting coverage flag and the admin membership view). */
export async function membershipFrozen(db:D1Database,userId:string):Promise<boolean>{
 return !!await db.prepare("SELECT 1 FROM membership_freezes WHERE user_id=? AND state IN ('frozen','pending_unfreeze') LIMIT 1").bind(userId).first();
}
/** End of the continuous membership that contains `now`: confirmed paid terms and
 * gifted months that touch or overlap are chained; a real gap ends the horizon.
 * Unpaid automatic renewals are not terms, so they are never projected. */
export async function membershipHorizon(db:D1Database,userId:string,now=new Date().toISOString()):Promise<string|null>{
 const terms=(await db.prepare("SELECT starts_at,ends_at FROM subscriptions WHERE user_id=? AND membership_frozen_by IS NULL AND state IN ('active','cancelled') AND ends_at>? ORDER BY starts_at,ends_at").bind(userId,now).all<{starts_at:string;ends_at:string}>()).results;
 let horizon:number|null=null;const at=Date.parse(now);
 for(const term of terms){
  const start=Date.parse(term.starts_at),end=Date.parse(term.ends_at);
  if(horizon===null){if(start<=at)horizon=end;continue;}
  if(start<=horizon&&end>horizon)horizon=end;
 }
 return horizon===null?null:new Date(horizon).toISOString();
}
type SummaryOrder=Pick<Order,'id'|'kind'|'plan_tier'|'amount_cents'|'credit_micros'|'currency'|'state'|'created_at'|'expires_at'|'paid_at'|'fulfilled_at'>&{hostingSiteId:string|null;hostingSiteName:string|null;hostingSiteDomain:string|null};

/** Public, cookie-free catalogue. Mounted before the authenticated billing routes. */
export const publicBillingRoutes=new Hono<App>();
export async function publicPaymentAvailability(env:Env){const row=await env.DB.prepare("SELECT id,public_config_json FROM integration_configs WHERE kind='payment' AND provider='alipay' AND status='active' AND test_status='passed' LIMIT 1").first<{id:string;public_config_json:string}>();if(!row)return {ready:false,provider:null,reason:'not-configured'};let mode:unknown;try{mode=JSON.parse(row.public_config_json).mode;}catch{return {ready:false,provider:'alipay' as const,reason:'configuration-invalid'};}if(mode!=='live'&&mode!=='sandbox')return {ready:false,provider:'alipay' as const,reason:'configuration-invalid'};if(env.APP_ENV==='production'&&mode!=='live')return {ready:false,provider:'alipay' as const,reason:'sandbox-in-production'};return {ready:true,provider:'alipay' as const,reason:null};}
publicBillingRoutes.get('/catalog',async c=>{const [catalog,payment]=await Promise.all([currentCatalog(c.env.DB),publicPaymentAvailability(c.env)]);return ok(c,{...publicCatalog(catalog),paymentProvider:payment.provider,paymentReady:payment.ready&&catalog.enabled&&!!catalog.catalog.cnyPricing,paymentUnavailableReason:payment.reason??(!catalog.catalog.cnyPricing?'pricing-not-configured':!catalog.enabled?'purchases-paused':null)});});

export const commerceRoutes=new Hono<App>();
commerceRoutes.use('*',requireAuth);
commerceRoutes.get('/summary',async c=>{
 const userId=c.get('auth').user.id,now=new Date().toISOString();
 const [plan,topup,orders,hostingRows,payment,agreements,catalog,frozen,horizon,grace]=await Promise.all([
  activeSubscription(c.env.DB,userId,now),canTopup(c.env.DB,userId,now),
  // The site join is scoped to the caller: an order never reveals another account's site.
  c.env.DB.prepare(`SELECT o.id,o.kind,o.plan_tier,o.amount_cents,o.credit_micros,o.currency,o.state,o.created_at,o.expires_at,o.paid_at,o.fulfilled_at,
   o.hosting_site_id AS hostingSiteId,s.name AS hostingSiteName,s.domain AS hostingSiteDomain
   FROM orders o LEFT JOIN sites s ON s.id=o.hosting_site_id AND s.user_id=o.user_id
   WHERE o.user_id=? ORDER BY o.created_at DESC LIMIT 50`).bind(userId).all<SummaryOrder>(),
  hostingBillingSummary(c.env.DB,userId),
  publicPaymentAvailability(c.env),
  c.env.DB.prepare('SELECT id,tier,state,cancel_requested FROM payment_agreements WHERE user_id=? ORDER BY created_at DESC').bind(userId).all(),
  currentCatalog(c.env.DB),membershipFrozen(c.env.DB,userId),membershipHorizon(c.env.DB,userId,now),renewalGraceTerm(c.env.DB,userId,now),
 ]);
 // R4-M1: while the auto-renewal invoice of the term that just ended is being
 // confirmed, the sites that term covered are still hosted (hostingSubscription).
 const graceEnded=grace?Date.parse(grace.ends_at):null;
 const hosting=hostingRows.map(row=>({...row,coverage:{...row.coverage,renewalPending:graceEnded!==null&&row.coverage.state!=='active'&&!!row.coverage.lastEndedAt&&Date.parse(row.coverage.lastEndedAt)===graceEnded}}));
 const membershipRenewalPending=grace?{tier:grace.tier,endedAt:grace.ends_at,hostedUntil:new Date(graceEnded!+RENEWAL_GRACE_MS).toISOString()}:null;
 let wallet:unknown=null, walletState='unavailable';
 // Credit that a design round left on hold without anyone reading its answer goes back before the balance is shown.
 try{await (await import('./ai-workflow')).releaseHeldRounds(c.env,userId);}catch{/* the balance is still shown */}
 try {wallet=await getWallet(c.env.DB,userId);walletState='ready';}catch{/* Never invent a zero balance. */}
 return ok(c,{plan:plan?{id:plan.id,tier:plan.tier,endsAt:plan.ends_at,membershipEndsAt:horizon&&Date.parse(horizon)>Date.parse(plan.ends_at)?horizon:plan.ends_at,source:plan.source,includedSites:plan.included_sites,autoRenew:!!plan.auto_renew}:null,
  membershipFrozen:frozen,wallet,walletState,canTopup:topup,...publicCatalog(catalog),orders:orders.results.map(order=>{const checkout=orderCheckoutState(order);return {...order,...checkout,canResumeCheckout:checkout.canResumeCheckout&&(order.kind!=='topup'||topup)};}),hosting,membershipRenewalPending,paymentProvider:payment.provider,paymentReady:payment.ready&&catalog.enabled&&!!catalog.catalog.cnyPricing,paymentUnavailableReason:payment.reason??(!catalog.catalog.cnyPricing?'pricing-not-configured':!catalog.enabled?'purchases-paused':null),agreements:agreements.results});
});
commerceRoutes.post('/checkout',async c=>{
 await rateLimit(c,'billing-checkout',20,3600,c.get('auth').user.id);
 const input=await body(c,orderInputSchema), {createCheckout,backgroundRuntime}=await import('./payments');
 return ok(c,await createCheckout(c.env,c.get('auth').user.id,input,backgroundRuntime(c)),201);
});
commerceRoutes.get('/orders/:id',async c=>ok(c,await getOrder(c.env.DB,c.req.param('id'),c.get('auth').user.id)));
commerceRoutes.post('/orders/:id/reconcile',async c=>{
 await rateLimit(c,'billing-reconcile',60,3600,c.get('auth').user.id);
 const {reconcileOrder,backgroundRuntime}=await import('./payments');
 return ok(c,await reconcileOrder(c.env,c.get('auth').user.id,c.req.param('id'),backgroundRuntime(c)));
});
commerceRoutes.post('/orders/:id/checkout',async c=>{
 await rateLimit(c,'billing-resume',60,3600,c.get('auth').user.id);
 const input=await body(c,z.object({checkoutChannel:z.enum(['page','wap']).optional()}).strict());
 const {resumeCheckout,backgroundRuntime}=await import('./payments');
 return ok(c,await resumeCheckout(c.env,c.get('auth').user.id,c.req.param('id'),{...backgroundRuntime(c),checkoutChannel:input.checkoutChannel}));
});
commerceRoutes.post('/agreements/:id/cancel',async c=>{
 const {cancelRenewal}=await import('./payments');
 return ok(c,await cancelRenewal(c.env,c.get('auth').user.id,c.req.param('id')));
});

