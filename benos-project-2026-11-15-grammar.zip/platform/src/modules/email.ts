import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { z } from 'zod';
import type { Env } from '../env';
import { AppError,assert } from '../lib/errors';
import { decryptSecret,id } from '../lib/crypto';

export const emailConfigurationSchema=z.object({fromEmail:z.string().email().max(254),fromName:z.string().trim().min(1).max(80).regex(/^[^\r\n<>\"]+$/).default('Benos'),replyTo:z.string().email().max(254).optional()}).strict();
export const emailSecretSchema=z.object({apiKey:z.string().startsWith('re_').min(16).max(512)}).strict();
export interface EmailConfiguration extends z.infer<typeof emailConfigurationSchema>{id:string;apiKey:string;}
export interface EmailRuntime {fetch?:typeof fetch;nowMs?:number;limit?:number;onlyId?:string;}
interface Outbox {id:string;user_id:string;token_id:string|null;config_version_id:string;payload_ciphertext:string|null;state:string;attempts:number;expires_at:string;}
function parseConfiguration(publicConfig:unknown,secret:unknown):Omit<EmailConfiguration,'id'>{
 const config=emailConfigurationSchema.safeParse(publicConfig),credentials=emailSecretSchema.safeParse(secret);
 assert(config.success&&credentials.success,'EMAIL_NOT_CONFIGURED','邮件配置尚未完成，暂时无法发送账户邮件',503);
 return {...config.data,...credentials.data};
}
export async function loadEmailConfiguration(env:Env,configId?:string):Promise<EmailConfiguration>{
 const row=await env.DB.prepare(`SELECT id,public_config_json,secret_ciphertext FROM integration_configs WHERE kind='email' AND provider='resend'
  ${configId?'AND id=?':"AND status='active' AND test_status='passed'"} LIMIT 1`).bind(...(configId?[configId]:[])).first<{id:string;public_config_json:string;secret_ciphertext:string|null}>();
 assert(row?.secret_ciphertext,'EMAIL_NOT_CONFIGURED','邮件服务尚未配置，暂时无法发送验证或重置邮件',503);
 try{return {id:row.id,...parseConfiguration(JSON.parse(row.public_config_json),JSON.parse(await decryptSecret(row.secret_ciphertext,env.ENCRYPTION_KEY,row.id))) };}
 catch(error){if(error instanceof AppError&&error.code==='EMAIL_NOT_CONFIGURED')throw error;throw new AppError('EMAIL_NOT_CONFIGURED','邮件配置无法读取，暂时无法发送账户邮件',503);}
}
async function request(config:EmailConfiguration,path:string,method:'GET'|'POST',runtime:EmailRuntime,payload?:unknown,key?:string){
 const headers:Record<string,string>={Authorization:`Bearer ${config.apiKey}`};
 if(payload)headers['Content-Type']='application/json';if(key)headers['Idempotency-Key']=key;
 let response:Response;
 try{response=await fetchWithoutRedirect(`https://api.resend.com${path}`,{method,headers,body:payload?JSON.stringify(payload):undefined,signal:AbortSignal.timeout(15_000)},runtime.fetch??fetch);}
 catch{throw new AppError('EMAIL_DELIVERY_UNCONFIRMED','邮件服务响应待确认',503);}
 let result:Record<string,unknown>;try{result=await response.json() as Record<string,unknown>;}catch{throw new AppError('EMAIL_DELIVERY_UNCONFIRMED','邮件服务返回无效响应',503);}
 if(!response.ok)throw new AppError(response.status===429||response.status>=500?'EMAIL_DELIVERY_UNCONFIRMED':'EMAIL_REJECTED','邮件请求尚未被服务商接受',response.status===429||response.status>=500?503:502);
 return result;
}
/** Read-only credentials/domain check. This never sends a test email. */
export async function probeEmailConfiguration(publicConfig:unknown,secret:unknown,runtime:EmailRuntime={}):Promise<void>{
 const config={id:'probe',...parseConfiguration(publicConfig,secret)},domain=config.fromEmail.split('@')[1].toLowerCase();let after='';
 for(let page=0;page<10;page++){
  const result=await request(config,`/domains?limit=100${after?`&after=${encodeURIComponent(after)}`:''}`,'GET',runtime);
  const rows=Array.isArray(result.data)?result.data as Record<string,unknown>[]:[];
  const found=rows.find(row=>String(row.name).toLowerCase()===domain);
  if(found){assert(found.status==='verified','EMAIL_DOMAIN_UNVERIFIED','发件域名尚未通过验证',503);return;}
  if(result.has_more!==true)break;
  after=String(rows.at(-1)?.id??'');if(!after)break;
 }
 throw new AppError('EMAIL_DOMAIN_UNVERIFIED','该发件域名未在邮件服务中验证',503);
}
/** Durable, bounded sender. A retry uses the same Resend idempotency key and
 * encrypted payload. Account token lifetimes are shorter than its 24-hour key TTL. */
export async function processEmailOutbox(env:Env,runtime:EmailRuntime={}){
 const time=runtime.nowMs??Date.now(),iso=new Date(time).toISOString(),limit=Math.min(Math.max(runtime.limit??10,1),20);
 await env.DB.prepare(`UPDATE email_outbox SET state='expired',payload_ciphertext=NULL,lease_token=NULL,lease_until_ms=NULL,updated_at=?
  WHERE state IN ('queued','sending','uncertain') AND (expires_at<=? OR EXISTS(SELECT 1 FROM account_tokens t
    JOIN users u ON u.id=t.user_id WHERE t.id=email_outbox.token_id AND (t.used_at IS NOT NULL OR t.email_snapshot<>u.email)))`).bind(iso,iso).run();
 const pending=(await env.DB.prepare(`SELECT * FROM email_outbox WHERE state IN ('queued','uncertain','sending') AND expires_at>?
  AND attempts<5 AND (lease_until_ms IS NULL OR lease_until_ms<=?) ${runtime.onlyId?'AND id=?':''} ORDER BY created_at LIMIT ?`)
  .bind(...(runtime.onlyId?[iso,time,runtime.onlyId,limit]:[iso,time,limit])).all<Outbox>()).results;
 const outcomes:{id:string;state:string}[]=[];
 for(const job of pending){
  const lease=id('maillease'),claimed=await env.DB.prepare(`UPDATE email_outbox SET state='sending',attempts=attempts+1,lease_token=?,lease_until_ms=?,updated_at=?
   WHERE id=? AND state IN ('queued','uncertain','sending') AND (lease_until_ms IS NULL OR lease_until_ms<=?) AND expires_at>? AND attempts<5 RETURNING id`)
   .bind(lease,time+30_000,iso,job.id,time,iso).first();if(!claimed)continue;
  try{
   assert(job.payload_ciphertext,'EMAIL_PAYLOAD_MISSING','邮件内容已过期',503);
   const config=await loadEmailConfiguration(env,job.config_version_id);
   const payload=JSON.parse(await decryptSecret(job.payload_ciphertext,env.ENCRYPTION_KEY,job.id));
   const result=await request(config,'/emails','POST',runtime,payload,`benos:${job.id}`);
   assert(typeof result.id==='string'&&result.id.length<=200,'EMAIL_DELIVERY_UNCONFIRMED','邮件服务未返回确认编号',503);
   await env.DB.prepare("UPDATE email_outbox SET state='accepted',provider_message_id=?,payload_ciphertext=NULL,error_code=NULL,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?")
    .bind(result.id,iso,job.id,lease).run();outcomes.push({id:job.id,state:'accepted'});
  }catch(error){
   const code=error instanceof AppError?error.code:'EMAIL_DELIVERY_UNCONFIRMED';
   const state=code==='EMAIL_REJECTED'?'failed':'uncertain';
   await env.DB.prepare("UPDATE email_outbox SET state=?,error_code=?,payload_ciphertext=CASE WHEN ?='failed' THEN NULL ELSE payload_ciphertext END,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?")
    .bind(state,code,state,iso,job.id,lease).run();outcomes.push({id:job.id,state});
  }
 }
 return {processed:outcomes.length,items:outcomes};
}
