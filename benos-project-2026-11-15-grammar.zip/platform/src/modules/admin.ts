import { Hono } from 'hono';
import { z } from 'zod';
import { type App,body,ok } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole } from './auth';
import { fundProvider,settle,releaseConfirmedUnused } from './ledger';

export const adminRoutes=new Hono<App>();
adminRoutes.use('*',requireAuth,requireRole('owner','admin','support','editor'));
adminRoutes.get('/overview',requireRole('owner','admin','support'),async c=>{
 const now=new Date().toISOString();
 const [users,projects,subscriptions,integrations,reservations]=await Promise.all([
  c.env.DB.prepare('SELECT COUNT(*) AS count FROM users').first<{count:number}>(),
  c.env.DB.prepare('SELECT COUNT(*) AS count FROM projects WHERE archived_at IS NULL').first<{count:number}>(),
  c.env.DB.prepare("SELECT COUNT(*) AS count FROM subscriptions WHERE state IN ('active','cancelled') AND membership_frozen_by IS NULL AND starts_at<=? AND ends_at>?").bind(now,now).first<{count:number}>(),
  c.env.DB.prepare('SELECT id,kind,name,provider,status,test_status,tested_at FROM integration_configs ORDER BY created_at DESC').all(),
  c.env.DB.prepare("SELECT COUNT(*) AS count FROM api_reservations WHERE state IN ('reserved','dispatching','uncertain')").first<{count:number}>()
 ]);
 return ok(c,{users:users?.count??0,projects:projects?.count??0,activeSubscriptions:subscriptions?.count??0,openReservations:reservations?.count??0,integrations:integrations.results});
});
adminRoutes.get('/users',requireRole('owner','admin','support'),async c=>{
 const rows=await c.env.DB.prepare('SELECT id,email,name,role,status,email_verified_at,created_at FROM users ORDER BY created_at DESC LIMIT 100').all();return ok(c,{items:rows.results});
});
adminRoutes.get('/users/:id',requireRole('owner','admin','support'),async c=>{
 const user=await c.env.DB.prepare('SELECT id,email,name,role,status,email_verified_at,created_at FROM users WHERE id=?').bind(c.req.param('id')).first();
 assert(user,'NOT_FOUND','会员不存在',404);
 const restrictions=await c.env.DB.prepare('SELECT id,scope,reason,starts_at,ends_at,revoked_at,created_at FROM user_restrictions WHERE user_id=? ORDER BY created_at DESC').bind(c.req.param('id')).all();return ok(c,{user,restrictions:restrictions.results});
});
adminRoutes.post('/users/:id/restrictions',requireRole('owner','admin'),async c=>{
 const input=await body(c,z.object({scopes:z.array(z.enum(['login','ai','topup','publish'])).min(1).max(4),reason:z.string().trim().min(3,'请填写具体原因').max(500),endsAt:z.string().datetime().nullable().default(null)}));
 const actor=c.get('auth').user,target=c.req.param('id'),now=new Date().toISOString();
 const user=await c.env.DB.prepare('SELECT id,role FROM users WHERE id=?').bind(target).first<{id:string;role:string}>();
 assert(user,'NOT_FOUND','会员不存在',404);assert(target!==actor.id&&user.role!=='owner','PROTECTED_ACCOUNT','不能限制当前账号或平台所有者',403);
 assert(actor.role==='owner'||user.role==='user','FORBIDDEN','不能限制同级管理员',403);
 assert(!input.endsAt||input.endsAt>now,'VALIDATION','解除时间必须晚于当前时间');
 const scopes=[...new Set(input.scopes)];
 await c.env.DB.batch([...scopes.map(scope=>c.env.DB.prepare('INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,ends_at,actor_id,created_at) VALUES(?,?,?,?,?,?,?,?)').bind(id('rst'),target,scope,input.reason,now,input.endsAt,actor.id,now)),auditStatement(c.env.DB,actor.id,'member.restrict','user',target,{scopes,reason:input.reason,endsAt:input.endsAt},c.get('requestId'))]);
 return ok(c,{restricted:true,scopes},201);
});
adminRoutes.post('/users/:id/restrictions/:restriction/revoke',requireRole('owner','admin'),async c=>{
 const input=await body(c,z.object({reason:z.string().trim().min(3).max(500)})),actor=c.get('auth').user;
 const record=await c.env.DB.prepare('SELECT r.id,u.role FROM user_restrictions r JOIN users u ON u.id=r.user_id WHERE r.id=? AND r.user_id=?').bind(c.req.param('restriction'),c.req.param('id')).first<{id:string;role:string}>();
 assert(record,'NOT_FOUND','限制记录不存在',404);assert(actor.role==='owner'||record.role==='user','FORBIDDEN','不能更改同级管理员',403);
 await c.env.DB.batch([c.env.DB.prepare('UPDATE user_restrictions SET revoked_at=COALESCE(revoked_at,?) WHERE id=?').bind(new Date().toISOString(),record.id),auditStatement(c.env.DB,actor.id,'member.unrestrict','user',c.req.param('id'),{restrictionId:record.id,reason:input.reason},c.get('requestId'))]);
 return ok(c,{revoked:true});
});
adminRoutes.get('/audit',requireRole('owner','admin'),async c=>{
 const rows=await c.env.DB.prepare('SELECT id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at FROM audit_logs ORDER BY created_at DESC LIMIT 100').all();return ok(c,{items:rows.results});
});
adminRoutes.get('/budgets',requireRole('owner','admin'),async c=>{
 const [pools,reservations]=await Promise.all([c.env.DB.prepare('SELECT * FROM provider_pools').all(),c.env.DB.prepare("SELECT id,user_id,provider_id,amount_micros,actual_micros,state,created_at_ms FROM api_reservations WHERE state IN ('reserved','dispatching','uncertain') ORDER BY created_at_ms DESC LIMIT 100").all()]);return ok(c,{pools:pools.results,reservations:reservations.results});
});
adminRoutes.post('/budgets/:provider/funding',requireRole('owner'),async c=>{
 const input=await body(c,z.object({amountMicros:z.number().int().positive().max(100_000_000_000),referenceId:z.string().trim().min(3).max(200),reason:z.string().trim().min(3).max(500),confirmedProviderDeposit:z.literal(true)}).strict());
 assert(/^[a-zA-Z0-9_-]{1,100}$/.test(c.req.param('provider')),'VALIDATION','额度池名称无效');
 // The immutable request audit is recorded BEFORE funding. Retries use the same
 // external receipt reference and cannot increase the pool twice.
 await auditStatement(c.env.DB,c.get('auth').user.id,'budget.funding_requested','provider',c.req.param('provider'),{...input},c.get('requestId')).run();
 const result=await fundProvider(c.env.DB,{id:id('fund'),providerId:c.req.param('provider'),amountMicros:input.amountMicros,referenceId:input.referenceId});return ok(c,result,201);
});
adminRoutes.patch('/budgets/:provider',requireRole('owner'),async c=>{
 const input=await body(c,z.object({enabled:z.boolean(),reason:z.string().trim().min(3).max(500)}));
 const result=await c.env.DB.batch([c.env.DB.prepare('UPDATE provider_pools SET enabled=?,updated_at_ms=? WHERE provider_id=? RETURNING provider_id').bind(input.enabled?1:0,Date.now(),c.req.param('provider')),auditStatement(c.env.DB,c.get('auth').user.id,'budget.set_enabled','provider',c.req.param('provider'),input,c.get('requestId'))]);assert(result[0].results.length,'NOT_FOUND','额度池不存在',404);return ok(c,{enabled:input.enabled});
});
adminRoutes.get('/ai-jobs',requireRole('owner','admin'),async c=>{
 const rows=await c.env.DB.prepare('SELECT id,user_id,project_id,reservation_id,state,usage_json,error_code,provider_response_id,created_at FROM ai_jobs ORDER BY created_at DESC LIMIT 100').all();return ok(c,{items:rows.results});
});
adminRoutes.post('/ai-jobs/:id/reconcile',requireRole('owner'),async c=>{
 const input=await body(c,z.discriminatedUnion('outcome',[
  z.object({outcome:z.literal('confirmed_unused'),evidence:z.string().trim().min(10).max(2000)}),
  z.object({outcome:z.literal('confirmed_cost'),actualMicros:z.number().int().min(0).max(100_000_000_000),evidence:z.string().trim().min(10).max(2000)})
 ]));
 const job=await c.env.DB.prepare('SELECT id,reservation_id,state,error_code FROM ai_jobs WHERE id=?').bind(c.req.param('id')).first<{id:string;reservation_id:string|null;state:string;error_code:string|null}>();assert(job?.reservation_id,'NOT_FOUND','未找到需核对的用量记录',404);
 assert(job.state==='uncertain'||job.error_code==='COST_RECONCILED','INVALID_STATE','该任务不需要人工费用核对',409);
 await auditStatement(c.env.DB,c.get('auth').user.id,'ai.reconciliation_requested','ai_job',job.id,input,c.get('requestId')).run();
 const reservation=input.outcome==='confirmed_unused'?await releaseConfirmedUnused(c.env.DB,job.reservation_id):await settle(c.env.DB,{reservationId:job.reservation_id,actualMicros:input.actualMicros});
 await c.env.DB.prepare("UPDATE ai_jobs SET state='failed',error_code='COST_RECONCILED',updated_at=? WHERE id=?").bind(new Date().toISOString(),job.id).run();return ok(c,{reconciled:true,reservationState:reservation.state});
});
adminRoutes.on(['POST','DELETE'],'/users',()=>{throw new AppError('PROTECTED_RECORD','会员记录只能通过注册及受控权益流程创建或更正',403);});
adminRoutes.delete('/users/:id',c=>c.json({ok:false,error:{code:'PROTECTED_RECORD',message:'会员记录不能通过普通删除操作移除'}},403));
