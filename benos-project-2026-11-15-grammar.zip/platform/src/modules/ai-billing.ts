import { assert } from '../lib/errors';

/** Audited against OpenAI's model pages and prompt-caching guide on 2026-11-07.
 * https://developers.openai.com/api/docs/models/gpt-6.1-sol
 * https://developers.openai.com/api/docs/models/gpt-6-sol
 * https://developers.openai.com/api/docs/guides/prompt-caching
 * No inference about pricing/limits of unlisted model IDs or compatible APIs.
 * New providers/models require a reviewed adapter version, not a form checkbox.
 */
export const TEXT_BILLING_PROFILE='openai-gpt6-standard-2026-11-07' as const;
export const DEEPSEEK_BILLING_PROFILE='deepseek-v4-standard-2026-11-13' as const;
export const MOONSHOT_BILLING_PROFILE='moonshot-k3-standard-2026-11-13' as const;
export const TEXT_BILLING_PROFILES=[TEXT_BILLING_PROFILE,DEEPSEEK_BILLING_PROFILE,MOONSHOT_BILLING_PROFILE] as const;
export type TextProvider='openai'|'deepseek'|'moonshot';
export type TextPricing={baseUrl:string;model:string;inputMicrosPerMillion:number;cachedInputMicrosPerMillion:number;outputMicrosPerMillion:number;contextTokens:number;maxOutputTokens:number;pricingConfirmedAt:string;billingProfile?:'unverified'|typeof TEXT_BILLING_PROFILES[number];cacheTtl?:'30m'|'12h'|'automatic'|'5m'|'1h';provider?:TextProvider;protocol?:'responses'|'chat-completions';stream?:boolean};
type Profile={provider:TextProvider;context:number;output:number;inputRate:number;readRate:number;outputRate:number;references:boolean};
const profiles:Record<string,Profile>={
 'gpt-6.1-sol':{provider:'openai',context:1_050_000,output:128_000,inputRate:2_000_000,readRate:100_000,outputRate:10_000_000,references:true},
 'gpt-6-sol':{provider:'openai',context:1_050_000,output:128_000,inputRate:2_000_000,readRate:200_000,outputRate:10_000_000,references:false},
 // DeepSeek rates are the PEAK ceiling, not an assertion that every call costs peak.
 'deepseek-flash':{provider:'deepseek',context:1_048_576,output:384_000,inputRate:300_000,readRate:6_000,outputRate:1_200_000,references:true},
 'deepseek-v4-pro':{provider:'deepseek',context:1_048_576,output:384_000,inputRate:1_320_000,readRate:44_000,outputRate:3_960_000,references:false},
 // The application caps Kimi output at 128 Ki tokens, below its documented maximum.
 // K3.1 Pro is intentionally not enabled: the official public price table did
 // not expose its 1h cache-write price on 2026-11-13, and existing cache TTLs can
 // stay locked at 1h even when a later request asks for 5m. Do not invent a bound.
 'kimi-k3':{provider:'moonshot',context:1_048_576,output:131_072,inputRate:3_000_000,readRate:300_000,outputRate:15_000_000,references:true},
};
function integer(value:unknown,max=2_000_000):number{assert(Number.isSafeInteger(value)&&Number(value)>=0&&Number(value)<=max,'AI_USAGE_INVALID','模型费用尚无法确认',502);return Number(value);}
function rounded(numerator:bigint){const result=(numerator+7_999_999n)/8_000_000n;assert(result<=BigInt(Number.MAX_SAFE_INTEGER),'AI_COST_INVALID','费用超出可核算范围',502);return Number(result);}
export function textProvider(pricing:TextPricing):TextProvider{return pricing.provider??(pricing.billingProfile===DEEPSEEK_BILLING_PROFILE?'deepseek':pricing.billingProfile===MOONSHOT_BILLING_PROFILE?'moonshot':'openai');}
export function verifiedTextPricing(pricing:TextPricing,provider?:string){
 const profile=profiles[pricing.model];
 const selected=textProvider(pricing),contract={openai:{url:'https://api.openai.com/v1',profile:TEXT_BILLING_PROFILE,protocol:'responses'},deepseek:{url:'https://api.deepseek.com',profile:DEEPSEEK_BILLING_PROFILE,protocol:'responses'},moonshot:{url:'https://api.moonshot.ai/v1',profile:MOONSHOT_BILLING_PROFILE,protocol:'chat-completions'}}[selected];
 assert(contract&&(!provider||provider===selected)&&profile?.provider===selected&&pricing.baseUrl===contract.url&&pricing.billingProfile===contract.profile&&(!pricing.protocol||pricing.protocol===contract.protocol),'AI_BILLING_UNVERIFIED','文本模型的费用与调用上限尚未通过审核',503);
 assert(pricing.contextTokens===profile.context&&Number.isSafeInteger(pricing.maxOutputTokens)&&pricing.maxOutputTokens>=16&&pricing.maxOutputTokens<=profile.output,'AI_BILLING_UNVERIFIED','模型上下文或输出上限与已审核合同不一致',503);
 assert(pricing.inputMicrosPerMillion===profile.inputRate&&pricing.cachedInputMicrosPerMillion===profile.readRate&&pricing.outputMicrosPerMillion===profile.outputRate,'AI_BILLING_UNVERIFIED','模型价格与已审核计费版本不一致，请核对新版本',503);
 assert(selected==='openai'?(pricing.cacheTtl==='30m'||pricing.cacheTtl==='12h'):selected==='deepseek'?pricing.cacheTtl==='automatic':(pricing.cacheTtl==='5m'||pricing.cacheTtl==='1h'),'AI_BILLING_UNVERIFIED','缓存计费期限尚未确认',503);
 return profile;
}
/** Reserve the actual model's full input ceiling, including long-context cache
 * write rates, plus the enforced output limit. This intentionally over-reserves.
 * The token-count endpoint is NOT called: its docs do not establish a free-price
 * contract. A future tighter bound needs a proved, model-specific tokenizer and
 * exact hidden formatting accounting, or an audited metering API contract. */
export function textReservationCost(pricing:TextPricing):number{
 const model=verifiedTextPricing(pricing),writeFactor=pricing.cacheTtl==='12h'?20n:10n;
 if(model.provider!=='openai'){
  // Kimi's returned TTL may remain locked to an earlier 1h cache. Reserve its
  // audited worst write rate even when this request asks for 5m.
  const inputMultiplier=model.provider==='moonshot'?2n:1n;
  return ceilMicros(BigInt(model.context)*BigInt(model.inputRate)*inputMultiplier+BigInt(pricing.maxOutputTokens)*BigInt(model.outputRate));
 }
 return rounded(BigInt(model.context)*BigInt(pricing.inputMicrosPerMillion)*writeFactor*2n+BigInt(pricing.maxOutputTokens)*BigInt(pricing.outputMicrosPerMillion)*12n);
}
export type TextUsageEvidence={startedAtMs:number;finishedAtMs:number;cacheWrite5m?:string|null;cacheWrite1h?:string|null};
export function textUsageCost(pricing:TextPricing,usage:any,evidence?:TextUsageEvidence):number{
 const model=verifiedTextPricing(pricing);
 if(model.provider==='deepseek')return deepseekUsageCost(pricing,usage,evidence);
 if(model.provider==='moonshot')return moonshotUsageCost(pricing,usage,evidence);
 return openaiUsageCost(pricing,usage);
}
function openaiUsageCost(pricing:TextPricing,usage:any):number{
 const model=verifiedTextPricing(pricing);assert(usage&&typeof usage==='object'&&!Array.isArray(usage),'AI_USAGE_INVALID','模型缺少完整用量',502);
 const input=integer(usage.input_tokens),output=integer(usage.output_tokens),details=usage.input_tokens_details;
 assert(input<=model.context&&output<=pricing.maxOutputTokens&&input+output<=model.context,'AI_USAGE_INVALID','模型用量超过计费合同上限',502);
 assert(details&&typeof details==='object'&&!Array.isArray(details),'AI_USAGE_INVALID','输入用量明细缺失',502);
 const cached=integer(details.cached_tokens),written=integer(details.cache_write_tokens);
 assert(cached+written<=input,'AI_USAGE_INVALID','缓存读写合计超过输入用量',502);
 const lifetimes=details.cache_write_tokens_details;
 assert(written===0||(lifetimes&&typeof lifetimes==='object'),'AI_USAGE_INVALID','缓存写入期限明细缺失',502);
 const shortWrite=lifetimes?integer(lifetimes.ttl_30m_tokens):0,longWrite=lifetimes?integer(lifetimes.ttl_12h_tokens):0;
 assert(shortWrite+longWrite===written,'AI_USAGE_INVALID','缓存写入合计不一致',502);
 assert(pricing.cacheTtl==='12h'||longWrite===0,'AI_PRICING_MISMATCH','出现未请求的 12 小时缓存写入，费用待核对',502);
 if(usage.total_tokens!==undefined)assert(integer(usage.total_tokens,4_000_000)===input+output,'AI_USAGE_INVALID','模型用量合计不一致',502);
 if(usage.output_tokens_details){assert(integer(usage.output_tokens_details.reasoning_tokens)<=output,'AI_USAGE_INVALID','推理用量超出输出用量',502);for(const key of Object.keys(usage.output_tokens_details))assert(key==='reasoning_tokens','AI_USAGE_INVALID','出现未知输出计费类型',502);}
 for(const key of Object.keys(usage))assert(['input_tokens','input_tokens_details','output_tokens','output_tokens_details','total_tokens'].includes(key),'AI_USAGE_INVALID','出现未知用量计费类型',502);
 for(const key of Object.keys(details))assert(['cached_tokens','cache_write_tokens','cache_write_tokens_details'].includes(key),'AI_USAGE_INVALID','出现未知输入计费类型',502);
 if(lifetimes)for(const key of Object.keys(lifetimes))assert(['ttl_30m_tokens','ttl_12h_tokens'].includes(key),'AI_USAGE_INVALID','出现未知缓存计费期限',502);
 const ordinary=input-cached-written,longContext=input>272_000;
 const inputPart=(BigInt(ordinary)*BigInt(pricing.inputMicrosPerMillion)*8n+BigInt(cached)*BigInt(pricing.cachedInputMicrosPerMillion)*8n+BigInt(shortWrite)*BigInt(pricing.inputMicrosPerMillion)*10n+BigInt(longWrite)*BigInt(pricing.inputMicrosPerMillion)*20n)*(longContext?2n:1n);
 const outputPart=BigInt(output)*BigInt(pricing.outputMicrosPerMillion)*(longContext?12n:8n);
 return rounded(inputPart+outputPart);
}

function ceilMicros(n:bigint,divisor=1_000_000n){const amount=(n+divisor-1n)/divisor;assert(amount>=0n&&amount<=BigInt(Number.MAX_SAFE_INTEGER),'AI_COST_INVALID','费用超出可核算范围',502);return Number(amount);}
function object(value:any){assert(value&&typeof value==='object'&&!Array.isArray(value),'AI_USAGE_INVALID','供应商费用明细缺失',502);return value;}
function keys(value:any,allowed:string[]){for(const key of Object.keys(object(value)))assert(allowed.includes(key),'AI_USAGE_INVALID','出现未审核的供应商计费字段',502);}
function usageBounds(pricing:TextPricing,input:number,output:number,total:any){assert(input<=pricing.contextTokens&&output<=pricing.maxOutputTokens&&input+output<=pricing.contextTokens&&integer(total,4_000_000)===input+output,'AI_USAGE_INVALID','供应商用量与计费上限不一致',502);}
// Official holiday calendars, not locale/weekend inference. Adjusted working
// weekends stay off-peak: DeepSeek explicitly says all weekends are off-peak.
// https://www.gov.cn/zhengce/zhengceku/202511/content_7047091.htm
// https://www.gov.cn/zhengce/content/202611/content_7085101.htm
const holidays:Record<string,ReadonlyArray<[string,string]>>={
 '2026':[['01-01','01-03'],['02-15','02-23'],['04-04','04-06'],['05-01','05-05'],['06-19','06-21'],['09-25','09-27'],['10-01','10-07']],
 '2027':[['01-01','01-03'],['02-05','02-13'],['04-03','04-05'],['05-01','05-05'],['06-09','06-09'],['09-15','09-15'],['10-01','10-07']],
};
/** Returns the documented UTC time band; unsupported calendar years fail closed. */
export function deepseekPriceBand(atMs:number):'peak'|'off_peak'{
 assert(Number.isSafeInteger(atMs)&&atMs>=0,'AI_PRICING_WINDOW_UNCERTAIN','供应商计费时间尚未核验',502);
 const at=new Date(atMs),china=new Date(atMs+8*3600000),year=String(china.getUTCFullYear()),calendar=holidays[year];
 assert(calendar,'AI_PRICING_CALENDAR_UNVERIFIED','该年度供应商节假日计价日历尚未核验',503);
 const day=china.toISOString().slice(5,10),holiday=calendar.some(([from,to])=>day>=from&&day<=to),hour=at.getUTCHours(),weekend=at.getUTCDay()===0||at.getUTCDay()===6;
 return !weekend&&!holiday&&((hour>=1&&hour<4)||(hour>=6&&hour<10))?'peak':'off_peak';
}
function deepseekUsageCost(pricing:TextPricing,usage:any,evidence?:TextUsageEvidence){
 keys(usage,['input_tokens','input_tokens_details','output_tokens','output_tokens_details','total_tokens','server_tool_use']);
 const input=integer(usage.input_tokens),output=integer(usage.output_tokens),details=object(usage.input_tokens_details);keys(details,['cached_tokens']);
 const cached=integer(details.cached_tokens);assert(cached<=input,'AI_USAGE_INVALID','缓存命中超出输入用量',502);usageBounds(pricing,input,output,usage.total_tokens);
 if(usage.output_tokens_details){keys(usage.output_tokens_details,['reasoning_tokens']);assert(integer(usage.output_tokens_details.reasoning_tokens)<=output,'AI_USAGE_INVALID','推理用量超出输出',502);}
 if(usage.server_tool_use){keys(usage.server_tool_use,['tool_search','tool_fetch']);assert(integer(usage.server_tool_use.tool_search)===0&&integer(usage.server_tool_use.tool_fetch)===0,'AI_USAGE_INVALID','未授权的服务器工具费用必须人工核对',502);}
 assert(evidence&&Number.isSafeInteger(evidence.startedAtMs)&&Number.isSafeInteger(evidence.finishedAtMs)&&evidence.finishedAtMs>=evidence.startedAtMs&&evidence.finishedAtMs-evidence.startedAtMs<=300_000,'AI_PRICING_WINDOW_UNCERTAIN','缺少本次请求的可信计费时间，原预算保留',502);
 // Supplier docs do not establish how a request crossing a rate boundary is
 // attributed. Check both ends and every minute, with a 5s clock tolerance.
 const start=evidence.startedAtMs-5000,end=evidence.finishedAtMs+5000,band=deepseekPriceBand(start);
 for(let at=start;at<=end;at+=60_000)assert(deepseekPriceBand(at)===band,'AI_PRICING_WINDOW_UNCERTAIN','请求跨越供应商费率切换窗口，费用待核对',502);
 assert(deepseekPriceBand(end)===band,'AI_PRICING_WINDOW_UNCERTAIN','请求跨越供应商费率切换窗口，费用待核对',502);
 const cost=BigInt(input-cached)*BigInt(pricing.inputMicrosPerMillion)+BigInt(cached)*BigInt(pricing.cachedInputMicrosPerMillion)+BigInt(output)*BigInt(pricing.outputMicrosPerMillion);
 return ceilMicros(cost,band==='peak'?1_000_000n:2_000_000n);
}
function headerCount(value:string|null|undefined){assert(typeof value==='string'&&/^(0|[1-9][0-9]*)$/.test(value),'AI_USAGE_INVALID','缺少缓存写入期限响应头，费用待核对',502);return integer(Number(value));}
function moonshotUsageCost(pricing:TextPricing,usage:any,evidence?:TextUsageEvidence){
 keys(usage,['prompt_tokens','completion_tokens','total_tokens','cached_tokens','prompt_tokens_details','completion_tokens_details']);
 const input=integer(usage.prompt_tokens),output=integer(usage.completion_tokens),details=object(usage.prompt_tokens_details);keys(details,['cached_tokens','cache_write_tokens']);
 const cached=integer(details.cached_tokens),written=integer(details.cache_write_tokens);assert(cached+written<=input,'AI_USAGE_INVALID','缓存读写超出输入用量',502);usageBounds(pricing,input,output,usage.total_tokens);
 if(usage.cached_tokens!==undefined)assert(integer(usage.cached_tokens)===cached,'AI_USAGE_INVALID','两处缓存读用量不一致',502);
 if(usage.completion_tokens_details){keys(usage.completion_tokens_details,['reasoning_tokens']);assert(integer(usage.completion_tokens_details.reasoning_tokens)<=output,'AI_USAGE_INVALID','推理用量超出输出',502);}
 // Even a zero-write usage body must agree with any returned TTL evidence.
 // Ignoring nonzero headers in that case would silently undercharge.
 const shortWrite=written||evidence?.cacheWrite5m!=null?headerCount(evidence?.cacheWrite5m):0,longWrite=written||evidence?.cacheWrite1h!=null?headerCount(evidence?.cacheWrite1h):0;
 assert(shortWrite+longWrite===written,'AI_USAGE_INVALID','缓存写入期限合计不一致',502);
 // K3 has an explicit 1h rate. Do not extrapolate that multiplier to K3.1 Pro.
 assert(longWrite===0||pricing.model==='kimi-k3','AI_PRICING_MISMATCH','此模型的 1h 缓存写入价格尚未核验，费用待核对',502);
 return ceilMicros(BigInt(input-cached-written+shortWrite)*BigInt(pricing.inputMicrosPerMillion)+BigInt(longWrite)*6_000_000n+BigInt(cached)*BigInt(pricing.cachedInputMicrosPerMillion)+BigInt(output)*BigInt(pricing.outputMicrosPerMillion));
}

/** A metered estimate for a call that was sent but whose usage receipt never arrived (the stream broke or timed
 * out): the token counts are approximations made by the caller from what was sent and what had streamed back.
 * Used only to close such a call at once instead of holding the customer's credit; never for a call with a receipt. */
export function estimatedTextCost(pricing:TextPricing,tokens:{input:number;cachedInput:number;output:number}):number{
 verifiedTextPricing(pricing);const count=(value:number)=>BigInt(Math.max(0,Math.min(4_000_000,Math.ceil(Number(value)||0))));
 return ceilMicros(count(tokens.input)*BigInt(pricing.inputMicrosPerMillion)+count(tokens.cachedInput)*BigInt(pricing.cachedInputMicrosPerMillion)+count(tokens.output)*BigInt(pricing.outputMicrosPerMillion));
}
