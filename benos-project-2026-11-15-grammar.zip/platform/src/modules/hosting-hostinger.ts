import { z } from 'zod';
import type { Env } from '../env';
import { AppError,assert } from '../lib/errors';
import { decryptSecret,encryptSecret,randomToken,sha256 } from '../lib/crypto';

// Audited against Hostinger's official PHP SDK HTTP contract on 2026-11-07.
// The SDK endpoint list is not proof that a particular customer's plan permits
// these operations. Never provision through a configurable arbitrary API origin.
const ORIGIN='https://developers.hostinger.com';
export const hpanelConfiguration=z.object({
 adapter:z.literal('hostinger-hpanel'),deploymentMode:z.enum(['registered-php-bridge','hostinger-tus-bootstrap']),
 hostingOrderId:z.number().int().positive().safe(),accountUsername:z.string().regex(/^u[0-9]{3,20}$/),
}).passthrough();
export type HpanelConfiguration=z.infer<typeof hpanelConfiguration>;
type Intent={job_id:string;config_version_id:string;site_id:string;domain:string;account_username:string;hosting_order_id:number;website_create_attempted:number;website_ready:number;database_name:string;database_user:string;database_secret_ciphertext:string;database_create_attempted:number;database_ready:number;root_directory:string|null;required_dns_txt:string|null;created_at:string;next_poll_at:string|null};
export type HpanelResult={ready:boolean;state?:'pending'|'awaiting_input'|'uncertain';step?:string;errorCode?:string;requiredDnsTxt?:string;deployment?:{mode:'hostinger-hpanel';accountUsername:string;rootDirectory:string};database?:{accountUsername:string;name:string;user:string;password:string}};

async function provider(token:string,method:'GET'|'POST',path:string,payload?:unknown):Promise<unknown>{
 assert(typeof token==='string'&&token.length>=16&&!/[\r\n]/.test(token),'HOSTINGER_TOKEN_REQUIRED','托管供应商凭据尚未配置',503);
 assert(path.startsWith('/api/hosting/v1/')&&!path.includes('..')&&!path.includes('\\'),'HOSTINGER_PATH_INVALID','托管供应商路径无效',503);
 let response:Response;
 try{response=await fetch(ORIGIN+path,{method,headers:{Authorization:'Bearer '+token,Accept:'application/json',...(method==='POST'?{'Content-Type':'application/json'}:{})},body:method==='POST'?JSON.stringify(payload):undefined,redirect:'manual',signal:AbortSignal.timeout(12000)});}
 catch{throw new AppError('HOSTINGER_RESULT_UNCERTAIN','托管供应商结果尚未确认，请稍后继续核验',502);}
 if(response.status<200||response.status>=300){
   const code=response.status===401||response.status===403?'HOSTINGER_AUTH_REQUIRED':response.status===429?'HOSTINGER_RATE_LIMITED':response.status===409?'HOSTINGER_NOT_READY':response.status>=500?'HOSTINGER_RESULT_UNCERTAIN':'HOSTINGER_REQUEST_REJECTED';
   throw new AppError(code,'托管供应商暂未完成请求，请检查配置或稍后继续',502);
 }
 assert(Number(response.headers.get('content-length')||0)<=2*1024*1024,'HOSTINGER_RESPONSE_INVALID','托管供应商响应过大',502);
 const raw=await response.text();assert(raw.length<=2*1024*1024,'HOSTINGER_RESPONSE_INVALID','托管供应商响应过大',502);
 if(!raw)return {};
 try{return JSON.parse(raw);}catch{throw new AppError('HOSTINGER_RESPONSE_INVALID','托管供应商响应格式无效',502);}
}
function record(value:unknown):Record<string,unknown>{assert(value!==null&&typeof value==='object'&&!Array.isArray(value),'HOSTINGER_RESPONSE_INVALID','托管供应商响应格式无效',502);return value as Record<string,unknown>;}
function array(value:unknown):Record<string,unknown>[]{const result=Array.isArray(value)?value:record(value).data;assert(Array.isArray(result)&&result.every(row=>row&&typeof row==='object'&&!Array.isArray(row)),'HOSTINGER_RESPONSE_INVALID','托管供应商列表无效',502);return result as Record<string,unknown>[];}
function value(row:Record<string,unknown>,snake:string,camel:string){return row[snake]??row[camel];}
export { provider as hpanelRequest };
/** Website lists are paginated on current hPanel. Old array responses remain
 * accepted, but never silently treat the first page of an envelope as complete. */
export async function listHpanelWebsites(token:string):Promise<Record<string,unknown>[]>{
 const rows:Record<string,unknown>[]=[];
 for(let page=1;page<=1000;page++){
   const result=await provider(token,'GET',`/api/hosting/v1/websites?page=${page}&per_page=100`);
   if(Array.isArray(result)){assert(page===1,'HOSTINGER_RESPONSE_INVALID','网站分页响应发生变化',502);return array(result);}
   const response=record(result),items=array(response),meta=record(response.meta);rows.push(...items);
   const total=Number(meta.total),current=Number(value(meta,'current_page','currentPage')),perPage=Number(value(meta,'per_page','perPage'));
   assert(Number.isSafeInteger(total)&&total>=0&&current===page&&Number.isSafeInteger(perPage)&&perPage>0&&perPage<=1000,'HOSTINGER_RESPONSE_INVALID','网站分页信息无效',502);
   if(current*perPage>=total)return rows;
   assert(items.length>0,'HOSTINGER_RESPONSE_INVALID','网站分页信息不完整',502);
 }
 throw new AppError('HOSTINGER_RESPONSE_INVALID','网站列表超过安全读取范围',502);
}
const websites=listHpanelWebsites;
/** Read only, scoped inventory. Counts are observations, never a purchase or a
 * promise that resources cannot be consumed outside Benos after this read. */
export async function inspectHpanelInventory(config:HpanelConfiguration,token:string){
 const all=await websites(token);
 const scoped=all.filter(row=>row.username===config.accountUsername&&Number(value(row,'order_id','orderId'))===config.hostingOrderId);
 assert(scoped.length>0,'HOSTINGER_ACCOUNT_SCOPE_INVALID','主机订单与账号未通过官方列表核对',503);
 const domains=scoped.map(row=>String(row.domain||'').toLowerCase());
 const rows=await databases(token,config.accountUsername),names=rows.map(row=>String(row.name||''));
 assert(domains.every(name=>name.length>0&&name.length<=253)&&names.every(name=>name.length>0&&name.length<=190),'HOSTINGER_RESPONSE_INVALID','托管资源清单不完整',502);
 return {domains:[...new Set(domains)],databases:[...new Set(names)]};
}
export async function testHpanelConfiguration(config:HpanelConfiguration,token:string):Promise<void>{
 const rows=await websites(token);
 assert(rows.some(row=>row.username===config.accountUsername&&Number(value(row,'order_id','orderId'))===config.hostingOrderId),'HOSTINGER_ACCOUNT_SCOPE_INVALID','主机订单与账号未通过官方列表核对',503);
 await databases(token,config.accountUsername);
}
async function databases(token:string,username:string):Promise<Record<string,unknown>[]>{
 const rows:Record<string,unknown>[]=[];
 for(let page=1;page<=1000;page++){
   const response=record(await provider(token,'GET',`/api/hosting/v1/accounts/${encodeURIComponent(username)}/databases?page=${page}&per_page=100`));
   const items=array(response),meta=record(response.meta);rows.push(...items);
   const total=Number(meta.total),current=Number(value(meta,'current_page','currentPage')),perPage=Number(value(meta,'per_page','perPage'));
   assert(Number.isSafeInteger(total)&&total>=0&&current===page&&Number.isSafeInteger(perPage)&&perPage>0&&perPage<=1000,'HOSTINGER_RESPONSE_INVALID','数据库分页信息无效',502);
   if(current*perPage>=total)return rows;
   assert(items.length>0,'HOSTINGER_RESPONSE_INVALID','数据库分页信息不完整',502);
 }
 throw new AppError('HOSTINGER_RESPONSE_INVALID','数据库列表超过安全读取范围',502);
}
async function pollLater(env:Env,jobId:string){await env.DB.prepare('UPDATE hosting_provider_intents SET next_poll_at=?,updated_at=? WHERE job_id=?').bind(new Date(Date.now()+15000).toISOString(),new Date().toISOString(),jobId).run();}

/** One durable step per call; retries reconcile exact persisted names first. */
export async function ensureHpanelResources(env:Env,configId:string,config:HpanelConfiguration,token:string,job:{id:string;siteId:string;domain:string}):Promise<HpanelResult>{
 assert(!job.domain.startsWith('www.'),'HOSTINGER_DOMAIN_UNSUPPORTED','请先用网站主域创建托管，www 别名需随后单独绑定');
 let intent=await env.DB.prepare('SELECT * FROM hosting_provider_intents WHERE job_id=?').bind(job.id).first<Intent>();
 if(!intent){
   const suffix=(await sha256(job.siteId)).slice(0,Math.min(14,30-config.accountUsername.length));
   const name=config.accountUsername+'_b'+suffix,password=randomToken(32),now=new Date().toISOString();
   const encrypted=await encryptSecret(password,env.ENCRYPTION_KEY,'hosting-database:'+job.id);
   await env.DB.prepare('INSERT INTO hosting_provider_intents(job_id,config_version_id,site_id,domain,account_username,hosting_order_id,database_name,database_user,database_secret_ciphertext,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(job_id) DO NOTHING').bind(job.id,configId,job.siteId,job.domain,config.accountUsername,config.hostingOrderId,name,name,encrypted,now,now).run();
   intent=await env.DB.prepare('SELECT * FROM hosting_provider_intents WHERE job_id=?').bind(job.id).first<Intent>();
 }
 assert(intent&&intent.site_id===job.siteId&&intent.domain===job.domain&&intent.config_version_id===configId&&intent.account_username===config.accountUsername&&intent.hosting_order_id===config.hostingOrderId,'HOSTINGER_INTENT_CONFLICT','托管任务的原始账号范围已变化，已停止以免创建重复资源',409);
 if(intent.next_poll_at&&intent.next_poll_at>new Date().toISOString())return {ready:false,state:'pending',step:'wait_provider_setup'};
 // Ownership verification is a separate gate from DNS pointing and TLS. Its TXT
 // challenge is safe to show the owner; no token/account/server address is shown.
 if(!intent.website_ready){
   const ownership=record(await provider(token,'POST','/api/hosting/v1/domains/verify-ownership',{domain:job.domain}));
   const verified=value(ownership,'is_accessible','isAccessible');
   assert(ownership.domain===job.domain&&typeof verified==='boolean','HOSTINGER_RESPONSE_INVALID','域名归属响应无效',502);
   if(!verified){
     const txt=String(value(ownership,'txt_to_verify','txtToVerify')||'');assert(txt.length<=4096,'HOSTINGER_RESPONSE_INVALID','域名验证信息无效',502);
     await env.DB.prepare('UPDATE hosting_provider_intents SET required_dns_txt=?,updated_at=? WHERE job_id=?').bind(txt,new Date().toISOString(),job.id).run();
     return {ready:false,state:'awaiting_input',step:'verify_domain_ownership',errorCode:'DOMAIN_OWNERSHIP_REQUIRED',requiredDnsTxt:txt};
   }
   const rows=await websites(token),found=rows.find(row=>row.domain===job.domain);
   if(found){
     assert(intent.website_create_attempted===1,'HOSTINGER_WEBSITE_EXISTS','域名已存在网站，不能自动覆盖或接管',409);
     assert(found.username===config.accountUsername&&Number(value(found,'order_id','orderId'))===config.hostingOrderId,'HOSTINGER_ACCOUNT_SCOPE_INVALID','网站所属主机账号与任务不符',409);
   }
   const setups=array(await provider(token,'GET',`/api/hosting/v1/onboardings?order_id=${config.hostingOrderId}&domain=${encodeURIComponent(job.domain)}`));
   const setup=setups.find(row=>row.domain===job.domain&&row.username===config.accountUsername&&typeof value(row,'created_at','createdAt')==='string'&&Date.parse(String(value(row,'created_at','createdAt')))>=Date.parse(intent!.created_at)-60000);
   if(!intent.website_create_attempted){
     assert(!found&&!setup,'HOSTINGER_WEBSITE_EXISTS','域名已有建站任务，不能重复创建',409);
     await env.DB.prepare('UPDATE hosting_provider_intents SET website_create_attempted=1,updated_at=? WHERE job_id=? AND website_create_attempted=0').bind(new Date().toISOString(),job.id).run();
     await provider(token,'POST',`/api/hosting/v1/orders/${config.hostingOrderId}/onboardings`,{domain:job.domain});
     await pollLater(env,job.id);return {ready:false,state:'pending',step:'wait_website_setup'};
   }
   if(setup?.status==='failed')return {ready:false,state:'awaiting_input',step:'review_website_setup',errorCode:'HOSTINGER_SETUP_FAILED'};
   if(setup?.status!=='completed'||!found){
     await pollLater(env,job.id);
     return {ready:false,state:setup?.status==='running'?'pending':'uncertain',step:'wait_website_setup',errorCode:setup?.status==='running'?undefined:'HOSTINGER_RESULT_UNCERTAIN'};
   }
   const root=String(value(found,'root_directory','rootDirectory')||'');
   if(config.deploymentMode!=='hostinger-tus-bootstrap')assert(root.startsWith('/')&&!root.includes('\0')&&!root.includes('..')&&root.length<1000,'HOSTINGER_ROOT_UNAVAILABLE','此主机未返回可用的网站目录，需先配置受控部署桥',409);
   await env.DB.prepare('UPDATE hosting_provider_intents SET website_ready=1,root_directory=?,required_dns_txt=NULL,next_poll_at=NULL,updated_at=? WHERE job_id=?').bind(root,new Date().toISOString(),job.id).run();
   intent.website_ready=1;intent.root_directory=root;
 }
 const rows=await databases(token,config.accountUsername),found=rows.find(row=>row.name===intent!.database_name||row.user===intent!.database_user);
 if(found){
   assert(intent.database_create_attempted===1&&found.name===intent.database_name&&found.user===intent.database_user&&found.domain===job.domain,'HOSTINGER_DATABASE_CONFLICT','数据库身份或归属与原始任务不符',409);
   await env.DB.prepare('UPDATE hosting_provider_intents SET database_ready=1,next_poll_at=NULL,updated_at=? WHERE job_id=?').bind(new Date().toISOString(),job.id).run();
 }else{
   if(intent.database_create_attempted)return {ready:false,state:'uncertain',step:'reconcile_database',errorCode:'HOSTINGER_DATABASE_UNCERTAIN'};
   const password=await decryptSecret(intent.database_secret_ciphertext,env.ENCRYPTION_KEY,'hosting-database:'+job.id);
   await env.DB.prepare('UPDATE hosting_provider_intents SET database_create_attempted=1,updated_at=? WHERE job_id=? AND database_create_attempted=0').bind(new Date().toISOString(),job.id).run();
   await provider(token,'POST',`/api/hosting/v1/accounts/${encodeURIComponent(config.accountUsername)}/databases`,{name:intent.database_name,user:intent.database_user,password,website_domain:job.domain});
   await pollLater(env,job.id);return {ready:false,state:'pending',step:'verify_created_database'};
 }
 return {ready:true,deployment:{mode:'hostinger-hpanel',accountUsername:config.accountUsername,rootDirectory:intent.root_directory!},database:{accountUsername:config.accountUsername,name:intent.database_name,user:intent.database_user,password:await decryptSecret(intent.database_secret_ciphertext,env.ENCRYPTION_KEY,'hosting-database:'+job.id)}};
}
