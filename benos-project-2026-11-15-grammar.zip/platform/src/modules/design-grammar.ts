import { Hono, type Context } from 'hono';
import { z } from 'zod';
import { body, ok, type App } from '../lib/http';
import { sha256 } from '../lib/crypto';
import { requireAuth, requireRole } from './auth';
import { compilePage } from '../design-system/grammar/compile';
import { compileSite } from '../design-system/grammar/site';
import { compileGrammarManifest } from '../design-system/grammar/manifest';
import { bindingFrames } from '../design-system/grammar/frames';
import { grammarRepairBrief } from '../design-system/grammar/generation';
import { GRAMMAR_SPEC } from '../design-system/grammar/spec';
import { GRAMMAR_VERSION } from '../design-system/grammar/brand';
import { GRAMMAR_IDENTITY } from '../design-system/grammar/identity';
import { assertGrammarApproved, brandRangeIssues, findGrammarApproval, grammarApprovalInputSchema, readGrammarApprovals, recordGrammarApproval } from '../lib/grammar-approvals';

/** The bnl-0 layout grammar, owner only. This route is the owner's workshop: it compiles documents the
 *  owner hands in, shows the page, and records the approval the production path requires. It never
 *  spends credit, writes a site or publishes one. */
export const designGrammarRoutes = new Hono<App>();
designGrammarRoutes.use('*', requireAuth, requireRole('owner'));

const escape = (value: string) => value.replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]!));
const privateHeaders = (c: Context<App>) => {
  c.header('Cache-Control', 'private, no-store');
  c.header('X-Robots-Tag', 'noindex, nofollow');
  c.header('X-Content-Type-Options', 'nosniff');
  c.header('Referrer-Policy', 'no-referrer');
};
/** One page, rendered in a sandbox exactly like the v2 review preview: no scripts, no requests out. */
function pagePreview(c: Context<App>, html: string, css: string, title: string, lang: string) {
  privateHeaders(c);
  c.header('X-Frame-Options', 'SAMEORIGIN');
  c.header('Content-Security-Policy', "sandbox allow-same-origin; default-src 'none'; script-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; font-src 'none'; connect-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'");
  return c.html(`<!doctype html><html lang="${escape(lang)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)}</title><style>html{scroll-behavior:auto}body{margin:0}${css.replace(/<\/style/gi, '<\\/style')}</style></head><body>${html}</body></html>`);
}
const assetSchema = z.object({ id: z.string().min(1).max(60), src: z.string().min(1).max(400), w: z.number().int().positive(), h: z.number().int().positive(), alt: z.string().max(200).default('') }).strict();
const elementSchema: z.ZodType<Record<string, unknown>> = z.record(z.string(), z.unknown());
const sectionSchema = z.object({ id: z.string().min(1).max(24), tone: z.string().optional(), space: z.string().optional(), gap: z.number().int().min(0).max(9).optional(), body: z.array(elementSchema).min(1).max(40) }).strict();
const docSchema = z.object({ lang: z.string().max(20).optional(), title: z.string().max(120).optional(), brand: z.record(z.string(), z.unknown()), sections: z.array(sectionSchema).min(1).max(10), images: z.array(assetSchema).optional() }).strict();
const imagesOf = (input: { images?: Array<{ id: string; src: string; w: number; h: number; alt: string }> }) =>
  Object.fromEntries((input.images ?? []).map(asset => [asset.id, { src: asset.src, w: asset.w, h: asset.h, alt: asset.alt }]));

/** Compiles a document and returns the page as JSON, so an admin page can render it without a blob. */
designGrammarRoutes.post('/compile', async c => {
  const input = await body(c, docSchema);
  privateHeaders(c);
  const images = imagesOf(input);
  const result = compilePage({ lang: input.lang, title: input.title, brand: input.brand as never, sections: input.sections as never, images }, { images, scope: 'preview' });
  return ok(c, {
    ok: result.ok, version: GRAMMAR_VERSION, issues: result.issues,
    brief: result.ok ? null : grammarRepairBrief(result.issues),
    html: result.ok ? result.body : '',
    css: result.ok ? result.sharedCss + result.pageCss : '',
    stats: { sections: result.stats.sections, nodes: result.stats.nodes, cssBytes: result.stats.cssBytes, forms: result.stats.forms },
  });
});

designGrammarRoutes.get('/spec', c => {
  privateHeaders(c);
  return ok(c, { version: GRAMMAR_VERSION, spec: GRAMMAR_SPEC, identity: GRAMMAR_IDENTITY });
});

designGrammarRoutes.post('/preview', async c => {
  const input = await body(c, docSchema);
  const result = compilePage({ lang: input.lang, title: input.title, brand: input.brand as never, sections: input.sections as never, images: imagesOf(input) }, { images: imagesOf(input), scope: 'preview' });
  if (!result.ok) return c.json({ error: 'GRAMMAR_DOCUMENT_INVALID', issues: result.issues, brief: grammarRepairBrief(result.issues) }, 422);
  return pagePreview(c, result.body, result.sharedCss + result.pageCss, input.title || 'bnl-0', input.lang || 'en');
});

/** Compiles a whole site. `production: true` is the only path to a shippable package, and it needs an
 *  approval that matches this exact grammar identity plus a brand inside the approved ranges. */
designGrammarRoutes.post('/site', async c => {
  const input = await body(c, z.object({
    lang: z.string().max(20).optional(),
    brand: z.record(z.string(), z.unknown()),
    images: z.array(assetSchema).optional(),
    pages: z.array(z.object({ key: z.string().min(1).max(32), path: z.string().min(1).max(64), title: z.string().min(1).max(120), sections: z.array(sectionSchema).min(1).max(10) }).strict()).min(1).max(12),
    production: z.boolean().default(false),
    name: z.string().min(1).max(120).optional(),
    slug: z.string().regex(/^[a-z0-9][a-z0-9-]{1,99}$/).optional(),
    createdAt: z.string().min(10).max(40).optional(),
  }).strict());
  privateHeaders(c);
  const images = imagesOf(input);
  const site = compileSite({ lang: input.lang, brand: input.brand as never, pages: input.pages as never, images }, {});
  if (!input.production) {
    return ok(c, {
      ok: site.ok, version: GRAMMAR_VERSION, sharedCssBytes: site.sharedCss.length, issues: site.issues,
      brief: site.ok ? null : grammarRepairBrief(site.issues),
      pages: site.pages.map(page => ({ key: page.key, path: page.path, title: page.title, ok: page.ok, html: page.body, css: page.css, cssBytes: page.stats.cssBytes, frames: page.frames.map(frame => frame.frameId), issues: page.issues })),
    });
  }
  if (!site.ok) return c.json({ error: 'GRAMMAR_SITE_INVALID', issues: site.issues, brief: grammarRepairBrief(site.issues) }, 422);
  const approvals = await readGrammarApprovals(c.env.DB);
  const approval = assertGrammarApproved(approvals);
  const rangeIssues = brandRangeIssues(input.brand as never, approval.brandRanges);
  if (rangeIssues.length) return c.json({ error: 'GRAMMAR_BRAND_OUTSIDE_RANGE', issues: rangeIssues, approved: approval.brandRanges }, 422);
  const built = compileGrammarManifest(
    { lang: input.lang, brand: input.brand as never, pages: input.pages as never, images },
    { name: input.name ?? 'Untitled site', slug: input.slug ?? 'untitled-site', createdAt: input.createdAt },
  );
  if (!built.ok) return c.json({ error: 'GRAMMAR_PACKAGE_INVALID', issues: built.issues }, 422);
  const frames = bindingFrames(site, { containerWidth: (input.brand as any)?.space?.container });
  return ok(c, {
    ok: true, version: GRAMMAR_VERSION, identity: GRAMMAR_IDENTITY.digest, approval: { reviewerId: approval.reviewerId, reviewedAt: approval.reviewedAt, grammarDigest: approval.grammarDigest },
    manifest: built.manifest, manifestDigest: await sha256(JSON.stringify(built.manifest)), pages: built.pages, frames: frames.frames, issues: [...built.issues, ...frames.issues],
  });
});

/** The approval ledger for the running grammar identity. */
designGrammarRoutes.get('/approvals', async c => {
  privateHeaders(c);
  const approvals = await readGrammarApprovals(c.env.DB);
  const current = findGrammarApproval(approvals);
  return ok(c, {
    identity: GRAMMAR_IDENTITY,
    approved: !!current,
    current: current ?? null,
    rows: approvals.map(approval => ({ ...approval, matchesRunningGrammar: approval.grammarDigest === GRAMMAR_IDENTITY.digest && approval.specDigest === GRAMMAR_IDENTITY.spec && approval.exemplarDigest === GRAMMAR_IDENTITY.exemplar })),
  });
});

designGrammarRoutes.post('/approve', async c => {
  privateHeaders(c);
  const input = await body(c, grammarApprovalInputSchema);
  const user = c.get('auth').user;
  const recorded = await recordGrammarApproval(c.env, user.id, input);
  return ok(c, { ...recorded, identity: GRAMMAR_IDENTITY });
});
