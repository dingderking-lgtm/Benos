import { z } from 'zod';
import type { Env,User } from '../env';
import { assert,AppError } from '../lib/errors';
import { id,sha256 } from '../lib/crypto';
import { loadPaymentConfiguration,stripeRequest,type PaymentRuntime } from './payments';

export const entitlementAdjustmentSchema=z.object({direction:z.enum(['revoke','restore']),targetKind:z.enum(['subscription','annual']),targetId:z.string().min(1).max(200),parentId:z.string().min(1).max(200).optional(),cancelRenewal:z.boolean(),confirmRenewalContinues:z.boolean(),reason:z.string().trim().min(3).max(500),evidence:z.string().trim().min(10).max(2000),requestKey:z.string().min(8).max(128),expectedRevision:z.number().int().positive(),confirmImpact:z.literal(true)}).strict().superRefine((v,c)=>{
 if((v.direction==='restore')!==!!v.parentId)c.addIssue({code:'custom',message:'恢复必须关联原撤销操作'});
 if(v.direction==='revoke'&&v.targetKind==='subscription'){if(v.cancelRenewal&&v.confirmRenewalContinues)c.addIssue({code:'custom',message:'取消续费与保留自动续费不能同时选择'});}
 else if(v.cancelRenewal||v.confirmRenewalContinues)c.addIssue({code:'custom',message:'此操作不能更改自动续费'});
});
type Input=z.infer<typeof entitlementAdjustmentSchema>;
type Operation={id:string;case_id:string;order_id:string;user_id:string;actor_id:string;direction:'revoke'|'restore';target_kind:'subscription'|'annual';target_id:string;parent_id:string|null;original_state:string;cancel_renewal:number;state:string;agreement_id:string|null;error_code:string|null;};
type Agreement={id:string;user_id:string;origin_order_id:string;config_version_id:string;provider_subscription_id:string;state:string;cancel_requested:number;};
const record=(v:unknown)=>v!==null&&typeof v==='object'&&!Array.isArray(v)?v as Record<string,unknown>:{};
const objectId=(v:unknown)=>typeof v==='string'?v:String(record(v).id??'');
function operationView(o:Operation){return {id:o.id,direction:o.direction,targetKind:o.target_kind,targetId:o.target_id,parentId:o.parent_id,state:o.state,errorCode:o.error_code,cancelRenewal:!!o.cancel_renewal};}
export async function caseEntitlements(env:Env,caseId:string){
 const row=await env.DB.prepare('SELECT f.order_id,o.kind,o.provider,COALESCE(o.payment_agreement_id,(SELECT a.id FROM payment_agreements a WHERE a.origin_order_id=o.id AND a.user_id=o.user_id)) AS payment_agreement_id FROM financial_cases f LEFT JOIN orders o ON o.id=f.order_id WHERE f.id=?').bind(caseId).first<{order_id:string|null;kind:string|null;provider:string|null;payment_agreement_id:string|null}>();assert(row,'NOT_FOUND','审核记录不存在',404);
 const [subscriptions,annual,operations,agreement]=await Promise.all([
  env.DB.prepare("SELECT id,'subscription' AS kind,state,starts_at AS startsAt,ends_at AS endsAt,tier,financial_revoked_by AS revocationId,membership_frozen_by IS NOT NULL AS membershipFrozen FROM subscriptions WHERE order_id=?").bind(row.order_id).all(),
  env.DB.prepare("SELECT id,'annual' AS kind,state,starts_at AS startsAt,ends_at AS endsAt,site_id AS siteId,financial_revoked_by AS revocationId FROM hosting_entitlements WHERE order_id=? AND source='annual'").bind(row.order_id).all(),
  env.DB.prepare('SELECT id,direction,target_kind AS targetKind,target_id AS targetId,parent_id AS parentId,state,error_code AS errorCode,cancel_renewal AS cancelRenewal,reason,evidence,created_at AS createdAt FROM financial_entitlement_operations WHERE case_id=? ORDER BY created_at DESC').bind(caseId).all(),
  env.DB.prepare('SELECT id,state,cancel_requested FROM payment_agreements WHERE id=?').bind(row.payment_agreement_id).first<{id:string;state:string;cancel_requested:number}>(),
 ]);
 return {items:[...subscriptions.results,...annual.results],operations:operations.results,renewal:{agreementId:agreement?.id??null,state:row.kind==='subscription'?(row.provider==='alipay'?'manual':agreement?.state??'unknown'):'not_applicable',cancelRequested:!!agreement?.cancel_requested}};
}
async function resolveAgreement(env:Env,operation:Operation,runtime:PaymentRuntime){
 const order=await env.DB.prepare('SELECT COALESCE(o.payment_agreement_id,(SELECT a.id FROM payment_agreements a WHERE a.origin_order_id=o.id AND a.user_id=o.user_id)) AS payment_agreement_id,o.payment_id,o.config_version_id FROM orders o WHERE o.id=? AND o.user_id=?').bind(operation.order_id,operation.user_id).first<{payment_agreement_id:string|null;payment_id:string|null;config_version_id:string}>();assert(order,'ORDER_NOT_FOUND','原订单不存在',409);
 let agreementId=order.payment_agreement_id;
 if(!agreementId){
  assert(/^stripe:in_[A-Za-z0-9_]+$/.test(order.payment_id??''),'RENEWAL_UNCONFIRMED','原账期的续费关联尚未确认',503);
  const config=await loadPaymentConfiguration(env,order.config_version_id),invoiceId=order.payment_id!.slice(7),invoice=await stripeRequest(config,`/v1/invoices/${invoiceId}`,'GET',undefined,undefined,runtime),details=record(record(invoice.parent).subscription_details),metadata=record(details.metadata);
  assert(objectId(invoice.id)===invoiceId&&invoice.livemode===(config.mode==='live'),'RENEWAL_UNCONFIRMED','原发票环境尚未确认',503);
  const agreement=await env.DB.prepare('SELECT * FROM payment_agreements WHERE provider_subscription_id=? AND user_id=? AND config_version_id=?').bind(objectId(details.subscription),operation.user_id,config.id).first<Agreement>();
  assert(agreement&&metadata.benos_order_id===agreement.origin_order_id&&metadata.benos_user_id===operation.user_id&&metadata.benos_config_id===config.id,'RENEWAL_UNCONFIRMED','原账期的订阅归属尚未确认',503);agreementId=agreement.id;
  await env.DB.prepare('UPDATE orders SET payment_agreement_id=? WHERE id=? AND payment_agreement_id IS NULL').bind(agreementId,operation.order_id).run();
 }
 const agreement=await env.DB.prepare('SELECT * FROM payment_agreements WHERE id=? AND user_id=?').bind(agreementId,operation.user_id).first<Agreement>();assert(agreement,'RENEWAL_UNCONFIRMED','原订阅不存在',503);
 await env.DB.prepare('UPDATE orders SET payment_agreement_id=? WHERE id=? AND (payment_agreement_id IS NULL OR payment_agreement_id=?)').bind(agreement.id,operation.order_id,agreement.id).run();return agreement;
}
/** The optional cancellation is a durable separate provider step. Unknown
 * responses leave this exact entitlement active until confirmation succeeds. */
async function confirmCancellation(env:Env,operation:Operation,runtime:PaymentRuntime){
 const agreement=await resolveAgreement(env,operation,runtime),config=await loadPaymentConfiguration(env,agreement.config_version_id),subId=agreement.provider_subscription_id,time=new Date(runtime.nowMs??Date.now()).toISOString();
 assert(/^sub_[A-Za-z0-9_]+$/.test(subId),'RENEWAL_UNCONFIRMED','原订阅标识无效',503);
 await env.DB.batch([env.DB.prepare('UPDATE financial_entitlement_operations SET agreement_id=? WHERE id=?').bind(agreement.id,operation.id),env.DB.prepare('UPDATE payment_agreements SET cancel_requested=1,updated_at=? WHERE id=?').bind(time,agreement.id)]);
 let subscription=await stripeRequest(config,`/v1/subscriptions/${subId}`,'GET',undefined,undefined,runtime);
 const validate=()=>assert(objectId(subscription.id)===subId&&subscription.livemode===(config.mode==='live'),'CANCELLATION_UNCONFIRMED','续费取消结果尚未确认',503);validate();
 if(subscription.status!=='canceled'&&subscription.cancel_at_period_end!==true){subscription=await stripeRequest(config,`/v1/subscriptions/${subId}`,'POST',new URLSearchParams({cancel_at_period_end:'true'}),`benos:case-cancel:${operation.id}`,runtime);validate();}
 assert(subscription.status==='canceled'||subscription.cancel_at_period_end===true,'CANCELLATION_UNCONFIRMED','续费取消结果尚未确认',503);
 await env.DB.batch([
  env.DB.prepare('UPDATE payment_agreements SET state=?,updated_at=? WHERE id=?').bind(subscription.status==='canceled'?'cancelled':'cancel_scheduled',time,agreement.id),
  // Existing paid intervals remain valid. Only renewal display changes for this agreement.
  env.DB.prepare('UPDATE subscriptions SET auto_renew=0 WHERE order_id IN(SELECT id FROM orders WHERE payment_agreement_id=?)').bind(agreement.id),
  env.DB.prepare("UPDATE financial_entitlement_operations SET state='pending_local_change',error_code=NULL WHERE id=? AND state='pending_billing_change'").bind(operation.id),
 ]);
}
export async function resumeEntitlementOperation(env:Env,caseId:string,operationId:string,actor:User,runtime:PaymentRuntime={}){
 assert(actor.role==='owner','FORBIDDEN','只有平台所有者可以调整订单权益',403);
 let operation=await env.DB.prepare('SELECT * FROM financial_entitlement_operations WHERE id=? AND case_id=?').bind(operationId,caseId).first<Operation>();assert(operation,'NOT_FOUND','权益调整记录不存在',404);
 if(operation.state==='completed')return operationView(operation);
 if(operation.state==='pending_billing_change'){
  try{await confirmCancellation(env,operation,runtime);}catch(error){const code=error instanceof AppError?error.code:'RENEWAL_UNCONFIRMED';await env.DB.prepare('UPDATE financial_entitlement_operations SET error_code=? WHERE id=? AND state<>\'completed\'').bind(code,operation.id).run();return operationView({...operation,error_code:code});}
 }
 operation=(await env.DB.prepare('SELECT * FROM financial_entitlement_operations WHERE id=?').bind(operation.id).first<Operation>())!;
 const table=operation.target_kind==='subscription'?'subscriptions':'hosting_entitlements',time=new Date(runtime.nowMs??Date.now()).toISOString(),guard=id('entitlement_guard');
 const stmt=(sql:string,...values:(string|number|null)[])=>env.DB.prepare(sql).bind(...values),pending="EXISTS(SELECT 1 FROM financial_entitlement_operations WHERE id=?1 AND state='pending_local_change')";
 const statements=[stmt(`INSERT INTO mutation_guards(id,permitted) SELECT ?2,CASE WHEN NOT ${pending} OR EXISTS(SELECT 1 FROM ${table} t WHERE t.id=?3 AND t.order_id=?4 AND t.user_id=?5
  ${operation.target_kind==='subscription'?'AND t.membership_frozen_by IS NULL':''}
  AND EXISTS(SELECT 1 FROM users WHERE id=?6 AND role='owner')
  AND ((?7='revoke' AND t.state<>'revoked' AND t.financial_revoked_by IS NULL AND EXISTS(SELECT 1 FROM financial_entitlement_claims l WHERE l.target_kind=?8 AND l.target_id=t.id AND l.operation_id=?1))
   OR (?7='restore' AND t.state='revoked' AND t.financial_revoked_by=?9 AND EXISTS(SELECT 1 FROM financial_entitlement_claims l WHERE l.target_kind=?8 AND l.target_id=t.id AND l.operation_id=?9)))) THEN 1 ELSE 0 END`,operation.id,guard,operation.target_id,operation.order_id,operation.user_id,actor.id,operation.direction,operation.target_kind,operation.parent_id)];
 if(operation.direction==='revoke'){
  statements.push(stmt(`UPDATE ${table} SET state='revoked',financial_revoked_by=?1 WHERE id=?2 AND ${pending}`,operation.id,operation.target_id));
  if(operation.target_kind==='subscription')statements.push(stmt(`UPDATE credit_grants SET entitlement_revoked_by=?1 WHERE source='subscription' AND user_id=?2 AND reference_id=(SELECT grant_reference_id FROM subscriptions WHERE id=?3) AND ${pending}`,operation.id,operation.user_id,operation.target_id));
 }else{
  statements.push(stmt(`UPDATE ${table} SET state=${operation.target_kind==='subscription'?"CASE WHEN auto_renew=0 AND ?3='active' THEN 'cancelled' ELSE ?3 END":'?3'},financial_revoked_by=NULL WHERE id=?2 AND ${pending}`,operation.id,operation.target_id,operation.original_state));
  if(operation.target_kind==='subscription')statements.push(stmt(`UPDATE credit_grants SET entitlement_revoked_by=NULL WHERE entitlement_revoked_by=?2 AND ${pending}`,operation.id,operation.parent_id));
  statements.push(stmt(`DELETE FROM financial_entitlement_claims WHERE operation_id=?2 AND ${pending}`,operation.id,operation.parent_id));
 }
 statements.push(stmt(`UPDATE financial_cases SET revision=revision+1,updated_at=?2 WHERE id=?3 AND ${pending}`,operation.id,time,caseId),stmt(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?2,?3,'payment.entitlement.completed','financial_case',?4,?5,?1,?6 WHERE ${pending}`,operation.id,id('audit'),actor.id,caseId,JSON.stringify({operationId:operation.id,direction:operation.direction,targetKind:operation.target_kind,targetId:operation.target_id}),time),stmt("UPDATE financial_entitlement_operations SET state='completed',error_code=NULL,completed_at=? WHERE id=? AND state='pending_local_change'",time,operation.id),stmt('DELETE FROM mutation_guards WHERE id=?',guard));
 try{await env.DB.batch(statements);}catch(error){if(String(error).includes('mutation_revision_ok')){await env.DB.prepare("UPDATE financial_entitlement_operations SET error_code='ENTITLEMENT_CHANGED' WHERE id=? AND state<>'completed'").bind(operation.id).run();return operationView({...operation,error_code:'ENTITLEMENT_CHANGED'});}throw error;}
 return operationView((await env.DB.prepare('SELECT * FROM financial_entitlement_operations WHERE id=?').bind(operation.id).first<Operation>())!);
}
export async function adjustCaseEntitlement(env:Env,caseId:string,actor:User,input:Input,runtime:PaymentRuntime={}){
 assert(actor.role==='owner','FORBIDDEN','只有平台所有者可以调整订单权益',403);input=entitlementAdjustmentSchema.parse(input);
 const row=await env.DB.prepare('SELECT order_id,user_id FROM financial_cases WHERE id=?').bind(caseId).first<{order_id:string|null;user_id:string|null}>();assert(row?.order_id&&row.user_id,'CASE_UNMAPPED','尚未确认原订单归属',409);
 if(input.direction==='revoke'&&input.targetKind==='subscription'){
  const order=await env.DB.prepare('SELECT provider FROM orders WHERE id=?').bind(row.order_id).first<{provider:string}>();
  if(order?.provider==='alipay')assert(!input.cancelRenewal&&!input.confirmRenewalContinues,'VALIDATION','支付宝按月单次购买没有自动扣款协议，不需要取消或保留自动续费');
  else assert(input.cancelRenewal!==input.confirmRenewalContinues,'VALIDATION','请明确选择取消续费，或确认保留后续自动续费');
 }
 const hash=await sha256(JSON.stringify({caseId,...input})),prior=await env.DB.prepare('SELECT id,payload_hash FROM financial_entitlement_operations WHERE actor_id=? AND request_key=?').bind(actor.id,input.requestKey).first<{id:string;payload_hash:string}>();
 if(prior){assert(prior.payload_hash===hash,'IDEMPOTENCY_CONFLICT','请求标识已用于其他权益调整',409);return resumeEntitlementOperation(env,caseId,prior.id,actor,runtime);}
 const table=input.targetKind==='subscription'?'subscriptions':'hosting_entitlements',target=await env.DB.prepare(`SELECT state,financial_revoked_by FROM ${table} WHERE id=? AND order_id=? AND user_id=? ${input.targetKind==='annual'?"AND source='annual'":''}`).bind(input.targetId,row.order_id,row.user_id).first<{state:string;financial_revoked_by:string|null}>();assert(target,'ENTITLEMENT_NOT_FOUND','此权益不属于原订单',404);
 const parent=input.parentId?await env.DB.prepare("SELECT original_state FROM financial_entitlement_operations WHERE id=? AND case_id=? AND target_kind=? AND target_id=? AND direction='revoke' AND state='completed'").bind(input.parentId,caseId,input.targetKind,input.targetId).first<{original_state:string}>():null;
 assert(input.direction!=='restore'||parent,'RESTORATION_INVALID','未找到此订单已完成的原撤销操作',409);
 const operationId=id('entitlement'),nonce=id('attempt'),guard=id('entitlement_guard'),time=new Date(runtime.nowMs??Date.now()).toISOString(),stmt=(sql:string,...values:(string|number|null)[])=>env.DB.prepare(sql).bind(...values),fresh='EXISTS(SELECT 1 FROM financial_entitlement_operations WHERE id=?1 AND attempt_nonce=?2)';
 const statements=[stmt(`INSERT INTO financial_entitlement_operations(id,case_id,order_id,user_id,actor_id,direction,target_kind,target_id,parent_id,original_state,request_key,payload_hash,attempt_nonce,cancel_renewal,renewal_continues_confirmed,state,reason,evidence,created_at)
  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(actor_id,request_key) DO UPDATE SET payload_hash=CASE WHEN financial_entitlement_operations.payload_hash=excluded.payload_hash THEN financial_entitlement_operations.payload_hash ELSE NULL END`,operationId,caseId,row.order_id,row.user_id,actor.id,input.direction,input.targetKind,input.targetId,input.parentId??null,parent?.original_state??target.state,input.requestKey,hash,nonce,input.cancelRenewal?1:0,input.confirmRenewalContinues?1:0,input.cancelRenewal?'pending_billing_change':'pending_local_change',input.reason,input.evidence,time),
 stmt(`INSERT INTO mutation_guards(id,permitted) SELECT ?3,CASE WHEN NOT ${fresh} OR EXISTS(SELECT 1 FROM financial_cases f JOIN ${table} t ON t.order_id=f.order_id AND t.user_id=f.user_id WHERE f.id=?4 AND f.revision=?5 AND t.id=?6
 ${input.targetKind==='subscription'?'AND t.membership_frozen_by IS NULL':"AND t.source='annual'"}
 AND EXISTS(SELECT 1 FROM users WHERE id=?7 AND role='owner') AND ((?8='revoke' AND t.state<>'revoked' AND t.financial_revoked_by IS NULL AND ((f.kind='refund' AND f.provider_state='succeeded') OR (f.kind='dispute' AND f.provider_state='lost')))
 OR (?8='restore' AND t.financial_revoked_by=?9 AND t.state='revoked'))) THEN 1 ELSE 0 END`,operationId,nonce,guard,caseId,input.expectedRevision,input.targetId,actor.id,input.direction,input.parentId??null)];
 if(input.direction==='revoke')statements.push(stmt(`INSERT INTO financial_entitlement_claims(target_kind,target_id,operation_id) SELECT ?3,?4,?1 WHERE ${fresh}`,operationId,nonce,input.targetKind,input.targetId));
 statements.push(stmt(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?3,?4,'payment.entitlement.requested','financial_case',?5,?6,?7,?8 WHERE ${fresh}`,operationId,nonce,id('audit'),actor.id,caseId,JSON.stringify(input),input.requestKey,time),stmt('DELETE FROM mutation_guards WHERE id=?',guard));
 try{await env.DB.batch(statements);}catch(error){if(String(error).includes('financial_entitlement_operations.payload_hash'))throw new AppError('IDEMPOTENCY_CONFLICT','请求标识已用于其他权益调整',409);if(/mutation_revision_ok|financial_entitlement_claims|financial_entitlement_operations.parent_id/.test(String(error)))throw new AppError('ENTITLEMENT_CHANGED','权益或案件已变化、仍在冻结计时，或已有待处理调整；请刷新核对',409);throw error;}
 const actual=await env.DB.prepare('SELECT id FROM financial_entitlement_operations WHERE actor_id=? AND request_key=?').bind(actor.id,input.requestKey).first<{id:string}>();return resumeEntitlementOperation(env,caseId,actual!.id,actor,runtime);
}
