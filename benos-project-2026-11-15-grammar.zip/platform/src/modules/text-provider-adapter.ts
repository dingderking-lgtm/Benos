import { assert,AppError } from '../lib/errors';
import { boundedBytes } from './media';
import { textProvider,verifiedTextPricing,textUsageCost,deepseekPriceBand,type TextPricing,type TextUsageEvidence } from './ai-billing';
import type { StreamProgress } from '../lib/workflow-progress';

/** Reviewed protocol boundaries: see docs/TEXT-PROVIDERS.md. No automatic retry.
 * Raw supplier usage stays supplier-specific even though output is projected to
 * the existing Responses-shaped design engine. Never expose private reasoning. */
const MAX_JSON_BYTES=600_000,MAX_STREAM_BYTES=2_400_000;
// A stream is many times larger than the result it carries: every few characters arrive wrapped in their own event,
// the finished pieces are repeated, and the last event holds the whole response again. Its total size therefore says
// nothing about the size of the result — a page of ordinary length once crossed the old 2.4 MB total and the step was
// lost. What is bounded is each single event (nothing larger is ever held in memory) and, far above any real response,
// the stream as a whole.
const MAX_STREAM_TOTAL_BYTES=96*1024*1024;
type CanonicalRequest=Record<string,any>;
export function textSupportsReferences(pricing:TextPricing){return verifiedTextPricing(pricing).references;}
function object(value:any,message='供应商响应结构无效'){assert(value&&typeof value==='object'&&!Array.isArray(value),'AI_RESPONSE_INVALID',message,502);return value;}
function containsImages(value:any):boolean{if(!value||typeof value!=='object')return false;if(value.type==='input_image'||value.type==='image_url')return true;return Object.values(value).some(v=>Array.isArray(v)?v.some(containsImages):containsImages(v));}
function chatContent(content:any):any{
 if(typeof content==='string')return content;
 assert(Array.isArray(content),'AI_REQUEST_INVALID','对话内容格式无效');
 return content.map(part=>{
  if(part?.type==='input_text'||part?.type==='output_text')return {type:'text',text:part.text};
  if(part?.type==='input_image'){assert(typeof part.image_url==='string'&&part.image_url.startsWith('data:image/'),'AI_REQUEST_INVALID','参考图必须使用已核验的私有素材');return {type:'image_url',image_url:{url:part.image_url}};}
  throw new AppError('AI_REQUEST_INVALID','此提供方不支持当前输入类型');
 });
}
function chatMessages(request:CanonicalRequest){
 const messages:any[]=[];if(request.instructions)messages.push({role:'system',content:String(request.instructions)});
 const input=typeof request.input==='string'?[{role:'user',content:request.input}]:request.input;
 assert(Array.isArray(input),'AI_REQUEST_INVALID','模型输入缺失');const replayedCalls=new Set<string>();
 for(const item of input){
  if(item?._provider_message){const original=object(item._provider_message);assert(original.role==='assistant','AI_REQUEST_INVALID','历史模型消息归属无效');messages.push(original);for(const call of original.tool_calls??[])replayedCalls.add(call.id);continue;}
  if(item?.type==='function_call'){
   if(replayedCalls.has(item.call_id))continue;
   let last=messages.at(-1);if(last?.role!=='assistant'){last={role:'assistant',content:null,tool_calls:[]};messages.push(last);}
   (last.tool_calls??=[]).push({id:item.call_id,type:'function',function:{name:item.name,arguments:item.arguments}});continue;
  }
  if(item?.type==='function_call_output'){messages.push({role:'tool',tool_call_id:item.call_id,content:typeof item.output==='string'?item.output:JSON.stringify(item.output)});continue;}
  assert(['system','user','assistant','developer'].includes(item?.role),'AI_REQUEST_INVALID','当前模型不能重放此历史输入类型');
  messages.push({role:item.role==='developer'?'system':item.role,content:chatContent(item.content)});
 }
 return messages;
}
export function buildTextProviderRequest(pricing:TextPricing,request:CanonicalRequest):{url:string;body:Record<string,any>}{
 verifiedTextPricing(pricing);const provider=textProvider(pricing);
 // Do not dispatch work that cannot possibly be metered with the audited
 // calendar. Cross-window uncertainty during an already sent request is held.
 if(provider==='deepseek')deepseekPriceBand(Date.now());
 assert(!containsImages(request.input)||textSupportsReferences(pricing),'VISION_BILLING_UNVERIFIED','所选模型不支持参考图；请移除参考图或选择支持图片的模型',422);
 if(request.tools)assert(Array.isArray(request.tools)&&request.tools.every((t:any)=>t.type==='function'),'AI_REQUEST_INVALID','仅开放本地函数工具，禁止额外计费的供应商工具');
 const stream=pricing.stream??false;
 if(provider==='openai')return {url:pricing.baseUrl+'/responses',body:{...request,model:pricing.model,max_output_tokens:pricing.maxOutputTokens,stream}};
 // DeepSeek thinking models reject a forced tool choice, so the requirement travels in the instructions.
 if(provider==='deepseek')return {url:pricing.baseUrl+'/responses',body:{model:pricing.model,input:request.input,...(request.instructions?{instructions:request.instructions}:{}),...(request.tools?{tools:request.tools,tool_choice:'auto'}:{}),...(request.text?{text:request.text}:{}),max_output_tokens:pricing.maxOutputTokens,reasoning:{effort:request.tools?'low':'none'},stream}};
 return {url:pricing.baseUrl+'/chat/completions',body:{model:pricing.model,messages:chatMessages(request),max_completion_tokens:pricing.maxOutputTokens,reasoning_effort:'low',stream,...(stream?{stream_options:{include_usage:true}}:{}),prompt_cache_options:{mode:'implicit',ttl:pricing.cacheTtl},...(request.prompt_cache_key?{prompt_cache_key:request.prompt_cache_key}:{}),...(request.tools?{tools:request.tools.map((t:any)=>({type:'function',function:{name:t.name,description:t.description,parameters:t.parameters,strict:t.strict??false}})),tool_choice:request.tool_choice??'required'}:{}),...(request.text?.format?{response_format:request.text.format}:{} )}};
}

function normalizeChat(raw:any){
 object(raw);const choices=raw.choices;
 assert(Array.isArray(choices)&&choices.length===1,'AI_RESPONSE_INVALID','模型未返回唯一结果',502);
 const choice=choices[0],message=object(choice.message),output:any[]=[];
 assert(message.role==='assistant'&&(message.content===null||message.content===undefined||typeof message.content==='string'),'AI_RESPONSE_INVALID','模型回复格式无效',502);
 // Keep the complete original assistant message to replay preserved thinking and
 // tool IDs. It is private metadata; publicOutput reads only output_text below.
 output.push({type:'message',role:'assistant',content:typeof message.content==='string'?[{type:'output_text',text:message.content}]:[],_provider_message:message});
 if(message.tool_calls!==undefined){assert(Array.isArray(message.tool_calls),'AI_RESPONSE_INVALID','工具调用格式无效',502);for(const call of message.tool_calls){assert(call?.type==='function'&&typeof call.id==='string'&&typeof call.function?.name==='string'&&typeof call.function?.arguments==='string','AI_RESPONSE_INVALID','工具调用字段缺失',502);output.push({type:'function_call',call_id:call.id,name:call.function.name,arguments:call.function.arguments});}}
 return {id:raw.id,model:raw.model,object:'response',status:['stop','tool_calls'].includes(choice.finish_reason)?'completed':'incomplete',output,usage:raw.usage,_provider_finish_reason:choice.finish_reason,_provider_created:raw.created};
}
/** Bounded SSE consumption. Deltas are never executable and are never used for
 * billing: only a terminal response/usage receipt can settle the reservation. */
async function readStream(response:Response,pricing:TextPricing,maxBytes=MAX_STREAM_BYTES,onProgress?:(progress:StreamProgress)=>void,onActivity?:()=>void){
 // Display material for the waiting customer only (lib/workflow-progress.ts): a listener can never fail the read.
 const progress:StreamProgress={text:'',calls:[]},callByIndex=new Map<number,{name:string;arguments:string}>();
 const report=()=>{try{onProgress?.(progress);}catch{/* display only */}};
 assert(response.body,'AI_RESPONSE_INVALID','模型没有返回响应内容',502);
 const reader=response.body.getReader(),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:false});let buffer='',bytes=0,eventLines:string[]=[],terminal:any=null,done=false,lastSequence=-1;
 const chat={id:null as any,model:null as any,created:null as any,object:'chat.completion',choices:[{index:0,message:{role:'assistant',content:'',reasoning_content:'',tool_calls:[] as any[]},finish_reason:null as any}],usage:null as any};
 function event(){
  const data=eventLines.filter(l=>l.startsWith('data:')).map(l=>l.slice(5).replace(/^ /,'')).join('\n');eventLines=[];if(!data)return;
  assert(!done,'AI_RESPONSE_INVALID','终态后出现额外模型事件',502);
  if(data==='[DONE]'){assert(textProvider(pricing)==='moonshot'&&chat.usage&&chat.choices[0].finish_reason,'AI_PROVIDER_UNCERTAIN','流式结果缺少最终用量，原预算保留',502);done=true;terminal=chat;return;}
  let value:any;try{value=JSON.parse(data);}catch{throw new AppError('AI_RESPONSE_INVALID','模型流事件格式无效',502);}object(value);
  if(textProvider(pricing)!=='moonshot'){
   if(value.sequence_number!==undefined){assert(Number.isSafeInteger(value.sequence_number)&&value.sequence_number>lastSequence,'AI_RESPONSE_INVALID','模型流序号无效',502);lastSequence=value.sequence_number;}
   if(onProgress){
    if(value.type==='response.output_text.delta'&&typeof value.delta==='string'){progress.text+=value.delta;report();}
    else if(value.type==='response.output_item.added'&&value.item?.type==='function_call'&&typeof value.item.name==='string'){const call={name:value.item.name,arguments:''};callByIndex.set(Number(value.output_index),call);progress.calls.push(call);report();}
    else if(value.type==='response.function_call_arguments.delta'&&typeof value.delta==='string'){const call=callByIndex.get(Number(value.output_index));if(call){call.arguments+=value.delta;report();}}
   }
   if(['response.completed','response.incomplete','response.failed'].includes(value.type)){assert(!terminal,'AI_RESPONSE_INVALID','重复终态模型事件',502);terminal=object(value.response);done=true;}
   else assert(value.type!=='error','AI_PROVIDER_UNCERTAIN','供应商流式调用失败，原预算保留',502);
   return;
  }
  assert(value.object==='chat.completion.chunk'&&typeof value.id==='string'&&typeof value.model==='string','AI_RESPONSE_INVALID','模型流块格式无效',502);
  if(chat.id===null){chat.id=value.id;chat.model=value.model;chat.created=value.created;}else assert(chat.id===value.id&&chat.model===value.model,'AI_RESPONSE_INVALID','流式响应来源变化',502);
  if(value.usage){assert(chat.usage===null,'AI_RESPONSE_INVALID','重复流式用量收据',502);chat.usage=value.usage;}
  assert(Array.isArray(value.choices)&&value.choices.length<=1,'AI_RESPONSE_INVALID','流式模型返回多结果',502);
  for(const choice of value.choices){assert(choice.index===0,'AI_RESPONSE_INVALID','流式结果索引无效',502);const delta=choice.delta??{},target=chat.choices[0];if(choice.finish_reason!==null&&choice.finish_reason!==undefined){assert(!target.finish_reason,'AI_RESPONSE_INVALID','重复流式结束标记',502);target.finish_reason=choice.finish_reason;}
   if(delta.role!==undefined)assert(delta.role==='assistant','AI_RESPONSE_INVALID','流式消息角色无效',502);
   for(const key of ['content','reasoning_content'] as const)if(delta[key]!==undefined&&delta[key]!==null){assert(typeof delta[key]==='string','AI_RESPONSE_INVALID','流式文本无效',502);target.message[key]+=delta[key];}
   for(const call of delta.tool_calls??[]){assert(Number.isInteger(call.index)&&call.index>=0&&call.index<8,'AI_RESPONSE_INVALID','流式工具数量超出范围',502);let item=target.message.tool_calls[call.index];if(!item){item={id:'',type:'function',function:{name:'',arguments:''}};target.message.tool_calls[call.index]=item;}if(call.id){assert(!item.id||item.id===call.id,'AI_RESPONSE_INVALID','流式工具编号变化',502);item.id=call.id;}if(call.type)assert(call.type==='function','AI_RESPONSE_INVALID','未开放的模型工具',502);if(call.function?.name)item.function.name+=call.function.name;if(call.function?.arguments)item.function.arguments+=call.function.arguments;}
  }
  if(onProgress){progress.text=chat.choices[0].message.content;progress.calls=chat.choices[0].message.tool_calls.filter(Boolean).map((call:any)=>({name:call.function.name,arguments:call.function.arguments}));report();}
 }
 let pending=0;
 try{while(true){const part=await reader.read();if(part.done)break;bytes+=part.value.byteLength;assert(bytes<=MAX_STREAM_TOTAL_BYTES,'AI_RESPONSE_TOO_LARGE','模型流超过安全读取上限',502);try{onActivity?.();}catch{/* housekeeping only */}buffer+=decoder.decode(part.value,{stream:true});let at:number;while((at=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,at).replace(/\r$/,'');buffer=buffer.slice(at+1);if(line===''){pending=0;event();}else if(!line.startsWith(':')){pending+=line.length;assert(pending<=maxBytes,'AI_RESPONSE_TOO_LARGE','模型流中的单个事件超过安全读取上限',502);eventLines.push(line);}}
   assert(buffer.length<=maxBytes,'AI_RESPONSE_TOO_LARGE','模型流中的单个事件超过安全读取上限',502);}
  buffer+=decoder.decode();if(buffer)eventLines.push(buffer.replace(/\r$/,''));if(eventLines.length)event();
  assert(done&&terminal,'AI_PROVIDER_UNCERTAIN','流式响应中断或最终费用缺失，原预算保留',502);return terminal;
 }catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
}
export async function readTextProviderResponse(response:Response,pricing:TextPricing,startedAtMs:number,options:{maxJsonBytes?:number;onProgress?:(progress:StreamProgress)=>void;onActivity?:()=>void}={}):Promise<any>{
 const maxJsonBytes=options.maxJsonBytes??MAX_JSON_BYTES;assert(Number.isSafeInteger(maxJsonBytes)&&maxJsonBytes>=1&&maxJsonBytes<=3*1024*1024,'AI_RESPONSE_LIMIT_INVALID','模型响应读取限制无效',500);
 let raw:any;
 if((response.headers.get('content-type')??'').toLowerCase().includes('text/event-stream'))raw=await readStream(response,pricing,maxJsonBytes*4,options.onProgress,options.onActivity);
 else{const bytes=await boundedBytes(response.body,maxJsonBytes);try{raw=JSON.parse(new TextDecoder('utf-8',{fatal:true,ignoreBOM:false}).decode(bytes));}catch{throw new AppError('AI_RESPONSE_INVALID','模型响应不是有效 JSON',502);}}
 object(raw);const result=textProvider(pricing)==='moonshot'?normalizeChat(raw):raw;
 const evidence:TextUsageEvidence={startedAtMs,finishedAtMs:Date.now(),cacheWrite5m:response.headers.get('Msh-Usage-Cache-Write-Tokens-5m'),cacheWrite1h:response.headers.get('Msh-Usage-Cache-Write-Tokens-1h')};
 return {...result,_benosMetering:evidence};
}
export function assertTextProviderResponse(pricing:TextPricing,result:any){
 verifiedTextPricing(pricing);object(result);
 assert(typeof result.id==='string'&&/^[A-Za-z0-9_-]{1,200}$/.test(result.id),'AI_RESPONSE_INVALID','模型缺少有效费用核对编号',502);
 assert(result.model===pricing.model&&(result.service_tier===undefined||result.service_tier==='default'),'AI_PRICING_MISMATCH','返回模型或服务档与已核验计费不一致',502);
 assert(Array.isArray(result.output)&&['completed','incomplete','failed'].includes(result.status),'AI_RESPONSE_INVALID','模型缺少终态结果',502);
}
export function textProviderUsageCost(pricing:TextPricing,result:any){return textUsageCost(pricing,result.usage,result._benosMetering);}
