import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { id,sha256,decryptSecret } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,enforceScope,rateLimit } from './auth';
import { reserve,claimReservation,settle,markUncertain,LedgerError,getWallet,settleEstimatedImage,correctEstimatedImage,releaseConfirmedUnused } from './ledger';
import { imageEstimatedCost,IMAGE_ESTIMATION_POLICY,type ImageEstimateSnapshot } from './image-estimated-cost';
import { boundedBytes,ownedMediaProject,saveMedia } from './media';
import { assertIntegrationCapability } from './integration-tests';
import { imageConfigSchema,meteredImageContract,imageReservationCost,imageResponseUsage,imageResponseBytes,createImageRequest,type ImagePricing,type FixtureImageContract,type ImageContract } from '../lib/image-billing';
import { IMAGE_SIZES,IMAGE_SLOT_PROMPT_RESERVE_BYTES,imageSlotSchema,imageLayout,imagePromptForSlot,type ImageSlotInput,type ImageSize } from '../lib/image-layout';
export { imageConfigSchema,imageReservationCost,imageUsageCost,type ImagePricing,type FixtureImageContract } from '../lib/image-billing';

export type ImageRuntime={fetch?:typeof fetch;fixtureContract?:FixtureImageContract};
type ImageJob={id:string;user_id:string;project_id:string;config_version_id:string;request_key:string;request_hash:string;reservation_id:string|null;state:string;request_json:string;pricing_json:string;response_json:string|null;usage_json:string|null;response_object_key:string|null;response_sha256:string|null;provider_request_id:string|null;result_media_id:string|null;error_code:string|null;created_at:string;updated_at:string};
type ConfigRow={id:string;name:string;provider:string;public_config_json:string;secret_ciphertext:string|null};
const MAX_RESPONSE_BYTES=17*1024*1024;
function auditedContract(env:Env,pricing:ImagePricing,runtime:ImageRuntime):ImageContract{
 const contract=runtime.fixtureContract;
 if(env.APP_ENV==='test'&&typeof runtime.fetch==='function'&&contract?.version==='fixture-v1'){
  assert(pricing.model===contract.model&&pricing.size===contract.size&&pricing.quality===contract.quality&&pricing.complexity===contract.complexity,'IMAGE_BOUND_UNVERIFIED','图片生成尚未启用',503);
  assert([contract.maxPromptBytes,contract.maxInputTextTokens,contract.maxOutputImageTokens].every(n=>Number.isSafeInteger(n)&&n>0&&n<=2_000_000)&&contract.maxInputImageTokens===0&&contract.maxPromptBytes<=128000,'IMAGE_BOUND_UNVERIFIED','计费合同不完整',503);
  return contract;
 }
 return meteredImageContract(pricing);
}
function json(bytes:Uint8Array):any{try{return JSON.parse(new TextDecoder().decode(bytes));}catch{throw new AppError('IMAGE_RESPONSE_INVALID','图片响应格式无效',502);}}
function evidenceKey(job:ImageJob){return 'private/image-jobs/'+encodeURIComponent(job.user_id)+'/'+job.id+'/response.json';}
async function getJob(env:Env,userId:string,jobId:string){const row=await env.DB.prepare('SELECT * FROM image_jobs WHERE id=? AND user_id=?').bind(jobId,userId).first<ImageJob>();assert(row,'NOT_FOUND','图片任务不存在',404);return row;}
export function imageJobView(job:ImageJob){let layout=null;try{layout=JSON.parse(job.request_json).layout??null;}catch{/* Legacy records may omit optional layout metadata. */}return {id:job.id,projectId:job.project_id,configId:job.config_version_id,requestKey:job.request_key,state:job.state,mediaId:job.result_media_id,errorCode:job.error_code,reservationId:job.reservation_id,layout,createdAt:job.created_at,updatedAt:job.updated_at};}
async function resolveImageConfiguration(env:Env,configId?:string):Promise<ConfigRow>{
 assert(configId===undefined||/^[A-Za-z0-9_-]{1,120}$/.test(configId),'IMAGE_CONFIG_UNAVAILABLE','所选图片模型不可用',409);
 const row=await env.DB.prepare(`SELECT id,name,provider,public_config_json,secret_ciphertext FROM integration_configs WHERE kind='image' AND deleted_at IS NULL AND status='active' AND test_status='passed' ${configId!==undefined?'AND id=?':''} ORDER BY created_at DESC,id DESC LIMIT 1`).bind(...(configId!==undefined?[configId]:[])).first<ConfigRow>();
 assert(row,configId===undefined?'IMAGE_NOT_CONFIGURED':'IMAGE_CONFIG_UNAVAILABLE',configId===undefined?'图片生成尚未启用':'所选图片模型已停用，请重新选择',503);
 return row;
}
function configPricing(row:ConfigRow):ImagePricing{
 try{return imageConfigSchema.parse(JSON.parse(row.public_config_json));}catch{throw new AppError('IMAGE_CONFIG_INVALID','图片配置无效',503);}
}
async function imagePoolAvailability(env:Env,providerPoolId:string,required:number){
 const pool=await env.DB.prepare('SELECT enabled,funded_micros-consumed_micros-reserved_micros-safety_micros available FROM provider_pools WHERE provider_id=?').bind(providerPoolId).first<{enabled:number;available:number}>();
 const available=pool?.enabled!==0;
 return {available,reason:available?null:'PROVIDER_UNAVAILABLE'};
}
async function configurationAvailability(env:Env,row:ConfigRow,quality?:'low'|'medium'){
 assert(env.BUCKET,'MEDIA_NOT_CONFIGURED','素材存储尚未配置',503);
 const configured=configPricing(row),pricing=quality?{...configured,quality}:configured,contract=meteredImageContract(pricing);
 assert(row.provider==='openai'&&row.secret_ciphertext,'IMAGE_NOT_CONFIGURED','图片服务密钥尚未配置',503);
 await assertIntegrationCapability(env.DB,row.id,'image');
 const requiredReservationMicros=imageReservationCost(pricing,contract),pool=await imagePoolAvailability(env,pricing.providerPoolId,requiredReservationMicros);
 return {...pool,configId:row.id,label:row.name,provider:row.provider,model:pricing.model,quality:pricing.quality,requiredReservationMicros,reservationIsEstimate:true as const,maxPromptBytes:contract.maxPromptBytes,slotPromptReserveBytes:IMAGE_SLOT_PROMPT_RESERVE_BYTES,supportedSizes:IMAGE_SIZES,configuredSize:pricing.size,basis:'metered-operating-reserve' as const};
}
export async function imageGenerationQuote(env:Env,userId:string,configId?:string,quality?:'low'|'medium'){
 try{const row=await resolveImageConfiguration(env,configId),quote=await configurationAvailability(env,row,quality),wallet=await getWallet(env.DB,userId),configured=configPricing(row),estimate=await imageEstimatedCost(env.DB,quality?{...configured,quality}:configured,quote.requiredReservationMicros);return {...quote,estimatedMicrosForPlanning:estimate.estimatedMicros,availableMicros:wallet.availableMicros,canReserve:quote.available&&wallet.availableMicros>=quote.requiredReservationMicros};}
 catch(error){return {available:false as const,canReserve:false,reason:error instanceof AppError?error.code:'IMAGE_CONFIG_INVALID',reservationIsEstimate:true as const};}
}
export async function listImageModels(env:Env,userId:string){
 const rows=await env.DB.prepare("SELECT id,name,provider,public_config_json,secret_ciphertext FROM integration_configs WHERE kind='image' AND deleted_at IS NULL AND status='active' AND test_status='passed' ORDER BY created_at DESC,id DESC").all<ConfigRow>(),wallet=await getWallet(env.DB,userId);
 const items=await Promise.all(rows.results.map(async row=>{
  try{const quote=await configurationAvailability(env,row);return {...quote,canReserve:quote.available&&wallet.availableMicros>=quote.requiredReservationMicros};}
  catch(error){let model:string|null=null;try{model=configPricing(row).model;}catch{}return {configId:row.id,label:row.name,provider:row.provider,model,available:false,canReserve:false,reason:error instanceof AppError?error.code:'IMAGE_CONFIG_INVALID',requiredReservationMicros:null,reservationIsEstimate:true as const};}
 }));
 return {items,defaultConfigId:items.find(item=>item.available)?.configId??null};
}
export async function imageAvailability(env:Env){
 if(!env.BUCKET)return {available:false,reason:'MEDIA_NOT_CONFIGURED'};
 try{const quote=await configurationAvailability(env,await resolveImageConfiguration(env));return {available:quote.available,reason:quote.reason};}
 catch(error){return {available:false,reason:error instanceof AppError?error.code:'IMAGE_CONFIG_INVALID'};}
}
async function finishEvidence(env:Env,job:ImageJob,bytes:Uint8Array,contract:ImageContract){
 assert(env.BUCKET&&job.reservation_id,'IMAGE_RECOVERY_UNAVAILABLE','图片任务尚无可核对记录',409);
 const pricing=imageConfigSchema.parse(JSON.parse(job.pricing_json)),result=json(bytes),digest=await sha256(bytes);
 assert(!job.response_sha256||job.response_sha256===digest,'IMAGE_EVIDENCE_CORRUPT','图片原始响应校验失败',503);
 const {actualMicros:actual,metadata}=imageResponseUsage(pricing,result,contract);
 await env.DB.prepare('UPDATE image_jobs SET response_object_key=?,response_sha256=?,response_json=?,usage_json=?,updated_at=? WHERE id=?').bind(evidenceKey(job),digest,JSON.stringify(metadata),JSON.stringify(result.usage),new Date().toISOString(),job.id).run();
 const estimated=await env.DB.prepare('SELECT job_id FROM image_estimated_settlements WHERE job_id=?').bind(job.id).first();
 if(estimated)await correctEstimatedImage(env.DB,{jobId:job.id,receiptSha256:digest,actualMicros:actual});
 else await settle(env.DB,{reservationId:job.reservation_id,actualMicros:actual});
 const image=await imageResponseBytes(pricing,result);
 const media=await saveMedia(env,job.user_id,job.project_id,{bytes:image,mimeType:'image/png',fileName:'Benos-'+job.id+'.png',source:'generation',generationJobId:job.id,requestKey:'image:'+job.id});
 await env.DB.prepare("UPDATE image_jobs SET state='succeeded',result_media_id=?,error_code=NULL,updated_at=? WHERE id=?").bind(media.id,new Date().toISOString(),job.id).run();
}
async function handleFailure(env:Env,job:ImageJob,error:unknown,dispatched:boolean){
 const reservation=job.reservation_id?await env.DB.prepare('SELECT state FROM api_reservations WHERE id=?').bind(job.reservation_id).first<{state:string}>():null;
 let held=!!reservation&&!['settled','released'].includes(reservation.state);const code=error instanceof AppError||error instanceof LedgerError?error.code:dispatched?'IMAGE_PROVIDER_UNCERTAIN':'IMAGE_TEMPORARILY_UNAVAILABLE';
 let estimate:ImageEstimateSnapshot|undefined;try{estimate=JSON.parse(job.request_json).costEstimate;}catch{}
 let estimated=!!await env.DB.prepare('SELECT job_id FROM image_estimated_settlements WHERE job_id=?').bind(job.id).first();
 // Only dispatched requests without validated usage can use the frozen opt-in
 // estimate. A ledger/storage failure with known usage must recover that exact
 // settlement, never substitute an estimate or redispatch the provider request.
 const knownUsage=await env.DB.prepare('SELECT usage_json FROM image_jobs WHERE id=?').bind(job.id).first<{usage_json:string|null}>();
 if(!dispatched&&held&&estimate?.policy===IMAGE_ESTIMATION_POLICY){
  try{await releaseConfirmedUnused(env.DB,job.reservation_id!);held=false;}
  catch{const confirmed=await env.DB.prepare("SELECT id FROM api_reservations WHERE id=? AND state='released' AND actual_micros=0").bind(job.reservation_id).first();if(confirmed)held=false;}
 }
 if(dispatched&&held&&estimate?.policy===IMAGE_ESTIMATION_POLICY&&!knownUsage?.usage_json){
  try{await settleEstimatedImage(env.DB,{jobId:job.id,reservationId:job.reservation_id!,estimatedMicros:estimate.estimatedMicros,snapshotJson:JSON.stringify(estimate),errorCode:code});held=false;estimated=true;}
  catch{/* Confirm a lost commit acknowledgement from the durable atomic audit. */
   const confirmed=await env.DB.prepare(`SELECT e.job_id FROM image_estimated_settlements e JOIN api_reservations r ON r.id=e.reservation_id WHERE e.job_id=? AND r.state='settled' AND r.actual_micros=e.estimated_micros`).bind(job.id).first();
   if(confirmed){held=false;estimated=true;}
  }
 }
 if(held)try{await markUncertain(env.DB,job.reservation_id!);}catch{/* A failed acknowledgement must never release funds. */}
 if(dispatched&&['IMAGE_CONTRACT_BREACH','IMAGE_PRICING_MISMATCH','IMAGE_USAGE_INVALID','COST_EXCEEDS_RESERVATION'].includes(code)){
  const pricing=imageConfigSchema.parse(JSON.parse(job.pricing_json));await env.DB.batch([env.DB.prepare('UPDATE provider_pools SET enabled=0,updated_at_ms=? WHERE provider_id=?').bind(Date.now(),pricing.providerPoolId),auditStatement(env.DB,null,'image.budget_suspended','provider',pricing.providerPoolId,{jobId:job.id,code},job.id)]);
 }
 const invalidOutput=['IMAGE_OUTPUT_INVALID','MEDIA_INVALID'].includes(code),state=held?'uncertain':estimated?'failed':reservation?.state==='settled'&&!invalidOutput?'output_pending':'failed';
 await env.DB.prepare('UPDATE image_jobs SET state=?,error_code=?,updated_at=? WHERE id=?').bind(state,code,new Date().toISOString(),job.id).run();
}
export async function createImageGeneration(env:Env,userId:string,projectId:string,input:{prompt:string;requestKey:string;configId?:string;slot?:ImageSlotInput;quality?:'low'|'medium';estimationPolicy?:typeof IMAGE_ESTIMATION_POLICY;expectedFinalPrompt?:string;generationSize?:ImageSize},runtime:ImageRuntime={}):Promise<ImageJob>{
 await ownedMediaProject(env,userId,projectId);assert(typeof input.prompt==='string'&&input.prompt.trim().length>=3&&input.prompt.length<=32000&&/^[a-zA-Z0-9_-]{16,128}$/.test(input.requestKey),'VALIDATION','图片需求或请求编号无效');
 const parsedSlot=imageSlotSchema.optional().safeParse(input.slot);assert(parsedSlot.success,'VALIDATION','图片图框尺寸或构图设置无效');const slot=parsedSlot.data;
 assert(input.quality===undefined||input.quality==='low'||input.quality==='medium','VALIDATION','图片质量档位无效');
 assert(input.estimationPolicy===undefined||input.estimationPolicy===IMAGE_ESTIMATION_POLICY,'VALIDATION','图片估算政策无效');
 assert(input.generationSize===undefined||IMAGE_SIZES.includes(input.generationSize),'VALIDATION','图片生成尺寸无效');
 const hash=await sha256(JSON.stringify({projectId,prompt:input.prompt,...(input.configId!==undefined?{configId:input.configId}:{}),...(slot?{slot}:{}),...(input.quality!==undefined?{quality:input.quality}:{}),...(input.estimationPolicy!==undefined?{estimationPolicy:input.estimationPolicy}:{}),...(input.generationSize!==undefined?{generationSize:input.generationSize}:{})})),existing=await env.DB.prepare('SELECT * FROM image_jobs WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<ImageJob>();
 if(existing){assert(existing.request_hash===hash,'IDEMPOTENCY_CONFLICT','该请求编号已用于其他图片',409);assert(input.expectedFinalPrompt===undefined||JSON.parse(existing.request_json).payload?.prompt===input.expectedFinalPrompt,'IMAGE_PROMPT_MISMATCH','图片需求与冻结的构图计划不一致',409);return existing;}
 assert(env.BUCKET,'MEDIA_NOT_CONFIGURED','素材存储尚未配置',503);
 const config=await resolveImageConfiguration(env,input.configId);
 const configuredPricing=configPricing(config),layout=slot?imageLayout(slot,input.generationSize):null,pricing={...configuredPricing,...(layout?{size:layout.generation.size}:input.generationSize?{size:input.generationSize}:{}),...(input.quality?{quality:input.quality}:{})},contract=auditedContract(env,pricing,runtime);
 if(contract.version!=='fixture-v1')await assertIntegrationCapability(env.DB,config.id,'image');
 const prompt=slot?imagePromptForSlot(input.prompt,slot,pricing.size):input.prompt;
 assert(input.expectedFinalPrompt===undefined||input.expectedFinalPrompt===prompt,'IMAGE_PROMPT_MISMATCH','图片需求与冻结的构图计划不一致',409);
 assert(new TextEncoder().encode(prompt).length<=contract.maxPromptBytes,'IMAGE_PROMPT_TOO_LONG','图片需求与构图说明超过当前模型支持的长度，请缩短描述');
 // All production traffic is pinned to the reviewed official endpoint.
 assert(config.provider==='openai'&&pricing.baseUrl==='https://api.openai.com/v1','IMAGE_ADAPTER_UNSUPPORTED','图片服务适配器尚未审核',503);
 assert(config.secret_ciphertext,'IMAGE_NOT_CONFIGURED','图片生成尚未启用',503);const secret=JSON.parse(await decryptSecret(config.secret_ciphertext,env.ENCRYPTION_KEY,config.id));assert(typeof secret.apiKey==='string'&&secret.apiKey.length>=8,'IMAGE_NOT_CONFIGURED','图片服务密钥尚未配置',503);
 const costEstimate=input.estimationPolicy?await imageEstimatedCost(env.DB,pricing,Math.max(1,imageReservationCost(pricing,contract))):null;
 const jobId=id('img'),now=new Date().toISOString(),request={...createImageRequest(pricing,prompt),safety_identifier:await sha256(userId)};
 await env.DB.prepare(`INSERT INTO image_jobs(id,user_id,project_id,config_version_id,request_key,request_hash,state,request_json,pricing_json,created_at,updated_at) VALUES(?,?,?,?,?,?,'preparing',?,?,?,?) ON CONFLICT(user_id,request_key) DO NOTHING`).bind(jobId,userId,projectId,config.id,input.requestKey,hash,JSON.stringify({payload:request,billingContract:contract,...(layout?{layout}:{}),...(costEstimate?{costEstimate}:{})}),JSON.stringify(pricing),now,now).run();
 const stored=await env.DB.prepare('SELECT * FROM image_jobs WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<ImageJob>();assert(stored,'IMAGE_JOB_UNAVAILABLE','图片任务创建结果待核对',503);assert(stored.request_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他内容',409);if(stored.id!==jobId)return stored;
 let job=stored,dispatched=false;
 try{
  const reservation=await reserve(env.DB,{id:id('res'),userId,providerId:pricing.providerPoolId,amountMicros:Math.max(1,imageReservationCost(pricing,contract)),requestKey:'image:'+jobId,requestHash:hash});
  job={...job,reservation_id:reservation.id};await env.DB.prepare("UPDATE image_jobs SET state='reserved',reservation_id=?,updated_at=? WHERE id=?").bind(reservation.id,new Date().toISOString(),jobId).run();
  assert(await claimReservation(env.DB,reservation.id),'IMAGE_DISPATCH_CONFLICT','图片任务已发送或账号状态发生变化',409);
  await env.DB.prepare("UPDATE image_jobs SET state='running',updated_at=? WHERE id=?").bind(new Date().toISOString(),jobId).run();dispatched=true;
  const response=await fetchWithoutRedirect(pricing.baseUrl+'/images/generations',{method:'POST',headers:{Authorization:'Bearer '+secret.apiKey,'Content-Type':'application/json','X-Client-Request-Id':jobId},body:JSON.stringify(request),signal:AbortSignal.timeout(180000)},runtime.fetch!);
  assert(response.ok,'IMAGE_PROVIDER_UNCERTAIN','图片响应或费用尚未确认，请查询原任务',502);
  const bytes=await boundedBytes(response.body,MAX_RESPONSE_BYTES),key=evidenceKey(job);
  await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:'application/json',cacheControl:'private, no-store'},customMetadata:{sha256:await sha256(bytes)}});
  await env.DB.prepare('UPDATE image_jobs SET provider_request_id=?,updated_at=? WHERE id=?').bind(response.headers.get('x-request-id'),new Date().toISOString(),jobId).run();
  await finishEvidence(env,job,bytes,contract);
 }catch(error){await handleFailure(env,job,error,dispatched);}
 return getJob(env,userId,jobId);
}
/** Reconcile the durable response only; never dispatches another paid request. */
export async function reconcileImageGeneration(env:Env,userId:string,jobId:string,runtime:ImageRuntime={}){
 const job=await getJob(env,userId,jobId);if(job.state==='succeeded')return job;
 assert(job.reservation_id&&env.BUCKET,'IMAGE_RECOVERY_UNAVAILABLE','图片任务尚无可核对响应',409);
 const pricing=imageConfigSchema.parse(JSON.parse(job.pricing_json)),contract=auditedContract(env,pricing,runtime);
 assert(JSON.stringify(JSON.parse(job.request_json).billingContract)===JSON.stringify(contract),'IMAGE_CONTRACT_MISMATCH','核对必须沿用原任务的计费合同',409);
 const object=await env.BUCKET.get(evidenceKey(job));assert(object&&object.size<=MAX_RESPONSE_BYTES,'IMAGE_RECOVERY_UNAVAILABLE','尚无可核对的供应商原始回执，当前结算记录保持不变',409);
 try{await finishEvidence(env,job,new Uint8Array(await object.arrayBuffer()),contract);}catch(error){await handleFailure(env,job,error,true);}return getJob(env,userId,jobId);
}
export const imagesRoutes=new Hono<App>();imagesRoutes.use('*',requireAuth);
imagesRoutes.get('/options',async c=>ok(c,await listImageModels(c.env,c.get('auth').user.id)));
imagesRoutes.get('/quote',async c=>ok(c,await imageGenerationQuote(c.env,c.get('auth').user.id,c.req.query('configId'))));
imagesRoutes.get('/availability',async c=>ok(c,await imageAvailability(c.env)));
imagesRoutes.post('/projects/:project/generate',async c=>{await enforceScope(c,'ai');await rateLimit(c,'image-generation',20,3600,c.get('auth').user.id);const input=await body(c,z.object({prompt:z.string().trim().min(3).max(32000),requestKey:z.string().regex(/^[a-zA-Z0-9_-]{16,128}$/),configId:z.string().regex(/^[A-Za-z0-9_-]{1,120}$/).optional(),slot:imageSlotSchema.optional()}).strict());return ok(c,imageJobView(await createImageGeneration(c.env,c.get('auth').user.id,c.req.param('project'),input)),202);});
imagesRoutes.get('/projects/:project/jobs',async c=>{await ownedMediaProject(c.env,c.get('auth').user.id,c.req.param('project'));const requestKey=c.req.query('requestKey');assert(requestKey===undefined||/^[a-zA-Z0-9_-]{16,128}$/.test(requestKey),'VALIDATION','请求编号无效');const rows=await c.env.DB.prepare(`SELECT * FROM image_jobs WHERE user_id=? AND project_id=? ${requestKey!==undefined?'AND request_key=?':''} ORDER BY created_at DESC LIMIT ${requestKey!==undefined?1:30}`).bind(c.get('auth').user.id,c.req.param('project'),...(requestKey!==undefined?[requestKey]:[])).all<ImageJob>();return ok(c,{items:rows.results.map(imageJobView)});});
imagesRoutes.get('/jobs/:id',async c=>ok(c,imageJobView(await getJob(c.env,c.get('auth').user.id,c.req.param('id')))));
imagesRoutes.post('/jobs/:id/reconcile',async c=>{await body(c,z.object({}).strict());return ok(c,imageJobView(await reconcileImageGeneration(c.env,c.get('auth').user.id,c.req.param('id'))));});
