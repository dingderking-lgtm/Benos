import { z } from 'zod';

/** Strings retain the original inline-text protocol. One nested parts object
 * describes a span containing plain spans, never client-supplied markup. */
export type InlineTextParts = { slots: string[]; children: (string | InlineTextParts)[] };
const slots = z.array(z.string().max(4000)).min(2).max(13);
const leaf = z.object({ slots, children: z.array(z.string().max(4000)).min(1).max(12) }).strict();
export const inlineTextPartsSchema = z.object({
 slots,
 children: z.array(z.union([z.string().max(4000), leaf])).min(1).max(12)
}).strict();
