import { parseFragment, type DefaultTreeAdapterMap } from 'parse5';
import type { PageBlueprint } from '../contracts/design-brief';

/** A bounded, non-mutating structural review, not a renderer or an aesthetic
 * score. Unknown CSS and image semantics deliberately produce no verdict. */
type Element = DefaultTreeAdapterMap['element'];
type Node = DefaultTreeAdapterMap['node'];
type Obj = Record<string, any>;
export type DesignCoherenceCode = 'repeated_heading_list_sections' | 'oversized_disclaimer_section' | 'alternating_section_backgrounds' | 'mobile_ratio_min_height_risk' | 'blueprint_depth_gap' | 'auxiliary_text_overuse' | 'unfinished_visual_placeholder';
export type DesignCoherenceLocation = {
  templateId: number; pageKey: string; section: number; sectionId?: string;
  heading: string; startOffset: number; endOffset: number; line: number;
};
export type DesignCoherenceDiagnostic = {
  code: DesignCoherenceCode; severity: 'advisory';
  locations: DesignCoherenceLocation[]; evidence: string[]; suggestion: string;
};
export type DesignCoherenceReport = {
  diagnostics: DesignCoherenceDiagnostic[];
  coverage: { templates: number; sections: number; cssSkipped: number; truncated: boolean; mobileSizingSkipped?: number };
};
const MAX_HTML = 750_000, MAX_CSS = 180_000, MAX_NODES = 12_000, MAX_SECTIONS = 80;
const omittedTags = new Set(['script', 'style', 'template', 'noscript', 'nav', 'header', 'footer', 'aside']);
const obj = (v: unknown): Obj => v && typeof v === 'object' && !Array.isArray(v) ? v as Obj : {};
const str = (v: unknown): string => typeof v === 'string' ? v : '';
const short = (v: string, n = 70) => v.replace(/\s+/g, ' ').trim().slice(0, n);
const attr = (e: Element, name: string) => e.attrs.find(a => a.name === name)?.value;
const isElement = (n: Node): n is Element => 'tagName' in n;
const parent = (e: Element): Element | null => e.parentNode && isElement(e.parentNode) ? e.parentNode : null;
const visible = (e: Element) => !omittedTags.has(e.tagName) && attr(e, 'hidden') === undefined && attr(e, 'aria-hidden') !== 'true'
  && !/(?:^|;)\s*(?:display\s*:\s*none|visibility\s*:\s*hidden)\s*(?:!important)?\s*(?:;|$)/i.test(attr(e, 'style') || '');

/** Match design-nodes.ts's parse5 source offsets; inert template content is not
 * traversed. A single iterative walk bounds work on untrusted generated HTML. */
function elements(root: Node, limit = MAX_NODES): Element[] | null {
  const out: Element[] = [], stack: Node[] = [root];
  while (stack.length) {
    const node = stack.pop()!;
    if (isElement(node)) {
      if (!visible(node)) continue;
      out.push(node);
      if (out.length > limit) return null;
    }
    if ('childNodes' in node) for (let i = node.childNodes.length - 1; i >= 0; i--) stack.push(node.childNodes[i]);
  }
  return out;
}
function text(root: Node, max = 8_000): string {
  let value = ''; const stack: Node[] = [root];
  while (stack.length && value.length < max) {
    const node = stack.pop()!;
    if (isElement(node) && !visible(node)) continue;
    if ('value' in node) value += node.value.slice(0, max - value.length) + ' ';
    else if ('childNodes' in node) for (let i = node.childNodes.length - 1; i >= 0; i--) stack.push(node.childNodes[i]);
  }
  return value.replace(/\s+/g, ' ').trim();
}
function contains(outer: Element, inner: Element): boolean {
  for (let at: Element | null = inner; at; at = parent(at)) if (at === outer) return true;
  return false;
}

type Declaration = { name: string; value: string; important: boolean };
type Rule = { selector: string; parts: string[]; specificity: number; declarations: Declaration[]; order: number };
type Css = { rules: Rule[]; unsupported: boolean; sizingUnsupported?: boolean };
type Computed = { values: Map<string, string>; variables: Map<string, string> };
const relevant = (name: string) => name.startsWith('--') || /^(?:all|background(?:-color|-image)?|padding(?:-block(?:-start|-end)?|-top|-bottom)?|height|min-height|width|max-width|max-inline-size|aspect-ratio|overflow(?:-x|-y)?|opacity|filter|backdrop-filter|mix-blend-mode|display|visibility)$/.test(name);

/** Only a small, explicit CSS subset is interpreted. Delimiters inside quoted
 * strings and functions are respected; unsupported conditions/selectors which
 * can affect the evidence disable CSS diagnostics rather than being guessed. */
function splitCss(value: string, delimiter: string): string[] {
  const result: string[] = []; let quote = '', depth = 0, start = 0;
  for (let i = 0; i < value.length; i++) {
    const ch = value[i];
    if (ch === '\\') { i++; continue; }
    if (quote) { if (ch === quote) quote = ''; continue; }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '(' || ch === '[') depth++;
    else if (ch === ')' || ch === ']') depth--;
    else if (ch === delimiter && depth === 0) { result.push(value.slice(start, i)); start = i + 1; }
  }
  result.push(value.slice(start)); return result;
}
function declarations(body: string): Declaration[] {
  return splitCss(body, ';').flatMap(part => {
    const at = part.indexOf(':'); if (at < 1) return [];
    const key = part.slice(0, at).trim(), name = key.startsWith('--') ? key : key.toLowerCase(), raw = part.slice(at + 1).trim();
    if (!relevant(name)) return [];
    return [{ name, value: raw.replace(/\s*!important\s*$/i, '').trim(), important: /!important\s*$/i.test(raw) }];
  });
}
const simpleCompound = /^(?:\*|[a-zA-Z][\w-]*|:root)?(?:[.#][a-zA-Z_][\w-]*)*$/;
function selectorParts(selector: string): string[] | null {
  const parts = selector.trim().replace(/\s*>\s*/g, '>').split(/(>|\s+)/).filter(Boolean).map(v => /^\s+$/.test(v) ? ' ' : v);
  if (!parts.length || parts.some((part, i) => i % 2 ? part !== ' ' && part !== '>' : !part || !simpleCompound.test(part))) return null;
  return parts.length % 2 ? parts : null;
}
/** A proof of non-intersection, not support for more of the CSS cascade. An
 * unknown descendant selector cannot reach page content when its known first
 * compound is absent. Siblings, nesting, escapes and unknown first compounds
 * cannot use this shortcut. :where/:is only accept a bounded list of simple
 * first compounds; their specificity/conditions are never computed here. */
function unrelatedSubtree(selector: string, activeNodes: Element[]): boolean {
  if (selector.length > 2048 || /[+~\\&|]/.test(selector)) return false;
  const source = selector.trim(), alternatives = source.match(/^:(?:where|is)\(([^()]*)\)(?=\s|>|$)/);
  const first = source.match(/^((?:\*|[a-zA-Z][\w-]*|:root)?(?:[.#][a-zA-Z_][\w-]*)*)(?=\s|>|$)/)?.[1];
  const origins = alternatives ? splitCss(alternatives[1], ',').map(part => part.trim()) : first ? [first] : [];
  if (!origins.length || origins.length > 16 || origins.some(origin => !origin || !simpleCompound.test(origin))) return false;
  const targets: Target[] = ['html', 'body', ...activeNodes];
  return origins.every(origin => !targets.some(target => compoundMatches(target, origin)));
}
const hides = (declaration: Declaration) => declaration.name === 'display' && declaration.value.toLowerCase() === 'none'
  || declaration.name === 'visibility' && declaration.value.toLowerCase() === 'hidden';
/** Only width conditions have a stable meaning for this static mobile sample.
 * Unsupported media features are never assumed true or false. */
function mobileMedia(selector: string, width: number): boolean | null {
  let query = selector.replace(/^@media\s*/i, '').trim().toLowerCase();
  if (/^print(?:\s|$)/.test(query)) return false;
  query = query.replace(/^(?:screen|all)\s*(?:and\s*)?/, '');
  const conditions = query.split(/\s+and\s+/), results: boolean[] = [];
  for (const condition of conditions) {
    const match = condition.trim().match(/^\(\s*(min|max)-width\s*:\s*(\d+(?:\.\d+)?)px\s*\)$/);
    if (!match) return null;
    results.push(match[1] === 'min' ? width >= Number(match[2]) : width <= Number(match[2]));
  }
  return results.every(Boolean);
}
const sizingDeclaration = (name: string) => name.startsWith('--') || /^(all|aspect-ratio|min-height|width|max-width|max-inline-size|overflow(?:-x|-y)?|display|visibility)$/.test(name);
/** Only an unused, ordinary selector can make a conditional variable irrelevant.
 * Flat rules only: no recursive parsing, pseudo selectors or sibling reach. A
 * variable on html/body or any page ancestor still invalidates base paint. */
function unrelatedMediaVariables(body: string, activeNodes: Element[]): boolean {
  const rule = /\s*([^{}]+)\{([^{}]*)\}\s*/gy, targets: Target[] = ['html', 'body', ...activeNodes];
  let cursor = 0, count = 0, found = false;
  while (cursor < body.length) {
    rule.lastIndex = cursor; const match = rule.exec(body);
    if (!match || ++count > 2000 || match[1].trim().startsWith('@')) return false;
    cursor = rule.lastIndex;
    if (!declarations(match[2]).some(d => d.name.startsWith('--'))) continue;
    found = true;
    for (const selector of splitCss(match[1], ',')) {
      const parts = selectorParts(selector);
      if (!parts || targets.some(target => matches(target, parts))) return false;
    }
  }
  return found;
}
function parseCss(input: string, activeNodes: Element[], mobile?: { width: number; depth: number }, visibilityProbe = false): Css {
  const css: Css = { rules: [], unsupported: false };
  if (input.length > MAX_CSS || (mobile && mobile.depth > 4)) return { rules: [], unsupported: true, sizingUnsupported: true };
  const source = input.replace(/\/\*[\s\S]*?\*\//g, ''); let cursor = 0, order = 0;
  while (cursor < source.length) {
    const open = source.indexOf('{', cursor); if (open < 0) break;
    const selector = source.slice(cursor, open).trim(); let depth = 1, quote = '', end = open + 1;
    for (; end < source.length && depth; end++) {
      const ch = source[end]; if (ch === '\\') { end++; continue; }
      if (quote) { if (ch === quote) quote = ''; continue; }
      if (ch === '"' || ch === "'") quote = ch;
      else if (ch === '{') depth++; else if (ch === '}') depth--;
    }
    if (depth) { css.unsupported = true; css.sizingUnsupported = true; break; }
    const body = source.slice(open + 1, end - 1); cursor = end;
    if (selector.startsWith('@') || body.includes('{')) {
      if (mobile) {
        const condition = /^@media\b/i.test(selector) ? mobileMedia(selector, mobile.width) : null;
        if (condition === true) {
          const nested = parseCss(body, activeNodes, { width: mobile.width, depth: mobile.depth + 1 });
          css.sizingUnsupported ||= nested.sizingUnsupported;
          for (const rule of nested.rules) css.rules.push({ ...rule, order: order++ });
        } else if (condition === null && /(?:^|[;{])\s*(?:--[\w-]+|all|aspect-ratio|min-height|width|max-width|max-inline-size|overflow(?:-[xy])?|display|visibility)\s*:/i.test(body)) css.sizingUnsupported = true;
        if (css.rules.length > 2000) return { rules: [], unsupported: true, sizingUnsupported: true };
        continue;
      }
      // Responsive spacing does not change a base-style observation. Paint and
      // matching variables still require abstention. Literal hiding and opacity:1 resets
      // only do so if their selector could affect this page: restoring an absent
      // menu's visibility cannot change a body chapter. Other opacity values,
      // paint and nested conditions keep the conservative boundary.
      const opacity = [...body.matchAll(/(?:^|[;{])\s*opacity\s*:\s*([^;}]+)/gi)];
      const resetsOpacity = opacity.length > 0 && opacity.every(match => /^1(?:\.0+)?\s*(?:!important\s*)?$/i.test(match[1].trim()));
      const variables = /(?:^|[;{])\s*--[\w-]+\s*:/i.test(body);
      if (/(?:^|[;{])\s*(?:all|background(?:-[\w-]+)?|filter)\s*:/i.test(body)
        || variables && (!/^@media\b/i.test(selector) || !unrelatedMediaVariables(body, activeNodes))
        || /@import\b/i.test(selector) || opacity.length > 0 && !resetsOpacity) css.unsupported = true;
      else if (resetsOpacity || /(?:^|[;{])\s*(?:display\s*:\s*none|visibility\s*:\s*hidden)/i.test(body)) {
        if (visibilityProbe || !/^@media\b/i.test(selector)) css.unsupported = true;
        else {
          const nested = parseCss(body, activeNodes, undefined, true), targets: Target[] = ['html', 'body', ...activeNodes];
          css.unsupported ||= nested.unsupported || nested.rules.some(rule => rule.declarations.some(d => hides(d) || d.name === 'opacity') && targets.some(target => matches(target, rule.parts)));
        }
      }
      continue;
    }
    const list = declarations(body); if (!list.length) continue;
    for (const part of splitCss(selector, ',')) {
      const parts = selectorParts(part);
      if (!parts) {
        if ((mobile || visibilityProbe) && unrelatedSubtree(part, activeNodes)) continue;
        // The conditional-hiding probe must not lose a possible match through
        // base-state or narrow pseudo-element exceptions below.
        if (visibilityProbe && list.some(d => hides(d) || d.name === 'opacity')) { css.unsupported = true; continue; }
        if (/:(?:hover|active|focus(?:-visible|-within)?|visited)\b/.test(part)) continue; // Base state only.
        if (mobile) {
          // Pseudo-element dimensions do not set the host container's ratio or
          // minimum height. Unknown real-element sizing selectors do matter.
          if (!/::?(?:before|after)\s*$/.test(part) && list.some(d => sizingDeclaration(d.name))) css.sizingUnsupported = true;
          continue;
        }
        // A registered primitive is not evidence that it is used. Restrict this
        // optimization to a recognizable pseudo-element origin; other unknown
        // selectors/conditions still cause abstention.
        if (/::(?:before|after)\s*$/.test(part)) {
          const origin = selectorParts(part.replace(/::(?:before|after)\s*$/, '').replace(/:not\(:last-child\)|:(?:first|last)-child/g, ''));
          if (origin && !(['html', 'body', ...activeNodes] as Target[]).some(n => matches(n, origin))) continue;
          // The foundation's 32px step marker and 1px connector cannot fill a
          // section. Never make this assumption for fixed/zoomed decorations.
          const narrow = body.match(/(?:^|;)\s*(?:width|height)\s*:\s*(\d+(?:\.\d+)?)px\s*(?:;|$)/i);
          if (origin && narrow && Number(narrow[1]) <= 64 && !/(?:^|;)\s*(?:transform|zoom|filter)\s*:|position\s*:\s*fixed/i.test(body)) continue;
        }
        // Hover colors, pseudo-element paints, attribute selectors, and other
        // unsupported cascade features must not be silently treated as absent.
        if (list.some(d => /^(?:--|all|background|opacity|filter)/.test(d.name) || (d.name === 'display' && d.value === 'none') || (d.name === 'visibility' && d.value === 'hidden'))) css.unsupported = true;
        continue;
      }
      const specificity = (part.match(/#/g)?.length || 0) * 100 + (part.match(/\.|:root/g)?.length || 0) * 10 + parts.filter(p => /^[a-zA-Z]/.test(p)).length;
      css.rules.push({ selector: part.trim(), parts, specificity, declarations: list, order: order++ });
      if (css.rules.length > 2000) return { rules: [], unsupported: true, sizingUnsupported: true };
    }
  }
  if (/@import\b/i.test(source)) { css.unsupported = true; css.sizingUnsupported = true; }
  return css;
}
type Target = Element | 'html' | 'body';
function targetParent(target: Target): Target | null { return target === 'html' ? null : target === 'body' ? 'html' : parent(target) || 'body'; }
function compoundMatches(target: Target, compound: string): boolean {
  const tag = typeof target === 'string' ? target : target.tagName;
  if (compound.startsWith(':root')) { if (target !== 'html') return false; compound = compound.slice(5); }
  const name = compound.match(/^(?:\*|[a-zA-Z][\w-]*)/)?.[0];
  if (name && name !== '*' && name.toLowerCase() !== tag) return false;
  const classes = typeof target === 'string' ? [] : (attr(target, 'class') || '').split(/\s+/);
  return [...compound.matchAll(/([.#])([\w-]+)/g)].every(([, kind, value]) => typeof target !== 'string' && (kind === '#' ? attr(target, 'id') === value : classes.includes(value)));
}
function matches(target: Target, parts: string[]): boolean {
  let at: Target | null = target, index = parts.length - 1;
  if (!compoundMatches(at, parts[index])) return false;
  while (index > 0) {
    const combinator = parts[index - 1], compound = parts[index - 2]; at = targetParent(at);
    if (combinator === ' ') while (at && !compoundMatches(at, compound)) at = targetParent(at);
    if (!at || !compoundMatches(at, compound)) return false;
    index -= 2;
  }
  return true;
}
function styleComputer(css: Css) {
  const cache = new Map<Target, Computed>();
  const compute = (target: Target): Computed => {
    const found = cache.get(target); if (found) return found;
    const ancestor = targetParent(target), inherited = ancestor ? compute(ancestor) : null;
    const variables = new Map(inherited?.variables), values = new Map<string, string>();
    const winners = new Map<string, { rank: number; value: string }>();
    const put = (d: Declaration, specificity: number, order: number) => {
      const rank = (d.important ? 1e12 : 0) + specificity * 1e6 + order;
      const old = winners.get(d.name); if (!old || rank >= old.rank) winners.set(d.name, { rank, value: d.value });
    };
    for (const rule of css.rules) if (matches(target, rule.parts)) for (const d of rule.declarations) put(d, rule.specificity, rule.order);
    if (typeof target !== 'string') for (const d of declarations(attr(target, 'style') || '')) put(d, 100_000, css.rules.length);
    // Expand only properties used for evidence, in cascade order. This respects
    // shorthand resets and !important without attempting a full CSS engine.
    for (const [name, winner] of [...winners].sort((a, b) => a[1].rank - b[1].rank)) {
      if (name.startsWith('--')) variables.set(name, winner.value);
      else if (name === 'background') { values.set('background-color', winner.value); values.set('background-image', '__shorthand__:' + winner.value); }
      else if (name === 'padding' || name === 'padding-block') {
        const sides = splitSpace(winner.value);
        values.set('padding-top', sides[0] || ''); values.set('padding-bottom', name === 'padding' ? sides[2] || sides[0] || '' : sides[1] || sides[0] || '');
      } else if (name === 'padding-block-start') values.set('padding-top', winner.value);
      else if (name === 'padding-block-end') values.set('padding-bottom', winner.value);
      else values.set(name, winner.value);
    }
    const result = { variables, values };
    // Inherited custom properties retain their computed value. A later child
    // override cannot retroactively change a parent's resolved alias.
    const resolvedVariables = new Map([...variables].map(([name, value]) => [name, resolve(value, result) ?? '__unsupported_css_value__']));
    result.variables = resolvedVariables; cache.set(target, result); return result;
  };
  return compute;
}
function splitSpace(value: string): string[] {
  // Convert only top-level whitespace to a separator; clamp/calc stay intact.
  let depth = 0, normalized = '';
  for (const ch of value) { if (ch === '(') depth++; if (ch === ')') depth--; normalized += depth === 0 && /\s/.test(ch) ? ';' : ch; }
  return normalized.split(';').filter(Boolean);
}
function resolve(value: string, style: Computed, seen = new Set<string>()): string | null {
  if (!value.includes('var(')) return value.trim();
  const match = value.match(/^var\(\s*(--[\w-]+)\s*(?:,\s*([^()]+))?\)$/);
  if (!match || seen.has(match[1]) || seen.size > 16) return null;
  seen.add(match[1]); const next = style.variables.get(match[1]) ?? match[2];
  return next === undefined ? null : resolve(next, style, seen);
}
function pxLowerBound(value: string | undefined, style: Computed): number | null {
  const raw = resolve(value || '', style); if (raw === null) return null;
  if (/^\d+(?:\.\d+)?px$/.test(raw)) return parseFloat(raw);
  if (raw === '0') return 0;
  const clamp = raw.match(/^clamp\(\s*(\d+(?:\.\d+)?)px\s*,[^,]+,\s*(\d+(?:\.\d+)?)px\s*\)$/);
  return clamp ? Math.min(Number(clamp[1]), Number(clamp[2])) : null;
}
type Color = { css: string; luminance: number };
function color(value: string): Color | null {
  const raw = value.trim().toLowerCase(); let rgb: number[];
  if (/^#[a-f0-9]{3}$/.test(raw)) rgb = [...raw.slice(1)].map(v => parseInt(v + v, 16));
  else if (/^#[a-f0-9]{6}$/.test(raw)) rgb = [1, 3, 5].map(i => parseInt(raw.slice(i, i + 2), 16));
  else if (raw === 'black' || raw === 'white') rgb = Array(3).fill(raw === 'black' ? 0 : 255);
  else {
    const match = raw.match(/^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/);
    if (!match || match.slice(1).some(v => Number(v) > 255)) return null;
    rgb = match.slice(1).map(Number);
  }
  const linear = rgb.map(v => { const n = v / 255; return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4; });
  return { css: '#' + rgb.map(v => v.toString(16).padStart(2, '0')).join(''), luminance: linear[0] * .2126 + linear[1] * .7152 + linear[2] * .0722 };
}
function background(target: Target, compute: ReturnType<typeof styleComputer>): Color | null {
  for (let at: Target | null = target; at; at = targetParent(at)) {
    const values = compute(at).values;
    if (values.has('all') || ['opacity', 'filter', 'backdrop-filter', 'mix-blend-mode'].some(n => values.has(n) && !['1', 'none', 'normal'].includes(values.get(n)!))) return null;
  }
  for (let at: Target | null = target; at; at = targetParent(at)) {
    const style = compute(at), values = style.values;
    const image = values.get('background-image');
    if (image?.startsWith('__shorthand__:')) {
      const paint = resolve(image.slice(14), style); if (!paint || (paint !== 'transparent' && !color(paint))) return null;
    } else if (image && image !== 'none') return null;
    const raw = resolve(values.get('background-color') || 'transparent', style);
    if (raw === 'transparent') continue;
    if (!raw) return null;
    return color(raw);
  }
  return null; // No assumed browser canvas color.
}

type Section = { element: Element; nodes: Element[]; location: DesignCoherenceLocation; text: string; groupCount: number; heading: Element | undefined };
function repeatedGroup(nodes: Element[], sectionText: string): number {
  if (nodes.some(n => ['form', 'table', 'details'].includes(n.tagName))) return 0;
  const stats = new Map<Element, { heading: boolean; paragraph: boolean; excluded: boolean; length: number }>();
  for (let i = nodes.length - 1; i >= 0; i--) {
    const n = nodes[i], children = n.childNodes.filter(isElement).map(c => stats.get(c)).filter(Boolean);
    const length = children.reduce((sum, child) => sum + child!.length, 0) + n.childNodes.reduce((sum, c) => sum + ('value' in c ? c.value.trim().length : 0), 0);
    stats.set(n, { heading: /^h[34]$/.test(n.tagName) || children.some(s => s!.heading),
      paragraph: (n.tagName === 'p' && length >= 16) || children.some(s => s!.paragraph),
      excluded: /^(h1|h2|img|svg|video|picture|figure|form|table|details|button|a)$/.test(n.tagName) || children.some(s => s!.excluded), length });
  }
  let largest = 0;
  for (const root of nodes) {
    const children = root.childNodes.filter(isElement).filter(visible);
    let run: Element[] = [], lastTag = '';
    const flush = () => {
      if (run.length >= 3 && run.length <= 8 && run.reduce((sum, item) => sum + stats.get(item)!.length, 0) >= sectionText.length * .45) largest = Math.max(largest, run.length);
      run = [];
    };
    for (const child of children) {
      if (!['li', 'article', 'div'].includes(child.tagName)) { flush(); lastTag = ''; continue; }
      const info = stats.get(child), qualifies = !!info?.heading && info.paragraph && !info.excluded;
      if (!qualifies || lastTag !== child.tagName) flush();
      if (qualifies) run.push(child); lastTag = child.tagName;
    }
    flush();
  }
  return largest;
}
function paddedSection(section: Section, compute: ReturnType<typeof styleComputer>): string | null {
  let node = section.element;
  for (let depth = 0; depth < 4; depth++) {
    const style = compute(node), top = pxLowerBound(style.values.get('padding-top'), style), bottom = pxLowerBound(style.values.get('padding-bottom'), style);
    if (top !== null && bottom !== null && top + bottom >= 96) return `非条件 CSS 在区块${node === section.element ? '本体' : '主容器'}声明上下留白下限 ${Math.round(top + bottom)}px（响应式尺寸未测量）`;
    const height = pxLowerBound(style.values.get('min-height') || style.values.get('height'), style);
    if (height !== null && height >= 280) return `CSS 在区块主容器声明高度或最小高度 ${height}px（未测量实际高度）`;
    const children = node.childNodes.filter(isElement).filter(visible);
    if (children.length !== 1 || !['div', 'article', 'main'].includes(children[0].tagName)) break;
    node = children[0];
  }
  return null;
}
function fullBand(element: Element, compute: ReturnType<typeof styleComputer>): boolean {
  for (let at: Target | null = element; at && at !== 'body'; at = targetParent(at)) {
    const values = compute(at).values;
    if (['width', 'max-width'].some(name => values.has(name) && !['auto', 'none', '100%'].includes(values.get(name)!))) return false;
  }
  return true;
}
function disclaimer(section: Section, compute: ReturnType<typeof styleComputer>): string | null {
  if (!section.heading || section.text.length < 120 || section.nodes.some(n => /^(img|picture|video|form|table|details|button)$/.test(n.tagName))) return null;
  const intro = section.nodes.filter(n => /^(h2|p)$/.test(n.tagName)).slice(0, 3).map(n => text(n)).join(' ');
  if (/隐私|法律|服务条款|privacy|legal terms|terms of service/i.test(intro)) return null;
  if (!/(免责|概念(?:边界|说明|展示)|功能(?:边界|承诺)|disclaimer|concept (?:boundary|limitations)|not a (?:live|working) product)/i.test(intro)) return null;
  const paras = section.nodes.filter(n => n.tagName === 'p' && text(n).length >= 24);
  const limiting = /(?:仅(?:供|用于)|非(?:软件|功能|已上线|真实)|并非|不是|不代表|未(?:提供|实现)|概念(?:配图|展示|描述)|不(?:提供|作为)|not (?:a |an |available|implemented|real)|does not|concept only)/i;
  const qualifying = paras.filter(n => limiting.test(text(n)));
  if (qualifying.length < 2 || qualifying.reduce((sum, n) => sum + text(n).length, 0) < section.text.length * .6) return null;
  return paddedSection(section, compute);
}

/** A geometry-risk observation, not a layout engine: aspect ratio can transfer
 * a fixed block minimum into an oversized inline size on a text composition.
 * Media frames and intentional horizontal scrolling are outside this rule. */
function mobileRatioRisks(sections: Section[], nodes: Element[], cssText: string): { diagnostics: DesignCoherenceDiagnostic[]; skipped: boolean } {
  const width = 390, css = parseCss(cssText, nodes, { width, depth: 0 });
  if (css.sizingUnsupported) return { diagnostics: [], skipped: true };
  const compute = styleComputer(css), diagnostics: DesignCoherenceDiagnostic[] = [], reported = new Set<Section>();
  for (const node of nodes) {
    if (!['div', 'section', 'article', 'main'].includes(node.tagName)) continue;
    const style = compute(node), values = style.values;
    const ratioText = resolve(values.get('aspect-ratio') || '', style), ratio = ratioText?.match(/^(\d+(?:\.\d+)?)(?:\s*\/\s*(\d+(?:\.\d+)?))?$/);
    const minimum = pxLowerBound(values.get('min-height'), style);
    if (!ratio || !minimum || minimum < 200 || values.has('all')) continue;
    const numerator = Number(ratio[1]), denominator = Number(ratio[2] || 1);
    if (!denominator || !numerator) continue;
    const transferredWidth = minimum * numerator / denominator;
    if (transferredWidth <= width + 24) continue;
    // An explicit inline-size constraint may already resolve this combination.
    // Do not guess calc/percentage/container sizing; abstain when it is present.
    if (['width', 'max-width', 'max-inline-size'].some(name => values.has(name) && !['auto', 'none', 'initial', 'unset'].includes(values.get(name)!))) continue;
    let excluded = false;
    for (let at: Target | null = node; at; at = targetParent(at)) {
      if (typeof at !== 'string' && ['table', 'figure', 'picture', 'video', 'svg', 'canvas'].includes(at.tagName)) { excluded = true; break; }
      const ancestor = compute(at).values;
      if (['overflow', 'overflow-x'].some(name => /\b(auto|scroll)\b/.test(ancestor.get(name) || '')) || ancestor.get('display') === 'none' || ancestor.get('visibility') === 'hidden') { excluded = true; break; }
    }
    if (excluded) continue;
    const inside = nodes.filter(child => contains(node, child));
    if (inside.some(child => /^(img|picture|video|svg|canvas|table|iframe)$/.test(child.tagName)) || text(node).length < 80 || inside.filter(child => /^(h[1-6]|p|article|li|blockquote)$/.test(child.tagName)).length < 2) continue;
    const section = sections.find(item => contains(item.element, node));
    if (!section || reported.has(section)) continue;
    reported.add(section);
    const classes = (attr(node, 'class') || '').split(/\s+/).filter(Boolean).slice(0, 3).join('.');
    const target = attr(node, 'id') ? '#' + short(attr(node, 'id')!, 48) : classes ? '.' + short(classes, 60) : node.tagName;
    diagnostics.push({ code: 'mobile_ratio_min_height_risk', severity: 'advisory', locations: [section.location], evidence: [
      `按可解析的 390px 手机媒体条件，文本容器 ${target} 同时保留 aspect-ratio:${ratioText} 与 min-height 下限 ${minimum}px；比例×最小高度约 ${Math.round(transferredWidth)}px，且未声明自身宽度上限。此为声明风险，未测量实际溢出。`,
    ], suggestion: '复核手机内容图：可在窄屏让 aspect-ratio:auto、由内容撑高，或设置合适的宽度约束并确认文字不裁切；固定比例的图片画框和明确允许横滚的自由构图应保留。不要用整页隐藏横向溢出来遮住内容。' });
    if (diagnostics.length === 2) break;
  }
  return { diagnostics, skipped: false };
}

export function diagnoseDesignCoherence(input: unknown, options: { pageKey?: string;blueprint?:PageBlueprint } = {}): DesignCoherenceReport {
  const report: DesignCoherenceReport = { diagnostics: [], coverage: { templates: 0, sections: 0, cssSkipped: 0, truncated: false } };
  const manifest = obj(input), site = obj(manifest.site), all = Array.isArray(manifest.templates) ? manifest.templates.map(obj) : [];
  const pages = Array.isArray(site.pages) ? site.pages.map(obj) : all.filter(t => t.type === 'page').map(t => ({ key: String(t.id), template_id: t.id }));
  const seen = new Set<number>();
  for (const page of pages.slice(0, 12)) {
    if (options.pageKey && page.key !== options.pageKey) continue;
    const template = all.find(t => t.id === page.template_id), id = template?.id;
    if (!template || typeof id !== 'number' || seen.has(id)) continue; seen.add(id);
    const html = str(obj(template.document).html);
    if (!html || html.length > MAX_HTML) { report.coverage.truncated ||= html.length > MAX_HTML; continue; }
    const root = parseFragment(html, { sourceCodeLocationInfo: true }); let nodes = elements(root);
    if (!nodes) { report.coverage.truncated = true; continue; }
    const depths = new Map<Element, number>(); let tooDeep = false;
    for (const n of nodes) { const depth = (depths.get(parent(n)!) || 0) + 1; if (depth > 128) { tooDeep = true; break; } depths.set(n, depth); }
    if (tooDeep) { report.coverage.truncated = true; continue; }
    const selected = [site.header_template_id, id, site.footer_template_id].map(key => all.find(t => t.id === key)).filter(Boolean);
    const cssText = str(obj(site.theme).global_css) + selected.map(t => str(obj(t!.document).css)).join('\n');
    const css = parseCss(cssText, nodes);
    const compute = styleComputer(css);
    if (css.rules.some(r => r.declarations.some(d => (d.name === 'display' && d.value === 'none') || (d.name === 'visibility' && d.value === 'hidden')))) {
      nodes = nodes.filter(n => {
        for (let at: Target | null = n; at; at = targetParent(at)) { const values = compute(at).values; if (values.get('display') === 'none' || values.get('visibility') === 'hidden') return false; }
        return true;
      });
    }
    const sectionNodes = nodes.filter(n => n.tagName === 'section' && !nodes.some(outer => outer !== n && outer.tagName === 'section' && contains(outer, n)));
    if (sectionNodes.length > MAX_SECTIONS) report.coverage.truncated = true;
    const sections: Section[] = sectionNodes.slice(0, MAX_SECTIONS).map((element, index) => {
      const inside = nodes.filter(n => contains(element, n)), heading = inside.find(n => /^h[12]$/.test(n.tagName)), content = text(element);
      const location = element.sourceCodeLocation;
      return { element, nodes: inside, text: content, heading, groupCount: heading?.tagName === 'h2' && content.length >= 140 ? repeatedGroup(inside, content) : 0,
        location: { templateId: id, pageKey: short(str(page.key), 48), section: index + 1, ...(attr(element, 'id') ? { sectionId: short(attr(element, 'id')!, 64) } : {}), heading: short(heading ? text(heading) : '', 48), startOffset: location?.startOffset ?? 0, endOffset: location?.endOffset ?? html.length, line: location?.startLine ?? 1 } };
    });
    report.coverage.templates++; report.coverage.sections += sections.length;
    // New-contract evidence only. These are static observations, not a forced
    // extra paid revision or a claim that a seven-section page looks good.
    if(options.blueprint?.version==='pb-1'&&page.key===site.home&&sections.length){
      const minimum=options.blueprint.targetSections[0];
      if(sections.length<minimum)report.diagnostics.push({code:'blueprint_depth_gap',severity:'advisory',locations:[sections[0].location],evidence:[`首页有${sections.length}个顶层内容section，冻结蓝图目标${minimum}–${options.blueprint.targetSections[1]}；不含首尾，尚未验证视觉内容深度。`],suggestion:'检查是否遗漏不同的访客问题。明确简单/范围或事实不足允许例外并报告，不造案例、同义章节或空白撑数量。'});
      const auxiliary=(node:Element)=>node.tagName==='figcaption'||/(?:^|\s)(?:[a-z0-9_-]*[-_])?(?:eyebrow|caption|kicker|meta|disclaimer)(?:\s|$)/i.test(attr(node,'class')||'');
      const counts=sections.map(section=>section.nodes.filter(node=>auxiliary(node)&&text(node)&&!section.nodes.some(outer=>outer!==node&&auxiliary(outer)&&contains(outer,node))).length);
      if(sections.length>=2&&counts.reduce((a,b)=>a+b,0)>sections.length*1.5)report.diagnostics.push({code:'auxiliary_text_overuse',severity:'advisory',locations:sections.filter((_,i)=>counts[i]>1).slice(0,3).map(s=>s.location),evidence:[`按明确辅助语义元素/类去重，${counts.reduce((a,b)=>a+b,0)}项/${sections.length}节；未把所有小字或业务标签都判冗余。`],suggestion:'删重复编号、眉题和氛围图注，条目避免第三层备注；必要图像来源合并页脚一次，保留有用单位和业务标签。'});
      for(const section of sections){
        const placeholder=section.nodes.find(node=>/(?:^|\s)(?:[a-z0-9_-]*[-_])?(?:skeleton|placeholder)(?:\s|$)/i.test(attr(node,'class')||'')&&!text(node)&&!section.nodes.some(child=>contains(node,child)&&['img','picture','video','table'].includes(child.tagName)));
        if(placeholder)report.diagnostics.push({code:'unfinished_visual_placeholder',severity:'advisory',locations:[section.location],evidence:['存在显式skeleton/placeholder空元素，缺少图像、文本或有标签关系。未推断任意CSS装饰的含义。'],suggestion:'移除空视觉或用有标签与关系的主题解释退化；不要再收费重发失败图片，不将无标签灰块称作成品。'});
      }
    }
    if (css.unsupported) report.coverage.cssSkipped++;
    const mobile = mobileRatioRisks(sections, nodes, cssText);
    if (mobile.skipped) report.coverage.mobileSizingSkipped = (report.coverage.mobileSizingSkipped || 0) + 1;
    let repeated: Section[] = [];
    const flushRepeated = () => {
      if (repeated.length >= 3) report.diagnostics.push({ code: 'repeated_heading_list_sections', severity: 'advisory', locations: repeated.slice(0, 3).map(s => s.location),
        evidence: [`连续 ${repeated.length} 个章节均为二级标题加 ${repeated.map(s => s.groupCount).join('/')} 项“子标题＋说明”内容；仅比较内容骨架，图片与排版可能不同。`],
        suggestion: '复核阅读节奏：保留必要信息和真实流程，只选一节改为贯穿的具体示例、前后对应关系或可扫读的对照；若统一列表是明确要求则保留，不为变化编造功能。' });
      repeated = [];
    };
    for (const section of sections) { if (section.groupCount) repeated.push(section); else flushRepeated(); }
    flushRepeated();
    if (!css.unsupported) {
      for (const section of sections) {
        const evidence = sections.length >= 3 && !/privacy|terms|legal|disclaimer|policy/i.test(str(page.key)) ? disclaimer(section, compute) : null; if (!evidence) continue;
        report.diagnostics.push({ code: 'oversized_disclaimer_section', severity: 'advisory', locations: [section.location], evidence: ['独立章节主要由至少两段概念/未实现/非真实使用声明组成。', evidence], suggestion: '保留真实边界和锚点，将重复声明压缩成与相关示例相邻的短注或紧凑说明；把整节空间用于具体内容。若用户明确要求独立声明章节则维持该结构。' });
      }
      const colors = sections.map(s => background(s.element, compute));
      for (let i = 1; i < sections.length - 1; i++) {
        const a = colors[i - 1], b = colors[i], c = colors[i + 1]; if (!a || !b || !c || !fullBand(sections[i].element, compute)) continue;
        const dark = (v: Color) => v.luminance <= .12, light = (v: Color) => v.luminance >= .65;
        if (!((dark(a) && light(b) && dark(c)) || (light(a) && dark(b) && light(c)))) continue;
        report.diagnostics.push({ code: 'alternating_section_backgrounds', severity: 'advisory', locations: sections.slice(i - 1, i + 2).map(s => s.location), evidence: [`基础 CSS 的三个相邻章节背景为 ${a.css} → ${b.css} → ${c.css}；中间章节未声明宽度限制。未判断像素、过渡效果或设计优劣。`], suggestion: '复核这一处明暗往返是否服务内容层次；若非明确设计意图，可用接近底色的表面、局部强调或延续的分隔元素连接章节。保留有目的的强对比，不要求统一成单色。' });
        i++; // One observation per overlapping transition, no warning flood.
      }
    }
    report.diagnostics.push(...mobile.diagnostics);
  }
  if (pages.length > 12 || report.diagnostics.length > 6) report.coverage.truncated = true;
  // New advisory-only notes must not crowd existing checks out of the bounded
  // report and silently bypass their established one-review contract.
  if(options.blueprint){const extra=new Set(['blueprint_depth_gap','auxiliary_text_overuse','unfinished_visual_placeholder']);report.diagnostics.sort((a,b)=>Number(extra.has(a.code))-Number(extra.has(b.code)));}
  report.diagnostics = report.diagnostics.slice(0, 6);
  return report;
}

/** This is intent suppression, not inferred taste. Only a positive explicit
 * pattern in the user's prompt/style suppresses its corresponding observation. */
export function filterExplicitCoherenceIntent(diagnostics: readonly DesignCoherenceDiagnostic[], promptAndStyle: string): DesignCoherenceDiagnostic[] {
  const requested = new Set<DesignCoherenceCode>();
  for (const clause of promptAndStyle.slice(0, 24_000).split(/[。；;！!？?\n，,]+/)) {
    if (/(?:避免|不要|不需(?:要)?|不(?:使用|做|要|允许)|别|取消|减少|禁止|without|avoid|do not|don't)/i.test(clause)) continue;
    if (/(?:明暗|深浅|黑白).{0,10}(?:章节|分区|区块|交替|切换|交错)|(?:交替|切换|交错).{0,10}(?:明暗|深浅|黑白)|(?:alternate|alternating).{0,24}(?:dark.{0,6}light|light.{0,6}dark|black.{0,6}white)/i.test(clause)) requested.add('alternating_section_backgrounds');
    if (/(?:(?:免责(?:声明)?|概念(?:边界|说明)|功能边界).{0,18}(?:独立|单独|整屏|大区|专门(?:一节|章节))|(?:独立|单独|整屏|大区|专门(?:一节|章节)).{0,18}(?:免责(?:声明)?|概念(?:边界|说明)|功能边界)|(?:standalone|separate|full[- ](?:screen|section)).{0,24}(?:disclaimer|concept limitations))/i.test(clause)) requested.add('oversized_disclaimer_section');
    if (/(?:(?:每个|各个|所有|连续|统一|重复|反复).{0,16}(?:章节|区块|模块).{0,18}(?:列表|清单|三项|3项)|(?:重复|统一|反复).{0,16}(?:标题.{0,8}列表)|(?:every|each|all|repeated).{0,16}sections?.{0,24}(?:list|three items|3 items))/i.test(clause)) requested.add('repeated_heading_list_sections');
    if (/(?:(?:手机|移动端|窄屏).{0,20}(?:允许|保留|使用).{0,12}(?:横(?:向)?(?:滚动|滑动|画布)|宽幅画布)|(?:允许|保留).{0,12}(?:手机|移动端|窄屏).{0,12}(?:横(?:向)?(?:滚动|滑动|画布)|宽幅画布)|(?:allow|keep).{0,20}horizontal (?:scroll|canvas).{0,20}(?:mobile|phone))/i.test(clause)) requested.add('mobile_ratio_min_height_risk');
  }
  return diagnostics.filter(d => !requested.has(d.code));
}

/** This is the only text intended for a model follow-up: at most 3,000 UTF-16
 * code units including framing, with whole observations retained or omitted. */
export function designCoherenceFeedback(diagnostics: readonly DesignCoherenceDiagnostic[]): string {
  if (!diagnostics.length) return '';
  const lead = '以下是静态结构复核建议，均为 advisory，不是像素审美评分，也不是必须全部修复的错误。保留用户明确要求、事实、功能绑定和已有有效锚点；只进行一次有依据的整体整理，不编造产品能力或证据。';
  let output = lead;
  for (const diagnostic of diagnostics) {
    const locations = diagnostic.locations.slice(0, 3).map(l => `模板${l.templateId}/${short(l.pageKey, 32)}第${l.section}节${l.sectionId ? '#' + short(l.sectionId, 48) : ''}「${short(l.heading, 36)}」`).join('、');
    const entry = `\n- ${diagnostic.code}：${locations}。${diagnostic.evidence.map(v => short(v, 200)).join(' ')} 建议：${short(diagnostic.suggestion, 240)}`;
    if (output.length + entry.length > 3000) break;
    output += entry;
  }
  return output === lead ? '' : output;
}
