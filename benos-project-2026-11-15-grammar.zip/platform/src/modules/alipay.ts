import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { AppError,assert } from '../lib/errors';
import { decryptSecret,id,sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole,rateLimit } from './auth';
import { createOrder,getOrder,canTopup,type Order,type OrderInput } from './commerce';
import { orderPlanSnapshot } from './billing-catalog';
import { completeFulfillment,backgroundRuntime,type PaymentRuntime } from './payments';
import { ALIPAY_GATEWAYS,parseAlipayConfiguration,alipayRequest,signedAlipayParams,verifiedAlipayNotification,amountCents,amountString,alipayTime,alipayTimestamp,type AlipayConfig,type AlipayJson } from './alipay-protocol';
export { type AlipayConfig } from './alipay-protocol';
const now=(r:PaymentRuntime)=>r.nowMs??Date.now(),iso=(r:PaymentRuntime)=>new Date(now(r)).toISOString();
type PaymentRow={order_id:string;config_version_id:string;app_id:string;seller_id:string;currency:string;amount_cents:number;checkout_published_at:string|null;trade_no:string|null;trade_status:string|null;paid_at:string|null};
type RefundRow={id:string;order_id:string;config_version_id:string;actor_id:string;request_key:string;payload_hash:string;trade_no:string;amount_cents:number;currency:string;reason:string;state:string;provider_state:string|null;last_error_code:string|null;created_at:string;updated_at:string};
export function validateAlipayConfiguration(publicConfig:unknown,secret:unknown){const c=parseAlipayConfiguration(publicConfig,secret);return {publicConfig:{mode:c.mode,appId:c.appId,sellerId:c.sellerId,keyMode:'public_key',signType:'RSA2',settlementCurrency:'CNY',...(c.usdToCnyRateMicros?{usdToCnyRateMicros:c.usdToCnyRateMicros}:{})},secret:{privateKey:c.privateKey,alipayPublicKey:c.alipayPublicKey}};}
export async function loadAlipayConfiguration(env:Env,configId?:string):Promise<AlipayConfig>{
 const row=await env.DB.prepare(`SELECT id,public_config_json,secret_ciphertext FROM integration_configs WHERE kind='payment' AND provider='alipay' ${configId?'AND id=?':"AND status='active' AND test_status='passed'"} LIMIT 1`).bind(...(configId?[configId]:[])).first<{id:string;public_config_json:string;secret_ciphertext:string|null}>();
 assert(row?.secret_ciphertext,'PAYMENT_NOT_CONFIGURED','支付宝收款尚未配置完成',503);let pub:unknown,secret:unknown;try{pub=JSON.parse(row.public_config_json);secret=JSON.parse(await decryptSecret(row.secret_ciphertext,env.ENCRYPTION_KEY,row.id));}catch{throw new AppError('PAYMENT_NOT_CONFIGURED','支付宝配置无法读取',503);}const config={id:row.id,...parseAlipayConfiguration(pub,secret)};assert(env.APP_ENV!=='production'||config.mode==='live','PAYMENT_SANDBOX_NOT_ALLOWED','正式平台禁止沙箱付款和沙箱权益发放，请在独立测试环境验收',503);return config;
}
/** Read-only signed query proves keys/application access, not product signing or live charging. */
export async function probeAlipayConfiguration(publicConfig:unknown,secret:unknown,runtime:PaymentRuntime={}){
 const c={id:'probe',...parseAlipayConfiguration(publicConfig,secret)};const result=await alipayRequest(c,'alipay.trade.query',{out_trade_no:`benos_probe_${id('key')}`},runtime);
 assert(result.code==='40004'&&result.sub_code==='ACQ.TRADE_NOT_EXIST','PAYMENT_PROBE_FAILED','支付宝签名查询未返回预期结果，请核对应用与公钥',503);
 return {verified:true,scope:'signed_read_only_query',mode:c.mode,livePaymentVerified:false};
}
async function payment(env:Env,order:Order,config:AlipayConfig,runtime:PaymentRuntime):Promise<PaymentRow>{
 assert(order.provider==='alipay'&&order.currency==='CNY'&&order.config_version_id===config.id,'PAYMENT_IDENTITY_MISMATCH','支付宝订单配置或币种不匹配',409);
 await env.DB.prepare(`INSERT INTO alipay_payments(order_id,config_version_id,app_id,seller_id,currency,amount_cents,next_reconcile_at,created_at,updated_at) VALUES(?,?,?,?,'CNY',?,?,?,?) ON CONFLICT(order_id) DO NOTHING`).bind(order.id,config.id,config.appId,config.sellerId,order.amount_cents,iso(runtime),iso(runtime),iso(runtime)).run();
 const p=await env.DB.prepare('SELECT * FROM alipay_payments WHERE order_id=?').bind(order.id).first<PaymentRow>();assert(p&&p.config_version_id===config.id&&p.app_id===config.appId&&p.seller_id===config.sellerId&&p.currency==='CNY'&&p.amount_cents===order.amount_cents,'PAYMENT_IDENTITY_MISMATCH','支付宝收款快照不匹配',409);return p;
}
function checkoutResult(order:Order,checkoutUrl:string|null,checkoutState:'open'|'paid'|'expired'|'complete'){
 return {orderId:order.id,state:order.state,checkoutUrl,checkoutState,provider:'alipay' as const,currency:'CNY' as const,amountCents:order.amount_cents,settlementCurrency:'CNY' as const,settlementAmountCents:order.amount_cents,billingMode:'manual' as const};
}
export async function createAlipayCheckout(env:Env,userId:string,input:OrderInput,runtime:PaymentRuntime={}){
 const config=await loadAlipayConfiguration(env),order=await createOrder(env.DB,userId,input,config.id,now(runtime),'alipay');return resumeAlipayCheckout(env,userId,order.id,{...runtime,checkoutChannel:input.checkoutChannel??runtime.checkoutChannel});
}
export async function resumeAlipayCheckout(env:Env,userId:string,orderId:string,runtime:PaymentRuntime={}){
 let order=await getOrder(env.DB,orderId,userId);if(order.state==='paid'&&order.fulfilled_at)return checkoutResult(order,null,'paid');
 assert(['created','pending','expired'].includes(order.state),'ORDER_NOT_PAYABLE','订单需要核对，不能继续付款',409);const config=await loadAlipayConfiguration(env,order.config_version_id);const p=await payment(env,order,config,runtime);
 if(p.checkout_published_at){order=await reconcileAlipayOrder(env,userId,orderId,runtime);if(order.state==='paid')return checkoutResult(order,null,'paid');if(order.state==='expired')return checkoutResult(order,null,'expired');assert(['created','pending'].includes(order.state),'ORDER_NOT_PAYABLE','订单已变化，请核对',409);}
 assert(Date.parse(order.expires_at)>now(runtime)&&order.state!=='expired','ORDER_EXPIRED','订单已到期，请核对原付款',409);
 assert(await env.DB.prepare("SELECT 1 FROM users WHERE id=? AND status='active'").bind(userId).first(),'PURCHASE_NOT_ALLOWED','当前账户不能继续付款',403);
 if(order.kind==='topup')assert(await canTopup(env.DB,userId,iso(runtime)),'TOPUP_MEMBERSHIP_REQUIRED','充值需要有效付费会员',403);
 if(order.kind==='subscription')assert(!await env.DB.prepare("SELECT 1 FROM membership_freezes WHERE user_id=? AND state<>'completed'").bind(userId).first(),'MEMBERSHIP_FROZEN','会员暂停期间不能付款',409);
 const origin=new URL(env.APP_ORIGIN);assert(origin.protocol==='https:'||(env.APP_ENV!=='production'&&origin.protocol==='http:'),'PAYMENT_ORIGIN_INVALID','支付回调需要正式HTTPS域名',503);
 const wap=runtime.checkoutChannel==='wap';const params=await signedAlipayParams(config,wap?'alipay.trade.wap.pay':'alipay.trade.page.pay',{
  out_trade_no:order.id,product_code:wap?'QUICK_WAP_WAY':'FAST_INSTANT_TRADE_PAY',total_amount:amountString(order.amount_cents),subject:`Benos ${orderPlanSnapshot(order).name}`,seller_id:config.sellerId,time_expire:alipayTimestamp(Date.parse(order.expires_at)),...(wap?{quit_url:`${origin.origin}/app/billing?order=${encodeURIComponent(order.id)}`}:{})
 },{notify_url:`${origin.origin}/api/webhooks/alipay/${encodeURIComponent(config.id)}`,return_url:`${origin.origin}/app/billing?order=${encodeURIComponent(order.id)}`},now(runtime));
 // Publication marker precedes returning any signed URL. Cancellation cannot mistake
 // an already issued but not yet opened gateway URL for an uncreated checkout.
 const guard=id('ali_checkout');await env.DB.batch([
  env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM orders WHERE id=? AND state IN ('created','pending') AND expires_at>?) THEN 1 ELSE 0 END`).bind(guard,order.id,iso(runtime)),
  env.DB.prepare('UPDATE alipay_payments SET checkout_published_at=COALESCE(checkout_published_at,?),updated_at=? WHERE order_id=?').bind(iso(runtime),iso(runtime),order.id),
  env.DB.prepare("UPDATE orders SET checkout_id=COALESCE(checkout_id,?),state='pending' WHERE id=? AND state IN ('created','pending')").bind(order.id,order.id),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
 ]);order=await getOrder(env.DB,order.id,userId);assert(order.state==='pending','ORDER_NOT_PAYABLE','订单状态已变化',409);
 return checkoutResult(order,ALIPAY_GATEWAYS[config.mode]+'?'+new URLSearchParams(params).toString(),'open');
}
function checkTrade(order:Order,p:PaymentRow,result:AlipayJson){
 assert(result.out_trade_no===order.id&&typeof result.trade_no==='string'&&/^\d{16,64}$/.test(result.trade_no)&&(!p.trade_no||p.trade_no===result.trade_no),'PAYMENT_IDENTITY_MISMATCH','支付宝交易与订单不匹配',409);
 assert(amountCents(result.total_amount)===p.amount_cents,'PAYMENT_AMOUNT_MISMATCH','支付宝金额与订单不一致',409);
 for(const field of ['trans_currency','settle_currency'])if(result[field]!==undefined)assert(result[field]==='CNY','PAYMENT_CURRENCY_MISMATCH','支付宝币种与人民币订单不匹配',409);
 if(result.seller_id!==undefined)assert(result.seller_id===p.seller_id,'PAYMENT_IDENTITY_MISMATCH','支付宝收款方不匹配',409);
 if(result.app_id!==undefined)assert(result.app_id===p.app_id,'PAYMENT_IDENTITY_MISMATCH','支付宝应用不匹配',409);
 assert(['WAIT_BUYER_PAY','TRADE_SUCCESS','TRADE_FINISHED','TRADE_CLOSED'].includes(String(result.trade_status)),'PAYMENT_PROVIDER_UNCONFIRMED','支付宝交易状态待确认',503);
}
async function recordReview(env:Env,order:Order,reference:string,reason:string,runtime:PaymentRuntime){
 const caseId=`ali_review_${await sha256(order.id+':'+reference)}`,time=iso(runtime);await env.DB.batch([
  env.DB.prepare(`INSERT INTO financial_cases(id,provider,kind,provider_object_id,config_version_id,order_id,user_id,provider_state,amount_cents,currency,reason,snapshot_json,snapshot_hash,created_at,updated_at) VALUES(?,'alipay','payment_review',?,?,?,?,'unreconciled',?,'CNY',?,'{}','review',?,?) ON CONFLICT(provider,kind,provider_object_id) DO NOTHING`).bind(caseId,reference,order.config_version_id,order.id,order.user_id,order.amount_cents,reason,time,time),
  env.DB.prepare("UPDATE orders SET state='review' WHERE id=? AND state NOT IN ('paid','refunded')").bind(order.id)
 ]);
}
async function fulfillAlipay(env:Env,order:Order,p:PaymentRow,result:AlipayJson,runtime:PaymentRuntime){
 if(order.state==='paid'&&order.fulfilled_at)return;
 assert(!['refunded','review'].includes(order.state),'PAYMENT_REVIEW','订单需人工核对',409);
 assert(result.additional_status!=='SELLER_NOT_RECEIVED','PAYMENT_NOT_SETTLED','卖家收款尚未确认',409);
 // send_pay_date is optional in trade.query. Keep an otherwise valid payment
 // retryable until either a signed query or notification supplies its paid time.
 const paidAt=result.send_pay_date?alipayTime(result.send_pay_date):p.paid_at;assert(paidAt,'PAYMENT_PROVIDER_UNCONFIRMED','支付宝付款时间仍待通知或查询确认',503);
 assert(Date.parse(paidAt)<=now(runtime)+300000,'PAYMENT_TIME_INVALID','支付宝付款时间不合理',409);
 if(order.kind==='topup'){assert(order.eligible_until!==null&&paidAt<order.eligible_until&&await canTopup(env.DB,order.user_id,paidAt),'TOPUP_MEMBERSHIP_EXPIRED','付款时充值资格已到期，请核对或退款',409);}
 let starts=paidAt,ends:string|null=null,activation:'create'|'resume'|null=null;
 if(order.kind==='subscription'){
  assert(!await env.DB.prepare("SELECT 1 FROM payment_agreements WHERE user_id=? AND state<>'cancelled'").bind(order.user_id).first(),'SUBSCRIPTION_CONFLICT','原自动续费协议尚未关闭，付款需要核对',409);
  assert(!await env.DB.prepare("SELECT 1 FROM subscriptions WHERE user_id=? AND source='paid' AND state IN ('active','cancelled') AND ends_at>? AND tier<>? AND membership_frozen_by IS NULL").bind(order.user_id,paidAt,order.plan_tier).first(),'SUBSCRIPTION_CONFLICT','套餐等级已变化，付款需要核对',409);
 }else if(order.kind==='hosting'){
  assert(await env.DB.prepare('SELECT 1 FROM sites WHERE id=? AND user_id=?').bind(order.hosting_site_id,order.user_id).first(),'HOSTING_SITE_RELEASED','网站待付款申请已释放，需要核对或退款',409);
  const billing=await import('./hosting-billing');const previous=await env.DB.prepare('SELECT starts_at,ends_at FROM payment_fulfillments WHERE order_id=?').bind(order.id).first<{starts_at:string;ends_at:string}>();
  // Use the same coverage placement as historical Stripe payments: a year
  // stranded after an early-ended membership moves forward before a new year
  // is chained. A maintenance retry covers transient non-conflict failures.
  if(!previous)for(let attempt=0;attempt<2;attempt++)try{await billing.rescheduleUncoveredAnnualYears(env.DB,order.user_id,order.hosting_site_id!,Date.parse(paidAt));break;}catch(error){if(!(error instanceof billing.AnnualMoveConflict)){console.warn('hosting pull-forward before placement failed; maintenance will retry',String(error));break;}}
  const plan=await billing.annualRenewalPlan(env.DB,order.user_id,order.hosting_site_id!,Date.parse(paidAt),order.id);if(plan){starts=plan.startsAt;activation=plan.activation;}
  if(previous){if(previous.starts_at!==starts)activation=null;starts=previous.starts_at;ends=previous.ends_at;}else{const date=new Date(starts),month=date.getUTCMonth();date.setUTCFullYear(date.getUTCFullYear()+1);if(date.getUTCMonth()!==month)date.setUTCDate(0);ends=date.toISOString();}
 }
 await completeFulfillment(env,order,`alipay:${result.trade_no}`,starts,ends,runtime,{autoRenew:false,paidAt,activation});
}
/** Always query server-side; browser return parameters never grant entitlements. */
export async function reconcileAlipayOrder(env:Env,userId:string,orderId:string,runtime:PaymentRuntime={}){
 const order=await getOrder(env.DB,orderId,userId),config=await loadAlipayConfiguration(env,order.config_version_id),p=await payment(env,order,config,runtime);
 const result=await alipayRequest(config,'alipay.trade.query',{out_trade_no:order.id},runtime);const next=new Date(now(runtime)+5*60000).toISOString();await env.DB.prepare('UPDATE alipay_payments SET next_reconcile_at=?,updated_at=? WHERE order_id=?').bind(next,iso(runtime),order.id).run();
 if(result.code==='40004'&&result.sub_code==='ACQ.TRADE_NOT_EXIST'){
  if(!p.trade_no&&Date.parse(order.expires_at)<=now(runtime))await env.DB.prepare("UPDATE orders SET state='expired' WHERE id=? AND state IN ('created','pending')").bind(order.id).run();
  return getOrder(env.DB,order.id,userId);
 }
 assert(result.code==='10000','PAYMENT_PROVIDER_UNCONFIRMED','支付宝订单结果待确认，请稍后查询原订单',503);checkTrade(order,p,result);
 const paid=typeof result.send_pay_date==='string'?alipayTime(result.send_pay_date):null;
 await env.DB.prepare(`UPDATE alipay_payments SET trade_no=COALESCE(trade_no,?),trade_status=?,paid_at=COALESCE(paid_at,?),verified_at=?,updated_at=? WHERE order_id=? AND (trade_no IS NULL OR trade_no=?)`).bind(String(result.trade_no),String(result.trade_status),paid,iso(runtime),iso(runtime),order.id,String(result.trade_no)).run();
 if(result.trade_status==='TRADE_SUCCESS'||result.trade_status==='TRADE_FINISHED'){
  try{await fulfillAlipay(env,order,p,result,runtime);}catch(error){if(error instanceof AppError&&error.status===409){await recordReview(env,order,String(result.trade_no),error.code,runtime);return getOrder(env.DB,order.id,userId);}throw error;}
 }else if(result.trade_status==='TRADE_CLOSED'){
  if(order.fulfilled_at||p.paid_at){await recordReview(env,order,String(result.trade_no),'ALIPAY_CLOSED_AFTER_PAYMENT',runtime);}else await env.DB.prepare("UPDATE orders SET state='expired' WHERE id=? AND state IN ('created','pending')").bind(order.id).run();
 }
 return getOrder(env.DB,order.id,userId);
}
export async function closeAlipayOrder(env:Env,userId:string,orderId:string,runtime:PaymentRuntime={}):Promise<'paid'|'closed'>{
 let order=await getOrder(env.DB,orderId,userId);if(['paid','review','refunded'].includes(order.state))return 'paid';const config=await loadAlipayConfiguration(env,order.config_version_id),p=await payment(env,order,config,runtime);
 if(!p.checkout_published_at){const changed=await env.DB.prepare("UPDATE orders SET state='expired',checkout_url=NULL WHERE id=? AND state IN ('created','pending') AND NOT EXISTS(SELECT 1 FROM alipay_payments WHERE order_id=? AND checkout_published_at IS NOT NULL) RETURNING id").bind(order.id,order.id).first();if(changed||order.state==='expired')return 'closed';}
 order=await reconcileAlipayOrder(env,userId,order.id,runtime);if(['paid','review','refunded'].includes(order.state))return 'paid';if(order.state==='expired')return 'closed';
 const result=await alipayRequest(config,'alipay.trade.close',{out_trade_no:order.id},runtime);
 if(result.code!=='10000'){
  if(result.sub_code==='ACQ.TRADE_HAS_SUCCESS'){await reconcileAlipayOrder(env,userId,order.id,runtime);return 'paid';}
  // TRADE_NOT_EXIST is NOT a tombstone: an already issued signed page-pay URL
  // can still create a trade until its immutable time_expire.
  throw new AppError('PAYMENT_PROVIDER_UNCONFIRMED','支付关闭尚待确认，请等待原付款有效期结束后核对',503);
 }
 assert(result.out_trade_no===order.id,'PAYMENT_IDENTITY_MISMATCH','关闭结果与订单不匹配',409);await env.DB.prepare("UPDATE orders SET state='expired',checkout_url=NULL WHERE id=? AND state IN ('created','pending')").bind(order.id).run();return ['paid','review','refunded'].includes((await getOrder(env.DB,order.id,userId)).state)?'paid':'closed';
}
export async function handleAlipayWebhook(env:Env,configId:string,raw:string,runtime:PaymentRuntime={}){
 const config=await loadAlipayConfiguration(env,configId),fields=await verifiedAlipayNotification(raw,config),order=await getOrder(env.DB,fields.out_trade_no),p=await payment(env,order,config,runtime);checkTrade(order,p,{...fields,total_amount:fields.total_amount});
 assert(typeof fields.notify_id==='string'&&/^[A-Za-z0-9_-]{8,256}$/.test(fields.notify_id),'WEBHOOK_INVALID','支付宝通知编号无效',400);
 const eventId=fields.notify_id,eventKey=`ali_event_${await sha256(configId+':'+eventId)}`,time=iso(runtime),payload={out_trade_no:order.id,trade_no:fields.trade_no,trade_status:fields.trade_status,total_amount:fields.total_amount,app_id:fields.app_id,seller_id:fields.seller_id,gmt_payment:fields.gmt_payment??null};
 const hash=await sha256(JSON.stringify(payload));await env.DB.prepare(`INSERT INTO payment_events(id,provider,event_id,order_id,event_type,payload_hash,state,received_at,config_version_id,payload_json) VALUES(?,'alipay',?,?,?,?,'received',?,?,?) ON CONFLICT(provider,event_id) DO UPDATE SET payload_hash=CASE WHEN payment_events.payload_hash=excluded.payload_hash AND payment_events.config_version_id=excluded.config_version_id THEN payment_events.payload_hash ELSE NULL END`).bind(eventKey,eventId,order.id,fields.trade_status,hash,time,configId,JSON.stringify(payload)).run();
 const stored=await env.DB.prepare("SELECT state FROM payment_events WHERE provider='alipay' AND event_id=?").bind(eventId).first<{state:string}>();if(stored?.state==='processed'||stored?.state==='review')return {received:true,state:stored.state};
 // Notification carries merchant identity; query confirms latest status. Reordered
 // notifications cannot turn a full refund into a fresh paid entitlement.
 if(fields.gmt_payment)await env.DB.prepare('UPDATE alipay_payments SET paid_at=COALESCE(paid_at,?) WHERE order_id=?').bind(alipayTime(fields.gmt_payment),order.id).run();
 const verified=await reconcileAlipayOrder(env,order.user_id,order.id,runtime);const state=verified.state==='review'?'review':'processed';
 await env.DB.prepare("UPDATE payment_events SET state=?,processed_at=? WHERE provider='alipay' AND event_id=? AND state='received'").bind(state,time,eventId).run();return {received:true,state};
}
export const alipayWebhookRoutes=new Hono<App>();
alipayWebhookRoutes.post('/:configId',async c=>{
 if(!c.req.header('content-type')?.toLowerCase().startsWith('application/x-www-form-urlencoded'))return c.text('failure',415);
 try{await handleAlipayWebhook(c.env,c.req.param('configId'),await c.req.text(),backgroundRuntime(c));return c.text('success',200);}catch(error){const status=error instanceof AppError&&error.status<500?400:503;return c.text('failure',status);}
});

function refundView(row:RefundRow){return {id:row.id,orderId:row.order_id,requestKey:row.request_key,amountCents:row.amount_cents,currency:row.currency,state:row.state,providerState:row.provider_state,errorCode:row.last_error_code,createdAt:row.created_at,updatedAt:row.updated_at,entitlementsRequireReview:true};}
async function readRefund(env:Env,refundId:string){const row=await env.DB.prepare('SELECT * FROM alipay_refunds WHERE id=?').bind(refundId).first<RefundRow>();assert(row,'NOT_FOUND','退款记录不存在',404);return row;}
async function recordRefundCase(env:Env,row:RefundRow,runtime:PaymentRuntime){const order=await getOrder(env.DB,row.order_id),time=iso(runtime),snapshot={refundId:row.id,tradeNo:row.trade_no,amountCents:row.amount_cents,currency:'CNY',state:'REFUND_SUCCESS'},raw=JSON.stringify(snapshot);await env.DB.batch([
 env.DB.prepare(`INSERT INTO financial_cases(id,provider,kind,provider_object_id,config_version_id,order_id,user_id,payment_intent_id,provider_state,amount_cents,currency,reason,snapshot_json,snapshot_hash,created_at,updated_at) VALUES(?,'alipay','refund',?,?,?,?,?,'succeeded',?,'CNY',?,?,?,?,?) ON CONFLICT(provider,kind,provider_object_id) DO NOTHING`).bind(`case_${row.id}`,row.id,row.config_version_id,order.id,order.user_id,`alipay:${row.trade_no}`,row.amount_cents,row.reason,raw,await sha256(raw),time,time),
 env.DB.prepare("UPDATE orders SET state='refunded' WHERE id=? AND (SELECT COALESCE(SUM(amount_cents),0) FROM alipay_refunds WHERE order_id=? AND state='succeeded')>=amount_cents").bind(order.id,order.id)
 ]);}
export const alipayRefundInput=z.object({amountCents:z.number().int().positive().max(100_000_000),reason:z.string().trim().min(3).max(256),requestKey:z.string().regex(/^[\w:-]{8,128}$/),confirmFinancialImpact:z.literal(true)}).strict();
export async function requestAlipayRefund(env:Env,actorId:string,orderId:string,input:z.infer<typeof alipayRefundInput>,runtime:PaymentRuntime={}){
 const parsed=alipayRefundInput.parse(input);assert(await env.DB.prepare("SELECT 1 FROM users WHERE id=? AND role='owner' AND status='active'").bind(actorId).first(),'FORBIDDEN','只有所有者可以发起退款',403);
 const order=await getOrder(env.DB,orderId);assert(order.provider==='alipay'&&order.currency==='CNY','PAYMENT_PROVIDER_MISMATCH','该接口只处理支付宝人民币退款',409);
 const hash=await sha256(JSON.stringify({orderId,amountCents:parsed.amountCents,reason:parsed.reason}));const existing=await env.DB.prepare('SELECT * FROM alipay_refunds WHERE actor_id=? AND request_key=?').bind(actorId,parsed.requestKey).first<RefundRow>();
 if(existing){assert(existing.payload_hash===hash,'IDEMPOTENCY_CONFLICT','退款编号已用于其他请求',409);return resumeAlipayRefund(env,existing.id,runtime);}
 const paid=await reconcileAlipayOrder(env,order.user_id,order.id,runtime);const p=await env.DB.prepare('SELECT * FROM alipay_payments WHERE order_id=?').bind(order.id).first<PaymentRow>();assert(p?.trade_no&&p.paid_at&&['TRADE_SUCCESS','TRADE_FINISHED'].includes(p.trade_status??'')&&['paid','review'].includes(paid.state),'PAYMENT_NOT_SETTLED','付款尚未确认，不可发起退款',409);
 const refundId=`ali_ref_${(await sha256(actorId+':'+parsed.requestKey)).slice(0,40)}`,time=iso(runtime),guard=id('refund_guard');
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN ?<=amount_cents-COALESCE((SELECT SUM(amount_cents) FROM alipay_refunds WHERE order_id=? AND state IN ('pending','uncertain','succeeded')),0) THEN 1 ELSE 0 END FROM orders WHERE id=?`).bind(guard,parsed.amountCents,order.id,order.id),
  env.DB.prepare(`INSERT INTO alipay_refunds(id,order_id,config_version_id,actor_id,request_key,payload_hash,trade_no,amount_cents,currency,reason,state,created_at,updated_at,next_reconcile_at) VALUES(?,?,?,?,?,?,?,?,'CNY',?,'pending',?,?,?)`).bind(refundId,order.id,order.config_version_id,actorId,parsed.requestKey,hash,p.trade_no,parsed.amountCents,parsed.reason,time,time,time),
  auditStatement(env.DB,actorId,'alipay.refund_requested','order',order.id,{refundId,amountCents:parsed.amountCents,currency:'CNY',reason:parsed.reason},parsed.requestKey),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
 ]);}catch(error){if(String(error).includes('mutation_revision_ok'))throw new AppError('REFUND_AMOUNT_EXCEEDED','退款与待核对退款总额超过原订单金额',409);throw error;}
 return resumeAlipayRefund(env,refundId,runtime);
}
export async function resumeAlipayRefund(env:Env,refundId:string,runtime:PaymentRuntime={}){
 let row=await readRefund(env,refundId);if(row.state==='succeeded'){await recordRefundCase(env,row,runtime);return refundView(row);}if(row.state==='failed')return refundView(row);
 const config=await loadAlipayConfiguration(env,row.config_version_id),query={out_trade_no:row.order_id,trade_no:row.trade_no,out_request_no:row.id};
 try{
  let result=await alipayRequest(config,'alipay.trade.fastpay.refund.query',query,runtime);
  if(result.code==='40004'&&['ACQ.REFUND_NOT_EXIST','ACQ.TRADE_NOT_EXIST'].includes(String(result.sub_code))){
   // Durable out_request_no is retained on every retry, including timeouts.
   result=await alipayRequest(config,'alipay.trade.refund',{...query,refund_amount:amountString(row.amount_cents),refund_reason:row.reason},runtime);
   assert(result.code==='10000','REFUND_PROVIDER_UNCONFIRMED','支付宝退款结果待确认，请核对同一退款编号',503);
   assert(result.out_trade_no===row.order_id&&result.trade_no===row.trade_no&&amountCents(result.refund_fee)===row.amount_cents,'REFUND_IDENTITY_MISMATCH','支付宝退款响应与请求不一致',409);
   result=await alipayRequest(config,'alipay.trade.fastpay.refund.query',query,runtime);
  }
  assert(result.code==='10000'&&result.out_request_no===row.id&&result.out_trade_no===row.order_id&&result.trade_no===row.trade_no&&amountCents(result.refund_amount)===row.amount_cents,'REFUND_PROVIDER_UNCONFIRMED','支付宝退款查询仍待确认',503);
  assert(result.refund_status==='REFUND_SUCCESS','REFUND_PROVIDER_UNCONFIRMED','支付宝退款尚未确认成功',503);
  await env.DB.prepare("UPDATE alipay_refunds SET state='succeeded',provider_state='REFUND_SUCCESS',last_error_code=NULL,updated_at=? WHERE id=? AND state IN ('pending','uncertain')").bind(iso(runtime),row.id).run();row=await readRefund(env,row.id);await recordRefundCase(env,row,runtime);return refundView(row);
 }catch(error){await env.DB.prepare("UPDATE alipay_refunds SET state='uncertain',last_error_code=?,updated_at=?,next_reconcile_at=? WHERE id=? AND state IN ('pending','uncertain')").bind(error instanceof AppError?error.code:'REFUND_PROVIDER_UNCONFIRMED',iso(runtime),new Date(now(runtime)+5*60000).toISOString(),row.id).run();throw error;}
}
/** Cron is bounded; each uncertain operation remains visible and retryable. */
export async function reconcilePendingAlipay(env:Env,runtime:PaymentRuntime={}){
 const refunds=(await env.DB.prepare("SELECT id FROM alipay_refunds WHERE state IN ('pending','uncertain','succeeded') AND next_reconcile_at<=? AND (state<>'succeeded' OR NOT EXISTS(SELECT 1 FROM financial_cases WHERE id='case_'||alipay_refunds.id)) ORDER BY next_reconcile_at LIMIT 5").bind(iso(runtime)).all<{id:string}>()).results;
 const orders=(await env.DB.prepare("SELECT o.id,o.user_id FROM orders o JOIN alipay_payments p ON p.order_id=o.id WHERE o.provider='alipay' AND o.state IN ('created','pending') AND p.checkout_published_at IS NOT NULL AND p.next_reconcile_at<=? ORDER BY p.next_reconcile_at LIMIT 10").bind(iso(runtime)).all<{id:string;user_id:string}>()).results;let completed=0,failed=0;
 for(const refund of refunds)try{await resumeAlipayRefund(env,refund.id,runtime);completed++;}catch{failed++;}
 for(const order of orders)try{await reconcileAlipayOrder(env,order.user_id,order.id,runtime);completed++;}catch{await env.DB.prepare('UPDATE alipay_payments SET next_reconcile_at=? WHERE order_id=?').bind(new Date(now(runtime)+5*60000).toISOString(),order.id).run();failed++;}
 return {completed,failed};
}
export const alipayAdminRoutes=new Hono<App>();alipayAdminRoutes.use('*',requireAuth,requireRole('owner'));
alipayAdminRoutes.post('/orders/:id/refunds',async c=>{await rateLimit(c,'alipay-refund',20,3600,c.get('auth').user.id);return ok(c,await requestAlipayRefund(c.env,c.get('auth').user.id,c.req.param('id'),await body(c,alipayRefundInput),backgroundRuntime(c)),201);});
alipayAdminRoutes.get('/refunds',async c=>{const requestKey=c.req.query('requestKey'),orderId=c.req.query('orderId');assert(!requestKey||/^[\w:-]{8,128}$/.test(requestKey),'VALIDATION','退款请求编号无效');assert(!orderId||/^[A-Za-z0-9_:-]{1,128}$/.test(orderId),'VALIDATION','订单编号无效');const rows=await c.env.DB.prepare(`SELECT * FROM alipay_refunds WHERE (? IS NULL OR request_key=?) AND (? IS NULL OR order_id=?) ORDER BY created_at DESC,id DESC LIMIT 100`).bind(requestKey??null,requestKey??null,orderId??null,orderId??null).all<RefundRow>();return ok(c,{items:rows.results.map(refundView),limit:100,filtered:!!requestKey||!!orderId});});
alipayAdminRoutes.post('/refunds/:id/reconcile',async c=>{await rateLimit(c,'alipay-refund-reconcile',60,3600,c.get('auth').user.id);await body(c,z.object({}).strict());return ok(c,await resumeAlipayRefund(c.env,c.req.param('id'),backgroundRuntime(c)));});
