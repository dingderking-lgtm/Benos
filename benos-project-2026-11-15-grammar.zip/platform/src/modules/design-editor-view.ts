import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { body,ok,type App } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id,sha256,base64url,unbase64url } from '../lib/crypto';
import { withDesignMemoryBudget } from '../lib/design-memory-budget';
import { readStoredManifestJson,designManifestObjectKey,prepareDesignManifestStorage,MAX_INLINE_MANIFEST_BYTES,type ManifestStorageRow,type ManifestObjectRow } from '../lib/design-storage';
import { requireAuth,rateLimit,restricted } from './auth';
import { ownedDesignProject } from './design-workspace';
import { DESIGN_FONTS,describeDesignNodePage,type DesignScope } from './design-nodes';
import { verifyProjectAssets } from './project-assets';
import { mediaReferencesAvailableStatement } from './media';
import { loadTypographySnapshot,copyTypographySnapshotStatement,typographyOptions } from '../lib/design-typography';

const PROJECTION_VERSION=1,MAX_PROJECTION_BYTES=256*1024;
const encoder=new TextEncoder();
export type EditorSource={versionId:string;candidateId?:never}|{candidateId:string;versionId?:never};
type SourceRow=ManifestStorageRow&{id:string;project_id:string;version?:number;user_id?:string;state?:string;base_version_id?:string|null;adopted_version_id?:string|null;scope_json?:string;created_at:string};
type SourceIndex={kind:'version'|'candidate';row:SourceRow;hash:string;byteSize:number;project:Awaited<ReturnType<typeof ownedDesignProject>>};
type Projection={site:{name:string;home:string|null;header_template_id:number|null;footer_template_id:number|null;pages:Array<{key:string;slug:string;title:string;type:string;template_id:number}>;blog:null|{enabled:boolean}};templates:Array<{id:number;name:string;type:string}>;assets:Array<{file:string;path:string;sha256:string;size:number}>;pageOptions:Array<{key:string;label:string}>};
type CacheRow={source_hash:string;source_bytes:number;projection_json:string;projection_hash:string};
type RestoreRow={id:string;user_id:string;project_id:string;request_key:string;request_hash:string;source_version_id:string;source_hash:string;expected_current_version_id:string|null;result_version_id:string};
export type RestoreDesignInput={requestKey:string;sourceVersionId:string;expectedCurrentVersionId:string|null};

async function permittedProject(env:Env,userId:string,projectId:string){
 const project=await ownedDesignProject(env,userId,projectId);
 assert(!await restricted(env.DB,userId,'login'),'ACCOUNT_RESTRICTED','该账户暂时无法修改或读取设计',403);
 return project;
}
function sourceChoice(input:EditorSource){assert(!!input.versionId!==!!input.candidateId,'VALIDATION','请选择一个版本或候选方案');return input.versionId?{kind:'version' as const,id:input.versionId}:{kind:'candidate' as const,id:input.candidateId!};}
async function sourceIndex(env:Env,userId:string,projectId:string,input:EditorSource):Promise<SourceIndex>{
 const project=await permittedProject(env,userId,projectId),source=sourceChoice(input);
 const row=source.kind==='version'?await env.DB.prepare('SELECT id,project_id,version,manifest_json,manifest_object_id,content_hash,created_at FROM design_versions WHERE id=? AND project_id=?').bind(source.id,projectId).first<SourceRow>():await env.DB.prepare('SELECT id,user_id,project_id,state,base_version_id,adopted_version_id,scope_json,manifest_json,manifest_object_id,created_at FROM design_candidates WHERE id=? AND project_id=? AND user_id=?').bind(source.id,projectId,userId).first<SourceRow>();
 assert(row,'NOT_FOUND','设计来源不存在',404);let hash:string,byteSize:number;
 if(row.manifest_object_id){
  const object=await env.DB.prepare('SELECT * FROM design_manifest_objects WHERE id=?').bind(row.manifest_object_id).first<ManifestObjectRow>();
  assert(object&&object.state==='ready'&&object.user_id===userId&&object.project_id===projectId&&object.index_json===row.manifest_json&&object.object_key===designManifestObjectKey({userId,projectId},object.id,object.sha256),'DESIGN_STORAGE_CORRUPT','设计来源索引校验失败',503);
  let index:any;try{index=JSON.parse(row.manifest_json);}catch{throw new AppError('DESIGN_STORAGE_CORRUPT','设计来源索引无法读取',503);}
  assert(index.format==='benos-manifest-ref'&&index.version===1&&index.objectId===object.id&&index.sha256===object.sha256&&index.byteSize===object.byte_size,'DESIGN_STORAGE_CORRUPT','设计来源索引校验失败',503);
  hash=object.sha256;byteSize=object.byte_size;
 }else{hash=await sha256(row.manifest_json);byteSize=encoder.encode(row.manifest_json).byteLength;}
 assert(byteSize>0&&byteSize<=10*1048576&&(!row.content_hash||row.content_hash===hash),'DESIGN_STORAGE_CORRUPT','设计来源摘要或容量不一致',503);
 return {kind:source.kind,row,hash,byteSize,project};
}
async function sourceManifest(env:Env,userId:string,projectId:string,source:SourceIndex){
 const json=await readStoredManifestJson(env,source.row,{userId,projectId});
 assert(await sha256(json)===source.hash&&encoder.encode(json).byteLength===source.byteSize,'DESIGN_STORAGE_CORRUPT','设计原字节与来源摘要不一致',503);
 return JSON.parse(json);
}
function projectManifest(manifest:any):Projection{
 assert(manifest&&manifest.site&&Array.isArray(manifest.site.pages)&&Array.isArray(manifest.templates)&&Array.isArray(manifest.assets),'DESIGN_STORAGE_CORRUPT','设计摘要结构不完整',503);
 const site=manifest.site,hasBlog=!!site.blog&&typeof site.blog==='object'&&!Array.isArray(site.blog);
 const pages=site.pages.map((page:any)=>({key:page.key,slug:page.slug||'',title:String(page.title||page.key).slice(0,180),type:page.type||'page',template_id:page.template_id}));
 const pageOptions=pages.map((page:Projection['site']['pages'][number])=>({key:page.key,label:page.title+(page.type==='article'?'（文章详情）':'')}));
 if(hasBlog&&site.blog.enabled!==false)pageOptions.push({key:'__blog_archive',label:'博客归档'},{key:'__blog_author',label:'博客作者页'});
 if(hasBlog&&!pages.some((page:Projection['site']['pages'][number])=>page.type==='article'))pageOptions.push({key:'__blog_article',label:'文章详情（示例）'});
 return {site:{name:String(site.name||'').slice(0,180),home:site.home??null,header_template_id:site.header_template_id??null,footer_template_id:site.footer_template_id??null,pages,blog:hasBlog?{enabled:site.blog.enabled!==false}:null},templates:manifest.templates.map((t:any)=>({id:t.id,name:String(t.name||'').slice(0,180),type:t.type})),assets:manifest.assets.map((a:any)=>({file:a.file,path:a.path,sha256:a.sha256,size:a.size})),pageOptions};
}
function candidateView(source:SourceIndex){const row=source.row;return source.kind==='candidate'?{id:row.id,state:row.state!,baseVersionId:row.base_version_id??null,versionId:row.adopted_version_id??null,scope:JSON.parse(row.scope_json!) as DesignScope,createdAt:row.created_at}:null;}
export async function getDesignEditorView(env:Env,userId:string,projectId:string,input:EditorSource){
 const source=await sourceIndex(env,userId,projectId,input),cached=await env.DB.prepare('SELECT source_hash,source_bytes,projection_json,projection_hash FROM design_editor_projections WHERE user_id=? AND project_id=? AND source_kind=? AND source_id=? AND projection_version=?').bind(userId,projectId,source.kind,source.row.id,PROJECTION_VERSION).first<CacheRow>();
 let projection:Projection|undefined;
 if(cached&&cached.source_hash===source.hash&&cached.source_bytes===source.byteSize&&await sha256(cached.projection_json)===cached.projection_hash){try{projection=JSON.parse(cached.projection_json);}catch{/* A derived cache can be regenerated from the immutable source. */}}
 if(!projection)projection=await withDesignMemoryBudget(async()=>{
  const value=projectManifest(await sourceManifest(env,userId,projectId,source)),json=JSON.stringify(value);
  assert(encoder.encode(json).byteLength<=MAX_PROJECTION_BYTES,'EDITOR_PROJECTION_LIMIT','编辑摘要超过安全容量',413);
  await permittedProject(env,userId,projectId);
  await env.DB.prepare('INSERT INTO design_editor_projections(user_id,project_id,source_kind,source_id,version_id,candidate_id,source_hash,source_bytes,projection_version,projection_json,projection_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,project_id,source_kind,source_id,projection_version) DO UPDATE SET source_hash=excluded.source_hash,source_bytes=excluded.source_bytes,projection_json=excluded.projection_json,projection_hash=excluded.projection_hash').bind(userId,projectId,source.kind,source.row.id,source.kind==='version'?source.row.id:null,source.kind==='candidate'?source.row.id:null,source.hash,source.byteSize,PROJECTION_VERSION,json,await sha256(json),new Date().toISOString()).run();return value;
 });
 const current=await permittedProject(env,userId,projectId);
 // Candidate state and current head are live metadata, never served from cache.
 let candidate=candidateView(source);if(candidate){const latest=await env.DB.prepare('SELECT state,adopted_version_id FROM design_candidates WHERE id=? AND user_id=? AND project_id=?').bind(source.row.id,userId,projectId).first<{state:string;adopted_version_id:string|null}>();assert(latest,'NOT_FOUND','设计方案不存在',404);candidate={...candidate,state:latest.state,versionId:latest.adopted_version_id};}
 const typography=await loadTypographySnapshot(env,userId,projectId,source.kind,source.row.id,source.hash);
 return {projectionVersion:PROJECTION_VERSION,sourceKind:source.kind,sourceId:source.row.id,contentHash:source.hash,sourceHash:source.hash,byteSize:source.byteSize,currentVersionId:current.current_version_id,version:source.kind==='version'?source.row.version:null,candidate,...projection,previewUrl:`/preview/${encodeURIComponent(projectId)}/${source.kind==='candidate'?'candidate/':''}${encodeURIComponent(source.row.id)}`,styleOptions:{fonts:DESIGN_FONTS,typography:typographyOptions(typography)}};
}
function encodeCursor(source:SourceIndex,templateId:number,after:number){return base64url(encoder.encode(JSON.stringify({v:1,sourceId:source.row.id,kind:source.kind,hash:source.hash,templateId,after})));}
function decodeCursor(cursor:string,source:SourceIndex,templateId:number){
 assert(cursor.length<=1000,'EDITOR_CURSOR_INVALID','区块游标无效');let value:any;try{value=JSON.parse(new TextDecoder('utf-8',{fatal:true,ignoreBOM:false}).decode(unbase64url(cursor)));}catch{throw new AppError('EDITOR_CURSOR_INVALID','区块游标无效',400);}
 assert(value?.v===1&&value.sourceId===source.row.id&&value.kind===source.kind&&value.hash===source.hash&&value.templateId===templateId,'EDITOR_CURSOR_STALE','设计来源已变化，请重新加载区块列表',409);
 assert(Number.isSafeInteger(value.after)&&value.after>=0,'EDITOR_CURSOR_INVALID','区块游标无效');return value.after as number;
}
export async function getDesignEditorNodes(env:Env,userId:string,projectId:string,input:EditorSource&{templateId:number;limit?:number;cursor?:string;nodeKey?:string}){
 assert(!input.cursor||!input.nodeKey,'VALIDATION','精确区块查询不能同时使用分页游标');
 const source=await sourceIndex(env,userId,projectId,input),after=input.cursor?decodeCursor(input.cursor,source,input.templateId):-1;
 return withDesignMemoryBudget(async()=>{
  const manifest=await sourceManifest(env,userId,projectId,source),typography=await loadTypographySnapshot(env,userId,projectId,source.kind,source.row.id,source.hash),page=describeDesignNodePage(manifest,{templateId:input.templateId,after,limit:input.limit,nodeKey:input.nodeKey,fontOverrides:typography?.overrides});await permittedProject(env,userId,projectId);
  return {projectionVersion:1,sourceKind:source.kind,sourceId:source.row.id,contentHash:source.hash,sourceHash:source.hash,templateId:input.templateId,items:page.items,nextCursor:page.nextAfter===null?null:encodeCursor(source,input.templateId,page.nextAfter),hasMore:page.hasMore};
 });
}
const liveOwnerSql="EXISTS(SELECT 1 FROM projects p WHERE p.id=? AND p.user_id=? AND p.archived_at IS NULL) AND NOT EXISTS(SELECT 1 FROM user_restrictions r WHERE r.user_id=? AND r.scope='login' AND r.revoked_at IS NULL AND r.starts_at<=? AND (r.ends_at IS NULL OR r.ends_at>?))";
export async function restoreDesignVersion(env:Env,userId:string,projectId:string,input:RestoreDesignInput){
 await permittedProject(env,userId,projectId);
 const requestHash=await sha256(JSON.stringify([projectId,input.sourceVersionId,input.expectedCurrentVersionId]));
 const prior=()=>env.DB.prepare('SELECT * FROM design_restore_requests WHERE user_id=? AND request_key=?').bind(userId,input.requestKey).first<RestoreRow>();
 const output=async(row:RestoreRow,replayed:boolean)=>{assert(row.project_id===projectId&&row.request_hash===requestHash,'IDEMPOTENCY_CONFLICT','恢复请求编号已用于其他来源或版本基线',409);const current=await permittedProject(env,userId,projectId);return {versionId:row.result_version_id,sourceVersionId:row.source_version_id,parentVersionId:row.expected_current_version_id,contentHash:row.source_hash,currentVersionId:current.current_version_id,replayed};};
 const previous=await prior();if(previous)return output(previous,true);
 return withDesignMemoryBudget(async()=>{
  const source=await sourceIndex(env,userId,projectId,{versionId:input.sourceVersionId});assert(source.project.current_version_id===input.expectedCurrentVersionId,'VERSION_CONFLICT','设计已有更新，请刷新后重新选择恢复基线',409);
  const manifest=await sourceManifest(env,userId,projectId,source);await verifyProjectAssets(env,userId,projectId,manifest);
  const storage=!source.row.manifest_object_id&&source.byteSize>MAX_INLINE_MANIFEST_BYTES?await prepareDesignManifestStorage(env,userId,projectId,manifest):{manifestJson:source.row.manifest_json,objectId:source.row.manifest_object_id??null};
  const versionId=id('ver'),guard=id('guard'),mediaGuard=id('guard'),now=new Date().toISOString();
  try{await env.DB.batch([
   env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN (${liveOwnerSql}) AND (EXISTS(SELECT 1 FROM projects WHERE id=? AND current_version_id IS ?) OR EXISTS(SELECT 1 FROM design_restore_requests WHERE user_id=? AND request_key=? AND project_id=? AND request_hash=?)) AND EXISTS(SELECT 1 FROM design_versions WHERE id=? AND project_id=? AND content_hash=?) THEN 1 ELSE 0 END`).bind(guard,projectId,userId,userId,now,now,projectId,input.expectedCurrentVersionId,userId,input.requestKey,projectId,requestHash,input.sourceVersionId,projectId,source.hash),
   mediaReferencesAvailableStatement(env.DB,userId,projectId,manifest,mediaGuard),
   env.DB.prepare("INSERT INTO design_versions(id,project_id,parent_id,version,source,manifest_json,manifest_object_id,content_hash,created_by,created_at) SELECT ?,?,?,COALESCE((SELECT MAX(version) FROM design_versions WHERE project_id=?),0)+1,'manual',?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM design_restore_requests WHERE user_id=? AND request_key=?)").bind(versionId,projectId,input.expectedCurrentVersionId,projectId,storage.manifestJson,storage.objectId,source.hash,userId,now,userId,input.requestKey),
   copyTypographySnapshotStatement(env.DB,{fromKind:'version',fromId:input.sourceVersionId,toKind:'version',toId:versionId,userId,projectId,manifestHash:source.hash,now}),
   env.DB.prepare('INSERT INTO design_restore_requests(id,user_id,project_id,request_key,request_hash,source_version_id,source_hash,expected_current_version_id,result_version_id,created_at) SELECT ?,?,?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM design_versions WHERE id=?)').bind(id('restore'),userId,projectId,input.requestKey,requestHash,input.sourceVersionId,source.hash,input.expectedCurrentVersionId,versionId,now,versionId),
   env.DB.prepare("UPDATE projects SET current_version_id=?,status=CASE WHEN published_version_id IS NULL THEN 'draft' ELSE 'modified' END,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM design_versions WHERE id=?)").bind(versionId,now,projectId,versionId),
   env.DB.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) SELECT ?,?,'design.version_restored','project',?,?,?,? WHERE EXISTS(SELECT 1 FROM design_versions WHERE id=?)").bind(id('audit'),userId,projectId,JSON.stringify({versionId,sourceVersionId:input.sourceVersionId,parentVersionId:input.expectedCurrentVersionId,contentHash:source.hash}),input.requestKey,now,versionId),
   env.DB.prepare('DELETE FROM mutation_guards WHERE id IN (?,?)').bind(guard,mediaGuard),
  ]);}catch(error){const committed=await prior();if(committed)return output(committed,true);if(String(error).includes('mutation_revision_ok'))throw new AppError('VERSION_CONFLICT','设计、账户权限或素材状态已变化，请刷新后重试',409);throw error;}
  const saved=await prior();assert(saved,'DESIGN_RESTORE_UNCONFIRMED','恢复结果尚未确认，请重试原请求',503);return output(saved,false);
 });
}

const sourceQuery=z.object({version:z.string().min(1).max(100).optional(),candidate:z.string().min(1).max(100).optional()}).refine(v=>!!v.version!==!!v.candidate,{message:'请选择一个版本或候选方案'});
function parseQuery<T>(schema:z.ZodType<T>,value:unknown):T{const parsed=schema.safeParse(value);assert(parsed.success,'VALIDATION',parsed.error?.issues[0]?.message||'查询参数无效');return parsed.data;}
function querySource(value:{version?:string;candidate?:string}):EditorSource{return value.version?{versionId:value.version}:{candidateId:value.candidate!};}
const restoreSchema=z.object({requestKey:z.string().regex(/^[A-Za-z0-9:_-]{16,128}$/),sourceVersionId:z.string().min(1).max(100),expectedCurrentVersionId:z.string().min(1).max(100).nullable()}).strict();
export const designEditorRoutes=new Hono<App>();designEditorRoutes.use('*',requireAuth);
designEditorRoutes.get('/projects/:project/editor-view',async c=>{const input=parseQuery(sourceQuery,c.req.query());return ok(c,await getDesignEditorView(c.env,c.get('auth').user.id,c.req.param('project'),querySource(input)));});
designEditorRoutes.get('/projects/:project/editor-nodes',async c=>{const query=c.req.query(),source=parseQuery(sourceQuery,query),input=parseQuery(z.object({templateId:z.coerce.number().int().positive(),limit:z.coerce.number().int().min(1).max(200).optional(),cursor:z.string().max(1000).optional(),nodeKey:z.string().regex(/^n\d{1,9}$/).optional()}),query);return ok(c,await getDesignEditorNodes(c.env,c.get('auth').user.id,c.req.param('project'),{...querySource(source),...input}));});
designEditorRoutes.post('/projects/:project/restore',async c=>{await rateLimit(c,'design-restore',60,60,c.get('auth').user.id);const input=await body(c,restoreSchema);return ok(c,await restoreDesignVersion(c.env,c.get('auth').user.id,c.req.param('project'),input),201);});
