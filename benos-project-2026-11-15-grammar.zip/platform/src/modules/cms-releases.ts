import { Hono } from 'hono';
import { type App,ok } from '../lib/http';
import { assert } from '../lib/errors';
import { sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,requireRole,rateLimit } from './auth';
import { boundedBytes } from './media';

export const cmsReleaseRoutes=new Hono<App>();
cmsReleaseRoutes.use('*',requireAuth,requireRole('owner'));
cmsReleaseRoutes.post('/upload',async c=>{
 await rateLimit(c,'cms-release-upload',6,3600,c.get('auth').user.id);
 assert(c.env.BUCKET,'STORAGE_NOT_CONFIGURED','私有文件存储尚未配置',503);
 const expected=c.req.header('x-content-sha256');
 assert(expected&&/^[a-f0-9]{64}$/.test(expected),'RELEASE_HASH_REQUIRED','请先计算发行文件 SHA256');
 assert(c.req.header('content-type')?.split(';')[0]==='application/zip','RELEASE_TYPE_INVALID','请上传受管 CMS ZIP 发行包');
 const bytes=await boundedBytes(c.req.raw.body,48*1024*1024);
 assert(bytes.length>=22&&bytes[0]===0x50&&bytes[1]===0x4b&&bytes[2]===3&&bytes[3]===4,'RELEASE_FORMAT_INVALID','文件不是有效的 ZIP 发行包');
 const hash=await sha256(bytes);assert(hash===expected,'RELEASE_HASH_MISMATCH','上传内容与原文件校验值不一致');
 // Content-addressed private storage: never replace an existing different file.
 // ZIP inventory and pinned CMS/overlay compatibility are verified again by the
 // receiving bootstrap before extraction. This endpoint does not execute code.
 const key='private/cms-releases/'+hash+'.zip',existing=await c.env.BUCKET.head(key);
 assert(!existing||existing.size===bytes.length&&existing.customMetadata?.sha256===hash,'RELEASE_STORAGE_CONFLICT','已有发行包记录需人工核对',409);
 await auditStatement(c.env.DB,c.get('auth').user.id,'cms.release_upload_requested','cms_release',hash,{sha256:hash,size:bytes.length},c.get('requestId')).run();
 if(!existing)await c.env.BUCKET.put(key,bytes,{httpMetadata:{contentType:'application/zip',cacheControl:'private, no-store'},customMetadata:{sha256:hash,source:'owner-upload'}});
 const verified=await c.env.BUCKET.head(key);assert(verified?.size===bytes.length&&verified.customMetadata?.sha256===hash,'RELEASE_STORAGE_UNCONFIRMED','发行文件保存结果待核对，请使用同一文件重试',503);
 return ok(c,{cmsReleaseObjectKey:key,cmsReleaseSha256:hash,cmsReleaseSize:bytes.length,verified:true},201);
});
