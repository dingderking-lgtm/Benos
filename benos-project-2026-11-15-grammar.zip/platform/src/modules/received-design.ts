import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { body,ok,type App } from '../lib/http';
import { assert } from '../lib/errors';
import { sha256 } from '../lib/crypto';
import { requireAuth,enforceScope } from './auth';
import { ownedDesignProject,readDesignVersion,saveDesignCandidate } from './design-workspace';
import { assertDesignScope,describeDesignNodePage,type DesignManifest } from './design-nodes';
import { validateSiteManifest } from './template-contract';
import { verifyProjectAssets } from './project-assets';
import { enforceTypographySnapshot,loadTypographySnapshot } from '../lib/design-typography';
import { typographySnapshotSchema } from '../contracts/design-typography';
import { SELECTED_EDIT_VERSION,selectedEditIssues } from '../lib/selected-edit';

const inputSchema=z.object({expectedManifestSha256:z.string().regex(/^[a-f0-9]{64}$/i).transform(value=>value.toLowerCase())}).strict();
const nodeScope=z.object({kind:z.literal('node'),templateId:z.number().int().positive(),nodeKey:z.string().regex(/^n\d{1,9}$/)}).strict();
type Workflow={id:string;user_id:string;project_id:string;base_version_id:string|null;base_manifest_json:string|null;manifest_json:string;requirements_json:string;scope_json:string;state:string;error_code:string|null;workspace_id:string|null;candidate_id:string|null;lease_token:string|null;lease_until_ms:number|null;validated_hash:string|null};
type Step={id:string;state:string;reservation_id:string;response_json:string|null;tool_results_json:string|null};
type Reservation={id:string;user_id:string;state:string;request_key:string;actual_micros:number|null};
function parse(text:string){try{return JSON.parse(text);}catch{assert(false,'RECEIVED_DESIGN_INVALID','已接收设计的持久记录无法核对',409);}}

/** Only persisted, complete provider output is evidence. An incomplete response,
 * or a tool name without a matching successful call receipt, is not enough. */
function receivedStep(steps:Step[]){return steps.find(step=>{
 if(step.state!=='completed'||!step.response_json||!step.tool_results_json)return false;
 const response=parse(step.response_json),tools=parse(step.tool_results_json);
 return response?.status==='completed'&&Array.isArray(response.output)&&Array.isArray(tools)&&tools.some(tool=>
  tool?.name==='replace_selected'&&tool.result?.ok===true&&tool.result?.replaced==='selected block'&&
  response.output.some((call:any)=>call.type==='function_call'&&call.name==='replace_selected'&&call.call_id===tool.callId));
});}

/** Append-only idempotency evidence. A requested event is deliberately distinct
 * from saved: storage/head conflicts may stop after the claim, and retry may
 * complete a lost acknowledgement without creating a second candidate. */
async function auditOnce(env:Env,kind:'requested'|'saved',details:Record<string,unknown>){
 const auditId='audit_received_'+await sha256(String(details.userId)+':'+String(details.workflowId)+':'+kind),action='ai.received_design_'+kind;
 await env.DB.prepare('INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING')
  .bind(auditId,details.userId,action,'workflow',details.workflowId,JSON.stringify(details),details.requestKey,new Date().toISOString()).run();
 const row=await env.DB.prepare('SELECT actor_id,action,entity_type,entity_id,details_json,request_id FROM audit_logs WHERE id=?').bind(auditId).first<{actor_id:string;action:string;entity_type:string;entity_id:string;details_json:string;request_id:string}>();
 assert(row&&row.actor_id===details.userId&&row.action===action&&row.entity_type==='workflow'&&row.entity_id===details.workflowId&&row.request_id===details.requestKey&&JSON.stringify(parse(row.details_json))===JSON.stringify(details),'IDEMPOTENCY_CONFLICT','该恢复编号已绑定另一份已接收设计',409);
}

/** Free, explicit local recovery. Never dispatches, settles, adopts, publishes,
 * or changes the original failed workflow/steps/requirements. */
export async function recoverReceivedDesign(env:Env,userId:string,workflowId:string,input:{expectedManifestSha256:string}){
 const expected=inputSchema.parse(input).expectedManifestSha256;
 const w=await env.DB.prepare('SELECT * FROM ai_workflows WHERE id=? AND user_id=?').bind(workflowId,userId).first<Workflow>();
 assert(w,'NOT_FOUND','任务不存在',404);
 const project=await ownedDesignProject(env,userId,w.project_id);
 assert(w.state==='failed'&&w.error_code==='AI_OUTPUT_INCOMPLETE'&&!w.workspace_id&&!w.candidate_id,'RECEIVED_DESIGN_UNAVAILABLE','此任务不支持恢复已接收设计',409);
 assert(!w.lease_token&&(!w.lease_until_ms||w.lease_until_ms<=Date.now()),'WORKFLOW_BUSY','任务仍有执行租约，请稍后核对',409);
 assert(new TextEncoder().encode(w.manifest_json).byteLength<=600000,'RECEIVED_DESIGN_INVALID','已接收设计超过恢复范围',409);
 const sourceManifestSha256=await sha256(w.manifest_json);
 assert(sourceManifestSha256===expected,'RECEIVED_DESIGN_HASH_CONFLICT','已接收设计与确认的内容不一致',409);
 assert(w.validated_hash===sourceManifestSha256,'RECEIVED_DESIGN_UNVERIFIED','已接收草稿尚无完整结构检查记录',409);
 const requirements=parse(w.requirements_json),scopeResult=nodeScope.safeParse(parse(w.scope_json));
 assert(requirements?.selectedEditProtocol===SELECTED_EDIT_VERSION&&scopeResult.success&&w.base_version_id&&w.base_manifest_json,'RECEIVED_DESIGN_UNAVAILABLE','仅支持新协议的普通选中内容修改',409);
 const scope=scopeResult.data,base=await readDesignVersion(env,userId,w.project_id,w.base_version_id);
 assert(JSON.stringify(base)===JSON.stringify(parse(w.base_manifest_json)),'RECEIVED_DESIGN_BASE_CONFLICT','原始设计版本与任务快照不一致',409);
 const selected=describeDesignNodePage(base,{templateId:scope.templateId,nodeKey:scope.nodeKey}).items[0];
 assert(selected&&!selected.protected&&!selected.aiTarget?.protected&&scope.templateId!==requirements.compiledHeader?.templateId,'DESIGN_SCOPE','受管理内容不能通过普通选中设计恢复',409);
 const steps=(await env.DB.prepare('SELECT id,state,reservation_id,response_json,tool_results_json FROM ai_workflow_steps WHERE workflow_id=? ORDER BY ordinal').bind(w.id).all<Step>()).results;
 assert(steps.length>0&&steps.length<=48&&steps.every(step=>['completed','failed'].includes(step.state)),'WORKFLOW_BUSY','任务步骤尚未全部结束',409);
 const receipt=receivedStep(steps);assert(receipt,'RECEIVED_DESIGN_UNVERIFIED','没有可核对的完整替换响应及成功回执',409);
 const prefix='workflow:'+w.id+':',reservations=(await env.DB.prepare('SELECT id,user_id,state,request_key,actual_micros FROM api_reservations WHERE substr(request_key,1,?)=? OR id IN(SELECT reservation_id FROM ai_workflow_steps WHERE workflow_id=?)').bind(prefix.length,prefix,w.id).all<Reservation>()).results;
 assert(reservations.length>0&&reservations.every(row=>row.user_id===userId&&row.request_key.startsWith(prefix)&&['settled','released'].includes(row.state)&&row.actual_micros!==null)&&steps.filter(step=>step.state==='completed').every(step=>reservations.some(row=>row.id===step.reservation_id)),'RECEIVED_DESIGN_UNSETTLED','任务仍有未确认或未结算记录，不能恢复',409);
 const imagePrefix='wfimg_'+(await sha256(w.id)).slice(0,20)+'_';
 const openImage=await env.DB.prepare(`SELECT j.id FROM image_jobs j LEFT JOIN api_reservations r ON r.id=j.reservation_id LEFT JOIN image_cost_corrections c ON c.job_id=j.id WHERE substr(j.request_key,1,?)=? AND (j.user_id<>? OR j.project_id<>? OR j.state NOT IN('succeeded','failed') OR r.id IS NULL OR r.user_id<>? OR r.state NOT IN('settled','released') OR c.state='pending') LIMIT 1`).bind(imagePrefix.length,imagePrefix,userId,w.project_id,userId).first();
 assert(!openImage,'RECEIVED_DESIGN_UNSETTLED','任务图片仍有未确认或未结算记录，不能恢复',409);
 const typography=requirements.typography?typographySnapshotSchema.parse(requirements.typography):null,versionTypography=await loadTypographySnapshot(env,userId,w.project_id,'version',w.base_version_id,await sha256(JSON.stringify(base)));
 assert(JSON.stringify(typography)===JSON.stringify(versionTypography),'TYPOGRAPHY_SNAPSHOT_CONFLICT','任务字体快照与原始设计版本不一致',409);
 const raw=parse(w.manifest_json) as DesignManifest,manifest=typography?enforceTypographySnapshot(raw,typography):raw;
 assertDesignScope(base,manifest,scope);
 const issues=selectedEditIssues(base,manifest,scope,requirements.selectedEditIntent==='restyle'?'restyle':'edit');assert(!issues.length,issues[0]?.code??'SELECTED_EDIT_NO_CHANGE',issues[0]?.message??'已接收内容没有有效修改',409);
 assert(validateSiteManifest(manifest).valid,'TEMPLATE_INVALID','已接收设计未通过结构检查',422);await verifyProjectAssets(env,userId,w.project_id,manifest);
 const requestKey='received-draft:'+w.id+':1',normalizedManifestSha256=await sha256(JSON.stringify(manifest));
 const previous=await env.DB.prepare('SELECT id,project_id,workflow_id,source FROM design_candidates WHERE user_id=? AND request_key=?').bind(userId,requestKey).first<{id:string;project_id:string;workflow_id:string;source:string}>();
 assert(!previous||(previous.project_id===w.project_id&&previous.workflow_id===w.id&&previous.source==='ai'),'IDEMPOTENCY_CONFLICT','该恢复编号已被其他方案使用',409);
 if(!previous)assert(project.current_version_id===w.base_version_id,'VERSION_CONFLICT','当前设计已更新；已接收内容保留，但不能创建旧版修改方案',409);
 const details={userId,projectId:w.project_id,workflowId:w.id,baseVersionId:w.base_version_id,requestKey,sourceManifestSha256,normalizedManifestSha256,receiptStepId:receipt.id,typographyNormalized:sourceManifestSha256!==normalizedManifestSha256};
 await auditOnce(env,'requested',details);
 const candidate=await saveDesignCandidate(env,{userId,projectId:w.project_id,requestKey,baseVersionId:w.base_version_id,scope,manifest,source:'ai',workflowId:w.id,...(typography?{typography}:{})});
 await auditOnce(env,'saved',{...details,candidateId:candidate.id});
 return {candidateId:candidate.id,previewUrl:candidate.previewUrl,localRecovery:true as const,originalWorkflowState:'failed' as const};
}

export const receivedDesignRoutes=new Hono<App>();receivedDesignRoutes.use('*',requireAuth);
receivedDesignRoutes.post('/workflows/:id/received-design',async c=>{await enforceScope(c,'ai');return ok(c,await recoverReceivedDesign(c.env,c.get('auth').user.id,c.req.param('id'),await body(c,inputSchema)),201);});
