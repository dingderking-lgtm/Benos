import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { AppError,assert } from '../lib/errors';
import type { PaymentRuntime } from './payments';

/** OpenAPI 2.0 RSA2 public-key mode. Protocol reference: official
 * alipay/alipay-sdk-nodejs-all src/util.ts and src/alipay.ts. No Node APIs. */
export type AlipayConfig={id:string;mode:'sandbox'|'live';appId:string;sellerId:string;privateKey:string;alipayPublicKey:string;usdToCnyRateMicros:number|null};
export type AlipayJson=Record<string,unknown>;
export const ALIPAY_GATEWAYS={live:'https://openapi.alipay.com/gateway.do',sandbox:'https://openapi-sandbox.dl.alipaydev.com/gateway.do'} as const;
const encoder=new TextEncoder(),RSA={name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'};
export function object(value:unknown):AlipayJson{return value!==null&&typeof value==='object'&&!Array.isArray(value)?value as AlipayJson:{};}
export function parseAlipayConfiguration(publicConfig:unknown,secret:unknown):Omit<AlipayConfig,'id'>{
 const c=object(publicConfig),s=object(secret);
 assert(c.mode==='sandbox'||c.mode==='live','PAYMENT_CONFIG_INVALID','请选择支付宝沙箱或正式环境',503);
 assert(typeof c.appId==='string'&&/^\d{16,32}$/.test(c.appId)&&typeof c.sellerId==='string'&&/^\d{16}$/.test(c.sellerId),'PAYMENT_CONFIG_INVALID','支付宝应用和收款商户标识无效',503);
 assert((c.keyMode??'public_key')==='public_key'&&(c.signType??'RSA2')==='RSA2'&&(c.settlementCurrency??'CNY')==='CNY','PAYMENT_CONFIG_INVALID','当前支付宝适配只支持RSA2公钥模式和人民币结算',503);
 assert(typeof s.privateKey==='string'&&s.privateKey.length<=12000&&typeof s.alipayPublicKey==='string'&&s.alipayPublicKey.length<=12000,'PAYMENT_CONFIG_INVALID','请配置应用私钥与支付宝公钥',503);
 const rate=c.usdToCnyRateMicros??null;assert(rate===null||(Number.isSafeInteger(rate)&&Number(rate)>0&&Number(rate)<=100_000_000),'PAYMENT_CONFIG_INVALID','人民币结算汇率无效',503);
 return {mode:c.mode,appId:c.appId,sellerId:c.sellerId,privateKey:s.privateKey,alipayPublicKey:s.alipayPublicKey,usdToCnyRateMicros:rate as number|null};
}
function bytes64(value:string):Uint8Array<ArrayBuffer>{assert(/^[A-Za-z0-9+/]+={0,2}$/.test(value)&&value.length%4===0,'ALIPAY_SIGNATURE_INVALID','支付宝签名或密钥格式无效',502);try{return Uint8Array.from(atob(value),c=>c.charCodeAt(0));}catch{throw new AppError('ALIPAY_SIGNATURE_INVALID','支付宝签名或密钥格式无效',502);}}
function base64(bytes:ArrayBuffer):string{return btoa(String.fromCharCode(...new Uint8Array(bytes)));}
async function key(pem:string,privateKey:boolean){
 const label=privateKey?'PRIVATE KEY':'PUBLIC KEY',header=`-----BEGIN ${label}-----`,footer=`-----END ${label}-----`;
 assert(!pem.includes('-----')||(pem.trim().startsWith(header)&&pem.trim().endsWith(footer)),'PAYMENT_CONFIG_INVALID','应用私钥须为PKCS8，支付宝公钥须为SPKI公钥格式',503);
 const encoded=pem.replace(header,'').replace(footer,'').replace(/\s/g,'');
 try{const imported=await crypto.subtle.importKey(privateKey?'pkcs8':'spki',bytes64(encoded),RSA,false,[privateKey?'sign':'verify']);assert((imported.algorithm as unknown as {modulusLength:number}).modulusLength>=2048,'PAYMENT_CONFIG_INVALID','RSA2密钥至少2048位',503);return imported;}
 catch(error){if(error instanceof AppError)throw error;throw new AppError('PAYMENT_CONFIG_INVALID','支付宝RSA2密钥无法读取',503);}
}
export function canonicalAlipay(params:Record<string,string>,notification=false):string{return Object.keys(params).filter(k=>k!=='sign'&&(!notification||k!=='sign_type')&&params[k]!=='').sort().map(k=>`${k}=${params[k]}`).join('&');}
export async function signAlipay(content:string,privateKey:string):Promise<string>{return base64(await crypto.subtle.sign(RSA,await key(privateKey,true),encoder.encode(content)));}
export async function verifyAlipay(content:string,signature:string,publicKey:string):Promise<void>{assert(typeof signature==='string'&&signature.length<=2048&&await crypto.subtle.verify(RSA,await key(publicKey,false),bytes64(signature),encoder.encode(content)),'ALIPAY_SIGNATURE_INVALID','支付宝响应签名无效',502);}
export function alipayTimestamp(nowMs:number):string{return new Date(nowMs+8*3600000).toISOString().slice(0,19).replace('T',' ');}
export function alipayTime(value:unknown):string{assert(typeof value==='string'&&/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/.test(value),'PAYMENT_TIME_INVALID','支付宝付款时间待核对',409);const ms=Date.parse(value.replace(' ','T')+'+08:00');assert(Number.isFinite(ms)&&alipayTimestamp(ms)===value,'PAYMENT_TIME_INVALID','支付宝付款时间无效',409);return new Date(ms).toISOString();}
export function amountCents(value:unknown):number{assert(typeof value==='string'&&/^(?:0|[1-9]\d{0,9})(?:\.\d{1,2})?$/.test(value),'PAYMENT_AMOUNT_MISMATCH','支付宝金额格式无效',409);const [whole,fraction='']=value.split('.');const amount=Number(whole)*100+Number(fraction.padEnd(2,'0'));assert(Number.isSafeInteger(amount),'PAYMENT_AMOUNT_MISMATCH','支付宝金额无效',409);return amount;}
export function amountString(cents:number):string{assert(Number.isSafeInteger(cents)&&cents>0&&cents<=100_000_000,'PAYMENT_AMOUNT_MISMATCH','人民币支付金额超出支持范围',409);return `${Math.floor(cents/100)}.${String(cents%100).padStart(2,'0')}`;}
export async function signedAlipayParams(config:AlipayConfig,method:string,biz:AlipayJson,extra:Record<string,string>={},nowMs=Date.now()){
 const p={app_id:config.appId,method,format:'JSON',charset:'utf-8',sign_type:'RSA2',timestamp:alipayTimestamp(nowMs),version:'1.0',...extra,biz_content:JSON.stringify(biz)};
 return {...p,sign:await signAlipay(canonicalAlipay(p),config.privateKey)};
}
/** Retain exact signed JSON bytes; JSON.stringify(JSON.parse(raw)) is NOT valid. */
export function responseSlice(raw:string,responseKey:string):{value:AlipayJson;signature:string;content:string}{
 let i=0;const spans=new Map<string,string>();const ws=()=>{while(/\s/.test(raw[i]??'')&&i<raw.length)i++;};ws();assert(raw[i++]==='{','ALIPAY_RESPONSE_INVALID','支付宝响应无效',502);
 while(true){ws();if(raw[i]==='}'){i++;break;}assert(raw[i]==='"','ALIPAY_RESPONSE_INVALID','支付宝响应无效',502);const ks=i++;let escaped=false;while(i<raw.length){const ch=raw[i++];if(!escaped&&ch==='"')break;if(!escaped&&ch==='\\')escaped=true;else escaped=false;}
  let name:string;try{name=JSON.parse(raw.slice(ks,i));}catch{throw new AppError('ALIPAY_RESPONSE_INVALID','支付宝响应无效',502);}assert(!spans.has(name),'ALIPAY_RESPONSE_INVALID','支付宝响应包含重复字段',502);ws();assert(raw[i++]===':','ALIPAY_RESPONSE_INVALID','支付宝响应无效',502);ws();const start=i;let depth=0,inString=false,escape=false;
  for(;i<raw.length;i++){const ch=raw[i];if(inString){if(!escape&&ch==='"')inString=false;if(!escape&&ch==='\\')escape=true;else escape=false;continue;}if(ch==='"'){inString=true;continue;}if(ch==='{'||ch==='[')depth++;else if(ch==='}'||ch===']'){if(depth===0)break;depth--;}else if(ch===','&&depth===0)break;}
  spans.set(name,raw.slice(start,i).trim());ws();if(raw[i]===','){i++;continue;}assert(raw[i]==='}','ALIPAY_RESPONSE_INVALID','支付宝响应无效',502);i++;break;
 }ws();assert(i===raw.length&&spans.has(responseKey)&&spans.has('sign'),'ALIPAY_RESPONSE_INVALID','支付宝响应缺少可验证签名',502);
 try{const parsed=JSON.parse(raw),content=spans.get(responseKey)!;assert(typeof parsed.sign==='string','ALIPAY_RESPONSE_INVALID','支付宝响应签名无效',502);return{value:object(JSON.parse(content)),signature:parsed.sign,content};}catch(error){if(error instanceof AppError)throw error;throw new AppError('ALIPAY_RESPONSE_INVALID','支付宝响应无效',502);}
}
async function boundedText(response:Response,limit=262144):Promise<string>{const reader=response.body?.getReader();assert(reader,'ALIPAY_RESPONSE_INVALID','支付宝响应为空',502);const parts:Uint8Array[]=[];let size=0;try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;assert(size<=limit,'ALIPAY_RESPONSE_INVALID','支付宝响应超出限制',502);parts.push(value);}}catch(error){await reader.cancel().catch(()=>undefined);throw error;}const all=new Uint8Array(size);let at=0;for(const part of parts){all.set(part,at);at+=part.length;}try{return new TextDecoder('utf-8',{fatal:true,ignoreBOM:false}).decode(all);}catch{throw new AppError('ALIPAY_RESPONSE_INVALID','支付宝响应编码无效',502);}}
export async function alipayRequest(config:AlipayConfig,method:'alipay.trade.query'|'alipay.trade.close'|'alipay.trade.refund'|'alipay.trade.fastpay.refund.query',biz:AlipayJson,runtime:PaymentRuntime={}):Promise<AlipayJson>{
 const params=await signedAlipayParams(config,method,biz,{},runtime.nowMs??Date.now());let response:Response;
 try{response=await fetchWithoutRedirect(ALIPAY_GATEWAYS[config.mode],{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=utf-8'},body:new URLSearchParams(params).toString(),signal:AbortSignal.timeout(15000)},runtime.fetch??fetch);}catch{throw new AppError('PAYMENT_PROVIDER_UNCONFIRMED','支付宝请求结果待确认，请查询原订单，勿重复付款',503);}
 assert(response.ok,'PAYMENT_PROVIDER_UNCONFIRMED','支付宝请求结果待确认',503);const raw=await boundedText(response),result=responseSlice(raw,method.replaceAll('.','_')+'_response');await verifyAlipay(result.content,result.signature,config.alipayPublicKey);return result.value;
}
export async function verifiedAlipayNotification(raw:string,config:AlipayConfig):Promise<Record<string,string>>{
 assert(encoder.encode(raw).byteLength<=65536,'REQUEST_TOO_LARGE','支付宝通知过大',413);const p:Record<string,string>=Object.create(null);for(const[k,v]of new URLSearchParams(raw)){assert(!Object.hasOwn(p,k)&&/^[a-zA-Z0-9_]+$/.test(k),'WEBHOOK_INVALID','支付宝通知字段无效',400);p[k]=v;}
 assert(p.sign_type==='RSA2'&&(p.charset??'utf-8').toLowerCase()==='utf-8','WEBHOOK_INVALID','支付宝通知签名算法或编码无效',400);await verifyAlipay(canonicalAlipay(p,true),p.sign,config.alipayPublicKey);
 assert(p.app_id===config.appId&&p.seller_id===config.sellerId,'PAYMENT_IDENTITY_MISMATCH','支付宝通知应用或收款方不匹配',409);return p;
}
