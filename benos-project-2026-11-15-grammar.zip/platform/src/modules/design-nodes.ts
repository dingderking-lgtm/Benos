import { parseFragment,type DefaultTreeAdapterMap } from 'parse5';
import { assert } from '../lib/errors';

type Element=DefaultTreeAdapterMap['element'];
export type DesignScope={kind:'node';templateId:number;nodeKey:string}|{kind:'site'};
export type DesignManifest={templates:Array<{id:number;name:string;type:string;document:{html:string;css?:string;[key:string]:unknown};[key:string]:unknown}>;assets:Array<{file:string;path:string;sha256:string;size:number}>;site:{theme?:{global_css?:string;[key:string]:unknown};[key:string]:unknown};[key:string]:unknown};
const clone=<T>(v:T):T=>JSON.parse(JSON.stringify(v));
function canonical(v:unknown):unknown{return Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b)).map(([k,x])=>[k,canonical(x)])):v;}
const same=(a:unknown,b:unknown)=>JSON.stringify(canonical(a))===JSON.stringify(canonical(b));
export const DESIGN_FONTS=[{value:'system-ui, sans-serif',label:'系统无衬线'},{value:'Arial, sans-serif',label:'Arial'},{value:'Georgia, serif',label:'Georgia 衬线'},{value:'ui-monospace, monospace',label:'等宽字体'}];
/** Iterative preorder matches the original parse5 childNodes traversal exactly,
 * including its intentional exclusion of inert template.content children. */
type AiEntryTarget={node:Element;nodeKey:string;protected:boolean};
type ElementEntry={node:Element;nodeKey:string;aiTarget?:AiEntryTarget};
const aiBlockTags=new Set(['section','article','header','footer']);
function aiManagedBoundary(node:Element){
 return node.namespaceURI!=='http://www.w3.org/1999/xhtml'||node.tagName==='form'||node.tagName==='template'
  ||node.attrs.some(a=>/^data-(?:aacms(?:-|$)|template(?:-|$)|form(?:-|$)|media(?:-|$)|asset(?:-|$))/.test(a.name)||/\{\{|\{%/.test(a.value))
  ||/(?:^|\s)bnh-[\w-]+(?:\s|$)/.test(attr(node,'class')||'')
  ||node.childNodes.some(n=>'value' in n&&/\{\{|\{%/.test(n.value));
}
function safeAiBlock(node:Element){const at=node.sourceCodeLocation;return aiBlockTags.has(node.tagName)&&!!at?.startTag&&!!at.endTag&&at.endOffset>at.startOffset;}
function* elementEntries(html:string,withAiTargets=false):Generator<ElementEntry>{
 const root=parseFragment(html,{sourceCodeLocationInfo:true});
 const stack:Array<{nodes:DefaultTreeAdapterMap['node'][];at:number;target?:AiEntryTarget;protected?:boolean}>=[{nodes:[root],at:0}];let ordinal=0;
 while(stack.length){const frame=stack[stack.length-1];if(frame.at>=frame.nodes.length){stack.pop();continue;}const node=frame.nodes[frame.at++];
  let target=frame.target,protectedBoundary=frame.protected??false;
  if(withAiTargets&&'tagName' in node)protectedBoundary ||= aiManagedBoundary(node);
  if('tagName' in node&&node.sourceCodeLocation?.startTag){const nodeKey='n'+ordinal++;
   if(withAiTargets){if(protectedBoundary)target=undefined;else if(safeAiBlock(node))target={node,nodeKey,protected:false};}
   yield {node,nodeKey,...(withAiTargets?{aiTarget:target??{node,nodeKey,protected:protectedBoundary}}:{})};
  }
  if('childNodes' in node&&node.childNodes.length)stack.push({nodes:node.childNodes,at:0,...(withAiTargets?{target,protected:protectedBoundary}:{})});
 }
}
function elements(html:string){return [...elementEntries(html)];}
/** Labels are UI hints, never source spans. Do not recursively concatenate the
 * complete descendant text for every ancestor of a multi-megabyte document. */
function shortText(root:DefaultTreeAdapterMap['node']):string{
 const stack:Array<{nodes:DefaultTreeAdapterMap['node'][];at:number}>=[{nodes:[root],at:0}];let label='',visited=0,characters=0;
 while(stack.length&&label.length<65&&visited<2048&&characters<8192){const frame=stack[stack.length-1];if(frame.at>=frame.nodes.length){stack.pop();continue;}const node=frame.nodes[frame.at++];visited++;
  if('value' in node){const value=node.value.slice(0,8192-characters);characters+=value.length;label=(label+' '+value.replace(/\s+/g,' ')).trim().slice(0,65);}
  else if('childNodes' in node&&node.childNodes.length)stack.push({nodes:node.childNodes,at:0});
 }return label;
}
export type DesignAiTarget={templateId:number;nodeKey:string;tag:string;label:string;protected:boolean};
export type DesignNodeDescription={templateId:number;nodeKey:string;tag:string;label:string;protected:boolean;canReplaceImage:boolean;canSetFont?:boolean;fontId?:string|null;aiTarget?:DesignAiTarget};
function describeAiTarget(template:{id:number;name:string},entry:ElementEntry):DesignAiTarget{
 let target=entry.aiTarget??{node:entry.node,nodeKey:entry.nodeKey,protected:false};
 const own=entry.node.sourceCodeLocation!,span=target.node.sourceCodeLocation!;
 // Malformed markup can be foster-parented by HTML parsing. A promoted target
 // must also contain the selected source bytes, not merely its DOM parent.
 if(span.startOffset>own.startOffset||span.endOffset<own.endOffset)target={node:entry.node,nodeKey:entry.nodeKey,protected:target.protected};
 const node=target.node,id=attr(node,'id')||'',classes=attr(node,'class')||'';
 const hero=node.tagName==='section'&&(/^(?:hero|orientation|intro|home-hero)$/i.test(id)||/(?:^|\s)(?:hero|bn[fs]-hero(?:-[\w-]+)?)(?:\s|$)/.test(classes));
 const kind=hero?'首屏区块':({section:'内容区块',article:'文章区块',header:'页头',footer:'页脚',img:'图片'} as Record<string,string>)[node.tagName]||'所选元素';
 const text=shortText(node)||String(attr(node,'alt')||template.name).slice(0,65);
 return{templateId:template.id,nodeKey:target.nodeKey,tag:node.tagName,label:(kind+(text?' · '+text:'')).slice(0,65),protected:target.protected};
}
type FontOverride={templateId:number;anchor:string;font:{id:string};headerNodeKey?:string};
function describeNode(template:{id:number;name:string},node:Element,nodeKey:string,fontOverrides?:FontOverride[]):DesignNodeDescription{
 const classes=(attr(node,'class')||'').split(/\s+/),font=fontOverrides?.find(o=>o.templateId===template.id&&(o.headerNodeKey===nodeKey||classes.includes(o.anchor)));
 return {templateId:template.id,nodeKey,tag:node.tagName,label:shortText(node)||String(attr(node,'alt')||template.name).slice(0,65),protected:node.attrs.some(a=>/^data-(aacms|template|form)/.test(a.name)),canSetFont:!hiddenNodeTags.has(node.tagName)&&attr(node,'aria-hidden')!=='true'&&(/^(h[1-6]|p|span|a|summary|strong|em|b|i|small|blockquote|figcaption|label|li|dt|dd|td|th|button|code|pre|s|u|mark|sub|sup|q|cite|time)$/.test(node.tagName)||node.childNodes.some(n=>'value' in n&&n.value.trim()))&&!/(?:^|\s)(?:icon-|bnh-menu-icon|aacms-nav-chevron)/.test(attr(node,'class')||''),canReplaceImage:node.tagName==='img'&&!node.attrs.some(a=>/^data-(aacms|media)/.test(a.name)),...(fontOverrides?{fontId:font?.font.id??null}:{})};
}
const hiddenNodeTags=new Set(['style','link','meta','script','template']);
/** Parse one target template, retain at most limit descriptors, and stop at the
 * first next selectable node. No all-site node list or unbounded labels. */
export function describeDesignNodePage(input:unknown,options:{templateId:number;after?:number;limit?:number;nodeKey?:string;fontOverrides?:FontOverride[]}){
 const manifest=input as DesignManifest,template=manifest.templates.find(t=>t.id===options.templateId);assert(template,'DESIGN_SCOPE','区块模板不存在',404);
 const limit=options.limit??100;assert(Number.isSafeInteger(limit)&&limit>=1&&limit<=200,'VALIDATION','每页区块数量需在 1 至 200 之间');
 const after=options.after??-1;assert(Number.isSafeInteger(after)&&after>=-1,'VALIDATION','区块游标无效');
 if(options.nodeKey)assert(/^n\d{1,9}$/.test(options.nodeKey),'VALIDATION','区块编号无效');
 const items:DesignNodeDescription[]=[];let nextAfter:number|null=null;
 for(const entry of elementEntries(template.document.html,!!options.nodeKey)){
  const ordinal=Number(entry.nodeKey.slice(1));
  if(options.nodeKey){if(entry.nodeKey!==options.nodeKey)continue;assert(!hiddenNodeTags.has(entry.node.tagName),'DESIGN_SCOPE','该节点不支持可视化选取',404);items.push({...describeNode(template,entry.node,entry.nodeKey,options.fontOverrides),aiTarget:describeAiTarget(template,entry)});break;}
  if(ordinal<=after||hiddenNodeTags.has(entry.node.tagName))continue;
  if(items.length===limit){nextAfter=Number(items[items.length-1].nodeKey.slice(1));break;}
  items.push(describeNode(template,entry.node,entry.nodeKey,options.fontOverrides));
 }
 if(options.nodeKey)assert(items.length===1,'DESIGN_SCOPE','所选区块已变化，请重新选择',404);
 return {items,nextAfter,hasMore:nextAfter!==null};
}
const protectedNames=/^(data-aacms(?:-.+)?|data-template|data-form|data-media-id|data-asset-id|href|action|name|form|for)$/;
type Binding={kind:'element';tag:string;namespace:string;attributes:Array<[string,string,string]>;children:Binding[]}|{kind:'text'|'comment';value:string};
/** Preserve the ordered binding tree, not a bag of independent attributes.
 * Plain decoration is flattened so wrappers/classes/styles remain editable.
 * Binding parents and attribute pairs stay together, including form ownership
 * and placeholders in text, attributes or inert template content. */
function bindings(html:string,allowStaticAnchors=false):Binding[]{
 const placeholders=(value:string)=>value.match(/\{\{[^}]+\}\}/g)||[];
 const visit=(node:DefaultTreeAdapterMap['node'],insideBinding=false):Binding[]=>{
  if('value' in node)return placeholders(node.value).map(value=>({kind:'text',value}));
  if(node.nodeName==='#comment'&&'data' in node)return placeholders(node.data).map(value=>({kind:'comment',value}));
  // Only plain links in whole-site edits may be added, removed or reorganized. CMS
  // ancestors, form/template boundaries and dynamic placeholders still own
  // their descendant links, even when a particular href happens to be static.
  const bound=insideBinding||('tagName' in node&&(node.tagName==='form'||node.tagName==='template'||node.attrs.some(attribute=>(attribute.name!=='href'&&protectedNames.test(attribute.name))||placeholders(attribute.value).length>0)));
  const childNodes='content' in node?(node as DefaultTreeAdapterMap['template']).content.childNodes:'childNodes' in node?node.childNodes:[];
  const children=childNodes.flatMap(child=>visit(child,bound));if(!('tagName' in node))return children;
  const editableHref=allowStaticAnchors&&!bound&&!children.length&&node.tagName==='a'&&node.namespaceURI==='http://www.w3.org/1999/xhtml';
  const attributes:Array<[string,string,string]>=node.attrs.flatMap(attribute=>{
   const tokens=placeholders(attribute.value);
   // A presentation link is not a CMS binding. Flatten it just like an ordinary
   // wrapper in site scope; bound descendants, other protected attributes and
   // foreign/namespaced links remain in the ordered tree. URL policy is checked
   // independently by validateSiteManifest before a candidate can be saved.
   if(editableHref&&attribute.name==='href'&&!attribute.namespace&&!tokens.length)return [];
   return protectedNames.test(attribute.name)||tokens.length?[[attribute.namespace||'',attribute.name,protectedNames.test(attribute.name)?attribute.value:JSON.stringify(tokens)] as [string,string,string]]:[];
  });
  // Form boundaries remain significant even when action is implicit. Existing
  // IDs on bound nodes also keep label/form references attached to their target.
  if(attributes.length||node.tagName==='form'||node.tagName==='template'){
   for(const attribute of node.attrs)if(attribute.name==='id'||(node.tagName==='form'&&['method','enctype','target'].includes(attribute.name))){const existing=attributes.find(item=>item[0]===(attribute.namespace||'')&&item[1]===attribute.name);if(existing)existing[2]=attribute.value;else attributes.push([attribute.namespace||'',attribute.name,attribute.value]);}
   attributes.sort((a,b)=>a[0].localeCompare(b[0])||a[1].localeCompare(b[1]));
   return [{kind:'element',tag:node.tagName,namespace:node.namespaceURI,attributes,children}];
  }
  return children;
 };
 return visit(parseFragment(html));
}
function attr(node:Element,name:string){return node.attrs.find(a=>a.name===name)?.value;}
function escape(value:string){return value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));}
function setAttribute(html:string,node:Element,name:string,value:string){
 const location=node.sourceCodeLocation!,existing=location.attrs?.[name];
 if(existing)return html.slice(0,existing.startOffset)+name+'="'+escape(value)+'"'+html.slice(existing.endOffset);
 const end=location.startTag!.endOffset-1,at=html[end-1]==='/'?end-1:end;
 return html.slice(0,at)+' '+name+'="'+escape(value)+'"'+html.slice(at);
}
export function annotateDesignHtml(html:string,templateId:number){
 let result=html;const edits:Array<{start:number;end:number;text:string}>=[];
 for(const {node,nodeKey} of elements(html)){const end=node.sourceCodeLocation!.startTag!.endOffset-1,at=html[end-1]==='/'?end-1:end;edits.push({start:at,end:at,text:` data-benos-template="${templateId}" data-benos-node="${nodeKey}"`});for(const name of ['data-benos-template','data-benos-node']){const loc=node.sourceCodeLocation!.attrs?.[name];if(loc)edits.push({start:loc.startOffset,end:loc.endOffset,text:''});}}
 for(const edit of edits.sort((a,b)=>b.start-a.start))result=result.slice(0,edit.start)+edit.text+result.slice(edit.end);
 return result;
}
export function describeDesignNodes(input:unknown){const manifest=input as DesignManifest;return manifest.templates.flatMap(t=>[...elementEntries(t.document.html)].filter(({node})=>!hiddenNodeTags.has(node.tagName)).map(({node,nodeKey})=>describeNode(t,node,nodeKey)));}
export function designNodeHtml(manifest:unknown,scope:DesignScope){assert(scope.kind==='node','DESIGN_SCOPE','请选择区块');const t=(manifest as DesignManifest).templates.find(t=>t.id===scope.templateId);assert(t,'DESIGN_SCOPE','区块模板不存在',409);const found=elements(t.document.html).find(x=>x.nodeKey===scope.nodeKey);assert(found,'DESIGN_SCOPE','所选区块已变化，请重新选择',409);const location=found.node.sourceCodeLocation!;return {html:t.document.html.slice(location.startOffset,location.endOffset),start:location.startOffset,end:location.endOffset,template:t,node:found.node};}
/** A selected-block proposal may only replace that exact source span. CMS
 * bindings and links remain invariant even when a model returns an entire file. */
export function assertDesignScope(baseInput:unknown,nextInput:unknown,scope:DesignScope){
 if(baseInput===null){assert(scope.kind==='site','DESIGN_SCOPE','首次设计必须作用于完整网站');return;}
 const base=baseInput as DesignManifest,next=nextInput as DesignManifest;
 const before=clone(base) as any,after=clone(next) as any;delete before.assets;delete after.assets;
 if(scope.kind==='node'){
  const original=designNodeHtml(base,scope),changed=next.templates.find(t=>t.id===scope.templateId);assert(changed,'DESIGN_SCOPE','不能移除所选模板',409);
  const oldHtml=original.template.document.html,newHtml=changed.document.html,prefix=oldHtml.slice(0,original.start),suffix=oldHtml.slice(original.end);
  assert(newHtml.startsWith(prefix)&&newHtml.endsWith(suffix)&&newHtml.length>=prefix.length+suffix.length,'DESIGN_SCOPE','修改超出所选区块',409);
  const replacement=newHtml.slice(prefix.length,suffix.length?newHtml.length-suffix.length:undefined);
  assert(same(bindings(original.html),bindings(replacement)),'DESIGN_BINDINGS','修改不能移除或改变 CMS 绑定、数据字段及链接',409);
  after.templates.find((t:any)=>t.id===scope.templateId)!.document.html=oldHtml;
  assert(same(before,after),'DESIGN_SCOPE','所选区块以外的页面、样式及设置必须保持不变',409);
 }else{
  assert(base.templates.length===next.templates.length,'DESIGN_BINDINGS','已有网站模板结构必须保留',409);
  for(const old of base.templates){const target=next.templates.find(t=>t.id===old.id);assert(target&&target.type===old.type&&same(bindings(old.document.html,true),bindings(target.document.html,true)),'DESIGN_BINDINGS','已有网站的动态绑定及受保护链接必须保留',409);const a=clone(old),b=clone(target);a.document.html='';b.document.html='';delete a.document.css;delete b.document.css;assert(same(a,b),'DESIGN_BINDINGS','已有模板的挂载条件与非样式配置必须保留',409);}
  // Layout/style changes do not rewrite seeded CMS content, forms, menus,
  // pages or their metadata. Explicit business-content changes belong to CMS.
  before.templates=[];after.templates=[];
  const locked=String(base.site.theme?.global_css||'').match(/\/\* Benos confirmed site styles \*\/\nbody\{[^}]+\}/g)||[];
  for(const css of locked)assert(String(next.site.theme?.global_css||'').includes(css),'DESIGN_BRAND','已确认的全站品牌样式必须保留',409);
  if(before.site.theme){delete before.site.theme.global_css;if(!Object.keys(before.site.theme).length)delete before.site.theme;}if(after.site.theme){delete after.site.theme.global_css;if(!Object.keys(after.site.theme).length)delete after.site.theme;}
  assert(same(before,after),'DESIGN_BINDINGS','网站业务内容和组件配置必须保留',409);
 }
 for(const asset of base.assets)assert(next.assets.some(a=>same(a,asset)),'DESIGN_BINDINGS','已有图片清单必须保留，避免丢失历史引用',409);
}
export type StyleProperties=Record<string,string|number>;
export function styleDeclarations(properties:StyleProperties){
 const output:string[]=[];assert(Object.keys(properties).length>0&&Object.keys(properties).length<=18,'DESIGN_STYLE','请填写至少一项样式');
 for(const [key,value] of Object.entries(properties)){
  let rendered:string;
  if(key==='fontFamily'){assert(typeof value==='string'&&DESIGN_FONTS.some(f=>f.value===value),'DESIGN_STYLE','字体不在可用列表');rendered=value;}
  else if(['color','backgroundColor'].includes(key)){assert(typeof value==='string'&&/^#[0-9a-f]{3}(?:[0-9a-f]{3}|[0-9a-f]{5})?$/i.test(value),'DESIGN_STYLE','请使用十六进制颜色');rendered=value;}
  else {const allowed=['fontSize','lineHeight','paddingTop','paddingRight','paddingBottom','paddingLeft','marginTop','marginRight','marginBottom','marginLeft','gap','borderRadius'];assert(allowed.includes(key)&&typeof value==='number'&&Number.isFinite(value),'DESIGN_STYLE','样式字段或数值无效');const min=key==='fontSize'?8:key==='lineHeight'?0.8:0,max=key==='fontSize'?160:key==='lineHeight'?3:160;assert(value>=min&&value<=max,'DESIGN_STYLE','样式数值超出范围');rendered=key==='lineHeight'?String(value):value+'px';}
  output.push(key.replace(/[A-Z]/g,c=>'-'+c.toLowerCase())+':'+rendered+' !important');
 }return output.join(';')+';';
}
export function patchDesignStyle(input:unknown,scope:DesignScope,properties:StyleProperties){
 const manifest=clone(input) as DesignManifest,css=styleDeclarations(properties);
 if(scope.kind==='site'){
  assert(Object.keys(properties).every(k=>['fontFamily','color','backgroundColor','fontSize','lineHeight'].includes(k)),'DESIGN_STYLE','全站仅支持基础字体、字号和配色');
  manifest.site.theme??={};manifest.site.theme.global_css=(manifest.site.theme.global_css||'')+'\n/* Benos confirmed site styles */\nbody{'+css+'}';
 }else{const selected=designNodeHtml(manifest,scope);selected.template.document.html=setAttribute(selected.template.document.html,selected.node,'style',(attr(selected.node,'style')||'')+';'+css);}
 return manifest;
}
/** Replaces the words of one plain text element (text and line breaks only). Markup, CMS-managed fields and
 * placeholders are never editable here; the new words are escaped, a new line becomes a line break. */
export function patchDesignText(input:unknown,scope:DesignScope,text:string){
 const manifest=clone(input) as DesignManifest,selected=designNodeHtml(manifest,scope),node=selected.node,location=node.sourceCodeLocation!;
 assert(!hiddenNodeTags.has(node.tagName)&&!node.attrs.some(a=>/^data-(aacms|template|form)/.test(a.name))&&!/\{\{[^}]+\}\}/.test(selected.html),'DESIGN_TEXT','这段内容由 CMS 管理，请在 CMS 中修改',409);
 assert(location.endTag&&node.childNodes.length>0&&node.childNodes.every(child=>'value' in child||('tagName' in child&&child.tagName==='br')),'DESIGN_TEXT','请点选具体的一段文字来修改',409);
 const value=text.replace(/\r\n?/g,'\n').trim();
 assert(value.length>=1&&value.length<=4000&&!/[\u0000-\u0009\u000B-\u001F\u007F]/.test(value),'DESIGN_TEXT','文字不能为空，且最多 4000 个字符',422);
 const html=selected.template.document.html;
 selected.template.document.html=html.slice(0,location.startTag!.endOffset)+value.split('\n').map(escape).join('<br>')+html.slice(location.endTag.startOffset);
 return manifest;
}
/** The same for text with inline emphasis: `slots` are the pieces of text before, between and after the inline
 * child elements, `children` their words (or one further level of pure span text parts).
 * Existing tags, attributes, font anchors, order and cardinality are never replaced by client markup. */
export function patchDesignInlineText(input:unknown,scope:DesignScope,parts:import('./design-text-parts').InlineTextParts){
 const manifest=clone(input) as DesignManifest,selected=designNodeHtml(manifest,scope),node=selected.node,location=node.sourceCodeLocation!,html=selected.template.document.html;
 const managed=(element:Element)=>hiddenNodeTags.has(element.tagName)||element.attrs.some(a=>/^data-(aacms|template|form)/.test(a.name)||a.name==='aria-hidden'&&a.value==='true'||a.name==='role'&&/^(img|button|link)$/.test(a.value)||a.name==='class'&&a.value.split(/\s+/).some(c=>/^(?:icon(?:-|$)|fa(?:[brsld]?|-)|material-(?:icons|symbols)|lucide(?:-|$)|bi(?:-|$))/.test(c))||a.name==='style'&&/font(?:-family)?\s*:[^;]*(?:icons?|fontawesome|glyphicons|wingdings|webdings)/i.test(a.value));
 assert(!managed(node)&&!/\{\{[^}]+\}\}/.test(selected.html),'DESIGN_TEXT','这段内容由 CMS 管理，请在 CMS 中修改',409);
 const children=(element:Element)=>element.childNodes.filter((child):child is Element=>'tagName' in child&&child.tagName!=='br');
 const wordsOnly=(element:Element)=>element.childNodes.every(child=>'value' in child||('tagName' in child&&child.tagName==='br'));
 let nodes=0,total=0;
 const clean=(value:string)=>{const text=value.replace(/\r\n?/g,'\n');assert(text.length<=4000&&!/[\u0000-\u0009\u000B-\u001F\u007F]/.test(text),'DESIGN_TEXT','文字内容无效',422);return text.split('\n').map(escape).join('<br>');};
 let visible='';
 const piece=(value:string)=>{assert(typeof value==='string','DESIGN_TEXT','文字内容无效',422);total+=value.length;assert(total<=52000,'DESIGN_TEXT','文字内容过长',422);visible+=value;return clean(value);};
 const build=(element:Element,value:import('./design-text-parts').InlineTextParts,depth:number):string=>{
  const inline=children(element);
  assert(depth<=1&&element.sourceCodeLocation?.endTag&&inline.length>=1&&inline.length<=12&&element.childNodes.every(child=>'value' in child||'tagName' in child),'DESIGN_TEXT','这段文字的结构较复杂，请交给 AI 修改',409);
  assert(value&&Array.isArray(value.children)&&Array.isArray(value.slots)&&value.children.length===inline.length&&value.slots.length===inline.length+1,'DESIGN_TEXT','文字的强调部分不能增减，请交给 AI 修改',409);
  let result=piece(value.slots[0]);
  inline.forEach((child,index)=>{
   assert(++nodes<=36&&(depth===0?/^(span|strong|em|b|i|u|small|mark)$/.test(child.tagName):child.tagName==='span')&&!managed(child)&&child.sourceCodeLocation?.endTag,'DESIGN_TEXT','这段文字的结构较复杂，请交给 AI 修改',409);
   const next=value.children[index],at=child.sourceCodeLocation!;let content:string;
   if(wordsOnly(child)){assert(typeof next==='string','DESIGN_TEXT','文字的强调部分不能增减，请交给 AI 修改',409);content=piece(next);}
   else{assert(child.tagName==='span'&&depth===0&&next!==null&&typeof next==='object','DESIGN_TEXT','这段文字的结构较复杂，请交给 AI 修改',409);content=build(child,next,depth+1);}
   result+=html.slice(at.startTag!.startOffset,at.startTag!.endOffset)+content+html.slice(at.endTag!.startOffset,at.endTag!.endOffset)+piece(value.slots[index+1]);
  });return result;
 };
 const inner=build(node,parts,0);assert(visible.trim().length>=1,'DESIGN_TEXT','文字不能为空',422);
 selected.template.document.html=html.slice(0,location.startTag!.endOffset)+inner+html.slice(location.endTag!.startOffset);
 return manifest;
}
export type ImagePresentation={fit:'cover'|'contain';focalPoint:'center'|'left'|'right'|'top'|'bottom'};
/** Split inline CSS declarations without splitting strings, comments or url() values. */
function imagePresentationStyle(style:string,presentation:ImagePresentation){
 const declarations:string[]=[];let start=0,quote='',comment=false,depth=0;
 for(let i=0;i<style.length;i++){
  const ch=style[i],next=style[i+1];
  if(comment){if(ch==='*'&&next==='/'){comment=false;i++;}continue;}
  if(quote){if(ch==='\\'){i++;continue;}if(ch===quote)quote='';continue;}
  if(ch==='/'&&next==='*'){comment=true;i++;continue;}
  if(ch==='"'||ch==="'"){quote=ch;continue;}
  if(ch==='('){depth++;continue;}if(ch===')'){depth=Math.max(0,depth-1);continue;}
  if(ch===';'&&depth===0){declarations.push(style.slice(start,i));start=i+1;}
 }
 declarations.push(style.slice(start));
 const kept=declarations.filter(item=>!/^\s*object-(?:fit|position)\s*:/i.test(item.replace(/\/\*[\s\S]*?\*\//g,''))).join(';').replace(/;+\s*$/,'');
 const positions={center:'50% 50%',left:'0% 50%',right:'100% 50%',top:'50% 0%',bottom:'50% 100%'};
 assert(presentation&&Object.keys(presentation).every(key=>['fit','focalPoint'].includes(key))&&['cover','contain'].includes(presentation.fit)&&Object.hasOwn(positions,presentation.focalPoint),'DESIGN_IMAGE','图片展示方式无效',422);
 return (kept?kept+';':'')+`object-fit:${presentation.fit} !important;object-position:${positions[presentation.focalPoint]} !important;`;
}
export function patchDesignImage(input:unknown,scope:DesignScope,asset:{file:string;path:string;sha256:string;size:number},alt?:string,options?:{dimensions?:{width:number;height:number};presentation?:ImagePresentation}){
 const manifest=clone(input) as DesignManifest,selected=designNodeHtml(manifest,scope);assert(selected.node.tagName==='img'&&!selected.node.attrs.some(a=>/^data-(aacms|media)/.test(a.name)),'DESIGN_IMAGE','请选择普通图片；动态数据图片需在 CMS 中管理');
 assert(!attr(selected.node,'srcset')&&(!('tagName' in selected.node.parentNode!)||selected.node.parentNode.tagName!=='picture'),'DESIGN_IMAGE','响应式图片请通过完整区块设计更新，避免只替换部分尺寸');
 selected.template.document.html=setAttribute(selected.template.document.html,selected.node,'src',asset.path);
 if(alt!==undefined){const latest=designNodeHtml(manifest,scope);latest.template.document.html=setAttribute(latest.template.document.html,latest.node,'alt',alt);}
 if(options?.dimensions){
  const {width,height}=options.dimensions;
  assert([width,height].every(value=>Number.isSafeInteger(value)&&value>=1&&value<=8192),'DESIGN_IMAGE','图片真实尺寸无效',422);
  for(const [name,value] of [['width',width],['height',height]] as const){const latest=designNodeHtml(manifest,scope);latest.template.document.html=setAttribute(latest.template.document.html,latest.node,name,String(value));}
 }
 if(options?.presentation){const latest=designNodeHtml(manifest,scope);latest.template.document.html=setAttribute(latest.template.document.html,latest.node,'style',imagePresentationStyle(attr(latest.node,'style')||'',options.presentation));}
 if(!manifest.assets.some(a=>a.path===asset.path))manifest.assets.push(asset);return manifest;
}
