/**
 * Atomic accounting for D1. A SQL CHECK failure, not an UPDATE row count,
 * aborts a failed mutation. User credits and provider funds MUST share this DB.
 * Grant/funding functions are trusted internal APIs: callers verify payment,
 * membership eligibility, minimum purchase and admin authorization first.
 */
export type CreditSource = 'subscription' | 'topup' | 'gift';
export type ReservationState = 'reserved' | 'dispatching' | 'uncertain' | 'settled' | 'released';
export type LedgerErrorCode = 'INVALID_AMOUNT' | 'INVALID_INPUT' | 'IDEMPOTENCY_CONFLICT'
  | 'ACCOUNT_RESTRICTED' | 'INSUFFICIENT_CREDIT' | 'INSUFFICIENT_PROVIDER_FUNDS'
  | 'RESERVATION_STATE' | 'COST_EXCEEDS_RESERVATION' | 'NOT_FOUND' | 'STORAGE_FAILURE';

export class LedgerError extends Error {
  constructor(public readonly code: LedgerErrorCode, message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = 'LedgerError';
  }
}

export interface CreditGrantInput {
  id: string; userId: string; source: CreditSource; amountMicros: number;
  expiresAtMs?: number; startsAtMs?: number; referenceId: string; nowMs?: number;
  /** The product policy must explicitly authorize the gift; this controls only allocation order. */
  giftSpendOrder?: 'before_topup' | 'after_topup';
}
export interface ProviderFundingInput {
  id: string; providerId: string; amountMicros: number; referenceId: string; nowMs?: number;
}
export interface ReserveInput {
  id: string; userId: string; providerId: string; amountMicros: number;
  requestKey: string; requestHash?: string; nowMs?: number;
  workflowGuard?: {workflowId:string;leaseToken:string};
}
export interface CreditGrant {
  id: string; userId: string; source: CreditSource; referenceId: string;
  amountMicros: number; consumedMicros: number; reservedMicros: number;
  reversedMicros: number;
  startsAtMs: number; expiresAtMs: number | null; spendPriority: number;
  membershipFrozen: boolean;
  entitlementRevoked: boolean;
}
export interface Reservation {
  id: string; userId: string; providerId: string; requestKey: string;
  requestHash: string | null; amountMicros: number; actualMicros: number | null;
  state: ReservationState; createdAtMs: number; completedAtMs: number | null;
  idempotentReplay?: boolean;
}
export interface Wallet {
  userId: string; asOfMs: number; availableMicros: number; reservedMicros: number;
  heldMicros: number; subscriptionMicros: number; topupMicros: number; giftMicros: number;
  consumedMicros: number; expiredMicros: number; pausedMicros: number; reversedMicros: number; revokedEntitlementMicros: number;
  bySource: Record<CreditSource, { availableMicros: number; reservedMicros: number; consumedMicros: number }>;
  grants: CreditGrant[];
}

type Row = Record<string, unknown>;
type Command = { key: string; nonce: string; payloadHash: string; kind: string; resourceId: string; now: number };
const NEW_COMMAND = `EXISTS (SELECT 1 FROM ledger_commands WHERE command_key = ?1 AND attempt_nonce = ?2 AND status = 'pending')`;

function identifier(value: string, name: string): string {
  if (typeof value !== 'string' || !value.trim() || value.length > 512) {
    throw new LedgerError('INVALID_INPUT', `${name} is required and must not exceed 512 characters.`);
  }
  return value;
}
function amount(value: number, allowZero = false): number {
  if (!Number.isSafeInteger(value) || value < (allowZero ? 0 : 1)) {
    throw new LedgerError('INVALID_AMOUNT', 'Money must be a safe integer number of micro-US dollars.');
  }
  return value;
}
function timestamp(value: number | undefined): number {
  const result = value ?? Date.now();
  if (!Number.isSafeInteger(result) || result < 0) throw new LedgerError('INVALID_INPUT', 'Invalid timestamp.');
  return result;
}
async function hash(value: unknown): Promise<string> {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(value)));
  return Array.from(new Uint8Array(bytes), b => b.toString(16).padStart(2, '0')).join('');
}
async function command(kind: string, identity: unknown, payload: unknown, resourceId: string, now: number): Promise<Command> {
  return { kind, key: `${kind}:${await hash(identity)}`, nonce: crypto.randomUUID(), payloadHash: await hash(payload), resourceId, now };
}
function prepared(db: D1Database, sql: string, ...values: (string | number | null)[]): D1PreparedStatement {
  return db.prepare(sql).bind(...values);
}
function begin(db: D1Database, c: Command): D1PreparedStatement {
  // Conflict preserves the ORIGINAL attempt nonce. Every remaining mutation is
  // guarded by the new nonce, so a retry is a read of the original result.
  return prepared(db, `INSERT INTO ledger_commands
    (command_key, attempt_nonce, payload_hash, kind, resource_id, created_at_ms)
    VALUES (?1, ?2, ?3, ?4, ?5, ?6)
    ON CONFLICT(command_key) DO UPDATE SET payload_hash = CASE
      WHEN ledger_commands.payload_hash = excluded.payload_hash THEN ledger_commands.payload_hash
      ELSE NULL END`, c.key, c.nonce, c.payloadHash, c.kind, c.resourceId, c.now);
}
function finish(db: D1Database, c: Command): D1PreparedStatement {
  return prepared(db, `UPDATE ledger_commands SET status = 'completed', completed_at_ms = ?3
    WHERE command_key = ?1 AND attempt_nonce = ?2 AND status = 'pending'`, c.key, c.nonce, c.now);
}
function event(db: D1Database, c: Command, userId: string | null, providerId: string | null,
  referenceId: string | null, micros: number): D1PreparedStatement {
  return prepared(db, `INSERT INTO ledger_events
    (id, command_key, kind, user_id, provider_id, resource_id, reference_id, amount_micros, created_at_ms)
    SELECT ?1, ?1, ?3, ?4, ?5, ?6, ?7, ?8, ?9 WHERE ${NEW_COMMAND}`,
  c.key, c.nonce, c.kind, userId, providerId, c.resourceId, referenceId, micros, c.now);
}
function storageError(error: unknown): LedgerError {
  if (error instanceof LedgerError) return error;
  const message = error instanceof Error ? `${error.message} ${String(error.cause ?? '')}` : String(error);
  const codes: [string, LedgerErrorCode, string][] = [
    ['ledger_commands.payload_hash', 'IDEMPOTENCY_CONFLICT', 'This operation key was already used with different data.'],
    ['provider_funding.reference_id', 'IDEMPOTENCY_CONFLICT', 'This provider deposit receipt has already been registered.'],
    ['provider_debits.reference_id', 'IDEMPOTENCY_CONFLICT', 'This provider withdrawal receipt has already been registered.'],
    ['ledger_auth_ok', 'ACCOUNT_RESTRICTED', 'The account is missing or restricted.'],
    ['ledger_credit_ok', 'INSUFFICIENT_CREDIT', 'Available AI credit cannot cover this request.'],
    ['ledger_grant_balance', 'INSUFFICIENT_CREDIT', 'Available AI credit cannot cover this request.'],
    ['ledger_grant_reversal_balance', 'INSUFFICIENT_CREDIT', 'Available AI credit cannot cover this request.'],
    ['ledger_pool_ok', 'INSUFFICIENT_PROVIDER_FUNDS', 'The provider budget is unavailable or insufficient.'],
    ['ledger_pool_balance', 'INSUFFICIENT_PROVIDER_FUNDS', 'The provider budget is unavailable or insufficient.'],
    ['ledger_state_ok', 'RESERVATION_STATE', 'The reservation does not permit this operation.'],
    ['ledger_cost_ok', 'COST_EXCEEDS_RESERVATION', 'Final cost exceeds the authorized reservation.'],
  ];
  for (const [needle, code, description] of codes) {
    if (message.includes(needle)) return new LedgerError(code, description, { cause: error });
  }
  return new LedgerError('STORAGE_FAILURE', 'Accounting could not be confirmed. Reconcile by operation key before retrying.', { cause: error });
}
async function batch(db: D1Database, statements: D1PreparedStatement[]): Promise<Row> {
  try {
    const results = await db.batch<Row>(statements);
    if (results.some(r => !r.success)) throw new Error('Accounting batch failed.');
    const row = results[results.length - 1]?.results?.[0];
    if (!row) throw new Error('Accounting batch did not return a confirmed result.');
    return row;
  } catch (error) { throw storageError(error); }
}
function grantFrom(row: Row): CreditGrant {
  return { id: String(row.id), userId: String(row.user_id), source: row.source as CreditSource,
    referenceId: String(row.reference_id), amountMicros: Number(row.amount_micros),
    consumedMicros: Number(row.consumed_micros), reservedMicros: Number(row.reserved_micros),
    reversedMicros: Number(row.reversed_micros),
    startsAtMs: Number(row.starts_at_ms), expiresAtMs: row.expires_at_ms == null ? null : Number(row.expires_at_ms),
    spendPriority: Number(row.spend_priority), membershipFrozen: row.membership_frozen_by != null,entitlementRevoked:row.entitlement_revoked_by!=null };
}
function reservationFrom(row: Row, nonce?: string): Reservation {
  return { id: String(row.id), userId: String(row.user_id), providerId: String(row.provider_id),
    requestKey: String(row.request_key), requestHash: row.request_hash == null ? null : String(row.request_hash),
    amountMicros: Number(row.amount_micros), actualMicros: row.actual_micros == null ? null : Number(row.actual_micros),
    state: row.state as ReservationState, createdAtMs: Number(row.created_at_ms),
    completedAtMs: row.completed_at_ms == null ? null : Number(row.completed_at_ms),
    ...(nonce ? { idempotentReplay: row.attempt_nonce !== nonce } : {}) };
}

export async function getWallet(db: D1Database, userId: string, nowMs?: number): Promise<Wallet> {
  identifier(userId, 'userId');
  const now = timestamp(nowMs);
  // The binding without Sessions uses the primary. Balance reads are never an authorization to spend.
  const result = await db.prepare(`SELECT * FROM credit_grants WHERE user_id = ?1
    ORDER BY spend_priority, expires_at_ms IS NULL, expires_at_ms, id`).bind(userId).all<Row>();
  const grants = result.results.map(grantFrom);
  const bySource: Wallet['bySource'] = {
    subscription: { availableMicros: 0, reservedMicros: 0, consumedMicros: 0 },
    topup: { availableMicros: 0, reservedMicros: 0, consumedMicros: 0 },
    gift: { availableMicros: 0, reservedMicros: 0, consumedMicros: 0 },
  };
  let availableMicros = 0, reservedMicros = 0, consumedMicros = 0, expiredMicros = 0, pausedMicros = 0, reversedMicros = 0,revokedEntitlementMicros=0;
  for (const g of grants) {
    const remaining = g.amountMicros - g.consumedMicros - g.reservedMicros - g.reversedMicros;
    reversedMicros += g.reversedMicros;
    const expired = !g.membershipFrozen && g.expiresAtMs !== null && g.expiresAtMs <= now;
    const available = !g.entitlementRevoked && !g.membershipFrozen && !expired && g.startsAtMs <= now ? remaining : 0;
    if(g.entitlementRevoked)revokedEntitlementMicros+=remaining;
    availableMicros += available; reservedMicros += g.reservedMicros; consumedMicros += g.consumedMicros;
    if (expired) expiredMicros += remaining;
    if (g.membershipFrozen) pausedMicros += remaining;
    bySource[g.source].availableMicros += available;
    bySource[g.source].reservedMicros += g.reservedMicros;
    bySource[g.source].consumedMicros += g.consumedMicros;
  }
  for (const total of [availableMicros, reservedMicros, consumedMicros, expiredMicros, pausedMicros, reversedMicros,revokedEntitlementMicros]) amount(total, true);
  return { userId, asOfMs: now, availableMicros, reservedMicros, heldMicros: reservedMicros,
    subscriptionMicros: bySource.subscription.availableMicros, topupMicros: bySource.topup.availableMicros,
    giftMicros: bySource.gift.availableMicros, consumedMicros, expiredMicros, pausedMicros, reversedMicros,revokedEntitlementMicros, bySource, grants };
}

/** Trusted caller policy guards and receipts may join the same grant transaction. */
export interface CreditGrantTransaction { before?: D1PreparedStatement[]; after?: D1PreparedStatement[]; }
export async function grantCredit(db: D1Database, input: CreditGrantInput, transaction: CreditGrantTransaction = {}): Promise<CreditGrant> {
  const id = identifier(input.id, 'id'), userId = identifier(input.userId, 'userId');
  const referenceId = identifier(input.referenceId, 'referenceId'), micros = amount(input.amountMicros);
  const now = timestamp(input.nowMs), starts = input.startsAtMs === undefined ? now : timestamp(input.startsAtMs);
  const expires = input.expiresAtMs === undefined ? null : timestamp(input.expiresAtMs);
  if (!['subscription', 'topup', 'gift'].includes(input.source)
    || (input.source === 'subscription' && expires === null)
    || (input.source === 'topup' && expires !== null)
    || (input.giftSpendOrder !== undefined && !['before_topup', 'after_topup'].includes(input.giftSpendOrder))) {
    throw new LedgerError('INVALID_INPUT', 'Invalid credit source, expiry or gift allocation order.');
  }
  const priority = input.source === 'subscription' ? 0 : input.source === 'topup' ? 2 : input.giftSpendOrder === 'after_topup' ? 3 : 1;
  // Omitted start time is intentionally not in the fingerprint: delivery retries may happen later.
  const c = await command('credit', [userId, input.source, referenceId],
    [userId, input.source, referenceId, micros, input.startsAtMs ?? null, expires, priority], id, now);
  const row = await batch(db, [...(transaction.before ?? []),begin(db, c),
    prepared(db, `INSERT INTO credit_grants
      (id, user_id, source, reference_id, amount_micros, starts_at_ms, expires_at_ms, spend_priority, created_at_ms)
      SELECT ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11 WHERE ${NEW_COMMAND}`,
      c.key, c.nonce, id, userId, input.source, referenceId, micros, starts, expires, priority, now),
    event(db, c, userId, null, referenceId, micros), finish(db, c),...(transaction.after ?? []),
    prepared(db, `SELECT g.* FROM credit_grants g JOIN ledger_commands c ON c.resource_id = g.id
      WHERE c.command_key = ?1 AND c.status = 'completed'`, c.key),
  ]);
  return grantFrom(row);
}

export async function fundProvider(db: D1Database, input: ProviderFundingInput): Promise<{ id: string; providerId: string; amountMicros: number; referenceId: string }> {
  const id = identifier(input.id, 'id'), providerId = identifier(input.providerId, 'providerId');
  const referenceId = identifier(input.referenceId, 'referenceId'), micros = amount(input.amountMicros), now = timestamp(input.nowMs);
  const c = await command('fund', [providerId, referenceId], [providerId, referenceId, micros], id, now);
  const row = await batch(db, [begin(db, c),
    prepared(db, `INSERT INTO provider_pools (provider_id, updated_at_ms) SELECT ?3, ?4 WHERE ${NEW_COMMAND}
      ON CONFLICT(provider_id) DO NOTHING`, c.key, c.nonce, providerId, now),
    prepared(db, `INSERT INTO provider_funding (id, provider_id, reference_id, amount_micros, created_at_ms)
      SELECT ?3, ?4, ?5, ?6, ?7 WHERE ${NEW_COMMAND}`, c.key, c.nonce, id, providerId, referenceId, micros, now),
    prepared(db, `UPDATE provider_pools SET funded_micros = funded_micros + ?4, updated_at_ms = ?5
      WHERE provider_id = ?3 AND ${NEW_COMMAND}`, c.key, c.nonce, providerId, micros, now),
    event(db, c, null, providerId, referenceId, micros), finish(db, c),
    prepared(db, `SELECT f.* FROM provider_funding f JOIN ledger_commands c ON c.resource_id = f.id
      WHERE c.command_key = ?1 AND c.status = 'completed'`, c.key),
  ]);
  return { id: String(row.id), providerId: String(row.provider_id), amountMicros: Number(row.amount_micros), referenceId: String(row.reference_id) };
}

/** An operator-confirmed withdrawal reduces only the available platform pool.
 * Reservations and past consumption remain untouched; CHECK rolls back overdraft. */
export async function debitProvider(db:D1Database,input:{id:string;providerId:string;amountMicros:number;referenceId:string;reason:string;actorId:string;nowMs?:number}){
 const resourceId=identifier(input.id,'id'),providerId=identifier(input.providerId,'providerId'),referenceId=identifier(input.referenceId,'referenceId'),reason=identifier(input.reason,'reason'),actorId=identifier(input.actorId,'actorId'),micros=amount(input.amountMicros),now=timestamp(input.nowMs);
 const c=await command('provider_debit',[referenceId],[providerId,referenceId,micros,reason,actorId],resourceId,now);
 const row=await batch(db,[begin(db,c),
  prepared(db,`UPDATE ledger_commands SET pool_ok=CASE WHEN EXISTS(SELECT 1 FROM provider_pools WHERE provider_id=?3 AND funded_micros-consumed_micros-reserved_micros-safety_micros>=?4) THEN 1 ELSE 0 END WHERE command_key=?1 AND attempt_nonce=?2 AND status='pending'`,c.key,c.nonce,providerId,micros),
  prepared(db,`INSERT INTO provider_debits(id,provider_id,reference_id,amount_micros,reason,actor_id,created_at_ms) SELECT ?3,?4,?5,?6,?7,?8,?9 WHERE ${NEW_COMMAND}`,c.key,c.nonce,resourceId,providerId,referenceId,micros,reason,actorId,now),
  prepared(db,`UPDATE provider_pools SET funded_micros=funded_micros-?4,updated_at_ms=?5 WHERE provider_id=?3 AND ${NEW_COMMAND}`,c.key,c.nonce,providerId,micros,now),
  event(db,c,null,providerId,referenceId,-micros),finish(db,c),
  prepared(db,'SELECT d.* FROM provider_debits d JOIN ledger_commands c ON c.resource_id=d.id WHERE c.command_key=?1 AND c.status=\'completed\'',c.key)
 ]);return {id:String(row.id),providerId:String(row.provider_id),amountMicros:Number(row.amount_micros),referenceId:String(row.reference_id)};
}

export async function reserve(db: D1Database, input: ReserveInput): Promise<Reservation> {
  const id = identifier(input.id, 'id'), userId = identifier(input.userId, 'userId');
  const providerId = identifier(input.providerId, 'providerId'), requestKey = identifier(input.requestKey, 'requestKey');
  const micros = amount(input.amountMicros), now = timestamp(input.nowMs);
  const requestHash = input.requestHash == null ? null : identifier(input.requestHash, 'requestHash');
  const workflowGuard=input.workflowGuard?{workflowId:identifier(input.workflowGuard.workflowId,'workflowId'),leaseToken:identifier(input.workflowGuard.leaseToken,'leaseToken')}:null;
  const c = await command('reserve', [userId, requestKey], [userId, providerId, requestKey, micros, requestHash], id, now);
  const row = await batch(db, [begin(db, c),
    prepared(db, `UPDATE ledger_commands SET auth_ok = CASE WHEN EXISTS
      (SELECT 1 FROM users WHERE id = ?3 AND status = 'active')
      AND NOT EXISTS (SELECT 1 FROM user_restrictions WHERE user_id = ?3 AND scope = 'ai' AND revoked_at IS NULL
        AND starts_at <= strftime('%Y-%m-%dT%H:%M:%fZ', ?4 / 1000.0, 'unixepoch')
        AND (ends_at IS NULL OR ends_at > strftime('%Y-%m-%dT%H:%M:%fZ', ?4 / 1000.0, 'unixepoch')))
      ${workflowGuard?"AND EXISTS(SELECT 1 FROM ai_workflow_steps s JOIN ai_workflows a ON a.id=s.workflow_id WHERE s.reservation_id=?7 AND a.id=?5 AND a.lease_token=?6 AND a.state='processing' AND a.lease_until_ms>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER))":''}
      THEN 1 ELSE 0 END
      WHERE command_key = ?1 AND attempt_nonce = ?2 AND status = 'pending'`, c.key, c.nonce, userId, now,...(workflowGuard?[workflowGuard.workflowId,workflowGuard.leaseToken,id]:[])),
    // The pool records what is held and consumed but no longer refuses work when its registered funds are short
    // (owner decision, 2026-11-13). A pool that was never funded is opened here; a shortfall is entered as an
    // automatic funding line ("auto:<reservation>"), so the registered total stays the sum of its funding lines and
    // every unfunded amount can be told apart from a real receipt. Only the disable switch refuses the reservation.
    prepared(db, `INSERT INTO provider_pools (provider_id, updated_at_ms) SELECT ?3, ?4 WHERE ${NEW_COMMAND}
      ON CONFLICT(provider_id) DO NOTHING`, c.key, c.nonce, providerId, now),
    prepared(db, `INSERT INTO provider_funding (id, provider_id, reference_id, amount_micros, created_at_ms)
      SELECT 'auto_' || ?3, provider_id, 'auto:' || ?3, ?5 - (funded_micros - consumed_micros - reserved_micros - safety_micros), ?6
      FROM provider_pools WHERE provider_id = ?4 AND enabled = 1
        AND funded_micros - consumed_micros - reserved_micros - safety_micros < ?5 AND ${NEW_COMMAND}`,
      c.key, c.nonce, id, providerId, micros, now),
    prepared(db, `UPDATE provider_pools SET funded_micros = consumed_micros + reserved_micros + safety_micros + ?4, updated_at_ms = ?5
      WHERE provider_id = ?3 AND enabled = 1
        AND funded_micros - consumed_micros - reserved_micros - safety_micros < ?4 AND ${NEW_COMMAND}`,
      c.key, c.nonce, providerId, micros, now),
    prepared(db, `UPDATE ledger_commands SET pool_ok = CASE WHEN EXISTS
      (SELECT 1 FROM provider_pools WHERE provider_id = ?3 AND enabled = 1) THEN 1 ELSE 0 END
      WHERE command_key = ?1 AND attempt_nonce = ?2 AND status = 'pending'`, c.key, c.nonce, providerId),
    prepared(db, `INSERT INTO api_reservations
      (id, user_id, provider_id, request_key, request_hash, amount_micros, created_at_ms)
      SELECT ?3, ?4, ?5, ?6, ?7, ?8, ?9 WHERE ${NEW_COMMAND}`,
      c.key, c.nonce, id, userId, providerId, requestKey, requestHash, micros, now),
    prepared(db, `WITH eligible AS (
        SELECT id, amount_micros - consumed_micros - reserved_micros - reversed_micros AS available,
          ROW_NUMBER() OVER (ORDER BY spend_priority, expires_at_ms IS NULL, expires_at_ms, id) AS ordinal,
          COALESCE(SUM(amount_micros - consumed_micros - reserved_micros - reversed_micros) OVER (
            ORDER BY spend_priority, expires_at_ms IS NULL, expires_at_ms, id
            ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING), 0) AS prior_available
        FROM credit_grants WHERE user_id = ?4 AND starts_at_ms <= ?5 AND membership_frozen_by IS NULL
          AND (expires_at_ms IS NULL OR expires_at_ms > ?5)
          AND amount_micros > consumed_micros + reserved_micros + reversed_micros AND entitlement_revoked_by IS NULL
      )
      INSERT INTO reservation_allocations (reservation_id, grant_id, ordinal, reserved_micros)
      SELECT ?3, id, ordinal, MIN(available, ?6 - prior_available) FROM eligible
      WHERE prior_available < ?6 AND ${NEW_COMMAND}`, c.key, c.nonce, id, userId, now, micros),
    prepared(db, `UPDATE ledger_commands SET credit_ok = CASE WHEN
      (SELECT COALESCE(SUM(reserved_micros), 0) FROM reservation_allocations WHERE reservation_id = ?3) = ?4
      THEN 1 ELSE 0 END WHERE command_key = ?1 AND attempt_nonce = ?2 AND status = 'pending'`,
      c.key, c.nonce, id, micros),
    prepared(db, `UPDATE credit_grants SET reserved_micros = reserved_micros +
      (SELECT a.reserved_micros FROM reservation_allocations a WHERE a.reservation_id = ?3 AND a.grant_id = credit_grants.id)
      WHERE id IN (SELECT grant_id FROM reservation_allocations WHERE reservation_id = ?3) AND ${NEW_COMMAND}`,
      c.key, c.nonce, id),
    prepared(db, `UPDATE provider_pools SET reserved_micros = reserved_micros + ?4, updated_at_ms = ?5
      WHERE provider_id = ?3 AND ${NEW_COMMAND}`, c.key, c.nonce, providerId, micros, now),
    event(db, c, userId, providerId, requestKey, micros), finish(db, c),
    prepared(db, `SELECT r.*, c.attempt_nonce FROM api_reservations r JOIN ledger_commands c ON c.resource_id = r.id
      WHERE c.command_key = ?1 AND c.status = 'completed'`, c.key),
  ]);
  return reservationFrom(row, c.nonce);
}

/** Claim exactly once immediately before sending upstream. A lost acknowledgement
 * is NOT permission to send again; a dispatching request requires reconciliation. */
export async function claimReservation(db: D1Database, id: string, nowMs?: number,workflowGuard?:{workflowId:string;leaseToken:string}): Promise<boolean> {
  identifier(id, 'id');
  if(workflowGuard){identifier(workflowGuard.workflowId,'workflowId');identifier(workflowGuard.leaseToken,'leaseToken');}
  try {
    const result = await prepared(db, `UPDATE api_reservations SET state = 'dispatching', dispatched_at_ms = ?2
      WHERE id = ?1 AND state = 'reserved'
      AND EXISTS (SELECT 1 FROM users u WHERE u.id = api_reservations.user_id AND u.status = 'active')
      AND NOT EXISTS (SELECT 1 FROM user_restrictions r WHERE r.user_id = api_reservations.user_id
        AND r.scope = 'ai' AND r.revoked_at IS NULL
        AND r.starts_at <= strftime('%Y-%m-%dT%H:%M:%fZ', ?2 / 1000.0, 'unixepoch')
        AND (r.ends_at IS NULL OR r.ends_at > strftime('%Y-%m-%dT%H:%M:%fZ', ?2 / 1000.0, 'unixepoch')))
      AND EXISTS (SELECT 1 FROM provider_pools p WHERE p.provider_id = api_reservations.provider_id AND p.enabled = 1)
      AND NOT EXISTS (SELECT 1 FROM reservation_allocations a JOIN credit_grants g ON g.id=a.grant_id
        WHERE a.reservation_id=api_reservations.id AND (g.membership_frozen_by IS NOT NULL OR g.entitlement_revoked_by IS NOT NULL))
      ${workflowGuard?"AND EXISTS(SELECT 1 FROM ai_workflow_steps s JOIN ai_workflows a ON a.id=s.workflow_id WHERE s.reservation_id=api_reservations.id AND a.id=?3 AND a.lease_token=?4 AND a.state='processing' AND a.lease_until_ms>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER))":''}
      RETURNING id`, id, timestamp(nowMs),...(workflowGuard?[workflowGuard.workflowId,workflowGuard.leaseToken]:[])).all<Row>();
    return result.results.length === 1;
  } catch (error) { throw storageError(error); }
}

export async function getReservation(db: D1Database, id: string): Promise<Reservation> {
  identifier(id, 'id');
  const row = await db.prepare('SELECT * FROM api_reservations WHERE id = ?1').bind(id).first<Row>();
  if (!row) throw new LedgerError('NOT_FOUND', 'Reservation not found.');
  return reservationFrom(row);
}

export async function markUncertain(db: D1Database, id: string): Promise<Reservation> {
  identifier(id, 'id');
  const now = Date.now(), c = await command('uncertain', [id], [id], id, now);
  const row = await batch(db, [begin(db, c),
    prepared(db, `UPDATE ledger_commands SET state_ok = CASE WHEN EXISTS
      (SELECT 1 FROM api_reservations WHERE id = ?3) THEN 1 ELSE 0 END
      WHERE command_key = ?1 AND attempt_nonce = ?2 AND status = 'pending'`, c.key, c.nonce, id),
    prepared(db, `UPDATE api_reservations SET state = 'uncertain'
      WHERE id = ?3 AND state IN ('reserved', 'dispatching') AND ${NEW_COMMAND}`, c.key, c.nonce, id),
    prepared(db, `INSERT INTO ledger_events (id, command_key, kind, user_id, provider_id, resource_id, amount_micros, created_at_ms)
      SELECT ?1, ?1, 'uncertain', user_id, provider_id, id, 0, ?4 FROM api_reservations
      WHERE id = ?3 AND state = 'uncertain' AND ${NEW_COMMAND}`, c.key, c.nonce, id, now),
    finish(db, c),
    prepared(db, 'SELECT * FROM api_reservations WHERE id = ?1', id),
  ]);
  return reservationFrom(row);
}

async function settleTo(db: D1Database, reservationId: string, actualMicros: number, nowMs: number | undefined,
  terminalState: 'settled' | 'released', imageAudit: D1PreparedStatement[] = []): Promise<Reservation> {
  identifier(reservationId, 'reservationId');
  const micros = amount(actualMicros, true), now = timestamp(nowMs);
  // Zero-cost settlement and confirmed-unused release have identical financial effects.
  const c = await command('settle', [reservationId], [reservationId, micros], reservationId, now);
  const row = await batch(db, [begin(db, c),
    prepared(db, `UPDATE ledger_commands SET state_ok = CASE WHEN EXISTS
      (SELECT 1 FROM api_reservations WHERE id = ?3 AND state IN ('reserved', 'dispatching', 'uncertain')) THEN 1 ELSE 0 END
      WHERE command_key = ?1 AND attempt_nonce = ?2 AND status = 'pending'`, c.key, c.nonce, reservationId),
    prepared(db, `UPDATE ledger_commands SET cost_ok = CASE WHEN EXISTS
      (SELECT 1 FROM api_reservations WHERE id = ?3 AND amount_micros >= ?4) THEN 1 ELSE 0 END
      WHERE command_key = ?1 AND attempt_nonce = ?2 AND status = 'pending'`, c.key, c.nonce, reservationId, micros),
    prepared(db, `UPDATE reservation_allocations AS a SET consumed_micros = MIN(reserved_micros,
      MAX(0, ?4 - (SELECT COALESCE(SUM(b.reserved_micros), 0) FROM reservation_allocations b
        WHERE b.reservation_id = a.reservation_id AND b.ordinal < a.ordinal)))
      WHERE reservation_id = ?3 AND ${NEW_COMMAND}`, c.key, c.nonce, reservationId, micros),
    prepared(db, `UPDATE credit_grants SET
      reserved_micros = reserved_micros - (SELECT a.reserved_micros FROM reservation_allocations a WHERE a.reservation_id = ?3 AND a.grant_id = credit_grants.id),
      consumed_micros = consumed_micros + (SELECT a.consumed_micros FROM reservation_allocations a WHERE a.reservation_id = ?3 AND a.grant_id = credit_grants.id)
      WHERE id IN (SELECT grant_id FROM reservation_allocations WHERE reservation_id = ?3) AND ${NEW_COMMAND}`,
      c.key, c.nonce, reservationId),
    prepared(db, `UPDATE provider_pools SET
      reserved_micros = reserved_micros - (SELECT amount_micros FROM api_reservations WHERE id = ?3),
      consumed_micros = consumed_micros + ?4, updated_at_ms = ?5
      WHERE provider_id = (SELECT provider_id FROM api_reservations WHERE id = ?3) AND ${NEW_COMMAND}`,
      c.key, c.nonce, reservationId, micros, now),
    prepared(db, `UPDATE api_reservations SET state = ?4, actual_micros = ?5, completed_at_ms = ?6
      WHERE id = ?3 AND ${NEW_COMMAND}`, c.key, c.nonce, reservationId, terminalState, micros, now),
    prepared(db, `INSERT INTO ledger_events
      (id, command_key, kind, user_id, provider_id, resource_id, reference_id, amount_micros, created_at_ms)
      SELECT ?1, ?1, ?4, user_id, provider_id, id, request_key, ?5, ?6 FROM api_reservations
      WHERE id = ?3 AND ${NEW_COMMAND}`, c.key, c.nonce, reservationId, terminalState, micros, now),
    finish(db, c), ...imageAudit,
    prepared(db, `SELECT r.*, c.attempt_nonce FROM api_reservations r JOIN ledger_commands c ON c.resource_id = r.id
      WHERE c.command_key = ?1 AND c.status = 'completed'`, c.key),
  ]);
  return reservationFrom(row, c.nonce);
}

export async function settle(db: D1Database, input: { reservationId: string; actualMicros: number; nowMs?: number }): Promise<Reservation> {
  return settleTo(db, input.reservationId, input.actualMicros, input.nowMs, 'settled');
}

/** Only call after positively establishing that no upstream fee was incurred. */
export async function releaseConfirmedUnused(db: D1Database, id: string, nowMs?: number): Promise<Reservation> {
  return settleTo(db, id, 0, nowMs, 'released');
}

/** Image opt-in only. The estimate audit and the original settlement commit
 * together; text and legacy image settlement remain unchanged. */
export async function settleEstimatedImage(db:D1Database,input:{jobId:string;reservationId:string;estimatedMicros:number;snapshotJson:string;errorCode:string;nowMs?:number}){
 const now=timestamp(input.nowMs),micros=amount(input.estimatedMicros,true);
 const job=await db.prepare('SELECT request_json,reservation_id FROM image_jobs WHERE id=?').bind(identifier(input.jobId,'jobId')).first<{request_json:string;reservation_id:string}>();
 let frozen:any;try{frozen=JSON.parse(job?.request_json??'{}').costEstimate;}catch{}
 if(!job||job.reservation_id!==input.reservationId||frozen?.policy!=='image-estimate-v1'||frozen.estimatedMicros!==micros||JSON.stringify(frozen)!==input.snapshotJson)throw new LedgerError('INVALID_INPUT','Image estimate must match its frozen dispatch policy.');
 return settleTo(db,input.reservationId,micros,now,'settled',[
  prepared(db,`INSERT INTO image_estimated_settlements(job_id,reservation_id,estimated_micros,snapshot_json,error_code,created_at_ms)
   SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM image_jobs WHERE id=? AND usage_json IS NULL)
   ON CONFLICT(job_id) DO NOTHING`,input.jobId,input.reservationId,micros,input.snapshotJson,identifier(input.errorCode,'errorCode'),now,input.jobId),
  // A real receipt arriving between the caller's read and this transaction must
  // win; do not relabel an actual settlement as an estimate with the same amount.
  prepared(db,`UPDATE ledger_commands SET state_ok=CASE WHEN EXISTS(SELECT 1 FROM image_estimated_settlements WHERE job_id=? AND reservation_id=? AND estimated_micros=?) THEN 1 ELSE 0 END
   WHERE resource_id=? AND kind='settle'`,input.jobId,input.reservationId,micros,input.reservationId),
  prepared(db,`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at)
   SELECT 'image-estimate:'||e.job_id,NULL,'image.generation_estimated','image_job',e.job_id,
    json_object('estimated',json('true'),'reservationId',e.reservation_id,'providerRequestId',j.provider_request_id,
     'estimatedMicros',e.estimated_micros,'releasedMicros',r.amount_micros-e.estimated_micros,'errorCode',e.error_code,'snapshot',json(e.snapshot_json)),
    e.job_id,strftime('%Y-%m-%dT%H:%M:%fZ',e.created_at_ms/1000.0,'unixepoch')
   FROM image_estimated_settlements e JOIN image_jobs j ON j.id=e.job_id JOIN api_reservations r ON r.id=e.reservation_id
   WHERE e.job_id=? ON CONFLICT(id) DO NOTHING`,input.jobId),
 ]);
}

export type ImageCostCorrection={jobId:string;receiptSha256:string;actualMicros:number;deltaMicros:number;state:'pending'|'applied'};
/** A trusted caller has already validated a durable provider usage receipt.
 * Append a receipt first, then atomically apply its delta. Insufficient credit
 * leaves the receipt pending, without overwriting the original settlement. */
export async function correctEstimatedImage(db:D1Database,input:{jobId:string;receiptSha256:string;actualMicros:number;nowMs?:number}):Promise<ImageCostCorrection>{
 const jobId=identifier(input.jobId,'jobId'),actual=amount(input.actualMicros,true),now=timestamp(input.nowMs);
 if(!/^[a-f0-9]{64}$/.test(input.receiptSha256))throw new LedgerError('INVALID_INPUT','A verified image receipt hash is required.');
 const original=await db.prepare(`SELECT e.*,r.user_id,r.provider_id,r.state reservation_state,r.actual_micros original_actual,j.response_sha256
  FROM image_estimated_settlements e JOIN api_reservations r ON r.id=e.reservation_id JOIN image_jobs j ON j.id=e.job_id WHERE e.job_id=?`).bind(jobId).first<any>();
 if(!original||original.reservation_state!=='settled'||original.original_actual!==original.estimated_micros||original.response_sha256!==input.receiptSha256)throw new LedgerError('RESERVATION_STATE','No matching settled image estimate and durable receipt.');
 const delta=actual-Number(original.estimated_micros),receipt=await command('image_cost_receipt',[jobId],[jobId,input.receiptSha256,actual],jobId,now);
 await batch(db,[begin(db,receipt),
  prepared(db,`INSERT INTO image_cost_corrections(job_id,receipt_sha256,actual_micros,delta_micros,created_at_ms)
   SELECT ?3,?4,?5,?6,?7 WHERE ${NEW_COMMAND}`,receipt.key,receipt.nonce,jobId,input.receiptSha256,actual,delta,now),
  prepared(db,`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at)
   SELECT 'image-cost-receipt:'||?3,NULL,'image.cost_receipt_received','image_job',?3,?4,?3,?5 WHERE ${NEW_COMMAND}`,
   receipt.key,receipt.nonce,jobId,JSON.stringify({reservationId:original.reservation_id,receiptSha256:input.receiptSha256,estimatedMicros:original.estimated_micros,actualMicros:actual,deltaMicros:delta,state:'pending'}),new Date(now).toISOString()),
  event(db,receipt,original.user_id,original.provider_id,original.reservation_id,0),finish(db,receipt),
  prepared(db,'SELECT * FROM image_cost_corrections WHERE job_id=?',jobId)]);
 const c=await command('image_cost_correction',[jobId],[jobId,input.receiptSha256,actual],jobId,now);
 const row=await batch(db,[begin(db,c),
  prepared(db,`UPDATE ledger_commands SET state_ok=CASE WHEN EXISTS(SELECT 1 FROM image_cost_corrections WHERE job_id=?3 AND state='pending') THEN 1 ELSE 0 END
   WHERE command_key=?1 AND attempt_nonce=?2 AND status='pending'`,c.key,c.nonce,jobId),
  // Positive deltas spend available grants in the usual order. A failed balance
  // check rolls back this entire batch, leaving only the pending receipt above.
  prepared(db,`WITH eligible AS (
   SELECT id,amount_micros-consumed_micros-reserved_micros-reversed_micros available,
    COALESCE(SUM(amount_micros-consumed_micros-reserved_micros-reversed_micros) OVER(ORDER BY spend_priority,expires_at_ms IS NULL,expires_at_ms,id ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0) prior
   FROM credit_grants WHERE user_id=?4 AND starts_at_ms<=?5 AND membership_frozen_by IS NULL AND entitlement_revoked_by IS NULL
    AND (expires_at_ms IS NULL OR expires_at_ms>?5) AND amount_micros>consumed_micros+reserved_micros+reversed_micros)
   INSERT INTO image_correction_allocations(job_id,grant_id,delta_micros)
   SELECT ?3,id,MIN(available,?6-prior) FROM eligible WHERE ?6>0 AND prior<?6 AND ${NEW_COMMAND}`,c.key,c.nonce,jobId,original.user_id,now,delta),
  // A refund returns to the original consumed grants, preserving expiry/freeze.
  prepared(db,`WITH used AS (
   SELECT grant_id,consumed_micros,COALESCE(SUM(consumed_micros) OVER(ORDER BY ordinal DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0) prior
   FROM reservation_allocations WHERE reservation_id=?4 AND consumed_micros>0)
   INSERT INTO image_correction_allocations(job_id,grant_id,delta_micros)
   SELECT ?3,grant_id,-MIN(consumed_micros,-?5-prior) FROM used WHERE ?5<0 AND prior< -?5 AND ${NEW_COMMAND}`,c.key,c.nonce,jobId,original.reservation_id,delta),
  prepared(db,`UPDATE ledger_commands SET credit_ok=CASE WHEN (SELECT COALESCE(SUM(delta_micros),0) FROM image_correction_allocations WHERE job_id=?3)=?4 THEN 1 ELSE 0 END
   WHERE command_key=?1 AND attempt_nonce=?2 AND status='pending'`,c.key,c.nonce,jobId,delta),
  prepared(db,`UPDATE credit_grants SET consumed_micros=consumed_micros+(SELECT a.delta_micros FROM image_correction_allocations a WHERE a.job_id=?3 AND a.grant_id=credit_grants.id)
   WHERE id IN(SELECT grant_id FROM image_correction_allocations WHERE job_id=?3) AND ${NEW_COMMAND}`,c.key,c.nonce,jobId),
  // Existing platform policy records unfunded provider expense as an explicit
  // automatic funding line. A disabled pool cannot erase an already-incurred fee.
  prepared(db,`INSERT INTO provider_funding(id,provider_id,reference_id,amount_micros,created_at_ms)
   SELECT 'image-correction:'||?3,provider_id,'auto:image-correction:'||?3,?5-(funded_micros-consumed_micros-reserved_micros-safety_micros),?6
   FROM provider_pools WHERE provider_id=?4 AND funded_micros-consumed_micros-reserved_micros-safety_micros<?5 AND ${NEW_COMMAND}`,c.key,c.nonce,jobId,original.provider_id,delta,now),
  prepared(db,`UPDATE provider_pools SET funded_micros=MAX(funded_micros,consumed_micros+reserved_micros+safety_micros+?4),consumed_micros=consumed_micros+?4,updated_at_ms=?5
   WHERE provider_id=?3 AND ${NEW_COMMAND}`,c.key,c.nonce,original.provider_id,delta,now),
  prepared(db,`UPDATE image_cost_corrections SET state='applied',applied_at_ms=?4 WHERE job_id=?3 AND ${NEW_COMMAND}`,c.key,c.nonce,jobId,now),
  prepared(db,`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at)
   SELECT 'image-cost-corrected:'||?3,NULL,'image.cost_corrected','image_job',?3,?4,?3,?5 WHERE ${NEW_COMMAND}`,
   c.key,c.nonce,jobId,JSON.stringify({reservationId:original.reservation_id,receiptSha256:input.receiptSha256,estimatedMicros:original.estimated_micros,actualMicros:actual,deltaMicros:delta,state:'applied'}),new Date(now).toISOString()),
  event(db,c,original.user_id,original.provider_id,original.reservation_id,delta),finish(db,c),
  prepared(db,'SELECT * FROM image_cost_corrections WHERE job_id=?',jobId),
 ]);
 return {jobId,receiptSha256:String(row.receipt_sha256),actualMicros:Number(row.actual_micros),deltaMicros:Number(row.delta_micros),state:row.state as 'applied'};
}
