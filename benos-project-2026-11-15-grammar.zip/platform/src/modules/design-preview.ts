﻿import { Hono,type Context } from 'hono';
import { type App } from '../lib/http';
import { assert } from '../lib/errors';
import { sha256 } from '../lib/crypto';
import { requireAuth } from './auth';
import type { Env } from '../env';
import { indexProjectAssets } from './project-assets';
import { annotateDesignHtml } from './design-nodes';
import { readDesignCandidate,readDesignVersion } from './design-workspace';
import { starterManifest } from '../contracts/starter-library';
import { isStarterPackage,starterPackageManifest,starterAssetUrl } from '../lib/starter-packages';
import { liveManifest,type DraftFile } from '../lib/workflow-progress';
import example from '../contracts/site-example.json';
import { foundationFromRequirements,foundationAuthoringExample } from '../contracts/design-foundation';

type Site={home:string;pages:Array<{key:string;slug:string;template_id:number}>;header_template_id?:number;footer_template_id?:number;theme?:{global_css?:string}};
export function previewLinkTarget(href:string,site:Site,base:string):string|null {
 if(href.startsWith('#'))return href;
 let url:URL;try{url=new URL(href,'https://preview.benos.invalid/');}catch{return null;}
 if(url.origin!=='https://preview.benos.invalid')return null;
 let path:string;try{path=decodeURIComponent(url.pathname).replace(/^\/|\/$/g,'');}catch{return null;}
 const page=site.pages.find(p=>path===''?p.key===site.home:p.slug===path);
 return page?`${base}?page=${encodeURIComponent(page.key)}${url.hash}`:null;
}
function escape(value:string){return value.replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]!));}
export const previewRoutes=new Hono<App>();previewRoutes.use('*',requireAuth);
previewRoutes.get('/starter/:template',async c=>{const id=c.req.param('template');
 // A packaged starter is shown with its own media files; nothing is copied anywhere for a preview.
 if(isStarterPackage(id)){const packaged=await starterPackageManifest(c.env,id);return renderDesignPreview(c,packaged,null,`/preview/starter/${encodeURIComponent(id)}`,Object.fromEntries((packaged.assets as {file:string;path:string}[]).map(asset=>[asset.path,starterAssetUrl(id,asset.file)])));}
 const manifest=starterManifest(id);assert(manifest,'NOT_FOUND','起步模板不存在',404);return renderDesignPreview(c,manifest,null,`/preview/starter/${encodeURIComponent(c.req.param('template'))}`);});
previewRoutes.get('/:project/candidate/:candidate',async c=>{
 const row=await readDesignCandidate(c.env,c.get('auth').user.id,c.req.param('project'),c.req.param('candidate'));
 return renderDesignPreview(c,JSON.parse(row.manifest_json),c.req.param('project'),`/preview/${encodeURIComponent(c.req.param('project'))}/candidate/${encodeURIComponent(row.id)}`);
});
/**
 * The design as far as the model has written it in the step that is still being answered. Unvalidated model
 * output, shown under the same sandbox as every preview (no scripts, no network beyond own images); links are
 * switched off and nothing here is saved. 404 when the step has no draft (any more).
 */
previewRoutes.get('/:project/live/:workflow',async c=>{
 const userId=c.get('auth').user.id,projectId=c.req.param('project');
 const row=await c.env.DB.prepare("SELECT w.manifest_json,w.base_manifest_json,w.requirements_json,w.workspace_id,s.state AS step_state,s.progress_draft FROM ai_workflows w JOIN ai_workflow_steps s ON s.workflow_id=w.id WHERE w.id=? AND w.user_id=? AND w.project_id=? AND w.state='processing' AND (s.state='dispatching' OR (s.state='responded' AND json_extract(w.requirements_json,'$.designPipelineVersion') IN ('frame-first-1','frame-first-2','site-grammar-1'))) AND s.progress_draft IS NOT NULL ORDER BY s.ordinal DESC LIMIT 1").bind(c.req.param('workflow'),userId,projectId).first<{manifest_json:string;base_manifest_json:string|null;requirements_json:string;workspace_id:string|null;step_state:string;progress_draft:string}>();
 assert(row&&!row.workspace_id,'NOT_FOUND','暂无生成中的预览',404);
 let files:DraftFile[]=[],working:any=null;try{files=JSON.parse(row.progress_draft);working=JSON.parse(row.manifest_json);}catch{/* nothing to show */}
 const live=liveManifest(working,Array.isArray(files)?files:[],foundationFromRequirements(row.requirements_json));assert(live,'NOT_FOUND','暂无生成中的预览',404);
 const by=(id:unknown)=>live.templates.find(t=>t.id===id),written=(t:{document:{html:string}}|undefined)=>!!t&&!!t.document.html.trim();
 // A page that is being written again (a correction after the first full pass) stays on screen as it was until its
 // new version is complete: a page that empties and regrows in front of the customer reads as work being lost.
 const profile=foundationFromRequirements(row.requirements_json),whole=files.some(f=>f?.path==='manifest.json'),established=row.base_manifest_json!==null||row.manifest_json!==JSON.stringify(profile?foundationAuthoringExample(profile):example);
 const before=(id:number)=>!whole&&established&&Array.isArray(working?.templates)?working.templates.find((t:any)=>t?.id===id&&typeof t?.document?.html==='string'&&t.document.html.trim()):null;
 // The fully persisted scaffold is no longer following the stream's last
 // template. A system-added contact page must not steal the home preview.
 const body=livePreviewBody(live,c.req.query('page'),whole,row.step_state==='responded');
 const selected=[by(live.site?.header_template_id),body,by(live.site?.footer_template_id)].filter(written) as typeof live.templates;
 const parts=selected.length?selected:live.templates.filter(written).slice(0,1);
 // The page is drawn as it is written: everything up to the last complete tag of the template under way. Nothing
 // is shown before there is a stylesheet to dress it (bare text would only look broken).
 const shown=parts.map(t=>{const kept=t.id===live.latest?before(t.id):null;return kept?{html:String(kept.document.html),css:String(kept.document.css??'')}:{html:t.id===live.latest?writtenMarkup(t.document.html):t.document.html,css:t.document.css};});
 let html=shown.map(t=>t.html).join('\n'),css=String(live.site?.theme?.global_css||'')+shown.map(t=>t.css).join('\n')+'body{margin:0}';
 assert(css.trim()&&html.trim(),'NOT_FOUND','暂无生成中的预览',404);
 // Reading position is managed by the parent canvas. Stream updates must not add movement of their own.
 css+='\nhtml{scroll-behavior:auto!important;overflow-anchor:none}';
 try{({html,css}=await designPreviewAssets(c.env,userId,projectId,{assets:live.assets},html,css));}catch{/* images appear once the proposal is saved */}
 const pageKey=live.site?.pages.find((item:any)=>item.template_id===body?.id)?.key||'';
 const document=`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="benos-preview-mode" content="live"><meta name="benos-live-page" content="${body?.id??0}"><meta name="benos-preview-page" content="${body?.id??0}"><meta name="benos-preview-page-key" content="${escape(pageKey)}"><title>生成中</title><style>${css.replace(/<\/style/gi,'<\\/style')}</style></head><body>${html}</body></html>`;
 const response=new Response(document,{headers:{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"sandbox allow-same-origin; default-src 'none'; script-src 'none'; style-src 'unsafe-inline' https://fonts.googleapis.com; img-src 'self' data:; font-src https://fonts.gstatic.com; form-action 'none'; base-uri 'none'; frame-ancestors 'self'",'Cache-Control':'no-store','X-Frame-Options':'SAMEORIGIN','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'}});
 return new HTMLRewriter().on('a[href]',{element(element){element.removeAttribute('href');element.removeAttribute('target');element.setAttribute('aria-disabled','true');}}).transform(response);
});
previewRoutes.get('/:project/:version',async c=>{
 const projectId=c.req.param('project'),versionId=c.req.param('version'),userId=c.get('auth').user.id;
 const manifest=await readDesignVersion(c.env,userId,projectId,versionId);
 return renderDesignPreview(c,manifest,projectId,`/preview/${encodeURIComponent(projectId)}/${encodeURIComponent(versionId)}`);
});
/** Shared-chrome edits stay on the requested page, or home by default. A whole new
 * manifest follows its last written body, while an actual body edit always wins. */
export function livePreviewBody(live:NonNullable<ReturnType<typeof liveManifest>>,requestedPage:string|undefined,whole:boolean,prepared=false){
 const by=(id:unknown)=>live.templates.find(t=>t.id===id),pages=live.site?.pages??[];
 const chrome=new Set([live.site?.header_template_id,live.site?.footer_template_id]);
 const pageIds=new Set(pages.map((page:any)=>page.template_id));
 const isPage=(template:typeof live.templates[number]|undefined)=>!!template&&!!template.document.html.trim()&&!chrome.has(template.id)&&(!pageIds.size||pageIds.has(template.id));
 const requested=requestedPage===undefined?undefined:pages.find((page:any)=>page.key===requestedPage||page.slug===requestedPage);
 const home=pages.find((page:any)=>page.key===live.site?.home);
 const candidates=[by(requested?.template_id),by(home?.template_id)];
 if(prepared)return candidates.find(isPage)??live.templates.find(isPage);
 const current=by(live.latest);if(isPage(current))return current;
 if(whole)return [...live.templates].reverse().find(isPage);
 return candidates.find(isPage)??live.templates.find(isPage);
}
/** Markup up to the end of its last finished block; an unfinished trailing block is left for the next rendering. */
export function finishedBlocks(html:string):string{
 let end=0;for(const match of html.matchAll(/<\/(?:header|section|footer|nav|article)\s*>/gi))end=match.index!+match[0].length;
 return html.slice(0,end);
}
/** Markup up to its last complete tag: text and elements appear as they are written, never half a tag. */
export function writtenMarkup(html:string):string{return html.slice(0,html.lastIndexOf('>')+1);}
export async function renderDesignPreview(c:Context<App>,manifest:any,projectId:string|null,base:string,assetUrls?:Record<string,string>){
 const userId=c.get('auth').user.id,site=manifest.site as Site,requested=c.req.query('page')||site.home,page=site.pages.find(p=>p.key===requested||p.slug===requested);assert(page,'NOT_FOUND','页面不存在',404);
 const selected=[site.header_template_id,page.template_id,site.footer_template_id].map(key=>manifest.templates.find((t:any)=>t.id===key)).filter(Boolean);
 const sourceHash=await sha256(JSON.stringify(manifest));
 const editing=c.req.query('editor')==='1';
 let css=String(site.theme?.global_css||'')+selected.map((t:any)=>t.document.css||'').join('\n'),html=selected.map((t:any)=>editing?annotateDesignHtml(t.document.html,t.id):t.document.html).join('\n');
 ({html,css}=await designPreviewAssets(c.env,userId,projectId,manifest,html,css,assetUrls));
 const document=`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="benos-preview-mode" content="design"><meta name="benos-preview-source-hash" content="${sourceHash}"><meta name="benos-preview-page" content="${page.template_id}"><meta name="benos-preview-page-key" content="${escape(page.key)}"><title>${escape(manifest.site.name||'Benos 网站预览')}</title><style>${css.replace(/<\/style/gi,'<\\/style')}</style></head><body>${html}</body></html>`;
 const response=new Response(document,{headers:{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"sandbox allow-same-origin; default-src 'none'; script-src 'none'; style-src 'unsafe-inline' https://fonts.googleapis.com; img-src 'self' data:; font-src https://fonts.gstatic.com; form-action 'none'; base-uri 'none'; frame-ancestors 'self'",'Cache-Control':'no-store','X-Frame-Options':'SAMEORIGIN','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'}});
 return new HTMLRewriter().on('a[href]',{element(element){
  let target=previewLinkTarget(element.getAttribute('href')||'',site,base);if(editing&&target?.startsWith(base+'?')){const url=new URL(target,'https://preview.benos.invalid');url.searchParams.set('editor','1');target=url.pathname+url.search+url.hash;}element.removeAttribute('target');element.removeAttribute('download');
  if(target)element.setAttribute('href',target);else{element.removeAttribute('href');element.setAttribute('aria-disabled','true');element.setAttribute('title','此链接在正式网站中可用');}
 }}).transform(response);
}
/** The script-free design iframe keeps its same origin, so each image can use
 * the existing authenticated media endpoint. Never embed all media as base64.
 * Native opaque previews use a different, separately scoped transport. */
export async function designPreviewAssets(env:Env,userId:string,projectId:string|null,manifest:any,html:string,css:string,assetUrls?:Record<string,string>){
 const resolved=assetUrls?{mapping:assetUrls}:projectId?await indexProjectAssets(env,userId,projectId,manifest):{mapping:{} as Record<string,string>};
 for(const asset of manifest.assets){
  const ext=asset.file.split('.').pop();
  // PDF is a download resource, never an image or executable data navigation.
  // Private downloads are available from the parent project's media library.
  if(ext==='pdf')continue;
  const url=resolved.mapping[asset.path];assert(url,'MEDIA_NOT_FOUND','预览素材不存在',422);
  css=css.split(asset.path).join(url);html=html.split(asset.path).join(url);
 }
 return {html,css};
}
