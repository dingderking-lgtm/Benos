import { fetchWithoutRedirect } from '../lib/provider-fetch';
import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id,sha256,encryptSecret,decryptSecret } from '../lib/crypto';
import { requireAuth } from './auth';
import { loadEmailConfiguration,type EmailConfiguration } from './email';
import { PARKED_JOB } from './hosting-billing';
import { renewalGraceTerm } from './commerce';

const DAY=86400000;
type Interval={start:number;end:number};
type Subscription={id:string;tier:string;starts_at:string;ends_at:string;included_sites:number;auto_renew:number;};
type Annual={site_id:string;starts_at:string;ends_at:string;};
type Notice={id:string;user_id:string;target_key:string;service:'membership'|'hosting';site_id:string|null;stage:'before_7_days'|'before_1_day'|'expired';ends_at:string;title:string;body:string;state:string;read_at:string|null;created_at:string;};
type Candidate={targetKey:string;service:'membership'|'hosting';siteId:string|null;stage:Notice['stage'];endsAt:string;title:string;body:string;};
type Mail={id:string;notification_id:string;user_id:string;config_version_id:string;recipient_snapshot:string;payload_ciphertext:string|null;state:string;attempts:number;first_attempt_ms:number|null;expires_at:string;};
export interface NotificationRuntime{nowMs?:number;fetch?:typeof fetch;userLimit?:number;mailLimit?:number;}
function merge(intervals:Interval[]){const result:Interval[]=[];for(const item of intervals.sort((a,b)=>a.start-b.start||a.end-b.end)){const last=result.at(-1);if(last&&last.end>=item.start)last.end=Math.max(last.end,item.end);else result.push({...item});}return result;}
function pickInterval(intervals:Interval[],now:number){return intervals.find(x=>x.start<=now&&x.end>now)??intervals.filter(x=>x.end<=now&&x.end>now-31*DAY).at(-1);}
function stage(end:number,now:number):Notice['stage']|null{const gap=end-now;return gap>7*DAY?null:gap>DAY?'before_7_days':gap>0?'before_1_day':end>now-31*DAY?'expired':null;}
const candidateKey=(n:Pick<Candidate,'targetKey'|'endsAt'|'stage'>)=>JSON.stringify([n.targetKey,n.endsAt,n.stage]);
/** Evaluate actual coverage, including contiguous future gift months and annual
 * hosting that removes a site from the membership slot allocation. */
export async function notificationCandidates(env:Env,userId:string,now=Date.now()):Promise<Candidate[]>{
 const cutoff=new Date(now-31*DAY).toISOString();
 const [subsResult,annualResult,sitesResult,frozen,parkedResult,grace]=await Promise.all([
  env.DB.prepare("SELECT id,tier,starts_at,ends_at,included_sites,auto_renew FROM subscriptions WHERE user_id=? AND state IN ('active','cancelled') AND membership_frozen_by IS NULL AND ends_at>? ORDER BY starts_at,ends_at").bind(userId,cutoff).all<Subscription>(),
  env.DB.prepare("SELECT site_id,starts_at,ends_at FROM hosting_entitlements WHERE user_id=? AND source IN ('annual','gift') AND state='active' AND ends_at>? ORDER BY starts_at,ends_at").bind(userId,cutoff).all<Annual>(),
  env.DB.prepare('SELECT id,name,created_at FROM sites WHERE user_id=? ORDER BY created_at,id').bind(userId).all<{id:string;name:string;created_at:string}>(),
  env.DB.prepare("SELECT id FROM membership_freezes WHERE user_id=? AND state IN ('frozen','pending_unfreeze') LIMIT 1").bind(userId).first(),
  // An unpaid pay-first site (job parked at awaiting_payment) never takes a membership slot,
  // the same rule as the billing summary and the hosting entitlement.
  env.DB.prepare(`SELECT DISTINCT site_id FROM provisioning_jobs WHERE user_id=? AND ${PARKED_JOB}`).bind(userId).all<{site_id:string}>(),
  // R4-m3: an auto-renewing term in its renewal grace (the cycle invoice is not
  // confirmed yet) has not expired; its sites are still hosted (hostingSubscription).
  renewalGraceTerm(env.DB,userId,new Date(now).toISOString()),
 ]);
 const graceEnd=grace?Date.parse(grace.ends_at):null;
 const subscriptions=subsResult.results,annual=annualResult.results,sites=sitesResult.results,parked=new Set(parkedResult.results.map(row=>row.site_id)),items:Candidate[]=[];
 function add(targetKey:string,service:Candidate['service'],siteId:string|null,label:string,period:Interval|undefined,renewing=false){if(!period||period.start>now)return;const phase=stage(period.end,now);if(!phase||(phase==='expired'&&period.end===graceEnd))return;const endsAt=new Date(period.end).toISOString(),date=endsAt.replace('T',' ').slice(0,16)+' UTC',expired=phase==='expired';items.push({targetKey,service,siteId,stage:phase,endsAt,title:label+(expired?'已到期':'即将到期'),body:`${label}${expired?'的当前权益已于':'的当前权益将于'} ${date} 结束。${renewing&&!expired?'当前设有自动续费，下期权益以实际付款成功为准。':''}${service==='membership'?'历史充值余额仍可继续使用；到期后须重新购买有效会员才能充值，独立年费托管另行计算。':'请在仪表盘核对该网站的托管覆盖并按需续费；暂停托管会保留网站数据。'}${expired?'如已续费但状态尚未更新，请查询原订单或联系支持。':''}`});}
 if(!frozen){const intervals=merge(subscriptions.map(s=>({start:Date.parse(s.starts_at),end:Date.parse(s.ends_at)}))),current=pickInterval(intervals,now);add('membership:'+userId,'membership',null,'会员',current,subscriptions.some(s=>s.auto_renew===1&&Date.parse(s.ends_at)===current?.end));}
 const boundaries=[...new Set([...subscriptions.flatMap(s=>[Date.parse(s.starts_at),Date.parse(s.ends_at)]),...annual.flatMap(a=>[Date.parse(a.starts_at),Date.parse(a.ends_at)])])].sort((a,b)=>a-b),coverage=new Map(sites.map(s=>[s.id,[] as Interval[]]));
 for(let index=0;index<boundaries.length-1;index++){
  const start=boundaries[index],end=boundaries[index+1],direct=new Set(annual.filter(a=>Date.parse(a.starts_at)<=start&&Date.parse(a.ends_at)>start).map(a=>a.site_id));
  const member=subscriptions.filter(s=>Date.parse(s.starts_at)<=start&&Date.parse(s.ends_at)>start).sort((a,b)=>(a.tier==='pro'?0:1)-(b.tier==='pro'?0:1)||b.ends_at.localeCompare(a.ends_at))[0];
  const included=new Set(member?sites.filter(s=>!direct.has(s.id)&&!parked.has(s.id)).slice(0,member.included_sites).map(s=>s.id):[]);
  for(const site of sites)if((direct.has(site.id)||included.has(site.id))&&Date.parse(site.created_at)<end)coverage.get(site.id)!.push({start:Math.max(start,Date.parse(site.created_at)),end});
 }
 for(const site of sites){const current=pickInterval(merge(coverage.get(site.id)!),now);
  // A membership pause is not an expiry. Independently expiring annual coverage
  // still has a real boundary; a site losing only paused membership is skipped.
  if(frozen&&!annual.some(a=>a.site_id===site.id&&Date.parse(a.ends_at)===current?.end))continue;
  add('hosting:'+site.id,'hosting',site.id,`网站“${site.name}”的托管`,current);
 }
 return items;
}
async function currentCandidate(env:Env,notice:Notice,now:number){return (await notificationCandidates(env,notice.user_id,now)).some(n=>candidateKey(n)===candidateKey({targetKey:notice.target_key,endsAt:notice.ends_at,stage:notice.stage}));}
async function syncUser(env:Env,userId:string,now:number){
 const candidates=await notificationCandidates(env,userId,now),existing=(await env.DB.prepare("SELECT * FROM service_notifications WHERE user_id=? AND state='active'").bind(userId).all<Notice>()).results,keys=new Set(candidates.map(candidateKey)),statements:D1PreparedStatement[]=[],insertIndexes:number[]=[],reactivationIndexes:number[]=[],time=new Date(now).toISOString();let superseded=0;
 for(const old of existing)if(!keys.has(candidateKey({targetKey:old.target_key,endsAt:old.ends_at,stage:old.stage}))){statements.push(env.DB.prepare("UPDATE service_notifications SET state='superseded' WHERE id=? AND state='active'").bind(old.id));superseded++;}
 for(const n of candidates){const notificationId='notice_'+await sha256(candidateKey(n));insertIndexes.push(statements.length);statements.push(env.DB.prepare('INSERT INTO service_notifications(id,user_id,target_key,service,site_id,stage,ends_at,title,body,created_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(target_key,ends_at,stage) DO NOTHING').bind(notificationId,userId,n.targetKey,n.service,n.siteId,n.stage,n.endsAt,n.title,n.body,time));
  // Revoking a future renewal can make this exact prior boundary relevant again.
  // Preserve identity, read state, creation time and every delivery record.
  reactivationIndexes.push(statements.length);statements.push(env.DB.prepare("UPDATE service_notifications SET state='active',title=?,body=? WHERE id=? AND user_id=? AND state='superseded'").bind(n.title,n.body,notificationId,userId));
 }
 const results=statements.length?await env.DB.batch(statements):[];return {created:insertIndexes.reduce((sum,index)=>sum+results[index].meta.changes,0),reactivated:reactivationIndexes.reduce((sum,index)=>sum+results[index].meta.changes,0),superseded:results.slice(0,superseded).reduce((sum,r)=>sum+r.meta.changes,0)};
}
async function queueEmail(env:Env,notice:Notice,config:EmailConfiguration,now:number){
 const user=await env.DB.prepare('SELECT email FROM users WHERE id=?').bind(notice.user_id).first<{email:string}>();if(!user)return false;
 const origin=new URL(env.APP_ORIGIN);assert(origin.protocol==='https:'||(env.APP_ENV!=='production'&&origin.protocol==='http:'),'NOTIFICATION_ORIGIN_INVALID','通知链接配置无效',503);
 const mailId='service_mail_'+notice.id,time=new Date(now).toISOString(),end=Date.parse(notice.ends_at),windowEnd=notice.stage==='before_7_days'?end-DAY:notice.stage==='before_1_day'?end:end+31*DAY,expires=new Date(Math.min(now+23*3600000,windowEnd)).toISOString();if(expires<=time)return false;
 const payload={from:`${config.fromName} <${config.fromEmail}>`,to:[user.email],subject:'Benos · '+notice.title,text:notice.body+`\n\n查看账户：${origin.origin}/#billing`,...(config.replyTo?{reply_to:config.replyTo}:{})};
 const encrypted=await encryptSecret(JSON.stringify(payload),env.ENCRYPTION_KEY,mailId),result=await env.DB.prepare(`INSERT INTO service_notification_outbox(id,notification_id,user_id,config_version_id,recipient_snapshot,payload_ciphertext,state,created_at,updated_at,expires_at)
 SELECT ?,?,?,?,?,?,'queued',?,?,? WHERE EXISTS(SELECT 1 FROM service_notifications WHERE id=? AND state='active') ON CONFLICT(notification_id) DO NOTHING`).bind(mailId,notice.id,notice.user_id,config.id,user.email,encrypted,time,time,expires,notice.id).run();return !!result.meta.changes;
}
async function sendQueued(env:Env,runtime:NotificationRuntime){
 const now=runtime.nowMs??Date.now(),time=new Date(now).toISOString(),limit=Math.max(1,Math.min(20,runtime.mailLimit??10));
 // Expiry after a possibly accepted request must remain visibly uncertain.
 await env.DB.prepare(`UPDATE service_notification_outbox SET state=CASE WHEN state IN ('sending','uncertain') THEN 'uncertain' ELSE 'expired' END,
 payload_ciphertext=NULL,error_code=CASE WHEN state IN ('sending','uncertain') THEN 'EMAIL_RETRY_WINDOW_CLOSED' ELSE error_code END,lease_token=NULL,lease_until_ms=NULL,updated_at=?
 WHERE state IN ('queued','sending','uncertain') AND (expires_at<=? OR first_attempt_ms<=?)`).bind(time,time,now-23*3600000).run();
 if(env.NOTIFICATION_EMAIL_ENABLED!=='true')return {emailsAccepted:0,emailsUncertain:0,failed:0};
 const rows=(await env.DB.prepare(`SELECT * FROM service_notification_outbox WHERE state IN ('queued','sending','uncertain') AND payload_ciphertext IS NOT NULL AND expires_at>? AND attempts<5 AND (lease_until_ms IS NULL OR lease_until_ms<=?) ORDER BY created_at LIMIT ?`).bind(time,now,limit).all<Mail>()).results;
 let emailsAccepted=0,emailsUncertain=0,failed=0;
 for(const mail of rows){
  const notice=await env.DB.prepare('SELECT * FROM service_notifications WHERE id=?').bind(mail.notification_id).first<Notice>(),user=await env.DB.prepare('SELECT email FROM users WHERE id=?').bind(mail.user_id).first<{email:string}>();
  const validNotice=!!notice&&notice.state==='active'&&await currentCandidate(env,notice,now),enabledConfig=await env.DB.prepare("SELECT id FROM integration_configs WHERE id=? AND kind='email' AND status='active' AND test_status='passed'").bind(mail.config_version_id).first();
  if(!validNotice||user?.email!==mail.recipient_snapshot||!enabledConfig){
   const uncertain=mail.state==='sending'||mail.state==='uncertain';await env.DB.prepare('UPDATE service_notification_outbox SET state=?,payload_ciphertext=NULL,error_code=?,updated_at=? WHERE id=?').bind(uncertain?'uncertain':'suppressed',uncertain?'EMAIL_SUPERSEDED_UNCONFIRMED':'NOTICE_SUPERSEDED',time,mail.id).run();if(notice&&!validNotice)await env.DB.prepare("UPDATE service_notifications SET state='superseded' WHERE id=?").bind(notice.id).run();continue;
  }
  const lease=id('notice_lease'),claimed=await env.DB.prepare(`UPDATE service_notification_outbox SET state='sending',first_attempt_ms=COALESCE(first_attempt_ms,?),attempts=attempts+1,lease_token=?,lease_until_ms=?,updated_at=? WHERE id=? AND state IN ('queued','sending','uncertain') AND payload_ciphertext IS NOT NULL AND expires_at>? AND attempts<5 AND (lease_until_ms IS NULL OR lease_until_ms<=?) RETURNING id`).bind(now,lease,now+30000,time,mail.id,time,now).first();if(!claimed)continue;
  try{
   const config=await loadEmailConfiguration(env,mail.config_version_id),payload=JSON.parse(await decryptSecret(mail.payload_ciphertext!,env.ENCRYPTION_KEY,mail.id));
   const result=await fetchWithoutRedirect('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${config.apiKey}`,'Content-Type':'application/json','Idempotency-Key':'benos:service:'+mail.id},body:JSON.stringify(payload),signal:AbortSignal.timeout(15000)},runtime.fetch??fetch);
   if(!result.ok)throw new AppError(result.status===429||result.status>=500?'EMAIL_DELIVERY_UNCONFIRMED':'EMAIL_REJECTED','通知邮件请求未确认',503);
   const data=await result.json() as {id?:unknown};assert(typeof data.id==='string'&&data.id.length<=200,'EMAIL_DELIVERY_UNCONFIRMED','通知邮件结果未确认',503);
   await env.DB.prepare("UPDATE service_notification_outbox SET state='accepted',provider_message_id=?,payload_ciphertext=NULL,error_code=NULL,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?").bind(data.id,time,mail.id,lease).run();emailsAccepted++;
  }catch(error){const current=await env.DB.prepare('SELECT state FROM service_notification_outbox WHERE id=?').bind(mail.id).first<{state:string}>();if(current?.state==='accepted'){emailsAccepted++;continue;}const code=error instanceof AppError?error.code:'EMAIL_DELIVERY_UNCONFIRMED',state=code==='EMAIL_REJECTED'?'failed':'uncertain';await env.DB.prepare('UPDATE service_notification_outbox SET state=?,error_code=?,payload_ciphertext=CASE WHEN ?=\'failed\' THEN NULL ELSE payload_ciphertext END,lease_token=NULL,lease_until_ms=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(state,code,state,time,mail.id,lease).run();if(state==='uncertain')emailsUncertain++;else failed++;}
 }
 return {emailsAccepted,emailsUncertain,failed};
}
/** Bounded, cursor-based maintenance job. It never interprets queued mail as
 * delivered, and disabled service notification email performs zero HTTP calls. */
export async function processServiceNotifications(env:Env,runtime:NotificationRuntime={}){
 const now=runtime.nowMs??Date.now(),time=new Date(now).toISOString(),limit=Math.max(1,Math.min(100,runtime.userLimit??50)),cursor=await env.DB.prepare("SELECT user_cursor FROM notification_scan_state WHERE name='service-expiry'").first<{user_cursor:string}>();
 const users=(await env.DB.prepare('SELECT id FROM users WHERE id>? AND (EXISTS(SELECT 1 FROM subscriptions s WHERE s.user_id=users.id) OR EXISTS(SELECT 1 FROM sites s WHERE s.user_id=users.id)) ORDER BY id LIMIT ?').bind(cursor?.user_cursor??'',limit).all<{id:string}>()).results;
 let created=0,reactivated=0,superseded=0,emailsQueued=0,failed=0;let mailConfig:EmailConfiguration|null=null;
 if(env.NOTIFICATION_EMAIL_ENABLED==='true')try{mailConfig=await loadEmailConfiguration(env);}catch{/* In-app notices remain usable when email is unavailable. */}
 for(const user of users){try{const result=await syncUser(env,user.id,now);created+=result.created;reactivated+=result.reactivated;superseded+=result.superseded;if(mailConfig){const notices=(await env.DB.prepare("SELECT n.* FROM service_notifications n WHERE n.user_id=? AND n.state='active' AND NOT EXISTS(SELECT 1 FROM service_notification_outbox m WHERE m.notification_id=n.id)").bind(user.id).all<Notice>()).results;for(const notice of notices)if(await currentCandidate(env,notice,now)&&await queueEmail(env,notice,mailConfig,now))emailsQueued++;}}catch{failed++;}}
 await env.DB.prepare("INSERT INTO notification_scan_state(name,user_cursor,updated_at) VALUES('service-expiry',?,?) ON CONFLICT(name) DO UPDATE SET user_cursor=excluded.user_cursor,updated_at=excluded.updated_at").bind(users.length===limit?users.at(-1)!.id:'',time).run();
 const delivery=await sendQueued(env,runtime);return {usersScanned:users.length,created,reactivated,superseded,emailsQueued,emailsAccepted:delivery.emailsAccepted,emailsUncertain:delivery.emailsUncertain,failed:failed+delivery.failed};
}
export type NotificationTarget={kind:'membership'}|{kind:'site';siteId:string};
/** Href-free routing hint. The front end owns its routes; the server only names
 * the subject. Only the platform `site_…` id is exposed, never provider, pool,
 * account or domain details. */
export function notificationTarget(n:Pick<Notice,'service'|'site_id'>):NotificationTarget{return n.service==='hosting'&&n.site_id?{kind:'site',siteId:n.site_id}:{kind:'membership'};}
/** Active notices that are still valid right now, newest first. Renewal may occur
 * between scheduler runs, so a stale expiry warning is never shown or counted. */
async function visibleNotices(env:Env,userId:string,now=Date.now()){
 const rows=await env.DB.prepare("SELECT * FROM service_notifications WHERE user_id=? AND state='active' ORDER BY created_at DESC,id").bind(userId).all<Notice>(),keys=new Set((await notificationCandidates(env,userId,now)).map(candidateKey));
 return rows.results.filter(n=>keys.has(candidateKey({targetKey:n.target_key,endsAt:n.ends_at,stage:n.stage})));
}
const UP_TO_MESSAGE='请提供有效的时间';
// The type error (null, number, object…) gets the same Chinese message as the format check.
const readAllInput=z.strictObject({upTo:z.string({error:UP_TO_MESSAGE}).datetime({error:UP_TO_MESSAGE}).optional()},{error:'请求内容不正确'});
/** `upTo` may arrive at any fractional precision; `created_at` is always a millisecond
 * ISO string. Compare instants, never strings. Flooring to the millisecond is exact
 * here: a millisecond `created_at` is <= upTo exactly when it is <= floor_ms(upTo). */
function readAllCutoff(upTo:string|undefined){
 if(upTo===undefined)return undefined;
 const ms=Date.parse(upTo);assert(Number.isFinite(ms),'VALIDATION',UP_TO_MESSAGE,400);
 return {ms,iso:new Date(ms).toISOString()};
}
export const notificationRoutes=new Hono<App>();notificationRoutes.use('*',requireAuth);
notificationRoutes.get('/',async c=>{
 const visible=await visibleNotices(c.env,c.get('auth').user.id);
 return ok(c,{items:visible.slice(0,100).map(n=>({id:n.id,service:n.service,siteId:n.site_id,target:notificationTarget(n),stage:n.stage,endsAt:n.ends_at,title:n.title,body:n.body,readAt:n.read_at,createdAt:n.created_at})),unreadCount:visible.filter(n=>!n.read_at).length});
});
/** Mark every currently visible unread notice as read. Naturally idempotent: a
 * repeat marks nothing, keeps the first read time and writes no audit row.
 * `upTo` (optional) limits it to notices created at or before the list the user
 * saw, so a notice created between list and click is not silently marked read. */
notificationRoutes.post('/read-all',async c=>{
 const input=await body(c,readAllInput),cutoff=readAllCutoff(input.upTo),userId=c.get('auth').user.id,now=Date.now(),time=new Date(now).toISOString();
 const visible=await visibleNotices(c.env,userId,now),targets=visible.filter(n=>!n.read_at&&(!cutoff||Date.parse(n.created_at)<=cutoff.ms)).map(n=>n.id);
 let marked=0;
 if(targets.length){
  // One statement whatever the count: ids travel as a single JSON parameter, so
  // the D1 bound-parameter limit never applies. `read_at IS NULL` keeps the first
  // read time and makes concurrent repeats mark each notice exactly once.
  const [update]=await c.env.DB.batch([
   c.env.DB.prepare("UPDATE service_notifications SET read_at=? WHERE user_id=? AND state='active' AND read_at IS NULL AND id IN (SELECT value FROM json_each(?)) RETURNING id").bind(time,userId,JSON.stringify(targets)),
   // Audited in the same transaction, and only when this request changed something.
   c.env.DB.prepare(`INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at)
    SELECT ?,?,'notification.read_all','user',?,json_object('count',changes(),'upTo',?),?,? WHERE changes()>0`).bind(id('audit'),userId,userId,cutoff?.iso??null,c.get('requestId')??null,time),
  ]);
  marked=update.results?.length??0;
 }
 const remaining=(await visibleNotices(c.env,userId,now)).filter(n=>!n.read_at).length;
 return ok(c,{read:true,marked,unreadCount:remaining});
});
notificationRoutes.post('/:id/read',async c=>{await body(c,z.object({}).strict());const result=await c.env.DB.prepare('UPDATE service_notifications SET read_at=COALESCE(read_at,?) WHERE id=? AND user_id=? RETURNING id').bind(new Date().toISOString(),c.req.param('id'),c.get('auth').user.id).first();assert(result,'NOT_FOUND','通知不存在',404);return ok(c,{read:true});});
