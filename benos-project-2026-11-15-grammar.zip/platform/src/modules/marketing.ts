// Public marketing site (decision D2: these server-rendered pages are canonical).
// Script-free HTML under a strict CSP: no inline style attributes, no <style>, no external hosts.
// Styles: /styles/marketing.css. Prices and plan facts come only from the active billing catalogue.
import { Hono, type Context } from 'hono';
import { type App } from '../lib/http';
import type { Env } from '../env';
import { findPublishedContent,listPublishedContent,type PublishedContent } from './content';
import { activePlatformBrand } from './admin-settings';
import { currentCatalog } from './billing-catalog';
import { AppError } from '../lib/errors';
import { sanitizeRichText,richTextToPlain } from '../lib/rich-text';
import { REGISTRATION_POLICIES,isRegistrationPolicy,hasPolicyBody,type RegistrationPolicy } from '../lib/registration-policies';

type Brand=Awaited<ReturnType<typeof activePlatformBrand>>;
type Section='blog'|'faq'|null;

const SIGN_IN='/#/login',SIGN_UP='/#/signup';

function e(value:unknown){return String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]!));}
export function publicContentPath(item:Pick<PublishedContent,'kind'|'slug'|'id'>){return item.kind==='post'?'/blog/'+item.slug:item.kind==='page'?'/pages/'+item.slug:item.kind==='category'?'/category/'+item.slug:item.kind==='tag'?'/tag/'+item.slug:item.kind==='faq'?'/faq#'+item.id:null;}
export function indexingEnabled(env:Env){return env.INDEXING_ENABLED==='true'&&env.APP_ENV==='production'&&env.APP_ORIGIN.startsWith('https://');}

// Monochrome line icons (Lucide shapes, ISC — see public/assets/icons/LICENSE-Lucide.txt). They inherit currentColor.
const ICONS:Record<string,string>={
 arrow:'<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
 check:'<path d="M20 6 9 17l-5-5"/>',
 chevron:'<path d="m6 9 6 6 6-6"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
 sparkle:'<path d="M9.94 15.5A2 2 0 0 0 8.5 14.06l-6.14-1.58a.5.5 0 0 1 0-.96L8.5 9.94A2 2 0 0 0 9.94 8.5l1.58-6.14a.5.5 0 0 1 .96 0l1.58 6.14a2 2 0 0 0 1.44 1.44l6.14 1.58a.5.5 0 0 1 0 .96l-6.14 1.58a2 2 0 0 0-1.44 1.44l-1.58 6.14a.5.5 0 0 1-.96 0z"/>',
 image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/>',
 history:'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
 server:'<rect x="2" y="3" width="20" height="8" rx="2"/><rect x="2" y="13" width="20" height="8" rx="2"/><path d="M6 7h.01"/><path d="M6 17h.01"/>',
 globe:'<circle cx="12" cy="12" r="9"/><path d="M12 3a13.5 13.5 0 0 0 0 18 13.5 13.5 0 0 0 0-18"/><path d="M3 12h18"/>',
 receipt:'<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/><path d="M6 15h4"/>',
 layers:'<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"/><path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"/><path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"/>',
 building:'<path d="M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16"/><path d="M3 21h18"/><path d="M10 8h4"/><path d="M10 12h4"/><path d="M10 16h4"/>',
 file:'<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M8 13h8"/><path d="M8 17h8"/>',
 help:'<circle cx="12" cy="12" r="9"/><path d="M9.2 9a3 3 0 0 1 5.8 1c0 2-3 2.6-3 4"/><path d="M12 17.5h.01"/>',
 pause:'<circle cx="12" cy="12" r="9"/><path d="M10 9v6"/><path d="M14 9v6"/>',
 mail:'<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a2 2 0 0 1-2.06 0L2 7"/>',
 send:'<path d="M12 19V5"/><path d="m6 11 6-6 6 6"/>',
 sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.9 4.9 1.4 1.4"/><path d="m17.7 17.7 1.4 1.4"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.3 17.7-1.4 1.4"/><path d="m19.1 4.9-1.4 1.4"/>',
 moon:'<path d="M20.5 14.5A8.5 8.5 0 0 1 9.5 3.5a8.5 8.5 0 1 0 11 11"/>',
};
// Home-page imagery: photographs in /assets/marketing (free Unsplash photos, see PROVENANCE.txt there) and the
// screenshots of the starter templates. Decorative images carry an empty alt text.
// Image paths are written out in full at each call: scripts/build-web.mjs only ships files whose literal path appears in src/.
function photo(src:string,cls:string,width=1200,height=900){return `<img class="${cls}" src="${src}" alt="" width="${width}" height="${height}" loading="lazy" decoding="async">`;}
function browser(src:string,cls:string){return `<figure class="mk-browser ${cls}"><div class="mk-browser-bar"><i></i><i></i><i></i></div><img src="${src}" alt="" width="1200" height="800" decoding="async"></figure>`;}
function icon(name:keyof typeof ICONS|string,size=16){return `<svg class="mk-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICONS[name]||''}</svg>`;}

// The Benos mark keeps its pearl material (static SVG files; the owner may replace them later, decision D22).
// A logo uploaded through the brand settings replaces it everywhere.
function brandMark(brand:Brand,size:number){
 if(brand.logoMediaId)return `<img class="mk-mark mk-mark--custom" src="${e(brand.logoUrl)}" width="${size}" height="${size}" alt="">`;
 const height=Math.round(size*656/700);
 return `<picture class="mk-mark"><source srcset="/assets/brand/benos-mark-dark.svg" media="(prefers-color-scheme: dark)"><img src="/assets/brand/benos-mark.svg" width="${size}" height="${height}" alt=""></picture>`;
}
function moneyNumber(amount:number,scale=100){return new Intl.NumberFormat('en-US',{maximumFractionDigits:6}).format(amount/scale);}
function dateLabel(iso:string){const match=/^(\d{4})-(\d{2})-(\d{2})/.exec(iso||'');return match?`<time datetime="${match[0]}">${match[1]} 年 ${Number(match[2])} 月 ${Number(match[3])} 日</time>`:'';}
function paragraphs(value:string){return String(value||'').split(/\n\s*\n/).filter(part=>part.trim()).map(part=>`<p>${e(part).replace(/\n/g,'<br>')}</p>`).join('');}
/** A body as words (for summaries) and as markup (for the article itself). */
const bodyText=(item:PublishedContent)=>item.bodyFormat==='html'?richTextToPlain(item.body).replace(/\s*\n+\s*/g,' '):item.body||'';
const bodyMarkup=(item:PublishedContent)=>item.bodyFormat==='html'?sanitizeRichText(item.body):paragraphs(item.body);
function excerpt(item:PublishedContent){const text=item.description||bodyText(item);return text.length>140?text.slice(0,140).trimEnd()+'…':text;}
function emptyState(glyph:string,title:string,text:string,action=''){return `<div class="mk-empty"><span class="mk-empty-icon">${icon(glyph,18)}</span><h2>${title}</h2><p>${text}</p>${action}</div>`;}
function sectionHead(eyebrow:string,title:string,lead='',aside=''){return `<div class="mk-section-head"><div><p class="mk-eyebrow">${eyebrow}</p><h2>${title}</h2>${lead?`<p class="mk-section-lead">${lead}</p>`:''}</div>${aside}</div>`;}

function articleCards(items:PublishedContent[],heading:'h2'|'h3'='h2'){
 const withCovers=items.some(item=>item.coverUrl);
 return `<div class="mk-article-grid">${items.map(item=>{
  const path=e(publicContentPath(item));
  const media=item.coverUrl?`<a class="mk-article-media" href="${path}" tabindex="-1" aria-hidden="true"><img src="${e(item.coverUrl)}" alt="${e(item.coverAlt||'')}" loading="lazy"></a>`:withCovers?`<a class="mk-article-media mk-article-media--empty" href="${path}" tabindex="-1" aria-hidden="true">${icon('file',20)}</a>`:'';
  return `<article class="mk-card mk-article-card">${media}<div class="mk-article-body"><p class="mk-meta">${dateLabel(item.publishedAt)}</p><${heading} class="mk-article-title"><a href="${path}">${e(item.title)}</a></${heading}><p class="mk-article-excerpt">${e(excerpt(item))}</p><span class="mk-link mk-article-more" aria-hidden="true">阅读文章 ${icon('arrow',14)}</span></div></article>`;
 }).join('')}</div>`;
}

type NavLink={href:string;title:string};
async function navigation(env:Env,placement:string):Promise<NavLink[]>{
 const records=await env.DB.prepare("SELECT n.id,n.published_json,t.id AS target_id,COALESCE(t.kind_override,t.kind) AS target_kind,t.published_json AS target_json FROM content_entries n LEFT JOIN content_entries t ON t.id=json_extract(n.published_json,'$.targetId') AND t.state='published' WHERE n.kind='navigation' AND n.state='published' ORDER BY CAST(COALESCE(json_extract(n.published_json,'$.position'),0) AS INTEGER),n.id LIMIT 100").all<{id:string;published_json:string;target_id:string|null;target_kind:string|null;target_json:string|null}>();
 return records.results.flatMap(row=>{const value=JSON.parse(row.published_json);if((value.placement||'home')!==placement)return [];const target=row.target_json?publicContentPath({id:row.target_id!,kind:row.target_kind!,slug:JSON.parse(row.target_json).slug}):value.url;return target?[{href:String(target),title:String(value.title??'')}]:[];});
}

// Header fit. Staff can add header entries and rename the brand, so the server estimates the row width and picks a layout
// that cannot collide: links inside the header row from 768 px (the default), from 1024 px only, or always in the bar
// under the header. CSS also clips each link and the brand name with an ellipsis and lets the row scroll as a last resort.
const NAV_LINK_TEXT_MAX=196,BRAND_MAX=260,ACCOUNT_WIDTH=200,HEADER_GAPS=64+24;
function textWidth(value:string,size:number,latin=.6){let width=0;for(const ch of value)width+=ch.codePointAt(0)!>=0x2e80?size:latin*size;return width;}
function headerLayout(brandName:string,titles:string[]){
 const links=titles.reduce((sum,title)=>sum+Math.min(textWidth(title,14),NAV_LINK_TEXT_MAX)+24+4,0);
 const need=Math.min(28+9+textWidth(brandName,18,.64),BRAND_MAX)+links+ACCOUNT_WIDTH+HEADER_GAPS;
 // Narrowest header row in each layout: 768 − 2×24 px gutter, 1024 − 2×40 px gutter.
 return need<=720?'':need<=944?' mk-header--nav-wide':' mk-header--nav-bar';
}
function headerLink(link:NavLink,current=''){return `<a href="${e(link.href)}"${current}${textWidth(link.title,14)>NAV_LINK_TEXT_MAX?` title="${e(link.title)}"`:''}><span>${e(link.title)}</span></a>`;}
async function contentLink(env:Env,item:PublishedContent){
 if(!item.targetId)return item.url||null;
 const row=await env.DB.prepare("SELECT id,COALESCE(kind_override,kind) AS kind,published_json FROM content_entries WHERE id=? AND state='published'").bind(item.targetId).first<{id:string;kind:string;published_json:string}>();
 return row?publicContentPath({id:row.id,kind:row.kind,slug:JSON.parse(row.published_json).slug}):null;
}
async function publishedTaxonomy(env:Env,kind:'category'|'tag',ids:string[]){
 if(!ids.length)return [] as {id:string;kind:string;title:string;slug:string}[];
 const rows=await env.DB.prepare("SELECT id,COALESCE(kind_override,kind) AS kind,published_json FROM content_entries WHERE COALESCE(kind_override,kind)=? AND state='published' AND id IN(SELECT value FROM json_each(?))").bind(kind,JSON.stringify(ids)).all<{id:string;kind:string;published_json:string}>();
 return rows.results.map(row=>({...JSON.parse(row.published_json),id:row.id,kind:row.kind})) as {id:string;kind:string;title:string;slug:string}[];
}

async function shell(env:Env,path:string|null,title:string,description:string,main:string,options:{cover?:string;schema?:Record<string,unknown>;noindex?:boolean;section?:Section;brand?:Brand}={}){
 const [header,footer,brand,...policies]=await Promise.all([navigation(env,'header'),navigation(env,'footer'),options.brand||activePlatformBrand(env),...(['terms','privacy'] as const).map(slug=>findPublishedContent(env,'page',slug))]);
 const policyLinks=(['terms','privacy'] as const).map((slug,index)=>hasPolicyBody(policies[index])?`<a href="${REGISTRATION_POLICIES[slug].href}">${REGISTRATION_POLICIES[slug].title}</a>`:'').join('');
 const current=(section:Section)=>options.section===section?' aria-current="page"':'';
 const contact=[brand.contactEmail?`<a href="mailto:${e(brand.contactEmail)}">${e(brand.contactEmail)}</a>`:'',brand.contactPhone?`<span>${e(brand.contactPhone)}</span>`:'',brand.contactAddress?`<span>${e(brand.contactAddress)}</span>`:'',brand.contactUrl?`<a href="${e(brand.contactUrl)}" rel="noopener">联系我们</a>`:''].filter(Boolean).join('');
 // A page without its own address (the 404 page) declares no canonical URL.
 const canonical=path===null?null:env.APP_ORIGIN+path,robots=indexingEnabled(env)&&!options.noindex?'index,follow':'noindex,nofollow',structured=options.schema?`<script type="application/ld+json">${JSON.stringify(options.schema).replace(/</g,'\\u003c')}</script>`:'';
 const head=`<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${e(title)}</title><meta name="description" content="${e(description)}"><meta name="robots" content="${robots}">${canonical?`<link rel="canonical" href="${e(canonical)}">`:''}<meta name="color-scheme" content="light dark"><meta name="theme-color" content="#fafafa" media="(prefers-color-scheme: light)"><meta name="theme-color" content="#0a0a0b" media="(prefers-color-scheme: dark)"><meta property="og:type" content="website"><meta property="og:site_name" content="${e(brand.brandName)}"><meta property="og:title" content="${e(title)}"><meta property="og:description" content="${e(description)}">${canonical?`<meta property="og:url" content="${e(canonical)}">`:''}${options.cover?`<meta property="og:image" content="${e(new URL(options.cover,env.APP_ORIGIN).toString())}">`:''}<link rel="icon" href="${e(brand.logoMediaId?brand.logoUrl:'/assets/brand/favicon.svg')}"><link rel="apple-touch-icon" href="${e(brand.logoMediaId?brand.logoUrl:'/assets/brand/apple-touch-icon.png')}"><link rel="stylesheet" href="/styles/marketing.css">${structured}`;
 // The links render twice: inside the header row (wide screens) and as a scrolling bar under it (phones). CSS shows one of them.
 const builtIn:Array<[NavLink,string]>=[[{href:'/home#plans',title:'套餐'},''],[{href:'/blog',title:'博客'},current('blog')],[{href:'/faq',title:'常见问题'},current('faq')]];
 const links=[...builtIn,...header.map(link=>[link,''] as [NavLink,string])].map(([link,attr])=>headerLink(link,attr)).join('');
 const layout=headerLayout(brand.brandName,[...builtIn.map(([link])=>link.title),...header.map(link=>link.title)]);
 const longBrand=textWidth(brand.brandName,18,.64)>BRAND_MAX-37?` title="${e(brand.brandName)}"`:'';
 const themePath=e(path||'/home'),themeSwitch=`<span class="mk-theme" role="group" aria-label="外观"><a href="${themePath}?theme=light" rel="nofollow" data-theme="light" aria-label="浅色" title="浅色">${icon('sun',16)}<span>浅色</span></a><a href="${themePath}?theme=dark" rel="nofollow" data-theme="dark" aria-label="深色" title="深色">${icon('moon',16)}<span>深色</span></a></span>`;
 const top=`<header class="mk-header${layout}"><div class="mk-wrap mk-header-inner"><a class="mk-brand" href="/home" aria-label="${e(brand.brandName)} 首页"${longBrand}>${brandMark(brand,28)}<span>${e(brand.brandName)}</span></a><nav class="mk-nav" aria-label="主导航">${links}</nav><div class="mk-account">${themeSwitch}<a class="mk-button mk-button--ghost mk-button--small" href="${SIGN_IN}">登录</a><a class="mk-button mk-button--primary mk-button--small" href="${SIGN_UP}">开始设计 ${icon('arrow',14)}</a></div></div></header><nav class="mk-nav mk-nav--bar" aria-label="主导航">${links}${themeSwitch}</nav>`;
 const bottom=`<footer class="mk-footer"><div class="mk-wrap"><div class="mk-footer-top"><div class="mk-footer-brand"><a class="mk-brand" href="/home">${brandMark(brand,24)}<span>${e(brand.brandName)}</span></a><p>${e(brand.tagline)}</p>${contact?`<p class="mk-footer-contact">${contact}</p>`:''}</div><nav class="mk-footer-nav" aria-label="页脚导航"><div class="mk-footer-group"><h2>产品</h2><a href="/home#plans">套餐</a><a href="/blog">博客</a><a href="/faq">常见问题</a></div><div class="mk-footer-group"><h2>账户</h2><a href="${SIGN_IN}">登录工作台</a><a href="${SIGN_UP}">创建账号</a></div>${policyLinks?`<div class="mk-footer-group"><h2>条款</h2>${policyLinks}</div>`:''}${footer.length?`<div class="mk-footer-group"><h2>更多</h2>${footer.map(link=>`<a href="${e(link.href)}">${e(link.title)}</a>`).join('')}</div>`:''}</nav></div><div class="mk-footer-bottom"><span>© ${new Date().getUTCFullYear()} ${e(brand.brandName)}</span><span>AI 网站设计与 CMS 托管</span>${themeSwitch}</div></div></footer>`;
 return new Response(`<!doctype html><html lang="zh-CN"><head>${head}</head><body class="mk-page"><a class="mk-skip" href="#main-content">跳到内容</a>${top}<main id="main-content">${main}</main>${bottom}</body></html>`,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; script-src 'none'; style-src 'self'; img-src 'self' https: data:; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY','X-Robots-Tag':robots}});
}

export const marketingRoutes=new Hono<App>();

const THEME_COOKIE='benos_theme',PUBLIC_PAGE=/^\/(?:home|blog|faq|pages|category|tag)(?:\/|$)/,DARK_MARK='<source srcset="/assets/brand/benos-mark-dark.svg" media="(prefers-color-scheme: dark)">';
marketingRoutes.use('*',async(c,next)=>{
 if(c.req.method!=='GET'||!PUBLIC_PAGE.test(c.req.path))return next();
 const requested=c.req.query('theme');
 if(requested==='light'||requested==='dark'||requested==='auto'){
  const url=new URL(c.req.url);url.searchParams.delete('theme');
  return new Response(null,{status:302,headers:{Location:url.pathname+url.search,'Set-Cookie':`${THEME_COOKIE}=${requested}; Path=/; Max-Age=${requested==='auto'?0:31536000}; SameSite=Lax`,'Cache-Control':'no-store'}});
 }
 await next();
 const theme=new RegExp('(?:^|;\\s*)'+THEME_COOKIE+'=(light|dark)(?:;|$)').exec(c.req.header('cookie')||'')?.[1];
 if(!theme||!(c.res.headers.get('Content-Type')||'').startsWith('text/html'))return;
 const response=c.res,html=(await response.text()).replace('<body class="mk-page">',`<body class="mk-page mk-theme-${theme}">`).split(DARK_MARK).join(theme==='dark'?'<source srcset="/assets/brand/benos-mark-dark.svg">':'');
 c.res=new Response(html,{status:response.status,headers:response.headers});
});

marketingRoutes.get('/home',async c=>{
 const [posts,banners,faqs,brand,active]=await Promise.all([listPublishedContent(c.env,{kind:'post',limit:3}),listPublishedContent(c.env,{kind:'banner',limit:12}),listPublishedContent(c.env,{kind:'faq',limit:100}),activePlatformBrand(c.env),currentCatalog(c.env.DB)]);
 const catalog=active.catalog,cny=catalog.cnyPricing,name=e(brand.brandName);
 // Every purchase entry follows the catalogue switch: a disabled catalogue shows 暂停新订购 instead of a link.
 const paused='<span class="mk-button mk-button--disabled" aria-disabled="true">暂停新订购</span>';
 const purchase=(label:string,primary=false,href=SIGN_UP)=>!active.enabled?paused:cny?`<a class="mk-button${primary?' mk-button--primary':''}" href="${href}">${label}</a>`:'<span class="mk-button mk-button--disabled" aria-disabled="true">价格待发布</span>';
 const creditAmount=(micros:number)=>{if(!cny){const cents=Math.floor(micros/10_000);return '$'+Math.floor(cents/100).toLocaleString('en-US')+(cents%100?'.'+String(cents%100).padStart(2,'0'):'');}const cents=micros/cny.topupCreditMicrosPerCnyCent;return cents>0&&cents<1?'不足 ¥0.01':'¥'+moneyNumber(Math.floor(cents));};
 const feature=(text:string)=>`<li>${icon('check',16)}<span>${text}</span></li>`;
 const bannerMarkup=(await Promise.all(banners.items.filter(item=>!item.placement||item.placement==='home').sort((a,b)=>(a.position||0)-(b.position||0)).map(async item=>{const target=await contentLink(c.env,item);return `<aside class="mk-card mk-banner">${item.coverUrl?`<img class="mk-banner-image" src="${e(item.coverUrl)}" alt="${e(item.coverAlt||'')}" loading="lazy">`:''}<div class="mk-banner-body"><div><h2>${e(item.title)}</h2><p>${e(item.description||item.body)}</p></div>${target?`<a class="mk-link" href="${e(target)}">了解更多 ${icon('arrow',14)}</a>`:''}</div></aside>`;}))).join('');

 const hero=`<section class="mk-hero"><img class="mk-hero-bg" src="/assets/marketing/iris-hero.webp" alt="" width="2000" height="1200" decoding="async"><div class="mk-wrap mk-hero-inner"><div class="mk-hero-copy"><h1>用一句话<br>设计你的网站</h1><p class="mk-lead">描述品牌和想要的风格，<strong>AI 生成页面并随你修改</strong>。<br>满意后一键发布，独立 CMS 与托管交给 ${name}。</p><a class="mk-hero-prompt" href="${SIGN_UP}" aria-label="用这句话开始设计"><span class="mk-hero-prompt-icon">${icon('sparkle',18)}</span><span class="mk-hero-prompt-text">为一家独立咖啡品牌设计官网，温暖克制，突出门店与菜单</span><b class="mk-send">${icon('send',18)}</b></a><div class="mk-hero-chips"><span>也可以试试</span><a href="${SIGN_UP}">陶瓷工作室官网</a><a href="${SIGN_UP}">建筑事务所作品集</a><a href="${SIGN_UP}">家居品牌目录</a><a href="${SIGN_UP}">民宿介绍页</a></div><div class="mk-hero-actions"><a class="mk-button mk-button--primary mk-button--large" href="${SIGN_UP}">开始设计 ${icon('arrow',16)}</a><a class="mk-button mk-button--large" href="#plans">查看套餐</a></div></div><div class="mk-showcase" aria-hidden="true">${browser('/assets/template-studio.webp','mk-browser--left')}${browser('/assets/template-manufacturing.webp','mk-browser--right')}${browser('/assets/template-home.webp','mk-browser--main')}</div></div></section>`;

 const steps=[['描述想法','用文字或参考图说明品牌、行业和想要的风格，为每个网站建立独立项目。'],['与 AI 一起设计','在画布上查看页面，选中区块继续修改；素材与版本都保存在项目里。'],['一键发布','确认设计后发布，平台自动完成模板转换与导入，无需手动上传。'],['在独立 CMS 中运营','每个网站都有自己的后台，日常编辑产品、文章和图片不占用 AI 额度。']];
 const flow=`<section class="mk-section mk-section--flush"><div class="mk-wrap mk-split"><figure class="mk-split-media" aria-hidden="true">${photo('/assets/marketing/glass-prism.webp','mk-split-img')}<figcaption class="mk-prompt"><span>为一家手作陶瓷工作室设计官网，安静一些，多留白。</span><b class="mk-send">${icon('send',16)}</b></figcaption></figure><div class="mk-split-copy">${sectionHead('工作方式','从一句话，<br><em>到上线的网站</em>')}<ol class="mk-steps">${steps.map(([title,text],index)=>`<li class="mk-step"><span class="mk-step-number">0${index+1}</span><div><h3>${title}</h3><p>${text}</p></div></li>`).join('')}</ol></div></div></section>`;

 const capabilities=[['sparkle','AI 设计对话','选择可用的 DeepSeek、GPT 或 Kimi，围绕网站画布、设计对话和选中的区块完成修改。'],['image','素材管理','上传的图片随项目保存，素材只在所属项目内使用。'],['history','版本保留','已保存的设计版本持续保留，方便回看、比较与继续创作。'],['server','独立 CMS 托管','每个网站配备独立的 CMS 与后台账号，内容和业务数据各自保存。'],['globe','域名与发布','在网站管理中配置域名，查看发布记录、模板版本与备份。'],['receipt','清楚的用量与账单','会员额度、充值余额与网站托管分别记账，AI 调用先预留、再按实际用量结算。']];
 const featureMedia:Record<string,string>={sparkle:'/assets/marketing/iris-discs.webp',server:'/assets/marketing/iris-wings.webp'};
 const features=`<section class="mk-section"><div class="mk-wrap">${sectionHead('产品能力','设计、发布与运营，<br><em>在同一个工作台</em>',`把时间用在想表达的内容上，其余交给 ${name}。`)}<div class="mk-bento">${capabilities.map(([glyph,title,text])=>`<article class="mk-card mk-feature${featureMedia[glyph]?' mk-feature--media':''}">${featureMedia[glyph]?photo(featureMedia[glyph],'mk-feature-img'):''}<div class="mk-feature-body"><span class="mk-tile">${icon(glyph,18)}</span><h3>${title}</h3><p>${text}</p></div></article>`).join('')}</div></div></section>`;

 const price=(amount:string,period:string)=>`<p class="mk-price"><span class="mk-price-amount">${amount}</span><span class="mk-price-period">${period}</span></p>`;
 const membership=(tier:'go'|'pro',title:string,glyph:string,summary:string,label:string,recommended:boolean)=>{const plan=catalog[tier],amount=cny?(tier==='go'?cny.goPriceCents:cny.proPriceCents):null;return `<article class="mk-card mk-plan${recommended?' mk-plan--featured':''}"><header class="mk-plan-head"><span class="mk-tile">${icon(glyph,18)}</span><h3>${title}</h3>${recommended?'<span class="mk-plaque">推荐方案</span>':''}</header><p class="mk-plan-summary">${summary}</p>${price(amount===null?'待公布':'¥'+moneyNumber(amount),'/ 月')}${purchase(label,recommended)}<ul class="mk-plan-features">${feature(`每月 ${creditAmount(plan.creditMicros)} AI 额度`)}${feature(`包含 ${plan.includedSites} 个网站托管`)}${feature('每个网站配备独立 CMS')}${feature('到期前可主动续费，不自动扣款')}</ul></article>`;};
 const enterpriseContact=brand.contactUrl?`<a class="mk-button" href="${e(brand.contactUrl)}" rel="noopener">联系报价</a>`:brand.contactEmail?`<a class="mk-button" href="mailto:${e(brand.contactEmail)}">联系报价</a>`:'<a class="mk-button" href="/faq">查看常见问题</a>';
 // Without brand contact details the card still offers a way forward; the launch checklist asks for the contact settings.
 const enterprise=catalog.enterprise.contactEnabled?`<article class="mk-card mk-plan"><header class="mk-plan-head"><span class="mk-tile">${icon('building',18)}</span><h3>Enterprise</h3></header><p class="mk-plan-summary">${e(catalog.enterprise.description)}</p><p class="mk-price"><span class="mk-price-amount mk-price-amount--text">定制报价</span></p>${enterpriseContact}<ul class="mk-plan-features">${feature('网站数量与服务范围按合同约定')}${feature('AI 额度按合同配置')}${feature('每个网站配备独立 CMS')}</ul></article>`:'';
 const plans=`<section class="mk-section" id="plans"><div class="mk-wrap">${sectionHead('套餐','按你的节奏选择','以人民币付款，到期前主动续费，不自动扣款。AI 额度充值与额外的网站托管在工作台内购买。')}${active.enabled?'':`<p class="mk-notice" role="status">${icon('pause',18)}<span><strong>暂停新订购</strong>平台当前不接受新的订购，价格仅供了解。已有订单与服务状态以工作台为准。</span></p>`}<div class="mk-plan-grid${enterprise?'':' mk-plan-grid--two'}">${membership('go','Go','sparkle','为你的第一个网站准备。','从 Go 开始',false)}${membership('pro','Pro','layers','持续设计，管理多个网站。','选择 Pro',true)}${enterprise}</div></div></section>`;

 const faqRows=faqs.items.sort((a,b)=>(a.position||0)-(b.position||0)).slice(0,5);
 const faqSection=faqRows.length?`<section class="mk-section"><div class="mk-wrap mk-wrap--narrow">${sectionHead('帮助','常见问题','',`<a class="mk-link" href="/faq">查看全部 ${icon('arrow',14)}</a>`)}${faqList(faqRows,false)}</div></section>`:'';
 const journal=posts.items.length?`<section class="mk-section"><div class="mk-wrap">${sectionHead('博客','最近更新','产品动态与网站创作记录。',`<a class="mk-link" href="/blog">阅读博客 ${icon('arrow',14)}</a>`)}${articleCards(posts.items,'h3')}</div></section>`:'';
 const cta=`<section class="mk-section mk-section--cta"><div class="mk-wrap"><div class="mk-cta mk-cta--media">${photo('/assets/marketing/iris-torus.webp','mk-cta-bg',2000,1100)}<div><h2>下一个网站，<em>从一句话开始。</em></h2><p>为它取个名字，剩下的一步步完成。</p></div><a class="mk-button mk-button--primary mk-button--large" href="${SIGN_UP}">开始设计 ${icon('arrow',16)}</a></div></div></section>`;
 const statement='<section class="mk-statement"><div class="mk-wrap"><p>不用学设计软件，<em>说出想法</em>就够了。AI 把它变成页面，你来判断<em>好不好看、对不对</em>；确认之后，网站直接<em>上线运营</em>。</p></div></section>';
 const main=hero+statement+(bannerMarkup?`<section class="mk-banners"><div class="mk-wrap">${bannerMarkup}</div></section>`:'')+flow+features+plans+faqSection+journal+cta;
 return shell(c.env,'/home',`${brand.brandName} · AI 网站设计与 CMS 托管`,`用 AI 设计网站，管理项目素材与版本，连接独立 CMS 并持续运营。查看 ${brand.brandName} Go、Pro 与每站年付托管方案。`,main,{brand});
});

function faqList(rows:PublishedContent[],anchors=true){return `<div class="mk-faq-list">${rows.map(item=>`<details class="mk-faq"${anchors?` id="${e(item.id)}"`:''}><summary><span>${e(item.title)}</span>${icon('chevron',18)}</summary><div class="mk-faq-answer">${paragraphs(item.body)}</div></details>`).join('')}</div>`;}

const LISTING_SORTS=['published_desc','title_asc','position_asc'];
async function listing(c:Context<App>,taxonomy?:PublishedContent){
 const brand=await activePlatformBrand(c.env);
 // Stale or mangled links still get a page: an unknown sort falls back to the default, an over-long query is cut to the
 // form's limit, and a cursor that no longer matches (or never decoded) shows the first page.
 const requestedSort=c.req.query('sort')||'',sort=LISTING_SORTS.includes(requestedSort)?requestedSort:'published_desc';
 const category=taxonomy?.kind==='category'?taxonomy:undefined,tag=taxonomy?.kind==='tag'?taxonomy:undefined,q=(c.req.query('q')||'').trim().slice(0,160);
 let cursor=c.req.query('cursor')||undefined;
 const loadPosts=(after?:string)=>listPublishedContent(c.env,{kind:'post',categoryId:category?.id,tagId:tag?.id,q,sort,cursor:after,limit:12});
 const [firstTry,categories,tags]=await Promise.all([loadPosts(cursor).catch((error:unknown)=>{if(error instanceof AppError&&error.code==='VALIDATION'&&cursor)return null;throw error;}),listPublishedContent(c.env,{kind:'category',limit:100}),listPublishedContent(c.env,{kind:'tag',limit:100})]);
 if(!firstTry)cursor=undefined;
 const posts=firstTry||await loadPosts();
 const path=taxonomy?publicContentPath(taxonomy)!:'/blog',title=taxonomy?.title||'博客',description=taxonomy?.description||`网站设计、内容管理与 ${brand.brandName} 产品更新。`;
 const eyebrow=category?'分类':tag?'标签':`${e(brand.brandName)} 博客`;
 // A lone "全部" chip says nothing, so the filters appear only once a category or tag is published.
 const chips=!categories.items.length&&!tags.items.length?'':`<nav class="mk-chips" aria-label="文章分类"><a href="/blog"${taxonomy?'':' aria-current="page"'}>全部</a>${categories.items.map(item=>`<a href="${e(publicContentPath(item))}"${category?.id===item.id?' aria-current="page"':''}>${e(item.title)}</a>`).join('')}</nav>${tags.items.length?`<nav class="mk-chips mk-chips--tags" aria-label="文章标签">${tags.items.map(item=>`<a href="${e(publicContentPath(item))}"${tag?.id===item.id?' aria-current="page"':''}># ${e(item.title)}</a>`).join('')}</nav>`:''}`;
 const option=(value:string,label:string)=>`<option value="${value}"${sort===value?' selected':''}>${label}</option>`;
 const search=`<form class="mk-search" method="get" action="${e(path)}" role="search"><label class="mk-field mk-field--grow"><span class="mk-field-label">搜索文章</span><span class="mk-input">${icon('search',16)}<input type="search" name="q" value="${e(q)}" maxlength="160" placeholder="输入标题或关键词" autocomplete="off"></span></label><label class="mk-field"><span class="mk-field-label">排序</span><span class="mk-select"><select name="sort">${option('published_desc','最近发布')}${option('title_asc','标题升序')}${option('position_asc','展示顺序')}</select>${icon('chevron',16)}</span></label><button class="mk-button mk-search-submit" type="submit">搜索</button></form>`;
 const filtered=!!q||!!taxonomy;
 const empty=q?emptyState('search','没有找到匹配的文章',`没有与“${e(q)}”相关的已发布文章，换个关键词再试试。`,`<a class="mk-button" href="${e(path)}">清除搜索</a>`):taxonomy?emptyState('file','这里还没有文章',`“${e(taxonomy.title)}”下暂时没有已发布的文章。`,'<a class="mk-button" href="/blog">查看全部文章</a>'):emptyState('file','文章正在准备中','这里会发布产品动态与网站创作记录，稍后再来看看。','<a class="mk-button" href="/home">返回首页</a>');
 const summary=q?`<p class="mk-result-note">“${e(q)}”的搜索结果 · <a class="mk-link" href="${e(path)}">清除搜索</a></p>`:'';
 const pager=posts.nextCursor||cursor?`<nav class="mk-pagination" aria-label="文章分页">${cursor?`<a class="mk-button" href="${e(path)}${q||sort!=='published_desc'?'?'+e(new URLSearchParams({q,sort}).toString()):''}">回到第一页</a>`:''}${posts.nextCursor?`<a class="mk-button" href="${e(path)}?${e(new URLSearchParams({q,sort,cursor:posts.nextCursor}).toString())}">下一页 ${icon('arrow',14)}</a>`:''}</nav>`:'';
 const main=`<section class="mk-page-head mk-page-head--media">${photo('/assets/marketing/iris-wings.webp','mk-page-head-bg')}<div class="mk-wrap"><p class="mk-eyebrow">${eyebrow}</p><h1>${e(title)}</h1><p class="mk-page-lead">${e(description)}</p></div></section><section class="mk-listing"><div class="mk-wrap"><div class="mk-toolbar">${chips}${posts.items.length||filtered||cursor?search:''}</div>${summary}${posts.items.length?articleCards(posts.items):empty}${pager}</div></section>`;
 return shell(c.env,path,`${taxonomy?.seoTitle||title} · ${brand.brandName}`,taxonomy?.seoDescription||description,main,{cover:taxonomy?.coverUrl,noindex:!!cursor||!!q,section:'blog',brand});
}
marketingRoutes.get('/blog',c=>listing(c));
marketingRoutes.get('/category/:slug{.+}',async c=>{const category=await findPublishedContent(c.env,'category',c.req.param('slug')||'');if(!category)return missing(c.env);return listing(c,category);});
marketingRoutes.get('/tag/:slug{.+}',async c=>{const tag=await findPublishedContent(c.env,'tag',c.req.param('slug')||'');if(!tag)return missing(c.env);return listing(c,tag);});

async function unavailablePolicy(env:Env,slug:RegistrationPolicy,brand:Brand){
 const policy=REGISTRATION_POLICIES[slug],title=policy.title+'尚未发布';
 const contact=brand.contactUrl?`<a class="mk-button" href="${e(brand.contactUrl)}" rel="noopener">联系运营方</a>`:brand.contactEmail?`<a class="mk-button" href="mailto:${e(brand.contactEmail)}">联系运营方</a>`:'';
 const main=`<section class="mk-page-head"><div class="mk-wrap mk-wrap--narrow"><p class="mk-eyebrow">${policy.title}</p><h1>${title}</h1><p class="mk-page-lead">运营方尚未发布可阅读的${policy.title}正文。正式内容发布前，暂时无法创建新账号；已有账号可正常登录。</p></div></section><section class="mk-listing"><div class="mk-wrap mk-wrap--narrow"><div class="mk-help-actions"><a class="mk-button mk-button--primary" href="${SIGN_IN}">已有账号，前往登录</a><a class="mk-button" href="/home">返回首页</a>${contact}</div></div></section>`;
 const response=await shell(env,policy.href,`${title} · ${brand.brandName}`,'正式政策内容尚未发布，暂时无法创建新账号。',main,{brand,noindex:true});
 return new Response(response.body,{status:503,headers:response.headers});
}
async function detail(c:Context<App>,kind:'post'|'page'){
 const brand=await activePlatformBrand(c.env);
  const slug=c.req.param('slug')||'',item=await findPublishedContent(c.env,kind,slug);
  if(kind==='page'&&isRegistrationPolicy(slug)&&!hasPolicyBody(item))return unavailablePolicy(c.env,slug,brand);
  if(!item)return missing(c.env);
 const [tags,categories]=await Promise.all([publishedTaxonomy(c.env,'tag',item.tagIds||[]),publishedTaxonomy(c.env,'category',item.categoryId?[item.categoryId]:[])]);
 const path=publicContentPath(item)!,title=item.seoTitle||item.title,description=item.seoDescription||item.description||bodyText(item).slice(0,160),post=kind==='post';
 const meta=[dateLabel(item.publishedAt),...categories.map(category=>`<a href="${e(publicContentPath(category))}">${e(category.title)}</a>`),`<span>${e(brand.brandName)}</span>`].filter(Boolean).join('<span class="mk-dot" aria-hidden="true">·</span>');
 const closing=post?`<footer class="mk-article-end">${tags.length?`<nav class="mk-chips mk-chips--tags" aria-label="文章标签">${tags.map(tag=>`<a href="${e(publicContentPath(tag))}"># ${e(tag.title)}</a>`).join('')}</nav>`:''}<a class="mk-link mk-link--back" href="/blog">${icon('arrow',14)}返回博客</a></footer>`:'';
 const main=`<div class="mk-wrap mk-wrap--article"><nav class="mk-breadcrumb" aria-label="面包屑"><a href="/home">首页</a><span aria-hidden="true">/</span>${post?'<a href="/blog">博客</a><span aria-hidden="true">/</span>':''}<span aria-current="page">${e(item.title)}</span></nav><article class="mk-article${post?'':' mk-article--page'}"><header class="mk-article-head"><h1>${e(item.title)}</h1><p class="mk-meta">${meta}</p>${item.description?`<p class="mk-article-intro">${e(item.description)}</p>`:''}</header>${item.coverUrl?`<img class="mk-article-cover" src="${e(item.coverUrl)}" alt="${e(item.coverAlt||'')}">`:''}<div class="mk-prose">${bodyMarkup(item)}</div>${closing}</article></div>${post?`<section class="mk-section mk-section--cta"><div class="mk-wrap"><div class="mk-cta"><div><h2>下一个网站，从一句话开始。</h2><p>为它取个名字，剩下的一步步完成。</p></div><a class="mk-button mk-button--primary mk-button--large" href="${SIGN_UP}">开始设计 ${icon('arrow',16)}</a></div></div></section>`:''}`;
 return shell(c.env,path,`${title} · ${brand.brandName}`,description,main,{cover:item.coverUrl,section:post?'blog':null,brand,schema:post?{'@context':'https://schema.org','@type':'BlogPosting',headline:item.title,datePublished:item.publishedAt,mainEntityOfPage:c.env.APP_ORIGIN+path,publisher:{'@type':'Organization',name:brand.brandName}}:undefined});
}
marketingRoutes.get('/blog/:slug{.+}',c=>detail(c,'post'));
marketingRoutes.get('/pages/:slug{.+}',c=>detail(c,'page'));

marketingRoutes.get('/faq',async c=>{
 const [published,brand]=await Promise.all([listPublishedContent(c.env,{kind:'faq',limit:100}),activePlatformBrand(c.env)]);
 const rows=published.items.sort((a,b)=>(a.position||0)-(b.position||0));
 const contact=brand.contactUrl?`<a class="mk-button" href="${e(brand.contactUrl)}" rel="noopener">联系我们</a>`:brand.contactEmail?`<a class="mk-button" href="mailto:${e(brand.contactEmail)}">${icon('mail',16)}${e(brand.contactEmail)}</a>`:'';
 const body=rows.length?faqList(rows):emptyState('help','帮助内容正在准备中','套餐权益请查看套餐说明；订单处理可通过运营方公布的客服渠道联系。','<a class="mk-button" href="/home#plans">查看套餐</a>');
 const aside=`<aside class="mk-card mk-help"><h2>没有找到答案？</h2><p>套餐价格与权益以套餐说明为准，账户内的订单、额度和托管状态请在工作台查看。</p><div class="mk-help-actions"><a class="mk-button" href="/home#plans">查看套餐</a>${contact}</div></aside>`;
 const main=`<section class="mk-page-head mk-page-head--media">${photo('/assets/marketing/glass-prism.webp','mk-page-head-bg')}<div class="mk-wrap mk-wrap--narrow"><p class="mk-eyebrow">帮助与说明</p><h1>常见问题</h1><p class="mk-page-lead">了解套餐、AI 额度和网站托管的使用规则。</p></div></section><section class="mk-listing"><div class="mk-wrap mk-wrap--narrow">${body}${rows.length?aside:''}</div></section>`;
 const schema=rows.length?{'@context':'https://schema.org','@type':'FAQPage',mainEntity:rows.map(item=>({'@type':'Question',name:item.title,acceptedAnswer:{'@type':'Answer',text:item.body}}))}:undefined;
 return shell(c.env,'/faq',`常见问题 · ${brand.brandName}`,`了解 ${brand.brandName} Go、Pro、AI 充值与 CMS 托管规则。`,main,{section:'faq',brand,schema});
});

async function missing(env:Env){
 const brand=await activePlatformBrand(env);
 const response=await shell(env,null,`页面不存在 · ${brand.brandName}`,'该页面未发布或已经下架。',`<section class="mk-listing mk-listing--solo"><div class="mk-wrap mk-wrap--narrow"><div class="mk-empty mk-empty--media">${photo('/assets/marketing/iris-torus.webp','mk-empty-bg',2000,1100)}<span class="mk-empty-icon">${icon('file',18)}</span><h1>页面暂不可用</h1><p>内容可能尚未发布或已经下架。</p><div class="mk-help-actions"><a class="mk-button mk-button--primary" href="/home">返回首页</a><a class="mk-button" href="/blog">浏览博客</a></div></div></div></section>`,{noindex:true,brand});
 return new Response(response.body,{status:404,headers:response.headers});
}

export async function marketingSitemap(env:Env){
 const paths=['/home','/blog','/faq'];
 if(indexingEnabled(env)){const rows=await env.DB.prepare("SELECT id,COALESCE(kind_override,kind) AS kind,published_json FROM content_entries WHERE state='published' AND COALESCE(kind_override,kind) IN ('post','page','category','tag') ORDER BY id LIMIT 10000").all<{id:string;kind:string;published_json:string}>();for(const row of rows.results){const path=publicContentPath({id:row.id,kind:row.kind,slug:JSON.parse(row.published_json).slug});if(path)paths.push(path);}}
 return '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+(indexingEnabled(env)?paths.map(path=>`<url><loc>${e(env.APP_ORIGIN+path)}</loc></url>`).join(''):'')+'</urlset>';
}
