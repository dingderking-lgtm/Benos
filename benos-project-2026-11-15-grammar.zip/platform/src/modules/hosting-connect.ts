import { z } from 'zod';
import { AppError,assert } from '../lib/errors';
import { hpanelRequest,listHpanelWebsites } from './hosting-hostinger';

// Read-only connection discovery. Never save this input, forward upstream error
// bodies, or treat an accessible account as proof of deployment permissions.
export const hostingerDiscoveryInput=z.object({hostingerApiToken:z.string().trim().min(16).max(8192).regex(/^[\x21-\x7e]+$/)}).strict();
type Row=Record<string,unknown>;
type DiscoveredAccount={hostingOrderId:number;accountUsername:string|null;planName:string;status:string;websiteCount:number;selectable:boolean;reason:string|null};
function object(value:unknown):Row{assert(value!==null&&typeof value==='object'&&!Array.isArray(value),'HOSTINGER_RESPONSE_INVALID','主机清单格式无效',502);return value as Row;}
async function orders(token:string):Promise<Row[]>{
 const all:Row[]=[];
 for(let page=1;page<=100;page++){
  const response=object(await hpanelRequest(token,'GET',`/api/hosting/v1/orders?page=${page}&per_page=100`));
  assert(Array.isArray(response.data),'HOSTINGER_RESPONSE_INVALID','主机套餐清单格式无效',502);
  const rows=response.data.map(object),meta=object(response.meta),total=Number(meta.total),current=Number(meta.current_page??meta.currentPage),perPage=Number(meta.per_page??meta.perPage);
  assert(Number.isSafeInteger(total)&&total>=0&&total<=10000&&current===page&&Number.isSafeInteger(perPage)&&perPage>0&&perPage<=1000,'HOSTINGER_RESPONSE_INVALID','主机套餐分页信息无效',502);
  all.push(...rows);
  if(current*perPage>=total){assert(all.length===total,'HOSTINGER_RESPONSE_INVALID','主机套餐清单发生变化，请重新读取',502);return all;}
  assert(rows.length>0,'HOSTINGER_RESPONSE_INVALID','主机套餐清单不完整',502);
 }
 throw new AppError('HOSTINGER_RESPONSE_INVALID','主机套餐清单超过安全读取范围',502);
}
export async function discoverHostinger(token:string){
 const [plans,websites]=await Promise.all([orders(token),listHpanelWebsites(token)]);
 const seen=new Set<number>();
 const items=plans.flatMap<DiscoveredAccount>(plan=>{
  const orderId=Number(plan.id);assert(Number.isSafeInteger(orderId)&&orderId>0&&!seen.has(orderId),'HOSTINGER_RESPONSE_INVALID','主机套餐编号无效，请重新读取',502);seen.add(orderId);
  const name=object(plan.plan).name,status=plan.status;
  assert(typeof name==='string'&&name.length>0&&name.length<=200&&typeof status==='string'&&status.length<=40,'HOSTINGER_RESPONSE_INVALID','主机套餐信息不完整',502);
  const scoped=websites.filter(site=>Number(site.order_id??site.orderId)===orderId);
  const accounts=[...new Set(scoped.map(site=>site.username).filter((username):username is string=>typeof username==='string'&&/^u[0-9]{3,20}$/.test(username)))];
  if(!accounts.length)return [{hostingOrderId:orderId,accountUsername:null,planName:name,status,websiteCount:0,selectable:false,reason:'该套餐尚未返回可用的 PHP 主机账户，请先在 hPanel 完成主机初始化后重新读取。'}];
  return accounts.map(accountUsername=>({hostingOrderId:orderId,accountUsername,planName:name,status,websiteCount:new Set(scoped.filter(site=>site.username===accountUsername).map(site=>site.domain).filter(Boolean)).size,selectable:status==='active',reason:status==='active'?null:'该主机套餐当前未启用，不能用于新网站。'}));
 });
 return {items,scope:'web-cloud' as const,checkedAt:new Date().toISOString()};
}
