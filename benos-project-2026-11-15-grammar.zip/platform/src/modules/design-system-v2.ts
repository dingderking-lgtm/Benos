import { Hono, type Context } from 'hono';
import { z } from 'zod';
import { body, ok, type App } from '../lib/http';
import { AppError, assert } from '../lib/errors';
import { requireAuth, requireRole } from './auth';
import { V2_PRESETS } from '../design-system/v2/contracts';
import { getV2Catalog, renderV2Section, compileV2Page } from '../design-system/v2/render';
import { getV2Fixture, createV2PageFixture, V2_FIXTURE_ASSETS } from '../design-system/v2/fixtures';
import { renderV2ReviewGallery, V2_REVIEW_GALLERY_CSS, V2_REVIEW_GALLERY_JS, type V2ReviewDocument } from '../design-system/v2/review-gallery';
import { getV2Sources, getV2Notices } from '../design-system/v2/provenance';
import { prepareV2Generation, v2GenerationRequestSchema, v2GenerationTool, compileV2GenerationSubmission } from '../design-system/v2/generation';
import { resolveSiteHeader, compileSiteHeader, type SiteHeaderContext } from '../contracts/site-header';
import { canonicalV2Json, v2ApprovalKey } from '../design-system/v2/registry';
import { v2PatternReviewInputSchema, readV2PatternReviews, recordV2PatternReview } from '../lib/pattern-approvals-v2';

const base = '/api/admin/design-system-v2';
const presetSchema = z.enum(V2_PRESETS);
const exampleSchema = z.enum(['industrial', 'stay']);
const scenarioSchema = z.enum(['standard', 'long', 'no-images', 'rtl']);
const escape = (value: string) => value.replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]!));
export const designSystemV2Routes = new Hono<App>();
designSystemV2Routes.use('*', requireAuth, requireRole('owner', 'admin'));

function privateHeaders(c: Context<App>) {
  c.header('Cache-Control', 'private, no-store'); c.header('X-Robots-Tag', 'noindex, nofollow');
  c.header('X-Content-Type-Options', 'nosniff'); c.header('Referrer-Policy', 'no-referrer');
}
function preview(c: Context<App>, html: string, css: string, title: string, lang: string, dir: string, artifactHash?: string) {
  privateHeaders(c); c.header('X-Frame-Options', 'SAMEORIGIN');
  c.header('Content-Security-Policy', "sandbox allow-same-origin; default-src 'none'; script-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; font-src 'none'; connect-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'");
  return c.html(`<!doctype html><html lang="${escape(lang)}" dir="${dir === 'rtl' ? 'rtl' : 'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">${artifactHash?`<meta name="bnx-artifact-hash" content="${escape(artifactHash)}">`:''}<title>${escape(title)}</title><style>html{scroll-behavior:auto}body{margin:0}*,*::before,*::after{box-sizing:border-box}${css.replace(/<\/style/gi,'<\\/style')}</style></head><body data-pattern-preview="bnx-1" data-review-only="true">${html}</body></html>`);
}
const fixtureOptions = (c: Context<App>) => ({ imageBaseUrl: base + '/assets', scenario: scenarioSchema.parse(c.req.query('scenario') || 'standard'), example: exampleSchema.parse(c.req.query('example') || 'stay') });

designSystemV2Routes.get('/catalog', async c => ok(c, await getV2Catalog()));

designSystemV2Routes.get('/reviews', async c => {
  privateHeaders(c);
  const [catalog, reviews] = await Promise.all([getV2Catalog(), readV2PatternReviews(c.env.DB)]);
  const items = catalog.patterns.flatMap(p => p.variants.flatMap(v => v.artifacts.map(artifact => {
    const key = v2ApprovalKey(artifact), exact = canonicalV2Json(key);
    const review = reviews.find(row => canonicalV2Json({patternId:row.patternId,variantId:row.variantId,revision:row.revision,preset:row.preset,artifactHash:row.artifactHash,sourceGraphHash:row.sourceGraphHash,noticeBundleHash:row.noticeBundleHash}) === exact);
    return {...key,state:review?.state ?? 'draft',reviewerId:review?.reviewerId ?? null,reviewedAt:review?.reviewedAt ?? null};
  })));
  return ok(c, {version:'bnx-review-1',namespace:'bnx-1',canReview:c.get('auth').user.role==='owner',items});
});

designSystemV2Routes.post('/review', requireRole('owner'), async c => {
  privateHeaders(c);
  const input = await body(c, v2PatternReviewInputSchema);
  return ok(c, await recordV2PatternReview(c.env, c.get('auth').user.id, input, c.get('requestId')));
});
designSystemV2Routes.get('/preview', async c => {
  const preset = presetSchema.parse(c.req.query('preset') || V2_PRESETS[0]);
  const catalog = await getV2Catalog(), family = catalog.patterns.find(f => f.id === c.req.query('pattern'));
  const variant = family?.variants.find(v => v.id === c.req.query('variant'));
  assert(family && variant, 'NOT_FOUND', '区块不存在', 404);
  const fixture = getV2Fixture(family.id, variant.id, preset, fixtureOptions(c));
  const result = await renderV2Section(fixture.input, fixture.context);
  assert(!c.req.query('artifact')||c.req.query('artifact')===result.artifact.artifactHash,'BNX_REVIEW_STALE','模式已更新，请刷新查看新版',409);
  return preview(c, result.html, result.css, family.label + ' · ' + variant.label, fixture.lang, fixture.dir,result.artifact.artifactHash);
});
designSystemV2Routes.get('/page', async c => {
  const preset = presetSchema.parse(c.req.query('preset') || V2_PRESETS[0]), options = fixtureOptions(c);
  const fixture = createV2PageFixture({ preset, ...options }), result = await compileV2Page(fixture.input, fixture.context);
  const industrial = options.example === 'industrial';
  const context: SiteHeaderContext = { seed: 'bnx-review-' + options.example, homeHref: '#orientation', language: fixture.lang, allowFixedOverlay: true,
    menus: [{ id: 1, items: [{ id: 'gallery', label: industrial ? 'Equipment' : '空间与细节', url: '#gallery' }, { id: 'process', label: industrial ? 'Process' : '停留节奏', url: '#process' }, { id: 'questions', label: industrial ? 'Questions' : '常见问题', url: '#questions' }] }] };
  const header = compileSiteHeader(resolveSiteHeader({ version: 'bnh-1', pattern: 'classic', brand: { text: industrial ? 'JianTai' : '山间来信', logo: null }, menuId: 1,
    actions: [{ label: industrial ? 'Explore equipment' : '探索空间', href: '#gallery', style: 'primary' }], options: { mobileMode: 'dropdown', sticky: false, allowFixedOverlay: true } }, context), context);
  return preview(c, header.html + result.html, header.css + result.css, fixture.title, fixture.lang, fixture.dir);
});

/** A genuine structured submission path for integration review, with no
 * provider, wallet, project save, approval, or publication side effects. */
designSystemV2Routes.post('/plan', async c => {
  const input = await body(c, v2GenerationRequestSchema), plan = await prepareV2Generation(input);
  return ok(c, { plan, tool: v2GenerationTool(plan), paidModelCalls: 0, productionEnabled: false });
});
designSystemV2Routes.post('/compile', async c => {
  const input = await body(c, z.object({ request: v2GenerationRequestSchema, submission: z.unknown() }).strict());
  const plan = await prepareV2Generation(input.request);
  const fixture = getV2Fixture('hero-stage', 'split', plan.preset, { imageBaseUrl: base + '/assets' });
  try { return ok(c, await compileV2GenerationSubmission(plan, input.submission, fixture.context)); }
  catch (error) {
    if (error instanceof Error && /^BNX_[A-Z_]+$/.test(error.message)) throw new AppError(error.message, '设计结构与当前方案不一致，请重新提交结构内容。', 400);
    throw error;
  }
});

async function reviewDocuments(): Promise<V2ReviewDocument[]> {
  const catalog = await getV2Catalog(), documents: V2ReviewDocument[] = [];
  const sources = (ids: readonly string[]) => getV2Sources(ids).map(s => ({ name: s.name, repository: s.repository, license: s.license, relationship: s.relationship }));
  for (const preset of V2_PRESETS) {
    for (const example of ['industrial', 'stay'] as const) documents.push({ id: `page-${example}-${preset}`, title: example === 'industrial' ? '工业 · 选型与过程' : '旅宿 · 空间与体验', role: 'examples', preset, example,
      href: base + '/page?' + new URLSearchParams({ example, preset }), sourceRefs: sources(catalog.patterns.flatMap(f => f.sourceIds)), notices: ['全部为审阅参考关系；完整许可见本页“许可证”入口。'], issues: [] });
    for (const family of catalog.patterns) for (const variant of family.variants) documents.push({ id: `${family.id}-${variant.id}-${preset}`, title: family.label + ' / ' + variant.label, role: family.role,
      patternId: family.id, variantId: variant.id, preset, href: base + '/preview?' + new URLSearchParams({ pattern: family.id, variant: variant.id, preset }),
      sourceRefs: sources(family.sourceIds), notices: [], issues: [], compiledHash: variant.artifacts.find(a => a.preset === preset)?.artifactHash });
  }
  return documents;
}
designSystemV2Routes.get('/gallery', async c => {
  const output = renderV2ReviewGallery({ documents: await reviewDocuments(), cssUrl: base + '/gallery.css', jsUrl: base + '/gallery.js' });
  privateHeaders(c); c.header('X-Frame-Options', 'SAMEORIGIN');
  c.header('Content-Security-Policy', "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; frame-src 'self'; img-src 'self' data:; font-src 'none'; connect-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'");
  return c.html(output.html.replace('</main>', `</main><footer style="padding:16px 32px;font:14px system-ui"><a href="${base}/notices" target="_blank" rel="noreferrer">来源许可证</a></footer>`));
});
designSystemV2Routes.get('/gallery.css', c => { privateHeaders(c); return c.body(V2_REVIEW_GALLERY_CSS, 200, { 'Content-Type': 'text/css;charset=utf-8' }); });
designSystemV2Routes.get('/gallery.js', c => { privateHeaders(c); return c.body(V2_REVIEW_GALLERY_JS, 200, { 'Content-Type': 'application/javascript;charset=utf-8' }); });
designSystemV2Routes.get('/notices', c => {
  privateHeaders(c);
  const ids = ['boardui', 'bencho', 'heroui-open', 'beui', 'libraries-dev', 'watermelon-ui'];
  return c.text(getV2Notices(ids).map(n => `${n.sourceId}\n${n.url}\n\n${n.text}`).join('\n\n' + '='.repeat(60) + '\n\n'));
});
async function asset(c: Context<App>, file: string) {
  const item = V2_FIXTURE_ASSETS.find(a => a.file === file); assert(item, 'NOT_FOUND', '素材不存在', 404);
  const response = await c.env.ASSETS.fetch(new Request(new URL(item.path, c.req.url))); assert(response.ok, 'ASSET_UNAVAILABLE', '画廊素材尚未就绪', 503);
  return new Response(response.body, { headers: { 'Content-Type': 'image/png', 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff', ETag: '"' + item.sha256 + '"' } });
}
designSystemV2Routes.get('/assets/:file', c => asset(c, c.req.param('file')));
export const designSystemV2AssetRoutes = new Hono<App>();
designSystemV2AssetRoutes.use('*', requireAuth, requireRole('owner', 'admin'));
designSystemV2AssetRoutes.get('/:file', c => asset(c, c.req.param('file')));
