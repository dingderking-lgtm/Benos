import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { type App,body,ok } from '../lib/http';
import { AppError,assert } from '../lib/errors';
import { decryptSecret,id,randomToken,sha256 } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { requireAuth,restricted,rateLimit } from './auth';
import { hasHostingAccess,signedHostingFetch } from './hosting';
import { validateSiteManifest } from './template-contract';
import { resolveProjectAssets } from './media';
import { readDesignVersion } from './design-workspace';
import { ensureCmsBundleTransfer,advanceCmsBundleTransfer,discardCmsBundleTransfer } from './cms-transfers';

type Release={id:string;site_id:string;user_id:string;project_id:string;version_id:string;previous_version_id:string|null;idempotency_key:string;payload_hash:string;state:string;review_hash:string|null;result_json:string|null;error_code:string|null;lease_until:string|null;lease_token:string|null;created_at:string;updated_at:string;bundle_transfer_id:string|null};
type Site={id:string;user_id:string;project_id:string|null;domain:string;state:string};
const remoteSchema=z.object({id:z.string(),projectId:z.string(),versionId:z.string(),state:z.enum(['preparing','prepared','importing','imported','published','rolled_back','failed']),reviewHash:z.string().regex(/^[a-f0-9]{64}$/).optional(),summary:z.object({createPages:z.number().int().nonnegative(),updatePages:z.number().int().nonnegative(),preserveArticles:z.number().int().nonnegative(),preserveDrafts:z.literal(true),replaceGlobalTheme:z.boolean(),removePages:z.literal(0)}).optional(),backup:z.object({id:z.number().int(),size:z.number().int().positive(),checksum:z.string().regex(/^[a-f0-9]{64}$/)}).optional(),errorCode:z.string().optional()}).refine(value=>['preparing','failed'].includes(value.state)||!!value.reviewHash&&!!value.summary);
function safe(release:Release){let result:unknown=null;try{result=JSON.parse(release.result_json||'null');}catch{}return {id:release.id,siteId:release.site_id,projectId:release.project_id,versionId:release.version_id,state:release.state,reviewHash:release.review_hash,result,errorCode:release.error_code,createdAt:release.created_at,updatedAt:release.updated_at};}
async function owner(env:Env,user:string,siteId:string):Promise<Site>{const site=await env.DB.prepare('SELECT id,user_id,project_id,domain,state FROM sites WHERE id=? AND user_id=?').bind(siteId,user).first<Site>();assert(site,'NOT_FOUND','托管网站不存在',404);return site;}
async function access(env:Env,user:string,site:Site){assert(!await restricted(env.DB,user,'publish'),'ACCOUNT_RESTRICTED','网站发布权限已冻结',403);assert(!await env.DB.prepare('SELECT 1 FROM hosting_site_controls WHERE site_id=? AND paused=1').bind(site.id).first(),'HOSTING_MANUALLY_PAUSED','网站托管已由管理员暂停',403);assert(await hasHostingAccess(env,user,site.id),'HOSTING_EXPIRED','请续费会员或该网站的年度托管服务',403);assert(site.state==='connected','CMS_NOT_CONNECTED','CMS 域名与 HTTPS 连接尚未验证',409);}
async function releaseFor(env:Env,user:string,releaseId:string){const row=await env.DB.prepare('SELECT * FROM publication_releases WHERE id=? AND user_id=?').bind(releaseId,user).first<Release>();assert(row,'NOT_FOUND','发布记录不存在',404);return row;}
async function remote(env:Env,site:Site,release:Release,payload:Record<string,unknown>){
 const connection=await env.DB.prepare('SELECT origin,key_id,secret_ciphertext FROM site_connections WHERE site_id=?').bind(site.id).first<{origin:string;key_id:string;secret_ciphertext:string}>();assert(connection&&connection.origin==='https://'+site.domain,'CMS_CONNECTION_INVALID','CMS 连接身份不可用',409);
 const secret=await decryptSecret(connection.secret_ciphertext,env.ENCRYPTION_KEY,site.id);
 return signedHostingFetch(connection.origin+'/benos-connect.php','POST',{...payload,releaseId:release.id},secret,connection.key_id,site.id,release.id+'_'+String(payload.operation),'BENOS-CMS-V1');
}
async function recordResult(env:Env,release:Release,token:string,data:unknown){
 const parsed=remoteSchema.safeParse(data);assert(parsed.success&&parsed.data.id===release.id&&parsed.data.projectId===release.project_id&&parsed.data.versionId===release.version_id,'CMS_RELEASE_IDENTITY_INVALID','CMS 发布响应身份无效',502);
 const result=parsed.data,state=['importing','imported'].includes(result.state)?'uncertain':result.state,now=new Date().toISOString();
 const statements=[env.DB.prepare('UPDATE publication_releases SET state=?,review_hash=?,result_json=?,error_code=?,lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(state,result.reviewHash??null,JSON.stringify(result),result.errorCode||null,now,release.id,token)];
 if(state==='published')statements.push(env.DB.prepare("UPDATE projects SET published_version_id=?,status=CASE WHEN current_version_id=? THEN 'published' ELSE 'modified' END,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM publication_releases WHERE id=? AND lease_token=?)").bind(release.version_id,release.version_id,now,release.project_id,release.id,token));
 if(state==='rolled_back')statements.push(env.DB.prepare("UPDATE projects SET published_version_id=?,status=CASE WHEN ? IS NULL THEN 'draft' WHEN current_version_id=? THEN 'published' ELSE 'modified' END,updated_at=? WHERE id=? AND published_version_id=? AND EXISTS(SELECT 1 FROM publication_releases WHERE id=? AND lease_token=?)").bind(release.previous_version_id,release.previous_version_id,release.previous_version_id,now,release.project_id,release.version_id,release.id,token));
 try{await env.DB.batch(statements);}catch(error){await inProgressConflict(env,release,token,error);throw error;}
}
/** The single-open-release index rejected a state change (another release of
 * the site is open). Release the lease and answer 409 instead of 500. */
async function inProgressConflict(env:Env,release:Release,token:string,error:unknown):Promise<void>{
 if(!/publication_in_progress|UNIQUE constraint failed: publication_releases/.test(String(error instanceof Error?`${error.message} ${error.cause??''}`:error)))return;
 await env.DB.prepare('UPDATE publication_releases SET lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(new Date().toISOString(),release.id,token).run();
 throw new AppError('PUBLICATION_IN_PROGRESS','该网站已有待确认或未核验完成的发布任务',409);
}
const isDiscarded=(release:Release)=>release.state==='failed'&&release.error_code==='PUBLICATION_DISCARDED';
export async function runPublicationOperation(env:Env,user:string,releaseId:string,operation:'prepare'|'commit'|'status'|'rollback'|'discard',reviewHash?:string):Promise<void>{
 let release=await releaseFor(env,user,releaseId);const site=await owner(env,user,release.site_id);await access(env,user,site);
 // A discarded preparation is final: it is never prepared again or committed,
 // even if a late CMS record appears (reconcile/discard then close that record).
 const discarded=isDiscarded(release);
 assert(!(discarded&&operation==='commit'),'PUBLICATION_DISCARDED','该发布准备已取消，请重新准备发布',409);
 if(discarded&&!['status','discard'].includes(operation))return;
 if(operation==='commit')assert(release.review_hash&&release.review_hash===reviewHash,'REVIEW_REQUIRED','请确认当前发布影响后继续',409);
 if(operation==='rollback')assert(['published','rolling_back','uncertain','rolled_back'].includes(release.state),'ROLLBACK_UNAVAILABLE','该版本尚不能回滚',409);
 if(operation==='discard')assert(['preparing','prepared','uncertain'].includes(release.state)||release.state==='failed'&&release.error_code==='PUBLICATION_DISCARDED','DISCARD_UNAVAILABLE','只能取消尚未开始导入的发布准备',409);
 const token=randomToken(20),now=new Date().toISOString();
 const leased=await env.DB.prepare('UPDATE publication_releases SET lease_token=?,lease_until=?,updated_at=? WHERE id=? AND (lease_until IS NULL OR lease_until<?) RETURNING *').bind(token,new Date(Date.now()+240000).toISOString(),now,release.id,now).first<Release>();if(!leased)return;release=leased;
 const beforeMutation=async()=>{
  assert(await env.DB.prepare("SELECT 1 FROM users WHERE id=? AND status='active'").bind(user).first(),'ACCOUNT_RESTRICTED','账户已暂停',403);const current=await owner(env,user,site.id);await access(env,user,current);assert(current.domain===site.domain&&current.project_id===site.project_id,'CMS_CONNECTION_CHANGED','CMS 网站连接已变更，请继续原记录重新核对',409);
  assert(await env.DB.prepare('SELECT 1 FROM publication_releases WHERE id=? AND lease_token=? AND lease_until>?').bind(release.id,token,new Date(Date.now()+25000).toISOString()).first(),'CMS_RELEASE_LEASE_CHANGED','发布准备已被接管，请继续核对原记录',409);
 };
 try{
   // Reconcile before every mutating retry; the exact remote release is durable.
   const status=await remote(env,site,release,{operation:'status'});
   if(discarded){
     // Only two outcomes are possible: a CMS record that landed late as
     // 'prepared' is discarded at the CMS too, or nothing changes (the row
     // keeps PUBLICATION_DISCARDED). Never send a prepare or a commit.
     const parsed=status.status===200?remoteSchema.safeParse(status.data):null;
     const remoteState=parsed?.success&&parsed.data.id===release.id&&parsed.data.projectId===release.project_id&&parsed.data.versionId===release.version_id?parsed.data.state:null;
     if(remoteState!=='prepared'){await env.DB.prepare('UPDATE publication_releases SET lease_until=NULL WHERE id=? AND lease_token=?').bind(release.id,token).run();return;}
     operation='discard';
   }
   else if(status.status===200){const parsed=remoteSchema.safeParse(status.data);assert(parsed.success&&parsed.data.id===release.id&&parsed.data.projectId===release.project_id&&parsed.data.versionId===release.version_id,'CMS_RELEASE_IDENTITY_INVALID','CMS 发布响应身份无效',502);if(operation==='status'&&parsed.data.state!=='preparing'||operation==='prepare'&&parsed.data.state==='prepared'||['published','rolled_back','failed','importing','imported'].includes(parsed.data.state)&&operation!=='rollback'){await recordResult(env,release,token,status.data);return;}}
   else assert(status.status===404,'CMS_RELEASE_UNAVAILABLE','CMS 发布状态暂不可用',502);
   if(operation==='discard'&&status.status===404&&release.bundle_transfer_id){
     await beforeMutation();const transfer=await discardCmsBundleTransfer(env,user,release.bundle_transfer_id,{authorize:beforeMutation});assert(transfer.state==='discarded','CMS_RELEASE_CANCEL_UNCERTAIN','CMS 尚未确认停止资源传输，请继续核对原记录',409);
     await env.DB.prepare("UPDATE publication_releases SET state='failed',result_json=?,error_code='PUBLICATION_DISCARDED',lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?").bind(JSON.stringify({transfer}),new Date().toISOString(),release.id,token).run();return;
   }
   if(operation==='discard'&&status.status===404&&!release.review_hash){
     // The signed CMS holds no record of this release, no bundle was ever
     // started and the CMS never returned a review. Close it locally and free
     // the site's single open-release slot. If the outcome of the original
     // prepare was unknown (timeout) and its record lands later, that record is
     // inert: this release is final (never prepared again or committed) and the
     // next reconcile/discard closes the late record at the CMS as well.
     // (A record that existed and then vanished stays CMS_RELEASE_MISSING.)
     await beforeMutation();
     await env.DB.prepare("UPDATE publication_releases SET state='failed',result_json=?,error_code='PUBLICATION_DISCARDED',lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?").bind(JSON.stringify({discarded:true,remote:'absent',previousErrorCode:release.error_code}),new Date().toISOString(),release.id,token).run();return;
   }
   if(operation==='discard')assert(status.status===200,'CMS_RELEASE_MISSING','尚未确认 CMS 中的准备记录，请先核对状态',409);
   let payload:Record<string,unknown>={operation};
   if(operation==='prepare'||operation==='status'&&(status.status===404||(status.data as {state?:string}).state==='preparing')){
     const stored=await env.DB.prepare('SELECT manifest_json,manifest_object_id FROM design_versions WHERE id=? AND project_id=?').bind(release.version_id,release.project_id).first<{manifest_json:string;manifest_object_id:string|null}>();assert(stored,'NOT_FOUND','设计版本不存在',404);const index=JSON.parse(stored.manifest_json),large=!!stored.manifest_object_id||index.assets.reduce((sum:number,a:{size:number})=>sum+a.size,0)>6*1048576;
     if(large||release.bundle_transfer_id){
       if(!release.bundle_transfer_id){
         const connection=await env.DB.prepare('SELECT origin,key_id,secret_ciphertext FROM site_connections WHERE site_id=?').bind(site.id).first<{origin:string;key_id:string;secret_ciphertext:string}>();assert(connection&&connection.origin==='https://'+site.domain,'CMS_CONNECTION_INVALID','CMS 连接身份不可用',409);
         const secret=await decryptSecret(connection.secret_ciphertext,env.ENCRYPTION_KEY,site.id),health=await signedHostingFetch(connection.origin+'/benos-health.php','GET',null,secret,connection.key_id,site.id,release.id+'_bundle_capability','BENOS-CMS-V1');
         const data=health.data as {siteId?:string;installed?:boolean;capabilities?:string[]};assert(health.status===200&&data.siteId===site.id&&data.installed===true&&Array.isArray(data.capabilities)&&data.capabilities.includes('bundlePublishV2'),'CMS_UPGRADE_REQUIRED','请先升级此网站的 CMS 连接，再发布完整容量模板',409);
         const transfer=await ensureCmsBundleTransfer(env,user,site.id,release.version_id,release.id+':publish','publish');release.bundle_transfer_id=transfer.id;await env.DB.prepare('UPDATE publication_releases SET bundle_transfer_id=? WHERE id=? AND lease_token=?').bind(transfer.id,release.id,token).run();
       }
       // A durable CMS preparing intent owns its pin, including after staging
       // expiry. Resume that exact intent; never replace its bundle identity.
       if(status.status!==200||(status.data as {state?:string}).state!=='preparing'){
         const transfer=await advanceCmsBundleTransfer(env,user,release.bundle_transfer_id,{authorize:beforeMutation});
         if(!transfer.sealed){await env.DB.prepare('UPDATE publication_releases SET state=?,result_json=?,error_code=?,lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(['expired','discarded'].includes(transfer.state)?'failed':'preparing',JSON.stringify({transfer}),transfer.errorCode,new Date().toISOString(),release.id,token).run();return;}
       }
       payload={operation:'prepare',projectId:release.project_id,versionId:release.version_id,bundleId:release.bundle_transfer_id};
     }else{
       const manifest=await readDesignVersion(env,user,release.project_id,release.version_id);assert(validateSiteManifest(manifest).valid,'TEMPLATE_INVALID','模板清单未通过校验',422);
       const resolved=await resolveProjectAssets(env,user,release.project_id,manifest);
       const assets=resolved.files.map(item=>{let binary='';for(let i=0;i<item.bytes.length;i+=32768)binary+=String.fromCharCode(...item.bytes.subarray(i,i+32768));return {file:item.file,base64:btoa(binary)};});
       payload={operation:'prepare',projectId:release.project_id,versionId:release.version_id,manifest,assets};assert(new TextEncoder().encode(JSON.stringify(payload)).length<=10*1048576,'PUBLICATION_PACKAGE_TOO_LARGE','发布内容超过单次传输上限',413);
     }
   }else if(operation==='commit')payload.reviewHash=reviewHash;
   await beforeMutation();
   const response=await remote(env,site,release,payload);
   if(response.status!==200){const data=response.data as {error?:{code?:string}};throw new AppError(data.error?.code||'CMS_RELEASE_REJECTED','CMS 未完成本次发布；现有内容已保留',response.status===409?409:502);}
   await recordResult(env,release,token,response.data);
 }catch(error){
   if(error instanceof AppError&&error.code==='PUBLICATION_IN_PROGRESS')throw error;
   const code=error instanceof AppError?error.code:'CMS_RELEASE_UNCERTAIN',at=new Date().toISOString();
   // A discarded release stays discarded; only its lease is released.
   if(discarded){await env.DB.prepare('UPDATE publication_releases SET lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?').bind(at,release.id,token).run();return;}
   try{await env.DB.prepare("UPDATE publication_releases SET state='uncertain',error_code=?,lease_until=NULL,updated_at=? WHERE id=? AND lease_token=?").bind(code,at,release.id,token).run();}
   catch(failure){await inProgressConflict(env,release,token,failure);throw failure;}
 }
}
/** Background preparation never commits. The user must still review and send
 * the exact CMS review hash to the existing commit endpoint. */
export async function continuePublicationPreparations(env:Env,limit=5){
 const rows=await env.DB.prepare("SELECT id,user_id FROM publication_releases WHERE state='preparing' AND bundle_transfer_id IS NOT NULL ORDER BY updated_at LIMIT ?").bind(Math.max(1,Math.min(10,limit))).all<{id:string;user_id:string}>();let continued=0,failed=0;
 for(const row of rows.results)try{await runPublicationOperation(env,row.user_id,row.id,'prepare');const current=await releaseFor(env,row.user_id,row.id);if(current.error_code)failed++;else continued++;}catch{failed++;}return {continued,failed};
}
export const publishingRoutes=new Hono<App>();publishingRoutes.use('*',requireAuth);
publishingRoutes.get('/sites/:site/releases',async c=>{const user=c.get('auth').user.id;await owner(c.env,user,c.req.param('site'));const rows=await c.env.DB.prepare('SELECT * FROM publication_releases WHERE site_id=? AND user_id=? ORDER BY created_at DESC LIMIT 100').bind(c.req.param('site'),user).all<Release>();return ok(c,{items:rows.results.map(safe)});});
publishingRoutes.post('/sites/:site/prepare',async c=>{
 const user=c.get('auth').user.id,site=await owner(c.env,user,c.req.param('site'));await access(c.env,user,site);await rateLimit(c,'publication',30,3600,user);
 const input=await body(c,z.object({versionId:z.string().regex(/^ver_[a-f0-9]{32}$/)}).strict()),key=z.string().regex(/^[A-Za-z0-9_-]{8,128}$/).safeParse(c.req.header('Idempotency-Key'));assert(key.success,'IDEMPOTENCY_REQUIRED','请提供稳定请求标识');
 const version=await c.env.DB.prepare('SELECT v.project_id,v.content_hash,p.published_version_id FROM design_versions v JOIN projects p ON p.id=v.project_id WHERE v.id=? AND p.user_id=? AND p.archived_at IS NULL').bind(input.versionId,user).first<{project_id:string;content_hash:string;published_version_id:string|null}>();assert(version&&site.project_id===version.project_id,'PROJECT_SITE_MISMATCH','设计版本与所选托管网站不匹配',409);
 const hash=await sha256(JSON.stringify([site.id,input.versionId,version.content_hash]));let row=await c.env.DB.prepare('SELECT * FROM publication_releases WHERE user_id=? AND idempotency_key=?').bind(user,key.data).first<Release>();
 if(row)assert(row.payload_hash===hash,'IDEMPOTENCY_CONFLICT','请求标识已用于不同发布内容',409);
 else{const releaseId=id('rel'),now=new Date().toISOString();try{await c.env.DB.prepare("INSERT INTO publication_releases(id,site_id,user_id,project_id,version_id,previous_version_id,idempotency_key,payload_hash,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,'preparing',?,?)").bind(releaseId,site.id,user,version.project_id,input.versionId,version.published_version_id,key.data,hash,now,now).run();}catch{throw new AppError('PUBLICATION_IN_PROGRESS','该网站已有待确认或未核验完成的发布任务',409);}row=await releaseFor(c.env,user,releaseId);}
 await runPublicationOperation(c.env,user,row.id,'prepare');return ok(c,{release:safe(await releaseFor(c.env,user,row.id))},202);
});
publishingRoutes.get('/releases/:id',async c=>ok(c,{release:safe(await releaseFor(c.env,c.get('auth').user.id,c.req.param('id')))}));
for(const operation of ['commit','rollback','reconcile','discard'] as const)publishingRoutes.post('/releases/:id/'+operation,async c=>{
 const user=c.get('auth').user.id,input=await body(c,z.object({reviewHash:z.string().regex(/^[a-f0-9]{64}$/).optional()}).strict());
 const releaseId=c.req.param('id')!;await runPublicationOperation(c.env,user,releaseId,operation==='reconcile'?'status':operation,input.reviewHash);
 await auditStatement(c.env.DB,user,'publication.'+operation,'release',releaseId,{},c.get('requestId')).run();return ok(c,{release:safe(await releaseFor(c.env,user,releaseId))},202);
});
