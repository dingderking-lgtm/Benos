import { z } from 'zod';
import type { Env } from '../env';
import { assert } from '../lib/errors';
import { encryptSecret,decryptSecret,randomToken,sha256 } from '../lib/crypto';
import { ensureTusUpload,type TusCheckpoint } from './hosting-tus';
import { bootstrapSource } from './hosting-bootstrap-source';
export const bootstrapConfiguration=z.object({adapter:z.literal('hostinger-hpanel'),deploymentMode:z.literal('hostinger-tus-bootstrap'),hostingOrderId:z.number().int().positive().safe(),accountUsername:z.string().regex(/^u[0-9]{3,20}$/),cmsReleaseObjectKey:z.string().regex(/^private\/cms-releases\/[A-Za-z0-9/_-]+\.zip$/).max(300),cmsReleaseSha256:z.string().regex(/^[a-f0-9]{64}$/),cmsReleaseSize:z.number().int().positive().max(48*1048576)}).passthrough();
export type BootstrapConfiguration=z.infer<typeof bootstrapConfiguration>;
type Intent={job_id:string;site_id:string;config_version_id:string;secret_ciphertext:string;expires_at:number;bootstrap_sha256:string;release_sha256:string;release_size:number;bootstrap_checkpoint_json:string|null;release_checkpoint_json:string|null};
export async function trustedRelease(env:Env,config:BootstrapConfiguration):Promise<Uint8Array>{
 assert(env.BUCKET,'CMS_RELEASE_STORAGE_REQUIRED','CMS 发行包存储尚未配置',503);const object=await env.BUCKET.get(config.cmsReleaseObjectKey);assert(object&&object.size===config.cmsReleaseSize&&object.size<=48*1048576,'CMS_RELEASE_INVALID','CMS 发行包大小校验失败',503);const bytes=new Uint8Array(await object.arrayBuffer());assert(await sha256(bytes)===config.cmsReleaseSha256,'CMS_RELEASE_INVALID','CMS 发行包摘要校验失败',503);return bytes;
}
export async function prepareBootstrap(env:Env,configId:string,config:BootstrapConfiguration,apiToken:string,job:{id:string;siteId:string;domain:string;leaseToken:string}):Promise<{ready:boolean;step:string;endpoint?:string;keyId?:string;signingSecret?:string;releaseSha256?:string}>{
 let intent=await env.DB.prepare('SELECT * FROM hosting_bootstrap_intents WHERE job_id=?').bind(job.id).first<Intent>();
 if(!intent){const secret=randomToken(40),expires=Math.floor(Date.now()/1000)+86400,now=new Date().toISOString();const source=renderBootstrap({jobId:job.id,siteId:job.siteId,domain:job.domain,accountUsername:config.accountUsername,signingSecret:secret,keyId:'bootstrap',releaseFilename:'benos-release-'+config.cmsReleaseSha256+'.zip',releaseSha256:config.cmsReleaseSha256,releaseSize:config.cmsReleaseSize,expiresAt:expires});
   await env.DB.prepare('INSERT INTO hosting_bootstrap_intents(job_id,site_id,config_version_id,secret_ciphertext,expires_at,bootstrap_sha256,release_sha256,release_size,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(job_id) DO NOTHING').bind(job.id,job.siteId,configId,await encryptSecret(secret,env.ENCRYPTION_KEY,'bootstrap:'+job.id),expires,await sha256(source),config.cmsReleaseSha256,config.cmsReleaseSize,now,now).run();intent=await env.DB.prepare('SELECT * FROM hosting_bootstrap_intents WHERE job_id=?').bind(job.id).first<Intent>();
 }
 assert(intent&&intent.site_id===job.siteId&&intent.config_version_id===configId&&intent.release_sha256===config.cmsReleaseSha256&&intent.release_size===config.cmsReleaseSize,'BOOTSTRAP_INTENT_CONFLICT','安装任务发行包或账号范围已变化',409);
 assert(intent.expires_at>Math.floor(Date.now()/1000),'BOOTSTRAP_EXPIRED','安装授权已过期，请管理员重新核验该任务',409);
 const secret=await decryptSecret(intent.secret_ciphertext,env.ENCRYPTION_KEY,'bootstrap:'+job.id),bootstrapPath='benos-bootstrap-'+job.id.slice(4)+'.php',releasePath='benos-release-'+config.cmsReleaseSha256+'.zip';
 const bytes=renderBootstrap({jobId:job.id,siteId:job.siteId,domain:job.domain,accountUsername:config.accountUsername,signingSecret:secret,keyId:'bootstrap',releaseFilename:releasePath,releaseSha256:config.cmsReleaseSha256,releaseSize:config.cmsReleaseSize,expiresAt:intent.expires_at});
 assert(await sha256(bytes)===intent.bootstrap_sha256,'BOOTSTRAP_SOURCE_CHANGED','安装程序已更新，当前任务需管理员核验后恢复',409);
 const persist=(column:'bootstrap_checkpoint_json'|'release_checkpoint_json')=>async(checkpoint:TusCheckpoint)=>{
   const result=await env.DB.prepare(`UPDATE hosting_bootstrap_intents SET ${column}=?,updated_at=? WHERE job_id=? AND EXISTS(SELECT 1 FROM provisioning_jobs WHERE id=? AND lease_token=?) RETURNING job_id`).bind(JSON.stringify(checkpoint),new Date().toISOString(),job.id,job.id,job.leaseToken).first();assert(result,'HOSTING_LEASE_LOST','安装任务已由其他工作进程接管',409);
 };
 const common={apiToken,accountUsername:config.accountUsername,domain:job.domain};
 const boot=await ensureTusUpload({...common,relativePath:bootstrapPath,bytes,sha256:intent.bootstrap_sha256,checkpoint:intent.bootstrap_checkpoint_json?JSON.parse(intent.bootstrap_checkpoint_json):undefined,persist:persist('bootstrap_checkpoint_json')});
 if(!boot.complete)return {ready:false,step:'upload_bootstrap'};
 const release=await ensureTusUpload({...common,relativePath:releasePath,bytes:await trustedRelease(env,config),sha256:config.cmsReleaseSha256,checkpoint:intent.release_checkpoint_json?JSON.parse(intent.release_checkpoint_json):undefined,persist:persist('release_checkpoint_json')});
 if(!release.complete)return {ready:false,step:'upload_cms_release'};
 return {ready:true,step:'verify_bootstrap_https',endpoint:'https://'+job.domain+'/'+bootstrapPath,keyId:'bootstrap',signingSecret:secret,releaseSha256:config.cmsReleaseSha256};
}
export function renderBootstrap(config:Record<string,unknown>):Uint8Array {
 const bytes=new TextEncoder().encode(JSON.stringify(config));let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);
 return new TextEncoder().encode(bootstrapSource.replace('__BENOS_BOOTSTRAP_CONFIG_BASE64__',btoa(binary)));
}
