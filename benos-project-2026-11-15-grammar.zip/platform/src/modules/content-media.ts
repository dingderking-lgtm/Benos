import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../env';
import { body,ok,type App } from '../lib/http';
import { assert,AppError } from '../lib/errors';
import { id,sha256,base64url,unbase64url } from '../lib/crypto';
import { auditStatement } from '../lib/audit';
import { boundedBytes,inspectMediaBytes,MAX_MEDIA_BYTES } from './media';
import { rateLimit } from './auth';
import { contentDependencies,dependencyMessage } from './content-references';

type Row={id:string;actor_id:string;request_key:string;request_hash:string;object_key:string;filename:string;mime_type:string;extension:string;byte_size:number;width:number;height:number;sha256:string;state:string;revision:number;created_at:string;updated_at:string;deleted_at:string|null};
const stateChange=z.object({revision:z.number().int().positive()}).strict();
export const contentMediaId=z.string().regex(/^cmedia_[a-f0-9]{32}$/);
export const publicMediaPath=(mediaId:string)=>'/api/content/media/'+mediaId;
const referenced=(snapshot:string)=>`(json_extract(${snapshot},'$.coverMediaId')=m.id OR instr(COALESCE(json_extract(${snapshot},'$.body'),''),'/api/content/media/'||m.id)>0)`;
const mediaPublicSql=`(EXISTS(SELECT 1 FROM content_entries e WHERE e.state='published' AND ${referenced('e.published_json')}) OR EXISTS(SELECT 1 FROM platform_brand_versions b WHERE b.state='active' AND json_extract(b.configuration_json,'$.logoMediaId')=m.id))`;
function view(row:Row){return {id:row.id,fileName:row.filename,mimeType:row.mime_type,byteSize:row.byte_size,width:row.width,height:row.height,sha256:row.sha256,state:row.state,revision:row.revision,createdAt:row.created_at,deletedAt:row.deleted_at,previewUrl:'/api/admin/content/media/'+row.id+'/file',publicUrl:publicMediaPath(row.id)};}
async function rowFor(env:Env,mediaId:string){const row=await env.DB.prepare('SELECT * FROM content_media WHERE id=?').bind(mediaId).first<Row>();assert(row,'NOT_FOUND','素材不存在',404);return row;}
function bucket(env:Env){assert(env.BUCKET,'MEDIA_NOT_CONFIGURED','素材存储尚未配置',503);return env.BUCKET;}
export function contentMediaGuard(env:Env,mediaId:string|null|undefined){
 if(!mediaId)return [];const guard=id('guard');
 return [env.DB.prepare("INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM content_media WHERE id=? AND state='ready') THEN 1 ELSE 0 END").bind(guard,mediaId),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)];
}
export async function readContentMedia(env:Env,mediaId:string,publicOnly=false){
 const allowed=()=>env.DB.prepare(`SELECT m.id FROM content_media m WHERE m.id=? AND m.state='ready' ${publicOnly?'AND '+mediaPublicSql:''}`).bind(mediaId).first();
 assert(await allowed(),'NOT_FOUND','素材未公开或不存在',404);
 const row=await rowFor(env,mediaId),object=await bucket(env).get(row.object_key);assert(object&&object.size===row.byte_size,'MEDIA_UNAVAILABLE','素材副本暂不可用',503);
 const bytes=new Uint8Array(await object.arrayBuffer());assert(await sha256(bytes)===row.sha256,'MEDIA_CORRUPT','素材校验失败',503);assert(await allowed(),'NOT_FOUND','素材未公开或不存在',404);
 return new Response(bytes,{headers:{'Content-Type':row.mime_type,'Cache-Control':'private, no-store','Content-Length':String(bytes.length),'X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox",'Cross-Origin-Resource-Policy':'same-origin','Referrer-Policy':'no-referrer','X-Robots-Tag':'noindex'}});
}
export async function saveContentMedia(env:Env,actorId:string,input:{bytes:Uint8Array;fileName:string;mimeType?:string;requestKey:string}){
 const storage=bucket(env),info=await inspectMediaBytes(input.bytes,input.mimeType);
 assert(['png','jpg','webp'].includes(info.extension),'MEDIA_INVALID','营销页封面仅支持 PNG、JPEG、WebP 图片',422);
 assert(/^[A-Za-z0-9_-]{8,128}$/.test(input.requestKey),'VALIDATION','上传请求编号无效');assert(input.fileName.length>0&&input.fileName.length<=180&&!/[\x00-\x1f\x7f/\\]/.test(input.fileName),'VALIDATION','文件名无效');
 const hash=await sha256(JSON.stringify({fileName:input.fileName,sha256:info.sha256}));
 let row=await env.DB.prepare('SELECT * FROM content_media WHERE actor_id=? AND request_key=?').bind(actorId,input.requestKey).first<Row>();
 if(!row){const mediaId=id('cmedia'),now=new Date().toISOString();await env.DB.prepare('INSERT INTO content_media(id,actor_id,request_key,request_hash,object_key,filename,mime_type,extension,byte_size,width,height,sha256,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(actor_id,request_key) DO NOTHING').bind(mediaId,actorId,input.requestKey,hash,'private/marketing/'+mediaId+'/original.'+info.extension,input.fileName,info.mimeType,info.extension,info.byteSize,info.width,info.height,info.sha256,now,now).run();row=await env.DB.prepare('SELECT * FROM content_media WHERE actor_id=? AND request_key=?').bind(actorId,input.requestKey).first<Row>();}
 assert(row,'MEDIA_WRITE_UNCERTAIN','上传结果待核对，请沿用原请求重试',503);assert(row.request_hash===hash,'IDEMPOTENCY_CONFLICT','请求编号已用于其他图片',409);
 if(row.state==='staging'){await storage.put(row.object_key,new Uint8Array(input.bytes),{httpMetadata:{contentType:info.mimeType,cacheControl:'private, no-store'},customMetadata:{sha256:info.sha256}});await env.DB.batch([env.DB.prepare("UPDATE content_media SET state='ready',updated_at=? WHERE id=? AND state='staging'").bind(new Date().toISOString(),row.id),auditStatement(env.DB,actorId,'content.media.upload','content_media',row.id,{sha256:info.sha256},input.requestKey)]);}
 return view(await rowFor(env,row.id));
}
export async function changeContentMedia(env:Env,actorId:string,mediaId:string,revision:number,action:'delete'|'restore',requestId:string){
 const guard=id('guard'),now=new Date().toISOString();
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO mutation_guards(id,permitted) SELECT ?,CASE WHEN EXISTS(SELECT 1 FROM content_media m WHERE m.id=? AND m.revision=? AND m.state=? ${action==='delete'?`AND NOT EXISTS(SELECT 1 FROM content_entries e WHERE e.state<>'trashed' AND (${referenced('e.draft_json')} OR ${referenced('e.published_json')})) AND NOT EXISTS(SELECT 1 FROM platform_brand_versions b WHERE json_extract(b.configuration_json,'$.logoMediaId')=m.id)`:''}) THEN 1 ELSE 0 END`).bind(guard,mediaId,revision,action==='delete'?'ready':'deleted'),
  env.DB.prepare('UPDATE content_media SET state=?,revision=revision+1,updated_at=?,deleted_at=? WHERE id=?').bind(action==='delete'?'deleted':'ready',now,action==='delete'?now:null,mediaId),auditStatement(env.DB,actorId,'content.media.'+action,'content_media',mediaId,{revision},requestId),env.DB.prepare('DELETE FROM mutation_guards WHERE id=?').bind(guard)
 ]);}catch(error){if(String(error).includes('mutation_revision_ok')){const dependencies=action==='delete'?await contentDependencies(env,mediaId,true):[];throw new AppError('MEDIA_REFERENCED_OR_CHANGED',dependencies.length?dependencyMessage(dependencies):'素材版本或状态已变化，请刷新核对',409);}throw error;}
 return view(await rowFor(env,mediaId));
}
export const contentMediaRoutes=new Hono<App>();
contentMediaRoutes.get('/',async c=>{
 const q=(c.req.query('q')||'').trim(),state=c.req.query('state')||'ready',sort=c.req.query('sort')||'newest',cursor=c.req.query('cursor');assert(q.length<=160&&['ready','deleted','any'].includes(state)&&['newest','name'].includes(sort),'VALIDATION','素材筛选无效');
 const key=sort==='name'?'lower(filename)':'created_at',dir=sort==='name'?'ASC':'DESC',cmp=sort==='name'?'>':'<',signature=JSON.stringify([q,state,sort]);let after:{key:string;id:string;signature:string}|null=null;
 if(cursor){try{after=JSON.parse(new TextDecoder().decode(unbase64url(cursor)));}catch{throw new AppError('VALIDATION','分页标识无效');}assert(after&&typeof after.key==='string'&&typeof after.id==='string'&&after.signature===signature,'VALIDATION','分页标识与筛选不符');}
 const rows=await c.env.DB.prepare(`SELECT *,${key} AS sort_key FROM content_media WHERE state<>'staging' AND (?='any' OR state=?) AND instr(lower(filename),lower(?))>0 AND (? IS NULL OR ${key}${cmp}? OR (${key}=? AND id${cmp}?)) ORDER BY ${key} ${dir},id ${dir} LIMIT 61`).bind(state,state,q,after?.key??null,after?.key??null,after?.key??null,after?.id??null).all<Row&{sort_key:string}>();const items=rows.results.slice(0,60),last=items.at(-1);
 return ok(c,{items:items.map(view),nextCursor:rows.results.length>60&&last?base64url(new TextEncoder().encode(JSON.stringify({key:last.sort_key,id:last.id,signature}))):null});
});
contentMediaRoutes.post('/',async c=>{const actor=c.get('auth').user.id;await rateLimit(c,'content-media',60,3600,actor);let fileName='';try{fileName=decodeURIComponent(c.req.header('x-filename')||'');}catch{throw new AppError('VALIDATION','文件名编码无效');}return ok(c,await saveContentMedia(c.env,actor,{bytes:await boundedBytes(c.req.raw.body,MAX_MEDIA_BYTES),fileName,mimeType:c.req.header('content-type'),requestKey:c.req.header('idempotency-key')||''}),201);});
contentMediaRoutes.get('/:id/references',async c=>{await rowFor(c.env,c.req.param('id'));return ok(c,{items:await contentDependencies(c.env,c.req.param('id'),true)});});
contentMediaRoutes.get('/:id/file',c=>readContentMedia(c.env,c.req.param('id')));
contentMediaRoutes.post('/bulk',async c=>{const input=await body(c,z.object({action:z.enum(['delete','restore']),items:z.array(stateChange.extend({id:contentMediaId})).min(1).max(100)}).strict());const results=[];for(const item of input.items){try{results.push({id:item.id,ok:true,data:await changeContentMedia(c.env,c.get('auth').user.id,item.id,item.revision,input.action,c.get('requestId'))});}catch(error){results.push({id:item.id,ok:false,error:{code:error instanceof AppError?error.code:'OPERATION_FAILED',message:error instanceof AppError?error.message:'操作未完成，请刷新核对'}});}}return ok(c,{items:results});});
for(const action of ['delete','restore'] as const)contentMediaRoutes.post('/:id/'+action,async c=>{const input=await body(c,stateChange);return ok(c,await changeContentMedia(c.env,c.get('auth').user.id,c.req.param('id')!,input.revision,action,c.get('requestId')));});
