import { imageConfigSchema,imageUsageCost,type ImagePricing,type ImageContract } from '../lib/image-billing';
import { IMAGE_SIZES,type ImageSize } from '../lib/image-layout';
import { assert } from '../lib/errors';

export const IMAGE_ESTIMATION_POLICY='image-estimate-v1' as const;
const WINDOW_MS=30*24*60*60*1000;
const rates=['textInputMicrosPerMillion','imageInputMicrosPerMillion','cachedTextInputMicrosPerMillion','cachedImageInputMicrosPerMillion','imageOutputMicrosPerMillion'] as const;
export type ImageEstimateSample={jobId:string;receiptSha256:string;size:ImageSize;actualMicros:number;settledAtMs:number;legacyComplexityOmitted:boolean;corrected:boolean};
export type ImageEstimateSnapshot={
 policy:typeof IMAGE_ESTIMATION_POLICY;estimated:true;source:'verified-receipts-max-30-v2'|'approved-image-fallback-20261114';
 frozenAtMs:number;windowStartMs:number;maxSamplesPerSize:30;minimumOwnSamples:5;model:string;size:ImageSize;quality:'low'|'medium';
 rateContract:Record<string,string|number>;sampleCounts:Record<ImageSize,number>;ownMaxMicros:number|null;crossMaxMicros:number|null;
 selectedMicros:number;reservedMicros:number;estimatedMicros:number;rule:'own-max'|'small-sample-cross-max'|'approved-fallback';samples:ImageEstimateSample[];
};
export function imageRateContract(p:ImagePricing){return {model:p.model,quality:p.quality,complexity:p.complexity,outputFormat:p.outputFormat,n:p.n,...Object.fromEntries(rates.map(k=>[k,p[k]]))};}
/** Planning and dispatch share this read-only sampler. Per-size windows prevent
 * a popular landscape size from evicting the portrait evidence. No estimate is
 * a true sample; corrected entries need a completed, matching real receipt. */
export async function imageEstimatedCost(db:D1Database,pricing:ImagePricing,reservedMicros:number,nowMs=Date.now()):Promise<ImageEstimateSnapshot>{
 assert(['gpt-image-2.6-flare','gpt-image-2.6-sunburst'].includes(pricing.model)&&IMAGE_SIZES.includes(pricing.size)&&(pricing.quality==='low'||pricing.quality==='medium')&&Number.isSafeInteger(reservedMicros)&&reservedMicros>0,'IMAGE_ESTIMATE_UNSUPPORTED','当前图片规格没有已批准的估算政策',409);
 const contract=imageRateContract(pricing),samples:ImageEstimateSample[]=[],counts={} as Record<ImageSize,number>;
 for(const size of IMAGE_SIZES){
  counts[size]=0;let offset=0;
  while(counts[size]<30){
   const rows=await db.prepare(`SELECT j.id,j.pricing_json,j.request_json,j.usage_json,j.response_sha256,
    r.actual_micros,r.completed_at_ms,e.job_id estimated_job,c.state correction_state,c.actual_micros corrected_actual,c.receipt_sha256 corrected_hash,c.applied_at_ms
    FROM image_jobs j JOIN api_reservations r ON r.id=j.reservation_id
    LEFT JOIN image_estimated_settlements e ON e.job_id=j.id LEFT JOIN image_cost_corrections c ON c.job_id=j.id
    WHERE r.state='settled' AND j.usage_json IS NOT NULL AND length(j.response_sha256)=64
     AND (e.job_id IS NULL OR (c.state='applied' AND c.receipt_sha256=j.response_sha256 AND
       (SELECT COUNT(*) FROM ledger_events l WHERE l.resource_id=j.id AND l.kind='image_cost_correction' AND l.amount_micros=c.delta_micros)=1))
     AND COALESCE(c.applied_at_ms,r.completed_at_ms)>=? AND COALESCE(c.applied_at_ms,r.completed_at_ms)<=?
     AND json_valid(j.pricing_json) AND json_extract(j.pricing_json,'$.model')=?
     AND json_extract(j.pricing_json,'$.quality')=? AND json_extract(j.pricing_json,'$.size')=?
     AND (SELECT COUNT(*) FROM ledger_events l WHERE l.resource_id=r.id AND l.kind='settled' AND l.amount_micros=r.actual_micros)=1
    ORDER BY COALESCE(c.applied_at_ms,r.completed_at_ms) DESC,j.id DESC LIMIT 100 OFFSET ?`).bind(nowMs-WINDOW_MS,nowMs,pricing.model,pricing.quality,size,offset).all<any>();
   for(const row of rows.results){
    try{
     const p=imageConfigSchema.parse(JSON.parse(row.pricing_json)),request=JSON.parse(row.request_json),billing=request.billingContract as ImageContract;
     // Fixture contracts are test-only and never legitimate production samples.
     if(billing?.version!=='metered-reserve-v1'||JSON.stringify(imageRateContract(p))!==JSON.stringify(contract))continue;
     if(billing.model!==p.model||billing.size!==p.size||billing.quality!==p.quality||billing.complexity!==p.complexity)continue;
     if(request.payload?.model!==p.model||request.payload?.size!==p.size||request.payload?.quality!==p.quality)continue;
     if(request.payload.complexity!==undefined&&request.payload.complexity!==p.complexity)continue;
     const actual=imageUsageCost(p,JSON.parse(row.usage_json),billing),recorded=Number(row.estimated_job?row.corrected_actual:row.actual_micros);
     if(actual!==recorded||samples.some(s=>s.receiptSha256===row.response_sha256))continue;
     samples.push({jobId:row.id,receiptSha256:row.response_sha256,size,actualMicros:actual,settledAtMs:Number(row.applied_at_ms??row.completed_at_ms),legacyComplexityOmitted:request.payload.complexity===undefined,corrected:!!row.estimated_job});
     if(++counts[size]===30)break;
    }catch{/* Malformed/unverifiable history is not a billing sample. */}
   }
   if(rows.results.length<100)break;offset+=100;
  }
 }
 const own=samples.filter(s=>s.size===pricing.size),ownMax=own.length?Math.max(...own.map(s=>s.actualMicros)):null,crossMax=samples.length?Math.max(...samples.map(s=>s.actualMicros)):null;
 const rule=own.length>=5?'own-max':samples.length?'small-sample-cross-max':'approved-fallback';
 const selected=rule==='own-max'?ownMax!:crossMax??(pricing.quality==='medium'?300000:60000);
 return {policy:IMAGE_ESTIMATION_POLICY,estimated:true,source:samples.length?'verified-receipts-max-30-v2':'approved-image-fallback-20261114',frozenAtMs:nowMs,windowStartMs:nowMs-WINDOW_MS,maxSamplesPerSize:30,minimumOwnSamples:5,model:pricing.model,size:pricing.size,quality:pricing.quality,rateContract:contract,sampleCounts:counts,ownMaxMicros:ownMax,crossMaxMicros:crossMax,selectedMicros:selected,reservedMicros,estimatedMicros:Math.min(reservedMicros,selected),rule,samples};
}
