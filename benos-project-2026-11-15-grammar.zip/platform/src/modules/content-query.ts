import type { Env } from '../env';
import { assert,AppError } from '../lib/errors';
import { base64url,unbase64url } from '../lib/crypto';
export type ContentQuery={kind?:string;state?:string;q?:string;sort?:string;categoryId?:string;tagId?:string;cursor?:string;limit?:number};
export async function queryContent<T>(env:Env,options:ContentQuery={},published=false){
 const q=(options.q||'').trim(),kind=options.kind||'',state=published?'published':options.state||'any',category=options.categoryId||'',tag=options.tagId||'';
 const sort=options.sort||(published?['faq','navigation','banner','category','tag'].includes(kind)?'position_asc':'published_desc':'updated_desc');
 assert(q.length<=160&&['','page','post','faq','navigation','banner','category','tag'].includes(kind)&&['any','draft','published','unpublished','trashed'].includes(state),'VALIDATION','内容筛选无效');
 assert(!category||/^cnt_[a-f0-9]{32}$/.test(category),'VALIDATION','分类筛选无效');assert(!tag||/^cnt_[a-f0-9]{32}$/.test(tag),'VALIDATION','标签筛选无效');
 const snapshot=published?'published_json':'draft_json',keys:Record<string,string>={updated_desc:'updated_at',created_desc:'created_at',published_desc:"COALESCE(published_at,'')",title_asc:`lower(json_extract(${snapshot},'$.title'))`,position_asc:`CAST(COALESCE(json_extract(${snapshot},'$.position'),0) AS INTEGER)`};
 assert(Object.hasOwn(keys,sort),'VALIDATION','排序方式无效');const key=keys[sort],asc=sort.endsWith('_asc'),dir=asc?'ASC':'DESC',cmp=asc?'>':'<',signature=JSON.stringify([published,kind,state,q,sort,category,tag]);
 let after:{key:string|number;id:string;signature:string}|null=null;
 if(options.cursor){try{after=JSON.parse(new TextDecoder().decode(unbase64url(options.cursor)));}catch{throw new AppError('VALIDATION','分页标识无效');}assert(after&&['string','number'].includes(typeof after.key)&&typeof after.id==='string'&&/^cnt_[a-f0-9]{32}$/.test(after.id)&&after.signature===signature,'VALIDATION','分页标识与筛选不一致');}
 const limit=Math.min(100,Math.max(1,Math.floor(options.limit??(published?24:100))));
 const rows=await env.DB.prepare(`SELECT *,${key} AS sort_key FROM content_entries WHERE (?='' OR COALESCE(kind_override,kind)=?) AND (?='any' OR state=?) ${published?'AND published_json IS NOT NULL':''}
 AND instr(lower(COALESCE(json_extract(${snapshot},'$.title'),'')||' '||COALESCE(json_extract(${snapshot},'$.slug'),'')||' '||COALESCE(json_extract(${snapshot},'$.body'),'')),lower(?))>0
 AND (?='' OR json_extract(${snapshot},'$.categoryId')=?) AND (?='' OR EXISTS(SELECT 1 FROM json_each(${snapshot},'$.tagIds') t WHERE t.value=?))
 AND (? IS NULL OR ${key}${cmp}? OR (${key}=? AND id${cmp}?)) ORDER BY ${key} ${dir},id ${dir} LIMIT ?`).bind(kind,kind,state,state,q,category,category,tag,tag,after?.key??null,after?.key??null,after?.key??null,after?.id??null,limit+1).all<T&{sort_key:string|number;id:string}>();
 const items=rows.results.slice(0,limit),last=items.at(-1);return {items,nextCursor:rows.results.length>limit&&last?base64url(new TextEncoder().encode(JSON.stringify({key:last.sort_key,id:last.id,signature}))):null};
}
