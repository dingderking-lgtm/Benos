import catalog from './design-style-catalog.json';
import { explicitWebsiteIntent } from './website-intent';

export type DesignPrimitive = 'split' | 'stack' | 'grid' | 'feature-list' | 'steps' | 'comparison' | 'gallery' | 'quote' | 'faq' | 'cta' | 'metrics' | 'toc' | 'hero-cover';
export interface DesignStyleTokens {
  background: string; surface: string; ink: string; muted: string; accent: string; border: string;
  radius: number; headingFont: string; bodyFont: string; container: number;
}
export interface DesignStyle {
  id: string; name: string; desc: string; summary: string; brief: string;
  scope: 'customer-website'; bestFor: string[]; colors: string[];
  preview: { bg: string; surface: string; ink: string; accent: string; radius: number; layout: string; serif?: boolean };
  layout: { hero: string; sections: string[]; mobile: string; sourceIds: string[] };
  typography: { heading: string; body: string; scale: number[]; unit: string; sourceIds: string[] };
  density: { level: string; sectionGap: number; rule: string; sourceIds: string[] };
  imagery: string[]; interaction: string[]; accessibility: string[]; antiPatterns: string[];
  principles: { rule: string; sourceIds: string[] }[];
  tokens: DesignStyleTokens; primitives: DesignPrimitive[]; sourceIds: string[];
}

// One serializable source for browser cards, workflow selection and deterministic foundation CSS.
export const DESIGN_STYLE_CATALOG = catalog as Omit<typeof catalog, 'styles'> & { styles: DesignStyle[] };
export const DESIGN_STYLES: readonly DesignStyle[] = DESIGN_STYLE_CATALOG.styles;
export function getDesignStyle(id: string | null | undefined): DesignStyle | undefined {
  return DESIGN_STYLES.find(style => style.id === id);
}
export function findDesignStyle(value: string | null | undefined): DesignStyle | undefined {
  const normalized = (value || '').replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
  if (!normalized) return undefined;
  // Persisted requests contain either an ID, an old name, or a name-prefixed brief.
  // Do not infer a style from an arbitrary substring in the user's custom direction.
  return getDesignStyle(normalized) || DESIGN_STYLES.find(style =>
    normalized === style.name || normalized.startsWith(`${style.name}；`) ||
    normalized.startsWith(`${style.name};`) || normalized.startsWith(`${style.name}，`) ||
    normalized.startsWith(`${style.name}：`)
  );
}

/** Offer compatible creative starting points, not a prescribed page structure.
 * Call only when the user has not selected a direction. The workflow samples
 * once and persists the selected profile; this helper never spends AI credits. */
export function suggestDesignStyles(brief: string): readonly DesignStyle[] {
  // Content responsibility and visual expression are separate. In particular,
  // manufacturing must not collapse to blue/grey corporate directions. These
  // are cross-industry starting points, not assertions about a customer's brand.
  const industryStyles = ['industrial', 'modern', 'editorial', 'bold', 'expressive', 'warm'];
  const hospitalityStyles = ['warm', 'editorial', 'fresh', 'luxury', 'bold', 'modern'];
  const explicit = explicitWebsiteIntent(brief);
  if (explicit && explicit !== 'other') {
    const ids = explicit === 'photography' ? ['portfolio', 'editorial', 'bold', 'luxury']
      : explicit === 'cafe' ? hospitalityStyles
        : industryStyles;
    return ids.map(id => getDesignStyle(id)!);
  }
  const normalized = brief.normalize('NFKC').toLowerCase()
    .replace(/(?:不要|不需要|不做|无需)[^，,。；;\n]{0,60}/g, ' ')
    .replace(/\b(?:not|no|without)\s+(?:an?\s+)?(?:shop|store|e-commerce|ecommerce|documentation|portfolio|report)\b/g, ' ');
  // A secondary feature is not the whole site's purpose: "企业官网，包括帮助中心"
  // should not unexpectedly become a documentation-only site.
  const primary = normalized.split(/(?:[，,；;]\s*(?:包含|包括|附带|加上|带有)|(?:并|再|顺便)(?:加上|提供|添加)|\bwith\s+(?:an?\s+)?(?:help cent(?:er|re)|knowledge base|blog|documentation)\b)/)[0];
  let ids: readonly string[] = ['modern', 'trust', 'editorial', 'bold'];
  if (/知识库|文档站|文档中心|开发者文档|帮助中心|使用手册|(?:文档|教程|指南)(?:网站|站点|门户)|\b(?:documentation|knowledge base|help cent(?:er|re)|user guides?|developer docs?|docs (?:site|portal))\b/.test(primary)) {
    ids = ['documentation', 'civic', 'editorial'];
  } else if (/报告(?:网站|站点|专题|发布|展示)|(?:研究|行业|年度|市场|调研|数据分析|可持续发展)报告|(?:数据|统计|研究)(?:可视化|故事|简报)|\b(?:annual|research|industry|market|sustainability|data) reports?\b|\b(?:data stor(?:y|ies)|public reports?|research publication|statistics website)\b/.test(primary)) {
    ids = ['data', 'editorial', 'trust'];
  } else if (/作品集|作品展示|作品网站|项目展陈|摄影(?:作品|网站)|\b(?:portfolio|photography (?:site|website)|project showcase)\b/.test(primary)) {
    ids = ['portfolio', 'editorial', 'bold', 'luxury'];
  } else if (/商城|网上商店|电商|在线商店|商品目录|产品目录|(?:在线|网上)(?:购买|销售)|\b(?:e-?commerce|online (?:shop|store)|product catalog(?:ue)?|storefront)\b/.test(primary)) {
    ids = ['commerce', 'modern', 'luxury', 'fresh'];
  } else if (/机械|设备制造|工业|制造业|工厂|生产线|塑料再生|\b(?:industrial|manufactur(?:er|ing)|machinery|factory|production line)\b/.test(primary)) {
    ids = industryStyles;
  } else if (/餐饮|餐厅|咖啡|烘焙|酒店|民宿|茶馆|食品品牌|\b(?:restaurant|cafe|café|coffee|bakery|hotel|hospitality|food brand)\b/.test(primary)) {
    ids = hospitalityStyles;
  } else if (/公共服务|办事指南|社区服务|便民服务|公益服务|\b(?:public service|community service|civic service|service guide)\b/.test(primary)) {
    ids = ['civic', 'trust', 'modern'];
  } else if (/软件|科技|人工智能|技术服务|\b(?:saas|software|technology|developer tool|ai product)\b/.test(primary)) {
    ids = ['tech', 'modern', 'editorial', 'bold', 'warm', 'expressive'];
  }
  return ids.map(id => getDesignStyle(id)!);
}
