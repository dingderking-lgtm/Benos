// Benos authoring guidance, informed by Damir Sokolovsky's Unslop (CC BY 4.0).
// https://github.com/heydamir/unslop
// The platform compiles the foundation; this short contract governs actual site content.
export const siteDesignGuidance = `【设计系统】foundation是可重组的配色、字阶与响应式原语，global_css只写项目差异。用户品牌、参考图和范围优先；局部修改不重置全站，旧站沿用原系统。制作客户网站，除非用户要求，不做平台介绍或后台壳。
【整页主线】围绕访客目标确定具体视觉主题，串联首屏、实例、图片与行动。图像解释业务对象、过程或结果，不用无含义光球、层片或团队照代替产品说明；概念产品可用带标签的实例/HTML图解，不伪装可操作软件。
【色阶与衔接】主背景与邻近色阶建立层次，强调色服务焦点。强反色只作有意义的转折，用对齐、图像或同调过渡承接，避免整屏深浅硬切或全页平铺。按需用bnf-tone/bridge，不每区加渐变。
【页面节奏】自由组合主视觉、实例、过程、对照与短说明，不固定页序。核心章节改变尺度和阅读路径，避免连续“标题+三列表”；可用bnf-chapter/workbench，不机械全用。内容少就合并收紧，不用巨大空区或装饰凑篇幅。
【可读性与响应式】正文16–18px、辅助字至少13px、行高1.6–1.8、对比≥4.5:1；中文不机械负字距。沿用基础容器、44px操作与focus，仅本机字体。长标题自然换行，窄屏HTML图解除去aspect-ratio与固定min-height组合，不用overflow-x:hidden遮内容；保留阅读和键盘顺序。
【图片尺寸规范】先定用途、图框和文字安全区，真实素材优先；统一色调/光线/镜头，各图主体或视角不同，不跨横幅竖卡强裁同图。普通内框保留aspect-ratio/overflow:hidden，img写真实width/height/alt及返回objectFit/objectPosition；完整新产品complete+adapt，已有contain保持。普通首屏通常≤min(72vh,640px)，其他单图≤560px。具hero-cover能力的全幅封面桌面约min(88vh,760px)，框外实底文字面；手机约56vh图上文字下，不套内框限宽。完整设备不能强裁；窄屏不拉伸，加载前保留框高。
【真实内容】只用用户提供或行业通用事实，不编数字、客户、资质、案例、参数。联系资料缺失可简标“待补充”。概念/非实拍等必要说明贴近对应内容或合并页脚，不独占大区或反复解释。主行动须通向真实目标。`;

/** Applied only while creating the db-3 frozen contract; legacy text is intact. */
export function blueprintDesignGuidance(base:string):string{return base
 .replace('内容少就合并收紧，不用巨大空区或装饰凑篇幅。','默认按蓝图7–9个有不同信息的内容章节；简单/明确范围优先，缺事实无法有用替代才跳过并列明原因，不用空白撑高度。')
 .replace('辅助字至少13px','主内容及辅助字至少14px（版权/法律例外）')
 .replace('联系资料缺失可简标“待补充”。概念/非实拍等必要说明贴近对应内容或合并页脚，不独占大区或反复解释。','缺资料写任务结果，不在客户页堆“待补充”；必要图像来源页脚合并一次。概念标签不能掩盖虚构作品。')
 +'\n【文字预算】标题/导语/行动同组，首屏一实心主按钮与至多一次动作优先同排，窄屏自然换行。每章辅助项≤1.5，导语≤2句，条目不挂第三层注释。原生图解必须有标签与关系，灰块骨架不是成品。';}
