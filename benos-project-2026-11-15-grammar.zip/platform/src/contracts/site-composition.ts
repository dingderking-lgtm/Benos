import { z } from 'zod';
import { pageCompositionSchema, sectionPatternInputSchema } from './section-patterns';

export const SITE_COMPOSITION_VERSION = 'site-compose-1' as const;
/** A nonempty subset: pages outside this tool remain independently authored. */
export const siteCompositionSchema = z.object({
  version: z.literal(SITE_COMPOSITION_VERSION),
  pages: z.array(z.object({
    pageKey: z.string().min(1).max(100),
    templateId: z.number().int().positive(),
    composition: pageCompositionSchema,
  }).strict()).min(1).max(20),
  footer: z.object({ templateId: z.number().int().positive(), section: sectionPatternInputSchema }).strict().nullable(),
}).strict();
export type SiteCompositionInput = z.input<typeof siteCompositionSchema>;
export type ResolvedSiteComposition = z.output<typeof siteCompositionSchema>;

/** Provider strict tools require every property; absent authoring options use
 * null on the wire. Defaults and optional fields are restored before parsing. */
function strictSchema(value: any): any {
  if (Array.isArray(value)) return value.map(strictSchema);
  if (!value || typeof value !== 'object') return value;
  const result: any = Object.fromEntries(Object.entries(value).filter(([key]) => key !== '$schema' && key !== 'default').map(([key, child]) => [key, strictSchema(child)]));
  if (result.type === 'object' && result.properties) {
    const required = new Set<string>(value.required || []);
    for (const key of Object.keys(result.properties)) if (!required.has(key)) result.properties[key] = { anyOf: [result.properties[key], { type: 'null' }] };
    result.required = Object.keys(result.properties);
    result.additionalProperties = false;
  }
  return result;
}
const inputJsonSchema = z.toJSONSchema(siteCompositionSchema, { io: 'input' });
export const siteCompositionJsonSchema = strictSchema(inputJsonSchema);
export function parseSiteComposition(raw: unknown): ResolvedSiteComposition {
  function options(value: any, schema: any): any {
    if (Array.isArray(value)) return value.map(child => options(child, schema?.items));
    if (!value || typeof value !== 'object') return value;
    const object = schema?.type === 'object' ? schema : schema?.anyOf?.find((candidate: any) => candidate.type === 'object');
    return Object.fromEntries(Object.entries(value).filter(([key, child]) => child !== null || !object?.properties?.[key] || object.required?.includes(key)).map(([key, child]) => [key, options(child, object?.properties?.[key])]));
  }
  return siteCompositionSchema.parse(options(raw, inputJsonSchema));
}
