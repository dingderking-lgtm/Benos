import { z } from 'zod';
import { parseFragment } from 'parse5';
import type { DesignBrief,PageBlueprint } from './design-brief';
import type { LayoutPlan } from './layout-plan';

export const SITE_PLAN_VERSION='site-plan-1' as const;
const keySchema=z.string().regex(/^[a-z][a-z0-9-]{0,63}$/);
const roleSchema=z.object({id:keySchema,purpose:z.string().min(1).max(180),requires:z.enum(['facts','owned-assets']).optional(),fallback:z.string().max(180).optional()}).strict();
const visualSchema=z.object({need:z.enum(['required','optional','none']),purpose:z.string().min(1).max(240),minimum:z.number().int().min(0).max(8),preferred:z.number().int().min(0).max(8),max:z.number().int().min(0).max(8),allowReuse:z.boolean(),evidence:z.enum(['concept-allowed','owned-only']),exception:z.enum(['user-no-images','budget','no-owned-evidence','not-needed']).optional()}).strict().refine(v=>v.minimum<=v.preferred&&v.preferred<=v.max,'Invalid visual range');
export const sitePlanSchema=z.object({version:z.literal(SITE_PLAN_VERSION),entryPageKey:keySchema,source:z.enum(['explicit','default']),pages:z.array(z.object({key:keySchema,title:z.string().min(1).max(80),purpose:z.string().min(1).max(180),source:z.enum(['explicit','default']),roles:z.array(roleSchema).min(1).max(12),sectionRange:z.tuple([z.number().int().min(1).max(12),z.number().int().min(1).max(12)]),visual:visualSchema}).strict()).min(1).max(12),imageBudget:z.object({max:z.number().int().min(0).max(8),minimum:z.number().int().min(0).max(8),preferred:z.number().int().min(0).max(8),generation:z.enum(['disabled','fill-gaps']),availableImageCount:z.number().int().min(0).max(10000).nullable()}).strict(),exceptions:z.array(z.string().max(240)).max(24),missingFactsPolicy:z.string().max(500)}).strict().superRefine((plan,ctx)=>{if(new Set(plan.pages.map(p=>p.key)).size!==plan.pages.length||!plan.pages.some(p=>p.key===plan.entryPageKey))ctx.addIssue({code:'custom',message:'Pages need unique keys and an existing entry'});if(plan.imageBudget.minimum>plan.imageBudget.preferred||plan.imageBudget.preferred>plan.imageBudget.max)ctx.addIssue({code:'custom',message:'Invalid site image budget'});});
export type SitePlan=z.infer<typeof sitePlanSchema>;
export type SitePlanPage=SitePlan['pages'][number];
export type SitePlanBinding={plannedKey:string;pageKey:string;templateId:number};
export type SitePlanIssue={code:string;severity:'error'|'warning';message:string;plannedKey?:string;pageKey?:string};
export type SitePlanValidation={valid:boolean;issues:SitePlanIssue[];bindings:SitePlanBinding[]};
export type SitePlanInput={request:string;brief:DesignBrief|null|undefined;layoutPlan?:LayoutPlan|null;availableImageCount?:number;maxImages?:number};

const aliases:Record<string,readonly string[]>={
 home:['首页','主页','home','homepage','index'],about:['关于我们','关于','公司介绍','企业介绍','品牌故事','about','about-us','about us','company'],
 products:['产品中心','产品目录','产品与服务','产品和服务','产品','商品目录','商品','products & services','product & services','products and services','product and services','products','product catalog','catalog','catalogue'],
 'product-detail':['产品详情','商品详情','产品单页','product detail','product-detail','product details'],
 services:['服务项目','服务','services','service'],solutions:['解决方案','solutions','solution'],
 portfolio:['作品集','作品展示','作品','portfolio','work','works'],gallery:['图片画廊','画廊','图库','gallery'],
 cases:['真实案例','客户案例','案例','case studies','case-studies','cases'],news:['新闻中心','新闻动态','新闻','资讯','博客','news','blog','insights'],
 article:['文章详情','新闻详情','文章单页','article','post'],contact:['联系我们','联系','联系方式','contact','contact-us','contact us'],
 faq:['常见问题','问答','faq','faqs'],team:['团队介绍','团队','team'],careers:['加入我们','招聘','careers','jobs'],pricing:['价格','定价','pricing'],
};
// New request synonyms do not reinterpret already-frozen page bindings.
const requestAliases:Record<string,readonly string[]>={...aliases,about:[...aliases.about,'品牌介绍'],products:[...aliases.products,'车型展示','车型目录','车辆展示','车型','vehicle showcase','vehicle models','car models']};
const titles:Record<string,string>={home:'首页',about:'关于我们',products:'产品中心','product-detail':'产品详情',services:'服务',solutions:'解决方案',portfolio:'作品集',gallery:'画廊',cases:'案例',news:'新闻',article:'文章',contact:'联系',faq:'常见问题',team:'团队',careers:'招聘',pricing:'定价'};
const normalized=(text:string)=>text.normalize('NFKC').trim().toLowerCase().replace(/^[/\s]+|[/\s]+$/g,'').replace(/\.(?:html?|php)$/,'');
function knownKey(text:string,request=true){const names=request?requestAliases:aliases,raw=normalized(text),exact=Object.keys(names).find(key=>names[key].some(alias=>normalized(alias)===raw));if(exact)return exact;const value=raw.replace(/(?:页面|网页|页)$/,'').trim();return Object.keys(names).find(key=>names[key].some(alias=>normalized(alias)===value));}
function stableCustomKey(title:string){const latin=normalized(title).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');if(/^[a-z]/.test(latin)&&latin.length<=56)return'custom-'+latin;let n=2166136261;for(const c of title.normalize('NFKC').trim())n=Math.imul(n^c.charCodeAt(0),16777619);return'custom-'+(n>>>0).toString(16).padStart(8,'0');}
const cleanPageTitle=(value:string)=>{const title=value.replace(/^\s*(?:\d+[.)、]|[-*•])\s*/,'').replace(/^[「『“"']|[」』”"']$/g,'').replace(/\s*[(（][^()（）]*[)）]\s*$/,'').replace(/\s+(?:page|pages)$/i,'').trim();return Object.values(requestAliases).some(names=>names.some(name=>normalized(name)===normalized(title)))?title:title.replace(/(?:页面|网页|页)$/,'').trim();};
// Preserve a named combined page before treating conjunctions as separators.
const pageListParts=(value:string)=>value.split(/[、,，/|]+/).flatMap(part=>knownKey(cleanPageTitle(part))?[part]:part.split(/\s+(?:and|&)\s+|(?:以及|和|与)/i));
function requestedPages(request:string):{pages:{key:string;title:string}[];exceptions:string[];requestedCount:number|null} {
 const text=request.normalize('NFKC'),found:{key:string;title:string}[]=[],exceptions:string[]=[];
 const add=(raw:string,custom=false)=>{const title=cleanPageTitle(raw);if(!title||title.length>80||/^(?:不要|不做|不需要|无需|不包括|不包含|不含|排除|风格|配色|采用|使用|要求|需要现代|no\b|without\b|exclude\b)/i.test(title))return;const key=knownKey(title)||(custom?stableCustomKey(title):null);if(key&&!found.some(p=>p.key===key))found.push({key,title});};
 // A declared page list may name custom pages. Clauses describing business
 // objects are not page declarations and never create extra pages by themselves.
 const lists=[...text.matchAll(/(?:页面|网页|页数|栏目|导航|pages?|site\s*map)\s*(?:包括|包含|分别(?:是|为)?|设为|设置为|有|为|including|includes?|are|:|：)\s*([^。；;\n]+)/gi)].filter(list=>!/(?:首页|主页|首屏|\bhome|\blanding)\s*$/i.test(text.slice(0,list.index)));
 for(const list of lists)for(const part of pageListParts(list[1].replace(/^[：:]\s*/,'')))add(part,true);
 for(const clause of text.split(/[。；;\n]/)){
  const positive=clause.replace(/(?:不要|不做|不需要|无需|不包括|不包含|不含|排除)[^，,、]{0,60}/g,' ').replace(/\b(?:no|without|exclude|excluding)\s+[^,;]+/gi,' ');
  if(/首页|主页|\bhome page\b|\bhomepage\b/i.test(positive))add(/首页|主页/.test(positive)?'首页':'Home');
  const sectionList=/(?:首页|主页|首屏|\bhome(?:page| page)?\b).{0,8}(?:包含|包括|展示|介绍|include|including|with)/i.test(positive)
   || /(?:单页(?:网站|官网|站点)?|\b(?:single|one)[- ]page\b)/i.test(positive)
   || /(?:包含|包括|include|including).{0,120}(?:等区块|等板块|这些区块|这些板块|\bsections?\b|\bblocks?\b)/i.test(positive);
  const listLike=!sectionList&&(/(?:首页|主页|\bhome\b)/i.test(positive)&&/[、,，/|]/.test(positive)||/(?:包含|包括|需要|设有|include|including)/i.test(positive)&&/[、,，/|]/.test(positive));
  if(listLike)for(const part of pageListParts(positive)){const tail=part.replace(/^.*?(?:包含|包括|需要|设有|including|include)\s*[:：]?/i,'').trim();add(tail);}
  for(const [key,names]of Object.entries(requestAliases))for(const alias of names){const escaped=alias.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),match=new RegExp('(?:^|[^a-z])('+escaped+')(?:页面|网页|页|\\s+pages?)(?:$|[^a-z])','i').exec(positive);if(match)add(key==='home'?'首页':alias);}
 }
 // Standalone “only X” is an explicit page scope, not a request for a new home.
 if(!found.length){const only=/(?:只做|只要|仅做|仅需|only|just)\s*(?:一个|一张|a |the )?([^，。；,;\n]{1,60})/i.exec(text);if(only)add(only[1],/(?:页面|网页|页|\bpage)\s*$/i.test(only[1]));}
 if(found.length>12)throw new Error('SITE_PLAN_PAGE_LIMIT');
 const inferredHome=found.length&&!found.some(p=>p.key==='home')&&!/(?:只做|仅做|只要|仅需)|\b(?:only|just)\b/i.test(text)&&!lists.length;
 if(inferredHome)found.unshift({key:'home',title:titles.home});
 const count=/(?:做|制作|设计|包含|共|共计|总共)?\s*(1[0-9]|[1-9一二两三四五六七八九十])\s*(?:个|张)?(?:页面|网页|页)|\b(\d{1,2})[- ]pages?\b/i.exec(text);let requestedCount:number|null=null;
 if(count){const value=count[1]||count[2];requestedCount=Number(value)||({一:1,二:2,两:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9,十:10} as Record<string,number>)[value];if(requestedCount>12)throw new Error('SITE_PLAN_PAGE_LIMIT');if(inferredHome&&found.length-1===requestedCount)found.shift();if(found.length>requestedCount)exceptions.push('明确列出的页面多于用户同时给出的数量；保留明确页面，不静默删除需求。');}
 return{pages:found,exceptions,requestedCount};
}
type Role=PageBlueprint['roles'][number];
const role=(id:string,purpose:string,requires?:Role['requires'],fallback?:string):Role=>({id,purpose,...(requires?{requires}:{}),...(fallback?{fallback}:{})});
function innerResponsibilities(key:string,title:string):{purpose:string;roles:Role[];range:[number,number]} {
 const action=role('action','真实可执行的下一步或内容入口');
 const values:Record<string,[string,Role[],[number,number]]>={
  about:['说明是谁、做什么及如何工作',[role('identity','原文中的身份与业务范围'),role('approach','工作方法与原则'),role('evidence','已确认的公司事实','facts','用通用工作过程解释，不造历史数字、团队与客户'),action],[3,5]],
  products:['帮助访客理解产品与选择条件',[role('orientation','产品对象与用途'),role('catalog','已知产品或品类差异','facts','用选择维度解释，不编型号价格参数'),role('selection','使用条件与询价所需资料'),action],[3,5]],
  'product-detail':['解释明确产品的用途、细节与咨询入口',[role('overview','已提供产品信息','facts','只说明已知类别与适用问题'),role('details','结构、用法与限制','facts','通用选择问题，不造性能数字'),role('use','使用环境与准备'),action],[3,5]],
  services:['解释服务范围与合作方式',[role('scope','已知服务范围'),role('method','服务过程与交付物形态'),role('fit','适用需求及准备'),action],[3,5]],
  solutions:['按具体需求解释解决过程',[role('problem','场景与问题'),role('approach','输入、方法与结果关系'),role('conditions','适用条件与边界'),action],[3,5]],
  portfolio:['浏览有证据的真实作品',[role('orientation','作品方向与观看线索'),role('work','已确认作品及说明','owned-assets','仅保留方向解释，不造作品名或客户项目'),role('method','创作方法'),action],[2,4]],
  gallery:['按主题浏览可用图片',[role('orientation','图片主题与观看方式'),role('gallery','已确认图片序列','owned-assets','有内容的主题介绍，不造作者作品'),action],[2,4]],
  cases:['解释经确认的实际案例',[role('context','案例背景','facts','改为通用问题场景，不归属公司案例'),role('evidence','实际过程与证据','owned-assets','保留方法说明，不造客户成果'),action],[2,4]],
  news:['提供真实文章索引与阅读入口',[role('orientation','内容主题与分类'),role('articles','已提供的文章与摘要','facts','展示主题导读，不编新闻事件、日期或不可达链接')],[1,3]],
  article:['完成一篇真实有用的主题阅读',[role('introduction','文章主题与范围'),role('body','有依据的正文'),role('related','有效的延伸阅读入口')],[2,4]],
  contact:['提供真实联系方式与沟通准备',[role('contact','已提供的联系资料与真实表单','facts','使用已有内容入口，不编电话、地址或提交功能'),role('preparation','联系前可准备的需求信息')],[1,2]],
  faq:['集中回答有依据的常见问题',[role('questions','通用问题与实际能力边界'),action],[1,3]],
  team:['介绍有证据的团队',[role('people','已确认的人物资料','facts','介绍合作方式，不编员工姓名履历'),role('collaboration','工作方式'),action],[2,3]],
  careers:['说明已确认职位或合作渠道',[role('openings','真实招聘职位','facts','说明合作方向，不造招聘承诺'),role('process','申请条件与真实入口')],[2,3]],
  pricing:['说明真实定价或询价依据',[role('terms','用户提供的价格与条件','facts','改为询价维度，不编金额'),role('selection','选择所需信息'),action],[2,3]],
 };
 const selected=values[key]||[`围绕“${title}”回答独立访客问题`,[role('orientation',`${title}的范围与目标`),role('content','用户指定内容的关键问题'),action],[2,4]];
 return{purpose:selected[0],roles:selected[1],range:selected[2]};
}

/** Deterministic local planning. No model call, authored business facts or new
 * constraints for a legacy task that has no saved sitePlan. */
export function createSitePlan(input:SitePlanInput):SitePlan|null {
 if(!input.brief?.pageBlueprint||input.brief.version!=='db-3')return null;
 const request=input.request.trim(),requested=requestedPages(request),explicit=requested.pages.length>0||requested.requestedCount!==null,raw=requested.pages.length?[...requested.pages]:[{key:'home',title:titles.home}],brief=input.brief;
 if(requested.requestedCount&&raw.length<requested.requestedCount){
  const kind=brief.inference.siteKind,first=kind==='portfolio-studio'?['portfolio','services']:kind==='local-hospitality'?['services','gallery']:kind==='professional-service'?['services','solutions']:['products','solutions'];
  for(const key of [...first,'about','contact','news','faq','services',...brief.pageBlueprint!.roles.map(r=>'custom-'+r.id)]){if(raw.length>=requested.requestedCount)break;if(!raw.some(p=>p.key===key))raw.push({key,title:titles[key]||brief.pageBlueprint!.roles.find(r=>'custom-'+r.id===key)!.purpose});}
  requested.exceptions.push('用户只指定部分页面名或页数；其余页面职责为设计推断，不代表已有产品、案例、团队或新闻事实。');
 }
 const exceptions=[...requested.exceptions],image=brief.imagePlan,available=Number.isSafeInteger(input.availableImageCount)&&input.availableImageCount!>=0?Math.min(10000,input.availableImageCount!):null;
 // The platform ceiling can lower, never widen, the user's frozen image
 // preference. This is a site visual-planning cap; owned assets still satisfy
 // the per-page minimum without becoming a new generation reservation.
 const limit=Math.max(0,Math.min(8,Number.isFinite(input.maxImages)?Math.floor(input.maxImages!):8,image?.targetRange[1]??8)),noImages=image?.mode==='none',generation=image?.generation??'fill-gaps';
 const max=noImages?0:generation==='disabled'&&available!==null?Math.min(limit,available):limit;
 const realOnly=/(?:只用|仅用|只能使用|必须使用)(?:真实|实拍|上传|已有)|\b(?:only (?:real|uploaded|existing) (?:images|photos)|real photos only)\b/i.test(request);
 const pages:SitePlanPage[]=raw.map(({key,title})=>{
  const inner=innerResponsibilities(key,title),home=key==='home',noVisual=['contact','faq','careers','pricing'].includes(key),owned=realOnly||['portfolio','gallery','cases'].includes(key),required=home||['products','product-detail','portfolio','gallery','cases','about','services','solutions','news'].includes(key);
  return{key,title,purpose:home?brief.visitorGoal:inner.purpose,source:explicit?'explicit':'default',roles:home?structuredClone(brief.pageBlueprint!.roles):inner.roles,sectionRange:home?[...brief.pageBlueprint!.targetSections]:inner.range,
   visual:{need:noImages||noVisual?'none':required?'required':'optional',purpose:noVisual?'文字与真实入口足够，不为页数配装饰图':home?image?.roles[0]?.purpose||'说明核心对象与用途':key==='products'||key==='product-detail'?'展示产品整体、用途或选择差异；概念图不能充当真实产品证据':owned?'展示经确认可公开的真实作品、案例或照片':'解释本页对象、过程或场景，不使用无关装饰图',minimum:0,preferred:0,max:noImages||noVisual?0:max,allowReuse:!owned,evidence:owned?'owned-only':'concept-allowed',...(noImages?{exception:'user-no-images' as const}:noVisual?{exception:'not-needed' as const}:{})}};
 });
 let remaining=max;
 for(const page of pages.filter(p=>p.visual.need==='required').sort((a,b)=>Number(b.key==='home')-Number(a.key==='home'))){if(page.visual.evidence==='owned-only'&&available===0){page.visual.need='optional';page.visual.exception='no-owned-evidence';exceptions.push(`${page.key}缺少已确认真实素材；不生成冒充作品/案例的图片，以真实内容退化并报告。`);continue;}if(remaining){page.visual.minimum=1;page.visual.preferred=1;remaining--;}else{page.visual.need='optional';page.visual.exception=generation==='disabled'&&available===0?'no-owned-evidence':'budget';exceptions.push(`${page.key}视觉未分配最低数量：受明确图片限制或可用素材约束；不得额外收费凑图。`);}}
 for(const page of pages.filter(p=>p.visual.need==='optional'&&!p.visual.exception)){if(remaining){page.visual.preferred=1;remaining--;}}
 const target=Math.min(max,image?.targetRange[0]??pages.filter(p=>p.visual.need!=='none').length),preferred=()=>pages.reduce((n,p)=>n+p.visual.preferred,0);
 while(remaining&&preferred()<target){const page=pages.find(p=>p.key==='home'&&p.visual.max>p.visual.preferred&&!p.visual.exception)||pages.find(p=>p.visual.max>p.visual.preferred&&!p.visual.exception);if(!page)break;page.visual.preferred++;remaining--;}
 if(noImages)exceptions.push('用户明确无图；全部页面采用文字或有标签关系的原生内容。');
 return sitePlanSchema.parse({version:SITE_PLAN_VERSION,entryPageKey:pages.find(p=>p.key==='home')?.key||pages[0].key,source:explicit?'explicit':'default',pages,imageBudget:{max,minimum:pages.reduce((n,p)=>n+p.visual.minimum,0),preferred:preferred(),generation,availableImageCount:available},exceptions,missingFactsPolicy:brief.missingFactsPolicy});
}

function sectionCount(html:string){if(html.length>500000)return null;const root=parseFragment(html),stack:{node:any;inside:boolean}[]=[{node:root,inside:false}];let count=0,visited=0;while(stack.length){const {node,inside}=stack.pop()!;if(++visited>16000)return null;const section=['section','article'].includes(node.tagName);if(section&&!inside)count++;if(['header','footer','nav','template','svg'].includes(node.tagName))continue;for(const child of node.childNodes||[])stack.push({node:child,inside:inside||section});}return count;}
export function validateSitePlanManifest(manifest:any,plan:SitePlan|null|undefined):SitePlanValidation {
 if(!plan)return{valid:true,issues:[],bindings:[]};const parsed=sitePlanSchema.safeParse(plan);if(!parsed.success)return{valid:false,bindings:[],issues:[{code:'SITE_PLAN_INVALID',severity:'error',message:'整站规划快照无效。'}]};
 const issues:SitePlanIssue[]=[],bindings:SitePlanBinding[]=[],pages=Array.isArray(manifest?.site?.pages)?manifest.site.pages:[],templates=Array.isArray(manifest?.templates)?manifest.templates:[];
 const error=(code:string,message:string,plannedKey?:string,pageKey?:string)=>issues.push({code,severity:'error',message,...(plannedKey?{plannedKey}:{}),...(pageKey?{pageKey}:{})});
 for(const page of pages){if(pages.filter((p:any)=>p.key===page.key).length!==1)error('SITE_PAGE_KEY_AMBIGUOUS','实际页面key重复，无法建立规划绑定。',undefined,page.key);if(pages.filter((p:any)=>p.template_id===page.template_id).length!==1)error('SITE_PAGE_TEMPLATE_SHARED','每个请求页面必须有独立且明确的正文模板。',undefined,page.key);}
 for(const planned of parsed.data.pages){const candidates=pages.filter((page:any)=>[String(page.key??''),String(page.slug??'')].some(value=>normalized(value)===planned.key||knownKey(value,false)===planned.key));
  if(!candidates.length){error('SITE_PLAN_PAGE_MISSING',`缺少请求页面：${planned.title}。`,planned.key);continue;}if(candidates.length!==1){error('SITE_PLAN_PAGE_AMBIGUOUS',`页面${planned.title}存在多个别名映射。`,planned.key);continue;}
  const page=candidates[0],matching=templates.filter((t:any)=>t.id===page.template_id),template=matching[0];
  if(matching.length!==1||!Number.isSafeInteger(page.template_id)||page.template_id<1||['header','footer'].includes(template?.type)||typeof template?.document?.html!=='string'){error('SITE_PLAN_TEMPLATE_INVALID',`页面${planned.title}的正文模板不存在或不唯一。`,planned.key,page.key);continue;}
  bindings.push({plannedKey:planned.key,pageKey:page.key,templateId:page.template_id});const count=sectionCount(template.document.html);
  if(count===null||count<planned.sectionRange[0])issues.push({code:'SITE_PLAN_DEPTH_ADVISORY',severity:'warning',plannedKey:planned.key,pageKey:page.key,message:count===null?'页面复杂，未完整统计区块；尚未核验内容职责。':`识别${count}个顶层内容区块，规划${planned.sectionRange[0]}–${planned.sectionRange[1]}；仅结构观察，需核对内容职责，不能凑空区。`});
 }
 if(new Set(bindings.map(b=>b.templateId)).size!==bindings.length||new Set(bindings.map(b=>b.pageKey)).size!==bindings.length)error('SITE_PLAN_BINDING_AMBIGUOUS','多个规划页面映射到了同一实际页面。');
 const entry=bindings.find(b=>b.plannedKey===parsed.data.entryPageKey);if(entry&&manifest.site.home!==entry.pageKey)error('SITE_PLAN_ENTRY_MISMATCH','网站入口必须对应规划中的入口页面。',entry.plannedKey,entry.pageKey);
 return{valid:!issues.some(i=>i.severity==='error'),issues,bindings};
}

export type SiteLayoutPlan=Omit<LayoutPlan,'version'>&{version:'lp-2';sitePlanVersion:'site-plan-1';parentCombinationHash:string};
/** Adds per-page intent without changing the already allocated home signature,
 * existing lp-1 snapshots or introducing any unapproved pattern references. */
export function expandLayoutPlan(layout:LayoutPlan,sitePlan:SitePlan):SiteLayoutPlan {
 const plan=sitePlanSchema.parse(sitePlan),home=layout.pages.find(p=>p.key==='home');
 return{...structuredClone(layout),version:'lp-2',sitePlanVersion:SITE_PLAN_VERSION,parentCombinationHash:layout.combinationHash,pages:plan.pages.map(page=>page.key==='home'&&home?structuredClone(home):{key:page.key,sections:page.roles.map((r,i)=>({id:r.id,role:r.id,composition:i===0?'page-introduction':r.id==='action'?'compact-action':page.visual.need!=='none'&&i===1?'detail-pair':'chapter',headingLayout:'stack-left',surface:'base' as const,factRefs:[],frameRefs:[],fallback:r.fallback||'按已知内容回答本页问题；缺事实不造业务证据'}))})};
}
