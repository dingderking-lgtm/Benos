import { parseFragment, type DefaultTreeAdapterMap } from 'parse5';

/** Enabled by the caller only for a new whole-site candidate. Frozen versions
 * and local/node edits never enter this materializer. No browser script needed. */
export const MOBILE_NAV_VERSION = 'bmn-1' as const;
export const MOBILE_NAV_MARKER = '/* benos-mobile-navigation:bmn-1 */';
export type MobileNavigationIssue = { code: string; templateId: number; message: string };
export type MobileNavigationReceipt = { templateId: number; action: 'created_disclosure' | 'normalized_disclosure'; menuId?: string };
type Element = DefaultTreeAdapterMap['element'];
type Node = DefaultTreeAdapterMap['node'];
type Template = { id: number; document: { html: string; css?: string; [key: string]: unknown }; [key: string]: unknown };
type Manifest = { site: { header_template_id?: number; theme?: { global_css?: string }; settings?: { site_language?: string }; home?: string; pages?: Array<{ key: string; seo?: { language?: string } }>; [key: string]: unknown }; templates: Template[]; [key: string]: unknown };
type Edit = { start: number; end: number; text: string };
const attr = (node: Element, name: string) => node.attrs.find(a => a.name === name && !a.namespace)?.value;
const classes = (node: Element) => (attr(node, 'class') || '').split(/\s+/).filter(Boolean);
const dynamic = (value: string) => /\{\{|\}\}|\{%|%\}/.test(value);
const escape = (value: string) => value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
function elements(root: Node): Element[] {
  const stack = [root], found: Element[] = [];
  while (stack.length) {
    const node = stack.pop()!;
    if (found.length > 10000) throw Error('header complexity');
    if ('tagName' in node) { found.push(node); if (node.tagName === 'template') continue; }
    if ('childNodes' in node) for (let i = node.childNodes.length - 1; i >= 0; i--) stack.push(node.childNodes[i]);
  }
  return found;
}
function inside(node: Element, parent: Element): boolean { for (let current: Node | null = node.parentNode; current; current = 'parentNode' in current ? current.parentNode : null) if (current === parent) return true; return false; }
function ancestor(node: Element, tag: string): Element | undefined { for (let current: Node | null = node.parentNode; current; current = 'parentNode' in current ? current.parentNode : null) if ('tagName' in current && current.tagName === tag) return current; }
function setAttribute(node: Element, name: string, value: string | null): Edit {
  const location = node.sourceCodeLocation?.attrs?.[name], start = node.sourceCodeLocation?.startTag;
  if (!start) throw Error('missing source location');
  return location ? { start: location.startOffset, end: location.endOffset, text: value === null ? '' : `${name}="${escape(value)}"` }
    : { start: start.endOffset - 1, end: start.endOffset - 1, text: value === null ? '' : ` ${name}="${escape(value)}"` };
}
function addClasses(node: Element, add: string[], remove: string[] = []): Edit { return setAttribute(node, 'class', [...new Set([...classes(node).filter(x => !remove.includes(x)), ...add])].join(' ')); }
function apply(html: string, edits: Edit[], offset = 0): string {
  for (const edit of edits.sort((a, b) => b.start - a.start || b.end - a.end)) html = html.slice(0, edit.start - offset) + edit.text + html.slice(edit.end - offset);
  return html;
}
function isNav(node: Element) { return node.tagName === 'nav' || attr(node, 'data-aacms') === 'site-navigation'; }
function plainNavigation(nav: Element) {
  const allowed = new Set(['nav', 'div', 'a', 'ul', 'ol', 'li', 'span', 'strong', 'em', 'b', 'i', 'small', 'svg', 'path', 'g', 'use', 'title']);
  return elements(nav).every(node => allowed.has(node.tagName)
    && !node.attrs.some(a => /^on/i.test(a.name) || dynamic(a.value) || /^data-menu-(?:toggle|panel|subtoggle)$/.test(a.name) || (node !== nav && /^data-(?:aacms|form|template)(?:-|$)/.test(a.name)))
    && (node !== nav || !node.attrs.some(a => /^data-(?:form|template)(?:-|$)/.test(a.name)) && (!attr(node, 'data-aacms') || attr(node, 'data-aacms') === 'site-navigation'))
    && !classes(node).some(value => /^(?:bnf-(?:button|chrome-action)|cta)$/i.test(value))
    && (node.tagName !== 'a' || attr(node, 'download') === undefined));
}
function navSource(nav: Element) {
  const binding = attr(nav, 'data-aacms');
  const nodes = elements(nav), ids = nodes.map(node => attr(node, 'id')).filter((id): id is string => !!id);
  const links = nodes.filter(node => node.tagName === 'a').map(node => {
    const href = attr(node, 'href') || '', local = href.startsWith('#') ? ids.indexOf(href.slice(1)) : -1;
    return [local < 0 ? href : `internal-navigation-target:${local}`, textContent(node).replace(/\s+/g, ' ').trim()];
  });
  return JSON.stringify([binding === 'site-navigation' ? [binding, attr(nav, 'data-aacms-menu') || ''] : null, links]);
}
function textContent(node: Node): string { return 'value' in node ? node.value : 'childNodes' in node ? node.childNodes.map(textContent).join('') : ''; }
function conflictCss(css: string, nodes: Element[]) {
  // We do not pretend to compute arbitrary CSS. Explicit high-priority overrides
  // of the actual menu contract require correction rather than a hidden duplicate.
  const names = new Set(nodes.flatMap(node => [node.tagName, ...classes(node).map(x => '.' + x), ...(attr(node, 'id') ? ['#' + attr(node, 'id')] : [])]));
  const customCss = css.replaceAll(designMobileNavigationCss(), '');
  for (const match of customCss.matchAll(/([^{}]+)\{([^{}]*)\}/g)) {
    if (!/(?:display|visibility|opacity|content-visibility|height|max-height)\s*:[^;{}]*!important/i.test(match[2])) continue;
    const selector = match[1].replace(/\/\*[\s\S]*?\*\//g, '').trim();
    if (selector === '*' || [...names].some(name => selector.includes(name))) return true;
  }
  return nodes.some(node => /(?:display|visibility|opacity|height|max-height)\s*:[^;]*!important/i.test(attr(node, 'style') || '') || attr(node, 'hidden') !== undefined || attr(node, 'inert') !== undefined);
}
function menuLabel(manifest: Manifest, header: Element, nav: Element, explicit?: string): string {
  if (explicit && explicit.trim().length <= 60 && !dynamic(explicit)) return explicit.trim();
  const declared = attr(header, 'lang') || manifest.site.settings?.site_language || manifest.site.pages?.find(page => page.key === manifest.site.home)?.seo?.language;
  if (declared) {
    const lang = declared.toLowerCase();
    if (/^zh(?:-|$)/.test(lang)) return /(?:tw|hk|hant)/.test(lang) ? '選單' : '菜单';
    if (/^ja(?:-|$)/.test(lang)) return 'メニュー';
    if (/^ko(?:-|$)/.test(lang)) return '메뉴';
    if (/^de(?:-|$)/.test(lang)) return 'Menü';
    if (/^es(?:-|$)/.test(lang)) return 'Menú';
    return 'Menu';
  }
  const context = attr(nav, 'aria-label') || textContent(nav);
  return /[\u3400-\u9fff]/.test(context) ? '菜单' : 'Menu';
}
function inspect(input: unknown) {
  const manifest = input as Manifest, id = manifest?.site?.header_template_id;
  if (id === undefined) return null;
  if (!Array.isArray(manifest.templates) || manifest.templates.length > 200) throw Error('templates');
  const candidates = manifest.templates.filter(template => template.id === id);
  if (candidates.length !== 1 || typeof candidates[0].document?.html !== 'string') throw Error('header template');
  const template = candidates[0], html = template.document.html;
  if (html.length > 200000) throw Error('header length');
  const nodes = elements(parseFragment(html, { sourceCodeLocationInfo: true }));
  const headers = nodes.filter(node => node.tagName === 'header');
  const navs = nodes.filter(isNav).filter(node => !nodes.some(other => other !== node && isNav(other) && inside(node, other)));
  return { manifest, id, template, html, nodes, headers, navs };
}

/** Source-span changes retain body/footer/content, bindings and authored CSS.
 * Ambiguous or action-bearing navigation is returned as actionable issues. */
export function materializeMobileHeaderNavigation<T>(input: T, options: { menuLabel?: string } = {}): { manifest: T; receipts: MobileNavigationReceipt[]; issues: MobileNavigationIssue[] } {
  const result = { manifest: input, receipts: [] as MobileNavigationReceipt[], issues: [] as MobileNavigationIssue[] };
  let templateId = Number((input as Manifest)?.site?.header_template_id) || 0;
  const issue = (code: string, message: string) => { result.issues.push({ code, templateId, message }); return result; };
  try {
    const info = inspect(input); if (!info || !info.navs.length) return result;
    const { manifest, id, template, html, nodes, headers, navs } = info; templateId = id;
    if (headers.length !== 1 || navs.some(nav => !inside(nav, headers[0]))) return issue('mobile_nav_structure', '将主导航放在唯一 header 内；手机使用默认关闭的 details > summary + nav。');
    const header = headers[0], desktop = navs.filter(nav => !ancestor(nav, 'details')), mobile = navs.filter(nav => ancestor(nav, 'details'));
    if (desktop.length > 1 || mobile.length > 1 || !desktop.length && mobile.length !== 1) return issue('mobile_nav_ambiguous', '合并主导航为一组桌面导航与一组手机菜单，避免系统猜测多个菜单的业务用途。');
    const source = desktop[0] || mobile[0];
    if (navs.some(nav => !plainNavigation(nav))) return issue('mobile_nav_actions', '导航只包含普通链接；将表单、按钮、下载、品牌行动和其它动态绑定放在导航之外。');
    if (!elements(source).some(node => node.tagName === 'a') && attr(source, 'data-aacms') !== 'site-navigation') return issue('mobile_nav_empty', '为主导航提供真实入口，不能留下空菜单。');
    if (mobile[0] && desktop[0] && navSource(source) !== navSource(mobile[0])) return issue('mobile_nav_source', '桌面与手机导航必须绑定同一菜单，并保留一致的链接顺序与标签。');
    const details = mobile[0] ? ancestor(mobile[0], 'details')! : undefined;
    if (details && (mobile[0].parentNode !== details || ancestor(details, 'details') || attr(details, 'data-aacms') || elements(details).some(node => !inside(node, mobile[0]) && node !== mobile[0] && node !== details && node.tagName !== 'summary' && node.tagName !== 'span'))) return issue('mobile_nav_structure', '手机菜单仅使用 details 的首个 summary 与一个直属 nav，行动按钮放在 details 外。');
    const ancestors: Element[] = [];
    for (const nav of navs) for (let p: Element | undefined = nav; p; p = p.parentNode && 'tagName' in p.parentNode ? p.parentNode : undefined) { ancestors.push(p); if (p === header) break; }
    if (ancestors.some(node => !navs.includes(node) && node.attrs.some(a => /^data-(?:aacms|form|template)(?:-|$)/.test(a.name) || dynamic(a.value)))) return issue('mobile_nav_binding', '不要将主导航放在会替换子树的动态绑定内；保留导航自身的 site-navigation 绑定。');
    const css = (manifest.site.theme?.global_css || '') + '\n' + manifest.templates.map(item => item.document?.css || '').join('\n');
    if (css.length > 600000) return issue('mobile_nav_complexity', '样式超出安全自动处理范围，请直接提供原生手机菜单。');
    if (conflictCss(css, [...ancestors, ...navs.flatMap(elements)])) return issue('mobile_nav_visibility', '移除页头导航的 hidden/inert 或 display、visibility、尺寸的 !important 强制覆盖，让平台响应式菜单控制展开状态。');
    const label = escape(menuLabel(manifest, header, source, options.menuLabel));
    const edits: Edit[] = [addClasses(header, ['bnf-mobile-header'])];
    const ids = new Set<string>(), idCounts = new Map<string, number>();
    let totalCharacters = 0;
    for (const item of manifest.templates) if (typeof item.document?.html === 'string') {
      if ((totalCharacters += item.document.html.length) > 600000) return issue('mobile_nav_complexity', '页头内容超出安全自动处理范围，请直接提供默认关闭的原生手机菜单。');
      for (const node of elements(parseFragment(item.document.html))) { const id = attr(node, 'id'); if (id) { ids.add(id); idCounts.set(id, (idCounts.get(id) || 0) + 1); } }
    }
    const clone = (nav: Element, creating: boolean) => {
      const location = nav.sourceCodeLocation; if (!location?.endTag) throw Error('nav end');
      const descendants = elements(nav), remap = new Map<string, string>(), own = new Set<string>();
      const changes: Edit[] = [addClasses(nav, ['bnf-chrome-nav', 'bnf-mobile-nav'], ['bnf-chrome-desktop', 'bnf-mobile-desktop'])];
      for (const node of descendants) {
        const id = attr(node, 'id'); if (!id) continue;
        if (own.has(id)) throw Error('duplicate source id'); own.add(id);
        const duplicateOutside = (idCounts.get(id) || 0) > 1;
        if (!creating && !duplicateOutside) continue;
        let target = `${id}-mobile`, suffix = 2; while (ids.has(target)) target = `${id}-mobile-${suffix++}`;
        ids.add(target); remap.set(id, target); changes.push(setAttribute(node, 'id', target));
      }
      for (const node of descendants) for (const attribute of node.attrs) {
        if (['for', 'aria-labelledby', 'aria-describedby', 'aria-controls', 'aria-owns', 'aria-flowto', 'aria-activedescendant'].includes(attribute.name)) {
          const value = attribute.value.split(/\s+/).map(id => remap.get(id) || id).join(' '); if (value !== attribute.value) changes.push(setAttribute(node, attribute.name, value));
        } else if (attribute.name === 'href' && attribute.value.startsWith('#') && remap.has(attribute.value.slice(1))) changes.push(setAttribute(node, attribute.prefix ? attribute.prefix + ':' + attribute.name : attribute.name, '#' + remap.get(attribute.value.slice(1))!));
      }
      return apply(html.slice(location.startOffset, location.endOffset), changes, location.startOffset);
    };
    if (desktop[0]) edits.push(addClasses(desktop[0], ['bnf-chrome-nav', 'bnf-chrome-desktop', 'bnf-mobile-desktop']));
    if (!details) {
      const end = source.sourceCodeLocation!.endOffset;
      edits.push({ start: end, end, text: `<details class="bnf-chrome-menu bnf-mobile-menu"><summary>${label}</summary>${clone(source, true)}</details>` });
    } else {
      const summaries = details.childNodes.filter((node): node is Element => 'tagName' in node && node.tagName === 'summary');
      if (summaries.length > 1 || summaries[0] && details.childNodes.find(node => 'tagName' in node) !== summaries[0]) return issue('mobile_nav_summary', 'details 的第一个元素必须是唯一、有文字的 summary 菜单按钮。');
      if (summaries[0] && !textContent(summaries[0]).trim()) return issue('mobile_nav_summary', '为 summary 提供清晰的“菜单”文字，不能只有未命名图标。');
      if (summaries[0] && (elements(summaries[0]).some(node => node !== summaries[0] && ['a', 'button', 'input'].includes(node.tagName)) || ['hidden', 'inert', 'aria-hidden'].some(name => attr(summaries[0], name) !== undefined))) return issue('mobile_nav_summary', 'summary 需要是可聚焦的原生菜单控件，不能隐藏或嵌套其它交互控件。');
      edits.push(addClasses(details, ['bnf-chrome-menu', 'bnf-mobile-menu', ...(!desktop.length || classes(header).includes('bnf-header-disclosure') ? ['bnf-mobile-always'] : [])]));
      if (attr(details, 'open') !== undefined) edits.push(setAttribute(details, 'open', null));
      // Native details reports its changing expansion state. A hard-coded ARIA
      // state/tabindex from the model must not hide or lie about that behavior.
      if (summaries[0]) for (const name of ['tabindex', 'aria-expanded', 'aria-controls', 'role']) if (attr(summaries[0], name) !== undefined) edits.push(setAttribute(summaries[0], name, null));
      if (!summaries.length) edits.push({ start: details.sourceCodeLocation!.startTag!.endOffset, end: details.sourceCodeLocation!.startTag!.endOffset, text: '<summary>' + label + '</summary>' });
      const nav = mobile[0], location = nav.sourceCodeLocation!;
      edits.push({ start: location.startOffset, end: location.endOffset, text: clone(nav, false) });
    }
    const updated = apply(html, edits);
    if (updated === html) return result;
    result.manifest = { ...manifest, templates: manifest.templates.map(item => item.id === id ? { ...item, document: { ...item.document, html: updated } } : item) } as T;
    result.receipts.push({ templateId: id, action: details ? 'normalized_disclosure' : 'created_disclosure', ...(attr(source, 'data-aacms-menu') ? { menuId: attr(source, 'data-aacms-menu') } : {}) });
    return result;
  } catch { return issue('mobile_nav_complexity', '无法安全自动整理页头；请使用一组桌面 nav 和默认关闭的 details > summary + 同源 nav，不改正文或绑定。'); }
}

export function validateMobileHeaderNavigation(input: unknown): MobileNavigationIssue[] {
  const normalized = materializeMobileHeaderNavigation(input);
  if (normalized.issues.length) return normalized.issues;
  if (normalized.receipts.length) return [{ code: 'mobile_nav_required', templateId: normalized.receipts[0].templateId, message: '含导航的页头必须具备默认关闭、同源且可展开收起的手机菜单；请先材料化手机导航契约。' }];
  return [];
}
export function mobileNavigationFeedback(issues: MobileNavigationIssue[]): string {
  return issues.slice(0, 4).map(issue => `页头模板 ${issue.templateId} [${issue.code}] ${issue.message}`).join('\n').slice(0, 1800);
}

export function designMobileNavigationCss(): string {
  return `${MOBILE_NAV_MARKER}
.bnf-mobile-header .bnf-mobile-menu{display:none}.bnf-mobile-header .bnf-mobile-menu.bnf-mobile-always{display:block}.bnf-mobile-header .bnf-mobile-menu>summary{display:list-item;min-height:44px;cursor:pointer;line-height:1.5;padding-block:10px}.bnf-mobile-header .bnf-mobile-menu>summary:focus-visible{outline:3px solid currentColor;outline-offset:3px}
@media(max-width:960px){.bnf-mobile-header .bnf-mobile-desktop{display:none!important}.bnf-mobile-header .bnf-mobile-menu{display:block!important;visibility:visible!important;opacity:1!important;grid-column:1/-1;grid-row:auto;min-width:0;width:100%;max-width:100%}.bnf-mobile-header .bnf-mobile-menu>summary{display:list-item!important;visibility:visible!important;min-height:44px}.bnf-mobile-header .bnf-mobile-menu>.bnf-mobile-nav{display:flex!important;flex-direction:column;align-items:stretch;min-width:0;max-width:100%;gap:4px}.bnf-mobile-header .bnf-mobile-nav>.aacms-nav-list{display:flex;flex-direction:column;align-items:stretch;width:100%;gap:4px}.bnf-mobile-header .bnf-mobile-nav a{min-height:44px;max-width:100%;overflow-wrap:anywhere}}
`;
}
