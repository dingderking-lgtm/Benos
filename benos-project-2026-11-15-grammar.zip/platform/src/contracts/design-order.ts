import { z } from 'zod';
import { parseFragment, type DefaultTreeAdapterMap } from 'parse5';

/** Explicit new-workflow capability. No existing task is upgraded by a class. */
export const DESIGN_ORDER_VERSION='dq-1' as const;
export const DESIGN_ORDER_MARKER='/* benos-design-order:dq-1 */';
export const designOrderSchema=z.object({version:z.literal(DESIGN_ORDER_VERSION),groupAlignmentVersion:z.literal('ga-1').optional(),layoutMode:z.enum(['regular','experimental']),modeSource:z.enum(['default','explicit-request','explicit-style']),language:z.enum(['zh','en','ar','auto']),headingWeight:z.literal(700),bodyWeight:z.literal(400),emphasisWeight:z.literal(600),fontPolicy:z.literal('local-style-1'),sampleFacts:z.literal('off'),providedTargets:z.array(z.string().max(2048)).max(12)}).strict();
export type DesignOrderProfile=z.infer<typeof designOrderSchema>;
export type DesignOrderIssue={code:string;message:string;templateId?:number};
export type DesignOrderReceipt={templateId:number;kind:'typography'|'group'|'primary-action'|'secondary-action';count?:number;href?:string};
export function createDesignOrder(input:{request:string;stylePreference?:string;language?:string}):DesignOrderProfile{
 const request=input.request||'',style=input.stylePreference||'',experiment=/杂志感|实验(?:性|风格|设计)|错位(?:构图|设计|排版)|\b(?:experimental|editorial layout|magazine[- ]style|asymmetric layout)\b/i;
 const positive=(text:string)=>text.replace(/(?:不要|不做|无需|不是)[^，。；\n]{0,30}/g,'').replace(/\b(?:do not|don't|no|not|avoid)\s+[^,.;\n]{0,50}/gi,'');
 const explicitRequest=experiment.test(positive(request)),explicitStyle=experiment.test(positive(style))||/^(?:editorial|expressive)$/.test(style);
 const language=/^en(?:-|$)|英文|英语|\bEnglish\b/i.test(input.language||'')||/英文|英语|\bEnglish\b/i.test(request)?'en':/^ar(?:-|$)|阿拉伯|العربية|\bArabic\b/i.test(input.language||'')||/阿拉伯|العربية|\bArabic\b/i.test(request)?'ar':/^zh(?:-|$)|中文|简体|繁体/i.test(input.language||'')||/[\u3400-\u9fff]/.test(request)?'zh':'auto';
 const targets=[...new Set(request.match(/(?:https?:\/\/[^\s<>"，。；]+|mailto:[^\s<>"，。；]+|tel:\+?[\d -]{5,})/g)||[])].slice(0,12);
 return designOrderSchema.parse({version:DESIGN_ORDER_VERSION,groupAlignmentVersion:'ga-1',layoutMode:explicitRequest||explicitStyle?'experimental':'regular',modeSource:explicitStyle?'explicit-style':explicitRequest?'explicit-request':'default',language,headingWeight:700,bodyWeight:400,emphasisWeight:600,fontPolicy:'local-style-1',sampleFacts:'off',providedTargets:targets});
}

const sans='"Segoe UI", "Microsoft YaHei", Arial, sans-serif',serif='Georgia, "Songti SC", SimSun, serif';
const headings:Record<string,string>={modern:'"Segoe UI", "Microsoft YaHei UI", sans-serif',industrial:'Bahnschrift, "Microsoft YaHei", Arial, sans-serif',trust:'Calibri, "Microsoft YaHei", sans-serif',luxury:'"Palatino Linotype", "Songti SC", SimSun, serif',warm:'Georgia, "KaiTi", serif',fresh:'"Trebuchet MS", "Microsoft YaHei", sans-serif',tech:'"Segoe UI Variable Display", "Segoe UI", "Microsoft YaHei", sans-serif',dark:'Verdana, "Microsoft YaHei", sans-serif',editorial:'Georgia, "Songti SC", SimSun, serif',bold:'Arial, "Microsoft YaHei UI", sans-serif',civic:'Tahoma, "Microsoft YaHei", sans-serif',commerce:'Candara, "Microsoft YaHei", sans-serif',data:'Consolas, "Microsoft YaHei", monospace',portfolio:'"Trebuchet MS", "KaiTi", sans-serif',documentation:'Calibri, "Microsoft YaHei UI", sans-serif',expressive:'"Palatino Linotype", "KaiTi", serif'};
export function designOrderFonts(styleId:string,profile:DesignOrderProfile){designOrderSchema.parse(profile);return {headingFont:headings[styleId]||sans,bodyFont:['editorial','luxury'].includes(styleId)?serif:sans};}
export function compileDesignOrder(profile:DesignOrderProfile){const p=designOrderSchema.parse(profile);return `${DESIGN_ORDER_MARKER}
:root{--bnf-order-size-aux:14px;--bnf-order-size-body:16px;--bnf-order-size-lead:20px;--bnf-order-size-h3:28px;--bnf-order-size-h2:40px;--bnf-order-size-h1:64px;--bnf-order-tracking:${p.language==='zh'?'0':'-.01em'};--bnf-order-heading-weight:700;--bnf-order-body-weight:400;--bnf-order-emphasis-weight:600}
body{font-size:var(--bnf-order-size-body);font-weight:400}h1,h2,h3,h4,h5,h6{font-weight:700;line-height:1.1;letter-spacing:var(--bnf-order-tracking)}h1,.bnf-title{font-size:var(--bnf-order-size-h1)}h2,.bnf-heading{font-size:var(--bnf-order-size-h2)}h3,h4,h5,h6,.bnf-subheading{font-size:var(--bnf-order-size-h3)}.bnf-lead{font-size:var(--bnf-order-size-lead)}.bnf-caption,.bnf-eyebrow,small,figcaption{font-size:var(--bnf-order-size-aux)}strong,b,.bnf-button{font-weight:600}.bnf-order-group{display:flex;flex-direction:column;align-items:flex-start;gap:20px;text-align:start}.bnf-order-group>*{margin-block:0}.bnf-order-primary{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:12px 24px;background:var(--bnf-accent);color:var(--bnf-accent-ink);border:1px solid var(--bnf-accent);text-decoration:none}.bnf-order-secondary{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:12px 24px;background:transparent;color:var(--bnf-ink);border:1px solid currentColor;text-decoration:none}
@media(max-width:640px){:root{--bnf-order-size-lead:18px;--bnf-order-size-h3:24px;--bnf-order-size-h2:28px;--bnf-order-size-h1:36px}.bnf-order-group{gap:16px}}
`;}

type Element=DefaultTreeAdapterMap['element'];type Node=DefaultTreeAdapterMap['node'];
const HTML='http://www.w3.org/1999/xhtml',attr=(n:Element,key:string)=>n.attrs.find(a=>a.name===key&&!a.namespace)?.value;
const classes=(n:Element)=>(attr(n,'class')||'').split(/\s+/).filter(Boolean),dynamic=(value:string)=>/\{\{|\}\}|\{%|%\}/.test(value);
const escape=(value:string)=>value.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
function nodes(html:string){const tree=parseFragment(html,{sourceCodeLocationInfo:true}),list:{node:Element;ancestors:Element[];protected:boolean}[]=[],stack:{node:Node;ancestors:Element[];protected:boolean}[]=[{node:tree,ancestors:[],protected:false}];while(stack.length){const item=stack.pop()!,node=item.node;if(list.length>12000||item.ancestors.length>128)throw Error('Too many nodes');let protect=item.protected;if('tagName'in node){protect ||= node.namespaceURI!==HTML||['nav','header','form','template','svg','math','picture'].includes(node.tagName)||node.attrs.some(a=>/^data-(aacms|form|template|placeholder)(-|$)/i.test(a.name)||dynamic(a.value))||attr(node,'aria-hidden')==='true';list.push({node,ancestors:item.ancestors,protected:protect});}if('childNodes'in node)for(let i=node.childNodes.length-1;i>=0;i--)stack.push({node:node.childNodes[i],ancestors:'tagName'in node?[...item.ancestors,node]:item.ancestors,protected:protect});}return list;}
function declarations(style:string):string[]|null{let depth=0,quote='',start=0;const out:string[]=[];for(let i=0;i<style.length;i++){const c=style[i];if(c==='\\'){i++;continue;}if(quote){if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='(')depth++;if(c===')'&&--depth<0)return null;if(c===';'&&depth===0){out.push(style.slice(start,i));start=i+1;}}if(quote||depth)return null;out.push(style.slice(start));return out;}
function mergedStyle(old:string,values:Record<string,string>){const parts=declarations(old);if(!parts)return null;return [...parts.filter(p=>p.trim()&&!Object.hasOwn(values,p.slice(0,p.indexOf(':')).trim().toLowerCase())),...Object.entries(values).map(([k,v])=>k+':'+v+'!important')].join(';');}
function opening(node:Element,html:string,changes:{style?:string;class?:string}){const loc=node.sourceCodeLocation?.startTag;if(!loc)return null;let result=html.slice(loc.startOffset,loc.endOffset);const edits:{start:number;end:number;text:string}[]=[],missing:string[]=[];for(const [name,value]of Object.entries(changes)){const old=node.sourceCodeLocation?.attrs?.[name];if(old)edits.push({start:old.startOffset-loc.startOffset,end:old.endOffset-loc.startOffset,text:name+'="'+escape(value)+'"'});else missing.push(name+'="'+escape(value)+'"');}for(const e of edits.sort((a,b)=>b.start-a.start))result=result.slice(0,e.start)+e.text+result.slice(e.end);if(missing.length)result=result.replace(/\s*(\/?)>$/,(_m,slash)=>' '+missing.join(' ')+(slash?' /':'')+'>');return{start:loc.startOffset,end:loc.endOffset,text:result};}
const textTags=new Set(['h1','h2','h3','h4','h5','h6','p','li','a','button','summary','small','figcaption','span','strong','b','em','label','dt','dd','td','th','blockquote']);
type GroupAlignment='start'|'center'|'end';
type AlignmentDeclaration={name:string;value:string;important:boolean};
type AlignmentRule={selector:string;declarations:AlignmentDeclaration[];conditional:boolean;order:number};
const alignmentProperties=new Set(['text-align','direction','align-items','align-self','justify-items','place-items','display','flex-direction','position','transform','float','writing-mode','grid-template-columns','all']);
function alignmentDeclarations(value:string):AlignmentDeclaration[]|null {
 const parts=declarations(value.replace(/\/\*[\s\S]*?\*\//g,''));if(!parts)return null;
 return parts.flatMap(part=>{const colon=part.indexOf(':'),name=part.slice(0,colon).trim().toLowerCase();if(colon<0||!alignmentProperties.has(name))return[];return[{name,value:part.slice(colon+1).replace(/\s*!important\s*$/i,'').trim().toLowerCase(),important:/!important\s*$/i.test(part)}];});
}
/** Only a bounded static subset is evidence for normalization. A conditional or
 * unsupported selector that may affect this group leaves its layout untouched. */
function alignmentRules(source:string):AlignmentRule[]|null {
 if(source.length>500000)return null;const css=source.replace(/\/\*[\s\S]*?\*\//g,''),rules:AlignmentRule[]=[];let failed=false;
 const read=(start:number,end:number,conditional:boolean,depth:number)=>{
  if(depth>8){failed=true;return;}let cursor=start;
  while(cursor<end&&!failed){let open=cursor,quote='',escaped=false;
   for(;open<end;open++){const c=css[open];if(escaped){escaped=false;continue;}if(c==='\\'){escaped=true;continue;}if(quote){if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')break;if(c===';')cursor=open+1;}
   if(open===end)break;const selector=css.slice(cursor,open).trim();let close=open+1,nesting=1;quote='';escaped=false;
   for(;close<end&&nesting;close++){const c=css[close];if(escaped){escaped=false;continue;}if(c==='\\'){escaped=true;continue;}if(quote){if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')nesting++;if(c==='}')nesting--;}
   if(nesting){failed=true;return;}const body=css.slice(open+1,close-1);
   if(selector.startsWith('@')){if(!/^@(?:font-face|property|(?:-webkit-)?keyframes)\b/i.test(selector))read(open+1,close-1,true,depth+1);}
   else if(body.includes('{')){if(/(?:text-align|direction|align-|place-items|display|position|transform|grid-template|\ball)\s*:/i.test(body))failed=true;}
   else {const parsed=alignmentDeclarations(body);if(!parsed){failed=true;return;}if(parsed.length){rules.push({selector,declarations:parsed,conditional,order:rules.length});if(rules.length>3000){failed=true;return;}}}
   cursor=close;
  }
 };read(0,css.length,false,0);return failed?null:rules;
}
type AlignmentTarget=Pick<Element,'tagName'|'attrs'>;
const alignmentCompound=/^(?:\*|[a-z][\w-]*)?(?:[.#][\w-]+)*$/i;
function alignmentSelectors(value:string):string[]|null {
 const result:string[]=[];let depth=0,start=0,quote='',escaped=false;
 for(let i=0;i<value.length;i++){const c=value[i];if(escaped){escaped=false;continue;}if(c==='\\'){escaped=true;continue;}if(quote){if(c===quote)quote='';continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='('||c==='[')depth++;if(c===')'||c===']'){if(--depth<0)return null;}if(c===','&&!depth){result.push(value.slice(start,i));start=i+1;}}
 if(depth||quote)return null;result.push(value.slice(start));return result;
}
function alignmentCompoundMatches(selector:string,node:AlignmentTarget){
 if(selector===':root')return node.tagName==='html';const tag=selector.match(/^[a-z][\w-]*/i)?.[0];if(tag&&tag.toLowerCase()!==node.tagName)return false;
 return [...selector.matchAll(/([.#])([\w-]+)/g)].every(([,kind,value])=>kind==='#'?node.attrs.some(a=>a.name==='id'&&a.value===value):node.attrs.some(a=>a.name==='class'&&a.value.split(/\s+/).includes(value)));
}
function alignmentSelectorMatch(selector:string,chain:AlignmentTarget[]):boolean|null {
 selector=selector.trim();const parts=selector.replace(/\s*>\s*/g,' > ').split(/\s+/).filter(Boolean);
 if(selector.includes('\\'))return null;
 if(!parts.length||parts.length>32)return null;
 if(parts.some((part,i)=>part!=='>'&&part!==':root'&&(!alignmentCompound.test(part)||!part)||part==='>'&&(i===0||i===parts.length-1||parts[i-1]==='>'))){
  // An unconditional first compound absent from the entire ancestor path proves
  // a header/footer-only rule irrelevant. Positive first alternatives can also
  // prove absence; never reason through negation or sibling combinators.
  const alternatives=selector.match(/^:(?:where|is)\(([^()]*)\)/)?.[1].split(',').map(s=>s.trim());
  if(alternatives?.length&&alternatives.every(s=>s&&alignmentCompound.test(s))&&!/[+~]/.test(selector)&&!chain.some(n=>alternatives.some(s=>alignmentCompoundMatches(s,n))))return false;
  const prefix=selector.match(/^(?:[a-z][\w-]*|\*)?(?:[.#][\w-]+)*/i)?.[0];
  return prefix&&!/[+~]/.test(selector)&&!chain.some(n=>alignmentCompoundMatches(prefix,n))?false:null;
 }
 let at=chain.length-1,index=parts.length-1;if(!alignmentCompoundMatches(parts[index--],chain[at--]))return false;
 while(index>=0){if(parts[index]==='>'){index--;if(at<0||!alignmentCompoundMatches(parts[index--],chain[at--]))return false;}
  else{while(at>=0&&!alignmentCompoundMatches(parts[index],chain[at]))at--;if(at<0)return false;at--;index--;}}
 return true;
}
function groupAlignment(group:Element,rows:ReturnType<typeof nodes>,css:string):GroupAlignment|null {
 const rules=alignmentRules(css);if(!rules)return null;
 const groupRow=rows.find(row=>row.node===group)!,children=rows.filter(row=>row.ancestors.at(-1)===group&&!row.protected).map(row=>row.node);
 if(children.length>64)return null;let remainingMatches=20000;
 const virtual:AlignmentTarget[]=[{tagName:'html',attrs:[]},{tagName:'body',attrs:[]}],chain=[...virtual,...groupRow.ancestors,group],targets=[...chain,...children],computed=new Map<AlignmentTarget,Map<string,{value:string;important:boolean;specificity:number;order:number}>>();
 for(const target of targets){const path=children.includes(target as Element)?[...chain,target]:chain.slice(0,chain.indexOf(target)+1),map=new Map<string,{value:string;important:boolean;specificity:number;order:number}>();computed.set(target,map);
  const put=(d:AlignmentDeclaration,specificity:number,order:number)=>{const old=map.get(d.name);if(!old||Number(d.important)>Number(old.important)||d.important===old.important&&(specificity>old.specificity||specificity===old.specificity&&order>=old.order))map.set(d.name,{...d,specificity,order});};
  for(const rule of rules){const selectors=alignmentSelectors(rule.selector);if(!selectors)return null;for(const selector of selectors){
   if(--remainingMatches<0)return null;
   const match=alignmentSelectorMatch(selector,path);if(match===false)continue;
   const applicable=rule.declarations.filter(d=>target===group||children.includes(target as Element)||['text-align','direction','all'].includes(d.name));if(!applicable.length)continue;
   if(match===null||rule.conditional)return null;
   const specificity=(selector.match(/#/g)?.length||0)*100+(selector.match(/[.:]/g)?.length||0)*10+(selector.match(/(?:^|[ >])[a-z][\w-]*/gi)?.length||0);
   for(const d of applicable)put(d,specificity,rule.order);
  }}
  const own=alignmentDeclarations(target.attrs.find(a=>a.name==='style')?.value||'');if(!own)return null;for(const d of own)put(d,10000,rules.length);
 }
 // Language is not a rendered direction. The preview's html/body are LTR
 // unless actual dir attributes or CSS establish otherwise.
 let direction='ltr',inheritedAlignment='start';
 const logical=(value:string):GroupAlignment|null=>value==='center'||value==='start'||value==='end'?value:value==='left'?(direction==='rtl'?'end':'start'):value==='right'?(direction==='rtl'?'start':'end'):null;
 for(const node of chain){const map=computed.get(node)!,dir=map.get('direction')?.value||node.attrs.find(a=>a.name==='dir')?.value;if(dir){if(!['ltr','rtl','inherit'].includes(dir))return null;if(dir!=='inherit')direction=dir;}
  if(map.has('all'))return null;const value=map.get('text-align')?.value;if(value){if(value==='inherit'||value==='unset')continue;inheritedAlignment=value==='initial'?'start':value;}
 }
 // Physical left/right stay physical through inheritance, even when an inner
 // element changes dir. Convert only after resolving the group's direction.
 let align=logical(inheritedAlignment);if(!align)return null;
 const map=computed.get(group)!,cross=map.get('align-items')?.value;
 if(!map.has('text-align')&&cross&&map.get('flex-direction')?.value==='column'){
  const resolved=cross==='flex-start'?'start':cross==='flex-end'?'end':logical(cross);if(resolved)align=resolved;else if(cross!=='stretch')return null;
 }
 for(const node of [group,...children]){const values=computed.get(node)!;
  if(values.has('all')||values.has('grid-template-columns')||values.has('place-items')||values.has('justify-items')||/grid/.test(values.get('display')?.value||'')||values.get('writing-mode')&&values.get('writing-mode')!.value!=='horizontal-tb'||values.get('transform')&&values.get('transform')!.value!=='none'||['absolute','fixed','sticky'].includes(values.get('position')?.value||'')||values.get('float')&&values.get('float')!.value!=='none')return null;
  if(node!==group){const childDirection=values.get('direction')?.value||attr(node,'dir');if(align!=='center'&&childDirection&&!['inherit',direction].includes(childDirection))return null;const child=values.get('text-align')?.value;if(child&&!['inherit','unset'].includes(child)&&logical(child)!==align)return null;const self=values.get('align-self')?.value;if(self&&!['auto','normal','stretch',align,align==='start'?'flex-start':align==='end'?'flex-end':'center'].includes(self))return null;}
 }
 return align;
}
/** Pure source-span normalization for new-site page templates only. No content,
 * href, image geometry, header binding or original manifest is rewritten. */
export function materializeDesignOrder<T>(manifest:T,profile:DesignOrderProfile|null):{manifest:T;issues:DesignOrderIssue[];receipts:DesignOrderReceipt[]}{
 if(!profile)return{manifest,issues:[],receipts:[]};const p=designOrderSchema.parse(profile),m=manifest as any,issues:DesignOrderIssue[]=[],receipts:DesignOrderReceipt[]=[];
 if(!Array.isArray(m?.templates)||!Array.isArray(m?.site?.pages))return{manifest,issues:[{code:'DESIGN_ORDER_STRUCTURE',message:'需要完整页面清单以确定排版与操作范围。'}],receipts};
 const parsed=new Map<number,ReturnType<typeof nodes>>();try{for(const t of m.templates)if(typeof t.document?.html==='string')parsed.set(t.id,nodes(t.document.html));}catch{return{manifest,issues:[{code:'DESIGN_ORDER_COMPLEXITY',message:'页面结构过于复杂，未执行自动规整。'}],receipts};}
 const home=m.site.pages.find((page:any)=>page.key===m.site.home),pageIds=new Set(m.site.pages.map((page:any)=>page.template_id));
 const renderedIds=(page:any)=>[m.site.header_template_id,page.template_id,m.site.footer_template_id].filter((x:any)=>Number.isInteger(x));
 const idCount=(page:any,id:string)=>renderedIds(page).flatMap((id:number)=>parsed.get(id)||[]).filter(row=>attr(row.node,'id')===id).length;
 const validHref=(href:string,page:any)=>{if(!href||dynamic(href)||/[\u0000-\u0020<>"'\\]/.test(href))return false;if(href.startsWith('#'))return href.length>1&&idCount(page,href.slice(1))===1;if(/^\/(?!\/)/.test(href)){const [route,fragment]=href.split('#');const target=route==='/'?home:m.site.pages.find((candidate:any)=>'/'+String(candidate.slug||candidate.key).replace(/^\/|\/$/g,'')===route.replace(/\/$/,''));return !!target&&(!fragment||idCount(target,fragment)===1);}return p.providedTargets.includes(href)&&/^(https?:\/\/|mailto:|tel:)/.test(href);};
 const templates=m.templates.map((t:any)=>{
  if((!pageIds.has(t.id)||t.type!=='page')&&!(t.id===m.site.footer_template_id&&t.type==='footer')||typeof t.document?.html!=='string')return t;const html=t.document.html as string,rows=parsed.get(t.id)||[],changes=new Map<Element,{style?:string;class?:string}>();let normalized=0;
  const change=(node:Element,values:Record<string,string>,add:string[]=[],remove:string[]=[])=>{const current=changes.get(node)||{},style=mergedStyle(current.style??attr(node,'style')??'',values);if(style===null){issues.push({code:'DESIGN_ORDER_STYLE',message:'内联样式无法安全分段，请移除损坏样式。',templateId:t.id});return;}changes.set(node,{style,class:[...new Set([...(current.class??attr(node,'class')??'').split(/\s+/).filter(c=>c&&!remove.includes(c)),...add])].join(' ')});};
  for(const row of rows){const n=row.node;if(row.protected||!textTags.has(n.tagName)||!n.sourceCodeLocation?.startTag)continue;const heading=/^h[1-6]$/.test(n.tagName)||classes(n).some(c=>/^(bnf-title|bnf-heading|bnf-subheading)$|(?:^|-)signoff$/.test(c))||row.ancestors.some(a=>/^h[1-6]$/.test(a.tagName)||classes(a).some(c=>/^(bnf-title|bnf-heading|bnf-subheading)$|(?:^|-)signoff$/.test(c))),ownHeading=/^h[1-6]$/.test(n.tagName)||classes(n).some(c=>/^(bnf-title|bnf-heading|bnf-subheading)$|(?:^|-)signoff$/.test(c)),emphasis=[n,...row.ancestors].some(a=>['strong','b','button','summary'].includes(a.tagName)||classes(a).some(c=>/button|primary|secondary/.test(c)));
   const inline=['span','strong','b','em','a'].includes(n.tagName)&&row.ancestors.some(a=>textTags.has(a.tagName)&&a.tagName!=='li');
   const slot=n.tagName==='h1'||classes(n).includes('bnf-title')?'h1':n.tagName==='h2'||classes(n).some(c=>c==='bnf-heading'||/(?:^|-)signoff$/.test(c))?'h2':ownHeading?'h3':['small','figcaption'].includes(n.tagName)||classes(n).some(c=>/caption|eyebrow|kicker|disclaimer/.test(c))?'aux':classes(n).includes('bnf-lead')?'lead':'body';
   change(n,{'font-weight':heading?'700':emphasis?'600':'400','font-size':(heading&&!ownHeading)||inline?'inherit':`var(--bnf-order-size-${slot})`,'font-family':inline?'inherit':heading?'var(--bnf-heading)':'var(--bnf-body)','line-height':inline?'inherit':heading?'1.1':'1.65','letter-spacing':heading?'var(--bnf-order-tracking)':'0'});normalized++;
  }
  if(normalized)receipts.push({templateId:t.id,kind:'typography',count:normalized});
  const page=m.site.pages.find((page:any)=>page.template_id===t.id),h1=rows.find(row=>!row.protected&&row.node.tagName==='h1');
  if(h1&&page?.key===m.site.home){
   const hero=[...h1.ancestors].reverse().find(n=>n.tagName==='section')||h1.ancestors.find(n=>n.tagName==='main');
   const inside=hero?rows.filter(row=>row.ancestors.includes(hero)):[];
   const links=inside.filter(row=>!row.protected&&row.node.tagName==='a'&&validHref(attr(row.node,'href')||'',page)&&!row.node.childNodes.some(n=>'tagName'in n&&n.tagName==='img'));
   const marked=links.find(row=>classes(row.node).some(c=>c==='bnf-order-primary'||/(?:^|-)(?:primary|button|btn)(?:-|$)/.test(c)));const primary=marked||links[0],secondary=links.find(row=>row!==primary&&attr(row.node,'href')!==attr(primary?.node||row.node,'href'));
   if(primary){change(primary.node,{'background':'var(--bnf-accent)','color':'var(--bnf-accent-ink)','border':'1px solid var(--bnf-accent)','display':'inline-flex','padding':'12px 24px','min-height':'44px','align-items':'center','justify-content':'center','text-decoration':'none','font-weight':'600'},['bnf-button','bnf-order-primary'],['bnf-button-secondary','bnf-order-secondary']);receipts.push({templateId:t.id,kind:'primary-action',href:attr(primary.node,'href')});}
   else issues.push({code:'DESIGN_ORDER_PRIMARY_MISSING',message:'首屏需要一个实心主行动，请复用页面中真实可达的内容入口，不编造联系方式。',templateId:t.id});
   if(secondary){change(secondary.node,{'background':'transparent','color':'var(--bnf-ink)','border':'1px solid currentColor','display':'inline-flex','padding':'12px 24px','min-height':'44px','text-decoration':'none','font-weight':'600'},['bnf-button','bnf-button-secondary','bnf-order-secondary'],['bnf-order-primary']);receipts.push({templateId:t.id,kind:'secondary-action',href:attr(secondary.node,'href')});}
   for(const row of inside.filter(row=>!row.protected&&row.node.tagName==='a'&&row!==primary&&row!==secondary))change(row.node,{'background':'transparent','border':'0','box-shadow':'none'},[],['bnf-button','bnf-button-secondary','bnf-order-primary','bnf-order-secondary']);
   if(p.layoutMode==='regular'){const safeGroup=(n:Element)=>!rows.some(row=>row.ancestors.includes(n)&&((row.protected&&![row.node,...row.ancestors].some(a=>attr(a,'aria-hidden')==='true'))||['img','figure','picture','video','iframe','section','article'].includes(row.node.tagName)||attr(row.node,'id')?.startsWith('bnf-image-')));
    const group=[...h1.ancestors].reverse().find(n=>['div','article','section'].includes(n.tagName)&&safeGroup(n));
    const alignment=group?(p.groupAlignmentVersion==='ga-1'?groupAlignment(group,rows,[m.site.theme?.global_css,...[m.site.header_template_id,t.id,m.site.footer_template_id].map(id=>m.templates.find((shared:any)=>shared.id===id)?.document?.css)].filter(Boolean).join('\n')):'start'):null;
    if(group&&alignment){const cross=alignment==='start'?'flex-start':alignment==='end'?'flex-end':'center';change(group,{'display':'flex','flex-direction':'column','align-items':cross,'text-align':alignment,'gap':'20px'},['bnf-order-group']);
     for(const row of rows.filter(row=>row.ancestors.at(-1)===group&&!row.protected)){change(row.node,{'margin-inline':'0','margin-block':'0','text-align':alignment,'align-self':cross,'max-width':'100%','transform':'none','position':'static'});if(row.node.tagName==='div'&&safeGroup(row.node)){const actions=classes(row.node).includes('bnf-actions')||row.node.childNodes.filter(n=>'tagName'in n).every(n=>'tagName'in n&&['a','button'].includes(n.tagName));change(row.node,{'display':'flex','flex-direction':actions?'row':'column','flex-wrap':'wrap','align-items':actions?'center':cross,...(p.groupAlignmentVersion==='ga-1'&&actions?{'justify-content':cross}:{}),'gap':'16px'});}}
     receipts.push({templateId:t.id,kind:'group'});}
   }
  }
  const edits=[...changes].map(([n,c])=>opening(n,html,c)).filter((e):e is NonNullable<typeof e>=>!!e).sort((a,b)=>b.start-a.start);let next=html;for(const e of edits)next=next.slice(0,e.start)+e.text+next.slice(e.end);return next===html?t:{...t,document:{...t.document,html:next}};
 });
 return{manifest:{...m,templates},issues,receipts};
}

export function designOrderAuthoringRules(base:string,profile:DesignOrderProfile|null){if(!profile)return base;const p=designOrderSchema.parse(profile);let rules=base;
 if(p.layoutMode==='regular')rules=rules.replace('designBrief.creativeDirection支持跨行业构图、编辑叙事、空间与文字实验，不把行业当审美模板。','默认常规结构、严格对齐、文字与行动成组；不主动错位、散落标签或使用实验性刊头。').replace('核心章节改变尺度和阅读路径，避免连续“标题+三列表”；','核心章节按内容变化，但同组对齐、相邻章节共享网格；');
 return rules+'\n【规整契约dq-1】'+(p.layoutMode==='regular'?'默认规整，错位/杂志实验仅用户明确要求时启用。':'用户明确要求实验构图，仍遵守以下阅读约束。')+'标题同一700字重、正文400、强调600，最多6个语义字号；中文字距0，拉丁不低于-.02em，标题行高1.1。首屏文案/说明/行动放同一组，一实心主按钮、次动作至多一，复用真实href；缺联系方式用现有内容锚点。图片组同比例对齐，上传原图与完整产品不强裁。主色/中性色写入共同artDirection，排除无依据跳色。sample off：不编命名Concept/self-initiated项目、客户、团队、评分与价格；无证据以能力/过程/原生图解替代，不靠声明放行。\n【平台页头】首次prepare_layout.header或无新图的propose_files.header必须提交工具定义的页头数据，模型不写页头HTML；后续提交header:null复用已编译页头。改页头用set_site_header({header:...})。菜单来自CMS绑定，品牌是纯文本或真实标志，不能有br、定位语和装饰线；保持真实链接与可用手机菜单。'+(p.groupAlignmentVersion==='ga-1'?'\n成组不等于左对齐：同一文案行动组明确使用 start/center/end；尊重居中或末端构图，按钮横排可换行，RTL沿用逻辑方向。':'');}

/** Replace only the new task's creative snapshot, preserving its factual brief. */
export function orderCreativeBrief<T extends {creativeDirection?:unknown}>(brief:T,profile:DesignOrderProfile):T {const p=designOrderSchema.parse(profile);return {...brief,creativeDirection:{version:'dq-1',styleSource:p.modeSource==='default'?'automatic':'user',judgment:'行业决定信息责任，不锁配色。用户明确品牌与布局优先；普通短句由平台完成设计判断。',composition:p.layoutMode==='regular'?'默认严格对齐、文案行动成组；章节共享网格，图像与文字按内容组合。禁止主动错位、散落标签、实验刊头。':'用户明确要求实验构图；仍保持阅读顺序、内容成组和移动可读。',rhythm:'用真实内容密度与图文比例形成节奏，不靠巨大空白或字号、字重堆叠。',imagery:'主视觉解释真实对象/用途；同组图片同比例、同色调，完整产品不强裁。共同 artDirection 写主色、中性色、材质和光线，禁止无依据跳色。',internationalization:'遵循站点语言；中文零字距，拉丁字距不低于 -.02em；RTL 用逻辑方向，产品图不镜像。',boundaries:'sample off：不虚构公司作品、客户、团队、报价、认证或联系方式；缺事实用能力/过程/原生图解。'}};}
