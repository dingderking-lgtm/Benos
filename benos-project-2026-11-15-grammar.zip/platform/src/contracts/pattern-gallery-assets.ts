/** Existing generated concept images, used only as explicitly labelled gallery fixtures.
 * Source evidence: source-manifest.json in the 20261114-pattern-gallery artifact assets directory.
 * No new image request or pixel edits. All asset routes require staff authentication. */
export const PATTERN_GALLERY_ASSETS = [
  {
    "file": "3365f01d98b81334c09d2603691d5c088fa9b9e844b2efdd2ac242f215a37e8d.png",
    "path": "/assets/pattern-gallery/3365f01d98b81334c09d2603691d5c088fa9b9e844b2efdd2ac242f215a37e8d.png",
    "sha256": "3365f01d98b81334c09d2603691d5c088fa9b9e844b2efdd2ac242f215a37e8d",
    "size": 2813393,
    "width": 1536,
    "height": 1024
  },
  {
    "file": "9f1a77ffcd46dc3498ea85875040a531a480c0a309b772efec2d9505539323f7.png",
    "path": "/assets/pattern-gallery/9f1a77ffcd46dc3498ea85875040a531a480c0a309b772efec2d9505539323f7.png",
    "sha256": "9f1a77ffcd46dc3498ea85875040a531a480c0a309b772efec2d9505539323f7",
    "size": 2540981,
    "width": 1536,
    "height": 1024
  },
  {
    "file": "a7708ab518a364bb2a14c090d4b1a42e532d8660e0e6379b2d1b4efa4fa1f91b.png",
    "path": "/assets/pattern-gallery/a7708ab518a364bb2a14c090d4b1a42e532d8660e0e6379b2d1b4efa4fa1f91b.png",
    "sha256": "a7708ab518a364bb2a14c090d4b1a42e532d8660e0e6379b2d1b4efa4fa1f91b",
    "size": 2698659,
    "width": 1536,
    "height": 1024
  },
  {
    "file": "eb6339668e38af2d3fbecf4774d01e31529e422ae40854b9942492f01eb43868.png",
    "path": "/assets/pattern-gallery/eb6339668e38af2d3fbecf4774d01e31529e422ae40854b9942492f01eb43868.png",
    "sha256": "eb6339668e38af2d3fbecf4774d01e31529e422ae40854b9942492f01eb43868",
    "size": 2147438,
    "width": 1536,
    "height": 1024
  }
] as const;
