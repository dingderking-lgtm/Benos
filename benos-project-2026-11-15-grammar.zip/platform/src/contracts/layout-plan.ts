import { sha256 } from '../lib/crypto';
import type { DesignBrief } from './design-brief';

export const LAYOUT_PLAN_VERSION='lp-1' as const;
export const MEDIA_COMPOSITIONS=['one-large-two-small','alternating','horizontal-rail','full-bleed-caption','lead-image-list','bento','image-caption-strip','image-steps'] as const;
export type MediaComposition=typeof MEDIA_COMPOSITIONS[number]|'native-explanation';
export interface LayoutPlan {
 version:'lp-1';catalogVersion:'layout-pool-1';rendering:'intent-only';seed:string;allocationId:string;
 source:'automatic'|'user'|'reference';previousCombinationHash:string|null;combinationHash:string;
 primaryMediaComposition:MediaComposition;primarySectionId:string;heroComposition:'stage'|'cover'|'centered';
 pages:{key:string;sections:{id:string;role:string;composition:string;headingLayout:string;surface:'base'|'tint'|'accent';factRefs:string[];frameRefs:string[];fallback:string}[]}[];
 exceptions:string[];
}
export interface LayoutHistory {combinationHash:string;primaryMediaComposition:string;heroComposition?:string}
export interface LayoutPlanInput {seed:string;allocationId:string;request:string;referenceImageCount:number;availableImageCount?:number;brief:DesignBrief;history:readonly LayoutHistory[]}
const HEADINGS=['stack-left','stack-center','numbered-side','integrated-first-item'] as const;
function rank(seed:string,value:string){let n=2166136261;for(const char of seed+'|'+value)n=Math.imul(n^char.charCodeAt(0),16777619);return n>>>0;}
const sorted=<T extends string>(items:readonly T[],seed:string)=>[...items].sort((a,b)=>rank(seed,a)-rank(seed,b)||a.localeCompare(b));
function candidates(input:LayoutPlanInput):{pool:MediaComposition[];explicit:MediaComposition|null;exceptions:string[]}{
 const image=input.brief.imagePlan,request=input.request.toLowerCase(),exceptions:string[]=[];
 let pool:MediaComposition[]=[...MEDIA_COMPOSITIONS];
 if(image?.mode==='none')return {pool:['native-explanation'],explicit:null,exceptions:['用户明确无图，媒体池不适用']};
 const count=image?.generation==='disabled'?Math.max(0,input.availableImageCount??0):image?.targetRange[1]??8;
 const minimum:Record<MediaComposition,number>={'one-large-two-small':3,bento:4,'horizontal-rail':3,alternating:2,'full-bleed-caption':1,'lead-image-list':1,'image-caption-strip':1,'image-steps':2,'native-explanation':0};
 pool=pool.filter(value=>count>=minimum[value]);
 if(!pool.length)return {pool:['native-explanation'],explicit:null,exceptions:['禁止生图且无足够已确认可用图片，采用原生解释；不宣称媒体已准备完成']};
 // Do not randomly put complete engineering products in a cropped banner.
 if(/完整|不裁|整机|机械|设备|\b(?:complete product|uncropped|machine|equipment)\b/.test(request))pool=pool.filter(value=>!['full-bleed-caption','one-large-two-small','bento'].includes(value));
 const explicit:MediaComposition|null=/横向(?:滑动|滚动)|横滑|\b(?:horizontal gallery|carousel|scrolling gallery)\b/.test(request)?'horizontal-rail':/便当盒|\bbento\b/.test(request)?'bento':/一大两小|\bone large.{0,8}two small\b/.test(request)?'one-large-two-small':/图文交替|\balternating\b/.test(request)?'alternating':/全幅(?:图片|大图)|\bfull.bleed\b/.test(request)?'full-bleed-caption':null;
 if(explicit&&pool.includes(explicit))pool=[explicit];else if(explicit)exceptions.push('用户布局偏好与图片数量/主体完整约束冲突，保留内容约束并允许创作调整');
 return {pool,explicit:explicit&&pool.includes(explicit)?explicit:null,exceptions};
}
function sectionComposition(role:string,index:number,media:MediaComposition,hero:string,seed:string,primaryRole:string){
 if(index===0)return 'hero-'+hero;
 if(role===primaryRole)return media;
 if(role==='process')return media==='image-steps'?'image-steps':sorted(['numbered-path','vertical-sequence','alternating-steps'],seed)[0];
 if(role==='faq')return 'disclosure';if(role==='action')return sorted(['accent-action','compact-action','contact-split'],seed)[0];
 return sorted(['numbered-ledger','grouped-points','detail-pair','chapter'],seed)[0];
}
/** Intent is independently frozen before any model call. No pattern IDs, code,
 * approved renderer references, or customer claims are invented here. */
export async function createLayoutPlan(input:LayoutPlanInput):Promise<LayoutPlan>{
 const history=input.history.slice(0,7),choices=candidates(input),automatic=!choices.explicit&&!input.referenceImageCount;
 const counts=new Map(choices.pool.map(m=>[m,history.filter(h=>h.primaryMediaComposition===m).length]));
 let pool=automatic?choices.pool.filter(m=>counts.get(m)!<2):choices.pool;
 const exceptions=[...choices.exceptions];
 if(!pool.length){pool=choices.pool;exceptions.push('可用媒体池不足，滚动8站≤2次限制让位于明确内容约束');}
 pool.sort((a,b)=>(counts.get(a)!-counts.get(b)!)||rank(input.seed,a)-rank(input.seed,b));
 const noImage=pool.every(value=>value==='native-explanation'),request=input.request.toLowerCase();
 const explicitHero=/全幅首屏|全屏(?:首屏|封面)|\b(?:cover hero|full.bleed hero)\b/.test(request)?'cover':/居中首屏|\bcentered hero\b/.test(request)?'centered':null;
 let heroes:LayoutPlan['heroComposition'][]=noImage?['stage','centered']:/完整|不裁|机械|设备|\b(?:machine|equipment)\b/.test(request)?['stage','centered']:['stage','cover','centered'];
 if(explicitHero&&heroes.includes(explicitHero))heroes=[explicitHero];
 else heroes=sorted(heroes,input.seed+'hero').sort((a,b)=>Number(a===history[0]?.heroComposition)-Number(b===history[0]?.heroComposition));
 const blueprint=input.brief.pageBlueprint!;
 const roles=blueprint.roles;
 const primaryDefault=roles.find(r=>['gallery','space','working-example','offering'].includes(r.id))?.id??roles.find(r=>['applications','details','example','content'].includes(r.id))?.id??roles[0].id;
 for(const media of pool)for(const hero of heroes){
  const primarySectionId=media==='image-steps'&&roles.some(r=>r.id==='process')?'process':primaryDefault;
  const middle=roles.slice(1,-1).filter(r=>r.id!=='faq'),closingQuestions=roles.slice(1,-1).filter(r=>r.id==='faq');
  // Only swap independent neighboring explanations. Product/capability
  // orientation remains before technical conditions; FAQ/action stay last.
  const independent=new Set(['applications|process','details|process','process|space','applications|details','content|format']);
  const swappable=middle.flatMap((role,index)=>index<middle.length-1&&independent.has([role.id,middle[index+1].id].sort().join('|'))?[index]:[]);
  const reordered=[...middle],swap=swappable[rank(input.seed,media+'order')%(swappable.length+1)];
  if(swap!==undefined)[reordered[swap],reordered[swap+1]]=[reordered[swap+1],reordered[swap]];
  const ordered=roles.length>1?[roles[0],...reordered,...closingQuestions,roles.at(-1)!]:roles;
  const sections:LayoutPlan['pages'][number]['sections']=[];
  for(const [index,role] of ordered.entries()){
   const previous=sections.at(-1);
   let composition=sectionComposition(role.id,index,media,hero,input.seed+index,primarySectionId);
   if(previous&&composition===previous.composition)composition=composition==='chapter'?'numbered-ledger':'chapter';
   sections.push({id:role.id,role:role.id,composition,headingLayout:HEADINGS[(rank(input.seed,media)+index)%HEADINGS.length],surface:index===ordered.length-1?'accent':index%3===1?'tint':'base',factRefs:[],frameRefs:[],fallback:role.fallback||'有标签的主题解释；无有用内容则跳过并记录'});
  }
  const signature={hero,media,sections:sections.map(({role,composition,headingLayout})=>({role,composition,headingLayout}))};
  const combinationHash=await sha256(JSON.stringify(signature));
  if(automatic&&combinationHash===history[0]?.combinationHash&&pool.length*heroes.length>1)continue;
  if(combinationHash===history[0]?.combinationHash)exceptions.push('明确布局/可用池不足导致与上一组合一致');
  return {version:'lp-1',catalogVersion:'layout-pool-1',rendering:'intent-only',seed:input.seed,allocationId:input.allocationId,source:choices.explicit||explicitHero?'user':input.referenceImageCount?'reference':'automatic',previousCombinationHash:history[0]?.combinationHash??null,combinationHash,primaryMediaComposition:media,primarySectionId,heroComposition:hero,pages:[{key:'home',sections}],exceptions};
 }
 throw new Error('Layout pool exhausted');
}

export const layoutPlanAuthoringNote='layoutPlan是已分配的构图意图，按完整需求落实，可因事实/素材/明确要求调整并说明例外。不是已审核模式授权；无patternRef时仅用现有foundation原语与局部CSS，不臆造bns类或compose工具。相邻主要章节避免相同构图和标题摆法，变化不靠换色或3卡改4卡。';
