import { explicitWebsiteIntent,inferWebsiteKind,type WebsiteKind } from './website-intent';
import { createCreativeDirection, type CreativeDirection } from './creative-direction';

/** Local, persistable professional decisions for a new customer website.
 * This is not a second planning call or a page template. Existing-site edits
 * keep their saved direction; the full user request remains authoritative. */
export const DESIGN_BRIEF_VERSION = 'db-3' as const;

export interface DesignBriefInput {
  request: string;
  hasExistingSite: boolean;
  referenceImageCount?: number;
  scope?: 'site' | 'page' | 'node';
  stylePreference?: string;
}

type LegacyDesignBriefKind = 'industrial' | 'cafe' | 'photography' | 'general';
export type DesignBriefKind = LegacyDesignBriefKind | WebsiteKind;
export interface DesignBrief {
  version: 'db-1' | 'db-2' | typeof DESIGN_BRIEF_VERSION;
  source: { requestExcerpt: string; excerptTruncated: boolean; referenceImageCount: number; factsPolicy: string };
  inference: { siteKind: DesignBriefKind; subtype?:string|null; reason: string };
  visitorGoal: string;
  pageStrategy: string;
  informationPriorities: string[];
  cta: { primary: string; reason: string; whenDetailsMissing: string };
  visualTasks: string[];
  referenceUse: string;
  missingFactsPolicy: string;
  creativeFreedom: string;
  /** Optional so previously persisted db-1 snapshots remain valid. */
  creativeDirection?: CreativeDirection;
  /** New-site image responsibilities, never a quota or another planning call. */
  imagePlan?: DesignImagePlan;
  artDirection?: string;
  pageBlueprint?: PageBlueprint;
}

export interface PageBlueprint {
 version:'pb-1';depth:'standard'|'simple'|'explicit';targetSections:[number,number];
 roles:{id:string;purpose:string;requires?:'facts'|'owned-assets';fallback?:string}[];
 exceptions:string[];
}

export interface DesignImagePlan {
  mode: 'none' | 'minimal' | 'standard';
  generation: 'disabled' | 'fill-gaps';
  targetRange: [number, number];
  roles: { role: string; purpose: string; count: [number, number] }[];
  assetPolicy: string;
  completionPolicy: string;
}

function imageResponsibilities(request: string, kind: LegacyDesignBriefKind): DesignImagePlan {
  const text = request.normalize('NFKC').toLowerCase().replace(/(?:不要|不是|并非)(?:纯文字|无图(?:片)?|简单|简短)|\bnot (?:text[- ]only|simple|brief)\b/g, ' ');
  const noImages = /纯文字|无图(?:片)?(?:网站|页面|首页|设计)?|(?:不要|不用|不需要|无需|禁止)(?:任何|使用|添加|放)?(?:图片|配图|照片|插图|图像)|\b(?:no images?|without (?:any )?(?:images?|photos?)|text[- ]only)\b/.test(text);
  const noGeneration = noImages || /(?:不要|不用|不需要|无需|禁止|不)(?:ai)?(?:(?:生成|新建|重绘)(?:任何|新的|ai)?(?:图片|配图|照片|插图|图像)|生图)|仅用(?:上传|现有|已有)|只用(?:上传|现有|已有)|\b(?:do not|don't) generate (?:any |new )?(?:images?|photos?)\b|\bno (?:generated images|image generation)|\b(?:only (?:use )?(?:uploaded|existing)|no new images)\b/.test(text);
  const minimal = /(?:简单|简短|少图|少量(?:图片|配图)|只(?:用|要|放)[一二两三123]张)|\b(?:simple|brief|few images|lightweight)\b/.test(text);
  const purpose = kind === 'industrial' ? ['设备与应用环境', '部件、物料或产品差异', '工艺关系与使用场景', '项目条件或环境细节']
    : kind === 'cafe' ? ['饮品或空间氛围', '风味、材质与饮品细节', '制作过程或空间体验', '有内容的到访氛围']
      : kind === 'photography' ? ['代表拍摄方向', '不同题材或系列', '创作方法或视觉叙事', '系列的收束画面']
        : ['核心对象与体验', '产品、作品或服务差异', '过程、场景或原生图解', '呼应主题的内容细节'];
  return {
    mode: noImages ? 'none' : minimal ? 'minimal' : 'standard', generation: noGeneration ? 'disabled' : 'fill-gaps',
    targetRange: noImages ? [0, 0] : minimal ? [0, 3] : [5, 8],
    roles: noImages ? [] : minimal
      ? [{ role: 'hero', purpose: purpose[0], count: [0, 1] }, { role: 'detail', purpose: purpose[1], count: [0, 2] }]
      : [{ role: 'hero', purpose: purpose[0], count: [1, 1] }, { role: 'detail', purpose: purpose[1], count: [2, 3] }, { role: 'process', purpose: purpose[2], count: [1, 2] }, { role: 'closing', purpose: purpose[3], count: [1, 2] }],
    assetPolicy: '目标含真实上传与已有素材，先识别用途再占位；生成只补缺口。原生图解可承担信息视觉，不把参考图冒充客户作品。',
    completionPolicy: '数量是规划目标而非硬配额；用户指定数量、无图或少图优先。有用途才生成，预算或服务不足可减图；失败用有内容的排版替代，如实报告，不重试凑数。',
  };
}

type ProfessionalDecisions = Pick<DesignBrief, 'visitorGoal' | 'informationPriorities' | 'cta' | 'visualTasks'> & { reason: string };
const DECISIONS: Record<LegacyDesignBriefKind, ProfessionalDecisions> = {
  industrial: {
    reason: '按设备选型场景推断访客需判断适用性与沟通条件，不推定企业具备任何产能、认证或交付案例。',
    visitorGoal: '让潜在采购者看懂设备处理什么、适合哪些需求，并知道进一步选型需要提供什么。',
    informationPriorities: ['先解释设备用途与适用原料，再用有依据的工艺关系帮助理解；不要只堆企业口号。', '区分可确认的产品信息与通用选型知识；型号、产量和材料参数仅使用用户提供值。', '把后续咨询需要的原料、目标产出与场地条件讲清，减少访客不知道问什么的阻力。'],
    cta: { primary: '真实咨询入口具备时，引导沟通设备需求。', reason: '设备选型依赖项目条件，直接报价或立即购买通常缺乏依据。', whenDetailsMissing: '无真实联系方式或接收端点时，改为可用的页内“了解选型要点”，不造电话或假提交表单。' },
    visualTasks: ['即使用户没提图片，也应规划解释设备形态或工作关系的主视觉；先检查真实上传，无合适素材再生成明确的说明性设备图。', '按布局确定图框与主体留白，完整设备避免硬裁；以部件、工艺、物料和应用场景分担视觉任务，不用同图多处充数。'],
  },
  cafe: {
    reason: '按到店体验场景推断访客需要了解饮品与空间，不推定门店地址、营业时间、价格或预约服务。',
    visitorGoal: '让访客判断这家店的饮品与氛围是否适合自己；真实到店条件齐备时帮助安排到访。',
    informationPriorities: ['优先呈现已知饮品特色和空间体验，把具体感受写清，不编招牌产品或获奖经历。', '菜单资料不足时解释品类、风味或选择方法，不伪造价目表。', '地址、时间、交通与订位仅呈现已提供信息；缺失项目不要靠空白大区块占位。'],
    cta: { primary: '有真实地址时提供到店信息；有有效预约能力时才提供预约。', reason: '餐饮访客通常先判断想喝什么、是否适合到访，再决定行动。', whenDetailsMissing: '条件不齐时使用可工作的页内“探索饮品与空间”；无真实菜单就展示风味方向，不能伪装成在售清单。' },
    visualTasks: ['由饮品特写、材质或空间之一承担主视觉，选择能帮助理解体验的画面；真实门店与产品上传优先。', '没有实拍时可生成氛围或饮品概念图，贴近图注说明其用途，不冒充实际门店；视觉色温与页面表达一致。'],
  },
  photography: {
    reason: '按作者作品浏览场景推断访客需看出拍摄方向与选择逻辑，不推定作者履历、客户、奖项或图片版权。',
    visitorGoal: '让访客快速理解作者的拍摄方向，方便浏览和选择感兴趣的作品，再决定是否进一步了解。',
    informationPriorities: ['真实作品是核心内容；按题材、系列或叙事组织，优先展示差异与选择依据，避免用通用服务卡片压过作品。', '作者介绍和创作方法服务于理解作品；履历、客户与合作经历仅使用用户提供信息。', '有真实联系方式或委托信息才提供合作入口；没有这些内容仍让分类与浏览完成有意义的动作。'],
    cta: { primary: '有真实作品时优先“浏览作品”或进入具体系列。', reason: '作品集需要先证明视觉方向，联系意向来自作品本身。', whenDetailsMissing: '无真实联系方式时保留作品分类或选片；无真实作品时改为“了解拍摄方向”，不放假联系按钮。' },
    visualTasks: ['即使用户没提图片，也需主视觉；先检查上传是否为用户作品，按原始构图展示，不推定每张参考图都是作者作品。', '无可用真实作品时可生成明确标为创作方向示意的概念图，不能编入真实作品或客户项目；为以后替换原片保留合适比例。'],
  },
  general: {
    reason: '需求未明确命中专门场景；下面是通用设计推断，由创作模型结合完整原文确定实际业务，不补造行业事实。',
    visitorGoal: '让首次访问者知道这是谁、提供什么、与自己有何关系，并完成一个有依据且可执行的下一步。',
    informationPriorities: ['先从完整需求判断目标访客与核心价值，用具体解释建立理解。', '根据现有事实选择最有说服力的内容：产品用途、服务过程、作品或内容本身；缺证据就解释方法，不造客户与数字。', '为主要问题安排清晰的阅读路径，短内容保持紧凑，不为凑完整首页添加无信息区块。'],
    cta: { primary: '依据用户明确目的和已有能力，选浏览内容、了解服务、查看作品或真实联系中的一个主行动。', reason: '主行动应承接访客刚获得的信息，也必须有真实可达的目标。', whenDetailsMissing: '交易、预约或联系条件不明时，选已有内容的页内入口；没有对应内容就不做按钮。' },
    visualTasks: ['主动判断哪些信息需要图像或原生图示解释，不等用户提供专业提示词；没有内容用途的装饰不必生成。', '真实素材优先；需要新图时先决定任务与图框，生成概念图与真实产品、作品或案例明确区分。'],
  },
};

function inferKind(request: string): LegacyDesignBriefKind {
  const explicit = explicitWebsiteIntent(request);
  if (explicit) return explicit === 'other' ? 'general' : explicit;
  const normalized = request.normalize('NFKC').toLowerCase()
    .replace(/(?:不要|不需要|不做|无需|不是|别做)[^，,。；;\n]{0,60}/g, ' ')
    .replace(/\b(?:not|no|without)\s+(?:an?\s+)?(?:coffee shop|caf[eé]|photography portfolio|industrial|machinery)\b/g, ' ');
  // Secondary examples and requested features must not redefine the business.
  const primary = normalized.split(/(?:[，,；;]\s*(?:包含|包括|附带|加上|带有)|\bwith\s+(?:an?\s+)?(?:gallery|portfolio|blog)\b)/)[0];
  if (/机械|设备制造|工业设备|装备制造|塑料再生|造粒|挤出|生产线|咖啡机(?:厂家|制造|生产|供应)|\b(?:machinery|industrial equipment|manufactur(?:er|ing)|factory|extruders?|recycling equipment|production line)\b/.test(primary)) return 'industrial';
  if (/咖啡(?:店|馆|厅|屋|品牌)|(?:精品|社区|街角)咖啡|\b(?:coffee shop|cafe|café|coffeehouse)\b/.test(primary)) return 'cafe';
  if (/摄影(?:师|作品|网站|官网)|(?:个人|我的)[^，,。；;\n]{0,12}摄影|\b(?:photographer|photography|photo portfolio)\b/.test(primary)) return 'photography';
  return 'general';
}

/** Create once with a new workflow, persist the result, and reuse that snapshot.
 * Do not invoke this to replace a saved brief while editing an existing site. */
export function createLegacyDesignBrief(input: DesignBriefInput): DesignBrief | null {
  if (input.hasExistingSite || (input.scope && input.scope !== 'site')) return null;
  const request = typeof input.request === 'string' ? input.request.trim() : '';
  const excerpt = Array.from(request).slice(0, 160).join('');
  const count = Number.isFinite(input.referenceImageCount) ? Math.max(0, Math.min(100, Math.floor(input.referenceImageCount!))) : 0;
  const siteKind = inferKind(request), decisions = DECISIONS[siteKind];
  return {
    version: 'db-2',
    source: {
      requestExcerpt: excerpt, excerptTruncated: excerpt !== request, referenceImageCount: count,
      factsPolicy: '完整原始需求和实际上传素材是事实来源；短摘录不可代替全文。下列访客目标、内容和视觉建议均为设计推断，不是用户确认的商业事实。',
    },
    inference: { siteKind, reason: decisions.reason },
    visitorGoal: decisions.visitorGoal,
    pageStrategy: '页面范围以完整原文和用户明确选择为准。未指定页面时，先制作内容完整的首页并用页内导航承接；不要默认凑关于、产品、案例、联系等薄页。明确要求多页时分别组织内容，不以默认首页覆盖要求。',
    informationPriorities: [...decisions.informationPriorities],
    cta: { ...decisions.cta },
    visualTasks: [...decisions.visualTasks],
    referenceUse: (count > 0
      ? '已提供参考图片，先识别其用途和实际内容；不凭数量判断为产品、实拍、商标或作者作品，不因参考图擅自改写业务。'
      : '未提供图片不等于不需要图片；按视觉任务判断生成需求。') + '生图失败时用原生文字、关系图或排版完成解释，不留破图，也不声称图片已成功。',
    missingFactsPolicy: '用户已给出的名称和事实按原文使用，不把真实公司一律称为虚构演示。缺失电话、地址、价格、参数、资质、案例、客户与业绩不得编造；只对自产概念图或示意内容就近简注，不让免责声明独占大区块。',
    creativeFreedom: '用户明确目的、风格与限制优先。这是内部判断职责，不是成品模板；模型自行创作整页主线、构图与节奏，不固定区块顺序、配色、卡片数量或图片数量，兼顾移动阅读与可用交互。',
    creativeDirection: createCreativeDirection(input)!,
    imagePlan: imageResponsibilities(request, siteKind),
    artDirection: '为整站确定一套色调、光线、镜头/景别、场景与避免项，随布局一次提交；各图保持共同语法但采用不同主体或视角。用户品牌和图片要求优先，概念图不冒充实拍，不为选美另开规划或付费重生。',
  };
}

const BLUEPRINTS:Record<WebsiteKind,readonly [string,string][]>={
 'industrial-b2b':[['orientation','设备用途与处理对象'],['capabilities','已知产品环节与差异'],['applications','使用环境与适用条件'],['process','工艺输入、过程与结果'],['details','部件与选择维度'],['selection','沟通所需项目条件'],['faq','通用选型疑问'],['action','有依据的下一步']],
 'local-hospitality':[['orientation','店铺或空间体验'],['highlights','品类与体验要点'],['offering','饮品、房型或服务方向'],['space','空间与使用场景'],['process','制作或到访前准备'],['selection','体验选择指南'],['faq','到访问题'],['action','真实到访或内容入口']],
 'portfolio-studio':[['orientation','创作定位与观看线索'],['highlights','创作方向要点'],['gallery','真实作品或明确的方向示意'],['details','视觉细节阅读'],['process','创作方法与过程'],['fit','委托需求与适配'],['faq','作品或委托疑问'],['action','浏览或真实合作入口']],
 'software-product':[['orientation','产品对象与解决的问题'],['highlights','有依据的能力要点'],['working-example','输入、处理与结果示例'],['capabilities','已确认功能或通用主题解释'],['applications','任务场景'],['process','使用流程与依赖'],['faq','能力边界与采用疑问'],['action','真实产品或内容入口']],
 'professional-service':[['orientation','服务定位'],['needs','常见需求'],['offering','服务范围或问题地图'],['applications','适用情境'],['process','方法过程'],['selection','合作准备'],['faq','常见疑问'],['action','真实联系或内容入口']],
 'brand-commerce':[['orientation','品牌与商品对象'],['highlights','设计要点'],['gallery','已有系列或外观方向'],['applications','使用情境'],['details','材料与局部细节'],['selection','选择与养护'],['faq','商品疑问'],['action','真实购买或内容入口']],
 'education-community':[['orientation','学习或社群主题'],['highlights','主题要点'],['content','内容方向'],['format','学习或讨论形式'],['example','一段有用的主题内容'],['selection','参与准备'],['faq','常见疑问'],['action','阅读或真实参与入口']],
 'event-campaign':[['orientation','活动或专题主题'],['highlights','内容亮点'],['gallery','主题内容展区'],['experience','体验脉络'],['programme','已知日程或内容顺序'],['selection','参与准备'],['faq','实务疑问'],['action','真实参与或内容入口']],
 general:[['orientation','主体与核心价值'],['highlights','核心要点'],['gallery','具体对象与内容'],['applications','适用场景'],['process','过程解释'],['selection','选择依据'],['faq','关键疑问'],['action','可执行下一步']],
};
const IMAGE_ROLES:Record<WebsiteKind,readonly string[]>={
 'industrial-b2b':['设备整体','工作环境','材料与部件','应用场景','工艺节点'],
 'local-hospitality':['空间宽景','体验细节','使用场景','制作或环境'],
 'portfolio-studio':['创作主视觉','不同创作方向','系列细节','创作过程'],
 'software-product':['具体产品或语义舞台','任务场景','工作流关系','功能细节'],
 'professional-service':['服务对象','方法过程','交付物形态','应用环境'],
 'brand-commerce':['完整产品','不同视角','材质细节','使用情境'],
 'education-community':['主题内容','读物或工具','学习场景','内容细节'],
 'event-campaign':['主题视觉','内容细节','环境示意','体验线索'],
 general:['具体对象','使用情境','对象细节','过程关系'],
};

/** The db-3 contract is compact: visitor questions, not a fixed template.
 * Legacy creation is explicit; reading a db-1/db-2 snapshot never calls this. */
export function createDesignBrief(input:DesignBriefInput):DesignBrief|null{
 const base=createLegacyDesignBrief(input);if(!base)return null;
 const request=input.request.trim(),inferred=inferWebsiteKind(request),legacy=inferKind(request);
 const plan=imageResponsibilities(request,legacy);
 const text=request.normalize('NFKC').toLowerCase().replace(/(?:不要|不是|并非)(?:简单|简短)|\bnot (?:simple|brief)\b/g,' ');
 const simple=/(?:简单|简短)|\b(?:simple|brief|lightweight)\b/.test(text);
 const onlyHero=/(?:只要|仅需|只做|仅做)(?:一个|一屏|1个)?(?:首屏|区块)|\b(?:only|just) (?:a |the )?hero\b/.test(text);
 const roles=BLUEPRINTS[inferred.kind].map(([id,purpose])=>({id,purpose} as PageBlueprint['roles'][number]));
 if(inferred.kind==='portfolio-studio')Object.assign(roles.find(r=>r.id==='gallery')!,{requires:'owned-assets',fallback:'明确的创作方向示意，不编命名项目或公司履历'});
 if(inferred.kind==='software-product')Object.assign(roles.find(r=>r.id==='capabilities')!,{requires:'facts',fallback:'一般任务解释，不声称该软件已具备'});
 if(inferred.kind==='brand-commerce')Object.assign(roles.find(r=>r.id==='gallery')!,{requires:'facts',fallback:'品类或外观方向，不伪装在售商品'});
 if(inferred.kind==='event-campaign')Object.assign(roles.find(r=>r.id==='programme')!,{requires:'facts',fallback:'内容阅读顺序，不造嘉宾日期地点'});
 const blueprint:PageBlueprint={version:'pb-1',depth:onlyHero?'explicit':simple?'simple':'standard',targetSections:onlyHero?[1,1]:simple?[4,5]:[7,9],roles:onlyHero?[roles[0]]:simple?[roles[0],roles[2],roles[4],roles.at(-1)!]:roles,exceptions:onlyHero?['用户明确只做首屏']:simple?['用户明确简单首页']:[]};
 let purposes=[...IMAGE_ROLES[inferred.kind]];
 if(inferred.subtype==='cafe')purposes=['饮品主视觉','品类与风味','饮品或材质细节','制作过程','空间体验'];
 if(inferred.subtype==='stay')purposes=['环境宽景','居住空间','材质与居住细节','休憩体验','周边环境示意'];
 if(inferred.subtype==='photography')purposes=['代表拍摄方向','不同题材与光线','人像局部细读','创作过程'];
 if(inferred.subtype==='hardware')purposes=['完整产品主视觉','结构与部件','任务场景','使用关系'];
 if(plan.mode!=='none')plan.roles=purposes.slice(0,plan.mode==='minimal'?2:undefined).map((purpose,i)=>({role:i===0?'hero':`visual-${i+1}`,purpose,count:plan.mode==='minimal'?[0,i===0?1:2]:[1,i===0?1:2]}));
 if(onlyHero&&plan.mode!=='none'){plan.mode='minimal';plan.targetRange=[0,1];plan.roles=plan.roles.slice(0,1);plan.roles[0].count=[0,1];}
 plan.assetPolicy='真实上传与已有素材优先，生成只补缺口；参考图不自动属于客户作品。软件无真实UI不造数据仪表盘，服务无团队资料不造员工照。';
 plan.completionPolicy='目标非硬配额；明确数量/无图优先，失败不重发。用有标签、有关系的内容退化，不留灰块；结果列计划/成功/缺失用途。';
 const imageNumber=(value:string)=>Number(value)||({零:0,一:1,二:2,两:2,三:3,四:4,五:5,六:6,七:7,八:8,zero:0,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8} as Record<string,number>)[value]||0;
 const explicitCount=/(?:只用|只要|仅用|仅需|总共|一共)\s*([0-8零一二两三四五六七八])\s*张(?:图片|图|照片|配图)?/.exec(text)||/\b(?:only|just|exactly|a total of)\s+(?:use\s+)?([0-8]|zero|one|two|three|four|five|six|seven|eight)\s+(?:images?|photos?|pictures?)\b/.exec(text);
 const upperCount=/(?:最多|不超过|至多|上限(?:为|是)?)\s*([0-8零一二两三四五六七八])\s*张(?:图片|图|照片|配图)?/.exec(text)||/\b(?:at most|no more than|up to|maximum of)\s+([0-8]|zero|one|two|three|four|five|six|seven|eight)\s+(?:images?|photos?|pictures?)\b/.exec(text);
 if(plan.mode!=='none'&&(explicitCount||upperCount)){const exact=explicitCount?imageNumber(explicitCount[1]):null,upper=upperCount?imageNumber(upperCount[1]):null,c=Math.min(exact??8,upper??8);plan.targetRange=exact===null?[0,c]:[c,c];if(!c){plan.mode='none';plan.generation='disabled';plan.roles=[];}}
 return {version:'db-3',source:base.source,inference:{siteKind:inferred.kind,subtype:inferred.subtype,reason:'依据主业务推断访客问题，不把行业绑定审美；完整原文优先。'},visitorGoal:base.visitorGoal,
  pageStrategy:'未指定页面先完整首页；明确页数/范围优先，不在每页重复8个角色。角色可调序替换；缺事实且无有用替代则跳过并报告，不凑空段。',
  informationPriorities:['按pageBlueprint回答不同访客问题；默认7–9内容区块，简单或明确范围例外。','事实只取原文与确认素材；行业知识不得写成公司承诺。'],cta:base.cta,
  visualTasks:['即使没提图片也主动按角色安排主视觉、细节与过程；完整实物不强裁。','无作品用明确方向示意，不造客户项目；缺图用有内容的图解，不能灰块占位。'],
  referenceUse:base.referenceUse,missingFactsPolicy:'名称按原文。电话、价格、地址、参数、资质、案例、客户、团队不得编造；概念标签不能证明公司作品。缺资料列任务结果，客户页面不堆待补充；图像来源页脚合并一次。',
  creativeFreedom:'用户明确目的、风格与限制优先。行业只决定内容责任，不固定区块顺序、配色、卡片数量或图片数量；layoutPlan统筹结构，内容保持成组、响应式与RTL可读。',
  imagePlan:plan,artDirection:base.artDirection,pageBlueprint:blueprint};
}

/** Inject only the saved brief; old workflows without one keep their context. */
export function designBriefAuthoringContext(brief: DesignBrief | null | undefined): string {
  return brief ? `平台内部设计简报（推断可按完整需求修正，无需向用户索要专业提示词）：\n${JSON.stringify(brief)}` : '';
}
