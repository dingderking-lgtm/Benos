import { z } from 'zod';
import { SITE_CHROME_VERSION } from './site-chrome';

// Original compositional starting points. The model can recombine them or follow
// a customer's explicit direction; these are never mandatory page templates.
export const HEADER_DIRECTIONS = {
  inline: '轻量横排：品牌、少量关键入口与一个主动作，给首屏内容让出空间。',
  centered: '居中品牌：品牌居中独立一层，下面紧凑导航，适合空间、生活方式与精致品牌。',
  split: '中轴双翼：品牌为中心，导航和主动作在两侧平衡；窄屏按阅读顺序收拢。',
  utility: '双层导览：真实辅助信息单独一行，主品牌与导航另成一层；缺辅助资料就删掉该行。',
  directory: '入口目录：品牌与简短定位在一侧，另一侧按访客任务组织少量入口，内容足够才分组。',
  offset: '错位编辑：品牌与小型说明错开，导航沿另一条对齐线组织；有控制的非对称，不作斜切堆叠。',
  masthead: '刊头式品牌：用通栏字标建立记忆点，配细导航；中文长品牌缩字号或换行，不裁字。',
  disclosure: '紧凑索引：品牌与原生展开菜单构成安静入口，展开后有清楚目录；按钮必须实际可用。',
} as const;
export const FOOTER_DIRECTIONS = {
  compact: '轻收尾：品牌短句、必要链接与版权分层对齐，适合内容少的站点，不能只剩孤零零一行版权。',
  columns: '品牌与分组：一侧品牌和定位，另一侧按真实内容分组导航；不要为了凑列编造资源。',
  sitemap: '探索目录：较宽的真实网站或章节索引，再收束品牌与法务；小站无需虚构多页。',
  contact: '下一步主导：用一句具体邀请与有效动作收束；无真实联系方式时链接到有价值的站内内容。',
  editorial: '编辑式尾章：大字品牌或一句有内容的结语，配细分隔线和小型索引，与首屏形成尺度呼应。',
  centered: '居中落款：简洁品牌落款、少量导航和小字信息，适合温暖或安静的页面结尾。',
  split: '双区结尾：一侧继续探索的邀请，另一侧必要信息；用间距、线或相近色面分区，不突然换陌生配色。',
  index: '编号索引：把真实页面或章节做成有节奏的目录行，末尾用小型品牌与版权收束。',
} as const;
type Header = keyof typeof HEADER_DIRECTIONS;
type Footer = keyof typeof FOOTER_DIRECTIONS;
export const siteChromeDirectionSchema = z.object({
  version: z.literal(SITE_CHROME_VERSION),
  header: z.enum(['inline','centered','split','utility','directory','offset','masthead','disclosure']),
  footer: z.enum(['compact','columns','sitemap','contact','editorial','centered','split','index']),
}).strict();
export type SiteChromeDirection = z.infer<typeof siteChromeDirectionSchema>;

const pools: Record<string, readonly [readonly Header[], readonly Footer[]]> = {
  modern: [['inline','split','offset','centered'],['columns','contact','split','index']],
  trust: [['utility','inline','directory','split'],['columns','sitemap','contact','compact']],
  editorial: [['masthead','offset','centered','directory'],['editorial','index','split','columns']],
  bold: [['masthead','offset','disclosure','split'],['editorial','contact','index','split']],
  expressive: [['offset','masthead','disclosure','centered'],['editorial','split','index','contact']],
  warm: [['centered','offset','masthead','split'],['centered','contact','editorial','split']],
  fresh: [['split','centered','inline','offset'],['split','centered','columns','contact']],
  luxury: [['centered','split','disclosure','masthead'],['editorial','centered','compact','contact']],
  portfolio: [['offset','disclosure','masthead','inline'],['editorial','index','contact','compact']],
  industrial: [['utility','directory','inline','split'],['columns','index','contact','split']],
  dark: [['inline','split','offset','disclosure'],['contact','editorial','columns','split']],
  tech: [['inline','split','directory','utility'],['columns','sitemap','contact','index']],
  commerce: [['utility','centered','directory','split'],['columns','sitemap','split','contact']],
  civic: [['utility','directory','inline','split'],['columns','sitemap','compact','index']],
  documentation: [['directory','utility','inline','split'],['sitemap','index','compact','columns']],
  data: [['directory','masthead','utility','offset'],['index','editorial','sitemap','columns']],
};
function hash(value: string) {
  let result = 2166136261;
  for (const char of value) { result ^= char.codePointAt(0)!; result = Math.imul(result,16777619); }
  result ^= result >>> 16; result = Math.imul(result,0x85ebca6b);
  result ^= result >>> 13; result = Math.imul(result,0xc2b2ae35);
  return (result ^ (result >>> 16)) >>> 0;
}
/** Persist once with the foundation. A replay never chooses a new composition. */
export function createSiteChromeDirection(styleId: string, variationKey = styleId): SiteChromeDirection {
  const [headers,footers] = pools[styleId] || pools.modern;
  return {version:SITE_CHROME_VERSION,header:headers[hash('header:'+variationKey)%headers.length],footer:footers[hash('footer:'+variationKey)%footers.length]};
}
export function siteChromeAuthoringContext(direction: SiteChromeDirection) {
  return {
    header:{class:'bnf-header-'+direction.header,intent:HEADER_DIRECTIONS[direction.header]},
    footer:{class:'bnf-footer-'+direction.footer,intent:FOOTER_DIRECTIONS[direction.footer]},
    judgment:'把本次起点发展成实际构图，在品牌尺度、导航组织、对齐和结尾动作上体现差异，不只挂类名或换颜色。可按用户要求、真实内容和首屏关系改选或重组，但不要无依据退回同一种单行结构与简单版权。少量链接也能用品牌尺度和对齐形成识别，无需编栏目。用户要求优先；首屏已有巨大品牌时页脚可收敛，首屏克制时页脚可形成记忆点。',
    content:'只保留真实可达入口。无资料不造电话、地址、社交、订阅、备案、认证或资源栏目；不让空栏目与占位联系方式撑高页脚。共享导航的首页锚点使用 /#id，其他页也要能返回对应章节。',
  };
}
