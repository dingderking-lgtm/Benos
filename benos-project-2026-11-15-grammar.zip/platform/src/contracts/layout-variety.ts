// A new site's persisted plan chooses a coherent composition family before choosing its details.
// Preferences narrow the family; randomness never independently mixes incompatible navigation and shapes.
const NAVIGATION=[
 '居中胶囊导航组，品牌在左，主按钮在右',
 '极简细线页头：品牌在左，右侧是文字链接加一个描边按钮，底部一条细分隔线',
 '双层页头：顶部一条细窄的信息条（联系方式或一句定位），下方是品牌与导航',
 '品牌居中，导航链接分列左右两侧',
 '大号品牌字标靠左，导航靠右并带数字编号（01、02…）',
 '悬浮卡片式页头：圆角白底卡片浮在首屏之上，四周留出间距',
] as const;
const HERO=[
 '满幅主视觉图铺底，标题与按钮压在左下角的深色渐变上',
 '居中的超大标题与导语，下方是一张横贯内容宽度的主视觉图',
 '左文右图的非对称双栏，图片出血到页面右边缘',
 '左图右文：图片为竖幅，文字区用一组带编号的要点代替长导语',
 '纯排版首屏：超大标题占满整行并分两行错位排布，主视觉缩成一条横向图带放在下方',
 '分屏首屏：左半是品牌色色块承载标题与按钮，右半是主视觉图',
 '卡片拼贴首屏：标题一侧是两到三张大小不一、错落叠放的图片卡',
 '编辑式首屏：小标题、超大标题、导语分三栏底部对齐，主视觉图在下方偏右并带图注',
 '首屏下沿叠放一条信息带：主视觉与标题之下，是横跨整宽的三到四项关键信息',
] as const;
const SECTIONS=[
 '横向编号流程：步骤之间用细线和节点连接',
 '纵向时间线：左侧是序号与连线，右侧是说明',
 '左右交替的图文区块，每块图片位置相反',
 '三栏或四栏特性网格：只用细线分隔，不加卡片底色',
 '便当盒式拼贴（bento）：大小不等的卡片组成一个矩形',
 '满幅深色理念区：一句大字号陈述配一小段说明',
 '带大号数字的服务清单：一行一项，行间细线，右侧是简短说明',
 '参数或对比表：表头固定样式，行交替浅底',
 '横向卡片带：一排等宽卡片，首张更宽作为引导',
 '图片画廊：一大两小或瀑布式排列，带简短图注',
 '常见问题：用 details 与 summary 做折叠，不依赖脚本',
 '两栏粘性布局：左侧标题与说明固定感排版，右侧是逐条展开的内容',
 '场景大图配浮动说明卡：说明卡压在图片一角',
 '数据或要点带：一行三到四项，用大号字突出关键词而不是编造数字',
 '引述或理念卡片：大引号、正文与署名位置（无真实来源时写成品牌主张）',
] as const;
const ACTION=[
 '整幅品牌色行动区：标题居左，按钮居右',
 '居中行动区：上下留白很大，按钮下附一行补充说明',
 '分栏行动区：左侧说明与按钮，右侧是联系要点卡',
 '嵌在浅色大圆角卡片里的行动区，卡片四周留白',
 '深色行动区，背景带极淡的网格或线条纹理',
] as const;
const FOOTER=[
 '多栏页脚：品牌简介加三组链接，底部一行版权',
 '极简单行页脚：品牌、几条链接与版权排在一行',
 '大字号品牌字标铺满页脚宽度，上方是链接与联系信息',
 '深色页脚，顶部并入一条简短的行动横幅',
] as const;
const SHAPE=[
 '直角与细线，克制硬朗',
 '大圆角与柔和阴影，亲和圆润',
 '胶囊形按钮配小圆角卡片',
 '混合语言：图片大圆角，卡片与按钮直角',
] as const;
const RHYTHM=['留白充裕、节奏舒缓','信息紧凑、层次分明','大小对比强烈：超大标题与小号辅助文字并置'] as const;
const ALIGNMENT=['整体左对齐','区块标题居中、正文左对齐','标题靠左、内容整体右移形成偏轴构图'] as const;

function draw<T>(items:readonly T[],random:()=>number):T{return items[Math.min(items.length-1,Math.floor(random()*items.length))];}
function pick<T>(items:readonly T[],count:number,random:()=>number):T[]{
 const pool=[...items],out:T[]=[];
 while(out.length<count&&pool.length)out.push(pool.splice(Math.min(pool.length-1,Math.floor(random()*pool.length)),1)[0]);
 return out;
}
const secureRandom=()=>crypto.getRandomValues(new Uint32Array(1))[0]/4294967296;
export type LayoutPlan={direction:string;navigation:string;hero:string;sections:string[];action:string;footer:string;shape:string;rhythm:string;alignment:string;typography:string;imageComposition:string};
type Family={name:string;nav:number[];hero:number[];sections:number[];action:number[];footer:number[];shape:number;rhythm:number;alignment:number;typography:string;imageComposition:string};
const FAMILIES:readonly Family[]=[
 {name:'电影叙事',nav:[1,3],hero:[0,8],sections:[2,5,6,9,10,12,13],action:[0,4],footer:[2,3],shape:0,rhythm:2,alignment:0,typography:'宽阔无衬线标题、克制短段落，以主视觉和明暗转换组织阅读',imageComposition:'横幅场景保留空间感，主视觉文字侧留出低细节区域；近景细节独立配图'},
 {name:'编辑画册',nav:[1,3],hero:[7,3],sections:[2,3,6,9,10,11,14],action:[1,2],footer:[1,2],shape:0,rhythm:0,alignment:2,typography:'衬线或宋体标题配无衬线正文，图注与细分栏形成画册层级',imageComposition:'竖向主体和横向场景成组编排，图片与文字并置，保留主体轮廓'},
 {name:'产品展示',nav:[0,1],hero:[1,2],sections:[0,2,3,4,7,10,13],action:[0,1],footer:[0,1],shape:2,rhythm:1,alignment:1,typography:'清晰无衬线标题，产品名与用途优先，参数以等宽辅助文字呈现',imageComposition:'主产品完整展示，优先 contain；场景图和功能细节使用独立图框'},
 {name:'精密工程',nav:[1,4],hero:[2,5],sections:[0,1,3,6,7,10,13],action:[0,2],footer:[0,1],shape:0,rhythm:1,alignment:0,typography:'硬朗无衬线标题、紧凑参数表与流程注释，字号服务信息层级',imageComposition:'宽幅整机配细节近景，清楚展示结构和工序；整机不得裁断关键部件'},
 {name:'品牌海报',nav:[3,4],hero:[4,7],sections:[2,3,5,6,9,12,13],action:[0,1],footer:[1,2],shape:0,rhythm:2,alignment:2,typography:'超大主张与小号注释强对比，错位标题和非对称留白，正文保持易读',imageComposition:'图片作为海报叙事焦点，主体偏轴，文字避开主体，局部特写独立取景'},
 {name:'专业简报',nav:[1,2],hero:[2,8],sections:[0,3,6,7,10,11,13],action:[0,2],footer:[0,1],shape:0,rhythm:1,alignment:0,typography:'稳健无衬线标题，结论先行，清单、对比与可信信息形成阅读层次',imageComposition:'真实业务场景宽图配过程图，视觉证据与对应说明就近排列'},
 {name:'自然故事',nav:[1,3],hero:[3,1],sections:[1,2,6,9,10,12,14],action:[1,3],footer:[0,1],shape:3,rhythm:0,alignment:0,typography:'柔和系统衬线或人文无衬线标题，舒展行距和短段落形成叙事',imageComposition:'自然光场景与竖幅人物或材料质感交替，主体完整，留白自然'},
 {name:'创意拼贴',nav:[0,5],hero:[6,5],sections:[2,4,5,8,9,10,12],action:[0,3],footer:[2,3],shape:3,rhythm:2,alignment:2,typography:'大标题、错落图注与块面组合，控制一个主要焦点并保持正文可读',imageComposition:'不同镜头组成拼贴，每个图框独立规划比例；不把一张图重复裁成所有配图'},
];
const PREFERRED:Record<string,readonly number[]>={
 '极简现代':[2,5],'工业专业':[3,5],'稳重商务':[5,3],'高端质感':[1,0],'自然温暖':[6,1],
 '清新活力':[6,7],'科技未来':[2,3],'暗色沉浸':[0,4],'杂志编辑':[1,4],'鲜明个性':[7,4],
};
/** A structure for one new site. `random` is injectable so a test can ask for a known plan. */
export function layoutPlan(random:()=>number=secureRandom,preference:{style?:string}={}):LayoutPlan{
 const style=String(preference.style||'').trim().split(/[；;：:，,]/)[0];
 const family=draw(PREFERRED[style]?.map(index=>FAMILIES[index])||FAMILIES,random);
 return {direction:family.name,navigation:draw(family.nav.map(i=>NAVIGATION[i]),random),hero:draw(family.hero.map(i=>HERO[i]),random),sections:pick(family.sections.map(i=>SECTIONS[i]),5,random),action:draw(family.action.map(i=>ACTION[i]),random),footer:draw(family.footer.map(i=>FOOTER[i]),random),shape:SHAPE[family.shape],rhythm:RHYTHM[family.rhythm],alignment:ALIGNMENT[family.alignment],typography:family.typography,imageComposition:family.imageComposition};
}
