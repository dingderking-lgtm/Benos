export type ExplicitWebsiteIntent = 'industrial' | 'cafe' | 'photography' | 'other';

// Only resolve the few business/site combinations whose incidental descriptions
// can otherwise conflict with the brief and style catalog. This is not a new
// classifier for all sixteen styles: null preserves each caller's fallback;
// other keeps a known specialized task out of a business-specific brief while
// leaving the catalog's more detailed purpose classification intact.
const specialPurpose = /知识库|文档|帮助中心|使用手册|教程|报告|数据可视化|商城|商店|电商|商品目录|产品目录|(?:在线|网上)(?:购买|销售)|公共服务|社区服务|\b(?:documentation|knowledge base|help cent(?:er|re)|user guides?|reports?|data stor(?:y|ies)|e-?commerce|online (?:shop|store)|product catalog(?:ue)?|storefront|public service|community service)\b/;
const siteNoun = /官网|网站|站点|作品集|\b(?:website|web site|site|portfolio)\b/;

function subjectKind(subject: string): Exclude<ExplicitWebsiteIntent, 'other'> | null {
  const value = subject.replace(/(?:机械|工业)+(?:风格|风|质感)/g, ' ');
  // A coffee-machine maker is an equipment business, not a coffee shop.
  if (/咖啡机[^，,。；;\n]{0,12}(?:厂家|厂商|制造|生产|供应)|\b(?:coffee|espresso) (?:machine|equipment)s?[^,.;\n]{0,16}\b(?:manufactur\w*|maker|supplier|factory)\b/.test(value)) return 'industrial';
  if (/摄影师|摄影|\b(?:photographer|photography|photo portfolio)\b/.test(value)) return 'photography';
  if (/咖啡(?!机)|\b(?:coffee shop|cafe|café|coffeehouse|coffee brand)\b/.test(value)) return 'cafe';
  if (/机械|设备制造|工业设备|装备制造|塑料再生|造粒|挤出|生产线|\b(?:machinery|industrial equipment|manufactur(?:er|ing)|factory|extruders?|recycling equipment|production line)\b/.test(value)) return 'industrial';
  return null;
}

/** Prefer the explicit subject of "a website for X" to photography subjects,
 * furniture, customers and decorative styles mentioned later in the request.
 * This returns a business inference only; explicit user style choices remain
 * the caller's responsibility and are never rewritten here. */
export function explicitWebsiteIntent(request: string): ExplicitWebsiteIntent | null {
  const normalized = request.normalize('NFKC').toLowerCase()
    .replace(/(?:不要|不需要|不做|无需|不是|别做)[^，,。；;\n]{0,60}/g, ' ')
    .replace(/\b(?:not|no|without)\s+(?:an?\s+)?(?:coffee shop|caf[eé]|photography portfolio|industrial|machinery)\b/g, ' ');
  for (const clause of normalized.split(/[，,。；;\n]/)) {
    const site = siteNoun.exec(clause);
    if (!site) continue; // A style-only preface is not the business being built.
    const target = clause.slice(0, site.index + site[0].length);
    if (specialPurpose.test(target)) return 'other';
    // A portfolio requested for a different business keeps the existing
    // portfolio classifier, instead of turning into a cafe/company website.
    if (/作品集|\bportfolio\b/.test(target) && !/摄影|\b(?:photo(?:graphy|grapher)?|photographer)\b/.test(target)) return 'other';
    const owner = /(?:给|为|替|帮)(.{1,80}?)(?:制作|创建|设计|搭建|做|建)/.exec(target)?.[1];
    const forSubject = /\b(?:website|web site|site|portfolio)\s+for\s+(.+)/.exec(clause)?.[1]
      ?.split(/\b(?:with|featuring|showcasing|about)\b/)[0];
    const subject = owner || forSubject || target;
    if (specialPurpose.test(subject)) return 'other';
    const kind = subjectKind(subject);
    if (kind) return kind;
    // Do not reinterpret a later customer's/example's site as the main task.
    return null;
  }
  return null;
}

export type WebsiteKind = 'industrial-b2b'|'local-hospitality'|'portfolio-studio'|'software-product'|'professional-service'|'brand-commerce'|'education-community'|'event-campaign'|'general';
/** Website purpose wins over incidental subjects, customers and decorative style.
 * This inference chooses content responsibilities, never a palette or template. */
export function inferWebsiteKind(request:string):{kind:WebsiteKind;subtype:string|null}{
 const normalized=request.normalize('NFKC').toLowerCase().replace(/(?:不要|不需要|不做|无需|不是|别做)[^，,。；;\n]{0,60}/g,' ')
  .replace(/\b(?:not|no|without)\s+(?:an?\s+)?(?:coffee shop|caf[eé]|photography portfolio|industrial|machinery)\b/g,' ');
 const text=normalized.split(/(?:[，,；;]\s*(?:包含|包括|附带|加上|带有)|\bwith\s+(?:an?\s+)?(?:gallery|portfolio|blog|help center)\b)/)[0];
 const explicit=explicitWebsiteIntent(request);
 if(explicit==='industrial')return {kind:'industrial-b2b',subtype:'equipment'};
 if(explicit==='cafe')return {kind:'local-hospitality',subtype:'cafe'};
 if(explicit==='photography')return {kind:'portfolio-studio',subtype:'photography'};
 // Knowledge/report sites retain their own purpose instead of becoming the
 // industry whose subjects they discuss. A model resolves their full brief.
 if(/知识库|文档|帮助中心|手册|报告|数据可视化|\b(?:documentation|knowledge base|help cent(?:er|re)|reports?|data stor(?:y|ies))\b/.test(text))return {kind:'general',subtype:'content'};
 if(/作品集|设计工作室|品牌设计|创意工作室|摄影|\b(?:portfolio|design studio|creative studio|photograph\w*)\b/.test(text))return {kind:'portfolio-studio',subtype:/摄影|\bphoto/.test(text)?'photography':'design'};
 if(/商城|商店|电商|商品目录|产品目录|商品品牌|服装|珠宝|护肤|\b(?:e-?commerce|storefront|product catalog\w*|consumer brand|jewellery|apparel)\b/.test(text))return {kind:'brand-commerce',subtype:'product'};
 if(/机械|设备|工业|精密|制造|工厂|生产线|\b(?:machinery|equipment|industrial|manufactur\w*|factory)\b/.test(text))return {kind:'industrial-b2b',subtype:'equipment'};
 if(/民宿|酒店|旅馆|度假|\b(?:hotel|homestay|guesthouse|hospitality|resort)\b/.test(text))return {kind:'local-hospitality',subtype:'stay'};
 if(/咖啡|餐饮|餐厅|烘焙|茶馆|\b(?:cafe|café|coffee shop|restaurant|bakery)\b/.test(text))return {kind:'local-hospitality',subtype:'cafe'};
 if(/花店|理发|美容|家政|维修服务|本地服务|\b(?:local service|salon|florist|cleaning service)\b/.test(text))return {kind:'local-hospitality',subtype:'local'};
 if(/软件|科技|无人机|人工智能|开发工具|\b(?:software|saas|technology|drone|ai product|developer tool)\b/.test(text))return {kind:'software-product',subtype:/无人机|\bdrone/.test(text)?'hardware':'software'};
 if(/律师|咨询|会计|顾问|医疗|诊所|专业服务|\b(?:consult\w*|law firm|legal service|account\w*|clinic|professional service)\b/.test(text))return {kind:'professional-service',subtype:null};
 if(/读书会|教育|课程|学习|社群|社区|学校|\b(?:education|course|learning|community|book club|school)\b/.test(text))return {kind:'education-community',subtype:null};
 if(/活动|大会|会议|展览|专题|节日|\b(?:event|conference|exhibition|campaign|festival)\b/.test(text))return {kind:'event-campaign',subtype:null};
 // A vehicle showroom is a consumer-product site even when the user only
 // names a car marque. Preserve full subjects without a marque-specific rule.
 // Service/parts/transport businesses and incidental photography are not a
 // vehicle catalog; earlier explicit industry/content purposes still win.
 if(/汽车|轿车|跑车|乘用车|车型(?:展示|目录)|车辆展示|\b(?:automotive|car|vehicle) (?:brand|showcase|showroom|catalog(?:ue)?|website|site)\b/.test(text)
   && !/汽车(?:配件|零件|维修|修理|保养|租赁|物流|运输)|\b(?:car|vehicle) (?:repair|parts|rental|maintenance|transport)\b/.test(text))return {kind:'brand-commerce',subtype:'vehicle'};
 if(/品牌|商品|\b(?:brand|product)\b/.test(text))return {kind:'brand-commerce',subtype:'product'};
 return {kind:'general',subtype:null};
}
