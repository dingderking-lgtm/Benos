/** Palette-relative surfaces and content compositions. No external stylesheet,
 * fixed page template, placeholder metrics or assumed product functionality. */
export const COHERENCE_VERSION='bnf-coherence-1' as const;
export const COHERENCE_MARKER='/* benos-coherence:1 */';
export const TEXT_COLOR_MARKER='/* benos-text-color:1 */';
type Palette={background:string;surface:string;ink:string;muted:string;accent:string};
type Surface={background:string;ink:string;muted:string;line:string};
function rgb(hex:string){if(!/^#[\da-f]{6}$/i.test(hex))throw new Error('Invalid foundation palette');return [1,3,5].map(start=>parseInt(hex.slice(start,start+2),16));}
function mix(a:string,b:string,weight:number){const x=rgb(a),y=rgb(b);return '#'+x.map((v,i)=>Math.round(v+(y[i]-v)*weight).toString(16).padStart(2,'0')).join('');}
function luminance(hex:string){const [r,g,b]=rgb(hex).map(v=>v/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return .2126*r+.7152*g+.0722*b;}
export function foundationContrast(a:string,b:string){const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
function surface(background:string,palette:Palette):Surface{
 const ink=foundationContrast(palette.ink,background)>=4.5?palette.ink:foundationContrast('#000000',background)>=foundationContrast('#ffffff',background)?'#000000':'#ffffff';
 const softened=mix(background,ink,.72),muted=foundationContrast(palette.muted,background)>=4.5?palette.muted:foundationContrast(softened,background)>=4.5?softened:ink;
 return {background,ink,muted,line:mix(background,ink,.22)};
}
export function foundationSurfaces(palette:Palette){
 const dark=luminance(palette.background)<.3;
 // Every shade retains the page/brand hue. Dark sites gain a readable raised
 // plane; light sites gain a gentle tinted plane, not an unrelated dark stripe.
 let tone=mix(palette.background,palette.accent,dark?.13:.075);
 let raised=dark?mix(tone,'#ffffff',.065):mix(palette.surface,'#ffffff',.45);
 const deep=dark?mix(palette.background,'#000000',.24):mix(palette.accent,'#10151d',.82);
 const candidates=[palette.ink,'#000000','#ffffff'];
 if(!candidates.some(ink=>[palette.background,tone,raised].every(bg=>foundationContrast(ink,bg)>=4.5))){
  const readable=candidates.find(ink=>foundationContrast(ink,palette.background)>=4.5)!;
  const safeShade=(shade:string)=>{for(let step=0;step<=10;step++){const next=mix(shade,palette.background,step/10);if(foundationContrast(readable,next)>=4.5)return next;}return palette.background;};
  tone=safeShade(tone);raised=safeShade(raised);
 }
 const toneSurface=surface(tone,palette),raisedSurface=surface(raised,palette),deepSurface=surface(deep,palette),deepRaised=surface(mix(deep,'#ffffff',.055),palette);
 // Existing bnf-card / bnf-surface only change their fill. Parent scopes must
 // therefore provide text that is readable on both their own and nested fill.
 const sharedInk=[palette.ink,'#000000','#ffffff'].find(ink=>[palette.background,tone,raised].every(bg=>foundationContrast(ink,bg)>=4.5))??toneSurface.ink;
 const sharedMuted=[palette.muted,mix(tone,sharedInk,.72),sharedInk].find(ink=>[palette.background,tone,raised].every(bg=>foundationContrast(ink,bg)>=4.5))!;
 toneSurface.ink=raisedSurface.ink=sharedInk;toneSurface.muted=raisedSurface.muted=sharedMuted;
 deepSurface.ink=deepRaised.ink;deepSurface.muted=deepRaised.muted;
 return {tone:toneSurface,raised:raisedSurface,deep:deepSurface,deepRaised};
}
/** Keep an existing readable accent, otherwise choose its nearest readable tint
 * or shade. These are text colors; the brand/button fill is never changed. */
export function readableAccentText(accent:string,backgrounds:readonly string[]):string{
 const readable=(value:string)=>backgrounds.every(background=>foundationContrast(value,background)>=4.5);
 if(readable(accent))return accent;
 const candidates:string[]=[];
 for(const end of ['#000000','#ffffff'])for(let step=1;step<=255;step++){const candidate=mix(accent,end,step/255);if(readable(candidate)){candidates.push(candidate);break;}}
 if(!candidates.length){
  // Arbitrary custom backgrounds can straddle incompatible luminance ranges.
  // The caller must validate those separately; no shared color can solve them.
  return readableAccentText(accent,[backgrounds[0]]);
 }
 const original=rgb(accent),distance=(value:string)=>rgb(value).reduce((sum,n,index)=>sum+(n-original[index])**2,0);
 return candidates.sort((a,b)=>distance(a)-distance(b))[0];
}
export type TextColorBackgrounds={surface?:string;tone?:string;raised?:string;deep?:string;deepRaised?:string;page?:string};
export function foundationTextColors(palette:Palette,retained:TextColorBackgrounds={}){
 const shades=foundationSurfaces(palette),backgrounds={base:palette.background,surface:palette.surface,tone:shades.tone.background,raised:shades.raised.background,deep:shades.deep.background,deepRaised:shades.deepRaised.background,...retained};
 return {base:readableAccentText(palette.accent,[backgrounds.base]),surface:readableAccentText(palette.accent,[backgrounds.surface]),tone:readableAccentText(palette.accent,[backgrounds.tone]),raised:readableAccentText(palette.accent,[backgrounds.raised]),deep:readableAccentText(palette.accent,[backgrounds.deep]),deepRaised:readableAccentText(palette.accent,[backgrounds.deepRaised]),bridge:readableAccentText(palette.accent,[backgrounds.page??backgrounds.base,backgrounds.tone])};
}
export function foundationTextColorTokens(palette:Palette,retained:TextColorBackgrounds={}){
 return ':root{'+Object.entries(foundationTextColors(palette,retained)).map(([name,value])=>`--bnf-${name==='base'?'':name.replace(/[A-Z]/g,letter=>'-'+letter.toLowerCase())+'-'}accent-text:${value}`).join(';')+'}';
}
export function designTextColorCss(palette:Palette){return `${TEXT_COLOR_MARKER}
${foundationTextColorTokens(palette)}
.bnf-accent-text{color:var(--bnf-accent-text)}.bnf-surface,.bnf-card,.bnf-cta,.bnf-nav-float{--bnf-accent-text:var(--bnf-surface-accent-text)}.bnf-tone{--bnf-accent-text:var(--bnf-tone-accent-text);--bnf-surface-accent-text:var(--bnf-raised-accent-text)}.bnf-panel,.bnf-workbench>*{--bnf-accent-text:var(--bnf-raised-accent-text);--bnf-surface-accent-text:var(--bnf-raised-accent-text)}.bnf-inverse{--bnf-accent-text:var(--bnf-deep-accent-text);--bnf-raised-accent-text:var(--bnf-deep-raised-accent-text);--bnf-surface-accent-text:var(--bnf-deep-raised-accent-text)}.bnf-bridge{--bnf-accent-text:var(--bnf-bridge-accent-text);--bnf-surface-accent-text:var(--bnf-raised-accent-text)}.bnf-hero-band{--bnf-accent-text:var(--bnf-accent-ink)}`;}
export const TEXT_COLOR_CLASS_GUIDE='正文强调：小字、编号、文字链接需品牌感时用 bnf-accent-text 或 color:var(--bnf-accent-text)，它按内置底色提供≥4.5的可读文字色；--bnf-accent 只作按钮/装饰填色，不直接给小字上色。tone/panel/inverse/bridge会切换对应文字色，按钮仍沿用品牌填色。自行改背景（含页脚）时必须另选可读的正文、辅助和强调文字色；图片/渐变叠字也需按实际画面检查，不能假定原token仍可读。';
export function designCoherenceCss(palette:Palette){
 const shades=foundationSurfaces(palette),tokens=Object.entries(shades).map(([key,value])=>{const name=key.replace(/[A-Z]/g,letter=>'-'+letter.toLowerCase());return `--bnf-${name}:${value.background};--bnf-${name}-ink:${value.ink};--bnf-${name}-muted:${value.muted};--bnf-${name}-line:${value.line}`;}).join(';');
 const scope=(name:'tone'|'raised'|'deep')=>`--bnf-bg:var(--bnf-${name});--bnf-ink:var(--bnf-${name}-ink);--bnf-muted:var(--bnf-${name}-muted);--bnf-line:var(--bnf-${name}-line);background:var(--bnf-bg);color:var(--bnf-ink)`;
 return `${COHERENCE_MARKER}
:root{--bnf-page-bg:${palette.background};${tokens}}
.bnf-tone{${scope('tone')};--bnf-surface:var(--bnf-raised)}.bnf-panel{${scope('raised')};padding:clamp(24px,3.5vw,48px);border:1px solid var(--bnf-line);border-radius:var(--bnf-radius)}.bnf-inverse{${scope('deep')};--bnf-raised:var(--bnf-deep-raised);--bnf-raised-ink:var(--bnf-deep-raised-ink);--bnf-raised-muted:var(--bnf-deep-raised-muted);--bnf-raised-line:var(--bnf-deep-raised-line);--bnf-surface:var(--bnf-raised)}.bnf-bridge{${scope('tone')};background:linear-gradient(180deg,var(--bnf-page-bg),var(--bnf-tone))}
.bnf-chapter{display:grid;grid-template-columns:minmax(160px,.55fr) minmax(0,1.45fr);gap:var(--bnf-gap);align-items:start}.bnf-chapter>*{min-width:0}.bnf-sequence{list-style:none;margin:0;padding:0;counter-reset:sequence}.bnf-sequence>li{counter-increment:sequence;position:relative;isolation:isolate;padding-block:0 32px;padding-inline:52px 0;min-height:52px}.bnf-sequence>li::before{content:counter(sequence,decimal-leading-zero);position:absolute;inset-inline-start:0;top:0;display:grid;place-items:center;width:32px;height:32px;border:1px solid var(--bnf-line);border-radius:50%;background:var(--bnf-bg);color:var(--bnf-ink);font-size:13px;font-weight:650}.bnf-sequence>li:not(:last-child)::after{content:"";position:absolute;z-index:-1;inset-inline-start:15px;top:32px;bottom:0;width:1px;background:var(--bnf-line)}.bnf-sequence>li:last-child{padding-block-end:0}.bnf-sequence p{max-width:38em;margin-block-start:8px}
.bnf-workbench{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr));gap:1px;border:1px solid var(--bnf-line);border-radius:var(--bnf-radius);overflow:hidden;background:var(--bnf-line)}.bnf-workbench>*{${scope('raised')};min-width:0;padding:clamp(20px,3vw,36px)}.bnf-workbench h3{font-size:clamp(20px,2vw,26px)}.bnf-workbench p{margin-block-start:16px;max-width:32em}.bnf-workbench pre{max-width:100%;white-space:pre-wrap;overflow-wrap:anywhere;font:inherit;font-size:14px}.bnf-outcome{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:var(--bnf-gap);align-items:start;padding-block:32px;border-block-start:1px solid var(--bnf-line)}.bnf-outcome>*{min-width:0}
@media(max-width:960px){.bnf-chapter{grid-template-columns:minmax(0,1fr);gap:32px}.bnf-outcome{grid-template-columns:minmax(0,1fr);gap:24px}}@media(max-width:640px){.bnf-workbench{grid-template-columns:minmax(0,1fr)}.bnf-sequence>li{padding-inline-start:44px;padding-inline-end:0}}`;
}
export const COHERENCE_CLASS_GUIDE=`同调层次：bnf-tone 是同色相章节面，bnf-panel 是局部嵌入说明/图例，bnf-bridge 从页面底色自然过渡到tone；bnf-inverse也沿用品牌色相。先用内容尺度、对齐与构图建立节奏，不逐段明暗翻转，不每段套panel。
语义组合（可选，非固定模板）：bnf-chapter 内放侧标题+主内容；bnf-sequence 用ol/li连接具体工作步骤；bnf-workbench 内放带小标题的输入/处理/结果示例；bnf-outcome 放结果说明+上下文。没有真实界面时做清楚标注的概念流程/对象关系，不冒充已上线功能，不用通用团队合照代替产品解释。相邻章节延续一个业务对象/问题，再按信息用途改变构图，保持主要视觉语言一致。`;
