/** Original creative responsibilities derived from primary-source research in
 * creative-direction-sources.txt. No copied assets, fixed page sequence, or
 * additional provider call: persist this small snapshot with a new-site brief. */
export const CREATIVE_DIRECTION_VERSION = 'cd-1' as const;

export interface CreativeDirectionInput {
  hasExistingSite: boolean;
  scope?: 'site' | 'page' | 'node';
  referenceImageCount?: number;
  stylePreference?: string;
}

export interface CreativeDirection {
  version: typeof CREATIVE_DIRECTION_VERSION;
  /** Tracks the explicit preference field, not whether the full request also
   * contains brand constraints. Both always take priority over suggestions. */
  styleSource: 'user' | 'automatic';
  judgment: string;
  brandExpression: string;
  composition: string;
  imagery: string;
  rhythm: string;
  internationalization: string;
  boundaries: string;
}

/** Industry informs what visitors must understand, not a compulsory aesthetic.
 * The model resolves these responsibilities against the full request and the
 * selected foundation. This helper neither reselects tokens nor replans edits. */
export function createCreativeDirection(input: CreativeDirectionInput): CreativeDirection | null {
  if (input.hasExistingSite || (input.scope && input.scope !== 'site')) return null;
  const suppliedStyle = !!input.stylePreference?.trim();
  const hasReferences = Number.isFinite(input.referenceImageCount) && input.referenceImageCount! > 0;
  return {
    version: CREATIVE_DIRECTION_VERSION,
    styleSource: suppliedStyle ? 'user' : 'automatic',
    judgment: '平台主动完成专业判断，普通用户不必提供设计术语。行业只决定信息责任：工业不必蓝灰，医疗不必卡片，软件不必霓虹。以完整需求、明确品牌和用户风格为准；选中方向是起点，不为跨界而更换业务。',
    brandExpression: '从产品形态、材料、工作方法或品牌语气提炼一个有内容依据的视觉母题，用字级、对齐、图像尺度与留白发展识别；可克制也可鲜明，不靠堆装饰或换颜色冒充创意。',
    composition: '按信息关系选取重组：产品与注解同场、主张与证据错位、编辑式图文穿插、连续过程带、内容索引、尺度对比或留白张力。保留清晰阅读次序；它们不是必选区块或固定页序，不把全页套成标题加等宽卡片。',
    imagery: (hasReferences ? '先辨认上传是品牌、作品、产品还是参考，不照抄他站整页。' : '没有上传也应判断图像任务。') + '主视觉解释具体对象、用途或体验，构图呼应母题；实物主体完整、细节图说明差别。软件可用有语义的原生工作流示例；概念图不得冒充真实界面、产品或客户成果。',
    rhythm: '重点允许大胆尺度，信息密集处用紧凑对照、索引或注解，短内容及时收束。保持整页色调与视觉语法连贯，不靠突兀深浅切换、空白大屏或连续相同构图制造节奏。',
    internationalization: '按用户指定或项目语言写作，不因“出海”擅改英文；长品牌、译文增长和非拉丁字形均需换行适配。RTL 用语义 dir 与逻辑方向属性，隔离号码/型号的双向文本，不镜像产品图；语言入口只链接真实版本。',
    boundaries: '先说清提供什么和真实下一步，再突破同行习惯。真实证据不足就解释方法，不编认证、客户、交付地区、价格或联系方式；移动阅读、键盘、对比度和减少动态效果不为造型让步。',
  };
}
