import { z } from 'zod';

/** Server-owned, versioned header compiler. This does not upgrade bnc-1 HTML. */
export const SITE_HEADER_VERSION = 'bnh-1' as const;
export const SITE_HEADER_MARKER = '/* benos-site-header:bnh-1 */';
export const HEADER_PATTERNS = ['classic','centered-nav','capsule','centered-brand','floating','overlay','tools','minimal'] as const;
export const EXPERIMENTAL_HEADER_PATTERNS = ['masthead','offset','directory','utility'] as const;
const ALL_PATTERNS = [...HEADER_PATTERNS,...EXPERIMENTAL_HEADER_PATTERNS] as const;
export const HEADER_MOBILE_MODES = ['dropdown','fullscreen','drawer','bottom'] as const;
const text = z.string().trim().min(1).max(100).refine(value => !/[<>\r\n\u0000-\u001f]/u.test(value), 'Use plain text, without HTML or line breaks.');
const href = z.string().min(1).max(2048).refine(value => !/[\s\u0000-\u001f<>\\]/u.test(value) && /^(?:\/(?!\/)|#[A-Za-z0-9_-]|https?:\/\/|mailto:|tel:)/i.test(value), 'Use a safe navigation destination.');
export const siteHeaderSpecSchema = z.object({
  version: z.literal(SITE_HEADER_VERSION),
  pattern: z.enum(['auto',...ALL_PATTERNS]),
  brand: z.object({text,logo:z.object({path:z.string().min(1).max(500),alt:text}).strict().nullable()}).strict(),
  menuId: z.number().int().positive(),
  actions: z.array(z.object({label:text,href,style:z.enum(['primary','text'])}).strict()).max(2),
  options: z.object({mobileMode:z.enum(HEADER_MOBILE_MODES),sticky:z.boolean(),allowFixedOverlay:z.boolean()}).strict(),
}).strict();
export type SiteHeaderSpec = z.infer<typeof siteHeaderSpecSchema>;
export const headerSpecJsonSchema = z.toJSONSchema(siteHeaderSpecSchema);
export type HeaderMenuItem = { id: string | number; label: string; url?: string; href?: string; parent_id?: string | number | null; target?: string; rel?: string };
export type HeaderMenu = { id: number; items: HeaderMenuItem[]; [key: string]: unknown };
export type SiteHeaderContext = {
  seed: string;
  menus: readonly HeaderMenu[];
  homeHref?: string;
  language?: string;
  siteKind?: string;
  styleId?: string;
  heroPresentation?: 'standard' | 'hero-cover';
  allowFixedOverlay?: boolean;
  allowExperimental?: boolean;
  request?: string;
  verifiedLogoPaths?: readonly string[];
  capabilities?: { search?: {href:string;label:string}; languageSwitch?: readonly {href:string;label:string}[] };
};
export const resolvedSiteHeaderSchema = z.object({
  version:z.literal(SITE_HEADER_VERSION),
  menuId:z.number().int().positive(),
  spec:siteHeaderSpecSchema,
  pattern:z.enum(ALL_PATTERNS),
  mobileMode:z.enum(HEADER_MOBILE_MODES),
  menuLabel:text, moreLabel:text,
  homeHref:href,
  language:z.string().max(40),
  selection:z.object({seed:z.string().max(300),eligible:z.array(z.enum(ALL_PATTERNS)).min(1),topLevelItems:z.number().int().nonnegative(),hasSubmenus:z.boolean(),reasons:z.array(z.string().max(240)).max(12)}).strict(),
}).strict();
export type ResolvedSiteHeader = z.infer<typeof resolvedSiteHeaderSchema>;
export type SiteHeaderReceipt = {
  version:typeof SITE_HEADER_VERSION; pattern:ResolvedSiteHeader['pattern']; mobileMode:ResolvedSiteHeader['mobileMode']; menuId:number;
  bindings:number; dynamicSubmenus:'visible-hierarchy-in-menu-panels'; noJavaScript:true;
  modal:false; escapeCloses:false; backgroundInert:false; degrades:string[];
};
const esc = (value:string) => value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const hash = (value:string) => {let n=2166136261;for(const ch of value){n^=ch.codePointAt(0)!;n=Math.imul(n,16777619);}return n>>>0;};
const experimentalRequests={masthead:/杂志|刊头|报头|mastheads?|magazine/i,offset:/错位|非对称|不对称|实验|offset|asymmetr\w*|experimental/i,directory:/目录式|目录型|目录页头|directory\s*(?:header|navigation)/i,utility:/辅助栏|服务栏|双层页头|工具栏页头|utility\s*(?:bar|header)|two[- ]tier\s*header/i};
/** Only a positive clause in the user's request grants an experimental mode. */
export function explicitlyRequestsHeaderPattern(pattern:typeof EXPERIMENTAL_HEADER_PATTERNS[number],request:string):boolean{
  const negative=/(?:不要|不想|避免|不用|别|无需|拒绝|取消|不采用|不使用|\bdo\s+not\b|\bdon't\b|\bnot\b|\bno\b|\bwithout\b|\bavoid\b|\bnever\b)[^,，。;；!！?？\n]{0,24}$/i;
  return request.split(/[,，。;；!！?？\n]|\bbut\b|\binstead\b|而是|但是|但/u).some(clause=>{
    const match=experimentalRequests[pattern].exec(clause);if(!match)return false;
    if(negative.test(clause.slice(0,match.index)))return false;
    const after=clause.slice(match.index+match[0].length);
    return !/^(?:\s*(?:风格|页头|式|is|are))*\s*(?:不要|不用|不需要|不采用|不使用|not\b|isn't\b|is\s+not\b)/i.test(after);
  });
}
function menuFor(id:number,ctx:SiteHeaderContext){
  const matches=ctx.menus.filter(menu=>menu.id===id);if(matches.length!==1)throw Error('HEADER_MENU_INVALID');
  const menu=matches[0];if(!Array.isArray(menu.items)||menu.items.length>200)throw Error('HEADER_MENU_INVALID');
  const ids=new Set<string>();
  for(const item of menu.items){
    const id=String(item.id);if(!id||ids.has(id)||!text.safeParse(item.label).success||!href.safeParse(item.url??item.href).success)throw Error('HEADER_MENU_INVALID');ids.add(id);
  }
  for(const item of menu.items){if(item.parent_id!==undefined&&item.parent_id!==null&&item.parent_id!==''&&!ids.has(String(item.parent_id)))throw Error('HEADER_MENU_INVALID');}
  const parent=(item:HeaderMenuItem)=>item.parent_id===undefined||item.parent_id===null||item.parent_id===''?null:String(item.parent_id);
  for(const item of menu.items){const seen=new Set([String(item.id)]);let p=parent(item);while(p!==null){if(seen.has(p))throw Error('HEADER_MENU_INVALID');seen.add(p);p=parent(menu.items.find(i=>String(i.id)===p)!);if(seen.size>4)throw Error('HEADER_MENU_DEPTH');}}
  return menu;
}
function labels(language:string){
  if(/^zh/i.test(language))return {menuLabel:/tw|hk|hant/i.test(language)?'選單':'菜单',moreLabel:'更多'};
  if(/^de/i.test(language))return {menuLabel:'Menü',moreLabel:'Mehr'};
  if(/^ar/i.test(language))return {menuLabel:'القائمة',moreLabel:'المزيد'};
  if(/^fr/i.test(language))return {menuLabel:'Menu',moreLabel:'Plus'};
  return {menuLabel:'Menu',moreLabel:'More'};
}
/** Resolve once before generation. Persist this result and the compiled bytes. */
export function resolveSiteHeader(value:unknown,ctx:SiteHeaderContext):ResolvedSiteHeader{
  const spec=siteHeaderSpecSchema.parse(value),menu=menuFor(spec.menuId,ctx),reasons:string[]=[];
  if(spec.brand.logo&&!ctx.verifiedLogoPaths?.includes(spec.brand.logo.path))throw Error('HEADER_LOGO_NOT_VERIFIED');
  if(spec.actions.filter(action=>action.style==='primary').length>1)throw Error('HEADER_PRIMARY_ACTION_LIMIT');
  const roots=menu.items.filter(item=>item.parent_id===undefined||item.parent_id===null||item.parent_id===''),nested=roots.length!==menu.items.length;
  const hint=`${ctx.siteKind||''} ${ctx.styleId||''} ${ctx.request||''}`;
  const eligible:ResolvedSiteHeader['pattern'][]=['classic','centered-nav'];
  if(spec.pattern==='capsule'||/软件|工具|科技|应用|平台|SaaS|software|\btool\b|\bapp\b|\btech\b/i.test(hint))eligible.push('capsule');
  if(spec.pattern==='minimal'||/作品|摄影|极简|portfolio|photograph|minimal/i.test(hint))eligible.push('minimal');
  if(roots.length<=6&&!nested&&(spec.pattern==='centered-brand'||/餐饮|咖啡|生活方式|酒店|民宿|居家|餐厅|cafe|café|restaurant|lifestyle|hotel|\bwarm\b/i.test(hint)))eligible.push('centered-brand');
  if(ctx.heroPresentation==='hero-cover')eligible.push('floating','overlay');
  if(ctx.capabilities?.search||ctx.capabilities?.languageSwitch?.length)eligible.push('tools');
  // Experimental designs require both the server gate and a matching user
  // request. They are never placed in the automatic everyday pool.
  if(spec.pattern!=='auto'&&spec.pattern in experimentalRequests&&ctx.allowExperimental&&explicitlyRequestsHeaderPattern(spec.pattern as keyof typeof experimentalRequests,ctx.request||''))eligible.push(spec.pattern as keyof typeof experimentalRequests);
  let pattern:ResolvedSiteHeader['pattern'];
  if(spec.pattern==='auto')pattern=eligible[hash(ctx.seed)%eligible.length];
  else if(eligible.includes(spec.pattern))pattern=spec.pattern;
  else{pattern='classic';reasons.push(`Requested ${spec.pattern} is not eligible; kept the classic layout.`);}
  // A caller cannot enable fixed panels solely by accepting model JSON.
  const mobileMode=spec.options.mobileMode==='dropdown'||spec.options.allowFixedOverlay&&ctx.allowFixedOverlay?spec.options.mobileMode:'dropdown';
  if(mobileMode!==spec.options.mobileMode)reasons.push('Fixed panel permission was absent; used a dropdown.');
  if(nested)reasons.push('Dynamic CMS submenus are a visible hierarchy inside menu panels, not nested accordions.');
  if(EXPERIMENTAL_HEADER_PATTERNS.includes(pattern as typeof EXPERIMENTAL_HEADER_PATTERNS[number]))reasons.push('Explicit experimental header: the ordinary desktop single-row height target does not apply.');
  if(pattern==='overlay')reasons.push('Overlay uses a transparent outer header with an opaque readable navigation face; it does not promise photo-dependent text contrast.');
  const language=ctx.language||'en';
  return resolvedSiteHeaderSchema.parse({version:SITE_HEADER_VERSION,menuId:spec.menuId,spec,pattern,mobileMode,...labels(language),homeHref:ctx.homeHref||'/',language,selection:{seed:ctx.seed,eligible,topLevelItems:roots.length,hasSubmenus:nested,reasons}});
}
function menuHtml(menu:HeaderMenu){
  const children=new Map<string,HeaderMenuItem[]>();
  for(const item of menu.items){const p=item.parent_id===undefined||item.parent_id===null||item.parent_id===''?'':String(item.parent_id);children.set(p,[...(children.get(p)||[]),item]);}
  const render=(parent:string,depth=0):string=>'<ul class="'+(depth?'aacms-nav-submenu':'aacms-nav-list')+'">'+(children.get(parent)||[]).map(item=>{
    const nested=children.has(String(item.id)),target=item.target==='_blank'?' target="_blank" rel="noopener noreferrer"':'';
    return '<li class="aacms-nav-item'+(nested?' aacms-nav-has-children':'')+'"><a class="aacms-nav-link" href="'+esc(item.url??item.href!)+'"'+target+'>'+esc(item.label)+'</a>'+(nested?render(String(item.id),depth+1):'')+'</li>';
  }).join('')+'</ul>';
  return render('');
}
function longestWordUnits(value:string){
  // Conservative CSS fitting hint, not a browser text measurement. Break only
  // at spaces/CJK opportunities; never insert <br>, soft hyphens or <wbr>.
  const units=value.split(/\s+/u).map(word=>Array.from(word).reduce((n,ch)=>n+(/[\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]/u.test(ch)?1:/[MW@%]/.test(ch)?.95:/[ilI1.,']/u.test(ch)?.35:.68),0));
  return Math.max(6,units.reduce((sum,n)=>sum+n+.4,0)/1.65,...units);
}
/** No source selection here: resumed tasks reuse the resolved plan, not a new pool. */
export function compileSiteHeader(value:ResolvedSiteHeader,ctx:SiteHeaderContext):{html:string;css:string;receipt:SiteHeaderReceipt}{
  const resolved=resolvedSiteHeaderSchema.parse(value),{spec,pattern,mobileMode}=resolved,menu=menuFor(spec.menuId,ctx);
  if(resolved.menuId!==spec.menuId)throw Error('HEADER_MENU_INVALID');
  if(mobileMode!=='dropdown'&&(!spec.options.allowFixedOverlay||!ctx.allowFixedOverlay))throw Error('HEADER_FIXED_PANEL_NOT_ALLOWED');
  if(spec.brand.logo&&!ctx.verifiedLogoPaths?.includes(spec.brand.logo.path))throw Error('HEADER_LOGO_NOT_VERIFIED');
  const nav=(className:string,label:string)=>`<nav class="${className}" data-aacms="site-navigation" data-aacms-menu="${spec.menuId}" data-aacms-menu-markup="flat" aria-label="${esc(label)}">${menuHtml(menu)}</nav>`;
  const actionHtml=spec.actions.map(action=>`<a class="bnh-action bnh-action-${action.style}" href="${esc(action.href)}">${esc(action.label)}</a>`).join('');
  const brand=spec.brand.logo?`<img src="${esc(spec.brand.logo.path)}" alt="${esc(spec.brand.logo.alt)}" decoding="async">`:`<span class="bnh-brand-text">${esc(spec.brand.text)}</span>`;
  const menuButton=`<span class="bnh-menu-label">${esc(resolved.menuLabel)}</span><span class="bnh-menu-icon" aria-hidden="true"></span>`;
  const more=`<details class="bnh-more"><summary>${esc(resolved.moreLabel)}<span aria-hidden="true">⌄</span></summary><div class="bnh-more-panel">${nav('bnh-more-nav',resolved.moreLabel)}</div></details>`;
  const primary=`<div class="bnh-primary">${nav('bnh-primary-nav',resolved.menuLabel)}${pattern==='centered-brand'?'':more}</div>`;
  const secondary=pattern==='centered-brand'?`<div class="bnh-secondary">${nav('bnh-secondary-nav',resolved.menuLabel)}${more}<div class="bnh-actions">${actionHtml}</div></div>`:`<div class="bnh-actions">${actionHtml}</div>`;
  const tools=pattern==='tools'?'<div class="bnh-tools">'+(ctx.capabilities?.search?`<a class="bnh-tool" href="${esc(href.parse(ctx.capabilities.search.href))}">${esc(text.parse(ctx.capabilities.search.label))}</a>`:'')+(ctx.capabilities?.languageSwitch?.length?`<details class="bnh-language"><summary>Language</summary><div class="bnh-language-panel">${ctx.capabilities.languageSwitch.map(item=>`<a href="${esc(href.parse(item.href))}">${esc(text.parse(item.label))}</a>`).join('')}</div></details>`:'')+'</div>':'';
  const mobile=`<details class="bnh-mobile-menu"><summary>${menuButton}</summary><div class="bnh-mobile-panel">${nav('bnh-mobile-nav',resolved.menuLabel)}${actionHtml?'<div class="bnh-panel-actions">'+actionHtml+'</div>':''}${tools}</div></details>`;
  const html=`<header class="bnh-site-header bnh-${pattern} bnh-mobile-${mobileMode}${spec.options.sticky?' bnh-sticky':''}" style="--bnh-brand-units:${longestWordUnits(spec.brand.text).toFixed(2)}"><div class="bnh-frame"><a class="bnh-brand${longestWordUnits(spec.brand.text)>15.5?' bnh-brand-long':''}" href="${esc(resolved.homeHref)}" aria-label="${esc(spec.brand.text)}">${brand}</a>${primary}${tools}${secondary}${mobile}</div></header>`;
  return {html,css:designSiteHeaderCss(),receipt:{version:SITE_HEADER_VERSION,pattern,mobileMode,menuId:spec.menuId,bindings:pattern==='centered-brand'?4:3,dynamicSubmenus:'visible-hierarchy-in-menu-panels',noJavaScript:true,modal:false,escapeCloses:false,backgroundInert:false,degrades:[...resolved.selection.reasons,'Details panels do not provide Escape dismissal, modal focus trapping or background inertness.','CMS nested items remain visible in the More/mobile panels; their original buttons are hidden, not simulated.']}};
}

/** All selectors are scoped to this compiler. Existing bnf/bnc layouts are untouched. */
export function designSiteHeaderCss():string{return `${SITE_HEADER_MARKER}
.bnh-site-header{--bnh-bg:var(--bnf-bg,#fff);--bnh-ink:var(--bnf-ink,#17212b);--bnh-muted:var(--bnf-muted,#536171);--bnh-line:var(--bnf-line,#d7dce2);position:relative;z-index:20;background:var(--bnh-bg);color:var(--bnh-ink);font-family:var(--bnf-body,system-ui);font-size:15px;line-height:1.4;text-align:start}.bnh-site-header *{box-sizing:border-box}.bnh-site-header a{color:inherit;text-decoration:none}.bnh-site-header :where(a,summary):focus-visible{outline:3px solid currentColor;outline-offset:3px;box-shadow:0 0 0 2px var(--bnh-bg)}.bnh-frame{width:min(var(--bnf-container,1280px),calc(100% - 48px));margin-inline:auto;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,2fr) auto;align-items:center;gap:24px;min-height:80px;padding-block:10px}.bnh-brand{display:block;min-width:0;max-width:280px;font-family:var(--bnf-heading,system-ui);font-size:24px;font-weight:700;line-height:1.1;overflow-wrap:normal;word-break:normal;white-space:normal}.bnh-brand-text{overflow-wrap:normal;word-break:normal;white-space:normal}.bnh-brand img{display:block;max-width:min(200px,100%);max-height:36px;width:auto;height:auto;object-fit:contain}.bnh-primary,.bnh-secondary,.bnh-actions,.bnh-tools{display:flex;align-items:center;gap:16px;min-width:0}.bnh-primary{justify-content:flex-end}.bnh-primary-nav,.bnh-secondary-nav{min-width:0}.bnh-site-header nav ul{list-style:none;margin:0;padding:0}.bnh-primary-nav,.bnh-secondary-nav,.bnh-primary-nav>.aacms-nav-list,.bnh-secondary-nav>.aacms-nav-list{display:flex;align-items:center;gap:20px;min-width:0}.bnh-primary-nav>.aacms-nav-list>.aacms-nav-item,.bnh-secondary-nav>.aacms-nav-list>.aacms-nav-item{display:block;min-width:0}.bnh-primary-nav>a,.bnh-secondary-nav>a,.bnh-primary-nav>.aacms-nav-list>.aacms-nav-item>a,.bnh-secondary-nav>.aacms-nav-list>.aacms-nav-item>a{display:block;min-height:44px;max-width:14ch;line-height:44px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bnh-site-header a[aria-current=page]{text-decoration:underline;text-underline-offset:5px}.bnh-primary-nav a:hover,.bnh-secondary-nav a:hover{text-decoration:underline;text-underline-offset:5px}.bnh-actions{justify-content:flex-end;white-space:nowrap}.bnh-action,.bnh-tool{display:inline-flex;align-items:center;justify-content:center;min-height:44px;gap:8px;line-height:1.25;padding:10px 16px;border-radius:999px;font-weight:600}.bnh-action-primary{background:var(--bnf-accent,#17212b);color:var(--bnf-accent-ink,#fff)!important}.bnh-action-text{padding-inline:4px}.bnh-site-header summary{cursor:pointer;list-style:none;min-height:44px;align-items:center;gap:8px;line-height:1.4}.bnh-site-header summary::-webkit-details-marker{display:none}.bnh-more,.bnh-language{position:relative;min-width:0}.bnh-more{display:none}.bnh-more>summary,.bnh-language>summary{display:flex;white-space:nowrap}.bnh-more-panel,.bnh-language-panel{position:absolute;right:0;top:100%;z-index:50;min-width:220px;width:max-content;max-width:min(400px,calc(100vw - 32px));max-height:70vh;overflow:auto;padding:16px;border:1px solid var(--bnh-line);border-radius:14px;background:var(--bnh-bg);box-shadow:0 12px 36px #0002;color:var(--bnh-ink)}.bnh-language-panel a{display:flex;align-items:center;min-height:44px}.bnh-site-header .aacms-nav-toggle{display:none!important}.bnh-primary-nav .aacms-nav-submenu,.bnh-secondary-nav .aacms-nav-submenu{display:none!important}.bnh-more-nav .aacms-nav-submenu,.bnh-mobile-nav .aacms-nav-submenu,.bnh-more-nav .aacms-nav-submenu[hidden],.bnh-mobile-nav .aacms-nav-submenu[hidden]{display:block!important;position:static!important;min-width:0;width:100%;max-width:100%;padding:0 0 0 16px;margin:0;border:0;box-shadow:none;background:transparent;visibility:visible;opacity:1}.bnh-more-nav .aacms-nav-item,.bnh-mobile-nav .aacms-nav-item{display:block;min-width:0}.bnh-more-nav a,.bnh-mobile-nav a{display:flex;align-items:center;min-height:44px;padding:10px 8px;line-height:1.4;white-space:normal;overflow-wrap:break-word;word-break:normal}.bnh-more-nav>a,.bnh-mobile-nav>a{width:100%}.bnh-primary-nav>a:nth-child(n+7),.bnh-primary-nav>.aacms-nav-list>.aacms-nav-item:nth-child(n+7),.bnh-secondary-nav>a:nth-child(n+7),.bnh-secondary-nav>.aacms-nav-list>.aacms-nav-item:nth-child(n+7){display:none}.bnh-site-header:has(.bnh-primary-nav>a:nth-child(7),.bnh-primary-nav>.aacms-nav-list>.aacms-nav-item:nth-child(7),.bnh-primary-nav .aacms-nav-has-children) .bnh-more{display:block}.bnh-site-header:not(:has(.aacms-nav-has-children)) .bnh-more-nav>a:nth-child(-n+6),.bnh-site-header:not(:has(.aacms-nav-has-children)) .bnh-more-nav>.aacms-nav-list>.aacms-nav-item:nth-child(-n+6){display:none}.bnh-mobile-menu{display:none}.bnh-sticky{position:sticky;top:0}.bnh-centered-nav .bnh-primary{justify-content:center}.bnh-capsule .bnh-primary{justify-self:center;padding:3px 18px;border:1px solid var(--bnh-line);border-radius:999px;gap:14px;background:var(--bnf-surface,var(--bnh-bg))}.bnh-capsule .bnh-primary a[aria-current=page]{background:var(--bnh-ink);color:var(--bnh-bg);padding-inline:12px;border-radius:999px;text-decoration:none}.bnh-centered-brand .bnh-frame{grid-template-columns:minmax(0,1fr) auto minmax(0,1fr)}.bnh-centered-brand .bnh-brand{grid-column:2;grid-row:1;text-align:center;max-width:240px}.bnh-centered-brand .bnh-primary{grid-column:1;grid-row:1;justify-content:flex-start}.bnh-centered-brand .bnh-secondary{grid-column:3;grid-row:1;justify-content:flex-end}.bnh-centered-brand .bnh-primary-nav>a:nth-child(n+4),.bnh-centered-brand .bnh-primary-nav>.aacms-nav-list>.aacms-nav-item:nth-child(n+4),.bnh-centered-brand .bnh-secondary-nav>a:nth-child(-n+3),.bnh-centered-brand .bnh-secondary-nav>.aacms-nav-list>.aacms-nav-item:nth-child(-n+3){display:none}.bnh-floating{margin:16px 16px -96px;border:1px solid var(--bnh-line);border-radius:20px;box-shadow:0 10px 30px #0001}.bnh-floating .bnh-frame{width:calc(100% - 40px)}.bnh-overlay{margin-bottom:-80px;background:transparent}.bnh-overlay .bnh-frame{padding-inline:20px;border-radius:0 0 18px 18px;background:var(--bnh-bg)}.bnh-tools .bnh-frame{grid-template-columns:minmax(0,1fr) minmax(0,2fr) auto auto}.bnh-tools .bnh-tools{gap:8px}.bnh-minimal .bnh-frame{grid-template-columns:minmax(0,1fr) auto}.bnh-minimal .bnh-primary,.bnh-minimal .bnh-frame>.bnh-actions{display:none}.bnh-minimal .bnh-mobile-menu{display:block}.bnh-mobile-menu>summary{display:flex;justify-content:flex-end;gap:10px;min-width:44px;padding:0}.bnh-menu-label,.bnh-menu-icon{position:relative;z-index:53}.bnh-menu-icon{display:block;width:22px;height:16px;border-top:2px solid currentColor;border-bottom:2px solid currentColor}.bnh-menu-icon::after{content:"";position:absolute;left:0;right:0;top:5px;border-top:2px solid currentColor}.bnh-mobile-menu[open] .bnh-menu-icon{border:0}.bnh-mobile-menu[open] .bnh-menu-icon::before,.bnh-mobile-menu[open] .bnh-menu-icon::after{content:"";position:absolute;left:0;right:0;top:7px;border-top:2px solid currentColor;transform:rotate(45deg)}.bnh-mobile-menu[open] .bnh-menu-icon::after{transform:rotate(-45deg)}.bnh-mobile-panel{position:absolute;z-index:52;top:100%;left:0;right:0;padding:20px 24px;background:var(--bnh-bg);color:var(--bnh-ink);border-top:1px solid var(--bnh-line);box-shadow:0 14px 24px #0001;max-height:calc(100vh - 96px);overflow:auto}.bnh-panel-actions{display:flex;flex-wrap:wrap;gap:12px;padding-top:16px;margin-top:12px;border-top:1px solid var(--bnh-line)}.bnh-mobile-panel .bnh-tools{display:flex;flex-wrap:wrap}.bnh-mobile-fullscreen .bnh-mobile-panel,.bnh-mobile-drawer .bnh-mobile-panel,.bnh-mobile-bottom .bnh-mobile-panel{position:fixed;top:64px;bottom:0;left:0;right:0;max-height:calc(100vh - 64px);border:0}.bnh-mobile-drawer .bnh-mobile-panel{left:auto;width:min(84vw,440px);box-shadow:-12px 0 36px #0003}.bnh-mobile-bottom .bnh-mobile-panel{top:auto;max-height:calc(100vh - 80px);border-radius:24px 24px 0 0;box-shadow:0 -12px 36px #0003}.bnh-mobile-fullscreen .bnh-mobile-menu[open]>summary::before,.bnh-mobile-drawer .bnh-mobile-menu[open]>summary::before,.bnh-mobile-bottom .bnh-mobile-menu[open]>summary::before{content:"";position:fixed;inset:64px 0 0;z-index:51;background:#0005}.bnh-mobile-fullscreen .bnh-mobile-menu[open] .bnh-menu-label,.bnh-mobile-drawer .bnh-mobile-menu[open] .bnh-menu-label,.bnh-mobile-bottom .bnh-mobile-menu[open] .bnh-menu-label{background:var(--bnh-bg)}
@media(max-width:960px){.bnh-frame,.bnh-tools .bnh-frame,.bnh-centered-brand .bnh-frame{width:calc(100% - 32px);grid-template-columns:minmax(0,1fr) auto;min-height:64px;padding-block:10px;gap:12px}.bnh-site-header .bnh-brand{grid-column:1;grid-row:1;max-width:100%;font-size:clamp(14px,calc((100vw - 112px) / var(--bnh-brand-units,12)),24px);line-height:1.1;text-align:start}.bnh-brand img{max-height:32px;max-width:min(180px,100%)}.bnh-site-header .bnh-primary,.bnh-site-header .bnh-secondary,.bnh-site-header .bnh-frame>.bnh-actions,.bnh-site-header .bnh-frame>.bnh-tools{display:none}.bnh-mobile-menu{display:block;grid-column:2;grid-row:1}.bnh-mobile-menu>summary{font-size:14px;min-height:44px}.bnh-floating{margin:12px 12px -76px;border-radius:16px}.bnh-floating .bnh-frame{width:calc(100% - 24px)}.bnh-overlay{margin-bottom:-64px}.bnh-overlay .bnh-frame{padding-inline:8px}.bnh-mobile-panel{padding:16px;max-height:calc(100vh - 64px)}.bnh-capsule .bnh-primary{border:0;padding:0}.bnh-site-header:has(.bnh-mobile-menu[open]){z-index:50}.bnh-mobile-fullscreen .bnh-mobile-menu[open] .bnh-menu-label,.bnh-mobile-drawer .bnh-mobile-menu[open] .bnh-menu-label,.bnh-mobile-bottom .bnh-mobile-menu[open] .bnh-menu-label{display:none}.bnh-mobile-fullscreen .bnh-mobile-menu[open] .bnh-menu-icon,.bnh-mobile-drawer .bnh-mobile-menu[open] .bnh-menu-icon,.bnh-mobile-bottom .bnh-mobile-menu[open] .bnh-menu-icon{position:fixed;top:24px;right:24px}}
.bnh-site-header{font-size:var(--bnf-order-size-aux,14px)}.bnh-site-header nav a,.bnh-site-header .bnh-action,.bnh-site-header summary{min-width:44px}.bnh-site-header .bnh-brand{display:flex;align-items:center;min-height:44px;font-size:var(--bnf-order-size-lead,20px)}.bnh-site-header .bnh-brand-long{font-size:var(--bnf-order-size-body,16px)}.bnh-centered-brand .bnh-brand{justify-content:center}.bnh-site-header:dir(rtl) .bnh-more-panel,.bnh-site-header:dir(rtl) .bnh-language-panel{left:0;right:auto}
@media(min-width:961px){.bnh-masthead .bnh-frame{grid-template-columns:minmax(0,1fr) auto;min-height:136px;padding-block:20px}.bnh-masthead .bnh-brand{grid-column:1/-1;font-size:clamp(32px,4vw,56px);max-width:100%;justify-content:center}.bnh-masthead .bnh-primary{grid-column:1;justify-content:center}.bnh-masthead .bnh-actions{grid-column:2}.bnh-offset .bnh-frame,.bnh-directory .bnh-frame{grid-template-columns:minmax(0,1fr) minmax(0,2fr);min-height:144px;gap:12px 48px;padding-block:20px}.bnh-offset .bnh-brand,.bnh-directory .bnh-brand{grid-column:1;grid-row:1/3;font-size:32px}.bnh-offset .bnh-primary,.bnh-directory .bnh-primary{grid-column:2;grid-row:1;justify-content:flex-start}.bnh-offset .bnh-actions,.bnh-directory .bnh-actions{grid-column:2;grid-row:2;justify-content:flex-start}.bnh-directory .bnh-primary-nav>.aacms-nav-list,.bnh-directory .bnh-primary-nav{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:4px 24px}.bnh-directory .bnh-primary-nav:has(>.aacms-nav-list){display:block}.bnh-directory .bnh-primary-nav a{max-width:100%}.bnh-utility .bnh-frame{grid-template-columns:minmax(0,1fr) minmax(0,2fr);min-height:124px;gap:4px 28px;padding-block:12px}.bnh-utility .bnh-actions{grid-column:1/-1;grid-row:1;justify-content:flex-end;border-bottom:1px solid var(--bnh-line);padding-bottom:6px}.bnh-utility .bnh-brand{grid-column:1;grid-row:2}.bnh-utility .bnh-primary{grid-column:2;grid-row:2}}
@media(max-width:960px){.bnh-site-header .bnh-brand{font-size:clamp(14px,calc((100vw - 112px) / var(--bnh-brand-units,12)),24px);justify-content:flex-start}.bnh-mobile-fullscreen .bnh-mobile-menu[open] .bnh-menu-icon,.bnh-mobile-drawer .bnh-mobile-menu[open] .bnh-menu-icon,.bnh-mobile-bottom .bnh-mobile-menu[open] .bnh-menu-icon{top:10px;right:16px;width:44px;height:44px;background:var(--bnh-bg);border-radius:8px}.bnh-mobile-fullscreen .bnh-mobile-menu[open] .bnh-menu-icon::before,.bnh-mobile-fullscreen .bnh-mobile-menu[open] .bnh-menu-icon::after,.bnh-mobile-drawer .bnh-mobile-menu[open] .bnh-menu-icon::before,.bnh-mobile-drawer .bnh-mobile-menu[open] .bnh-menu-icon::after,.bnh-mobile-bottom .bnh-mobile-menu[open] .bnh-menu-icon::before,.bnh-mobile-bottom .bnh-mobile-menu[open] .bnh-menu-icon::after{top:21px;left:11px;right:11px}}
@media(max-width:960px){.bnh-site-header .bnh-brand{font-size:var(--bnf-order-size-lead,18px)}.bnh-site-header .bnh-brand-long{font-size:var(--bnf-order-size-aux,14px)}.bnh-floating .bnh-frame{min-height:62px;padding-block:9px}}
.bnh-site-header{font-style:normal;font-weight:400;letter-spacing:normal;text-transform:none}.bnh-site-header nav a,.bnh-site-header summary,.bnh-site-header .bnh-tool{font-family:inherit;font-size:inherit;font-style:normal;letter-spacing:normal;text-transform:none}.bnh-site-header nav a{font-weight:400}.bnh-site-header summary{background:transparent;border:0;box-shadow:none}.bnh-site-header summary,.bnh-site-header .bnh-action{font-weight:600}.bnh-site-header .bnh-action{font-family:inherit;font-size:inherit;font-style:normal;letter-spacing:normal;text-transform:none}.bnh-site-header .bnh-brand{font-weight:700;font-style:normal;letter-spacing:normal;text-transform:none}.bnh-site-header .bnh-brand-text,.bnh-site-header .bnh-menu-label{font:inherit;letter-spacing:normal;text-transform:none}
@media(prefers-reduced-motion:reduce){.bnh-site-header *,.bnh-site-header *::before,.bnh-site-header *::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
`;}
