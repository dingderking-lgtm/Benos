import { z } from 'zod';
import { WEB_FONT_FAMILIES, webFontId, webFontUrl } from './design-web-fonts';

export const TYPOGRAPHY_VERSION = 'btf-1' as const;
export type DesignFont = { id: string; label: string; script: 'zh'|'latin'; category: 'sans'|'serif'|'mono'|'display'; stack: string; sampleZh: string; sampleLatin: string; source: 'system'|'google'; stylesheet?: string; legacy?: boolean; recommendedFor: string };
const font = (id:string,label:string,script:DesignFont['script'],category:DesignFont['category'],stack:string,recommendedFor:string):DesignFont => ({id,label,script,category,stack,recommendedFor,sampleZh:'让想法清晰呈现',sampleLatin:'Make ideas clear',source:'system'});
const LEGACY_FONTS:readonly DesignFont[] = [
 font('zh-hei','黑体','zh','sans','"PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "WenQuanYi Micro Hei", sans-serif','中文正文与界面'),
 font('zh-song','宋体','zh','serif','"Songti SC", "Noto Serif CJK SC", SimSun, serif','中文阅读与品牌标题'),
 font('zh-kai','楷体','zh','serif','"Kaiti SC", STKaiti, KaiTi, "Songti SC", SimSun, serif','人文标题与短句'),
 font('system-sans','系统无衬线','latin','sans','system-ui, -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif','商务与通用正文'),
 font('neo-grotesque','新哥特无衬线','latin','sans','Arial, "Helvetica Neue", Helvetica, "PingFang SC", "Microsoft YaHei", sans-serif','简洁品牌与产品'),
 font('humanist-sans','人文无衬线','latin','sans','"Segoe UI", Calibri, "Trebuchet MS", "PingFang SC", "Microsoft YaHei", sans-serif','友好的正文与服务'),
 font('open-sans','宽朗无衬线','latin','sans','"Trebuchet MS", "Gill Sans", Verdana, "PingFang SC", "Microsoft YaHei", sans-serif','宽松清晰的介绍页面'),
 font('transitional-serif','过渡衬线','latin','serif','Georgia, "Times New Roman", "Songti SC", SimSun, serif','品牌与长文阅读'),
 font('book-serif','书籍衬线','latin','serif','"Palatino Linotype", Palatino, "Book Antiqua", Georgia, "Songti SC", SimSun, serif','书籍与编辑阅读'),
 font('modern-serif','现代衬线方向','latin','serif','Didot, "Bodoni MT", "Times New Roman", "Songti SC", SimSun, serif','短品牌标题；本机未安装时使用回退'),
 font('monospace','等宽','latin','mono','"SFMono-Regular", Consolas, "Liberation Mono", Menlo, "Microsoft YaHei", monospace','技术内容与代码'),
 font('bold-display','粗体展示','latin','display','Impact, "Arial Black", Arial, "Microsoft YaHei", sans-serif','短标题；不建议长篇正文'),
 font('industrial-display','工业展示','latin','display','Bahnschrift, "DIN Alternate", "Arial Narrow", Arial, "Microsoft YaHei", sans-serif','工业产品与短标题'),
];
export const DEFAULT_DESIGN_FONT_ID='helvetica';
export const DESIGN_FONT_CATALOG:readonly DesignFont[] = Object.freeze([
 font('helvetica','Helvetica','latin','sans','Helvetica, "Helvetica Neue", Arial, "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif','默认字体'),
 ...WEB_FONT_FAMILIES.map(family=>{
  const serif=/Serif|Slab|Merriweather|Playfair|Lora/.test(family),zh=family.endsWith(' SC');
  return {...font(webFontId(family),family,zh?'zh':'latin',serif?'serif':'sans',`"${family}", ${serif?'Georgia, "Songti SC", SimSun, serif':'Helvetica, Arial, "PingFang SC", "Microsoft YaHei", sans-serif'}`,''),source:'google' as const,stylesheet:webFontUrl(family)};
 }),
 // Frozen older versions remain readable; these are not offered in the picker.
 ...LEGACY_FONTS.map(f=>({...f,legacy:true})),
]);
export const DESIGN_FONT_PAIRS = Object.freeze([
 {id:'clean-business',label:'清爽商务',headingId:'neo-grotesque',bodyId:'system-sans'},
 {id:'warm-brand',label:'温润品牌',headingId:'transitional-serif',bodyId:'humanist-sans'},
 {id:'book-reading',label:'书籍阅读',headingId:'book-serif',bodyId:'transitional-serif'},
 {id:'handwritten-spirit',label:'书写气质',headingId:'zh-kai',bodyId:'zh-hei'},
 {id:'industrial-product',label:'工业产品',headingId:'industrial-display',bodyId:'system-sans'},
 {id:'technical-documentation',label:'技术文档',headingId:'monospace',bodyId:'system-sans'},
]);
const legacy:Readonly<Record<string,string>> = Object.freeze({'system-ui, sans-serif':'system-sans','Arial, sans-serif':'neo-grotesque','Georgia, serif':'transitional-serif','ui-monospace, monospace':'monospace'});
export const designFontIdSchema=z.enum(DESIGN_FONT_CATALOG.map(f=>f.id) as [string,...string[]]);
export function resolveDesignFont(value:string):DesignFont { const id=legacy[value]??value,entry=DESIGN_FONT_CATALOG.find(f=>f.id===id); if(!entry)throw new Error('TYPOGRAPHY_FONT_UNKNOWN');return entry; }
/** Plain local family names only. No functions, escapes, declarations or network resources. */
export function isSafeFontStack(value:string):boolean {
 if(value.length<1||value.length>500||/[;{}()\\@!\r\n]/.test(value)||/\/\*|\*\//.test(value))return false;
 const names=value.split(',').map(v=>v.trim());return names.length>0&&names.every(name=>/^(?:"[\p{L}\p{N} _.-]+"|'[\p{L}\p{N} _.-]+'|[\p{L}_-][\p{L}\p{N} _.-]*)$/u.test(name));
}
export const frozenDesignFontSchema=z.object({id:designFontIdSchema,stack:z.string().refine(isSafeFontStack,'Only local font-family stacks are supported')}).strict();
export const typographyAnchorSchema=z.string().regex(/^btf-local-[a-z0-9]{8,48}$/);
export const typographySnapshotSchema=z.object({version:z.literal(TYPOGRAPHY_VERSION),heading:frozenDesignFontSchema.nullable(),body:frozenDesignFontSchema.nullable(),overrides:z.array(z.object({templateId:z.number().int().positive(),anchor:typographyAnchorSchema,font:frozenDesignFontSchema,headerNodeKey:z.string().regex(/^n\d{1,9}$/).optional()}).strict()).max(200),headerSources:z.array(z.object({templateId:z.number().int().positive(),html:z.string().max(200000),css:z.string().max(100000)}).strict()).max(4).optional()}).strict().superRefine((value,ctx)=>{const seen=new Set<string>();for(const entry of value.overrides){const key=entry.templateId+':'+entry.anchor;if(seen.has(key))ctx.addIssue({code:'custom',message:'Duplicate local font anchor'});seen.add(key);}});
export type TypographySnapshot=z.infer<typeof typographySnapshotSchema>;
export function freezeDesignFont(idOrAlias:string){const f=resolveDesignFont(idOrAlias);return{id:f.id,stack:f.stack};}
export function createTypographySnapshot(input:{headingFontId?:string;bodyFontId?:string;fontPairId?:string},previous?:TypographySnapshot):TypographySnapshot {
 const current=previous?typographySnapshotSchema.parse(previous):null,pair=input.fontPairId?DESIGN_FONT_PAIRS.find(p=>p.id===input.fontPairId):null;if(input.fontPairId&&!pair)throw new Error('TYPOGRAPHY_PAIR_UNKNOWN');
 const heading=input.headingFontId??pair?.headingId,body=input.bodyFontId??pair?.bodyId;
 return typographySnapshotSchema.parse({version:TYPOGRAPHY_VERSION,heading:heading?freezeDesignFont(heading):current?.heading??null,body:body?freezeDesignFont(body):current?.body??null,overrides:current?.overrides??[],...(current?.headerSources?{headerSources:current.headerSources}:{})});
}
