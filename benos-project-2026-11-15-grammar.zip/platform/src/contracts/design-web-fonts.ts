/** Curated from Google Fonts and HTTP Archive's most used text families.
 * Only these exact URLs may be imported by a design. No arbitrary font CSS. */
export const WEB_FONT_FAMILIES = [
 'Inter','Roboto','Open Sans','Lato','Montserrat','Poppins','Roboto Condensed','Oswald',
 'Raleway','Nunito','Nunito Sans','Merriweather','Playfair Display','Lora','PT Sans','PT Serif',
 'Ubuntu','Rubik','Work Sans','Source Sans 3','Fira Sans','Noto Sans','Noto Serif','DM Sans',
 'Mulish','Manrope','Quicksand','Karla','Barlow','Roboto Slab','Noto Sans SC','Noto Serif SC',
] as const;
export const webFontId=(family:string)=>'google-'+family.toLowerCase().replace(/ /g,'-');
export const webFontUrl=(family:string)=>'https://fonts.googleapis.com/css2?family='+family.replace(/ /g,'+')+':wght@400;700&display=swap';
export const webFontImport=(family:string)=>'@import url("'+webFontUrl(family)+'");';
export function stripManagedFontImports(css:string):string {
 // Complete, exact statements only; any altered URL or appended rule is still validated.
 for(const family of WEB_FONT_FAMILIES)css=css.split(webFontImport(family)).join('');
 return css;
}
