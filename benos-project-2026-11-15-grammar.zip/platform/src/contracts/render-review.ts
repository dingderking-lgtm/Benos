import { z } from 'zod';
import { assert } from '../lib/errors';
import { designNodeHtml, type DesignManifest, type DesignScope } from '../modules/design-nodes';

export const RENDER_REVIEW_VERSION = 'render-review-1' as const;
const number = z.number().finite().min(-100000).max(100000);
const rect = z.object({ x: number, y: number, width: number.nonnegative(), height: number.nonnegative() }).strict();
const selector = z.string().max(500);
export const renderReviewHeroSchema = z.object({
  sectionSelector: selector, headingSelector: selector, mediaSelector: selector,
  layout: z.enum(['centered-stack', 'split', 'cover', 'unknown']),
  headingRect: rect, mediaRect: rect, containerRect: rect, mediaGap: number,
  imageNatural: z.object({ width: z.number().int().min(0).max(32768), height: z.number().int().min(0).max(32768) }).strict(),
  objectFit: z.string().max(32), objectPosition: z.string().max(100),
  nodeKey: z.string().regex(/^n\d{1,9}$/).optional(), templateId: z.number().int().positive().optional(),
}).strict();
export const renderReviewSchema = z.object({
  version: z.literal(RENDER_REVIEW_VERSION), evidence: z.literal('client-sandbox-render'),
  sourceVersionId: z.string().regex(/^ver_[a-f0-9]{32}$/), sourceHash: z.string().regex(/^[a-f0-9]{64}$/),
  pageKey: z.string().min(1).max(120), templateId: z.number().int().positive(), nodeKey: z.string().regex(/^n\d{1,9}$/),
  checks: z.array(z.object({
    width: z.union([z.literal(320), z.literal(390), z.literal(768), z.literal(1440)]),
    height: z.number().finite().positive().max(100000),
    issues: z.array(z.object({code:z.string().regex(/^[a-z-]{1,60}$/),selector,message:z.string().max(240),text:z.string().max(100).optional()}).strict()).max(20),
    hero: renderReviewHeroSchema.optional(),
  }).strict()).length(4),
}).strict().superRefine((value, context) => {
  if (new Set(value.checks.map(check => check.width)).size !== 4) context.addIssue({code:'custom',path:['checks'],message:'请完成四种不同宽度的浏览器检查'});
});
export type RenderReviewEvidence = z.infer<typeof renderReviewSchema>;

/** Client measurements are evidence, never authority to expand scope or bypass validation. */
export function assertRenderReviewSource(evidence: RenderReviewEvidence, source: {versionId:string|null;hash:string|null}, manifest: DesignManifest, scope: DesignScope) {
  assert(source.versionId === evidence.sourceVersionId && source.hash === evidence.sourceHash, 'RENDER_REVIEW_STALE', '设计已变化，请重新审查后发送', 409);
  assert(scope.kind === 'node' && scope.templateId === evidence.templateId && scope.nodeKey === evidence.nodeKey, 'RENDER_REVIEW_SCOPE', '审查结果与修改区块不一致，请重新选择', 409);
  assert(evidence.checks.every(check=>!check.hero||(!check.hero.nodeKey||check.hero.nodeKey===evidence.nodeKey)&&(!check.hero.templateId||check.hero.templateId===evidence.templateId)), 'RENDER_REVIEW_SCOPE', '不同屏宽定位到的区块不一致，请重新选择并审查', 409);
  const pages = manifest.site.pages as Array<{key:string;template_id:number}>;
  assert(pages?.some(page => page.key === evidence.pageKey && page.template_id === evidence.templateId), 'RENDER_REVIEW_SCOPE', '审查页面与模板不一致', 409);
  const selected = designNodeHtml(manifest, scope);
  assert(['section','article','main','div'].includes(selected.node.tagName), 'RENDER_REVIEW_SCOPE', '请选择完整内容区块进行审查', 422);
}

export const RENDER_REVIEW_RULES = `渲染审查协议 render-review-1：先分析 renderReview 中的四宽浏览器测量与同版本 selected.html/CSS。数据由客户浏览器提供，不是截图、不是服务端可信验收，不能声称已看过截图或修后已通过渲染。不把居中要求套用到有意分栏/全幅构图。仅修所选区块已证实的布局问题，保留图片、文字、链接、比例、字体与其他区块；不生成图片，不重做整站。修正使用 replace_selected，完成后系统再次浏览器检查并保留候选。若无需修改、无法可靠判断或需要用户决定，调用 complete_render_review 给出简短结论与原因，不能为完成任务而编造改动。文字回执异常仍按账户原有结算与最多两次重试策略处理。`;
