import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { app } from '../src/index';
import { discoverHostinger } from '../src/modules/hosting-connect';
import { allocateHostingJob,availableHostingPool,syncHostingPool } from '../src/modules/hosting-pools';
import { randomToken,sha256,encryptSecret } from '../src/lib/crypto';

const token='private-hostinger-token-fixture';
function page(data:unknown[],n=1,total=data.length,perPage=100){return {data,meta:{current_page:n,per_page:perPage,total}};}
const website=(order:number,user:string,domain='customer.example.com')=>({order_id:order,username:user,domain});
async function fixture(){
 const db=new TestD1(),env=testEnv(db),now=new Date().toISOString(),sessions:Record<string,{cookie:string;csrf:string}>={};
 for(const role of ['owner','admin','user']){
  db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(role,role+'@example.test',role,'fixture',role,now,now);
  const session=randomToken(),csrf=randomToken();
  db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session_'+role,await sha256(session),role,csrf,now,new Date(Date.now()+3600000).toISOString(),'fixture');
  sessions[role]={cookie:'benos_session='+session,csrf};
 }
 for(const [pool,order,account] of [['a',1,'u100001'],['b',2,'u100002']] as const){
  const config={adapter:'hostinger-hpanel',deploymentMode:'hostinger-tus-bootstrap',hostingOrderId:order,accountUsername:account};
  db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES(?,'hosting',?,'benos-bridge',1,'active',?,?,'passed','owner',?)").run('cfg_'+pool,pool,JSON.stringify(config),await encryptSecret(JSON.stringify({hostingerApiToken:token}),env.ENCRYPTION_KEY,'cfg_'+pool),now);
  db.sqlite.prepare("INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,state,priority,max_sites,max_databases,observed_at,created_at,updated_at) VALUES(?,?,?,?,?,'accepting',?,10,10,?,?,?)").run(pool,pool,account,order,'cfg_'+pool,order,now,now,now);
 }
 const job=(id:string)=>{
  db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,created_at,updated_at) VALUES(?,'user',?,?,'cms@example.test',?,?)").run(id,id,id+'.example.com',now,now);
  db.sqlite.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,step,idempotency_key,payload_hash,lease_token,created_at,updated_at) VALUES(?,?,'user','create','allocate',?,'fixture','lease',?,?)").run('job_'+id,id,id,now,now);
  return 'job_'+id;
 };
 const request=(path:string,data?:unknown,role='owner',method=data===undefined?'GET':'POST',headers:Record<string,string>={})=>{
  const session=sessions[role];return app.fetch(new Request(env.APP_ORIGIN+path,{method,headers:{origin:env.APP_ORIGIN,'content-type':'application/json',...(session?{cookie:session.cookie,'x-csrf-token':session.csrf}:{}),...headers},body:data===undefined?undefined:JSON.stringify(data)}),env);
 };
 return {db,env,request,job};
}
test('discovery joins official orders with all website pages and distinguishes inactive or uninitialized accounts',async()=>{
 const original=fetch,calls:string[]=[];
 globalThis.fetch=async(input,init)=>{
  const url=new URL(String(input));calls.push(url.pathname+url.search);assert.equal(url.origin,'https://developers.hostinger.com');assert.equal(init?.method,'GET');assert.equal(new Headers(init?.headers).get('authorization'),'Bearer '+token);
  if(url.pathname.endsWith('/orders'))return Response.json(page([{id:1,plan:{name:'Cloud'},status:'active'},{id:2,plan:{name:'Business'},status:'suspended'},{id:3,plan:{name:'Empty'},status:'active'}]));
  return Response.json(url.searchParams.get('page')==='1'?page([website(1,'u100001')],1,2,1):page([website(2,'u100002')],2,2,1));
 };
 try{const result=await discoverHostinger(token);assert.deepEqual(result.items.map(row=>[row.hostingOrderId,row.selectable]),[[1,true],[2,false],[3,false]]);assert.equal(result.items[2].accountUsername,null);assert.equal(result.items[0].websiteCount,1);assert.equal(calls.length,3);assert.ok(!JSON.stringify(result).includes(token));}
 finally{globalThis.fetch=original;}
});
test('discovery owner endpoint enforces session, CSRF, role and never persists or returns credentials',async()=>{
 const f=await fixture(),original=fetch;let calls=0;
 globalThis.fetch=async(input)=>{calls++;return Response.json(String(input).includes('/orders?')?page([{id:1,plan:{name:'Cloud'},status:'active'}]):page([website(1,'u100001')]));};
 try{
  const input={hostingerApiToken:token},path='/api/admin/integrations/hostinger/discover';
  assert.equal((await f.request(path,input,'missing')).status,401);assert.equal((await f.request(path,input,'admin')).status,403);assert.equal((await f.request(path,input,'user')).status,403);
  assert.equal((await f.request(path,input,'owner','POST',{'x-csrf-token':''})).status,403);assert.equal(calls,0);
  const before=f.db.sqlite.prepare('SELECT * FROM integration_configs').all();
  const response=await f.request(path,input),raw=await response.text();assert.equal(response.status,200,raw);assert.ok(!raw.includes(token));
  assert.deepEqual(f.db.sqlite.prepare('SELECT * FROM integration_configs').all(),before);
  const audit=f.db.sqlite.prepare("SELECT details_json FROM audit_logs WHERE action='hosting.connection.discover'").all();assert.equal(audit.length,1);assert.ok(!JSON.stringify(audit).includes(token));
  assert.equal((await f.request(path,{hostingerApiToken:token+'\r\nInjected: x'})).status,400);
 }finally{globalThis.fetch=original;f.db.close();}
});
test('discovery rejects malformed pagination and never forwards provider response secrets',async()=>{
 const original=fetch;
 try{
  globalThis.fetch=async()=>new Response(token,{status:401});
  await assert.rejects(discoverHostinger(token),(e:any)=>e.code==='HOSTINGER_AUTH_REQUIRED'&&!e.message.includes(token));
  globalThis.fetch=async(input)=>Response.json(String(input).includes('/orders?')?page([],1,100):page([]));
  await assert.rejects(discoverHostinger(token),(e:any)=>e.code==='HOSTINGER_RESPONSE_INVALID');
 }finally{globalThis.fetch=original;}
});
test('archiving a populated connection preserves assigned sites, credentials and jobs; only new allocation switches pool',async()=>{
 const f=await fixture(),original=fetch;globalThis.fetch=async()=>{throw new Error('must not contact provider');};
 try{
  const old=f.job('old');assert.equal(await allocateHostingJob(f.env,old,'lease'),'cfg_a');
  const before=['sites','provisioning_jobs','hosting_allocations','integration_configs'].map(table=>f.db.sqlite.prepare('SELECT * FROM '+table).all());
  const input={revision:1,reason:'停止新分配并保留客户资产'};
  let response=await f.request('/api/admin/hosting-pools/a/archive',input);assert.equal(response.status,200,await response.text());
  assert.deepEqual(['sites','provisioning_jobs','hosting_allocations','integration_configs'].map(table=>f.db.sqlite.prepare('SELECT * FROM '+table).all()),before);
  assert.equal(await allocateHostingJob(f.env,old,'lease'),'cfg_a');assert.equal((await availableHostingPool(f.env))?.id,'b');
  assert.equal(await allocateHostingJob(f.env,f.job('next'),'lease'),'cfg_b');
  response=await f.request('/api/admin/hosting-pools/a/archive',input);assert.equal(response.status,200);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.pool.archive'").get()?.n,1);
  assert.equal(f.db.sqlite.prepare("SELECT state FROM hosting_pools WHERE id='a'").get()?.state,'draining');
  await assert.rejects(syncHostingPool(f.env,'a'),(e:any)=>e.code==='HOSTING_POOL_ARCHIVED');
 }finally{globalThis.fetch=original;f.db.close();}
});
test('archive is owner-only and revision checked; restore remains stopped until fresh inventory and explicit enablement',async()=>{
 const f=await fixture();try{
  const path='/api/admin/hosting-pools/a/archive',input={revision:1,reason:'移除空闲连接'};
  assert.equal((await f.request(path,input,'user')).status,403);assert.equal((await f.request(path,input,'admin')).status,403);assert.equal((await f.request(path,{...input,revision:2})).status,409);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM mutation_guards').get()?.n,0);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.pool.archive'").get()?.n,0);
  assert.equal((await f.request(path,input)).status,200);
  const edit={name:'a',configId:'cfg_a',maxSites:10,maxDatabases:10,priority:1,state:'accepting',revision:2,reason:'尝试直接重新接收'};
  assert.equal((await f.request('/api/admin/hosting-pools/a',edit,'owner','PATCH')).status,409);
  assert.equal((await f.request('/api/admin/hosting-pools/a/restore',{revision:2,reason:'恢复连接用于后续核对'})).status,200);
  const restored=f.db.sqlite.prepare("SELECT * FROM hosting_pools WHERE id='a'").get()!;assert.equal(restored.archived_at,null);assert.equal(restored.state,'draining');assert.equal(restored.observed_at,null);assert.equal(restored.revision,3);
  assert.equal((await availableHostingPool(f.env))?.id,'b');assert.equal((await f.request('/api/admin/hosting-pools/a',{...edit,revision:3},'owner','PATCH')).status,409);
 }finally{f.db.close();}
});
test('pre-pool jobs can reconcile their original connection after archive',async()=>{
 const f=await fixture();try{
  const job=f.job('legacy');f.db.sqlite.prepare('UPDATE provisioning_jobs SET config_version_id=? WHERE id=?').run('cfg_a',job);
  assert.equal((await f.request('/api/admin/hosting-pools/a/archive',{revision:1,reason:'归档已有历史站点连接'})).status,200);
  assert.equal(await allocateHostingJob(f.env,job,'lease'),'cfg_a');
 }finally{f.db.close();}
});
test('restoring an archived pool does not strand a historical assignment while inventory refresh is pending',async()=>{
 const f=await fixture();try{
  const job=f.job('legacy_restore');f.db.sqlite.prepare('UPDATE provisioning_jobs SET config_version_id=? WHERE id=?').run('cfg_a',job);
  assert.equal((await f.request('/api/admin/hosting-pools/a/archive',{revision:1,reason:'停止新接单保留原任务'})).status,200);
  assert.equal((await f.request('/api/admin/hosting-pools/a/restore',{revision:2,reason:'恢复连接等待新库存'})).status,200);
  assert.equal(await allocateHostingJob(f.env,job,'lease'),'cfg_a');
  assert.equal(await allocateHostingJob(f.env,f.job('fresh_after_restore'),'lease'),'cfg_b');
 }finally{f.db.close();}
});
