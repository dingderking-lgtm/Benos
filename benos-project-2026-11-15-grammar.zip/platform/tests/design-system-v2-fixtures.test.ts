import test from 'node:test';
import assert from 'node:assert/strict';
import { V2_PATTERN_DEFINITIONS, V2_PRESETS } from '../src/design-system/v2/contracts';
import { createV2PageFixture, getV2Fixture, V2_FIXTURE_ASSETS, V2_FIXTURE_VARIANTS } from '../src/design-system/v2/fixtures';
import { renderV2ReviewGallery } from '../src/design-system/v2/review-gallery';

test('v2 review fixtures cover each real variant and keep every image inside the supplied owned set', () => {
  assert.deepEqual(Object.keys(V2_FIXTURE_VARIANTS).sort(), V2_PATTERN_DEFINITIONS.map(f => f.id).sort());
  for (const family of V2_PATTERN_DEFINITIONS) {
    assert.deepEqual([...V2_FIXTURE_VARIANTS[family.id]].sort(), family.variants.map(v => v.id).sort());
    for (const variant of family.variants) for (const preset of V2_PRESETS) for (const example of ['industrial', 'stay'] as const) {
      const fixture = getV2Fixture(family.id, variant.id, preset, { example, imageBaseUrl: '/review-assets' });
      assert.equal(fixture.context.mode, 'review');
      assert.ok(fixture.input.media.every(media => media.kind === 'owned' && fixture.context.ownedAssets.some(asset => asset.path === media.assetPath)));
      assert.equal(fixture.input.content.contact.length, 0);
      assert.equal(fixture.fixtureOnly, true);
      assert.ok(fixture.input.media.every(media => !media.prompt));
    }
  }
});
test('long, RTL and absent-image examples remain valid without planned images or false facts', () => {
  for (const family of V2_PATTERN_DEFINITIONS) for (const variant of family.variants) for (const scenario of ['long', 'rtl', 'no-images'] as const) {
    const fixture = getV2Fixture(family.id, variant.id, 'deep-studio', { scenario, example: 'industrial' });
    if (scenario === 'no-images') assert.equal(fixture.input.media.length, 0);
    if (scenario === 'rtl') assert.equal(fixture.dir, 'rtl');
    assert.deepEqual(fixture.context.verifiedFactRefs, []);
  }
});
test('six complete compositions share one skin, have unique sections and real fragment destinations', () => {
  for (const preset of V2_PRESETS) for (const example of ['industrial', 'stay'] as const) {
    const fixture = createV2PageFixture({ preset, example });
    const ids = new Set(fixture.input.sections.map(section => section.id));
    assert.equal(ids.size, fixture.input.sections.length);
    assert.ok(fixture.input.sections.every(section => section.preset === preset));
    assert.equal(fixture.input.sections.at(-1)?.patternId, 'footer');
    assert.equal(fixture.input.sections.filter(section => section.patternId.startsWith('hero-')).length, 1);
    assert.ok(fixture.input.sections.slice(1).every(section => section.content.eyebrow === undefined));
    assert.ok(fixture.input.sections.filter(section => section.patternId === 'faq' || section.patternId === 'footer').every(section => section.content.lead === undefined));
    for (const section of fixture.input.sections) {
      const links = [...(section.content.actions ?? []).map(a => a.href), ...(section.content.navigation ?? []).flatMap(group => group.links.map(link => link.href))];
      assert.ok(links.every(href => href.startsWith('#') && ids.has(href.slice(1))), JSON.stringify(links));
    }
  }
  assert.equal(V2_FIXTURE_ASSETS.length, 7);
  assert.ok(V2_FIXTURE_ASSETS.every(asset => asset.path.endsWith(asset.sha256 + '.png')));
});
test('gallery renders review-only controls and keeps arbitrary document titles outside executable HTML', () => {
  const result = renderV2ReviewGallery({ documents: [{ id: 'test', title: '</script><img src=x onerror=alert(1)>', role: 'hero', preset: 'calm-paper', href: '/preview.html', sourceRefs: [], notices: [], issues: [] }] });
  assert.match(result.html, /仅审阅 · 未向 AI 开放/);
  assert.match(result.html, /sandbox="allow-same-origin"/);
  assert.ok(!result.html.includes('<img src=x'));
  assert.ok(!result.js.includes('fetch('));
  assert.ok(!result.js.includes('POST'));
});
