import test from 'node:test';
import assert from 'node:assert/strict';
import { mediaFixture } from './media-helper';
import example from '../src/contracts/site-example.json';
import { app } from '../src/index';
import { sha256 } from '../src/lib/crypto';
import { saveVersion } from '../src/modules/ai';
import { readDesignVersion } from '../src/modules/design-workspace';
import { restoreDesignVersion } from '../src/modules/design-editor-view';
test('nested text candidate HTTP save/adopt/replay/undo is scoped and does not touch billing',async()=>{
 const f=mediaFixture();try{
  const m=structuredClone(example),html='<h1><span class="bnx-heading-phrase">在群<span class="bnx-heading-tail">山之间，</span></span></h1><p>保留正文</p>';m.templates[0].document.html=html;
  const version=await saveVersion(f.env,'u','p',m,'manual',null,'nested-http-initial');
  const token='nested-text-session'.padEnd(43,'x'),now=new Date().toISOString();f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('nested-session','u',await sha256(token),'csrf',now,'2099-01-01T00:00:00.000Z','test');
  const post=(path:string,data:unknown)=>app.request('/api/design/projects/p'+path,{method:'POST',headers:{origin:f.env.APP_ORIGIN,cookie:'benos_session='+token,'x-csrf-token':'csrf','content-type':'application/json'},body:JSON.stringify(data)},f.env);
  const input={requestKey:'nested-http-text-001',baseVersionId:version,scope:{kind:'node',templateId:1,nodeKey:'n0'},operation:{kind:'text',slots:['',''],children:[{slots:['沿着',''],children:['山谷走。']}]}};
  const result=await post('/candidates',input),body:any=await result.json();assert.equal(result.status,201,JSON.stringify(body));const candidate=body.data;
  assert.equal((await (await post('/candidates',input)).json() as any).data.id,candidate.id);
  const adopted:any=await (await post('/candidates/'+candidate.id+'/adopt',{})).json();assert(adopted.ok);
  const changed=await readDesignVersion(f.env,'u','p',adopted.data.versionId);assert.equal(changed.templates[0].document.html,html.replace('在群','沿着').replace('山之间，','山谷走。'));
  await restoreDesignVersion(f.env,'u','p',{requestKey:'nested-http-undo-001',sourceVersionId:version,expectedCurrentVersionId:adopted.data.versionId});assert.equal((await readDesignVersion(f.env,'u','p',version)).templates[0].document.html,html);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM ledger_events').get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM ai_workflows').get()!.n,0);
  const tooDeep=await post('/candidates',{...input,requestKey:'nested-http-depth-001',operation:{kind:'text',slots:['',''],children:[{slots:['',''],children:[{slots:['',''],children:['x']}]}]}});assert.equal(tooDeep.status,400);
 }finally{f.db.close();}
});
