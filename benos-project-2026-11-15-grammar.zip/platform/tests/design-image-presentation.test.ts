import test from 'node:test';
import assert from 'node:assert/strict';
import { patchDesignImage,assertDesignScope,describeDesignNodes,type DesignManifest } from '../src/modules/design-nodes';
import { saveMedia } from '../src/modules/media';
import { saveVersion } from '../src/modules/ai';
import { readDesignCandidate } from '../src/modules/design-workspace';
import { sha256 } from '../src/lib/crypto';
import { app } from '../src/index';
import { mediaFixture,png } from './media-helper';
import example from '../src/contracts/site-example.json';

test('image presentation updates only the selected image, actual dimensions and two controlled CSS properties',()=>{
 const base=structuredClone(example);
 base.templates[0].document.html='<section><figure style="aspect-ratio:4/3"><img src="/before.png" width="100" height="100" style="width:100%;height:300px;/* old */object-fit:cover!important;object-position:right;--caption:\'a;b\'" alt="before"></figure><p>Keep this content.</p></section>';
 const scope={kind:'node' as const,templateId:1,nodeKey:'n2'},asset={file:'assets/0.png',path:'/after.png',sha256:'a'.repeat(64),size:128};
 const next=patchDesignImage(base,scope,asset,'Whole product',{dimensions:{width:1024,height:1536},presentation:{fit:'contain',focalPoint:'top'}});
 assertDesignScope(base,next,scope);assert.deepEqual(next.templates.slice(1),base.templates.slice(1));
 const html=next.templates[0].document.html;
 assert.match(html,/width="1024" height="1536"/);assert.match(html,/object-fit:contain !important/);assert.match(html,/object-position:50% 0% !important/);
 assert.doesNotMatch(html,/object-fit:cover|object-position:right/);assert.match(html,/width:100%;height:300px/);assert.match(html,/--caption:&#39;a;b&#39;/);
 assert.match(html,/<figure style="aspect-ratio:4\/3">/);
 const again=patchDesignImage(next,scope,asset,'Whole product',{dimensions:{width:1024,height:1536},presentation:{fit:'contain',focalPoint:'top'}});
 assert.equal(again.templates[0].document.html,html,'repeated edits do not append duplicate fit declarations');
 for(const presentation of [{fit:'fill',focalPoint:'center'},{fit:'contain',focalPoint:'center;position:fixed'},{fit:'contain',focalPoint:'center',style:'color:red'}])assert.throws(()=>patchDesignImage(base,scope,asset,'New',{presentation:presentation as any}),/展示方式/);
});

test('candidate route takes dimensions from owned media, validates presentation and preserves every other node',async()=>{
 const f=mediaFixture();try{
  const original=await saveMedia(f.env,'u','p',{bytes:png(200,200),fileName:'original.png',requestKey:'image-original-0001'});
  const replacement=await saveMedia(f.env,'u','p',{bytes:png(1024,1536),fileName:'portrait.png',requestKey:'image-new-portrait-0001'});
  const foreign=await saveMedia(f.env,'other','other-project',{bytes:png(500,500),fileName:'foreign.png',requestKey:'image-foreign-0001'});
  const base=structuredClone(example) as DesignManifest;base.assets=[{file:'assets/0.png',path:original.assetPath,sha256:original.sha256,size:original.byteSize}];
  base.templates[0].document.html='<section><figure style="aspect-ratio:4/3"><img src="'+original.assetPath+'" width="200" height="200" style="width:100%;height:300px;object-fit:cover!important" alt="old"></figure><p>Unchanged copy.</p></section>';
  const version=await saveVersion(f.env,'u','p',base,'manual',null,'image-base-fixture');
  const node=describeDesignNodes(base).find(item=>item.canReplaceImage)!;
  const token='image-presentation-session'.padEnd(43,'x'),now=new Date().toISOString();
  f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session','u',await sha256(token),'csrf',now,'2099-01-01T00:00:00.000Z','test');
  const input={requestKey:'image-layout-candidate-0001',baseVersionId:version,scope:{kind:'node',templateId:node.templateId,nodeKey:node.nodeKey},operation:{kind:'image',assetPath:replacement.assetPath,alt:'Complete equipment',presentation:{fit:'contain',focalPoint:'top'}}};
  const send=(body:unknown)=>app.request('/api/design/projects/p/candidates',{method:'POST',headers:{origin:f.env.APP_ORIGIN,cookie:'benos_session='+token,'x-csrf-token':'csrf','content-type':'application/json'},body:JSON.stringify(body)},f.env);
  const response=await send(input),body=await response.json() as any;assert.equal(response.status,201,JSON.stringify(body));
  const candidate=await readDesignCandidate(f.env,'u','p',body.data.id),manifest=JSON.parse(candidate.manifest_json);
  assertDesignScope(base,manifest,input.scope as any);assert.match(manifest.templates[0].document.html,/width="1024" height="1536"/);assert.match(manifest.templates[0].document.html,/object-fit:contain !important/);
  assert.equal(f.db.sqlite.prepare("SELECT current_version_id FROM projects WHERE id='p'").get()!.current_version_id,version);
  assert.equal(((await (await send(input)).json()) as any).data.id,body.data.id);
  assert.equal((await send({...input,operation:{...input.operation,presentation:{fit:'cover',focalPoint:'top'}}})).status,409);
  for(const operation of [{...input.operation,width:9999},{...input.operation,presentation:{fit:'contain',focalPoint:'center;position:fixed'}},{...input.operation,presentation:{fit:'contain',focalPoint:'center',css:'position:fixed'}}]){
   assert.equal((await send({...input,requestKey:'image-bad-candidate-0001',operation})).status,400);
  }
  assert.equal((await send({...input,requestKey:'image-foreign-candidate-0001',operation:{...input.operation,assetPath:foreign.assetPath}})).status,422);
  // An old request with no presentation remains byte-compatible for queued retries.
  const legacyResponse=await send({...input,requestKey:'image-legacy-candidate-0001',operation:{kind:'image',assetPath:replacement.assetPath,alt:'Legacy'}}),legacy=(await legacyResponse.json() as any).data;
  assert.equal(legacyResponse.status,201);const old=JSON.parse((await readDesignCandidate(f.env,'u','p',legacy.id)).manifest_json);
  assert.match(old.templates[0].document.html,/width="200" height="200"/);assert.match(old.templates[0].document.html,/object-fit:cover!important/);
 }finally{f.db.close();}
});
