import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';
import { giftAiCredit,findCreditGift,listCreditGifts } from '../src/modules/credit-gifts';
import { grantCredit,getWallet,fundProvider,reserve,claimReservation,settle } from '../src/modules/ledger';
import { giftMembership,freezeMembership } from '../src/modules/memberships';
import { activeSubscription,canTopup } from '../src/modules/commerce';
import { AppError } from '../src/lib/errors';

const NOW=Date.parse('2026-11-13T03:00:00Z'),DAY=86400000;
const input={amountMicros:10_000_000,expiresInDays:30,reason:'活动体验额度',requestKey:'credit-gift-fixture-001'};
function fixture(){
 const db=new TestD1(),env=testEnv(db),iso=new Date(NOW).toISOString();
 for(const [id,role] of [['owner','owner'],['admin','admin'],['support','support'],['editor','editor'],['u','user'],['other','user']])db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(id,id+'@example.test',id,'fixture',role,iso,iso);
 return {db,env};
}
const hasCode=(code:string)=>(error:unknown)=>error instanceof AppError&&error.code===code;

test('standalone gifts are immediately spendable and never create revenue, membership or supplier funds',async()=>{
 const f=fixture();try{
  const result=await giftAiCredit(f.env,'owner','u',input,NOW);
  assert.equal(result.gift.state,'completed');assert.equal(result.gift.expiresAtMs,NOW+30*DAY);assert.equal(result.wallet.availableMicros,10_000_000);assert.equal(result.wallet.giftMicros,10_000_000);assert.equal(result.wallet.topupMicros,0);
  assert.equal(await activeSubscription(f.env.DB,'u',new Date(NOW).toISOString()),null);assert.equal(await canTopup(f.env.DB,'u',new Date(NOW).toISOString()),false);
  for(const table of ['orders','subscriptions','provider_pools','provider_funding'])assert.equal(f.db.sqlite.prepare(`SELECT COUNT(*) n FROM ${table}`).get()!.n,0);
  await fundProvider(f.env.DB,{id:'real-fixture-receipt',providerId:'pool',amountMicros:20_000_000,referenceId:'isolated-paid-fixture',nowMs:NOW});
  await reserve(f.env.DB,{id:'call',userId:'u',providerId:'pool',amountMicros:5_000_000,requestKey:'call-fixture',nowMs:NOW});assert.equal(await claimReservation(f.env.DB,'call',NOW),true);
  await settle(f.env.DB,{reservationId:'call',actualMicros:1_000_000,nowMs:NOW});assert.equal((await getWallet(f.env.DB,'u',NOW)).availableMicros,9_000_000);
  assert.equal(f.db.sqlite.prepare("SELECT source FROM credit_grants WHERE id=?").get(result.gift.grantId!)!.source,'gift');
 }finally{f.db.close();}
});

test('parallel replay issues once and cannot extend expiry or change its payload',async()=>{
 const f=fixture();try{
  const rows=await Promise.all(Array.from({length:6},()=>giftAiCredit(f.env,'owner','u',input,NOW)));
  assert.equal(new Set(rows.map(row=>row.gift.id)).size,1);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM credit_grants').get()!.n,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM ledger_events').get()!.n,1);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='member.credit_gift'").get()!.n,1);
  const replay=await giftAiCredit(f.env,'owner','u',input,NOW+31*DAY);assert.equal(replay.gift.expiresAtMs,NOW+30*DAY);assert.equal(replay.wallet.availableMicros,0);assert.equal(replay.wallet.expiredMicros,input.amountMicros);
  for(const change of [{amountMicros:1},{expiresInDays:null},{reason:'更改赠送原因'}])await assert.rejects(()=>giftAiCredit(f.env,'owner','u',{...input,...change},NOW),hasCode('IDEMPOTENCY_CONFLICT'));
  await assert.rejects(()=>giftAiCredit(f.env,'owner','other',input,NOW),hasCode('IDEMPOTENCY_CONFLICT'));
 }finally{f.db.close();}
});

test('expiry keeps pending consumption attributable and never reactivates unused expired credit',async()=>{
 const f=fixture();try{
  await giftAiCredit(f.env,'owner','u',{...input,expiresInDays:1},NOW);
  await fundProvider(f.env.DB,{id:'fund',providerId:'pool',amountMicros:10_000_000,referenceId:'fixture-funds',nowMs:NOW});
  await reserve(f.env.DB,{id:'call',userId:'u',providerId:'pool',amountMicros:5_000_000,requestKey:'call-fixture',nowMs:NOW+DAY-1});assert.equal(await claimReservation(f.env.DB,'call',NOW+DAY-1),true);
  assert.equal((await getWallet(f.env.DB,'u',NOW+DAY)).availableMicros,0);
  await settle(f.env.DB,{reservationId:'call',actualMicros:1_000_000,nowMs:NOW+DAY+1});const wallet=await getWallet(f.env.DB,'u',NOW+DAY+1);assert.equal(wallet.availableMicros,0);assert.equal(wallet.heldMicros,0);assert.equal(wallet.expiredMicros,9_000_000);
 }finally{f.db.close();}
});

test('permanent gifts and existing topups keep independent amounts and expiry',async()=>{
 const f=fixture();try{
  await grantCredit(f.env.DB,{id:'topup',userId:'u',source:'topup',amountMicros:1000,referenceId:'existing-paid-topup',nowMs:NOW});
  await giftAiCredit(f.env,'owner','u',{...input,expiresInDays:null},NOW);
  const wallet=await getWallet(f.env.DB,'u',NOW+10*365*DAY);assert.equal(wallet.giftMicros,input.amountMicros);assert.equal(wallet.topupMicros,1000);
  assert.equal(f.db.sqlite.prepare("SELECT amount_micros FROM credit_grants WHERE id='topup'").get()!.amount_micros,1000);
 }finally{f.db.close();}
});

test('only owner and administrators of ordinary users can gift, including owner self-gifts',async()=>{
 const f=fixture();try{
  for(const actor of ['u','support','editor'])await assert.rejects(()=>giftAiCredit(f.env,actor,'other',input,NOW),hasCode('FORBIDDEN'));
  for(const target of ['owner','admin','support','editor'])await assert.rejects(()=>giftAiCredit(f.env,'admin',target,input,NOW),hasCode('FORBIDDEN'));
  await giftAiCredit(f.env,'admin','u',input,NOW);await giftAiCredit(f.env,'owner','owner',input,NOW);
  assert.equal((await getWallet(f.env.DB,'owner',NOW)).availableMicros,input.amountMicros);
  f.db.sqlite.prepare("UPDATE users SET status='restricted' WHERE id='admin'").run();await assert.rejects(()=>giftAiCredit(f.env,'admin','u',{...input,requestKey:'restricted-admin-gift'},NOW),hasCode('FORBIDDEN'));
 }finally{f.db.close();}
});

test('grant, completion receipt and completion audit roll back together and retry preserves first validity',async()=>{
 const f=fixture();try{
  f.db.sqlite.exec("CREATE TRIGGER fail_gift_audit BEFORE INSERT ON audit_logs WHEN NEW.action='member.credit_gift' BEGIN SELECT RAISE(ABORT,'fixture-audit-write-failure'); END;");
  await assert.rejects(()=>giftAiCredit(f.env,'owner','u',input,NOW));assert.equal((await getWallet(f.env.DB,'u',NOW)).availableMicros,0);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM ledger_events').get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM mutation_guards').get()!.n,0);
  const pending=await findCreditGift(f.env,'owner','u',input.requestKey);assert.equal(pending.gift?.state,'pending');assert.equal(pending.gift?.expiresAtMs,NOW+30*DAY);
  f.db.sqlite.exec('DROP TRIGGER fail_gift_audit');const result=await giftAiCredit(f.env,'owner','u',input,NOW+DAY);assert.equal(result.gift.state,'completed');assert.equal(result.gift.expiresAtMs,NOW+30*DAY);assert.equal(result.wallet.availableMicros,input.amountMicros);
 }finally{f.db.close();}
});

test('revoked administrator permissions are checked inside the same transaction as the credit grant',async()=>{
 const f=fixture();try{
  const batch=f.db.batch.bind(f.db);let revoke=true;
  f.db.batch=async <T=Record<string,unknown>>(statements:Parameters<typeof batch>[0])=>{
   if(revoke&&statements.some(statement=>String((statement as any).sql).includes('INSERT INTO mutation_guards'))){revoke=false;f.db.sqlite.prepare("UPDATE users SET role='support' WHERE id='admin'").run();}
   return batch<T>(statements);
  };
  await assert.rejects(()=>giftAiCredit(f.env,'admin','u',input,NOW),hasCode('FORBIDDEN'));
  assert.equal((await getWallet(f.env.DB,'u',NOW)).availableMicros,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM ledger_events').get()!.n,0);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='member.credit_gift'").get()!.n,0);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM mutation_guards').get()!.n,0);
 }finally{f.db.close();}
});

test('lost committed acknowledgement resolves through the original request without a second grant',async()=>{
 const f=fixture();try{
  const batch=f.db.batch.bind(f.db);let fail=true;
  f.db.batch=async <T=Record<string,unknown>>(statements:Parameters<typeof batch>[0])=>{const result=await batch<T>(statements);if(fail&&statements.some(statement=>String((statement as any).sql).includes("UPDATE admin_credit_gifts SET state='completed'"))){fail=false;throw new Error('fixture acknowledgement lost');}return result;};
  await assert.rejects(()=>giftAiCredit(f.env,'owner','u',input,NOW));assert.equal((await findCreditGift(f.env,'owner','u',input.requestKey)).gift?.state,'completed');
  const result=await giftAiCredit(f.env,'owner','u',input,NOW+DAY);assert.equal(result.wallet.availableMicros,input.amountMicros);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM credit_grants').get()!.n,1);
 }finally{f.db.close();}
});

test('gift list is stable, paginated, scoped and records are immutable',async()=>{
 const f=fixture();try{
  for(let i=0;i<3;i++)await giftAiCredit(f.env,'owner','u',{...input,requestKey:'gift-page-'+i},NOW+i);
  const first=await listCreditGifts(f.env,'owner','u',{page:1,limit:2}),last=await listCreditGifts(f.env,'owner','u',{page:2,limit:2});assert.equal(first.items.length,2);assert.equal(first.hasMore,true);assert.equal(last.items.length,1);assert.equal(last.hasMore,false);assert.equal(new Set([...first.items,...last.items].map(item=>item.id)).size,3);
  assert.equal((await findCreditGift(f.env,'owner','other','gift-page-0')).gift,null);assert.equal((await listCreditGifts(f.env,'owner','other',{})).items.length,0);
  assert.throws(()=>f.db.sqlite.prepare('UPDATE admin_credit_gifts SET amount_micros=1 WHERE id=?').run(first.items[0].id),/immutable_credit_gift/);assert.throws(()=>f.db.sqlite.prepare('DELETE FROM admin_credit_gifts WHERE id=?').run(first.items[0].id),/immutable_credit_gift/);
 }finally{f.db.close();}
});

test('existing membership gifts still grant monthly credits and hosting without granting paid topup rights',async()=>{
 const f=fixture();try{
  await giftMembership(f.env,'owner','owner',{tier:'go',months:1,reason:'所有者体验会员',requestKey:'owner-membership-gift'},{nowMs:NOW});
  assert.equal((await activeSubscription(f.env.DB,'owner',new Date(NOW).toISOString()))?.tier,'go');assert.equal((await getWallet(f.env.DB,'owner',NOW)).giftMicros,16_250_000);assert.equal(await canTopup(f.env.DB,'owner',new Date(NOW).toISOString()),false);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM orders').get()!.n,0);
 }finally{f.db.close();}
});

test('freezing a membership leaves an independent AI gift available with its original expiry',async()=>{
 const f=fixture();try{
  await giftMembership(f.env,'owner','u',{tier:'go',months:1,reason:'活动体验会员',requestKey:'membership-before-credit-gift'},{nowMs:NOW});
  const gift=await giftAiCredit(f.env,'owner','u',input,NOW);
  await freezeMembership(f.env,'owner','u',{reason:'暂停会员权益',requestKey:'freeze-membership-only'},{nowMs:NOW+1000});
  const wallet=await getWallet(f.env.DB,'u',NOW+1000),grant=wallet.grants.find(row=>row.id===gift.gift.grantId);
  assert.equal(wallet.availableMicros,input.amountMicros);assert.equal(wallet.pausedMicros,16_250_000);assert.equal(grant?.membershipFrozen,false);assert.equal(grant?.expiresAtMs,NOW+30*DAY);
 }finally{f.db.close();}
});

test('gift HTTP endpoints enforce login, role, CSRF and bounded inputs',async()=>{
 const db=new TestD1(),env=testEnv(db);try{
  let cookie='',csrf='';const request=(path:string,method='GET',data?:unknown,authenticated=true)=>app.fetch(new Request(env.APP_ORIGIN+path,{method,headers:{origin:env.APP_ORIGIN,...(data?{'content-type':'application/json'}:{}),...(authenticated&&cookie?{cookie,'x-csrf-token':csrf}:{})},body:data?JSON.stringify(data):undefined}),env);
  const bootstrap=await request('/api/bootstrap','POST',{token:env.BOOTSTRAP_TOKEN,email:'owner@example.test',name:'Owner',password:'fixture-credit-gift-password'}),body=await bootstrap.json() as any;cookie=bootstrap.headers.get('set-cookie')!.split(';')[0];csrf=body.data.csrfToken;const target=body.data.user.id,path='/api/admin/memberships/'+target+'/credit-gifts';
  assert.equal((await request(path,'POST',input,false)).status,401);
  for(const change of [{amountMicros:0},{amountMicros:0.1},{amountMicros:100_000_000_001},{expiresInDays:0},{expiresInDays:367},{expiresInDays:undefined},{reason:'短'},{requestKey:'short'}])assert.equal((await request(path,'POST',{...input,...change})).status,400);
  const response=await request(path,'POST',input);assert.equal(response.status,201);assert.equal((await response.json() as any).data.gift.state,'completed');
  assert.equal((await request(path+'?page=0')).status,400);assert.equal((await(await request(path+'/requests/'+input.requestKey)).json() as any).data.gift.requestKey,input.requestKey);
  csrf='wrong';assert.equal((await request(path,'POST',{...input,requestKey:'csrf-failed-fixture'})).status,403);
 }finally{db.close();}
});
