import test from 'node:test';
import assert from 'node:assert/strict';
import { V2_PATTERN_DEFINITIONS, V2_PRESETS, BNX_VERSION, createWebsiteTokenSnapshot, v2SectionSchema, v2PageSchema, v2PageJsonSchema, type V2PatternDefinition, type V2VariantDefinition, type V2SectionInput } from '../src/design-system/v2/contracts';
import { SECTION_PATTERN_VERSION, PATTERN_SKINS, sectionPatternInputSchema } from '../src/contracts/section-patterns';

function sample(family: V2PatternDefinition, variant: V2VariantDefinition): V2SectionInput {
  const c = variant.capacity;
  return { id: 'test-section', patternId: family.id, variantId: variant.id, preset: 'calm-paper', content: {
    title: 'A useful, honest section', lead: 'A short introduction.',
    items: Array.from({ length: c.items[0] }, (_, i) => ({ title: `Item ${i + 1}`, text: 'An explanation without fabricated performance claims.' })),
    questions: Array.from({ length: c.questions[0] }, (_, i) => ({ question: `Question ${i + 1}?`, answer: 'A useful answer.' })),
    actions: Array.from({ length: c.actions[0] }, (_, i) => ({ label: `Action ${i + 1}`, href: '/contact', kind: i ? 'secondary' as const : 'primary' as const })),
  }, media: [] };
}
function get(pattern: string, variantId?: string) { const f = V2_PATTERN_DEFINITIONS.find(f => f.id === pattern)!; return sample(f, f.variants.find(v => v.id === variantId) || f.variants[0]); }

test('bnx has 17 independent families / 37 bounded variants and three shared website presets', () => {
  assert.equal(BNX_VERSION, 'bnx-1'); assert.equal(V2_PATTERN_DEFINITIONS.length, 17);
  assert.equal(V2_PATTERN_DEFINITIONS.reduce((n, f) => n + f.variants.length, 0), 37);
  for (const family of V2_PATTERN_DEFINITIONS) for (const variant of family.variants) for (const preset of V2_PRESETS) {
    const input = { ...sample(family, variant), preset }; assert.equal(v2SectionSchema.parse(input).preset, preset);
    assert.ok(variant.layoutKey); assert.ok(family.sourceIds.length);
  }
});
test('existing bns schema stays a separate namespace and continues to parse its old input', () => {
  assert.equal(SECTION_PATTERN_VERSION, 'bns-1'); assert.deepEqual(PATTERN_SKINS, ['soft-gradient', 'bold-outline', 'clean-business']);
  const old = { id: 'hero', patternId: 'hero-stage', variantId: 'product-stage', skin: 'clean-business', content: { title: 'Existing website' } };
  assert.equal(sectionPatternInputSchema.parse(old).skin, 'clean-business');
  assert.equal(v2SectionSchema.safeParse(old).success, false);
  assert.equal(sectionPatternInputSchema.safeParse(get('hero-stage')).success, false);
});
test('content capacities reject wrong content families and excessive items', () => {
  const features = get('features'); features.content.items = Array.from({ length: 7 }, () => ({ title: 'Too many', text: 'Text' }));
  assert.equal(v2SectionSchema.safeParse(features).success, false);
  const faq = get('faq'); faq.content.items = [{ title: 'Hidden content', text: 'Must not disappear silently.' }];
  assert.equal(v2SectionSchema.safeParse(faq).success, false);
  const action = get('action'); action.content.actions = []; assert.equal(v2SectionSchema.safeParse(action).success, false);
  const footer = get('footer', 'compact'); footer.content.navigation = Array.from({ length: 3 }, () => ({ title: 'Directory', links: [{ label: 'Contact', href: '/contact' }] }));
  assert.equal(v2SectionSchema.safeParse(footer).success, false);
});
test('strict content keeps safe hrefs and disallows executable/unknown HTML inputs', () => {
  const bad = get('hero-stage'); bad.content.actions = [{ label: 'Click', href: 'javascript:alert(1)' }]; assert.equal(v2SectionSchema.safeParse(bad).success, false);
  assert.equal(v2SectionSchema.safeParse({ ...get('hero-stage'), html: '<script>x</script>' }).success, false);
  const duplicate = get('hero-stage'); duplicate.content.actions = [{ label: 'One', href: '/a', kind: 'primary' }, { label: 'Two', href: '/b', kind: 'primary' }];
  assert.equal(v2SectionSchema.safeParse(duplicate).success, false);
  const copyright = get('features'); copyright.content.copyright = 'A footer statement'; assert.equal(v2SectionSchema.safeParse(copyright).success, false);
});
test('missing media is explicit/valid; complete subjects cannot be silently cropped in cover', () => {
  const cover = get('hero-cover'); assert.equal(v2SectionSchema.parse(cover).media.length, 0);
  cover.media = [{ id: 'scene', purpose: 'A scene', alt: 'Scene', kind: 'planned', prompt: 'A complete machine', subjectPolicy: 'complete' }];
  assert.equal(v2SectionSchema.safeParse(cover).success, false);
  cover.media[0].subjectPolicy = 'crop-safe'; assert.equal(v2SectionSchema.safeParse(cover).success, true);
  cover.media[0].kind = 'missing'; assert.equal(v2SectionSchema.safeParse(cover).success, true);
  const story = get('media-story'); story.media = Array.from({ length: 3 }, (_, i) => ({ id: `image-${i}`, purpose: 'Story', alt: 'Story image', kind: 'missing' }));
  assert.equal(v2SectionSchema.safeParse(story).success, false);
});
test('page contract enforces one preset, one first hero, one last footer and globally unique frame IDs', () => {
  const hero = get('hero-stage'), features = { ...get('features'), id: 'features' }, footer = { ...get('footer'), id: 'footer' };
  const page = { version: 'bnx-compose-1', preset: 'calm-paper', sections: [hero, features, footer] };
  assert.equal(v2PageSchema.safeParse(page).success, true);
  assert.equal(v2PageSchema.safeParse({ ...page, sections: [features, hero] }).success, false);
  assert.equal(v2PageSchema.safeParse({ ...page, sections: [footer, features] }).success, false);
  assert.equal(v2PageSchema.safeParse({ ...page, sections: [hero, { ...features, preset: 'deep-studio' }] }).success, false);
  assert.equal(v2PageSchema.safeParse({ ...page, sections: [features, features] }).success, false);
  const a = { ...get('media-mosaic'), id: 'a-b', media: [{ id: 'c', purpose: 'Scene', alt: 'Scene', kind: 'missing' }] };
  const b = { ...get('media-mosaic'), id: 'a', media: [{ id: 'b-c', purpose: 'Scene', alt: 'Scene', kind: 'missing' }] };
  assert.equal(v2PageSchema.safeParse({ ...page, sections: [a, b] }).success, false);
});
test('token snapshots are schema-safe independent copies rather than mutable shared state', () => {
  const first = createWebsiteTokenSnapshot('calm-paper'), second = createWebsiteTokenSnapshot('calm-paper');
  first.colors.accent = '#ff0000'; first.type.body = 20;
  assert.notDeepEqual(first, second); assert.deepEqual(createWebsiteTokenSnapshot('calm-paper'), second);
  for (const preset of V2_PRESETS) {
    const snapshot = createWebsiteTokenSnapshot(preset); assert.equal(snapshot.preset, preset); assert.equal(snapshot.type.small, 14);
    assert.ok(new Set(Object.values(snapshot.type)).size >= 5); // body and label share the 16px step of the adopted scale
  }
  assert.throws(() => createWebsiteTokenSnapshot('user-css' as any));
  assert.equal((v2PageJsonSchema as any).additionalProperties, false);
});
