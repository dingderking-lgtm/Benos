import test from 'node:test';
import assert from 'node:assert/strict';
import { sha256 } from '../src/lib/crypto';
import { createV2Artifact, findV2Pattern, getV2Pattern, v2ApprovalKey, hasExactV2Review, assertV2ProductionReady, canonicalV2Json, type V2ArtifactInput, type V2TrustedReview } from '../src/design-system/v2/registry';
import { getV2Sources, getV2Notices, assertV2CustomerExportReady } from '../src/design-system/v2/provenance';

const input: V2ArtifactInput = { patternId: 'hero-stage', variantId: 'split', preset: 'calm-paper', rendererVersion: 'fixture-renderer-1', rendererFingerprint: 'function fixture(){return "semantic-html"}', css: '.bnx-section{display:block}' };
test('artifact exact hashes cover renderer, CSS, selected preset and variant', async () => {
  const artifact = await createV2Artifact(input); assert.deepEqual(await createV2Artifact({ ...input }), artifact);
  for (const changed of [{ css: input.css + '\n' }, { rendererFingerprint: input.rendererFingerprint + '/* fix */' }, { rendererVersion: 'fixture-renderer-2' }, { preset: 'deep-studio' as const }, { variantId: 'centered' }]) {
    assert.notEqual((await createV2Artifact({ ...input, ...changed })).artifactHash, artifact.artifactHash);
  }
  assert.match(artifact.artifactHash, /^[a-f0-9]{64}$/); assert.equal(artifact.approvalStatus, 'draft');
  assert.equal(artifact.reviewOnly, true); assert.equal(artifact.customerExportReady, false);
  assert.equal(artifact.sourceGraphHash, await sha256(canonicalV2Json(artifact.sourceRefs)));
  assert.equal(artifact.noticeBundleHash, await sha256(canonicalV2Json(artifact.notices)));
});
test('metadata and caller-supplied approvals cannot unlock production/export', async () => {
  const artifact = await createV2Artifact(input);
  assert.throws(() => { (artifact as any).customerExportReady = true; });
  assert.throws(() => { (artifact.tokenSnapshot.colors as any).accent = 'red'; });
  assert.throws(() => assertV2ProductionReady({ ...artifact, customerExportReady: true, approvalStatus: 'approved' } as any), /BNX_PATTERN_NOT_APPROVED/);
  assert.throws(() => assertV2CustomerExportReady(), /BNX_CUSTOMER_EXPORT_NOT_READY/);
  assert.throws(() => { (getV2Pattern('hero-stage').variants[0] as any).layoutKey = 'changed'; });
});
test('review match requires exact source, notice, preset and artifact hashes', async () => {
  const artifact = await createV2Artifact(input), row: V2TrustedReview = { ...v2ApprovalKey(artifact), state: 'approved', reviewerId: 'fixture-reviewer', reviewedAt: '2026-11-14T00:00:00Z' };
  assert.equal(hasExactV2Review(artifact, [row]), true);
  assert.equal(hasExactV2Review(artifact, []), false);
  for (const changed of [{ state: 'rejected' }, { preset: 'deep-studio' }, { artifactHash: 'a'.repeat(64) }, { sourceGraphHash: 'b'.repeat(64) }, { noticeBundleHash: 'c'.repeat(64) }, { revision: 2 }, { reviewerId: '' }]) assert.equal(hasExactV2Review(artifact, [{ ...row, ...changed } as V2TrustedReview]), false);
  assert.doesNotThrow(() => assertV2ProductionReady(artifact, [row]));
});
test('source references bind actual local adaptations while retaining license and modification notices', async () => {
  const sources = getV2Sources(); assert.equal(sources.length, 6);
  assert.equal(sources.find(source => source.id === 'heroui-open')!.license, 'Apache-2.0');
  for (const source of sources) {
    assert.match(source.commit, /^[a-f0-9]{40}$/); assert.equal(source.relationship, 'adapted-source');
    assert.equal(source.dependencyReview, 'local-adapters-only'); assert.deepEqual(source.runtimePackages, []); assert.deepEqual(source.copiedFiles, []);
    assert.deepEqual(source.adaptedFiles, source.files.map(file => file.path)); assert.equal(source.adapterReady, true);
    assert.equal(source.adaptations?.length, 1);
    assert.ok(source.files.length); assert.ok(source.notices.length);
    for (const notice of source.notices) assert.equal(await sha256(notice.text), notice.sha256);
  }
  sources[0].name = 'Mutated caller copy'; assert.notEqual(getV2Sources()[0].name, sources[0].name);
  assert.throws(() => getV2Sources(['paid-pro']), /BNX_SOURCE_UNKNOWN/);
  assert.equal(getV2Notices(['heroui-open']).length, 2);
});
test('unknown registry IDs and incomplete renderer identity fail closed', async () => {
  assert.throws(() => getV2Pattern('old-or-pro'), /BNX_PATTERN_UNKNOWN/);
  assert.throws(() => findV2Pattern('hero-stage', 'imaginary'), /BNX_VARIANT_UNKNOWN/);
  await assert.rejects(() => createV2Artifact({ ...input, rendererFingerprint: '' }), /BNX_RENDERER_IDENTITY_REQUIRED/);
  await assert.rejects(() => createV2Artifact({ ...input, css: '' }), /BNX_ARTIFACT_CSS_INVALID/);
  assert.equal(canonicalV2Json({ b: 2, a: 1 }), canonicalV2Json({ a: 1, b: 2 }));
  assert.throws(() => canonicalV2Json({ runtime: undefined }), /BNX_HASH_VALUE_UNSUPPORTED/);
});
