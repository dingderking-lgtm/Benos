import test from 'node:test';
import assert from 'node:assert/strict';
import { DESIGN_STYLES,getDesignStyle } from '../src/contracts/design-style-catalog';
import { createDesignFoundation,compileDesignFoundation,foundationAuthoringContext,materializeDesignFoundation,foundationAuthoringExample,inheritDesignFoundation,supportsDesignCoherence } from '../src/contracts/design-foundation';
import { COHERENCE_MARKER,foundationSurfaces,foundationContrast } from '../src/contracts/design-coherence';
import { validateSiteManifest } from '../src/modules/template-contract';
import { imagePromptWithVisualDirection,userSpecifiesImageDirection } from '../src/lib/image-visual-direction';
import { imagePromptForSlot,imageSlotSchema } from '../src/lib/image-layout';
import { createDesignOrder } from '../src/contracts/design-order';

test('derived surfaces keep primary/supporting text readable, including nested fills and both bridge endpoints',()=>{
 for(const style of DESIGN_STYLES){
  const shades=foundationSurfaces(style.tokens),profile=createDesignFoundation(style),manifest=materializeDesignFoundation(foundationAuthoringExample(profile),profile);
  for(const [name,value] of Object.entries(shades)){assert.ok(foundationContrast(value.ink,value.background)>=4.5,style.id+'/'+name+':body');assert.ok(foundationContrast(value.muted,value.background)>=4.5,style.id+'/'+name+':muted');assert.match(value.background,/^#[a-f0-9]{6}$/);}
  for(const shade of [shades.tone,shades.raised]){assert.ok(foundationContrast(shade.ink,style.tokens.background)>=4.5);assert.ok(foundationContrast(shade.muted,style.tokens.background)>=4.5);}
  assert.ok(foundationContrast(shades.deep.muted,shades.deepRaised.background)>=4.5);
  const checked=validateSiteManifest(manifest);assert.equal(checked.valid,true,JSON.stringify(checked.issues));
  assert.equal(manifest.site.theme.global_css.split(COHERENCE_MARKER).length-1,1);assert.deepEqual(materializeDesignFoundation(manifest,profile),manifest);
  assert.ok(supportsDesignCoherence(profile));const context=foundationAuthoringContext(profile);assert.match(context.classes,/bnf-chapter/);assert.match(context.classes,/bnf-workbench/);assert.equal(context.tokens['--bnf-tone'],shades.tone.background);
 }
 const tech=getDesignStyle('tech')!,shades=foundationSurfaces(tech.tokens);
 assert.notEqual(shades.deep.background,'#172126');assert.ok(foundationContrast(shades.raised.background,tech.tokens.background)>1.2);
 for(const background of ['#666666','#777777','#999999'])for(const shade of Object.values(foundationSurfaces({...tech.tokens,background}))){assert.ok(foundationContrast(shade.ink,shade.background)>=4.5);assert.ok(foundationContrast(shade.muted,shade.background)>=4.5);}
});

test('legacy and frozen foundations neither change nor advertise primitives they do not contain',()=>{
 const current=createDesignFoundation(getDesignStyle('tech')!),legacy={...current};delete legacy.coherenceVersion;
 const old=materializeDesignFoundation(foundationAuthoringExample(legacy),legacy),originalCss=old.site.theme.global_css;
 assert.ok(!originalCss.includes(COHERENCE_MARKER));assert.ok(!foundationAuthoringContext(legacy).classes.includes('bnf-workbench'));
 const frozen=inheritDesignFoundation(old,legacy)!;assert.equal(compileDesignFoundation(frozen,old.site.theme),originalCss);assert.deepEqual(materializeDesignFoundation(old,frozen),old);
 assert.equal(supportsDesignCoherence({...frozen,coherenceVersion:current.coherenceVersion}),false);
 assert.ok(!foundationAuthoringContext({...frozen,coherenceVersion:current.coherenceVersion}).classes.includes('bnf-workbench'));
});

test('generated images share palette/light/motif while preserving independent subjects and requested media',()=>{
 const profile=createDesignFoundation(getDesignStyle('tech')!),before=JSON.stringify(profile);
 const hero='A precise layered information sculpture, wide cinematic framing, blue glass and paper material, no interface text.';
 const detail='Close view of a paper document and its source connections, editorial photographic treatment, a single object fully in frame.';
 const a=imagePromptWithVisualDirection(hero,profile,{section:'hero'}),b=imagePromptWithVisualDirection(detail,profile,{section:'workflow-detail'});
 assert.ok(a.applied&&b.applied);assert.ok(a.prompt.startsWith(hero+'\n'));assert.ok(b.prompt.startsWith(detail+'\n'));
 assert.equal(a.prompt.slice(hero.length),b.prompt.slice(detail.length),'the series uses shared art direction, not a repeated hero subject');
 for(const entry of [a,b]){assert.ok(entry.prompt.includes(profile.tokens.accent));assert.match(entry.prompt,/directional light/);assert.match(entry.prompt,/connected layers, routes or component relationships/);assert.match(entry.prompt,/Keep the original subject, requested palette and medium/);assert.match(entry.prompt,/distinct view/);assert.match(entry.prompt,/generic stock team portraits/);}
 assert.equal(JSON.stringify(profile),before);assert.deepEqual(imagePromptWithVisualDirection(hero,profile),a);
});

test('uploaded photographs, explicit user direction and legacy image-job prompts remain byte-for-byte unchanged',()=>{
 const profile=createDesignFoundation(getDesignStyle('tech')!),prompt='Keep this warm documentary photograph and its actual people unchanged.',legacy={...profile};delete legacy.coherenceVersion;
 for(const [current,options,reason] of [[profile,{source:'uploaded'},'uploaded-asset'],[profile,{preserveExplicitDirection:true},'explicit-direction'],[legacy,{},'legacy-profile'],[null,{},'legacy-profile'],[{...profile,styleName:'自定义方向'}, {},'explicit-direction']] as const)assert.deepEqual(imagePromptWithVisualDirection(prompt,current,options),{prompt,applied:false,reason});
});

test('only the explicit orderly foundation adds palette exclusions without recoloring real assets',()=>{
 const style=getDesignStyle('tech')!,legacy=createDesignFoundation(style),ordered=createDesignFoundation(style,'same',{designOrder:createDesignOrder({request:'Design a website'})});
 const prompt='A precise paper sculpture with distinct layers.';
 assert.doesNotMatch(imagePromptWithVisualDirection(prompt,legacy).prompt,/exclude unrelated/);
 const output=imagePromptWithVisualDirection(prompt,ordered).prompt;
 for(const color of [ordered.tokens.background,ordered.tokens.surface,ordered.tokens.accent])assert.ok(output.includes(color));
 assert.match(output,/exclude unrelated high-saturation accent colors/);assert.match(output,/Preserve the actual colors of real products and supplied assets/);
 assert.equal(imagePromptWithVisualDirection(prompt,ordered,{source:'uploaded'}).prompt,prompt);
 assert.equal(imagePromptWithVisualDirection(prompt,ordered,{preserveExplicitDirection:true}).prompt,prompt);
});

test('shared art direction respects UTF-8 and reserves geometry bytes without truncating the original brief',()=>{
 const profile=createDesignFoundation(getDesignStyle('tech')!),slot=imageSlotSchema.parse({width:1600,height:700,fit:'contain',focalPoint:'right',textSafeArea:'left'}),bytes=(text:string)=>new TextEncoder().encode(text).length;
 const prompt='说明材料与路径之间的关系。'.repeat(65),result=imagePromptWithVisualDirection(prompt,profile);
 assert.equal(result.applied,true);assert.ok(bytes(result.prompt)<=3360);assert.ok(bytes(imagePromptForSlot(result.prompt,slot))<=4000);assert.match(imagePromptForSlot(result.prompt,slot),/destination frame 1600x700, fit contain/);
 for(const [text,maxPromptBytes] of [['中'.repeat(1100),undefined],[prompt,bytes(prompt)+10],[prompt,-1]] as const){const skipped=imagePromptWithVisualDirection(text,profile,{maxPromptBytes});assert.equal(skipped.prompt,text);assert.equal(skipped.applied,false);assert.equal(skipped.reason,'insufficient-prompt-budget');}
});

test('explicit user image art direction is distinguished from generic requests and negated preferences in Chinese and English',()=>{
 for(const text of ['图片统一采用暖色水彩风格','使用蓝色的产品主图','主图不要蓝色，改用暖色手绘','Keep photos in warm documentary lighting.','Use monochrome illustrations throughout.','图片严格参考我上传的参考图','不要改变原图中的色彩','Preserve the original uploaded photo unchanged.','Avoid cartoons; use warm documentary photos.'])assert.equal(userSpecifiesImageDirection(text),true,text);
 for(const text of ['科技网站，主图和插图你来安排','网站用蓝色，图片展示工作过程','不要使用蓝色插图','不要严格参考图片','不需要保留原图','Make images not blue.','Do not strictly follow the reference image.','避免卡通照片','不要卡通插图，网站用蓝色','Do not use stock team photos.','Avoid blue illustrations; the site should be red.','A blue website with explanatory images.','Use images to explain the process.'])assert.equal(userSpecifiesImageDirection(text),false,text);
});
