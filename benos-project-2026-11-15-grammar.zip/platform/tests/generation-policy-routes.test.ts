import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';

test('generation settings require owner and CSRF, audit changes, and never reserve credit',async()=>{
 const db=new TestD1(),env=testEnv(db),path='/api/ai/admin/generation-policy';
 try{
  const headers:Record<string,string>={origin:env.APP_ORIGIN,'content-type':'application/json'};
  const boot=await app.request('/api/bootstrap',{method:'POST',headers,body:JSON.stringify({token:env.BOOTSTRAP_TOKEN,email:'generation@example.test',password:'generation-owner-password',name:'Owner'})},env);
  assert.equal(boot.status,201);const auth:any=await boot.json();headers.cookie=boot.headers.get('set-cookie')!.split(';')[0];
  const put=()=>app.request(path,{method:'PUT',headers,body:JSON.stringify({imageQuality:'medium',imageConcurrency:4})},env);
  assert.equal((await put()).status,403);headers['x-csrf-token']=auth.data.csrfToken;
  const response=await put();assert.equal(response.status,200);const saved:any=await response.json();assert.equal(saved.data.policy.imageQuality,'medium');assert.equal(saved.data.policy.costTargetMicros,400_000);assert.equal(saved.data.costTargetIsLimit,false);
  assert.equal(db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='ai.generation_policy_changed'").get()!.n,1);
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) n FROM api_reservations').get()!.n,0);
  db.sqlite.prepare("UPDATE users SET role='admin'").run();assert.equal((await put()).status,403);assert.equal((await app.request(path,{headers},env)).status,200);
  db.sqlite.prepare("UPDATE users SET role='user'").run();assert.equal((await app.request(path,{headers},env)).status,403);
 }finally{db.close();}
});
