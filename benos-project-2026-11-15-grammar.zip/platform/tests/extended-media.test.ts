import test from 'node:test';
import assert from 'node:assert/strict';
import { Hono } from 'hono';
import type { App } from '../src/lib/http';
import { inspectMediaBytes,saveMedia,listMedia,readMedia,setMediaDeleted,mediaRoutes,resolveProjectAssets } from '../src/modules/media';
import { importTemplatePackage } from '../src/modules/template-import';
import { readDesignCandidate } from '../src/modules/design-workspace';
import { templateZip } from '../src/lib/template-zip';
import { readTemplateZip } from '../src/lib/template-unzip';
import { starterManifest } from '../src/contracts/starter-library';
import { validateSiteManifest } from '../src/modules/template-contract';
import { mediaFixture,png } from './media-helper';
import { sha256,randomToken } from '../src/lib/crypto';

const encode=(text:string)=>new TextEncoder().encode(text);
const svg=encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 60"><defs><linearGradient id="g"><stop offset="0" stop-color="#000"/><stop offset="1" stop-color="#fff"/></linearGradient></defs><path d="M0 0H100V60H0Z" fill="url(#g)"/></svg>');
function pdf(extra=''){
 const objects=['<< /Type /Catalog /Pages 2 0 R '+extra+' >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 100 100] /Resources << >> /Contents 4 0 R >>','<< /Length 24 >>\nstream\n0 0 1 rg 0 0 10 10 re f\n\nendstream'];
 let text='%PDF-1.7\n';const offsets=[0];objects.forEach((body,index)=>{offsets.push(text.length);text+=`${index+1} 0 obj\n${body}\nendobj\n`;});const start=text.length;text+='xref\n0 5\n0000000000 65535 f \n'+offsets.slice(1).map(n=>String(n).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n'+start+'\n%%EOF\n';return encode(text);
}
const upload=(bytes:Uint8Array,name:string,key='extended-upload')=>({bytes,fileName:name,requestKey:key});

test('safe SVG XML supports vector logo dimensions and internal gradients without altering source bytes',async()=>{
 const info=await inspectMediaBytes(svg,'image/svg+xml');assert.equal(info.extension,'svg');assert.equal(info.width,100);assert.equal(info.height,60);assert.equal(info.sha256,await sha256(svg));
 const namespace=encode('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="20px" height="30"><defs><path id="mark" d="M0 0L20 30"/></defs><use xlink:href="#mark"/></svg>');assert.equal((await inspectMediaBytes(namespace)).width,20);
});
test('SVG rejects malformed XML, active content, external references, DTD, non-UTF8 and oversized trees',async()=>{
 for(const content of ['<svg width="1" height="1"><script/></svg>','<svg width="1" height="1" onload="alert(1)"/>','<svg width="1" height="1"><use href="https://evil.invalid/a"/></svg>','<svg width="1" height="1"><path fill="url(//evil.invalid/x)"/></svg>','<svg width="1" height="1"><foreignObject/></svg>','<svg width="1" height="1"><g></svg>','<svg width="1" width="2" height="1"/>','<!DOCTYPE svg [<!ENTITY x "bad">]><svg width="1" height="1">&x;</svg>','<svg xmlns="urn:not-svg" width="1" height="1"/>','<svg width="1" height="1"><path style="fill:expres&#115;ion(alert(1))"/></svg>','<svg width="1" height="1">'+'<g>'.repeat(65)+'</g>'.repeat(65)+'</svg>'])await assert.rejects(inspectMediaBytes(encode(content)));
 await assert.rejects(inspectMediaBytes(new Uint8Array(Buffer.from('<svg width="1" height="1"/>','utf16le'))));await assert.rejects(inspectMediaBytes(svg,'image/png'));
});
test('PDF accepts ordinary download bytes and rejects active, encoded, encrypted and object-stream dictionaries',async()=>{
 const info=await inspectMediaBytes(pdf(),'application/pdf');assert.equal(info.extension,'pdf');assert.equal(info.width,0);assert.equal(info.height,0);
 for(const key of ['OpenAction','Open#41ction','JS','J#53','JavaScript','Launch','EmbeddedFile','RichMedia','AA','XFA','AcroForm','Encrypt','ObjStm'])await assert.rejects(inspectMediaBytes(pdf('/'+key+' 8 0 R')));
 await assert.rejects(inspectMediaBytes(encode('%PDF-1.7\nnot a document\n%%EOF')));await assert.rejects(inspectMediaBytes(encode(new TextDecoder().decode(pdf())+'garbage')));
});
test('extended inventory shares owner, quotas, idempotency and soft-deletion rules while preserving raster table identity',async()=>{
 const f=mediaFixture();try{
  const raster=await saveMedia(f.env,'u','p',upload(png(),'one.png','raster-upload')),vector=await saveMedia(f.env,'u','p',upload(svg,'标志.svg')),document=await saveMedia(f.env,'u','p',upload(pdf(),'产品手册.pdf','document-upload'));
  assert.equal((await listMedia(f.env,'u','p')).length,3);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media').get()!.n,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media_extended').get()!.n,2);
  assert.equal((await saveMedia(f.env,'u','p',upload(svg,'标志.svg'))).id,vector.id);await assert.rejects(saveMedia(f.env,'u','p',upload(png(),'other.png')),/请求编号/);
  await assert.rejects(readMedia(f.env,'other',document.id));await setMediaDeleted(f.env,'u',document.id,true);await assert.rejects(readMedia(f.env,'u',document.id));await setMediaDeleted(f.env,'u',document.id,false);assert.deepEqual((await readMedia(f.env,'u',document.id)).bytes,pdf());assert.deepEqual((await readMedia(f.env,'u',raster.id)).bytes,png());
  assert.deepEqual(f.db.sqlite.prepare('PRAGMA foreign_key_check').all(),[]);
 }finally{f.db.close();}
});
test('cross-format concurrent request-key collision preserves exactly one immutable asset identity',async()=>{
 const f=mediaFixture();try{const results=await Promise.allSettled([saveMedia(f.env,'u','p',upload(svg,'logo.svg')),saveMedia(f.env,'u','p',upload(png(),'logo.png'))]);assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media_inventory').get()!.n,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM mutation_guards').get()!.n,0);}finally{f.db.close();}
});
test('extended lost PUT acknowledgement is recoverable and combined inventory enforces the 500 file cap',async()=>{
 const f=mediaFixture();try{f.storage.failAfter=true;await assert.rejects(saveMedia(f.env,'u','p',upload(svg,'logo.svg')));assert.equal(f.db.sqlite.prepare('SELECT state FROM project_media_extended').get()!.state,'staging');const media=await saveMedia(f.env,'u','p',upload(svg,'logo.svg'));assert.equal(media.state,'ready');
  f.db.sqlite.prepare(`WITH RECURSIVE n(i) AS (SELECT 1 UNION ALL SELECT i+1 FROM n WHERE i<499) INSERT INTO project_media(id,user_id,project_id,request_key,request_hash,object_key,filename,mime_type,extension,byte_size,width,height,sha256,source,state,created_at,updated_at) SELECT 'f'||i,'u','p','f'||i,'h','private/f'||i,'f.png','image/png','png',1,1,1,'h','upload','ready','2026-11-07','2026-11-07' FROM n`).run();
  await assert.rejects(saveMedia(f.env,'u','p',upload(pdf(),'handbook.pdf','another-document')),/上限/);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media_inventory').get()!.n,500);
 }finally{f.db.close();}
});
test('safe SVG and PDF package round trip preserves bytes and rejects PDF visual bindings before storing uploads',async()=>{
 const f=mediaFixture();try{const manifest=starterManifest('studio')!,files=[{file:'assets/0.svg',bytes:svg},{file:'assets/1.pdf',bytes:pdf()}];manifest.assets=await Promise.all(files.map(async file=>({file:file.file,path:'/uploads/2026/11/'+await sha256(file.bytes)+'.'+file.file.split('.').pop(),sha256:await sha256(file.bytes),size:file.bytes.length})));
  manifest.templates[0].document.html+='<img src="'+manifest.assets[0].path+'"><a href="'+manifest.assets[1].path+'">下载资料</a>';assert.equal(validateSiteManifest(manifest).valid,true);
  const candidate=await importTemplatePackage(f.env,'u','p',templateZip(manifest,files)),stored=JSON.parse((await readDesignCandidate(f.env,'u','p',candidate.id)).manifest_json),resolved=await resolveProjectAssets(f.env,'u','p',stored),round=await readTemplateZip(templateZip(stored,resolved.files));assert.deepEqual(round.files,files);const vector=(await listMedia(f.env,'u','p')).find(a=>a.extension==='svg')!;await assert.rejects(setMediaDeleted(f.env,'u',vector.id,true),/引用/);
  for(const html of ['<img src="'+manifest.assets[1].path+'">','<source srcset="'+manifest.assets[1].path+' 2x">','<div style="background:url('+manifest.assets[1].path+')"></div>']){const invalid=structuredClone(manifest);invalid.templates[0].document.html+=html;assert.ok(validateSiteManifest(invalid).issues.some(i=>i.code==='policy_pdf_visual_reference'));await assert.rejects(importTemplatePackage(f.env,'u','p2',templateZip(invalid,files)));}
  const structured=structuredClone(manifest);structured.templates[0].document.project={components:[{tagName:'img',attributes:{src:manifest.assets[1].path}}]};assert.ok(validateSiteManifest(structured).issues.some(i=>i.code==='policy_pdf_visual_reference'));
  assert.equal((await listMedia(f.env,'u','p2')).length,0);
 }finally{f.db.close();}
});
test('PDF HTTP download remains authenticated, attachment-only and non-sniffable',async()=>{
 const f=mediaFixture();try{const media=await saveMedia(f.env,'u','p',upload(pdf(),'guide.pdf')),token=randomToken(32),now=new Date().toISOString();f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,expires_at,created_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session','u',await sha256(token),'csrf',new Date(Date.now()+60000).toISOString(),now,'fixture');
  const app=new Hono<App>();app.route('/api/media',mediaRoutes);const response=await app.request('/api/media/assets/'+media.id+'/content',{headers:{cookie:'benos_session='+token}},f.env);assert.equal(response.status,200);assert.equal(response.headers.get('content-type'),'application/pdf');assert.match(response.headers.get('content-disposition')!,/^attachment;/);assert.equal(response.headers.get('x-content-type-options'),'nosniff');assert.deepEqual(new Uint8Array(await response.arrayBuffer()),pdf());
 }finally{f.db.close();}
});
