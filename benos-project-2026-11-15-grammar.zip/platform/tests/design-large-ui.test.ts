import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-ignore Browser module uses stable source identifiers, never full manifests.
import { designHistory,recordDesignAdoption,restoreDesignVersion } from '../public/js/design-history.js';
// @ts-ignore Exercise the actual editor's network boundary.
import { loadDesignResource } from '../public/js/design.js';

function installFetch(fn:(url:string,body:any)=>any){const old=globalThis.fetch;globalThis.fetch=(async(url:any,init:any)=>{const value=await fn(String(url),init?.body?JSON.parse(init.body):null);return Response.json({ok:true,data:value});}) as typeof fetch;return()=>{globalThis.fetch=old;};}
test('large design adoption undo/redo retain only IDs and send bounded source restore requests',async()=>{
 const user='history-ids',project='p',calls:any[]=[];recordDesignAdoption(user,project,'before','after');
 const stop=installFetch((url,body)=>{calls.push({url,body});return{versionId:calls.length===1?'undo-new':'redo-new',currentVersionId:calls.length===1?'undo-new':'redo-new',replayed:false};});
 try{await restoreDesignVersion(user,project,'after','undo');assert.equal(designHistory(user,project,'undo-new').redo.length,1);await restoreDesignVersion(user,project,'undo-new','redo');assert.equal(designHistory(user,project,'redo-new').undo.length,1);assert.deepEqual(calls.map(c=>c.body.sourceVersionId),['before','after']);assert.ok(calls.every(c=>JSON.stringify(c.body).length<300&&!('manifest'in c.body)));assert.doesNotMatch(JSON.stringify(designHistory(user,project,'redo-new')),/document|manifest|before":|after":/);}finally{stop();}
});
test('lost restore acknowledgement keeps the original expected head and key even if a newer head appears',async()=>{
 const user='history-lost',project='p',calls:any[]=[];recordDesignAdoption(user,project,'v1','v2');let fail=true;
 const stop=installFetch((_url,body)=>{calls.push(body);if(fail){fail=false;throw new Error('response lost');}return{versionId:'restored-v1',currentVersionId:'independent-newer',replayed:true};});
 try{await assert.rejects(()=>restoreDesignVersion(user,project,'v2','undo'));assert.ok(designHistory(user,project,'independent-newer').pending);const result=await restoreDesignVersion(user,project,'independent-newer','undo');assert.equal(result.superseded,true);assert.deepEqual(calls[0],calls[1]);assert.equal(calls[1].expectedCurrentVersionId,'v2');assert.equal(designHistory(user,project,'independent-newer').undo.length,0);}finally{stop();}
});
test('explicit history restore uses a source ID while an unrelated operation cannot replace its pending key',async()=>{
 const user='history-restore',project='p';const stop=installFetch(()=>{throw new Error('lost');});
 try{await assert.rejects(()=>restoreDesignVersion(user,project,'head','restore','old'));const pending=designHistory(user,project,'head').pending;assert.equal(pending.sourceVersionId,'old');await assert.rejects(()=>restoreDesignVersion(user,project,'head','undo'),/原请求/);assert.equal(designHistory(user,project,'head').pending.requestKey,pending.requestKey);}finally{stop();}
});
test('editor reads bounded candidate/version projections and template-scoped nodes instead of full manifests',async()=>{
 const oldLocation=(globalThis as any).location;(globalThis as any).location={hash:'#design/p?candidate=c'};const calls:string[]=[];
 const view=(kind:string,id:string)=>({projectionVersion:1,sourceKind:kind,sourceId:id,contentHash:'hash-'+id,byteSize:9969143,currentVersionId:'v',version:kind==='version'?1:null,candidate:kind==='candidate'?{id,state:'draft',baseVersionId:'v',scope:{kind:'site'}}:null,site:{name:'Large',home:'home',pages:[{key:'home',template_id:7,title:'首页'}]},templates:[{id:7,name:'首页',type:'page'}],assets:[],styleOptions:{fonts:[]},pageOptions:[{key:'home',label:'首页'}]});
 const stop=installFetch(url=>{calls.push(url);if(url==='/api/projects/p')return{id:'p',current_version_id:'v'};if(url.includes('/editor-view?candidate='))return view('candidate','c');if(url.includes('/editor-view?version='))return view('version','v');if(url.includes('/editor-nodes?'))return{sourceId:'v',contentHash:'hash-v',templateId:7,items:[{templateId:7,nodeKey:'n0',tag:'section',label:'首页'}],nextCursor:'opaque'};if(url.endsWith('/quote')||url.endsWith('/workflow-quote'))return{available:false};return{items:[]};});
 try{const data=await loadDesignResource('p',{id:'reader'});assert.equal(data.selected.editorView.byteSize,9969143);assert.equal(data.selected.manifest,undefined);assert.equal(data.visual.proposal.manifest,undefined);assert.ok(calls.some(url=>url.includes('templateId=7&limit=100')));assert.ok(!calls.some(url=>/\/versions\/v($|\?)/.test(url)));assert.ok(!calls.includes('/api/design/projects/p/candidates/c'));assert.equal(data.visual.nodePages[7].nextCursor,'opaque');}finally{stop();(globalThis as any).location=oldLocation;}
});
// @ts-ignore Browser JSON editor: validate task metadata without loading its full source.
import { renderManifestEditor,validateManifestEditView } from '../public/js/design-manifest-editor.js';

test('large JSON editor never places the whole manifest into a textarea and offers explicit bounded editing',()=>{
 const html=renderManifestEditor({project:{id:'large-manual',current_version_id:'v'},selected:{id:'v',version:3,editorView:{byteSize:9969143},manifest:{unsafeTestMarker:'WHOLE_MANIFEST_MUST_NOT_BE_RENDERED'}}},{id:'manual-ui'},{editing:true});assert.doesNotMatch(html,/WHOLE_MANIFEST/);assert.match(html,/manifest-source\?version=v/);assert.match(html,/开始分段编辑此版本/);assert.match(html,/校验并保存新版本/);assert.match(html,/每段最多 128 KiB/);assert.ok(html.length<12000);
});
test('advanced JSON progress rejects missing chunks, changed identity, and forged confirmed offsets',()=>{
 const request={requestKey:'stable-request',baseVersionId:'base',fileName:'manifest.json',totalBytes:2000000};const view:any={id:'edit',projectId:'p',mode:'upload',fileName:'manifest.json',baseVersionId:'base',sourceVersionId:null,state:'uploading',revision:0,completedSteps:0,totalBytes:2000000,uploadTotalBytes:2000000,receivedBytes:1048576,chunkSize:1048576,chunks:[{index:0,offset:0,size:1048576,sha256:'a'.repeat(64)}]};assert.equal(validateManifestEditView(view,request,'edit','p'),view);for(const change of [{receivedBytes:1048577},{chunks:[]},{id:'other'},{projectId:'other'},{sourceVersionId:'invented'},{chunks:[{...view.chunks[0],offset:1}]}])assert.throws(()=>validateManifestEditView({...view,...change},request,'edit','p'));
});
// @ts-ignore Same browser module, exercising durable task identity on an unknown create result.
import { handleManifestAction } from '../public/js/design-manifest-editor.js';
test('advanced editor creation acknowledgement loss retries the same small source request without a new task',async()=>{
 const calls:any[]=[],context={state:{user:{id:'manifest-lost-create'},resource:{project:{id:'p',current_version_id:'head'},selected:{id:'source',version:1}}}};let fail=true;
 const stop=installFetch((url,body)=>{calls.push({url,body});if(fail){fail=false;throw new Error('ack lost');}return{id:'edit-source',projectId:'p',mode:'source',fileName:'manifest.json',baseVersionId:'head',sourceVersionId:'source',state:'preparing',revision:0,completedSteps:0,totalBytes:10420224,uploadTotalBytes:10420224,receivedBytes:10420224,chunkSize:1048576,chunks:[]};});
 try{await handleManifestAction('design-manifest-source',{},context);await handleManifestAction('design-manifest-continue',{},context);assert.equal(calls.length,2);assert.deepEqual(calls[0],calls[1]);assert.deepEqual(Object.keys(calls[1].body).sort(),['baseVersionId','requestKey','sourceVersionId']);assert.ok(JSON.stringify(calls[1].body).length<250);}finally{stop();}
});

test('temporary empty JSON remains readable for repair while the original upload identity stays nonempty',()=>{
 const request={requestKey:'empty-repair',baseVersionId:'base',sourceVersionId:'source'},view={id:'edit-empty',projectId:'p',mode:'source',fileName:'manifest.json',baseVersionId:'base',sourceVersionId:'source',state:'editing',revision:1,completedSteps:1,totalBytes:0,uploadTotalBytes:100,receivedBytes:100,chunkSize:1048576,chunks:[]};assert.equal(validateManifestEditView(view,request,'edit-empty','p'),view);assert.throws(()=>validateManifestEditView({...view,totalBytes:-1},request,'edit-empty','p'));assert.throws(()=>validateManifestEditView({...view,uploadTotalBytes:0},request,'edit-empty','p'));
});
// @ts-ignore Parent pointer coordinates must account for CSS zoom and mobile iframe widths.
import { visualFramePoint } from '../public/js/design-editor.js';
test('parent selection hit testing respects scaled iframe coordinates and rejects clicks outside it',()=>{
 const rect={left:100,top:200,width:780,height:1000};assert.deepEqual(visualFramePoint(rect,{width:390,height:500},490,700),{x:195,y:250});assert.equal(visualFramePoint(rect,{width:390,height:500},99,700),null);assert.equal(visualFramePoint({...rect,width:0},{width:390,height:500},100,200),null);
});
