import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mediaFixture,png } from './media-helper';
import { starterManifest } from '../src/contracts/starter-library';
import { saveVersion } from '../src/modules/ai';
import { readDesignVersion } from '../src/modules/design-workspace';
import { saveMedia,setMediaDeleted } from '../src/modules/media';
import { sha256 } from '../src/lib/crypto';
import { AppError } from '../src/lib/errors';
import { createManifestEdit,putManifestEditChunk,continueManifestEdit,manifestEditStatus,listManifestEditSegments,readManifestEditSegment,patchManifestEdit,commitManifestEdit,cancelManifestEdit,purgeManifestEdits,manifestEditOperation,downloadManifestSource,continuePendingManifestEdits } from '../src/modules/manifest-edits';

const MIB=1048576,DAY=86400000;
class R2 {
 objects=new Map<string,Uint8Array>();losePut=false;loseDelete=false;puts=0;onGet:((key:string)=>void)|null=null;onPut:((key:string)=>void)|null=null;
 digest(bytes:Uint8Array){return createHash('sha256').update(bytes).digest('hex');}
 async put(key:string,bytes:Uint8Array,options?:any){this.puts++;if(options?.onlyIf&&this.objects.has(key))return null;this.onPut?.(key);this.objects.set(key,new Uint8Array(bytes));if(this.losePut){this.losePut=false;throw new Error('PUT ACK lost');}return {key,size:bytes.length,etag:this.digest(bytes)};}
 async head(key:string){const bytes=this.objects.get(key);return bytes?{key,size:bytes.length,etag:this.digest(bytes)}:null;}
 async get(key:string,options?:any){this.onGet?.(key);const bytes=this.objects.get(key);if(!bytes)return null;const etag=this.digest(bytes);if(options?.onlyIf?.etagMatches&&options.onlyIf.etagMatches!==etag)return {size:bytes.length,etag};const value=options?.range?bytes.subarray(options.range.offset,options.range.offset+options.range.length):bytes;return {key,size:bytes.length,etag,body:true,arrayBuffer:async()=>new Uint8Array(value).buffer};}
 async delete(keys:string|string[]){for(const key of Array.isArray(keys)?keys:[keys])this.objects.delete(key);if(this.loseDelete){this.loseDelete=false;throw new Error('DELETE ACK lost');}}
}
function fixture(){const f=mediaFixture(),storage=new R2();f.env.BUCKET=storage as unknown as R2Bucket;return {...f,storage};}
type Fixture=ReturnType<typeof fixture>;
const errorCode=(code:string)=>(e:any)=>e instanceof AppError&&e.code===code;
const head=(f:Fixture,project='p')=>String(f.db.sqlite.prepare('SELECT current_version_id FROM projects WHERE id=?').get(project)!.current_version_id);
const count=(f:Fixture)=>Number(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n);
function large(size=10*MIB-256){const manifest=starterManifest('studio')!,extra=size-new TextEncoder().encode(JSON.stringify(manifest)).length-8;manifest.templates[0].document.css+='/*'+'x'.repeat(Math.floor(extra/2))+'*/';manifest.templates[1].document.css+='/*'+'y'.repeat(extra-Math.floor(extra/2))+'*/';return manifest;}
async function initial(f:Fixture,manifest:unknown=starterManifest('studio')){return saveVersion(f.env,'u','p',manifest,'manual',null,'manifest-initial');}
async function prepared(f:Fixture,id:string){let state=await manifestEditStatus(f.env,'u',id);for(let n=0;state.state==='preparing'&&n<60;n++)state=await continueManifestEdit(f.env,'u',id,state.completedSteps+1);assert.equal(state.state,'editing');return state;}
async function source(f:Fixture,version:string){return prepared(f,(await createManifestEdit(f.env,'u','p',{requestKey:'source-edit-request',baseVersionId:version,sourceVersionId:version})).id);}
async function upload(f:Fixture,text:string,baseVersionId:string|null=null){const bytes=new TextEncoder().encode(text);let task=await createManifestEdit(f.env,'u','p',{requestKey:'upload-edit-request',baseVersionId,fileName:'manifest.json',totalBytes:bytes.length});for(let index=0;index<Math.ceil(bytes.length/MIB);index++){const offset=index*MIB,part=bytes.slice(offset,offset+MIB);task=await putManifestEditChunk(f.env,'u',task.id,{index,offset,sha256:await sha256(part),bytes:part});}return prepared(f,task.id);}

test('near10MiB source is segmented and patched without full request bodies; confirmed manual commit saves once and never rewinds later head',async()=>{
 const f=fixture();try{const manifest=large();manifest.site.name='Source site name marker';const version=await initial(f,manifest),task=await source(f,version);assert.ok(task.segmentCount>150);const page=await listManifestEditSegments(f.env,'u',task.id);assert.equal(page.items.length,40);assert.equal(page.nextCursor,40);
  let segment=await readManifestEditSegment(f.env,'u',task.id,0);for(let i=1;!segment.text.includes(manifest.site.name)&&i<task.segmentCount;i++)segment=await readManifestEditSegment(f.env,'u',task.id,i);const text=segment.text.replace(manifest.site.name,'Benos 大模板');assert.notEqual(text,segment.text);const request={requestKey:'patch-request-0001',expectedRevision:0,segmentIndex:segment.index,expectedSha:segment.sha256,text};const patched=await patchManifestEdit(f.env,'u',task.id,request);assert.equal(patched.revision,1);assert.equal(head(f),version);assert.equal((await patchManifestEdit(f.env,'u',task.id,request)).revision,1);
  const saved=await commitManifestEdit(f.env,'u',task.id,{requestKey:'commit-request-0001',expectedRevision:1});assert.equal(saved.state,'saved');assert.equal(count(f),2);const result=await readDesignVersion(f.env,'u','p',saved.resultVersionId!);assert.equal(result.site.name,'Benos 大模板');assert.deepEqual(result.templates,manifest.templates);assert.equal(saved.currentVersionId,saved.resultVersionId);
  const later=await saveVersion(f.env,'u','p',manifest,'manual',saved.resultVersionId,'later-version');assert.equal((await commitManifestEdit(f.env,'u',task.id,{requestKey:'commit-request-0001',expectedRevision:1})).resultVersionId,saved.resultVersionId);assert.equal(head(f),later);assert.equal(count(f),3);
  await purgeManifestEdits(f.env);assert.equal((await manifestEditStatus(f.env,'u',task.id)).state,'saved');assert.equal(await downloadManifestSource(f.env,'u','p',saved.resultVersionId!),JSON.stringify(result));assert.equal([...f.storage.objects.keys()].filter(k=>k.includes('/manifest-edits/')).length,0);
 }finally{f.db.close();}
});

test('UTF8 characters across 64KiB boundaries retain exact bytes; syntactically invalid upload can be repaired before explicit save',async()=>{
 const f=fixture();try{const manifest=starterManifest('studio')!;manifest.templates[0].document.css+='/*'+'设计🌟'.repeat(20000)+'*/';const valid=JSON.stringify(manifest),broken='!'+valid.slice(1),task=await upload(f,broken);let assembled='';for(let index=0;index<task.segmentCount;index++)assembled+=(await readManifestEditSegment(f.env,'u',task.id,index)).text;assert.equal(assembled,broken);assert.equal(count(f),0);
  await assert.rejects(commitManifestEdit(f.env,'u',task.id,{requestKey:'invalid-commit-001',expectedRevision:0}),errorCode('MANIFEST_EDIT_JSON'));assert.equal((await manifestEditOperation(f.env,'u',task.id,'invalid-commit-001')).state,'failed');assert.equal((await manifestEditStatus(f.env,'u',task.id)).state,'editing');assert.equal(count(f),0);
  const segment=await readManifestEditSegment(f.env,'u',task.id,0);await patchManifestEdit(f.env,'u',task.id,{requestKey:'repair-patch-0001',expectedRevision:0,segmentIndex:0,expectedSha:segment.sha256,text:'{'+segment.text.slice(1)});const saved=await commitManifestEdit(f.env,'u',task.id,{requestKey:'repaired-commit-1',expectedRevision:1});assert.deepEqual(await readDesignVersion(f.env,'u','p',saved.resultVersionId!),manifest);
 }finally{f.db.close();}
});

test('lost PUT, patch and final transaction acknowledgements reconcile original identities with no duplicate patch/version',async()=>{
 const f=fixture();try{const task=await upload(f,JSON.stringify(starterManifest('studio'))),segment=await readManifestEditSegment(f.env,'u',task.id,0);f.storage.losePut=true;const batch=f.db.batch.bind(f.db);let patchAck=false,commitAck=false;(f.db as any).batch=async(ss:any[])=>{const value=await batch(ss);if(!patchAck&&ss.some(s=>s.sql.includes('revision=revision+1'))){patchAck=true;throw new Error('lost patch ack');}if(!commitAck&&ss.some(s=>s.sql.includes('INSERT INTO design_versions'))){commitAck=true;throw new Error('lost commit ack');}return value;};
  const request={requestKey:'lost-patch-ack-01',expectedRevision:0,segmentIndex:0,expectedSha:segment.sha256,text:segment.text.replace('Studio','Studio Next')};const patch=await patchManifestEdit(f.env,'u',task.id,request);assert.equal(patch.revision,1);assert.equal(patchAck,true);assert.equal((await manifestEditOperation(f.env,'u',task.id,request.requestKey)).state,'completed');const saved=await commitManifestEdit(f.env,'u',task.id,{requestKey:'lost-commit-ack01',expectedRevision:1});assert.equal(commitAck,true);assert.equal(saved.state,'saved');assert.equal(count(f),1);assert.equal((await commitManifestEdit(f.env,'u',task.id,{requestKey:'lost-commit-ack01',expectedRevision:1})).resultVersionId,saved.resultVersionId);
 }finally{f.db.close();}
});

test('ownership, exact offsets, revision, conflicting request identities and invalid Unicode cannot mutate a draft',async()=>{
 const f=fixture();try{const text=JSON.stringify(starterManifest('studio')),bytes=new TextEncoder().encode(text),task=await createManifestEdit(f.env,'u','p',{requestKey:'upload-test-key-01',baseVersionId:null,fileName:'manifest.json',totalBytes:bytes.length});await assert.rejects(createManifestEdit(f.env,'u','p2',{requestKey:'upload-test-key-01',baseVersionId:null,fileName:'manifest.json',totalBytes:bytes.length}),errorCode('IDEMPOTENCY_CONFLICT'));await assert.rejects(manifestEditStatus(f.env,'other',task.id),errorCode('NOT_FOUND'));
  await assert.rejects(putManifestEditChunk(f.env,'u',task.id,{index:1,offset:0,sha256:await sha256(bytes),bytes}),errorCode('MANIFEST_EDIT_CHUNK'));await putManifestEditChunk(f.env,'u',task.id,{index:0,offset:0,sha256:await sha256(bytes),bytes});await prepared(f,task.id);const segment=await readManifestEditSegment(f.env,'u',task.id,0),request={requestKey:'guard-patch-key01',expectedRevision:0,segmentIndex:0,expectedSha:segment.sha256,text:segment.text};await assert.rejects(patchManifestEdit(f.env,'u',task.id,{...request,text:'\ud800'}),errorCode('MANIFEST_EDIT_ENCODING'));await assert.rejects(patchManifestEdit(f.env,'u',task.id,{...request,expectedSha:'0'.repeat(64)}),errorCode('MANIFEST_EDIT_REVISION'));await patchManifestEdit(f.env,'u',task.id,request);await assert.rejects(patchManifestEdit(f.env,'u',task.id,{...request,text:'x'}),errorCode('IDEMPOTENCY_CONFLICT'));await assert.rejects(patchManifestEdit(f.env,'u',task.id,{...request,requestKey:'guard-patch-key02'}),errorCode('MANIFEST_EDIT_REVISION'));assert.equal(count(f),0);
 }finally{f.db.close();}
});

test('source corruption is rejected before editing; archived account/head/media races cannot save versions',async()=>{
 for(const race of ['source','archive','account','head','media']){const f=fixture();try{const manifest=race==='source'?large(2*MIB):starterManifest('studio')!;let task:any;
  if(race==='media'){const media=await saveMedia(f.env,'u','p',{bytes:png(),fileName:'x.png',requestKey:'asset-for-edit-01'});manifest.assets=[{file:'assets/0.png',path:media.assetPath,sha256:media.sha256,size:media.byteSize}];task=await upload(f,JSON.stringify(manifest));}
  else{const version=await initial(f,manifest);task=await createManifestEdit(f.env,'u','p',{requestKey:'source-edit-request',baseVersionId:version,sourceVersionId:version});if(race==='source'){const key=[...f.storage.objects.keys()].find(k=>k.includes('/manifests/'))!,bytes=f.storage.objects.get(key)!;bytes[100]^=1;for(let n=0;n<20;n++){const current=await manifestEditStatus(f.env,'u',task.id);if(current.state!=='preparing')break;await continueManifestEdit(f.env,'u',task.id,current.completedSteps+1);}const failed=await manifestEditStatus(f.env,'u',task.id);assert.notEqual(failed.state,'editing');assert.equal(failed.errorCode,'MANIFEST_EDIT_SOURCE');continue;}task=await prepared(f,task.id);}
  const before=count(f);let fired=false;const batch=f.db.batch.bind(f.db);(f.db as any).batch=async(ss:any[])=>{if(!fired&&ss.some(s=>s.sql.includes('INSERT INTO design_versions'))){fired=true;if(race==='archive')f.db.sqlite.prepare("UPDATE projects SET archived_at=? WHERE id='p'").run(new Date().toISOString());if(race==='account')f.db.sqlite.prepare("UPDATE users SET status='restricted' WHERE id='u'").run();if(race==='head')f.db.sqlite.prepare("UPDATE projects SET current_version_id=NULL WHERE id='p'").run();if(race==='media')f.db.sqlite.prepare("UPDATE media_assets SET state='deleted' WHERE project_id='p'").run();}return batch(ss);};await assert.rejects(commitManifestEdit(f.env,'u',task.id,{requestKey:'raced-commit-001',expectedRevision:0}));assert.equal(fired,true,race);assert.equal(count(f),before);assert.notEqual(f.db.sqlite.prepare('SELECT state FROM manifest_edits WHERE id=?').get(task.id)!.state,'saved');
 }finally{f.db.close();}}
});

test('cancellation during PUT prevents promotion; retained tombstone removes a late object and cleanup failure keeps quota',async()=>{
 const f=fixture();try{const text=JSON.stringify(starterManifest('studio')),bytes=new TextEncoder().encode(text),task=await createManifestEdit(f.env,'u','p',{requestKey:'cancel-upload-001',baseVersionId:null,fileName:'manifest.json',totalBytes:bytes.length});f.storage.onPut=()=>{f.storage.onPut=null;f.db.sqlite.prepare("UPDATE manifest_edits SET state='cancelled',lease_token=NULL,lease_until_ms=NULL WHERE id=?").run(task.id);};await assert.rejects(putManifestEditChunk(f.env,'u',task.id,{index:0,offset:0,sha256:await sha256(bytes),bytes}));assert.equal((await manifestEditStatus(f.env,'u',task.id)).receivedBytes,0);const key=[...f.storage.objects.keys()][0];f.storage.loseDelete=true;assert.equal((await purgeManifestEdits(f.env)).uncertain,1);f.storage.loseDelete=true;await assert.rejects(createManifestEdit(f.env,'u','p',{requestKey:'next-upload-key1',baseVersionId:null,fileName:'manifest.json',totalBytes:bytes.length}),errorCode('MANIFEST_EDIT_QUOTA'));assert.equal((await purgeManifestEdits(f.env)).removed,1);f.storage.objects.set(key,bytes);assert.equal((await purgeManifestEdits(f.env,Date.now()+DAY+1)).removed,1);assert.equal(f.storage.objects.has(key),false);assert.equal(count(f),0);
 }finally{f.db.close();}
});

test('expired lease, canceled tasks and concurrent commits cannot append a second version; maintenance prepares but never invents save consent',async()=>{
 const f=fixture();try{const version=await initial(f),task=await createManifestEdit(f.env,'u','p',{requestKey:'maintenance-edit1',baseVersionId:version,sourceVersionId:version});await continuePendingManifestEdits(f.env);assert.equal((await manifestEditStatus(f.env,'u',task.id)).state,'editing');assert.equal(count(f),1);const settled=await Promise.allSettled([commitManifestEdit(f.env,'u',task.id,{requestKey:'same-commit-key01',expectedRevision:0}),commitManifestEdit(f.env,'u',task.id,{requestKey:'same-commit-key01',expectedRevision:0})]);assert.ok(settled.some(s=>s.status==='fulfilled'));assert.equal(count(f),2);assert.equal((await manifestEditOperation(f.env,'u',task.id,'same-commit-key01')).state,'completed');
  await purgeManifestEdits(f.env);const next=await createManifestEdit(f.env,'u','p',{requestKey:'cancel-after-save',baseVersionId:head(f),sourceVersionId:version});await cancelManifestEdit(f.env,'u',next.id);await assert.rejects(continueManifestEdit(f.env,'u',next.id,1),errorCode('MANIFEST_EDIT_CLOSED'));assert.equal(count(f),2);
 }finally{f.db.close();}
});

test('lease expiry during R2 reads and GC winning the immutable manifest race both block final append',async()=>{
 for(const race of ['lease','manifest-gc']){const f=fixture();try{const version=await initial(f,race==='manifest-gc'?large(2*MIB):undefined),task=await source(f,version);const segment=await readManifestEditSegment(f.env,'u',task.id,0);await patchManifestEdit(f.env,'u',task.id,{requestKey:'lease-race-patch1',expectedRevision:0,segmentIndex:0,expectedSha:segment.sha256,text:segment.text+' '});const before=count(f);
  if(race==='lease')f.storage.onGet=key=>{if(key.includes('/manifest-edits/')){f.storage.onGet=null;f.db.sqlite.prepare('UPDATE manifest_edits SET lease_until_ms=1 WHERE id=?').run(task.id);}};
  else{const batch=f.db.batch.bind(f.db);(f.db as any).batch=async(ss:any[])=>{if(ss.some(s=>s.sql.includes('INSERT INTO design_versions')))f.db.sqlite.prepare("UPDATE design_manifest_objects SET state='purging' WHERE id NOT IN (SELECT manifest_object_id FROM design_versions WHERE manifest_object_id IS NOT NULL)").run();return batch(ss);};}
  await assert.rejects(commitManifestEdit(f.env,'u',task.id,{requestKey:'lease-race-save01',expectedRevision:1}));assert.equal(count(f),before);assert.equal(head(f),version);
 }finally{f.db.close();}}
});

test('expired drafts refuse fresh uploads; a completed buffer is reclaimed on the next edit without a scheduler',async()=>{
 const f=fixture();try{const text=JSON.stringify(starterManifest('studio')),bytes=new TextEncoder().encode(text),old=await createManifestEdit(f.env,'u','p',{requestKey:'expired-upload01',baseVersionId:null,fileName:'manifest.json',totalBytes:bytes.length},Date.now()-DAY-10);await assert.rejects(putManifestEditChunk(f.env,'u',old.id,{index:0,offset:0,sha256:await sha256(bytes),bytes}),errorCode('MANIFEST_EDIT_EXPIRED'));
  const task=await upload(f,text),saved=await commitManifestEdit(f.env,'u',task.id,{requestKey:'schedulerless-save',expectedRevision:0});const next=await createManifestEdit(f.env,'u','p',{requestKey:'schedulerless-next',baseVersionId:saved.resultVersionId,sourceVersionId:saved.resultVersionId!});assert.equal(next.state,'preparing');assert.equal(f.db.sqlite.prepare('SELECT cleanup_state FROM manifest_edits WHERE id=?').get(task.id)!.cleanup_state,'purged');assert.equal(count(f),1);assert.ok(await downloadManifestSource(f.env,'u','p',saved.resultVersionId!));
 }finally{f.db.close();}
});

test('a deliberately empty draft stays readable and repairable without falsely saving a website',async()=>{
 const f=fixture();try{const text=JSON.stringify(starterManifest('studio')),task=await upload(f,text),segment=await readManifestEditSegment(f.env,'u',task.id,0);const empty=await patchManifestEdit(f.env,'u',task.id,{requestKey:'empty-draft-edit1',expectedRevision:0,segmentIndex:0,expectedSha:segment.sha256,text:''});assert.equal(empty.totalBytes,0);assert.equal((await readManifestEditSegment(f.env,'u',task.id,0)).text,'');await assert.rejects(commitManifestEdit(f.env,'u',task.id,{requestKey:'empty-draft-save1',expectedRevision:1}),errorCode('MANIFEST_EDIT_JSON'));assert.equal(count(f),0);
  await patchManifestEdit(f.env,'u',task.id,{requestKey:'repair-empty-edit',expectedRevision:1,segmentIndex:0,expectedSha:await sha256(''),text});const saved=await commitManifestEdit(f.env,'u',task.id,{requestKey:'repair-empty-save',expectedRevision:2});assert.equal(saved.state,'saved');assert.equal(count(f),1);
 }finally{f.db.close();}
});

test('an interrupted older patch becomes a failed receipt after a competing revision and cannot report false success',async()=>{
 const f=fixture();try{const task=await upload(f,JSON.stringify(starterManifest('studio'))),segment=await readManifestEditSegment(f.env,'u',task.id,0),first={requestKey:'pending-old-patch',expectedRevision:0,segmentIndex:0,expectedSha:segment.sha256,text:segment.text+' '};const batch=f.db.batch.bind(f.db);let interrupted=false;(f.db as any).batch=async(ss:any[])=>{if(!interrupted&&ss.some(s=>s.sql.includes('revision=revision+1'))){interrupted=true;throw Error('transaction never submitted');}return batch(ss);};await assert.rejects(patchManifestEdit(f.env,'u',task.id,first));assert.equal((await manifestEditOperation(f.env,'u',task.id,first.requestKey)).state,'pending');
  const next=await patchManifestEdit(f.env,'u',task.id,{...first,requestKey:'pending-new-patch',text:segment.text+'  '});assert.equal(next.revision,1);assert.equal((await manifestEditOperation(f.env,'u',task.id,first.requestKey)).state,'failed');await assert.rejects(patchManifestEdit(f.env,'u',task.id,first),errorCode('MANIFEST_EDIT_REVISION'));assert.equal(count(f),0);
 }finally{f.db.close();}
});

test('a stored chunk whose progress transaction did not commit is omitted from confirmed status and safely replayed',async()=>{
 const f=fixture();try{const bytes=new TextEncoder().encode(JSON.stringify(starterManifest('studio'))),task=await createManifestEdit(f.env,'u','p',{requestKey:'chunk-counter-001',baseVersionId:null,fileName:'manifest.json',totalBytes:bytes.length}),input={index:0,offset:0,sha256:await sha256(bytes),bytes};const batch=f.db.batch.bind(f.db);let failed=false;(f.db as any).batch=async(ss:any[])=>{if(!failed&&ss.some(s=>s.sql.includes('SET received_bytes='))){failed=true;throw Error('progress write never submitted');}return batch(ss);};await assert.rejects(putManifestEditChunk(f.env,'u',task.id,input));const pending=await manifestEditStatus(f.env,'u',task.id);assert.equal(pending.receivedBytes,0);assert.deepEqual(pending.chunks,[]);const puts=f.storage.puts,next=await putManifestEditChunk(f.env,'u',task.id,input);assert.equal(next.chunks.length,1);assert.equal(next.receivedBytes,bytes.length);assert.equal(f.storage.puts,puts,'Reuse original registered object rather than another PUT');await prepared(f,task.id);assert.equal(count(f),0);
 }finally{f.db.close();}
});
