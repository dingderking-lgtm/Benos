import test from 'node:test';
import assert from 'node:assert/strict';
import { encryptSecret,sha256 } from '../src/lib/crypto';
import { createImageGeneration,reconcileImageGeneration,imageGenerationQuote } from '../src/modules/images';
import { imageEstimatedCost } from '../src/modules/image-estimated-cost';
import { grantCredit,fundProvider,reserve,claimReservation,settle,getWallet,correctEstimatedImage,settleEstimatedImage } from '../src/modules/ledger';
import { meteredImageContract,createImageRequest,type ImagePricing } from '../src/lib/image-billing';
import { imageSlotSchema,imagePromptForSlot,type ImageSize } from '../src/lib/image-layout';
import { mediaFixture,png } from './media-helper';

const pricing:ImagePricing={baseUrl:'https://api.openai.com/v1',model:'gpt-image-2.6-flare',protocol:'images',providerPoolId:'images',n:1,size:'1024x1024',quality:'low',complexity:'low',outputFormat:'png',textInputMicrosPerMillion:5000000,cachedTextInputMicrosPerMillion:1250000,imageInputMicrosPerMillion:8000000,cachedImageInputMicrosPerMillion:2000000,imageOutputMicrosPerMillion:30000000,pricingConfirmedAt:'2026-11-14T00:00:00.000Z',billingContract:{kind:'metered-reserve-v1'}};
const input={prompt:'A quiet mountain landscape',requestKey:'image-estimate-test-0001',estimationPolicy:'image-estimate-v1' as const};
function usage(output=1000){return {input_tokens:100,input_tokens_details:{text_tokens:100,image_tokens:0},output_tokens:output,total_tokens:output+100,output_tokens_details:{image_tokens:output,text_tokens:0}};}
function response(output=1000,size:ImageSize='1024x1024',quality='low'){const [w,h]=size.split('x').map(Number);return {model:pricing.model,size,quality,output_format:'png',usage:usage(output),data:[{b64_json:Buffer.from(png(w,h)).toString('base64')}]};}
async function fixture(funds=10000000){const f=mediaFixture(),now=new Date().toISOString(),serialized=JSON.stringify(pricing),secret=await encryptSecret(JSON.stringify({apiKey:'sk-fixture-only'}),f.env.ENCRYPTION_KEY,'image-config');
 f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('image-config','image','Images','openai',1,'active',?,?,'passed','u',?)").run(serialized,secret,now);
 await grantCredit(f.env.DB,{id:'grant',userId:'u',source:'topup',amountMicros:funds,referenceId:'fixture-grant',startsAtMs:0});await fundProvider(f.env.DB,{id:'fund',providerId:'images',amountMicros:funds,referenceId:'fixture-fund'});
 return f;
}
type Fixture=Awaited<ReturnType<typeof fixture>>;
async function seed(f:Fixture,id:string,options:{size?:ImageSize;output?:number;time?:number;quality?:'low'|'medium';rate?:number;legacy?:boolean;fixture?:boolean;digest?:string}={}){
 const p={...pricing,size:options.size??pricing.size,quality:options.quality??pricing.quality,...(options.rate?{textInputMicrosPerMillion:options.rate}:{})},time=options.time??Date.now()-1000,actual=500+(options.output??1000)*30;
 const r=await reserve(f.env.DB,{id:'r-'+id,userId:'u',providerId:'images',amountMicros:1000000,requestKey:'image:'+id,nowMs:time});await claimReservation(f.env.DB,r.id,time);await settle(f.env.DB,{reservationId:r.id,actualMicros:actual,nowMs:time});
 const payload:any=createImageRequest(p,'fixture sample');if(options.legacy)delete payload.complexity;
 const billing:any=meteredImageContract({...p,textInputMicrosPerMillion:pricing.textInputMicrosPerMillion});if(options.fixture)billing.version='fixture-v1';
 f.db.sqlite.prepare(`INSERT INTO image_jobs(id,user_id,project_id,config_version_id,request_key,request_hash,reservation_id,state,request_json,pricing_json,usage_json,response_sha256,created_at,updated_at)
 VALUES(?,'u','p','image-config',?,'fixture',?,'failed',?,?,?,?,?,?)`).run(id,id,r.id,JSON.stringify({payload,billingContract:billing}),JSON.stringify(p),JSON.stringify(usage(options.output)),options.digest??await sha256(id),new Date(time).toISOString(),new Date(time).toISOString());
 return actual;
}
function key(job:any){return 'private/image-jobs/u/'+job.id+'/response.json';}

test('approved fallback is quality-specific, reserve capped, and has no fabricated samples',async()=>{const f=await fixture();try{
 for(const quality of ['low','medium'] as const)for(const size of ['1024x1024','1536x1024','1024x1536'] as const){const e=await imageEstimatedCost(f.env.DB,{...pricing,quality,size},1000000);assert.equal(e.estimatedMicros,quality==='low'?60000:300000);assert.equal(e.source,'approved-image-fallback-20261114');assert.equal(e.samples.length,0);assert.deepEqual(Object.values(e.sampleCounts),[0,0,0]);}
 assert.equal((await imageEstimatedCost(f.env.DB,pricing,12345)).estimatedMicros,12345);
 const quote=await imageGenerationQuote(f.env,'u','image-config','medium');assert.ok('quality' in quote);assert.equal(quote.quality,'medium');assert.equal(quote.estimatedMicrosForPlanning,300000);
}finally{f.db.close();}});

test('each size has its own latest 30 real receipts; small samples use cross-size max',async()=>{const f=await fixture();try{
 const now=Date.now();await seed(f,'old-landscape',{size:'1536x1024',output:4000,time:now-100000});
 for(let i=0;i<31;i++)await seed(f,'land-'+i,{size:'1536x1024',output:1000+i,time:now-5000+i});
 await seed(f,'portrait',{size:'1024x1536',output:3000,time:now-2000,legacy:true});
 let e=await imageEstimatedCost(f.env.DB,pricing,1000000,now);assert.deepEqual(e.sampleCounts,{'1024x1024':0,'1536x1024':30,'1024x1536':1});assert.equal(e.estimatedMicros,90500);assert.equal(e.ownMaxMicros,null);assert.equal(e.rule,'small-sample-cross-max');assert.ok(!e.samples.some(x=>x.jobId==='old-landscape'||x.jobId==='land-0'));assert.equal(e.samples.find(x=>x.jobId==='portrait')?.legacyComplexityOmitted,true);
 for(let i=0;i<5;i++)await seed(f,'square-'+i,{output:500+i,time:now-1000+i});
 e=await imageEstimatedCost(f.env.DB,pricing,1000000,now);assert.equal(e.sampleCounts['1024x1024'],5);assert.equal(e.rule,'own-max');assert.equal(e.estimatedMicros,15620);assert.equal(e.crossMaxMicros,90500);
}finally{f.db.close();}});

test('sample window excludes expired, wrong rates/quality, fixture, duplicate and unverifiable receipts',async()=>{const f=await fixture();try{
 const now=Date.now(),digest=await sha256('same-receipt');await seed(f,'valid',{time:now-1000,legacy:true,digest});await seed(f,'duplicate',{time:now-900,digest});
 await seed(f,'old',{time:now-31*86400000});await seed(f,'future',{time:now+1000});await seed(f,'rate',{rate:6000000});await seed(f,'quality',{quality:'medium'});await seed(f,'fixture',{fixture:true});await seed(f,'invalid');f.db.sqlite.prepare("UPDATE image_jobs SET usage_json='{}' WHERE id='invalid'").run();
 const e=await imageEstimatedCost(f.env.DB,pricing,1000000,now);assert.equal(e.samples.length,1);assert.equal(e.samples[0].jobId,'duplicate');
}finally{f.db.close();}});

test('unknown opted-in image settles the frozen estimate once, releases remainder and never redispatches',async()=>{const f=await fixture();try{
 let calls=0;const rt={fetch:async()=>{calls++;await seed(f,'after-freeze',{output:4000,time:Date.now()});throw new Error('transport lost');}};
 const job=await createImageGeneration(f.env,'u','p',input,rt);assert.equal(job.state,'failed');const e=f.db.sqlite.prepare('SELECT * FROM image_estimated_settlements WHERE job_id=?').get(job.id)!;assert.equal(e.estimated_micros,60000);assert.equal(JSON.parse(String(e.snapshot_json)).samples.length,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
 const before=(await getWallet(f.env.DB,'u')).consumedMicros;assert.equal((await createImageGeneration(f.env,'u','p',input,rt)).id,job.id);assert.equal(calls,1);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,before);
 const sample=await imageEstimatedCost(f.env.DB,pricing,1000000);assert.equal(sample.samples.length,1);assert.equal(sample.samples[0].jobId,'after-freeze');assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM ledger_events WHERE resource_id=? AND kind='settled'").get(job.reservation_id)!.n,1);
}finally{f.db.close();}});

test('legacy ambiguity retains its hold; malformed output with valid usage uses actual not estimate',async()=>{const f=await fixture();try{
 const legacy=await createImageGeneration(f.env,'u','p',{prompt:input.prompt,requestKey:'image-legacy-test-0001'},{fetch:async()=>{throw new Error('lost');}});assert.equal(legacy.state,'uncertain');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,1000000);
 const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>Response.json({...response(),data:[]})});assert.equal(job.state,'failed');assert.equal(f.db.sqlite.prepare('SELECT actual_micros FROM api_reservations WHERE id=?').get(job.reservation_id)!.actual_micros,30500);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_estimated_settlements').get()!.n,0);
}finally{f.db.close();}});

test('opted-in pre-dispatch failure releases the unused reservation without estimating a fee',async()=>{const f=await fixture();try{
 const originalBatch=f.env.DB.batch.bind(f.env.DB);(f.env.DB as any).batch=async(statements:any[])=>{const result=await originalBatch(statements);if(statements.some(s=>s.sql.includes('INSERT INTO api_reservations')))f.db.sqlite.prepare('UPDATE provider_pools SET enabled=0').run();return result;};
 let calls=0;const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{calls++;return Response.json(response());}});assert.equal(calls,0);assert.equal(job.state,'failed');assert.equal(job.error_code,'IMAGE_DISPATCH_CONFLICT');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,0);assert.equal(f.db.sqlite.prepare('SELECT state FROM api_reservations').get()!.state,'released');assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_estimated_settlements').get()!.n,0);
}finally{f.db.close();}});

test('late receipt refunds only the delta, leaves original rows immutable and becomes a true sample',async()=>{const f=await fixture();try{
 let calls=0;f.storage.failAfter=true;const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{calls++;return Response.json(response());}});assert.equal(job.state,'failed');assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,60000);
 const original=JSON.stringify(f.db.sqlite.prepare('SELECT * FROM api_reservations WHERE id=?').get(job.reservation_id)),alloc=JSON.stringify(f.db.sqlite.prepare('SELECT * FROM reservation_allocations WHERE reservation_id=?').all(job.reservation_id));
 const recovered=await reconcileImageGeneration(f.env,'u',job.id);assert.equal(recovered.state,'succeeded');assert.equal(calls,1);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,30500);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
 assert.equal(JSON.stringify(f.db.sqlite.prepare('SELECT * FROM api_reservations WHERE id=?').get(job.reservation_id)),original);assert.equal(JSON.stringify(f.db.sqlite.prepare('SELECT * FROM reservation_allocations WHERE reservation_id=?').all(job.reservation_id)),alloc);
 const correction=f.db.sqlite.prepare('SELECT * FROM image_cost_corrections').get()!;assert.equal(correction.delta_micros,-29500);assert.equal(correction.state,'applied');await correctEstimatedImage(f.env.DB,{jobId:job.id,receiptSha256:String(correction.receipt_sha256),actualMicros:30500});assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,30500);
 const audits=f.db.sqlite.prepare("SELECT action,details_json FROM audit_logs WHERE entity_id=? AND action LIKE 'image.%' ORDER BY action").all(job.id);assert.equal(audits.length,3);
 const estimateAudit=JSON.parse(String(audits.find(x=>x.action==='image.generation_estimated')!.details_json));assert.equal(estimateAudit.estimated,true);assert.equal(estimateAudit.estimatedMicros,60000);assert.equal(estimateAudit.releasedMicros,940000);assert.equal(estimateAudit.snapshot.source,'approved-image-fallback-20261114');
 for(const table of ['image_estimated_settlements','image_cost_corrections','image_correction_allocations'])assert.throws(()=>f.db.sqlite.prepare('DELETE FROM '+table+' WHERE job_id=?').run(job.id),/immutable/);
 assert.throws(()=>f.db.sqlite.prepare('UPDATE image_estimated_settlements SET estimated_micros=1 WHERE job_id=?').run(job.id),/immutable/);
 assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM ledger_events WHERE kind='image_cost_correction'").get()!.n,1);const sample=await imageEstimatedCost(f.env.DB,pricing,1000000);assert.equal(sample.samples.length,1);assert.equal(sample.samples[0].actualMicros,30500);assert.equal(sample.samples[0].corrected,true);
 await assert.rejects(()=>correctEstimatedImage(f.env.DB,{jobId:job.id,receiptSha256:String(correction.receipt_sha256),actualMicros:30501}),/different data/);
}finally{f.db.close();}});

test('late cost above original reserve applies actual delta; pending insufficient funds does not overdraw',async()=>{const f=await fixture(1000000);try{
 const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{throw new Error('lost');}});f.storage.objects.set(key(job),new TextEncoder().encode(JSON.stringify(response(40000))));
 const pending=await reconcileImageGeneration(f.env,'u',job.id);assert.equal(pending.state,'failed');assert.equal(pending.error_code,'INSUFFICIENT_CREDIT');assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,60000);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare('SELECT state FROM image_cost_corrections').get()!.state,'pending');assert.equal((await imageEstimatedCost(f.env.DB,pricing,1000000)).samples.length,0);
 await grantCredit(f.env.DB,{id:'later-credit',userId:'u',source:'topup',amountMicros:500000,referenceId:'later'});const final=await reconcileImageGeneration(f.env,'u',job.id);assert.equal(final.state,'succeeded');assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,1200500);assert.equal(f.db.sqlite.prepare('SELECT delta_micros FROM image_cost_corrections').get()!.delta_micros,1140500);assert.equal(f.db.sqlite.prepare('SELECT consumed_micros FROM provider_pools').get()!.consumed_micros,1200500);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM provider_funding WHERE reference_id LIKE 'auto:image-correction:%'").get()!.n,1);
}finally{f.db.close();}});

test('zero late delta still audits once; competing correction calls have one net effect',async()=>{const f=await fixture();try{
 // 500 input microUSD + 1983 image tokens * 30 = 59990.
 await seed(f,'sample-exact',{output:1983});const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{throw new Error('lost');}});const bytes=new TextEncoder().encode(JSON.stringify(response(1983)));f.storage.objects.set(key(job),bytes);
 await Promise.all(Array.from({length:8},()=>reconcileImageGeneration(f.env,'u',job.id)));assert.equal(f.db.sqlite.prepare('SELECT delta_micros FROM image_cost_corrections').get()!.delta_micros,0);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM ledger_events WHERE kind='image_cost_correction'").get()!.n,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_correction_allocations').get()!.n,0);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,119980);
}finally{f.db.close();}});

test('nonzero refund and debit concurrent retries each apply only once',async()=>{for(const output of [1000,3000]){const f=await fixture();try{
 const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{throw new Error('lost');}});const bytes=new TextEncoder().encode(JSON.stringify(response(output))),digest=await sha256(bytes);f.db.sqlite.prepare('UPDATE image_jobs SET response_sha256=? WHERE id=?').run(digest,job.id);
 const actual=500+output*30;await Promise.all(Array.from({length:8},()=>correctEstimatedImage(f.env.DB,{jobId:job.id,receiptSha256:digest,actualMicros:actual})));assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,actual);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM ledger_events WHERE kind='image_cost_correction'").get()!.n,1);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='image.cost_corrected'").get()!.n,1);
}finally{f.db.close();}}});

test('estimated settlement atomic failure retains hold and refuses relabeling known actual usage',async()=>{const f=await fixture();try{
 const originalBatch=f.env.DB.batch.bind(f.env.DB);let refused=false;(f.env.DB as any).batch=async(statements:any[])=>{if(!refused&&statements.some(s=>s.sql.includes('INSERT INTO image_estimated_settlements'))){refused=true;throw new Error('fixture storage failure');}return originalBatch(statements);};
 const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{throw new Error('lost');}});assert.equal(job.state,'uncertain');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,1000000);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_estimated_settlements').get()!.n,0);
 const snapshot=JSON.parse(job.request_json).costEstimate;f.db.sqlite.prepare('UPDATE image_jobs SET usage_json=? WHERE id=?').run(JSON.stringify(usage()),job.id);
 await assert.rejects(()=>settleEstimatedImage(f.env.DB,{jobId:job.id,reservationId:job.reservation_id!,estimatedMicros:snapshot.estimatedMicros,snapshotJson:JSON.stringify(snapshot),errorCode:'IMAGE_PROVIDER_UNCERTAIN'}));assert.equal((await getWallet(f.env.DB,'u')).heldMicros,1000000);
}finally{f.db.close();}});

test('a lost estimate commit acknowledgement is confirmed once from its audit record',async()=>{const f=await fixture();try{
 const originalBatch=f.env.DB.batch.bind(f.env.DB);let lost=false;(f.env.DB as any).batch=async(statements:any[])=>{const result=await originalBatch(statements);if(!lost&&statements.some(s=>s.sql.includes('INSERT INTO image_estimated_settlements'))){lost=true;throw new Error('lost successful commit acknowledgement');}return result;};
 const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{throw new Error('transport failed');}});assert.equal(job.state,'failed');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,60000);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_estimated_settlements').get()!.n,1);
}finally{f.db.close();}});

test('refund restores the original mixed grants without extending expiry or unfreezing credit',async()=>{const f=await fixture();try{
 await grantCredit(f.env.DB,{id:'subscription',userId:'u',source:'subscription',amountMicros:40000,referenceId:'sub',expiresAtMs:Date.now()+86400000});
 const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{throw new Error('lost');}});assert.equal(f.db.sqlite.prepare("SELECT consumed_micros FROM credit_grants WHERE id='subscription'").get()!.consumed_micros,40000);
 // The entitlement ends before the receipt arrives; its refund must not become
 // a new everlasting top-up. The remaining 20k is refunded to the old top-up.
 f.db.sqlite.prepare("UPDATE credit_grants SET expires_at_ms=1 WHERE id='subscription'").run();f.storage.objects.set(key(job),new TextEncoder().encode(JSON.stringify(response(0))));
 await reconcileImageGeneration(f.env,'u',job.id);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,500);assert.equal((await getWallet(f.env.DB,'u')).expiredMicros,39500);assert.equal(f.db.sqlite.prepare("SELECT consumed_micros FROM credit_grants WHERE id='grant'").get()!.consumed_micros,0);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM credit_grants").get()!.n,2);
 assert.equal(f.db.sqlite.prepare('SELECT SUM(delta_micros) n FROM image_correction_allocations').get()!.n,-59500);
}finally{f.db.close();}});

test('correction transaction rollback and lost commit replay never duplicate the delta',async()=>{for(const mode of ['rollback','lost-ack']){const f=await fixture();try{
 const job=await createImageGeneration(f.env,'u','p',input,{fetch:async()=>{throw new Error('lost');}});f.storage.objects.set(key(job),new TextEncoder().encode(JSON.stringify(response())));
 const originalBatch=f.env.DB.batch.bind(f.env.DB);let injected=false;(f.env.DB as any).batch=async(statements:any[])=>{
  const correction=statements.some(s=>s.sql.includes("SET state='applied'"));
  if(!injected&&correction&&mode==='rollback'){injected=true;return originalBatch([...statements.slice(0,-1),(f.env.DB as any).prepare('SELECT missing_column FROM image_cost_corrections'),statements.at(-1)]);}
  const result=await originalBatch(statements);if(!injected&&correction&&mode==='lost-ack'){injected=true;throw new Error('lost commit');}return result;
 };
 await reconcileImageGeneration(f.env,'u',job.id);const state=f.db.sqlite.prepare('SELECT state FROM image_cost_corrections').get()!.state;assert.equal(state,mode==='rollback'?'pending':'applied');assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,mode==='rollback'?60000:30500);
 await reconcileImageGeneration(f.env,'u',job.id);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,30500);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM ledger_events WHERE kind='image_cost_correction'").get()!.n,1);
}finally{f.db.close();}}});

test('explicit generation size and exact final prompt freeze geometry before reserve and preserve old hashes',async()=>{const f=await fixture();try{
 const slot=imageSlotSchema.parse({width:900,height:900}),prompt=imagePromptForSlot(input.prompt,slot,'1536x1024');let calls=0;
 await assert.rejects(()=>createImageGeneration(f.env,'u','p',{...input,slot,generationSize:'1536x1024',expectedFinalPrompt:prompt+'x'},{fetch:async()=>{calls++;return Response.json(response());}}),/冻结/);assert.equal(calls,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_jobs').get()!.n,0);
 const job=await createImageGeneration(f.env,'u','p',{...input,slot,generationSize:'1536x1024',expectedFinalPrompt:prompt},{fetch:async(_url,init)=>{calls++;const payload=JSON.parse(String(init?.body));assert.equal(payload.size,'1536x1024');assert.equal(payload.prompt,prompt);return Response.json(response(1000,'1536x1024'));}});assert.equal(job.state,'succeeded');assert.equal(JSON.parse(job.request_json).layout.generation.size,'1536x1024');assert.equal(JSON.parse(job.request_json).layout.display.cropFraction,0.333);
 const legacy=await createImageGeneration(f.env,'u','p',{prompt:input.prompt,requestKey:'legacy-hash-image-0001'},{fetch:async()=>Response.json(response())});assert.equal(legacy.request_hash,await sha256(JSON.stringify({projectId:'p',prompt:input.prompt})));assert.equal(JSON.parse(legacy.request_json).costEstimate,undefined);
}finally{f.db.close();}});
