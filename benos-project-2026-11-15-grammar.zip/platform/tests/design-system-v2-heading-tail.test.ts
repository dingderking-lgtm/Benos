import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { basename, resolve } from 'node:path';
import { compileV2Page, renderV2Section } from '../src/design-system/v2/render';
import { createV2PageFixture, getV2Fixture } from '../src/design-system/v2/fixtures';
import { V2_PRESETS, createWebsiteTokenSnapshot } from '../src/design-system/v2/contracts';

const require=createRequire(import.meta.url);let chromium:any=null;try{chromium=require('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright').chromium;}catch{}
const source=resolve('..','reference','aacmss','src','Services'),browserPath='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const phpAvailable=existsSync(resolve(source,'Renderer.php'))&&spawnSync('php',['-r','echo class_exists("DOMDocument")&&extension_loaded("mbstring")?"yes":"no";'],{windowsHide:true,encoding:'utf8'}).stdout==='yes';
const php=String.raw`spl_autoload_register(function($class){$p=$GLOBALS['argv'][1].'/'.substr($class,strrpos($class,'\\')+1).'.php';if(is_file($p))require_once $p;});require $argv[1].'/PageHiddenContent.php';require $argv[1].'/Renderer.php';$p=new class extends PDO{public function __construct(){}};$r=new \AACMS\Services\Renderer($p);$out=[];foreach(json_decode(stream_get_contents(STDIN),true,64,JSON_THROW_ON_ERROR) as $row)$out[]=$r->renderDocument(['version'=>1,'html'=>$row['html'],'css'=>$row['css']]);echo json_encode($out,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);`;
const target='空间的细节，比安排更多事情更重要。',long120='长'.repeat(117)+'完整性',long200='长'.repeat(197)+'完整性';

test('120-character headings remain the production limit; tail grouping never expands accepted input',async()=>{
 const f=getV2Fixture('media-story','lead-list','calm-paper',{scenario:'no-images'});
 const r=await renderV2Section({...f.input,content:{...f.input.content,title:long120}},f.context);assert.match(r.html,/class="bnx-heading-tail">完整性<\/span>/);
 await assert.rejects(renderV2Section({...f.input,content:{...f.input.content,title:long200}},f.context));
});

test('formal PHP and no-script Edge remove the three 320px CJK widow cases without changing text or size',{
 skip:!phpAvailable||!chromium||!existsSync(browserPath)?'Requires local PHP and Edge':false,timeout:60000,
},async()=>{
 const dir=resolve('..','artifacts','design-system-activation-20261114','heading');await mkdir(dir,{recursive:true});
 const sourceFiles=['src/design-system/v2/render.ts','src/design-system/v2/styles.ts','src/design-system/v2/source-identity.json'];
 const hashes=async()=>Object.fromEntries(await Promise.all(sourceFiles.map(async f=>[f,createHash('sha256').update(await readFile(f)).digest('hex')])));const before=await hashes();
 const rows:any[]=[],assets=new Map<string,Buffer>();
 for(const preset of V2_PRESETS){const f=createV2PageFixture({preset,example:'stay'}),r=await compileV2Page(f.input,f.context);rows.push({key:preset,kind:'page',preset,html:r.html,css:r.css});rows.push({key:preset+'-before',kind:'negative',preset,html:r.html.replace(/<span class="bnx-heading-tail">([^<>]*)<\/span>/g,'$1'),css:r.css});for(const a of f.context.ownedAssets)if(!assets.has(a.path))assets.set(a.path,await readFile(resolve('public','assets/design-system-v2',basename(a.path))));}
 const cases=[{key:'length-120',title:long120},{key:'length-200-css-only',title:long120},{key:'english',title:'A clearer engineering brief makes the next decision more useful.'},{key:'mixed',title:'CNC machining 与真实工艺相互对应，先理解零件再确认选择依据。'}];
 for(const [pattern,variant] of [['hero-stage','centered'],['media-story','lead-list']] as const)for(const c of cases){const f=getV2Fixture(pattern,variant,'calm-paper',{scenario:'no-images'}),r=await renderV2Section({...f.input,content:{...f.input.content,title:c.title}},f.context);rows.push({key:pattern+'-'+c.key,kind:'stress',title:c.key==='length-200-css-only'?long200:c.title,outsideContract:c.key==='length-200-css-only',html:c.key==='length-200-css-only'?r.html.replace('长'.repeat(117),'长'.repeat(197)):r.html,css:r.css});}
 const proc=spawnSync('php',['-r',php,source],{windowsHide:true,encoding:'utf8',input:JSON.stringify(rows),maxBuffer:8*1024*1024});assert.equal(proc.status,0,proc.stderr);const rendered=JSON.parse(proc.stdout);
 const browser=await chromium.launch({executablePath:browserPath,headless:true}),results:any[]=[];
 try{const context=await browser.newContext({javaScriptEnabled:false});await context.route('**/*',(route:any)=>{const data=assets.get(new URL(route.request().url()).pathname);return data?route.fulfill({contentType:'image/png',body:data}):route.abort();});const page=await context.newPage();
  for(let i=0;i<rows.length;i++)for(const width of rows[i].kind==='negative'?[320]:[320,390,768,1440]){
   await page.setViewportSize({width,height:900});await page.setContent(`<html lang="${rows[i].key.endsWith('english')?'en':'zh-CN'}"><head><base href="https://fixture.test/"><style>body{margin:0}:root{--bnf-heading:Helvetica,Arial,"Microsoft YaHei",sans-serif}</style></head><body><div class="aacms-page">${rendered[i]}</div></body></html>`);await page.evaluate('globalThis.__name=(fn)=>fn');
   const measured=await page.evaluate(()=>{const w=globalThis as any,d=w.document;return{overflow:d.documentElement.scrollWidth-w.innerWidth,headings:[...d.querySelectorAll('h1,h2')].map((h:any)=>{const walker=d.createTreeWalker(h,w.NodeFilter.SHOW_TEXT),lines:Array<{top:number;text:string}>=[];let node:any;while((node=walker.nextNode())){let offset=0;for(const ch of Array.from(node.textContent||'') as string[]){const range=d.createRange();range.setStart(node,offset);offset+=ch.length;range.setEnd(node,offset);const r=range.getBoundingClientRect();if(!r.width&&!r.height)continue;let line=lines.find(l=>Math.abs(l.top-r.top)<2);if(!line){line={top:r.top,text:''};lines.push(line);}line.text+=ch;}}lines.sort((a,b)=>a.top-b.top);const han=(s:string)=>(s.match(/\p{Script=Han}/gu)||[]).length;return{tag:h.tagName,text:h.textContent,fontSize:w.getComputedStyle(h).fontSize,lines,lastHan:han(lines.at(-1)?.text||''),orphan:han(h.textContent)>=8&&lines.length>1&&han(lines.at(-1)?.text||'')<=2&&han(lines.at(-2)?.text||'')>=4,tailCount:h.querySelectorAll('.bnx-heading-tail').length};})};});
   const result={key:rows[i].key,kind:rows[i].kind,width,outsideContract:!!rows[i].outsideContract,...measured};results.push(result);assert.ok(measured.overflow<=1,JSON.stringify(result));
   if(rows[i].kind==='negative'){const h=measured.headings.find((h:any)=>h.text===target);assert.ok(h?.orphan,JSON.stringify(result));assert.equal(h.lines.at(-1).text,'要。');await page.locator('#details .bnx-heading').scrollIntoViewIfNeeded();await page.waitForTimeout(80);await page.locator('#details .bnx-heading').screenshot({path:resolve(dir,rows[i].preset+'-320-before.png')});}
   else if(rows[i].kind==='page'){const h=measured.headings.find((h:any)=>h.text===target);assert.ok(h);assert.equal(h.orphan,false,JSON.stringify(result));assert.ok(h.lastHan>=3);assert.equal(h.text,target);assert.equal(h.fontSize,width<=640?'30px':width<=800?'36px':createWebsiteTokenSnapshot(rows[i].preset).type.title+'px');assert.equal(measured.headings.some((h:any)=>h.orphan),false,JSON.stringify(result));if(width===320||width===1440){await page.locator('#details .bnx-heading').scrollIntoViewIfNeeded();await page.waitForTimeout(80);await page.locator('#details .bnx-heading').screenshot({path:resolve(dir,rows[i].preset+'-'+width+'-after.png')});}}
   else {assert.equal(measured.headings[0].text,rows[i].title);if(!rows[i].key.endsWith('english'))assert.equal(measured.headings[0].orphan,false,JSON.stringify(result));if(rows[i].key.endsWith('english'))assert.equal(measured.headings[0].tailCount,0);}
  }
 }finally{await browser.close();const after=await hashes();await writeFile(resolve(dir,'report.json'),JSON.stringify({recordedAt:new Date().toISOString(),cases:results.length,expectedCases:47,negativeControls:results.filter(r=>r.kind==='negative').length,sourceBefore:before,sourceAfter:after,sourceStable:JSON.stringify(before)===JSON.stringify(after),scope:'Published renderer plus Edge with page JavaScript disabled; no model calls or business writes. 200-character cases are CSS-only stress fixtures; production schema still rejects titles over 120 characters.',results},null,2));}
 assert.equal(results.length,47);
});
