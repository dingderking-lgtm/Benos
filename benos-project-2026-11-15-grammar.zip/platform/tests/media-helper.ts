import { deflateSync } from 'node:zlib';
import { TestD1,testEnv } from './d1-helper';
export class FakeR2 {
 objects=new Map<string,Uint8Array>();puts=0;gets=0;failBefore=false;failAfter=false;
 async put(key:string,bytes:Uint8Array){this.puts++;if(this.failBefore){this.failBefore=false;throw new Error('fixture put failed');}this.objects.set(key,new Uint8Array(bytes));if(this.failAfter){this.failAfter=false;throw new Error('fixture acknowledgement lost');}return {key};}
 async get(key:string){this.gets++;const value=this.objects.get(key);return value?{size:value.length,arrayBuffer:async()=>new Uint8Array(value).buffer}:null;}
}
function crc(bytes:Uint8Array){let n=0xffffffff;for(const b of bytes){n^=b;for(let i=0;i<8;i++)n=(n>>>1)^((n&1)?0xedb88320:0);}return (n^0xffffffff)>>>0;}
function chunk(type:string,data:Uint8Array){const result=Buffer.alloc(data.length+12);result.writeUInt32BE(data.length,0);result.write(type,4);result.set(data,8);result.writeUInt32BE(crc(result.subarray(4,-4)),result.length-4);return result;}
export function png(width=1,height=1){const header=Buffer.alloc(13);header.writeUInt32BE(width,0);header.writeUInt32BE(height,4);header[8]=8;header[9]=6;const pixels=Buffer.alloc(height*(width*4+1));for(let row=0;row<height;row++){pixels[row*(width*4+1)]=0;for(let col=0;col<width;col++)pixels[row*(width*4+1)+col*4+4]=255;}return new Uint8Array(Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(pixels)),chunk('IEND',Buffer.alloc(0))]));}
export function mediaFixture(options:{presentation?:'legacy'|'default'}={}){const db=new TestD1(),env=testEnv(db),storage=new FakeR2(),now=new Date().toISOString();env.BUCKET=storage as unknown as R2Bucket;
 // The existing recorded provider fixtures speak the pre-bnh-1 protocol. Keep
 // testing that replay explicitly; ordered-workflow tests use real defaults.
 if(options.presentation!=='default')db.sqlite.prepare('INSERT INTO settings(key,value_json,updated_at) VALUES(?,?,?)').run('ai.presentation-policy.v1',JSON.stringify({mode:'legacy'}),now);
 for(const user of ['u','other'])db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(user,user+'@example.test',user,'test','user',now,now);
 for(const [project,user] of [['p','u'],['p2','u'],['other-project','other']])db.sqlite.prepare('INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES(?,?,?,?,?)').run(project,user,'图片项目',now,now);
 return {db,env,storage};
}
