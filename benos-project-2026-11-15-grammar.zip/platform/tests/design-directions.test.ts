import test from 'node:test';
import assert from 'node:assert/strict';
import { layoutPlan } from '../src/contracts/layout-variety';

test('an explicit engineering preference chooses a coherent family and never round collage styling',()=>{
 for(const value of [0,.2,.49,.5,.8,.999]){
  const plan=layoutPlan(()=>value,{style:'工业专业；保留暖白与钴蓝'});
  assert.ok(['精密工程','专业简报'].includes(plan.direction));
  assert.equal(plan.shape,'直角与细线，克制硬朗');
  assert.match(plan.typography,/无衬线/);
  assert.match(plan.imageComposition,/整机|业务场景/);
 }
});

test('a known style changes composition and type as well as palette, while custom text remains accepted',()=>{
 const industrial=layoutPlan(()=>0,{style:'工业专业'}),editorial=layoutPlan(()=>0,{style:'杂志编辑；黑白色'}),dark=layoutPlan(()=>0,{style:'暗色沉浸'});
 assert.equal(new Set([industrial.hero,editorial.hero,dark.hero]).size,3);
 assert.match(editorial.typography,/衬线|宋体/);assert.notEqual(editorial.imageComposition,industrial.imageComposition);
 assert.equal(editorial.direction,'编辑画册');assert.equal(dark.direction,'电影叙事');
 assert.doesNotThrow(()=>layoutPlan(()=>.7,{style:'保留客户原创的手绘水彩与竖向分栏'}));
});

test('persistable plans keep their exact composition across retries and offer eight default families',()=>{
 const families=new Set<string>();
 for(let i=0;i<8;i++){
  const random=()=>i/8+.001;
  const plan=layoutPlan(random);families.add(plan.direction);
  assert.deepEqual(plan,layoutPlan(random));assert.deepEqual(JSON.parse(JSON.stringify(plan)),plan);
  assert.equal(new Set(plan.sections).size,5);
 }
 assert.equal(families.size,8);
});
