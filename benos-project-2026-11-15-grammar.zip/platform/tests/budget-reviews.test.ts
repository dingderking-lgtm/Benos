import test from 'node:test';
import assert from 'node:assert/strict';
import { mediaFixture } from './media-helper';
import { budgetAlerts,recordBalanceReview } from '../src/modules/budget-reviews';
import { fundProvider } from '../src/modules/ledger';
import { app } from '../src/index';
import { sha256 } from '../src/lib/crypto';
async function fixture(){const f=mediaFixture();f.db.sqlite.prepare("UPDATE users SET role='owner' WHERE id='u'").run();await fundProvider(f.env.DB,{id:'fund',providerId:'openai',amountMicros:100_000_000,referenceId:'test-deposit-only'});f.db.sqlite.prepare("UPDATE provider_pools SET consumed_micros=10_000_000,reserved_micros=5_000_000,safety_micros=1_000_000 WHERE provider_id='openai'").run();return f;}
const input={requestKey:'balance-review-once',observedAt:new Date().toISOString(),actualBalanceMicros:87_000_000,evidence:'Local fixture supplier statement 001; not a real provider balance.'};
test('provider balance review snapshots current accounting without changing funds, holds or user credit, and is atomically replay-safe',async()=>{
 const f=await fixture();try{
  const before=f.db.sqlite.prepare('SELECT * FROM provider_pools').get();const [a,b]=await Promise.all([recordBalanceReview(f.env,'u','openai',input),recordBalanceReview(f.env,'u','openai',input)]);assert.equal(a.id,b.id);assert.deepEqual(f.db.sqlite.prepare('SELECT * FROM provider_pools').get(),before);
  const row=f.db.sqlite.prepare('SELECT * FROM provider_balance_reviews').get()!;assert.equal(row.local_net_micros,90_000_000);assert.equal(row.held_micros,5_000_000);assert.equal(row.difference_micros,-3_000_000);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='budget.balance_review'").get()!.n,1);
  await assert.rejects(recordBalanceReview(f.env,'u','openai',{...input,actualBalanceMicros:86_000_000}),/编号/);await assert.rejects(recordBalanceReview(f.env,'other','openai',input),/所有者/);
  assert.equal((await budgetAlerts(f.env)).alerts.filter(a=>a.code==='PROVIDER_BALANCE_DIFFERENCE').length,1);
 }finally{f.db.close();}
});
test('operations alerts distinguish unavailable provider funds and stopped pools; reviews never auto-clear restrictions or budgets',async()=>{
 const f=await fixture();try{
  assert.equal((await budgetAlerts(f.env)).alerts.length,0);f.db.sqlite.prepare("UPDATE provider_pools SET funded_micros=16_000_000,enabled=0 WHERE provider_id='openai'").run();const alerts=await budgetAlerts(f.env);assert.deepEqual(alerts.alerts.map(a=>a.code),['PROVIDER_STOPPED','PROVIDER_FUNDS_LOW']);assert.equal(alerts.pools[0].availableMicros,0);
  await recordBalanceReview(f.env,'u','openai',{...input,actualBalanceMicros:99_000_000});assert.equal(f.db.sqlite.prepare('SELECT funded_micros FROM provider_pools').get()!.funded_micros,16_000_000);assert.equal(f.db.sqlite.prepare('SELECT enabled FROM provider_pools').get()!.enabled,0);
 }finally{f.db.close();}
});
test('review API restricts roles, requires CSRF, omits request hash and provides no edit or delete route',async()=>{
 const f=await fixture();try{const token='balance-review-session'.padEnd(43,'x');f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('s','u',await sha256(token),'csrf',input.observedAt,'2099-01-01T00:00:00.000Z','fixture');const headers={cookie:'benos_session='+token,origin:f.env.APP_ORIGIN,'content-type':'application/json'};
  assert.equal((await app.request('/api/admin/budget-reviews/openai',{method:'POST',headers,body:JSON.stringify(input)},f.env)).status,403);const response=await app.request('/api/admin/budget-reviews/openai',{method:'POST',headers:{...headers,'x-csrf-token':'csrf'},body:JSON.stringify(input)},f.env);assert.equal(response.status,201);
  const data=await (await app.request('/api/admin/budget-reviews',{headers},f.env)).json() as any;assert.equal(data.data.reviews.length,1);assert.equal(data.data.reviews[0].request_hash,undefined);
  assert.equal((await app.request('/api/admin/budget-reviews/'+data.data.reviews[0].id,{method:'DELETE',headers:{...headers,'x-csrf-token':'csrf'}},f.env)).status,404);
  f.db.sqlite.prepare("UPDATE users SET role='support' WHERE id='u'").run();assert.equal((await app.request('/api/admin/budget-reviews',{headers},f.env)).status,403);
 }finally{f.db.close();}
});
