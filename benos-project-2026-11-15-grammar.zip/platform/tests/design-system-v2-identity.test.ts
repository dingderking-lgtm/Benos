import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, statSync, utimesSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve, dirname, join, basename } from 'node:path';
import { spawnSync } from 'node:child_process';

const root=resolve('.'),script=resolve('scripts/design-system-v2-identity.mjs');
const files=['src/contracts/section-patterns.ts','src/design-system/v2/adapted-primitives.ts','src/design-system/v2/contracts.ts','src/design-system/v2/provenance.ts','src/design-system/v2/registry.ts','src/design-system/v2/render.ts','src/design-system/v2/styles.ts','src/design-system/v2/kit.ts'];
const target='src/design-system/v2/source-identity.json';
const hash=(bytes:Uint8Array|string)=>createHash('sha256').update(bytes).digest('hex');
function fixture(){const directory=mkdtempSync(join(tmpdir(),'benos-v2-identity-'));for(const file of files){const path=join(directory,file);mkdirSync(dirname(path),{recursive:true});writeFileSync(path,`// fixture for ${file}\r\nexport const value='原始源码';\r\n`);}return{directory,target:join(directory,target),close(){assert.equal(dirname(directory),resolve(tmpdir()));assert(basename(directory).startsWith('benos-v2-identity-'));rmSync(directory,{recursive:true,force:true});}};}
function run(directory:string,mode:string,dev='0'){return spawnSync(process.execPath,[script,mode,'--root='+directory],{encoding:'utf8',env:{...process.env,BENOS_V2_IDENTITY_DEV:dev}});}

test('identity hashes original source bytes in deterministic order, excluding itself and timestamps',()=>{
 const f=fixture();try{assert.equal(run(f.directory,'--write').status,0);const identity=JSON.parse(readFileSync(f.target,'utf8'));const expectedFiles=Object.fromEntries(files.map(file=>[file,hash(readFileSync(join(f.directory,file)))]));assert.deepEqual(identity,{version:'bnx-source-identity-1',files:expectedFiles,digest:hash(JSON.stringify({version:'bnx-source-identity-1',files:expectedFiles}))});assert.equal(run(f.directory,'--check').status,0);
  const before=readFileSync(f.target,'utf8');utimesSync(f.target,new Date('2001-01-01'),new Date('2001-01-01'));const mtime=statSync(f.target,{bigint:true}).mtimeNs;const unchanged=run(f.directory,'--write');assert.equal(unchanged.status,0);assert.match(unchanged.stdout,/unchanged/);assert.equal(statSync(f.target,{bigint:true}).mtimeNs,mtime);assert.equal(readFileSync(f.target,'utf8'),before);
 }finally{f.close();}
});

test('every reused contract, renderer and adapter source invalidates identity before checks can proceed',()=>{
 const f=fixture();try{assert.equal(run(f.directory,'--write').status,0);for(const file of files){const original=readFileSync(f.target,'utf8'),path=join(f.directory,file);writeFileSync(path,readFileSync(path,'utf8')+'// revised\n');const failed=run(f.directory,'--check','1');assert.notEqual(failed.status,0,file);assert.match(failed.stderr,/BNX_SOURCE_IDENTITY_STALE/);assert.equal(readFileSync(f.target,'utf8'),original,'check must not silently refresh');assert.equal(run(f.directory,'--write').status,0);assert.notEqual(readFileSync(f.target,'utf8'),original);assert.equal(run(f.directory,'--check').status,0);}}
 finally{f.close();}
});

test('tampered/missing identity and missing compiler inputs fail closed without generating a partial approval identity',()=>{
 const f=fixture();try{const missing=run(f.directory,'--check');assert.notEqual(missing.status,0);assert(!existsSync(f.target));assert.equal(run(f.directory,'--write').status,0);writeFileSync(f.target,'{"version":"bnx-source-identity-1","digest":"forged"}\n');assert.notEqual(run(f.directory,'--check').status,0);assert.equal(run(f.directory,'--write').status,0);const retained=readFileSync(f.target,'utf8');rmSync(join(f.directory,files[0]));assert.notEqual(run(f.directory,'--write').status,0);assert.equal(readFileSync(f.target,'utf8'),retained);}
 finally{f.close();}
});

test('custom build checks by default; explicit dev refresh changes once and then leaves mtime untouched',()=>{
 const f=fixture();try{assert.notEqual(run(f.directory,'--build').status,0);assert(!existsSync(f.target));assert.equal(run(f.directory,'--build','1').status,0);const old=readFileSync(f.target,'utf8');writeFileSync(join(f.directory,files[5]),'// renderer revision\n');assert.notEqual(run(f.directory,'--build').status,0);assert.equal(readFileSync(f.target,'utf8'),old);assert.equal(run(f.directory,'--build','1').status,0);const mtime=statSync(f.target,{bigint:true}).mtimeNs;assert.equal(run(f.directory,'--build','1').status,0);assert.equal(statSync(f.target,{bigint:true}).mtimeNs,mtime);}
 finally{f.close();}
});

test('checked-in identity matches the active source and all public build/check entry points keep the gate',()=>{
 const checked=run(root,'--check');assert.equal(checked.status,0,checked.stderr);
 const packageJson=JSON.parse(readFileSync(resolve('package.json'),'utf8'));
 for(const name of ['check','test'])assert(packageJson.scripts[name].startsWith('node scripts/design-system-v2-identity.mjs --check && '));
 const build=readFileSync(resolve('scripts/build-web.mjs'),'utf8');assert.match(build,/async function main\(\)\s*\{\s*\/\/[^\n]+\n\s*checkV2SourceIdentity\(backend\);/);
 const config=JSON.parse(readFileSync(resolve('wrangler.jsonc'),'utf8'));assert.equal(config.build.command,'node scripts/design-system-v2-identity.mjs --build');assert.equal(config.build.watch_dir,'src');
 const launch=readFileSync(resolve('scripts/wrangler.mjs'),'utf8');assert.match(launch,/BENOS_V2_IDENTITY_DEV: development \? '1' : '0'/);assert(launch.indexOf('checkV2SourceIdentity(backend)')<launch.indexOf('const child = spawn'));
});
