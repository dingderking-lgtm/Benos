import test from 'node:test';
import assert from 'node:assert/strict';
import { TEXT_BILLING_PROFILE,textReservationCost,textUsageCost,verifiedTextPricing,type TextPricing } from '../src/modules/ai-billing';
import { validateConfiguration } from '../src/modules/integrations';
import { createGeneration,textGenerationQuote } from '../src/modules/ai';
import { encryptSecret } from '../src/lib/crypto';
import { grantCredit,fundProvider,getWallet } from '../src/modules/ledger';
import { mediaFixture } from './media-helper';
import example from '../src/contracts/site-example.json';
import { seedCapabilityFixture } from './integration-test-helper';

const pricing:TextPricing={baseUrl:'https://api.openai.com/v1',model:'gpt-6.1-sol',inputMicrosPerMillion:2_000_000,cachedInputMicrosPerMillion:100_000,outputMicrosPerMillion:10_000_000,contextTokens:1_050_000,maxOutputTokens:10000,pricingConfirmedAt:new Date().toISOString(),billingProfile:TEXT_BILLING_PROFILE,cacheTtl:'30m'};
const config={...pricing,protocol:'responses',providerPoolId:'text-pool'};
const usage=(input=100,output=20,read=10,shortWrite=50,longWrite=0)=>({input_tokens:input,output_tokens:output,total_tokens:input+output,input_tokens_details:{cached_tokens:read,cache_write_tokens:shortWrite+longWrite,cache_write_tokens_details:{ttl_30m_tokens:shortWrite,ttl_12h_tokens:longWrite}},output_tokens_details:{reasoning_tokens:Math.min(5,output)}});
async function fixture(funds=16_250_000){const f=mediaFixture(),secret=await encryptSecret(JSON.stringify({apiKey:'sk-fixture-only'}),f.env.ENCRYPTION_KEY,'text-config');f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('text-config','text','Text','openai',1,'active',?,?,'passed','u',?)").run(JSON.stringify(config),secret,new Date().toISOString());await grantCredit(f.env.DB,{id:'funds',userId:'u',source:'topup',amountMicros:funds,referenceId:'topup-receipt'});await fundProvider(f.env.DB,{id:'upstream',providerId:'text-pool',amountMicros:100_000_000,referenceId:'actual-provider-receipt'});await seedCapabilityFixture(f.env.DB,'text-config');return f;}
const result=(billing=usage())=>({id:'resp_fixture',model:pricing.model,service_tier:'default',status:'completed',usage:billing,output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(example)}]}]});

test('cache reads, 30m writes and ordinary input are mutually exclusive charges with exact rounding',()=>{
 assert.equal(textUsageCost(pricing,usage()),406); // 40*2 + 10*.1 + 50*2.5 + 20*10
 const mixed={...pricing,cacheTtl:'12h' as const};assert.equal(textUsageCost(mixed,usage(12000,20,4000,3000,4000)),30100); // 1000*2+4000*.1+3000*2.5+4000*5+20*10
 assert.equal(textUsageCost(pricing,usage(1,1,1,0)),11);
 assert.equal(textUsageCost({...pricing,model:'gpt-6-sol',cachedInputMicrosPerMillion:200000},usage()),407);
});
test('long-context boundary multiplies every input/cache rate by two and output by 1.5',()=>{
 assert.equal(textUsageCost(pricing,usage(272000,20,1000,1000)),542800);
 assert.equal(textUsageCost(pricing,usage(272001,20,1000,1000)),1085504);
 assert.equal(textReservationCost(pricing),5400000);assert.equal(textReservationCost({...pricing,cacheTtl:'12h'}),10650000);
 // The bound covers any allowed disjoint usage partition across the full window.
 for(const input of [0,100,272000,272001,1040000])for(const write of [0,input]){const sample=usage(input,10000,0,write);sample.output_tokens_details.reasoning_tokens=0;assert.ok(textUsageCost(pricing,sample)<=textReservationCost(pricing));}
});
test('unknown billing, bad sums, missing lifetime fields and unrequested 12h writes fail closed',()=>{
 for(const malformed of [{...usage(),input_tokens_details:{cached_tokens:1}},{...usage(),input_tokens_details:{cached_tokens:20,cache_write_tokens:100,cache_write_tokens_details:{ttl_30m_tokens:100,ttl_12h_tokens:0}}},{...usage(),input_tokens_details:{...usage().input_tokens_details,cache_write_tokens_details:undefined}},{...usage(),input_tokens_details:{...usage().input_tokens_details,audio_tokens:1}},{...usage(),output_tokens_details:{reasoning_tokens:5,audio_tokens:1}},{...usage(),total_tokens:999},usage(100,20,10,20,10)])assert.throws(()=>textUsageCost(pricing,malformed));
 assert.throws(()=>textUsageCost({...pricing,billingProfile:'unverified'},usage()));assert.throws(()=>textUsageCost({...pricing,model:'gpt-unknown'},usage()));assert.throws(()=>textUsageCost({...pricing,contextTokens:100000},usage()));assert.throws(()=>textUsageCost({...pricing,inputMicrosPerMillion:1},usage()));
});
test('reviewed provider configuration binds exact model prices and limits; compatible unknown services remain unverified',()=>{
 assert.equal(validateConfiguration('text','openai',config,{apiKey:'fixture-only'}).config.billingProfile,TEXT_BILLING_PROFILE);
 assert.throws(()=>validateConfiguration('text','openai',{...config,cachedInputMicrosPerMillion:1},{apiKey:'fixture-only'}));assert.throws(()=>validateConfiguration('text','openai-compatible',config,{apiKey:'fixture-only'}));
 const unknown=validateConfiguration('text','openai-compatible',{...config,baseUrl:'https://provider.actual-domain.org/v1',model:'future-model',billingProfile:'unverified'},{apiKey:'fixture-only'});assert.equal(unknown.config.billingProfile,'unverified');assert.throws(()=>verifiedTextPricing(unknown.config as unknown as TextPricing,'openai-compatible'));
});
test('quote is exact and no unmetered token-count HTTP happens before the single reserved generation',async()=>{
 const f=await fixture();try{const quote=await textGenerationQuote(f.env,'u');assert.deepEqual(quote,{available:true,reason:null,configId:'text-config',provider:'openai',model:'gpt-6.1-sol',referenceImages:true,requiredReservationMicros:5400000,availableMicros:16250000,canReserve:true,basis:'model-context-ceiling'});let calls=0;
 const job=await createGeneration(f.env,'u','p',{prompt:'创建品牌网站',requestKey:'strict-text-generation'}, {fetch:async(url,init)=>{calls++;assert.equal(String(url),'https://api.openai.com/v1/responses');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,5400000);const body=JSON.parse(String(init!.body));assert.deepEqual(body.prompt_cache_options,{mode:'implicit',ttl:'30m'});assert.match(body.prompt_cache_key,/^[a-f0-9]{64}$/);return new Response(JSON.stringify(result()));}});assert.equal(job.state,'succeeded');assert.equal(calls,1);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,406);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
 }finally{f.db.close();}
});
test('insufficient full-context preauthorization returns an exact quote and sends zero external requests',async()=>{
 const f=await fixture(1_000_000);try{assert.deepEqual(await textGenerationQuote(f.env,'u'),{available:true,reason:null,configId:'text-config',provider:'openai',model:'gpt-6.1-sol',referenceImages:true,requiredReservationMicros:5400000,availableMicros:1000000,canReserve:false,basis:'model-context-ceiling'});let calls=0;const job=await createGeneration(f.env,'u','p',{prompt:'创建网站',requestKey:'strict-low-funds'}, {fetch:async()=>{calls++;throw new Error('must not be reached');}});assert.equal(job.error_code,'INSUFFICIENT_CREDIT');assert.equal(calls,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
 }finally{f.db.close();}
});
test('unverified model aborts before any HTTP and mismatched usage retains the full hold',async()=>{
 const f=await fixture();try{f.db.sqlite.prepare('UPDATE integration_configs SET public_config_json=?').run(JSON.stringify({...config,model:'gpt-future'}));assert.equal((await textGenerationQuote(f.env,'u')).available,false);await assert.rejects(()=>createGeneration(f.env,'u','p',{prompt:'创建网站',requestKey:'strict-unknown-model'},{fetch:async()=>{throw new Error('never');}}),/尚未通过审核/);f.db.sqlite.prepare('UPDATE integration_configs SET public_config_json=?').run(JSON.stringify(config));
 const job=await createGeneration(f.env,'u','p',{prompt:'创建网站',requestKey:'strict-bad-usage'}, {fetch:async()=>new Response(JSON.stringify(result(usage(100,20,10,0,50))))});assert.equal(job.state,'uncertain');assert.equal(job.error_code,'AI_PRICING_MISMATCH');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,5400000);assert.equal(f.db.sqlite.prepare('SELECT enabled FROM provider_pools').get()!.enabled,0);
 }finally{f.db.close();}
});

