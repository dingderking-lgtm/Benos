import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync } from 'node:crypto';
import type { Env } from '../src/env';
import { app } from '../src/index';
import { encryptSecret } from '../src/lib/crypto';
import { TestD1, testEnv } from './d1-helper';
import { publishTestPolicies } from './policy-fixture';
import { DEFAULT_CATALOG, activateCatalog, createCatalogVersion } from '../src/modules/billing-catalog';
import { membershipHorizon } from '../src/modules/commerce';
import { grantCredit } from '../src/modules/ledger';
import { freezeMembership, giftMembership as giveMembership, unfreezeMembership } from '../src/modules/memberships';
import { STRIPE_API_VERSION } from '../src/modules/payments';
import { signAlipay } from '../src/modules/alipay-protocol';

// P2.B: the billing contract the React billing page (P2.1) and the public pricing (P7.x) rely on.

const KEY='sk_test_commerce_ui_contract_fixture',WEBHOOK='whsec_commerce_ui_contract_fixture';
const CNY_CATALOG_ID='catalog_contract_cny',CNY_PRICES={goPriceCents:2500,proPriceCents:10000,hostingAnnualPriceCents:3000,minimumTopupCents:500,topupCreditMicrosPerCnyCent:6500};
const merchantKeys=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
const gatewayKeys=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
const DAY=24*3600_000;
type Json=Record<string,any>;
type Session={cookie:string;csrf:string;userId:string};

/** A TestD1 that can inject a concurrent change right before a statement runs, or fail one query. */
class HookedD1 extends TestD1 {
 beforeOrderInsert?:()=>void;
 failWhen?:RegExp;
 prepare(sql:string){
  if(this.failWhen?.test(sql))throw new Error('simulated storage failure');
  if(this.beforeOrderInsert&&/INSERT INTO orders/.test(sql)){const hook=this.beforeOrderInsert;this.beforeOrderInsert=undefined;hook();}
  return super.prepare(sql);
 }
}
function fixture(){
 const db=new HookedD1(),env=testEnv(db),iso=new Date().toISOString();
 db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES('owner','owner@example.test','Owner','unused','owner',?,?)").run(iso,iso);
 publishTestPolicies(db,'owner');
 db.sqlite.prepare("INSERT INTO billing_catalog_versions(id,version,payload_json,payload_hash,request_key,reason,created_by,created_at) VALUES(?,1,?,'local-fixture','commerce-cny-fixture-001','Explicit local CNY prices','owner',?)").run(CNY_CATALOG_ID,JSON.stringify({...structuredClone(DEFAULT_CATALOG),cnyPricing:CNY_PRICES}),iso);
 db.sqlite.prepare("INSERT INTO billing_catalog_active(singleton,version_id,enabled,updated_by,updated_at) VALUES(1,?,1,'owner',?)").run(CNY_CATALOG_ID,iso);
 return {db,env};
}
async function json(response:Response){return await response.json() as Json;}
async function register(env:Env,email:string):Promise<Session>{
 const response=await app.request('/api/auth/register',{method:'POST',headers:{origin:env.APP_ORIGIN,'content-type':'application/json'},body:JSON.stringify({email,name:'Billing',password:'billing-contract-password'})},env);
 assert.equal(response.status,201);const data=(await json(response)).data;
 return {cookie:response.headers.get('set-cookie')!.split(';')[0],csrf:data.csrfToken,userId:data.user.id};
}
function get(env:Env,path:string,session?:Session){return app.request(path,{headers:session?{cookie:session.cookie}:{}},env);}
function post(env:Env,path:string,session:Session,payload:unknown){
 return app.request(path,{method:'POST',headers:{origin:env.APP_ORIGIN,'content-type':'application/json',cookie:session.cookie,'x-csrf-token':session.csrf},body:JSON.stringify(payload)},env);
}
async function summary(env:Env,session:Session){const response=await get(env,'/api/billing/summary',session);assert.equal(response.status,200);return (await json(response)).data;}
async function paymentConfig(db:TestD1,env:Env,provider:'alipay'|'stripe'='alipay'){
 if(provider==='alipay'){const encrypted=await encryptSecret(JSON.stringify({privateKey:merchantKeys.privateKey,alipayPublicKey:gatewayKeys.publicKey}),env.ENCRYPTION_KEY,'pay');db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('pay','payment','Alipay','alipay',1,'active',?,?,'passed','owner',?)").run(JSON.stringify({mode:'sandbox',appId:'2026000000000001',sellerId:'2088000000000001',keyMode:'public_key',signType:'RSA2',settlementCurrency:'CNY'}),encrypted,new Date().toISOString());return;}
 const encrypted=await encryptSecret(JSON.stringify({secretKey:KEY,webhookSecret:WEBHOOK}),env.ENCRYPTION_KEY,'pay');
 db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('pay','payment','Payments','stripe',1,'active',?,?,'passed','owner',?)")
  .run(JSON.stringify({mode:'test',apiVersion:STRIPE_API_VERSION}),encrypted,new Date().toISOString());
}
async function giftMembership(...args:Parameters<typeof giveMembership>){const [env,actor,user,payload]=args;return giveMembership(env,actor,user,{...payload,catalogVersionId:payload.catalogVersionId??CNY_CATALOG_ID});}
/** New sales sign checkout URLs locally; only recovery queries use HTTP. */
function fakeAlipay(t:import('node:test').TestContext){const calls:{method:string}[]=[];let failNext=false;t.mock.method(globalThis,'fetch',async(input:unknown,init?:RequestInit)=>{assert.equal(String(input),'https://openapi-sandbox.dl.alipaydev.com/gateway.do');const params=new URLSearchParams(String(init?.body)),method=params.get('method')!;calls.push({method});assert.equal(method,'alipay.trade.query');if(failNext){failNext=false;throw new Error('isolated query interruption');}const content=JSON.stringify({code:'40004',sub_code:'ACQ.TRADE_NOT_EXIST'}),signature=await signAlipay(content,gatewayKeys.privateKey);return new Response(`{"alipay_trade_query_response":${content},"sign":${JSON.stringify(signature)}}`,{headers:{'content-type':'application/json'}});});return {calls,interruptNextQuery:()=>{failNext=true;},checkoutCreations:()=>calls.filter(c=>c.method==='alipay.trade.page.pay').length};}
const checkoutIdentity=(url:string)=>JSON.parse(new URL(url).searchParams.get('biz_content')!);
function paidTerm(db:TestD1,userId:string,id='paid',startMs=Date.now()-DAY,endMs=Date.now()+20*DAY,state='active',source='paid',tier='go',sites=1){
 db.sqlite.prepare('INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,state,auto_renew,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
  .run(id,userId,tier,source,new Date(startMs).toISOString(),new Date(endMs).toISOString(),state,source==='paid'&&state==='active'?1:0,sites,16_250_000,source==='paid'?1:0,'ref_'+id,new Date().toISOString());
}
function site(db:TestD1,userId:string,id:string,name:string,domain:string){
 const iso=new Date(Date.now()-30*DAY).toISOString();
 db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,?,?,?,'cms@example.test','connected',?,?)").run(id,userId,name,domain,iso,iso);
}
function orderCount(db:TestD1){return Number(db.sqlite.prepare('SELECT COUNT(*) AS n FROM orders').get()!.n);}
/**
 * Stripe double for the provider calls the billing routes make; counts every outbound request.
 * With `refuseInFlight`, it behaves like the real provider for a concurrent duplicate: a second request
 * with an idempotency key that is still being processed is refused with 409 instead of being replayed.
 */
function fakeHistoricalStripe(t:import('node:test').TestContext,options:{refuseInFlight?:boolean}={}){
 const sessions=new Map<string,Json>(),calls:{method:string;path:string;key:string|null}[]=[],inFlight=new Set<string>();
 t.mock.method(globalThis,'fetch',async(input:unknown,init?:RequestInit)=>{
  const url=new URL(String(input)),method=init?.method??'GET',headers=new Headers(init?.headers),params=new URLSearchParams(String(init?.body??''));
  assert.equal(url.origin,'https://api.stripe.com');calls.push({method,path:url.pathname,key:headers.get('idempotency-key')});
  if(url.pathname==='/v1/checkout/sessions'&&method==='POST'&&options.refuseInFlight){
   const key=headers.get('idempotency-key')!;
   if(inFlight.has(key))return Response.json({error:{type:'idempotency_error',message:'concurrent request with the same key'}},{status:409});
   inFlight.add(key);await new Promise(resolve=>setTimeout(resolve,25));inFlight.delete(key);
  }
  if(url.pathname==='/v1/checkout/sessions'&&method==='POST'){
   const orderId=params.get('metadata[benos_order_id]')!,amount=Number(params.get('line_items[0][price_data][unit_amount]')),sessionId=`cs_${orderId}`;
   const session=sessions.get(sessionId)??{id:sessionId,object:'checkout.session',livemode:false,url:`https://checkout.stripe.com/c/pay/${sessionId}`,mode:params.get('mode'),status:'open',
    expires_at:Number(params.get('expires_at')),currency:'usd',amount_total:amount,client_reference_id:orderId,payment_status:'unpaid',
    metadata:{benos_order_id:orderId,benos_user_id:params.get('metadata[benos_user_id]'),benos_config_id:params.get('metadata[benos_config_id]')},
    line_items:{has_more:false,data:[{quantity:1,amount_total:amount}]}};
   sessions.set(sessionId,session);return Response.json(session);
  }
  if(url.pathname.startsWith('/v1/checkout/sessions/')&&method==='GET'){const session=sessions.get(url.pathname.split('/').pop()!);return session?Response.json(session):Response.json({error:{}},{status:404});}
  if(url.pathname.startsWith('/v1/subscriptions/')&&method==='POST'){assert.equal(params.get('cancel_at_period_end'),'true');return Response.json({id:url.pathname.split('/').pop(),status:'active',cancel_at_period_end:true});}
  throw new Error(`unexpected provider call ${method} ${url.pathname}`);
 });
 return {calls,sessions,checkoutCreations:()=>calls.filter(call=>call.method==='POST'&&call.path==='/v1/checkout/sessions').length};
}
async function newCatalog(env:Env,changes:Partial<typeof DEFAULT_CATALOG>,key:string){
 return createCatalogVersion(env,'owner',{catalog:{...structuredClone(DEFAULT_CATALOG),...changes,cnyPricing:{...CNY_PRICES,goPriceCents:changes.go?.priceCents??CNY_PRICES.goPriceCents,proPriceCents:changes.pro?.priceCents??CNY_PRICES.proPriceCents,hostingAnnualPriceCents:changes.hosting?.annualPriceCents??CNY_PRICES.hostingAnnualPriceCents}},reason:'合同测试价格',requestKey:key});
}

test('public catalogue needs no session, reports explicit CNY prices and exposes nothing else',async()=>{
 const {db,env}=fixture();
 try{
  const response=await get(env,'/api/billing/catalog');assert.equal(response.status,200);
  assert.equal(response.headers.get('cache-control'),'no-store');assert.ok(response.headers.get('x-request-id'));
  const body=await json(response);assert.equal(body.ok,true);
  assert.deepEqual(Object.keys(body.data).sort(),['billingMode','catalogEnabled','catalogVersionId','cnyPricing','currency','enterprise','hostingAnnualPriceCents','paymentProvider','paymentReady','paymentUnavailableReason','plans','pricingReady','topupPolicy']);
  assert.equal(body.data.paymentProvider,null);assert.equal(body.data.paymentReady,false);assert.equal(body.data.paymentUnavailableReason,'not-configured');
  assert.deepEqual(body.data.plans,[
   {tier:'go',name:'Go',priceCents:2500,creditMicros:16_250_000,includedSites:1,billingInterval:'month'},
   {tier:'pro',name:'Pro',priceCents:10000,creditMicros:65_000_000,includedSites:2,billingInterval:'month'},
  ]);
  assert.equal(body.data.hostingAnnualPriceCents,3000);assert.deepEqual(body.data.topupPolicy,{minimumCents:500,creditMicrosPerCnyCent:6500,currency:'CNY'});
  assert.equal(body.data.currency,'CNY');assert.equal(body.data.billingMode,'manual');assert.equal(body.data.pricingReady,true);assert.deepEqual(body.data.cnyPricing,CNY_PRICES);assert.equal(body.data.enterprise.contactEnabled,true);assert.equal(body.data.catalogEnabled,true);assert.equal(body.data.catalogVersionId,CNY_CATALOG_ID);
  assert.doesNotMatch(JSON.stringify(body),/stripe|secret|config_version|integration/i);
  // Only the catalogue is public: every other billing route still requires a session.
  for(const path of ['/api/billing/summary','/api/billing/orders/ord_x']){const denied=await get(env,path);assert.equal(denied.status,401);assert.equal((await json(denied)).error.code,'UNAUTHENTICATED');}
  // A signed-in caller gets the identical catalogue.
  const user=await register(env,'catalog@example.test');assert.deepEqual((await json(await get(env,'/api/billing/catalog',user))).data,body.data);
 }finally{db.close();}
});

test('activating or pausing a catalogue changes the public catalogue and the summary together',async()=>{
 const {db,env}=fixture();
 try{
  // Payment is configured, so paymentReady can only turn false because of the pause itself.
  await paymentConfig(db,env);const user=await register(env,'switch@example.test');
  assert.equal((await summary(env,user)).paymentReady,true);
  const version=await newCatalog(env,{go:{priceCents:3200,creditMicros:20_800_000,includedSites:1},hosting:{annualPriceCents:4400}},'contract-catalog-0001');
  await activateCatalog(env,'owner',version.id,{expectedVersionId:CNY_CATALOG_ID,enabled:true,reason:'启用新价格',confirmedFutureOrdersOnly:true});
  const open=(await json(await get(env,'/api/billing/catalog'))).data,mine=await summary(env,user);
  assert.equal(open.catalogVersionId,version.id);assert.equal(open.plans[0].priceCents,3200);assert.equal(open.plans[0].creditMicros,20_800_000);assert.equal(open.hostingAnnualPriceCents,4400);
  for(const key of ['plans','catalogVersionId','catalogEnabled','hostingAnnualPriceCents','topupPolicy','enterprise'])assert.deepEqual(mine[key],open[key],key);
  assert.equal(mine.paymentReady,true);
  await activateCatalog(env,'owner',version.id,{expectedVersionId:version.id,enabled:false,reason:'暂停新订单',confirmedFutureOrdersOnly:true});
  const paused=(await json(await get(env,'/api/billing/catalog'))).data;assert.equal(paused.catalogEnabled,false);assert.equal(paused.catalogVersionId,version.id);
  const pausedSummary=await summary(env,user);assert.equal(pausedSummary.catalogEnabled,false);assert.equal(pausedSummary.paymentReady,false);
  // Resuming the catalogue makes buying possible again with the same payment configuration.
  await activateCatalog(env,'owner',version.id,{expectedVersionId:version.id,enabled:true,reason:'恢复新订单',confirmedFutureOrdersOnly:true});
  const resumed=await summary(env,user);assert.equal(resumed.catalogEnabled,true);assert.equal(resumed.paymentReady,true);
 }finally{db.close();}
});

test('checkout refuses every new order while the catalogue is disabled, without orders or provider calls',async t=>{
 const {db,env}=fixture(),stripe=fakeAlipay(t);
 try{
  await paymentConfig(db,env);const user=await register(env,'paused@example.test');paidTerm(db,user.userId);site(db,user.userId,'site_paused','Paused','paused.example.test');
  // The default catalogue cannot be disabled without a stored version; activate one and keep its id.
  const version=await newCatalog(env,{},'contract-catalog-0002');
  await activateCatalog(env,'owner',version.id,{expectedVersionId:CNY_CATALOG_ID,enabled:true,reason:'启用新版本',confirmedFutureOrdersOnly:true});
  // An order placed before the pause keeps working with its original request key.
  const before=await post(env,'/api/billing/checkout',user,{kind:'topup',amountCents:500,requestKey:'before-pause-0001',catalogVersionId:version.id});
  assert.equal(before.status,201);const original=(await json(before)).data;assert.equal(original.checkoutState,'open');assert.equal(stripe.checkoutCreations(),0);
  await activateCatalog(env,'owner',version.id,{expectedVersionId:version.id,enabled:false,reason:'暂停新订单',confirmedFutureOrdersOnly:true});
  for(const [index,payload] of [{kind:'subscription',tier:'pro'},{kind:'topup',amountCents:1000},{kind:'hosting',siteId:'site_paused'}].entries()){
   const response=await post(env,'/api/billing/checkout',user,{...payload,requestKey:`paused-request-${index}-0001`,catalogVersionId:version.id});
   assert.equal(response.status,503);const error=(await json(response)).error;assert.equal(error.code,'PURCHASES_PAUSED');assert.match(error.message,/停止新订单/);assert.match(error.requestId,/^req_/);
  }
  assert.equal(orderCount(db),1);assert.equal(stripe.checkoutCreations(),0);
  const retry=await post(env,'/api/billing/checkout',user,{kind:'topup',amountCents:500,requestKey:'before-pause-0001',catalogVersionId:version.id});
  assert.equal(retry.status,201);const resumed=(await json(retry)).data;assert.equal(resumed.orderId,original.orderId);assert.deepEqual(checkoutIdentity(resumed.checkoutUrl),checkoutIdentity(original.checkoutUrl));
  const resume=await post(env,`/api/billing/orders/${original.orderId}/checkout`,user,{});assert.equal(resume.status,200);assert.equal((await json(resume)).data.checkoutState,'open');
  assert.equal(orderCount(db),1);assert.equal(stripe.checkoutCreations(),0);
 }finally{db.close();}
});

test('a pause that lands between the catalogue read and the order insert is still refused atomically',async t=>{
 const {db,env}=fixture(),stripe=fakeAlipay(t);
 try{
  await paymentConfig(db,env);const user=await register(env,'race@example.test');
  const version=await newCatalog(env,{},'contract-catalog-0003');
  await activateCatalog(env,'owner',version.id,{expectedVersionId:CNY_CATALOG_ID,enabled:true,reason:'启用新版本',confirmedFutureOrdersOnly:true});
  db.beforeOrderInsert=()=>db.sqlite.prepare('UPDATE billing_catalog_active SET enabled=0').run();
  const response=await post(env,'/api/billing/checkout',user,{kind:'subscription',tier:'go',requestKey:'race-pause-0001',catalogVersionId:version.id});
  assert.equal(response.status,403);assert.equal((await json(response)).error.code,'PURCHASE_NOT_ALLOWED');
  assert.equal(orderCount(db),0);assert.equal(stripe.calls.length,0);
 }finally{db.close();}
});

test('checkout validation, missing payment configuration and stale catalogues never create orders',async t=>{
 const {db,env}=fixture(),stripe=fakeAlipay(t);
 try{
  const user=await register(env,'validate@example.test');paidTerm(db,user.userId);
  // No payment configuration yet: nothing is created and the summary disables buying.
  const unconfigured=await post(env,'/api/billing/checkout',user,{kind:'subscription',tier:'go',requestKey:'no-config-0001',catalogVersionId:CNY_CATALOG_ID});
  assert.equal(unconfigured.status,503);assert.equal((await json(unconfigured)).error.code,'PAYMENT_NOT_CONFIGURED');assert.equal(orderCount(db),0);
  assert.equal((await summary(env,user)).paymentReady,false);
  await paymentConfig(db,env);assert.equal((await summary(env,user)).paymentReady,true);
  // CNY 4.99 and other malformed amounts fail the schema with 400 VALIDATION.
  for(const amountCents of [499,0,-500,500.5,'500',100_000_000]){
   const response=await post(env,'/api/billing/checkout',user,{kind:'topup',amountCents,requestKey:'bad-amount-0001',catalogVersionId:CNY_CATALOG_ID});
   assert.equal(response.status,400,String(amountCents));const error=(await json(response)).error;assert.equal(error.code,'VALIDATION');
   // The message is a Chinese default, never the schema library's English text.
   assert.equal(error.message,amountCents===499?'充值金额低于当前人民币最低充值金额':'请检查填写内容',String(amountCents));
  }
  for(const payload of [{kind:'topup',amountCents:500,requestKey:'short'},{kind:'subscription',tier:'max',requestKey:'bad-tier-0001'},{kind:'subscription',tier:'go',requestKey:'extra-key-0001',amountCents:1}]){
   const response=await post(env,'/api/billing/checkout',user,payload);assert.equal(response.status,400);assert.equal((await json(response)).error.code,'VALIDATION');
  }
  const stale=await post(env,'/api/billing/checkout',user,{kind:'topup',amountCents:500,requestKey:'stale-catalog-0001',catalogVersionId:'catalog_old'});
  assert.equal(stale.status,409);assert.equal((await json(stale)).error.code,'CATALOG_CHANGED');
  assert.equal(orderCount(db),0);assert.equal(stripe.calls.length,0);
  // The minimum top-up uses the explicit CNY-cent to AI micro-USD rule.
  const minimum=await post(env,'/api/billing/checkout',user,{kind:'topup',amountCents:500,requestKey:'minimum-topup-0001',catalogVersionId:CNY_CATALOG_ID});
  assert.equal(minimum.status,201);const order=(await summary(env,user)).orders[0];assert.equal(order.amount_cents,500);assert.equal(order.credit_micros,3_250_000);
 }finally{db.close();}
});

test('a double-clicked confirm creates exactly one order and one payment session; a changed payload conflicts',async t=>{
 const {db,env}=fixture(),stripe=fakeAlipay(t);
 try{
  await paymentConfig(db,env);const user=await register(env,'double@example.test');
  const payload={kind:'subscription',tier:'go',requestKey:'double-click-0001',catalogVersionId:CNY_CATALOG_ID};
  const [first,second]=await Promise.all([post(env,'/api/billing/checkout',user,payload),post(env,'/api/billing/checkout',user,payload)]);
  assert.equal(first.status,201);assert.equal(second.status,201);
  const a=(await json(first)).data,b=(await json(second)).data;assert.equal(a.orderId,b.orderId);assert.deepEqual(checkoutIdentity(a.checkoutUrl),checkoutIdentity(b.checkoutUrl));assert.match(a.checkoutUrl,/^https:\/\/openapi-sandbox\.dl\.alipaydev\.com\/gateway\.do\?/);
  assert.equal(orderCount(db),1);
  // The signed URLs share one merchant order. Recovery may query, but checkout creation does not POST to the gateway.
  assert.equal(checkoutIdentity(a.checkoutUrl).out_trade_no,a.orderId);assert.equal(stripe.checkoutCreations(),0);
  assert.equal(db.sqlite.prepare('SELECT COUNT(*) n FROM alipay_payments').get()!.n,1);
  const conflict=await post(env,'/api/billing/checkout',user,{...payload,tier:'pro'});assert.equal(conflict.status,409);assert.equal((await json(conflict)).error.code,'IDEMPOTENCY_CONFLICT');
  // A second dialog (new key) cannot open a second outstanding membership order.
  const second2=await post(env,'/api/billing/checkout',user,{...payload,requestKey:'double-click-0002'});assert.equal(second2.status,403);assert.equal((await json(second2)).error.code,'PURCHASE_NOT_ALLOWED');
  assert.equal(orderCount(db),1);
  const listed=(await summary(env,user)).orders;assert.equal(listed.length,1);assert.equal(listed[0].canResumeCheckout,true);assert.equal(listed[0].hostingSiteId,null);
 }finally{db.close();}
});

test('an interrupted Alipay recovery query leaves one order; same-key retry returns its signed payment URL',async t=>{
 const {db,env}=fixture(),gateway=fakeAlipay(t);
 try{
  await paymentConfig(db,env);const user=await register(env,'inflight@example.test');
  const payload={kind:'subscription',tier:'go',requestKey:'inflight-click-0001',catalogVersionId:CNY_CATALOG_ID};
  const first=await post(env,'/api/billing/checkout',user,payload);assert.equal(first.status,201);const original=(await json(first)).data;
  gateway.interruptNextQuery();const interrupted=await post(env,'/api/billing/checkout',user,payload);assert.equal(interrupted.status,503);const error=(await json(interrupted)).error;assert.equal(error.code,'PAYMENT_PROVIDER_UNCONFIRMED');assert.doesNotMatch(error.message,/isolated|interruption|stack/i);
  assert.equal(orderCount(db),1);assert.equal(db.sqlite.prepare('SELECT COUNT(*) n FROM alipay_payments').get()!.n,1);
  const retry=await post(env,'/api/billing/checkout',user,payload);assert.equal(retry.status,201);const again=(await json(retry)).data;assert.equal(again.orderId,original.orderId);assert.deepEqual(checkoutIdentity(again.checkoutUrl),checkoutIdentity(original.checkoutUrl));assert.equal(orderCount(db),1);assert.equal(gateway.checkoutCreations(),0);
 }finally{db.close();}
});

test('summary orders name the hosted site they renew without leaking checkout data or foreign sites',async t=>{
 const {db,env}=fixture();fakeAlipay(t);
 try{
  await paymentConfig(db,env);const user=await register(env,'sites@example.test'),other=await register(env,'other-sites@example.test');
  site(db,user.userId,'site_mine','我的网站','mine.example.test');site(db,other.userId,'site_theirs','别人的网站','theirs.example.test');
  const bought=await post(env,'/api/billing/checkout',user,{kind:'hosting',siteId:'site_mine',requestKey:'hosting-renew-0001',catalogVersionId:CNY_CATALOG_ID});assert.equal(bought.status,201);const boughtId=(await json(bought)).data.orderId;
  const foreign=await post(env,'/api/billing/checkout',user,{kind:'hosting',siteId:'site_theirs',requestKey:'hosting-foreign-0001',catalogVersionId:CNY_CATALOG_ID});
  assert.equal(foreign.status,403);assert.equal((await json(foreign)).error.code,'PURCHASE_NOT_ALLOWED');
  // A legacy/corrupt row pointing at another account's site must not reveal that site's name or domain.
  db.sqlite.prepare("INSERT INTO orders(id,user_id,kind,amount_cents,credit_micros,currency,state,idempotency_key,payload_hash,hosting_site_id,created_at,expires_at) VALUES('ord_legacy',?,'hosting',3000,0,'USD','expired','legacy-key','hash','site_theirs',?,?)")
   .run(user.userId,new Date(Date.now()-DAY).toISOString(),new Date(Date.now()-DAY+7200_000).toISOString());
  const data=await summary(env,user),hosting=data.orders.find((o:Json)=>o.id===boughtId),legacy=data.orders.find((o:Json)=>o.id==='ord_legacy');
  assert.equal(hosting.kind,'hosting');assert.equal(hosting.hostingSiteId,'site_mine');assert.equal(hosting.hostingSiteName,'我的网站');assert.equal(hosting.hostingSiteDomain,'mine.example.test');
  assert.equal(hosting.amount_cents,3000);assert.equal(hosting.credit_micros,0);
  assert.equal(legacy.hostingSiteName,null);assert.equal(legacy.hostingSiteDomain,null);
  assert.doesNotMatch(JSON.stringify(data.orders),/checkout_url|checkout_id|payment_id|plan_snapshot_json|theirs\.example|别人的网站|cs_ord/);
  // The other account sees none of it.
  assert.equal((await summary(env,other)).orders.length,0);
 }finally{db.close();}
});

test('membership expired with a top-up balance: balance stays usable, top-up is refused, nothing is frozen',async t=>{
 const {db,env}=fixture(),stripe=fakeAlipay(t);
 try{
  await paymentConfig(db,env);const user=await register(env,'expired@example.test');
  paidTerm(db,user.userId,'old',Date.now()-40*DAY,Date.now()-10*DAY);
  await grantCredit(db as unknown as D1Database,{id:'topup_left',userId:user.userId,source:'topup',amountMicros:6_500_000,referenceId:'topup-left'});
  const data=await summary(env,user);
  assert.equal(data.plan,null);assert.equal(data.membershipFrozen,false);assert.equal(data.canTopup,false);assert.equal(data.walletState,'ready');
  assert.equal(data.wallet.topupMicros,6_500_000);assert.equal(data.wallet.availableMicros,6_500_000);assert.equal(data.wallet.pausedMicros,0);
  const refused=await post(env,'/api/billing/checkout',user,{kind:'topup',amountCents:500,requestKey:'expired-topup-0001',catalogVersionId:CNY_CATALOG_ID});
  assert.equal(refused.status,403);assert.equal((await json(refused)).error.code,'PURCHASE_NOT_ALLOWED');assert.equal(orderCount(db),0);assert.equal(stripe.calls.length,0);
 }finally{db.close();}
});

test('membershipFrozen follows a real admin freeze and unfreeze; plan and paused credit match it',async()=>{
 const {db,env}=fixture();
 try{
  const user=await register(env,'frozen@example.test');site(db,user.userId,'site_frozen','冻结站点','frozen.example.test');
  const before=await summary(env,user);assert.equal(before.membershipFrozen,false);assert.equal(before.plan,null);
  await giftMembership(env,'owner',user.userId,{tier:'go',months:1,reason:'合同测试赠送',requestKey:'gift-frozen-0001'});
  const gifted=await summary(env,user);assert.equal(gifted.membershipFrozen,false);assert.equal(gifted.plan.source,'gift');assert.equal(gifted.hosting[0].coverage.current.sources[0],'membership');
  const frozenStatus=await freezeMembership(env,'owner',user.userId,{reason:'合同测试冻结',requestKey:'freeze-frozen-0001'});assert.equal(frozenStatus.freeze?.state,'frozen');
  const frozen=await summary(env,user);
  assert.equal(frozen.membershipFrozen,true);assert.equal(frozen.plan,null);assert.ok(frozen.wallet.pausedMicros>0);assert.equal(frozen.hosting[0].coverage.membershipFrozen,true);assert.equal(frozen.canTopup,false);
  await unfreezeMembership(env,'owner',user.userId,{reason:'合同测试解冻',requestKey:'unfreeze-frozen-0001'});
  const resumed=await summary(env,user);assert.equal(resumed.membershipFrozen,false);assert.equal(resumed.plan.source,'gift');assert.equal(resumed.wallet.pausedMicros,0);
 }finally{db.close();}
});

test('a freeze that has not paused billing yet, or has completed, is not reported as frozen',async()=>{
 const {db,env}=fixture();
 try{
  const user=await register(env,'pending-freeze@example.test');paidTerm(db,user.userId);
  const insert=(id:string,state:string,key:string)=>db.sqlite.prepare("INSERT INTO membership_freezes(id,user_id,actor_id,request_key,payload_hash,reason,state,requested_at_ms,updated_at) VALUES(?,?,'owner',?,'hash','test',?,?,?)").run(id,user.userId,key,state,Date.now(),new Date().toISOString());
  insert('freeze_done','completed','freeze-done-key');assert.equal((await summary(env,user)).membershipFrozen,false);
  insert('freeze_pending','pending_billing_change','freeze-pending-key');const pending=await summary(env,user);assert.equal(pending.membershipFrozen,false);assert.equal(pending.plan.source,'paid');
  db.sqlite.prepare("UPDATE membership_freezes SET state='pending_unfreeze',frozen_at_ms=? WHERE id='freeze_pending'").run(Date.now());assert.equal((await summary(env,user)).membershipFrozen,true);
 }finally{db.close();}
});

test('plan.membershipEndsAt spans the whole contiguous membership while endsAt stays the current term',async()=>{
 const {db,env}=fixture();
 try{
  const user=await register(env,'horizon@example.test');
  await giftMembership(env,'owner',user.userId,{tier:'pro',months:3,reason:'三个月赠送',requestKey:'gift-horizon-0001'});
  const data=await summary(env,user),rows=db.sqlite.prepare('SELECT starts_at,ends_at FROM subscriptions WHERE user_id=? ORDER BY starts_at').all(user.userId) as {starts_at:string;ends_at:string}[];
  assert.equal(rows.length,3);assert.equal(data.plan.endsAt,rows[0].ends_at);assert.equal(data.plan.membershipEndsAt,rows[2].ends_at);assert.ok(Date.parse(data.plan.membershipEndsAt)>Date.parse(data.plan.endsAt));
 }finally{db.close();}
});

test('membership horizon chains touching paid and gift terms, stops at gaps and ignores frozen or revoked terms',async()=>{
 const {db}=fixture(),now=Date.parse('2026-11-12T00:00:00.000Z'),at=(days:number)=>now+days*DAY,iso=new Date(now).toISOString();
 try{
  db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,created_at,updated_at) VALUES('h','h@example.test','H','unused',?,?)").run(iso,iso);
  const d=db as unknown as D1Database;
  assert.equal(await membershipHorizon(d,'h',iso),null);
  paidTerm(db,'h','p1',at(-10),at(20));assert.equal(await membershipHorizon(d,'h',iso),new Date(at(20)).toISOString());
  paidTerm(db,'h','g1',at(20),at(50),'active','gift');assert.equal(await membershipHorizon(d,'h',iso),new Date(at(50)).toISOString());
  paidTerm(db,'h','g2',at(40),at(70),'cancelled','gift','pro');assert.equal(await membershipHorizon(d,'h',iso),new Date(at(70)).toISOString());
  paidTerm(db,'h','gap',at(71),at(100),'active','gift');assert.equal(await membershipHorizon(d,'h',iso),new Date(at(70)).toISOString());
  paidTerm(db,'h','revoked',at(70),at(200),'revoked','gift');assert.equal(await membershipHorizon(d,'h',iso),new Date(at(70)).toISOString());
  db.sqlite.prepare("INSERT INTO membership_freezes(id,user_id,actor_id,request_key,payload_hash,reason,state,requested_at_ms,updated_at) VALUES('fz','h','h','fz-key','hash','t','frozen',?,?)").run(now,iso);
  db.sqlite.prepare("UPDATE subscriptions SET membership_frozen_by='fz' WHERE id='g1'").run();assert.equal(await membershipHorizon(d,'h',iso),new Date(at(20)).toISOString());
  // Only future terms (nothing current) yield no horizon.
  assert.equal(await membershipHorizon(d,'h',new Date(at(-20)).toISOString()),null);
 }finally{db.close();}
});

test('cancelling auto-renew keeps the paid period, its end and its hosting slot visible',async t=>{
 const {db,env}=fixture(),stripe=fakeHistoricalStripe(t);
 try{
  await paymentConfig(db,env,'stripe');const user=await register(env,'cancel@example.test');site(db,user.userId,'site_cancel','续费站点','cancel.example.test');
  const iso=new Date().toISOString();
  db.sqlite.prepare("INSERT INTO orders(id,user_id,kind,plan_tier,amount_cents,credit_micros,currency,state,idempotency_key,payload_hash,created_at,expires_at,paid_at,fulfilled_at,config_version_id) VALUES('ord_sub',?,'subscription','go',2500,16250000,'USD','paid','sub-key','hash',?,?,?,?,'pay')").run(user.userId,iso,iso,iso,iso);
  db.sqlite.prepare("INSERT INTO payment_agreements(id,user_id,origin_order_id,config_version_id,provider_subscription_id,tier,state,created_at,updated_at) VALUES('agr_sub_1',?,'ord_sub','pay','sub_contract1','go','active',?,?)").run(user.userId,iso,iso);
  paidTerm(db,user.userId);
  const before=await summary(env,user);assert.equal(before.plan.autoRenew,true);
  const cancel=await post(env,'/api/billing/agreements/agr_sub_1/cancel',user,{});assert.equal(cancel.status,200);assert.deepEqual((await json(cancel)).data,{id:'agr_sub_1',state:'cancel_scheduled',cancelRequested:true});
  const again=await post(env,'/api/billing/agreements/agr_sub_1/cancel',user,{});assert.equal(again.status,200);
  assert.ok(stripe.calls.every(call=>call.key==='benos:cancel:agr_sub_1'));
  const after=await summary(env,user);
  assert.equal(after.plan.autoRenew,false);assert.equal(after.plan.endsAt,before.plan.endsAt);assert.equal(after.plan.membershipEndsAt,before.plan.endsAt);assert.equal(after.plan.source,'paid');
  assert.equal(after.agreements[0].state,'cancel_scheduled');assert.equal(after.canTopup,true);assert.equal(after.membershipFrozen,false);
  assert.deepEqual(after.hosting[0].coverage.current.sources,['membership']);assert.equal(after.hosting[0].endsAt,before.plan.endsAt);
 }finally{db.close();}
});

test('an unreadable wallet is reported as unavailable, never as a zero balance',async()=>{
 const {db,env}=fixture();
 try{
  const user=await register(env,'wallet@example.test');paidTerm(db,user.userId);
  db.failWhen=/credit_grants/;const data=await summary(env,user);db.failWhen=undefined;
  assert.equal(data.walletState,'unavailable');assert.equal(data.wallet,null);assert.equal(data.plan.tier,'go');
 }finally{db.close();}
});
