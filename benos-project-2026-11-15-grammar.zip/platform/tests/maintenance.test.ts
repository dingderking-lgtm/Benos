import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { maintenance } from '../src/modules/maintenance';

test('maintenance lease prevents simultaneous ticks and records only safe counters',async()=>{
 const db=new TestD1(),env=testEnv(db);let unblock!:()=>void,calls=0;
 const pending=new Promise<void>(resolve=>{unblock=resolve;});
 try{
  const first=maintenance(env,{tasks:[{name:'fixture',run:async()=>{calls++;await pending;return {processed:3,credential:'must not persist'};}}]});
  await new Promise(resolve=>setTimeout(resolve,10));
  const duplicate=await maintenance(env,{tasks:[{name:'fixture',run:async()=>{calls++;}}]});assert.equal(duplicate.state,'already_running');unblock();
  assert.equal((await first).state,'succeeded');assert.equal(calls,1);
  const record=db.sqlite.prepare('SELECT * FROM maintenance_runs').get()!;assert.equal(record.lease_token,null);assert.ok(record.last_finished_at);assert.doesNotMatch(String(record.last_result_json),/credential|must not/);
 }finally{unblock?.();db.close();}
});
test('failed or partially completed background tasks are not reported as successful; next tick can recover',async()=>{
 const db=new TestD1(),env=testEnv(db);try{
  const result=await maintenance(env,{tasks:[{name:'connector',run:async()=>{throw Error('token=secret');}},{name:'hosting',run:async()=>({synced:2,failed:1})}]});assert.equal(result.state,'partial');assert.doesNotMatch(JSON.stringify(result),/secret|token/);
  const next=await maintenance(env,{tasks:[{name:'recovery',run:async()=>({processed:2})}]});assert.equal(next.state,'succeeded');
 }finally{db.close();}
});
