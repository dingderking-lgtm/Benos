import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { mkdir, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { parseFragment } from 'parse5';
import { getV2Fixture } from '../src/design-system/v2/fixtures';
import { renderV2Section } from '../src/design-system/v2/render';

const localRequire=createRequire(import.meta.url);let chromium:any=null;try{chromium=localRequire('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright').chromium;}catch{}
const source=resolve('..','reference','aacmss','src','Services'),browserPath='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const phpAvailable=existsSync(resolve(source,'Renderer.php'))&&spawnSync('php',['-r','echo class_exists("DOMDocument")&&extension_loaded("mbstring")?"yes":"no";'],{windowsHide:true,encoding:'utf8'}).stdout==='yes';
const php=String.raw`require $argv[1].'/PageHiddenContent.php';require $argv[1].'/Renderer.php';$p=new class extends PDO{public function __construct(){}};$r=new \AACMS\Services\Renderer($p);$out=[];foreach(json_decode(stream_get_contents(STDIN),true,64,JSON_THROW_ON_ERROR) as $row)$out[]=['html'=>$r->renderDocument(['version'=>1,'html'=>$row['html'],'css'=>$row['css']]),'css'=>$r->sanitizeCss($row['css'])];echo json_encode($out,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);`;
const text=(node:any):string=>node.nodeName==='#text'?node.value:(node.childNodes||[]).map(text).join('');

test('CJK phrase markup preserves exact authored text and escaped content; English stays unchanged',async()=>{
 const f=getV2Fixture('hero-stage','centered','deep-studio',{scenario:'no-images'});
 for(const title of ['在群山之间，留一段空白。','“先了解问题，再制定计划。”','中文，<script>literal</script>。','只保留没有标点的原始中文标题','Start with the part. Define the right machine.']){
  const r=await renderV2Section({...f.input,content:{...f.input.content,title}},f.context),fragment=parseFragment(r.html);let heading:any;
  const walk=(n:any)=>{if(n.tagName==='h1')heading=n;for(const c of n.childNodes||[])walk(c);};walk(fragment);
  assert.equal(text(heading),title);assert.equal(/<script>/.test(r.html),false);
  if(!/[\p{Script=Han}]/u.test(title))assert.equal(heading.childNodes.some((n:any)=>n.tagName==='span'),false);
 }
});

test('formal PHP renderer keeps CJK clause line boxes balanced and long/English titles safe at four widths',{
 skip:!phpAvailable||!chromium||!existsSync(browserPath)?'Requires local PHP and Edge':false,timeout:60000,
},async()=>{
 const titles=[
  {key:'stay',text:'在群山之间，留一段空白。'},
  {key:'long',text:'让每一次复杂设备选型都能回到真实的工艺问题与完整上下文，按项目需要稳妥地安排下一步。'},
  {key:'english',text:'Start with the part. Define the right machine.'},
  {key:'mixed',text:'以真实工艺为起点，Build a clearer plan together。'},
 ];
 const rows:any[]=[];for(const [pattern,variant] of [['hero-stage','centered'],['hero-cover','scene']] as const)for(const title of titles){const f=getV2Fixture(pattern,variant,'deep-studio',{scenario:'no-images'}),r=await renderV2Section({...f.input,content:{...f.input.content,title:title.text}},f.context);rows.push({...title,pattern,html:r.html,css:r.css});}
 const proc=spawnSync('php',['-r',php,source],{windowsHide:true,encoding:'utf8',input:JSON.stringify(rows),maxBuffer:4*1024*1024});assert.equal(proc.status,0,proc.stderr);const rendered=JSON.parse(proc.stdout);
 // The production renderer strips text-wrap; the structural fallback must work alone.
 assert.ok(rendered.every((r:any)=>!r.css.includes('text-wrap:')));assert.ok(rendered.every((r:any)=>r.css.includes('display:inline-block')&&r.css.includes('max-width:100%')));
 const dir=resolve('..','artifacts','design-system-integration-20261114','heading-phrases');await mkdir(dir,{recursive:true});
 const browser=await chromium.launch({executablePath:browserPath,headless:true}),measurements:any[]=[];
 try{const page=await browser.newPage();for(let i=0;i<rows.length;i++)for(const width of [320,390,768,1440]){
  await page.setViewportSize({width,height:900});await page.setContent(`<html lang="${rows[i].key==='english'?'en':'zh-CN'}"><head><style>body{margin:0}:root{--bnf-heading:Helvetica,Arial,"Microsoft YaHei",sans-serif}</style></head><body><div class="aacms-page">${rendered[i].html}</div></body></html>`);await page.evaluate('globalThis.__name=(fn)=>fn');
  const measurement=await page.evaluate(()=>{const win=globalThis as any,doc=win.document,h=doc.querySelector('h1'),r=h.getBoundingClientRect(),walker=doc.createTreeWalker(h,win.NodeFilter.SHOW_TEXT),lines:Array<{top:number;text:string}>=[];let node:any;
   while((node=walker.nextNode())){let offset=0;for(const ch of Array.from(node.textContent||'') as string[]){const range=doc.createRange();range.setStart(node,offset);offset+=ch.length;range.setEnd(node,offset);const box=range.getBoundingClientRect();if(!box.width&&!box.height)continue;let line=lines.find(l=>Math.abs(l.top-box.top)<2);if(!line){line={top:box.top,text:''};lines.push(line);}line.text+=ch;}}
   return{text:h.textContent,overflow:doc.documentElement.scrollWidth-win.innerWidth,headingWidth:r.width,phrases:[...h.querySelectorAll('.bnx-heading-phrase')].map((el:any)=>({text:el.textContent,width:el.getBoundingClientRect().width})),lines:lines.sort((a,b)=>a.top-b.top)};
  });const result={pattern:rows[i].pattern,key:rows[i].key,width,...measurement};measurements.push(result);assert.equal(measurement.text,rows[i].text);assert.ok(measurement.overflow<=1,JSON.stringify(result));assert.ok(measurement.phrases.every((p:any)=>p.width<=measurement.headingWidth+1),JSON.stringify(result));
  if(rows[i].key==='english')assert.equal(measurement.phrases.length,0);
  if(rows[i].key==='stay'){assert.deepEqual(measurement.lines.map((l:any)=>l.text),['在群山之间，','留一段空白。'],JSON.stringify(result));if(width===390||width===1440)await page.screenshot({path:resolve(dir,`${rows[i].pattern}-${width}.png`),fullPage:true});}
 }}finally{await browser.close();await writeFile(resolve(dir,'report.json'),JSON.stringify({cases:measurements.length,expectedCases:32,cmsStripsTextWrap:true,measurements},null,2));}
 assert.equal(measurements.length,32);
});
