import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';
import { FakeR2,png } from './media-helper';
import { defaultPlatformBrand } from '../src/modules/admin-settings';
import { createCatalogVersion,activateCatalog,BUILTIN_CATALOG_ID,DEFAULT_CATALOG } from '../src/modules/billing-catalog';

async function fixture(){const db=new TestD1(),env=testEnv(db);env.BUCKET=new FakeR2() as unknown as R2Bucket;const headers:Record<string,string>={origin:env.APP_ORIGIN,'content-type':'application/json'};const boot=await app.request('/api/bootstrap',{method:'POST',headers,body:JSON.stringify({token:env.BOOTSTRAP_TOKEN,email:'brand@example.test',password:'brand-owner-password',name:'Owner'})},env),auth=await boot.json() as any;assert.equal(boot.status,201);headers.cookie=boot.headers.get('set-cookie')!.split(';')[0];headers['x-csrf-token']=auth.data.csrfToken;const request=(path:string,method='GET',data?:unknown)=>app.request(path,{method,headers,body:data===undefined?undefined:JSON.stringify(data)},env);const json=async(response:Response,status=200)=>{assert.equal(response.status,status,await response.clone().text());return (await response.json() as any).data;};return {db,env,headers,request,json};}

test('branding versions require owner, real logo verification and activation; rollback retains dependencies and public logo permission',async()=>{
 const f=await fixture();try{
  assert.equal((await f.json(await f.request('/api/branding'))).brandName,'Benos');
  const upload=await app.request('/api/admin/content/media',{method:'POST',headers:{...f.headers,'content-type':'image/png','x-filename':'brand.png','idempotency-key':'branding_upload_01'},body:png(32,32)},f.env),media=await f.json(upload,201);
  const create=async(name:string,logo:string|null)=>f.json(await f.request('/api/admin/settings/branding','POST',{configuration:{...defaultPlatformBrand,brandName:name,logoMediaId:logo,contactEmail:'support@example.test'},reason:'验证品牌版本'}),201);
  const first=await create('Benos Studio',media.id);
  assert.equal((await f.request(media.publicUrl)).status,404);assert.equal((await f.request('/api/admin/settings/branding/'+first.id+'/activate','POST',{reason:'不能越过校验'})).status,409);
  await f.json(await f.request('/api/admin/settings/branding/'+first.id+'/test','POST',{reason:'校验文件完整性'}));await f.json(await f.request('/api/admin/settings/branding/'+first.id+'/activate','POST',{reason:'启用已验证配置'}));
  assert.equal((await f.request(media.publicUrl)).status,200);const home=await (await f.request('/home')).text();assert.ok(home.includes('Benos Studio'));assert.ok(home.includes('mailto:support@example.test'));assert.ok(home.includes(media.publicUrl));
  const refs=await f.json(await f.request('/api/admin/content/media/'+media.id+'/references'));assert.ok(refs.items.some((r:any)=>r.kind==='brand_version'&&r.id===first.id));
  const rejected=await f.request('/api/admin/content/media/'+media.id+'/delete','POST',{revision:media.revision});assert.equal(rejected.status,409);assert.ok((await rejected.text()).includes('品牌配置 v1'));
  const second=await create('Benos New',null);for(const action of ['test','activate'])await f.json(await f.request('/api/admin/settings/branding/'+second.id+'/'+action,'POST',{reason:'启用新版配置'}));assert.equal((await f.request(media.publicUrl)).status,404);
  await f.json(await f.request('/api/admin/settings/branding/'+first.id+'/activate','POST',{reason:'回退到原配置'}));assert.equal((await f.request(media.publicUrl)).status,200);
  assert.throws(()=>f.db.sqlite.prepare("UPDATE platform_brand_versions SET configuration_json='{}' WHERE id=?").run(first.id),/brand_configuration_immutable/);assert.throws(()=>f.db.sqlite.prepare('DELETE FROM platform_brand_versions WHERE id=?').run(first.id),/brand_version_no_delete/);
  await f.json(await f.request('/api/admin/settings/branding/'+first.id+'/disable','POST',{reason:'恢复默认品牌'}));assert.equal((await f.json(await f.request('/api/branding'))).brandName,'Benos');assert.equal((await f.request(media.publicUrl)).status,404);
  f.db.sqlite.prepare("UPDATE users SET role='editor'").run();assert.equal((await f.request('/api/admin/settings/branding')).status,403);assert.equal((await f.request('/api/admin/settings/branding/'+first.id+'/activate','POST',{reason:'越权不能修改'})).status,403);
 }finally{f.db.close();}
});

test('published marketing price copy uses active catalog and disabled sales remain visibly unavailable',async()=>{
 const f=await fixture();try{const owner=f.db.sqlite.prepare('SELECT id FROM users').get()!.id as string,catalog=structuredClone(DEFAULT_CATALOG);catalog.cnyPricing={goPriceCents:3200,proPriceCents:10000,hostingAnnualPriceCents:4400,minimumTopupCents:500,topupCreditMicrosPerCnyCent:900};catalog.go.priceCents=3200;catalog.go.creditMicros=20_800_000;catalog.go.includedSites=3;catalog.hosting.annualPriceCents=4400;catalog.enterprise.description='团队专属联系报价';const version=await createCatalogVersion(f.env,owner,{catalog,reason:'新的定价验证版本',requestKey:'branding-catalog-01'});await activateCatalog(f.env,owner,version.id,{expectedVersionId:BUILTIN_CATALOG_ID,enabled:true,reason:'启用新版本定价',confirmedFutureOrdersOnly:true});let html=await (await f.request('/home')).text();/* The hosting add-on card (¥44) is no longer on the home page; its price is shown in the workspace. */for(const value of ['¥32','¥231.11','包含 3 个网站托管','团队专属联系报价'])assert.ok(html.includes(value),value);assert.ok(!html.includes('$25 <small>'));await activateCatalog(f.env,owner,version.id,{expectedVersionId:version.id,enabled:false,reason:'暂停新订单入口',confirmedFutureOrdersOnly:true});html=await (await f.request('/home')).text();assert.ok(html.includes('暂停新订购'));assert.ok(!html.includes('>从 Go 开始</a>'));}finally{f.db.close();}
});

test('the public price list lives only at /api/billing/catalog: the duplicate /api/catalog is gone',async()=>{
 const f=await fixture();try{
  // P7.2 removed the duplicate GET /api/catalog; every front-end consumer reads GET /api/billing/catalog.
  for(const method of ['GET','POST'])assert.equal((await app.request('/api/catalog',{method,headers:{origin:f.env.APP_ORIGIN}},f.env)).status,404,method);
  const anonymous=await app.request('/api/billing/catalog',{},f.env),initial=(await anonymous.json() as any).data;assert.equal(anonymous.status,200);assert.equal(anonymous.headers.get('cache-control'),'no-store');
  assert.equal(initial.catalogVersionId,BUILTIN_CATALOG_ID);assert.equal(initial.catalogEnabled,true);
  assert.deepEqual(initial.plans.map((plan:any)=>[plan.tier,plan.name,plan.priceCents,plan.creditMicros,plan.includedSites,plan.billingInterval]),[['go','Go',null,16_250_000,1,'month'],['pro','Pro',null,65_000_000,2,'month']]);
  assert.equal(initial.hostingAnnualPriceCents,null);assert.deepEqual(initial.topupPolicy,{minimumCents:null,creditMicrosPerCnyCent:null,currency:'CNY'});assert.equal(initial.pricingReady,false);assert.equal(initial.paymentReady,false);assert.equal(initial.enterprise.contactEnabled,true);
  assert.deepEqual(Object.keys(initial).sort(),['billingMode','catalogEnabled','catalogVersionId','cnyPricing','currency','enterprise','hostingAnnualPriceCents','paymentProvider','paymentReady','paymentUnavailableReason','plans','pricingReady','topupPolicy']);
  const owner=f.db.sqlite.prepare('SELECT id FROM users').get()!.id as string,catalog=structuredClone(DEFAULT_CATALOG);catalog.cnyPricing={goPriceCents:3200,proPriceCents:10000,hostingAnnualPriceCents:4400,minimumTopupCents:500,topupCreditMicrosPerCnyCent:900};catalog.go.priceCents=3200;catalog.go.creditMicros=20_800_000;catalog.hosting.annualPriceCents=4400;
  const version=await createCatalogVersion(f.env,owner,{catalog,reason:'公开价目验证版本',requestKey:'public-catalog-test-01'});await activateCatalog(f.env,owner,version.id,{expectedVersionId:BUILTIN_CATALOG_ID,enabled:false,reason:'暂停新订单入口',confirmedFutureOrdersOnly:true});
  const next=(await (await app.request('/api/billing/catalog',{},f.env)).json() as any).data;assert.equal(next.catalogVersionId,version.id);assert.equal(next.catalogEnabled,false);assert.equal(next.plans[0].priceCents,3200);assert.equal(next.hostingAnnualPriceCents,4400);
 }finally{f.db.close();}
});

test('content dates keep the published snapshot until explicit publication and dependency lists identify each draft or published source',async()=>{
 const f=await fixture();try{
  const create=async(kind:string,slug:string,content:any)=>f.json(await f.request('/api/admin/content','POST',{kind,slug,title:'标题 '+slug,content}),201);
  let category=await create('category','category',{body:'分类'});category=await f.json(await f.request('/api/admin/content/'+category.id+'/publish','POST',{revision:category.revision}));
  let row=await create('post','publication-date',{body:'正文',categoryId:category.id,publicationDate:'2025-01-02T03:04:00.000Z'});row=await f.json(await f.request('/api/admin/content/'+row.id+'/publish','POST',{revision:row.revision}));assert.equal(row.publishedAt,'2025-01-02T03:04:00.000Z');
  row=await f.json(await f.request('/api/admin/content/'+row.id,'PATCH',{kind:'post',slug:'publication-date',title:row.title,revision:row.revision,content:{body:'新版草稿',categoryId:category.id,publicationDate:'2025-02-03T04:05:00.000Z'}}));let live=await f.json(await f.request('/api/content/post/publication-date'));assert.equal(live.publishedAt,'2025-01-02T03:04:00.000Z');
  const refs=await f.json(await f.request('/api/admin/content/'+category.id+'/references'));assert.equal(refs.items[0].id,row.id);assert.deepEqual(refs.items[0].snapshots,['draft','published']);const denied=await f.request('/api/admin/content/'+category.id+'/unpublish','POST',{revision:category.revision});assert.equal(denied.status,409);assert.ok((await denied.text()).includes(row.title));
  row=await f.json(await f.request('/api/admin/content/'+row.id+'/publish','POST',{revision:row.revision}));assert.equal(row.publishedAt,'2025-02-03T04:05:00.000Z');
  row=await f.json(await f.request('/api/admin/content/'+row.id,'PATCH',{kind:'post',slug:'publication-date',title:row.title,revision:row.revision,content:{body:'未来草稿',publicationDate:'2099-01-01T00:00:00.000Z'}}));assert.equal((await f.request('/api/admin/content/'+row.id+'/publish','POST',{revision:row.revision})).status,400);live=await f.json(await f.request('/api/content/post/publication-date'));assert.equal(live.publishedAt,'2025-02-03T04:05:00.000Z');
 }finally{f.db.close();}
});
