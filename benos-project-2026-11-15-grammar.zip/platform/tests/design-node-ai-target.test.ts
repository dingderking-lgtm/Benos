import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath, URL } from 'node:url';
import { describeDesignNodePage,describeDesignNodes,annotateDesignHtml,designNodeHtml,patchDesignImage,assertDesignScope,type DesignManifest } from '../src/modules/design-nodes';
const manifest=(html:string):DesignManifest=>({site:{},assets:[],templates:[{id:1,name:'首页',type:'page',document:{html,css:''}}]});
const selected=(html:string,key:string)=>describeDesignNodePage(manifest(html),{templateId:1,nodeKey:key}).items[0];

test('real selected Hero image retains its image scope and exposes the same-source enclosing Hero for AI',()=>{
 const html=readFileSync(fileURLToPath(new URL('./fixtures/selected-hero/home.html',import.meta.url)),'utf8'),base=manifest(html),before=JSON.stringify(base);
 const image=describeDesignNodePage(base,{templateId:1,nodeKey:'n3'}).items[0],frame=describeDesignNodePage(base,{templateId:1,nodeKey:'n2'}).items[0],hero=describeDesignNodePage(base,{templateId:1,nodeKey:'n1'}).items[0];
 assert.equal(image.tag,'img');assert.equal(image.nodeKey,'n3');assert.equal(image.canReplaceImage,true);assert.equal(image.protected,false);
 assert.equal(image.aiTarget?.templateId,1);assert.equal(image.aiTarget?.nodeKey,'n1');assert.equal(image.aiTarget?.tag,'section');assert.equal(image.aiTarget?.protected,false);assert.match(image.aiTarget!.label,/^首屏区块/);
 assert.deepEqual(image.aiTarget,frame.aiTarget);assert.deepEqual(image.aiTarget,hero.aiTarget);assert.equal(JSON.stringify(base),before);
 const original=designNodeHtml(base,{kind:'node',templateId:1,nodeKey:'n3'});assert.match(original.html,/^<img\b/);assert.doesNotMatch(original.html,/<section/);
 const changed=patchDesignImage(base,{kind:'node',templateId:1,nodeKey:'n3'},{file:'assets/replacement.png',path:'/replacement.png',sha256:'a'.repeat(64),size:1},'替换图片');assertDesignScope(base,changed,{kind:'node',templateId:1,nodeKey:'n3'});
 assert.match(designNodeHtml(changed,{kind:'node',templateId:1,nodeKey:'n3'}).html,/src="\/replacement.png"/);
});

test('nearest explicit semantic ancestor wins; ordinary wrappers and plain static anchors are not AI boundaries',()=>{
 const html='<main><section id="outer"><div><article><a href="#details"><span>具体说明</span></a></article></div></section><footer><p>落款</p></footer></main>';
 assert.deepEqual(selected(html,'n5').aiTarget,{templateId:1,nodeKey:'n3',tag:'article',label:'文章区块 · 具体说明',protected:false});
 assert.equal(selected(html,'n7').aiTarget?.nodeKey,'n6');assert.equal(selected(html,'n7').aiTarget?.tag,'footer');
 const header='<header><div><a href="/">品牌</a></div></header>';assert.equal(selected(header,'n2').aiTarget?.nodeKey,'n0');assert.equal(selected(header,'n2').aiTarget?.protected,false);
});

test('managed bindings, forms, placeholders and compiled header boundaries never promote a descendant to an editable ancestor',()=>{
 const samples=[
  '<section><div data-aacms="site-navigation"><span>菜单</span></div></section>',
  '<section><div data-template="field"><span>模板</span></div></section>',
  '<section><form><span>表单</span></form></section>',
  '<section><a href="{{ target }}"><span>链接</span></a></section>',
  '<section><div data-media-id="owned"><span>素材</span></div></section>',
  '<header class="bnh-site-header"><div><span>品牌</span></div></header>',
 ];
 for(const html of samples){const node=selected(html,'n2');assert.equal(node.aiTarget?.nodeKey,'n2');assert.equal(node.aiTarget?.protected,true,html);}
 const nested='<section data-aacms="listing"><article><p>内容</p></article></section>';assert.equal(selected(nested,'n2').aiTarget?.nodeKey,'n2');assert.equal(selected(nested,'n2').aiTarget?.protected,true);
 assert.equal(selected('<section><p>{{ title }}</p></section>','n1').aiTarget?.protected,true);
 const header=selected('<header class="bnh-site-header"><span>品牌</span></header>','n0');assert.equal(header.aiTarget?.protected,true);assert.equal(header.aiTarget?.nodeKey,'n0');
});

test('no ancestor, malformed unclosed block and foreign markup conservatively keep the exact node',()=>{
 const plain=selected('<div><img src="/x.png" alt="设备"></div>','n1');assert.equal(plain.aiTarget?.nodeKey,'n1');assert.equal(plain.aiTarget?.tag,'img');assert.equal(plain.aiTarget?.protected,false);
 const unclosed=selected('<section><div><img src="/x.png" alt="设备">','n2');assert.equal(unclosed.aiTarget?.nodeKey,'n2');
 const foreign=selected('<section><svg><text>图中文字</text></svg></section>','n2');assert.equal(foreign.aiTarget?.nodeKey,'n2');assert.equal(foreign.aiTarget?.protected,true);
});

test('node ordinals, inert-template exclusion, pagination and legacy model descriptions remain unchanged',()=>{
 const html='<div><style>.x{color:red}</style><template><section><img src="/inert.png"></section></template><section><p>正文</p><img src="/x.png" alt="图片"></section></div>',base=manifest(html),nodes=describeDesignNodes(base);
 assert.deepEqual(nodes.map(n=>n.nodeKey),['n0','n3','n4','n5']);assert.ok(nodes.every(n=>!('aiTarget' in n)));
 const page=describeDesignNodePage(base,{templateId:1,limit:200});assert.deepEqual(page.items,nodes);assert.ok(page.items.every(n=>!('aiTarget' in n)));
 const exact=describeDesignNodePage(base,{templateId:1,nodeKey:'n5'}).items[0];const {aiTarget,...old}=exact;assert.deepEqual(old,nodes.at(-1));assert.equal(aiTarget?.nodeKey,'n3');
 const annotated=annotateDesignHtml(html,1);assert.ok(annotated.includes('data-benos-node="n5"'));assert.ok(!annotated.includes('data-benos-node="n6"'));assert.throws(()=>describeDesignNodePage(base,{templateId:1,nodeKey:'n2'}));
});

test('large explicit lookup stays bounded and does not inflate batched responses or read other templates',()=>{
 const count=20000,base=manifest('<section id="orientation">'+Array.from({length:count},(_,i)=>`<div><p>item ${i}</p></div>`).join('')+'</section>');
 const other:any={id:2,name:'未请求模板',type:'page'};Object.defineProperty(other,'document',{get(){throw Error('other template must not be parsed');}});base.templates.push(other);
 const exact=describeDesignNodePage(base,{templateId:1,nodeKey:'n40000'});assert.equal(exact.items[0].label,'item 19999');assert.equal(exact.items[0].aiTarget?.nodeKey,'n0');assert.ok(exact.items[0].aiTarget!.label.length<=65);assert.ok(JSON.stringify(exact).length<1000);
 const page=describeDesignNodePage(base,{templateId:1,limit:200});assert.equal(page.items.length,200);assert.ok(page.items.every(n=>!('aiTarget' in n)));assert.ok(JSON.stringify(page).length<45000);
});
