import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Browser modules are authored in JavaScript.
import { renderBillingHosting } from '../public/js/billing-hosting.js';
// @ts-expect-error Browser modules are authored in JavaScript.
import { renderMembershipPanel } from '../public/js/memberships.js';
// @ts-expect-error Browser modules are authored in JavaScript.
import { renderOrderActions,handlePaymentAction } from '../public/js/payments.js';

test('billing distinguishes current coverage, elapsed periods and a future gap without duplicating sites',()=>{
 const html=renderBillingHosting([
  {id:'a',name:'A',domain:'a.example.com',state:'connected',coverage:{current:{startsAt:'2026-01-01',endsAt:'2027-01-01',sources:['annual','membership']},upcoming:[{startsAt:'2027-03-01',endsAt:'2028-03-01',sources:['annual']}]}},
  {id:'b',name:'B',domain:'b.example.com',state:'suspended',coverage:{current:null,lastEndedAt:'2026-01-01',upcoming:[{startsAt:'2027-03-01',endsAt:'2028-03-01',sources:['annual']}]}},
 ],true);
 assert.equal((html.match(/data-billing-site-id=/g)||[]).length,2);
 assert.equal((html.match(/当前权益有效至/g)||[]).length,1);
 assert.match(html,/当前托管权益已到期/);assert.match(html,/空档不包含托管服务/);assert.match(html,/会员附送托管/);assert.match(html,/未到账的自动续费不计入/);
});
test('missing coverage is not invented and disabled payments do not expose actionable renewal buttons',()=>{
 const html=renderBillingHosting([{id:'s',name:'<script>bad</script>',state:'pending'}],false);
 assert.match(html,/权益暂时无法读取/);assert.doesNotMatch(html,/<script>/);assert.match(html,/data-site-id="s" disabled/);
});
test('pending membership gifts remain readable but retries are exposed only to the permitted manager',()=>{
 const member={id:'u',role:'user'},membership={items:[],gifts:[{id:'g',tier:'go',state:'pending'}]};
 for(const role of ['support','editor','user']){const html=renderMembershipPanel({user:member,membership},{id:'actor',role});assert.match(html,/赠送正在入账/);assert.doesNotMatch(html,/membership-gift-retry/);assert.match(html,/此记录仅供查看/);}
 assert.match(renderMembershipPanel({user:member,membership},{id:'owner',role:'owner'}),/membership-gift-retry/);
 assert.match(renderMembershipPanel({user:member,membership},{id:'admin',role:'admin'}),/membership-gift-retry/);
 for(const role of ['admin','support','editor','owner'])assert.doesNotMatch(renderMembershipPanel({user:{id:'peer',role},membership},{id:'admin',role:'admin'}),/membership-gift-retry/);
});

test('checkout recovery uses the original order, redirects only verified open HTTPS Stripe sessions, and reports pending payment honestly',async t=>{
 assert.match(renderOrderActions({id:'original',canResumeCheckout:true}),/payment-resume/);assert.doesNotMatch(renderOrderActions({id:'closed',canResumeCheckout:false}),/payment-resume/);
 const assigned:string[]=[],notices:string[]=[],requests:any[]=[];let reloads=0;
 const oldWindow=Object.getOwnPropertyDescriptor(globalThis,'window');Object.defineProperty(globalThis,'window',{configurable:true,value:{location:{assign:(url:string)=>assigned.push(url)}}});t.after(()=>{if(oldWindow)Object.defineProperty(globalThis,'window',oldWindow);else delete (globalThis as any).window;});
 let response:any={checkoutState:'open',checkoutUrl:'https://checkout.stripe.com/c/pay/original'};
 t.mock.method(globalThis,'fetch',async(url:unknown,init:RequestInit)=>{requests.push({url,body:JSON.parse(String(init.body)),method:init.method});return Response.json({ok:true,data:response});});
 const trigger={dataset:{orderId:'original'},isConnected:true,disabled:false},context={state:{resource:{}},notify:(text:string)=>notices.push(text),reload:async()=>{reloads++;}};
 await handlePaymentAction('payment-resume',trigger,context);assert.deepEqual(requests[0],{url:'/api/billing/orders/original/checkout',method:'POST',body:{}});assert.equal(assigned.length,1);assert.equal(trigger.disabled,false);
 for(const url of ['https://evil.example/pay','https://checkout.stripe.com@evil.example/pay','https://x:y@checkout.stripe.com/pay','http://checkout.stripe.com/pay']){response={checkoutState:'open',checkoutUrl:url};await assert.rejects(handlePaymentAction('payment-resume',trigger,context),/安全检查/);}
 for(const state of ['complete','paid','expired','unconfirmed']){response={checkoutState:state,checkoutUrl:'https://checkout.stripe.com/must-not-follow'};await handlePaymentAction('payment-resume',trigger,context);}
 assert.equal(assigned.length,1);assert.equal(reloads,4);assert.match(notices[0],/正在核对到账/);assert.match(notices[1],/已确认入账/);assert.match(notices[2],/已到期/);assert.match(notices[3],/尚未确认/);
});
