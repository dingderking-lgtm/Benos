import assert from 'node:assert/strict';
import { afterEach, beforeEach, test } from 'node:test';
import { LedgerTestDatabase } from './ledger-helper.ts';
import {
  claimReservation, fundProvider, getReservation, getWallet, grantCredit,
  LedgerError, markUncertain, releaseConfirmedUnused, reserve, settle,
} from '../src/modules/ledger.ts';

let database: LedgerTestDatabase;
let db: D1Database;
const now = 1_000;
beforeEach(() => { database = new LedgerTestDatabase(); db = database.asD1(); });
afterEach(() => database.close());

async function seed(userAmount = 1_000_000, poolAmount = 10_000_000, userId = 'user-a') {
  await grantCredit(db, { id: `topup-${userId}`, userId, source: 'topup', amountMicros: userAmount, referenceId: `purchase-${userId}`, nowMs: now });
  await fundProvider(db, { id: 'fund-1', providerId: 'openai', amountMicros: poolAmount, referenceId: 'upstream-purchase-1', nowMs: now });
}
function hold(id: string, amountMicros: number, userId = 'user-a') {
  return reserve(db, { id, userId, providerId: 'openai', amountMicros, requestKey: id, nowMs: now });
}
function code(expected: string) {
  return (error: unknown) => error instanceof LedgerError && error.code === expected;
}

test('grants and provider funding are idempotent by business reference, not random delivery IDs', async () => {
  await seed();
  const credit = await grantCredit(db, { id: 'different-delivery-id', userId: 'user-a', source: 'topup', amountMicros: 1_000_000, referenceId: 'purchase-user-a', nowMs: now + 99 });
  assert.equal(credit.id, 'topup-user-a');
  const funding = await fundProvider(db, { id: 'different-funding-id', providerId: 'openai', amountMicros: 10_000_000, referenceId: 'upstream-purchase-1', nowMs: now + 99 });
  assert.equal(funding.id, 'fund-1');
  assert.equal((await getWallet(db, 'user-a', now)).availableMicros, 1_000_000);
  assert.equal(database.row('SELECT funded_micros AS amount FROM provider_pools').amount, 10_000_000);
  assert.equal(database.row('SELECT count(*) AS count FROM ledger_events').count, 2);
  await assert.rejects(grantCredit(db, { id: 'changed', userId: 'user-a', source: 'topup', amountMicros: 2_000_000, referenceId: 'purchase-user-a', nowMs: now }), code('IDEMPOTENCY_CONFLICT'));
});

test('allocates earliest monthly grants, then gifts, then paid topup and settles in that same order', async () => {
  await seed(100, 1_000);
  await grantCredit(db, { id: 'month-late', userId: 'user-a', source: 'subscription', amountMicros: 8, expiresAtMs: 9_000, referenceId: 'month-late', nowMs: now });
  await grantCredit(db, { id: 'month-early', userId: 'user-a', source: 'subscription', amountMicros: 5, expiresAtMs: 4_000, referenceId: 'month-early', nowMs: now });
  await grantCredit(db, { id: 'gift', userId: 'user-a', source: 'gift', amountMicros: 20, expiresAtMs: 3_000, referenceId: 'gift', nowMs: now });
  await hold('request-1', 35);
  assert.deepEqual(database.rows('SELECT grant_id, reserved_micros FROM reservation_allocations ORDER BY ordinal').map(row => [row.grant_id, row.reserved_micros]),
    [['month-early', 5], ['month-late', 8], ['gift', 20], ['topup-user-a', 2]]);
  await settle(db, { reservationId: 'request-1', actualMicros: 14, nowMs: 2_000 });
  assert.deepEqual(database.rows('SELECT grant_id, consumed_micros FROM reservation_allocations ORDER BY ordinal').map(row => [row.grant_id, row.consumed_micros]),
    [['month-early', 5], ['month-late', 8], ['gift', 1], ['topup-user-a', 0]]);
  const wallet = await getWallet(db, 'user-a', 2_000);
  assert.equal(wallet.availableMicros, 119);
  assert.equal(wallet.reservedMicros, 0);
  assert.equal(wallet.consumedMicros, 14);
  assert.equal(database.row('SELECT consumed_micros AS spent FROM provider_pools').spent, 14);
});

test('gift consumption order can explicitly follow topup', async () => {
  await seed(100, 1_000);
  await grantCredit(db, { id: 'gift', userId: 'user-a', source: 'gift', amountMicros: 100, referenceId: 'gift', giftSpendOrder: 'after_topup', nowMs: now });
  await hold('request-1', 50);
  assert.equal(database.row('SELECT grant_id FROM reservation_allocations').grant_id, 'topup-user-a');
});

test('new reservations cannot use expired or not-yet-active monthly grants', async () => {
  await fundProvider(db, { id: 'fund', providerId: 'openai', amountMicros: 1_000, referenceId: 'fund', nowMs: now });
  await grantCredit(db, { id: 'expired', userId: 'user-a', source: 'subscription', amountMicros: 100, expiresAtMs: now, referenceId: 'expired', nowMs: 0 });
  await grantCredit(db, { id: 'future', userId: 'user-a', source: 'subscription', amountMicros: 100, startsAtMs: 2_000, expiresAtMs: 3_000, referenceId: 'future', nowMs: now });
  await assert.rejects(hold('request-1', 1), code('INSUFFICIENT_CREDIT'));
  const wallet = await getWallet(db, 'user-a', now);
  assert.equal(wallet.availableMicros, 0);
  assert.equal(wallet.expiredMicros, 100);
  assert.equal(database.row('SELECT count(*) AS count FROM api_reservations').count, 0);
});

test('concurrent requests compete for the final wallet balance without overdrawing', async () => {
  await seed(100, 1_000);
  const results = await Promise.allSettled(Array.from({ length: 20 }, (_, i) => hold(`concurrent-${i}`, 30)));
  assert.equal(results.filter(r => r.status === 'fulfilled').length, 3);
  assert.equal((await getWallet(db, 'user-a', now)).availableMicros, 10);
  assert.equal((await getWallet(db, 'user-a', now)).reservedMicros, 90);
  assert.equal(database.row('SELECT reserved_micros AS held FROM provider_pools').held, 90);
  assert.equal(database.row('SELECT count(*) AS count FROM api_reservations').count, 3);
});

test('different users both reserve when the provider funds cover only one; the shortfall is one automatic line', async () => {
  await seed(1_000, 100);
  await grantCredit(db, { id: 'credit-b', userId: 'user-b', source: 'topup', amountMicros: 1_000, referenceId: 'credit-b', nowMs: now });
  const results = await Promise.allSettled([hold('request-a', 75), hold('request-b', 75, 'user-b')]);
  assert.equal(results.filter(r => r.status === 'fulfilled').length, 2);
  assert.deepEqual({ ...database.row('SELECT reserved_micros AS held, funded_micros AS funded FROM provider_pools') }, { held: 150, funded: 150 });
  assert.equal(database.row("SELECT SUM(amount_micros) AS amount FROM provider_funding WHERE reference_id LIKE 'auto:%'").amount, 50);
  assert.equal(database.row('SELECT SUM(reserved_micros) AS held FROM credit_grants').held, 150);
});

test('insufficient wallet credit rolls back allocations, command, reservation and provider changes', async () => {
  await seed(10, 1_000);
  const commandsBefore = database.row('SELECT count(*) AS count FROM ledger_commands').count;
  await assert.rejects(hold('too-large', 11), code('INSUFFICIENT_CREDIT'));
  assert.equal(database.row('SELECT count(*) AS count FROM ledger_commands').count, commandsBefore);
  assert.equal(database.row('SELECT count(*) AS count FROM reservation_allocations').count, 0);
  assert.equal(database.row('SELECT count(*) AS count FROM api_reservations').count, 0);
  assert.equal(database.row('SELECT reserved_micros AS held FROM provider_pools').held, 0);
  assert.equal((await getWallet(db, 'user-a', now)).availableMicros, 10);
});

test('a short or missing provider pool records an automatic funding line instead of refusing; a disabled pool still fails closed', async () => {
  await seed(1_000, 10);
  await hold('too-large', 11);
  assert.deepEqual({ ...database.row("SELECT funded_micros AS funded, reserved_micros AS held FROM provider_pools WHERE provider_id <> 'other'") }, { funded: 11, held: 11 });
  assert.deepEqual({ ...database.row("SELECT reference_id AS reference, amount_micros AS amount FROM provider_funding WHERE reference_id LIKE 'auto:%'") }, { reference: 'auto:too-large', amount: 1 });
  await reserve(db, { id: 'missing', requestKey: 'missing', userId: 'user-a', providerId: 'other', amountMicros: 1, nowMs: now });
  assert.deepEqual({ ...database.row("SELECT funded_micros AS funded, reserved_micros AS held, enabled FROM provider_pools WHERE provider_id = 'other'") }, { funded: 1, held: 1, enabled: 1 });
  const before = (await getWallet(db, 'user-a', now)).reservedMicros;
  database.sqlite.exec('UPDATE provider_pools SET enabled = 0');
  await assert.rejects(hold('disabled', 1), code('INSUFFICIENT_PROVIDER_FUNDS'));
  assert.equal((await getWallet(db, 'user-a', now)).reservedMicros, before);
});

test('reservation replay is idempotent and rejects changed request content or amount', async () => {
  await seed();
  const input = { id: 'original', userId: 'user-a', providerId: 'openai', amountMicros: 100, requestKey: 'same', requestHash: 'body-hash-a', nowMs: now };
  const first = await reserve(db, input);
  const replay = await reserve(db, { ...input, id: 'another-delivery', nowMs: now + 10 });
  assert.equal(first.idempotentReplay, false);
  assert.equal(replay.id, 'original');
  assert.equal(replay.idempotentReplay, true);
  await assert.rejects(reserve(db, { ...input, requestHash: 'body-hash-b' }), code('IDEMPOTENCY_CONFLICT'));
  await assert.rejects(reserve(db, { ...input, amountMicros: 200 }), code('IDEMPOTENCY_CONFLICT'));
  assert.equal((await getWallet(db, 'user-a', now)).reservedMicros, 100);
});

test('dispatch is claimed once and uncertain fees remain reserved indefinitely until resolved', async () => {
  await seed();
  await hold('request-1', 100);
  const claims = await Promise.all([claimReservation(db, 'request-1', now), claimReservation(db, 'request-1', now)]);
  assert.deepEqual(claims.sort(), [false, true]);
  await markUncertain(db, 'request-1');
  await markUncertain(db, 'request-1');
  assert.equal((await getReservation(db, 'request-1')).state, 'uncertain');
  assert.equal((await getWallet(db, 'user-a', now + 365 * 86400_000)).reservedMicros, 100);
  assert.equal(database.row('SELECT reserved_micros AS held FROM provider_pools').held, 100);
  assert.equal(await claimReservation(db, 'request-1'), false);
});

test('cross-period settlement consumes original grants and expired released remainder cannot be spent', async () => {
  await seed(30, 1_000);
  await grantCredit(db, { id: 'month', userId: 'user-a', source: 'subscription', amountMicros: 100, expiresAtMs: 2_000, referenceId: 'month', nowMs: now });
  await hold('request-1', 110);
  await markUncertain(db, 'request-1');
  await settle(db, { reservationId: 'request-1', actualMicros: 80, nowMs: 3_000 });
  const wallet = await getWallet(db, 'user-a', 3_000);
  assert.equal(wallet.availableMicros, 30);
  assert.equal(wallet.expiredMicros, 20);
  assert.equal(wallet.reservedMicros, 0);
  assert.equal(wallet.bySource.subscription.consumedMicros, 80);
  assert.equal(wallet.bySource.topup.consumedMicros, 0);
});

test('settlement is idempotent and a contradictory final cost is rejected', async () => {
  await seed();
  await hold('request-1', 100);
  await settle(db, { reservationId: 'request-1', actualMicros: 60, nowMs: now + 1 });
  const replay = await settle(db, { reservationId: 'request-1', actualMicros: 60, nowMs: now + 2 });
  assert.equal(replay.idempotentReplay, true);
  await assert.rejects(settle(db, { reservationId: 'request-1', actualMicros: 61 }), code('IDEMPOTENCY_CONFLICT'));
  await assert.rejects(releaseConfirmedUnused(db, 'request-1'), code('IDEMPOTENCY_CONFLICT'));
  assert.equal((await getWallet(db, 'user-a', now)).consumedMicros, 60);
  assert.equal(database.row("SELECT count(*) AS count FROM ledger_events WHERE kind = 'settled'").count, 1);
});

test('confirmed-unused release returns funds exactly once without reviving expired monthly credit', async () => {
  await seed(30, 1_000);
  await grantCredit(db, { id: 'month', userId: 'user-a', source: 'subscription', amountMicros: 100, expiresAtMs: 2_000, referenceId: 'month', nowMs: now });
  await hold('request-1', 110);
  await releaseConfirmedUnused(db, 'request-1', 3_000);
  await releaseConfirmedUnused(db, 'request-1', 4_000);
  assert.equal((await getReservation(db, 'request-1')).state, 'released');
  assert.equal((await getWallet(db, 'user-a', 4_000)).availableMicros, 30);
  assert.equal((await getWallet(db, 'user-a', 4_000)).expiredMicros, 100);
  assert.equal(database.row('SELECT reserved_micros AS held FROM provider_pools').held, 0);
});

test('injected mid-settlement failure rolls back both wallet and provider updates', async () => {
  await seed();
  await hold('request-1', 100);
  database.failAfterStatement = 4;
  await assert.rejects(settle(db, { reservationId: 'request-1', actualMicros: 60 }), code('STORAGE_FAILURE'));
  assert.equal((await getWallet(db, 'user-a', now)).reservedMicros, 100);
  assert.equal((await getWallet(db, 'user-a', now)).consumedMicros, 0);
  assert.equal(database.row('SELECT reserved_micros AS held FROM provider_pools').held, 100);
  assert.equal((await getReservation(db, 'request-1')).state, 'reserved');
  await settle(db, { reservationId: 'request-1', actualMicros: 60 });
  assert.equal((await getWallet(db, 'user-a', now)).consumedMicros, 60);
});

test('a committed reservation with a lost acknowledgement is reconciled by the same request key', async () => {
  await seed();
  database.failAfterCommit = true;
  await assert.rejects(hold('request-1', 100), code('STORAGE_FAILURE'));
  const recovered = await hold('request-1', 100);
  assert.equal(recovered.idempotentReplay, true);
  assert.equal((await getWallet(db, 'user-a', now)).reservedMicros, 100);
  assert.equal(database.row('SELECT count(*) AS count FROM api_reservations').count, 1);
});

test('over-limit reported costs do not silently debit extra credit or release uncertain funds', async () => {
  await seed();
  await hold('request-1', 100);
  await markUncertain(db, 'request-1');
  await assert.rejects(settle(db, { reservationId: 'request-1', actualMicros: 101 }), code('COST_EXCEEDS_RESERVATION'));
  assert.equal((await getReservation(db, 'request-1')).state, 'uncertain');
  assert.equal((await getWallet(db, 'user-a', now)).reservedMicros, 100);
  assert.equal((await getWallet(db, 'user-a', now)).consumedMicros, 0);
});

test('restriction prevents reserve and dispatch but does not erase money or prevent fee reconciliation', async () => {
  await seed();
  await hold('request-1', 100);
  database.sqlite.exec("UPDATE users SET status = 'restricted' WHERE id = 'user-a'");
  assert.equal(await claimReservation(db, 'request-1', now), false);
  await assert.rejects(hold('request-2', 100), code('ACCOUNT_RESTRICTED'));
  await settle(db, { reservationId: 'request-1', actualMicros: 60 });
  assert.equal((await getWallet(db, 'user-a', now)).availableMicros, 999_940);
});

test('unsafe amounts and expiry rules are rejected before any write', async () => {
  for (const invalid of [0, -1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1]) {
    await assert.rejects(hold('invalid', invalid), code('INVALID_AMOUNT'));
  }
  await assert.rejects(grantCredit(db, { id: 'bad', userId: 'user-a', source: 'topup', amountMicros: 1, expiresAtMs: 2_000, referenceId: 'bad', nowMs: now }), code('INVALID_INPUT'));
  await assert.rejects(grantCredit(db, { id: 'bad', userId: 'user-a', source: 'subscription', amountMicros: 1, referenceId: 'bad', nowMs: now }), code('INVALID_INPUT'));
  assert.equal(database.row('SELECT count(*) AS count FROM ledger_commands').count, 0);
});

test('AI restrictions are checked atomically on reserve and immediately before dispatch', async () => {
  await seed();
  await hold('before-restriction', 100);
  database.sqlite.prepare('INSERT INTO user_restrictions (id,user_id,scope,starts_at,ends_at) VALUES (?,?,?,?,?)')
    .run('restriction', 'user-a', 'ai', new Date(now).toISOString(), new Date(now + 1_000).toISOString());
  await assert.rejects(hold('during-restriction', 100), code('ACCOUNT_RESTRICTED'));
  assert.equal(await claimReservation(db, 'before-restriction', now), false);
  assert.equal(await claimReservation(db, 'before-restriction', now + 999), false);
  assert.equal(await claimReservation(db, 'before-restriction', now + 1_000), true);
  await settle(db, { reservationId: 'before-restriction', actualMicros: 25, nowMs: now + 1_000 });
  const wallet = await getWallet(db, 'user-a', now + 1_000);
  assert.equal(wallet.heldMicros, 0);
  assert.equal(wallet.topupMicros, 999_975);
  assert.equal(wallet.subscriptionMicros, 0);
  assert.equal(wallet.giftMicros, 0);
});

test('revoked, future and non-AI restrictions do not block historical topup spending', async () => {
  await seed();
  const insert = database.sqlite.prepare('INSERT INTO user_restrictions (id,user_id,scope,starts_at,ends_at,revoked_at) VALUES (?,?,?,?,?,?)');
  insert.run('revoked', 'user-a', 'ai', new Date(0).toISOString(), null, new Date(now).toISOString());
  insert.run('future', 'user-a', 'ai', new Date(now + 1).toISOString(), null, null);
  insert.run('topup', 'user-a', 'topup', new Date(0).toISOString(), null, null);
  await hold('allowed', 100);
  assert.equal(await claimReservation(db, 'allowed', now), true);
});
