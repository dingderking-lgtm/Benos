import assert from 'node:assert/strict';
import test from 'node:test';
import { createHmac,generateKeyPairSync } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { Hono } from 'hono';
import type { App } from '../src/lib/http';
import { AppError } from '../src/lib/errors';
import { encryptSecret,sha256 } from '../src/lib/crypto';
import { hostingRoutes,processPendingHostingJobs,reconcileHostingEntitlements,runProvisioningJob } from '../src/modules/hosting';
import { hostingManagementRoutes,reconcilePendingDomainChanges } from '../src/modules/hosting-management';
import { publishingRoutes } from '../src/modules/publishing';
import { anchorAnnualActivations,addHostingYear,annualRenewalPlan,AnnualMoveConflict,deferAnnualYearsBehindIdleSlot,deferralRequestStatement,hostingBillingSummary,runDeferralRequest } from '../src/modules/hosting-billing';
import { commerceRoutes } from '../src/modules/commerce';
import { createCheckout as createPaymentCheckout } from '../src/modules/payments';
import { handleAlipayWebhook } from '../src/modules/alipay';
import { canonicalAlipay,signAlipay,alipayTimestamp } from '../src/modules/alipay-protocol';
import { DEFAULT_CATALOG,createCatalogVersion,activateCatalog,BUILTIN_CATALOG_ID } from '../src/modules/billing-catalog';
import { freezeMembership,giftMembership as giveMembership,unfreezeMembership } from '../src/modules/memberships';
import { TestD1,testEnv } from './d1-helper';

/** P4.B contract tests: renewal quote, annual start rule, pay-first annual
 * creation, deterministic provisioning errors, discard of a release that never
 * reached the CMS, lease re-sync after fulfilment and the admin site list. */
const app=new Hono<App>();
app.use('*',async(c,next)=>{c.set('requestId','p4b-test');await next();});
app.route('/api/hosting',hostingRoutes);app.route('/api/hosting-management',hostingManagementRoutes);app.route('/api/publishing',publishingRoutes);app.route('/api/billing',commerceRoutes);
app.onError((error,c)=>c.json({ok:false,error:{code:error instanceof AppError?error.code:'UNEXPECTED',message:error instanceof AppError?error.message:''}},(error instanceof AppError?error.status:500) as 400));

const DAY=86400000,APP_ID='2026000000000001',SELLER_ID='2088000000000001';
const merchantKeys=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
const gatewayKeys=generateKeyPairSync('rsa',{modulusLength:2048,publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
const iso=(ms:number)=>new Date(ms).toISOString();
const input={name:'客户网站',domain:'shop.example.com',cmsAdminEmail:'cms@example.com',cmsAdminPassword:'contract-password-12345'};
// The test client confirms the explicit current CNY catalogue before purchase.
async function createCheckout(...args:Parameters<typeof createPaymentCheckout>){const [env,userId,payload,runtime]=args;const row=await env.DB.prepare('SELECT version_id FROM billing_catalog_active WHERE singleton=1').first<{version_id:string}>();return createPaymentCheckout(env,userId,{...payload,catalogVersionId:payload.catalogVersionId??row!.version_id},runtime);}
async function giftMembership(...args:Parameters<typeof giveMembership>){const [env,actorId,userId,payload]=args;const row=await env.DB.prepare('SELECT version_id FROM billing_catalog_active WHERE singleton=1').first<{version_id:string}>();return giveMembership(env,actorId,userId,{...payload,catalogVersionId:payload.catalogVersionId??row!.version_id});}
type Role='user'|'owner'|'admin'|'support';
async function json(response:Response){return await response.json() as any;}
async function signedCms(request:Request,status:number,value:unknown,secret:string){
 const body=JSON.stringify(value),timestamp=String(Math.floor(Date.now()/1000));
 return new Response(body,{status,headers:{'content-type':'application/json','X-Benos-Timestamp':timestamp,'X-Benos-Signature':createHmac('sha256',secret).update(['BENOS-CMS-V1-RESPONSE',request.headers.get('X-Benos-Nonce'),String(status),timestamp,await sha256(body)].join('\n')).digest('base64url')}});
}

async function fixture(){
 const db=new TestD1(),env=testEnv(db),user='usr_contract',now=iso(Date.now()),later=iso(Date.now()+DAY);
 const sessions=new Map<string,{token:string;csrf:string}>(),background:Promise<unknown>[]=[];
 for(const [id,role] of [[user,'user'],['usr_owner','owner'],['usr_admin','admin'],['usr_support','support']] as const){
  db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,'x',?,'active',?,?)").run(id,id+'@example.com',id,role,now,now);
  const token=(id+'-token-').padEnd(43,'t'),csrf='csrf-'+id;
  db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('ses_'+id,await sha256(token),id,csrf,now,later,'test');
  sessions.set(role,{token,csrf});
 }
 const ctx={waitUntil:(work:Promise<unknown>)=>{background.push(work);},passThroughOnException(){},props:{}} as unknown as ExecutionContext;
 const call=async(path:string,method='GET',data?:unknown,key='contract_key_0001',as:Role='user')=>{const s=sessions.get(as)!;
  if(data&&typeof data==='object'&&(path==='/api/billing/checkout'||(path==='/api/hosting/sites'&&(data as any).billing==='annual')))data={...data,catalogVersionId:(data as any).catalogVersionId??db.sqlite.prepare('SELECT version_id FROM billing_catalog_active WHERE singleton=1').get()!.version_id};
  return app.fetch(new Request(env.APP_ORIGIN+path,{method,headers:{origin:env.APP_ORIGIN,cookie:'benos_session='+s.token,'x-csrf-token':s.csrf,'content-type':'application/json','Idempotency-Key':key},body:data===undefined?undefined:JSON.stringify(data)}),env,ctx);};
 const subscribe=(o:{included?:number;startsMs?:number;endsMs?:number;state?:string;autoRenew?:number;source?:string;id?:string}={})=>db.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,state,auto_renew,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at) VALUES(?,?,'go',?,?,?,?,?,?,16250000,1,?,?)")
  .run(o.id??'sub_contract',user,o.source??'paid',iso(o.startsMs??Date.now()-10*DAY),iso(o.endsMs??Date.now()+20*DAY),o.state??'active',o.autoRenew??1,o.included??1,'grant_'+(o.id??'sub_contract'),now);
 const site=(id:string,domain:string,state='connected',createdMs=Date.now()-5*DAY)=>{db.sqlite.prepare('INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(id,user,'Site '+id,domain,'cms@example.com',state,iso(createdMs),iso(createdMs));return id;};
 const grant=(id:string,siteId:string,source:'annual'|'gift',startsMs:number,endsMs:number)=>db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES(?,?,?,?,?,?,'active',?)").run(id,user,siteId,source,iso(startsMs),iso(endsMs),now);
 // Local signed Alipay sandbox double; no external requests. The browser
 // is assumed to have opened each signed checkout, creating WAIT_BUYER_PAY.
 const catalog=await createCatalogVersion(env,'usr_owner',{catalog:{...structuredClone(DEFAULT_CATALOG),cnyPricing:{goPriceCents:2500,proPriceCents:10000,hostingAnnualPriceCents:3000,minimumTopupCents:500,topupCreditMicrosPerCnyCent:6500}},reason:'Explicit local CNY contract',requestKey:'hosting-cny-fixture-0001'});
 await activateCatalog(env,'usr_owner',catalog.id,{expectedVersionId:BUILTIN_CATALOG_ID,enabled:true,reason:'Local CNY contract activation',confirmedFutureOrdersOnly:true});
 let cms:((request:Request)=>Promise<Response>)|null=null;const closedTrades:string[]=[];
 class CheckoutStates extends Map<string,any>{get(orderId:string){let value=super.get(orderId);if(!value){const order=db.sqlite.prepare('SELECT * FROM orders WHERE id=?').get(orderId);if(!order)return undefined;value={status:'open',payment_status:'unpaid',trade_no:'202611130000000000'+String(this.size+1).padStart(6,'0')};this.set(orderId,value);}return value;}}
 const checkoutStates=new CheckoutStates();
 const payment=async()=>{const encrypted=await encryptSecret(JSON.stringify({privateKey:merchantKeys.privateKey,alipayPublicKey:gatewayKeys.publicKey}),env.ENCRYPTION_KEY,'pay');
  db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('pay','payment','Alipay','alipay',1,'active',?,?,'passed','usr_owner',?)").run(JSON.stringify({mode:'sandbox',appId:APP_ID,sellerId:SELLER_ID,keyMode:'public_key',signType:'RSA2',settlementCurrency:'CNY'}),encrypted,now);};
 const signed=async(method:string,value:unknown)=>{const content=JSON.stringify(value),signature=await signAlipay(content,gatewayKeys.privateKey);return new Response(`{"${method.replaceAll('.','_')}_response":${content},"sign":${JSON.stringify(signature)}}`,{headers:{'content-type':'application/json'}});};
 const original=globalThis.fetch;
 globalThis.fetch=async(value,init)=>{
  const request=value instanceof Request?value:new Request(value,init),url=new URL(request.url);
  if(url.origin==='https://openapi-sandbox.dl.alipaydev.com'){
   const params=new URLSearchParams(await request.text()),method=params.get('method')!,biz=JSON.parse(params.get('biz_content')!),order=db.sqlite.prepare('SELECT * FROM orders WHERE id=?').get(biz.out_trade_no),session=checkoutStates.get(biz.out_trade_no);
   if(!order||!session)return signed(method,{code:'40004',sub_code:'ACQ.TRADE_NOT_EXIST'});
   if(method==='alipay.trade.close'){if(session.payment_status==='paid')return signed(method,{code:'40004',sub_code:'ACQ.TRADE_HAS_SUCCESS'});closedTrades.push(biz.out_trade_no);session.status='expired';return signed(method,{code:'10000',out_trade_no:biz.out_trade_no,trade_no:session.trade_no});}
   if(method==='alipay.trade.query')return signed(method,{code:'10000',out_trade_no:biz.out_trade_no,trade_no:session.trade_no,trade_status:session.payment_status==='paid'?'TRADE_SUCCESS':session.status==='expired'?'TRADE_CLOSED':'WAIT_BUYER_PAY',total_amount:(Number(order.amount_cents)/100).toFixed(2),send_pay_date:alipayTimestamp(Date.now()),trans_currency:'CNY',settle_currency:'CNY'});
   throw new Error('Unexpected Alipay method '+method);
  }
  if(cms)return cms(request);
  throw new Error('Unexpected network request '+url.href);
 };
 const pay=async(orderId:string,eventId:string,waitUntil?:(work:Promise<unknown>)=>void)=>{
  const session=checkoutStates.get(orderId);session.status='complete';session.payment_status='paid';const order=db.sqlite.prepare('SELECT * FROM orders WHERE id=?').get(orderId)!;
  const params={app_id:APP_ID,seller_id:SELLER_ID,sign_type:'RSA2',charset:'utf-8',notify_id:'notify_'+eventId,out_trade_no:orderId,trade_no:session.trade_no,trade_status:'TRADE_SUCCESS',total_amount:(Number(order.amount_cents)/100).toFixed(2),gmt_payment:alipayTimestamp(Date.now())};
  const raw=new URLSearchParams({...params,sign:await signAlipay(canonicalAlipay(params,true),gatewayKeys.privateKey)}).toString();
  return handleAlipayWebhook(env,'pay',raw,waitUntil?{waitUntil}:{});
 };
 const close=()=>{globalThis.fetch=original;db.close();};
 return {db,env,user,call,subscribe,site,grant,payment,pay,checkoutStates,closedTrades,get checkoutOrders(){return db.sqlite.prepare("SELECT id FROM orders WHERE provider='alipay'").all().map(row=>row.id);},background,setCms:(handler:typeof cms)=>{cms=handler;},close};
}
const entitlements=(f:{db:TestD1},siteId:string)=>f.db.sqlite.prepare("SELECT order_id,starts_at,ends_at FROM hosting_entitlements WHERE site_id=? AND source='annual' ORDER BY starts_at").all(siteId) as {order_id:string;starts_at:string;ends_at:string}[];

test('renewal quote: CNY 30 from the catalogue, continues existing coverage and never overlaps it',async()=>{
 const f=await fixture();try{
  const membershipEnd=Date.now()+12*DAY,annualEnd=Date.now()+40*DAY,giftEnd=Date.now()+70*DAY;
  f.subscribe({state:'cancelled',autoRenew:0,endsMs:membershipEnd,included:1});
  const covered=f.site('site_'+'a'.repeat(32),'covered.example.com','connected',Date.now()-9*DAY);
  const annual=f.site('site_'+'b'.repeat(32),'annual.example.com','connected',Date.now()-8*DAY);f.grant('ann_b',annual,'annual',Date.now()-300*DAY,annualEnd);
  const gift=f.site('site_'+'c'.repeat(32),'gift.example.com','connected',Date.now()-7*DAY);f.grant('gift_c',gift,'gift',Date.now()-10*DAY,giftEnd);
  const suspended=f.site('site_'+'d'.repeat(32),'paused.example.com','suspended',Date.now()-6*DAY);
  const unopened=f.site('site_'+'e'.repeat(32),'new.example.com','pending',Date.now()-1*DAY);
  const quote=async(id:string)=>{const response=await f.call('/api/hosting/sites/'+id+'/renewal-quote');assert.equal(response.status,200);return (await json(response)).data;};
  let q=await quote(covered);
  assert.equal(q.amountCents,3000);assert.equal(q.currency,'CNY');assert.equal(q.basis,'after_membership');assert.equal(q.startsAt,iso(membershipEnd));assert.equal(q.endsAt,addHostingYear(iso(membershipEnd)));assert.equal(q.estimated,false);assert.equal(q.currentCoverageEndsAt,iso(membershipEnd));
  assert.equal(q.purchasable,false,'no payment configuration yet');
  q=await quote(annual);assert.equal(q.basis,'extend_annual');assert.equal(q.startsAt,iso(annualEnd));
  q=await quote(gift);assert.equal(q.basis,'after_gift');assert.equal(q.startsAt,iso(giftEnd));
  q=await quote(suspended);assert.equal(q.basis,'on_resume');assert.equal(q.estimated,true);assert.equal(q.currentCoverageEndsAt,null);
  q=await quote(unopened);assert.equal(q.basis,'on_activation');assert.equal(q.estimated,true);
  assert.ok(Math.abs(Date.parse(q.startsAt)-Date.now())<60000);assert.equal(q.endsAt,addHostingYear(q.startsAt));
  await f.payment();assert.equal((await quote(covered)).purchasable,true);
  // A renewing membership is not projected: the year still starts after the paid term, so it is never charged twice.
  f.db.sqlite.prepare("UPDATE subscriptions SET state='active',auto_renew=1").run();assert.equal((await quote(covered)).startsAt,iso(membershipEnd));
  assert.equal((await f.call('/api/hosting/sites/site_'+'9'.repeat(32)+'/renewal-quote')).status,404);
  f.db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES('usr_other','o@example.com','O','x','user','active',?,?)").run(iso(Date.now()),iso(Date.now()));
  f.db.sqlite.prepare("UPDATE sites SET user_id='usr_other' WHERE id=?").run(unopened);
  assert.equal((await f.call('/api/hosting/sites/'+unopened+'/renewal-quote')).status,404,'another customer site is invisible');
 }finally{f.close();}
});

test('renewing a site that is still on annual extends from its own annual end, even if a free slot would cover it later',async()=>{
 const f=await fixture();try{
  const annualEnd=Date.now()+40*DAY,membershipEnd=Date.now()+60*DAY;f.subscribe({included:3,endsMs:membershipEnd});
  const siteId=f.site('site_'+'f'.repeat(32),'own-annual.example.com');f.grant('ann_own',siteId,'annual',Date.now()-325*DAY,annualEnd);
  const q=(await json(await f.call('/api/hosting/sites/'+siteId+'/renewal-quote'))).data;
  assert.equal(q.basis,'extend_annual');assert.equal(q.startsAt,iso(annualEnd));assert.equal(q.currentCoverageEndsAt,iso(membershipEnd),'the summary shows the slot taking over, but the year continues the annual');
  // A year already scheduled after the membership is never overlapped.
  const member=f.site('site_'+'0'.repeat(32),'member-next.example.com');f.grant('ann_next',member,'annual',membershipEnd,membershipEnd+365*DAY);
  const next=(await json(await f.call('/api/hosting/sites/'+member+'/renewal-quote'))).data;assert.equal(next.basis,'extend_annual');assert.equal(next.startsAt,iso(membershipEnd+365*DAY));
 }finally{f.close();}
});

test('annual fulfilment starts when the ending membership coverage ends, matches the quote and is charged once',async()=>{
 const f=await fixture();try{
  await f.payment();const membershipEnd=Date.now()+15*DAY;f.subscribe({state:'cancelled',autoRenew:0,endsMs:membershipEnd});
  const siteId=f.site('site_'+'1'.repeat(32),'member.example.com');
  const quote=(await json(await f.call('/api/hosting/sites/'+siteId+'/renewal-quote'))).data;
  const order=await createCheckout(f.env,f.user,{kind:'hosting',siteId,requestKey:'renew-member-site'});
  assert.equal(order.checkoutState,'open');
  assert.equal((await f.pay(order.orderId,'evt_member_1')).state,'processed');
  assert.equal((await f.pay(order.orderId,'evt_member_2')).state,'processed');
  const rows=entitlements(f,siteId);assert.equal(rows.length,1);
  assert.equal(rows[0].starts_at,iso(membershipEnd));assert.equal(rows[0].starts_at,quote.startsAt);assert.equal(rows[0].ends_at,quote.endsAt);
  const stored=f.db.sqlite.prepare('SELECT state,paid_at FROM orders WHERE id=?').get(order.orderId)!;assert.equal(stored.state,'paid');
  assert.ok(Date.parse(String(stored.paid_at))<=Date.now(),'paid_at records the real payment time, not the future coverage start');
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM payment_fulfillments').get()!.n,1);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_annual_activations').get()!.n,0,'a covered site is a continuation, never re-anchored');
  // While membership still covers the site it keeps using the slot; afterwards annual takes over without a gap.
  const next=(await json(await f.call('/api/hosting/sites/'+siteId+'/renewal-quote'))).data;assert.equal(next.basis,'extend_annual');assert.equal(next.startsAt,rows[0].ends_at);
 }finally{f.close();}
});

test('annual renewal of an annual site extends from the old end; concurrent purchases chain without overlap',async()=>{
 const f=await fixture();try{
  await f.payment();const siteId=f.site('site_'+'2'.repeat(32),'chain.example.com');const end=Date.now()+30*DAY;f.grant('ann_chain',siteId,'annual',Date.now()-335*DAY,end);
  const a=await createCheckout(f.env,f.user,{kind:'hosting',siteId,requestKey:'chain-order-a'}),b=await createCheckout(f.env,f.user,{kind:'hosting',siteId,requestKey:'chain-order-b'});
  await Promise.all([f.pay(a.orderId,'evt_chain_a'),f.pay(b.orderId,'evt_chain_b')]);
  const rows=entitlements(f,siteId);assert.equal(rows.length,3);
  assert.equal(rows[1].starts_at,iso(end));assert.equal(rows[2].starts_at,rows[1].ends_at);assert.equal(rows[2].ends_at,addHostingYear(rows[1].ends_at));
 }finally{f.close();}
});

test('pay-first annual site: parked until paid, one order per create key, fulfilment starts provisioning and anchors the year at opening',async()=>{
 const f=await fixture();try{
  f.subscribe({included:1});await f.payment();
  // A free membership slot exists: the normal (membership) path is required, nothing is created or charged.
  const annualInput={...input,billing:'annual'};
  let response=await f.call('/api/hosting/sites','POST',annualInput,'annual_free_slot');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'HOSTING_SLOT_AVAILABLE');
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM sites').get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM orders').get()!.n,0);
  f.site('site_'+'3'.repeat(32),'slot.example.com');
  const list=(await json(await f.call('/api/hosting/sites'))).data.entitlement;assert.equal(list.canCreate,false);assert.equal(list.canCreateAnnual,true);assert.equal(list.annualPriceCents,3000);
  assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain:'www.shop.example.com',billing:'annual'},'annual_www')).status,400);
  response=await f.call('/api/hosting/sites','POST',annualInput,'annual_create_001');assert.equal(response.status,202);
  const created=(await json(response)).data;
  assert.equal(created.site.state,'pending');assert.equal(created.job.step,'awaiting_payment');assert.equal(created.job.state,'awaiting_input');assert.equal(created.job.errorCode,'HOSTING_PAYMENT_REQUIRED');assert.equal(created.job.awaitingPayment,true);
  assert.equal(created.payment.amountCents,3000);assert.equal(created.payment.checkoutState,'open');assert.match(created.payment.checkoutUrl,/^https:\/\/openapi-sandbox\.dl\.alipaydev\.com\/gateway\.do\?/);
  assert.ok(!JSON.stringify(created).includes(input.cmsAdminPassword));
  // Replays (double submit, reload) reuse the site, the job and the single order.
  const replay=(await json(await f.call('/api/hosting/sites','POST',annualInput,'annual_create_001'))).data;
  assert.equal(replay.site.id,created.site.id);assert.equal(replay.payment.orderId,created.payment.orderId);
  assert.equal((await f.call('/api/hosting/sites','POST',{...annualInput,name:'changed'},'annual_create_001')).status,409);
  assert.equal((await f.call('/api/hosting/sites','POST',input,'annual_create_001')).status,409,'the same key cannot switch to membership billing');
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM orders WHERE kind='hosting'").get()!.n,1);assert.equal(new Set(f.checkoutOrders).size,1);
  const detail=(await json(await f.call('/api/hosting/sites/'+created.site.id))).data;assert.equal(detail.pendingPayment.orderId,created.payment.orderId);assert.equal(detail.canManageHosting,false);
  // Unpaid: retry refuses, cron never runs the parked job.
  response=await f.call('/api/hosting/jobs/'+created.job.id+'/retry','POST',{});assert.equal(response.status,409);assert.equal((await json(response)).error.code,'HOSTING_PAYMENT_REQUIRED');
  await processPendingHostingJobs(f.env);assert.equal(f.db.sqlite.prepare('SELECT attempt_count FROM provisioning_jobs WHERE id=?').get(created.job.id)!.attempt_count,0);
  // Payment confirmed (duplicate callbacks): one year, one activation record, provisioning starts in the background.
  const work:Promise<unknown>[]=[];
  assert.equal((await f.pay(created.payment.orderId,'evt_first_site',p=>work.push(p))).state,'processed');
  assert.equal((await f.pay(created.payment.orderId,'evt_first_site_dup',p=>work.push(p))).state,'processed');
  assert.equal(work.length,1,'background provisioning is scheduled once');
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.provisioning_started'").get()!.n,1);
  await Promise.all(work);
  const job=f.db.sqlite.prepare('SELECT state,step,error_code,attempt_count FROM provisioning_jobs WHERE id=?').get(created.job.id)!;assert.equal(job.step,'configure_hosting');assert.equal(job.error_code,'HOSTING_NOT_CONFIGURED');assert.equal(job.attempt_count,1);
  const rows=entitlements(f,created.site.id);assert.equal(rows.length,1);
  const activation=f.db.sqlite.prepare('SELECT reason,state,provisional_ends_at FROM hosting_annual_activations').get()!;assert.equal(activation.reason,'create');assert.equal(activation.state,'pending');assert.equal(activation.provisional_ends_at,rows[0].ends_at);
  assert.equal((await json(await f.call('/api/hosting/sites/'+created.site.id))).data.canManageHosting,true);
  assert.equal((await f.call('/api/hosting/jobs/'+created.job.id+'/retry','POST',{})).status,202);
  // A second year bought while the site is still opening chains after the first.
  const second=await createCheckout(f.env,f.user,{kind:'hosting',siteId:created.site.id,requestKey:'second-year-early'});await f.pay(second.orderId,'evt_second_year');
  const chained=entitlements(f,created.site.id);assert.equal(chained.length,2);assert.equal(chained[1].starts_at,chained[0].ends_at);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_annual_activations').get()!.n,1);
  // A third year is paid but its grant has not completed yet (durable pending reservation).
  const third=await createCheckout(f.env,f.user,{kind:'hosting',siteId:created.site.id,requestKey:'third-year-reserved'}),reference='alipay:'+f.checkoutStates.get(third.orderId).trade_no;
  f.db.sqlite.prepare("INSERT INTO payment_fulfillments(id,order_id,provider_reference,snapshot_hash,starts_at,ends_at,created_at) VALUES(?,?,?,?,?,?,?)").run('ful_'+await sha256(reference),third.orderId,reference,await sha256(JSON.stringify([third.orderId,reference,null,null,3000,0])),chained[1].ends_at,addHostingYear(chained[1].ends_at),iso(Date.now()));
  // Not connected yet: nothing is anchored.
  assert.equal(await anchorAnnualActivations(f.env.DB,created.site.id,Date.now()+3*DAY),0);
  // The site opens three days later: the first year counts from opening and the chained year moves with it.
  f.db.sqlite.prepare("UPDATE sites SET state='connected' WHERE id=?").run(created.site.id);
  const openedAt=Date.now()+3*DAY;assert.equal(await anchorAnnualActivations(f.env.DB,created.site.id,openedAt),1);
  const anchored=entitlements(f,created.site.id);
  assert.equal(anchored[0].starts_at,chained[0].starts_at);assert.equal(anchored[0].ends_at,addHostingYear(iso(openedAt)));
  assert.equal(anchored[1].starts_at,anchored[0].ends_at);assert.equal(Date.parse(anchored[1].ends_at)-Date.parse(anchored[1].starts_at),Date.parse(chained[1].ends_at)-Date.parse(chained[1].starts_at));
  assert.equal(await anchorAnnualActivations(f.env.DB,created.site.id,openedAt+5*DAY),0,'anchoring is applied once');
  assert.deepEqual(entitlements(f,created.site.id),anchored);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.anchored'").get()!.n,1);
  // The reserved third year moved with the chain, so completing it leaves no overlap and no gap.
  await f.pay(third.orderId,'evt_third_year');
  const all=entitlements(f,created.site.id);assert.equal(all.length,3);assert.equal(all[2].starts_at,anchored[1].ends_at);assert.equal(all[2].ends_at,addHostingYear(anchored[1].ends_at));
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM orders WHERE kind='hosting' AND state='paid'").get()!.n,3);
 }finally{f.close();}
});

test('the provisioning job reaching connected anchors the paid year to the actual opening',async()=>{
 const f=await fixture();try{
  await f.payment();const secret='opening-site-signing-secret-0123456789ab';
  const created=(await json(await f.call('/api/hosting/sites','POST',{...input,billing:'annual'},'annual_open_001'))).data;
  await f.pay(created.payment.orderId,'evt_open_site');
  assert.equal(f.db.sqlite.prepare('SELECT step FROM provisioning_jobs WHERE id=?').get(created.job.id)!.step,'configure_hosting');
  // Model a CMS that the platform already installed; the job only has to prove HTTPS and the lease.
  f.db.sqlite.prepare("UPDATE provisioning_jobs SET result_json='{\"cmsInstalled\":true}' WHERE id=?").run(created.job.id);
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_open',?,'https://shop.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(created.site.id,await encryptSecret(secret,f.env.ENCRYPTION_KEY,created.site.id),iso(Date.now()),iso(Date.now()));
  f.setCms(async request=>{
   if(new URL(request.url).pathname==='/benos-health.php')return signedCms(request,200,{siteId:created.site.id,installed:true,database:'ready'},secret);
   const payload=await request.json() as any;delete payload.operation;return signedCms(request,200,{siteId:created.site.id,...payload},secret);
  });
  const provisional=entitlements(f,created.site.id)[0];
  await runProvisioningJob(f.env,f.user,created.job.id);
  const job=(await json(await f.call('/api/hosting/jobs/'+created.job.id))).data;assert.equal(job.state,'succeeded');
  assert.equal(f.db.sqlite.prepare('SELECT state FROM sites WHERE id=?').get(created.site.id)!.state,'connected');
  const activation=f.db.sqlite.prepare('SELECT state,activated_at FROM hosting_annual_activations').get()!;assert.equal(activation.state,'anchored');
  const anchored=entitlements(f,created.site.id)[0];assert.equal(anchored.ends_at,addHostingYear(String(activation.activated_at)));assert.ok(anchored.ends_at>=provisional.ends_at);
 }finally{f.close();}
});

test('pay-first annual creation without any membership, and refusals before any site is created',async()=>{
 const f=await fixture();try{
  let response=await f.call('/api/hosting/sites','POST',{...input,billing:'annual'},'no_payment_cfg');assert.equal(response.status,503);assert.equal((await json(response)).error.code,'PAYMENT_NOT_CONFIGURED');
  await f.payment();
  response=await f.call('/api/hosting/sites','POST',{...input,billing:'annual',catalogVersionId:'stale-catalog'},'stale_catalog');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'CATALOG_CHANGED');
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM sites').get()!.n,0);
  response=await f.call('/api/hosting/sites','POST',input,'membership_only');assert.equal(response.status,403);assert.equal((await json(response)).error.code,'MEMBERSHIP_REQUIRED');
  response=await f.call('/api/hosting/sites','POST',{...input,billing:'annual'},'no_member_annual');assert.equal(response.status,202);
  const data=(await json(response)).data;assert.equal(data.job.step,'awaiting_payment');assert.equal(data.payment.checkoutState,'open');
  f.db.sqlite.prepare("INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,actor_id,created_at) VALUES('rst_p4b',?,'publish','test freeze',?,?,?)").run(f.user,iso(Date.now()-1000),'usr_owner',iso(Date.now()));
  assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain:'second.example.com',billing:'annual'},'frozen_annual')).status,403);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM sites').get()!.n,1);
 }finally{f.close();}
});

test('a suspended site renewed in retention resumes right after payment and its year counts from the resumption',async()=>{
 const f=await fixture();try{
  await f.payment();const secret='suspended-site-signing-secret-0123456789';
  const siteId=f.site('site_'+'4'.repeat(32),'paused.example.com','suspended');f.grant('ann_old',siteId,'annual',Date.now()-400*DAY,Date.now()-35*DAY);
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_p4b',?,'https://paused.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(siteId,await encryptSecret(secret,f.env.ENCRYPTION_KEY,siteId),iso(Date.now()),iso(Date.now()));
  const connectionBefore=f.db.sqlite.prepare('SELECT id,site_id,origin,key_id,secret_ciphertext FROM site_connections WHERE site_id=?').get(siteId);
  const leases:any[]=[];f.setCms(async request=>{assert.equal(request.url,'https://paused.example.com/benos-connect.php','renewal uses the original CMS connection, never provider SSL, upload or onboarding');const payload=await request.json() as any;assert.equal(payload.operation,'entitlement','renewal never calls the installer');delete payload.operation;leases.push(payload);return signedCms(request,200,{siteId,...payload},secret);});
  assert.equal((await json(await f.call('/api/hosting/sites/'+siteId+'/renewal-quote'))).data.basis,'on_resume');
  const order=await createCheckout(f.env,f.user,{kind:'hosting',siteId,requestKey:'resume-renewal'}),work:Promise<unknown>[]=[];
  await f.pay(order.orderId,'evt_resume',p=>work.push(p));assert.equal(work.length,1,'a connected site gets an immediate lease re-sync');
  const provisional=entitlements(f,siteId).at(-1)!;
  await Promise.all(work);
  assert.equal(leases.length,1);assert.equal(leases[0].hostingActive,true);
  assert.equal(f.db.sqlite.prepare('SELECT state FROM sites WHERE id=?').get(siteId)!.state,'connected');
  assert.deepEqual(f.db.sqlite.prepare('SELECT id,site_id,origin,key_id,secret_ciphertext FROM site_connections WHERE site_id=?').get(siteId),connectionBefore);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_provider_intents WHERE site_id=?').get(siteId)!.n,0,'renewal creates no provider resource or SSL intent');
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_bootstrap_intents WHERE site_id=?').get(siteId)!.n,0,'renewal creates no installation intent');
  const activation=f.db.sqlite.prepare('SELECT reason,state,activated_at,anchored_ends_at FROM hosting_annual_activations').get()!;
  assert.equal(activation.reason,'resume');assert.equal(activation.state,'anchored');
  const current=entitlements(f,siteId).at(-1)!;assert.equal(current.ends_at,activation.anchored_ends_at);assert.ok(current.ends_at>=provisional.ends_at);assert.equal(current.ends_at,addHostingYear(String(activation.activated_at)));
 }finally{f.close();}
});

test('annual fulfilment after a gift, and for a live site without coverage, starts where the requirement says',async()=>{
 const f=await fixture();try{
  await f.payment();const giftEnd=Date.now()+20*DAY;
  const gifted=f.site('site_'+'a1'.repeat(16),'gifted.example.com');f.grant('gift_a1',gifted,'gift',Date.now()-10*DAY,giftEnd);
  let order=await createCheckout(f.env,f.user,{kind:'hosting',siteId:gifted,requestKey:'after-gift-order'});await f.pay(order.orderId,'evt_after_gift');
  let rows=entitlements(f,gifted);assert.equal(rows.length,1);assert.equal(rows[0].starts_at,iso(giftEnd));assert.equal(rows[0].ends_at,addHostingYear(iso(giftEnd)));
  // Coverage already ran out but the site has not been suspended yet: the year starts at the payment.
  const lapsed=f.site('site_'+'a2'.repeat(16),'lapsed.example.com');f.grant('ann_a2',lapsed,'annual',Date.now()-370*DAY,Date.now()-5*DAY);
  const quote=(await json(await f.call('/api/hosting/sites/'+lapsed+'/renewal-quote'))).data;assert.equal(quote.basis,'immediate');assert.equal(quote.estimated,false);
  order=await createCheckout(f.env,f.user,{kind:'hosting',siteId:lapsed,requestKey:'lapsed-site-order'});await f.pay(order.orderId,'evt_lapsed');
  rows=entitlements(f,lapsed);assert.equal(rows.length,2);assert.ok(Math.abs(Date.parse(rows[1].starts_at)-Date.now())<60000);assert.equal(rows[1].ends_at,addHostingYear(rows[1].starts_at));
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_annual_activations').get()!.n,0);
 }finally{f.close();}
});

test('pay-first site whose checkout expired: a new order for the same site starts it; maintenance starts a paid site whose follow-up never ran',async()=>{
 const f=await fixture();try{
  await f.payment();const annualInput={...input,billing:'annual'};
  const created=(await json(await f.call('/api/hosting/sites','POST',annualInput,'annual_expired_01'))).data;
  // The checkout page expired unpaid.
  const session=f.checkoutStates.get(created.payment.orderId);session.status='expired';
  const replay=(await json(await f.call('/api/hosting/sites','POST',annualInput,'annual_expired_01'))).data;
  assert.equal(replay.site.id,created.site.id);assert.equal(replay.payment.orderId,created.payment.orderId);assert.equal(replay.payment.checkoutState,'expired');assert.equal(replay.payment.checkoutUrl,null);assert.equal(replay.payment.state,'expired');
  let detail=(await json(await f.call('/api/hosting/sites/'+created.site.id))).data;assert.equal(detail.pendingPayment,null);assert.equal(detail.job.awaitingPayment,true);
  // The domain stays bound to the parked site: a second create for it is refused, never a second site.
  assert.equal((await f.call('/api/hosting/sites','POST',annualInput,'annual_expired_02')).status,409);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM sites').get()!.n,1);
  // The customer pays with an ordinary hosting order for that site, long after the temporary password expired.
  const order=await createCheckout(f.env,f.user,{kind:'hosting',siteId:created.site.id,requestKey:'parked-site-second-order'});assert.equal(order.checkoutState,'open');assert.notEqual(order.orderId,created.payment.orderId);
  detail=(await json(await f.call('/api/hosting/sites/'+created.site.id))).data;assert.equal(detail.pendingPayment.orderId,order.orderId);
  f.db.sqlite.prepare('UPDATE provisioning_jobs SET secret_expires_at=? WHERE id=?').run(iso(Date.now()-60000),created.job.id);
  await f.pay(order.orderId,'evt_parked_second');
  let job=(await json(await f.call('/api/hosting/jobs/'+created.job.id))).data;
  assert.equal(job.awaitingPayment,false);assert.equal(job.state,'pending');assert.equal(job.step,'configure_hosting');
  await processPendingHostingJobs(f.env);
  job=(await json(await f.call('/api/hosting/jobs/'+created.job.id))).data;assert.equal(job.attemptCount,1);assert.equal(job.requiresPassword,true,'the expired password was purged; the same job asks for it again');
  assert.equal(f.db.sqlite.prepare('SELECT secret_ciphertext FROM provisioning_jobs WHERE id=?').get(created.job.id)!.secret_ciphertext,null);
  assert.equal(entitlements(f,created.site.id).length,1);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM orders WHERE state='paid'").get()!.n,1);
  // Safety net: paid, but the follow-up that starts provisioning never ran.
  const second=(await json(await f.call('/api/hosting/sites','POST',{...annualInput,domain:'second.example.com'},'annual_selfheal_1'))).data,unpaid=(await json(await f.call('/api/hosting/sites','POST',{...annualInput,domain:'third.example.com'},'annual_selfheal_2'))).data;
  f.grant('ann_selfheal',second.site.id,'annual',Date.now()-1000,Date.now()+365*DAY);
  await processPendingHostingJobs(f.env);await processPendingHostingJobs(f.env);
  const healed=f.db.sqlite.prepare('SELECT step,attempt_count FROM provisioning_jobs WHERE id=?').get(second.job.id)!;assert.equal(healed.step,'configure_hosting');assert.ok(Number(healed.attempt_count)>=1);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.provisioning_started' AND entity_id=?").get(second.site.id)!.n,1);
  const parked=f.db.sqlite.prepare('SELECT state,step,attempt_count FROM provisioning_jobs WHERE id=?').get(unpaid.job.id)!;assert.equal(parked.step,'awaiting_payment');assert.equal(parked.attempt_count,0,'an unpaid site is never started');
 }finally{f.close();}
});

test('a suspended site renewed without a background hook recovers on the next maintenance pass and is anchored once',async()=>{
 const f=await fixture();try{
  await f.payment();const secret='maintenance-resume-signing-secret-012345';
  const siteId=f.site('site_'+'a3'.repeat(16),'later.example.com','suspended');f.grant('ann_a3',siteId,'annual',Date.now()-400*DAY,Date.now()-35*DAY);
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_a3',?,'https://later.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(siteId,await encryptSecret(secret,f.env.ENCRYPTION_KEY,siteId),iso(Date.now()),iso(Date.now()));
  const leases:any[]=[];f.setCms(async request=>{const payload=await request.json() as any;delete payload.operation;leases.push(payload);return signedCms(request,200,{siteId,...payload},secret);});
  const order=await createCheckout(f.env,f.user,{kind:'hosting',siteId,requestKey:'resume-by-maintenance'});
  await f.pay(order.orderId,'evt_resume_cron');await f.pay(order.orderId,'evt_resume_cron_dup');
  assert.equal(leases.length,0);assert.equal(f.db.sqlite.prepare('SELECT state FROM sites WHERE id=?').get(siteId)!.state,'suspended');
  assert.equal(f.db.sqlite.prepare('SELECT state FROM hosting_annual_activations').get()!.state,'pending');
  assert.deepEqual(await reconcileHostingEntitlements(f.env),{synced:1,failed:0});
  assert.equal(leases.at(-1).hostingActive,true,'the latest entitlement decides: the renewed site is not suspended again');
  assert.equal(f.db.sqlite.prepare('SELECT state FROM sites WHERE id=?').get(siteId)!.state,'connected');
  const anchored=entitlements(f,siteId).at(-1)!,activation=f.db.sqlite.prepare('SELECT state,activated_at FROM hosting_annual_activations').get()!;
  assert.equal(activation.state,'anchored');assert.equal(anchored.ends_at,addHostingYear(String(activation.activated_at)));
  assert.equal(await anchorAnnualActivations(f.env.DB,siteId,Date.now()+9*DAY),0);assert.deepEqual(entitlements(f,siteId).at(-1),anchored);
  assert.equal(entitlements(f,siteId).length,2);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM payment_fulfillments').get()!.n,1);
 }finally{f.close();}
});

async function poolFixture(f:Awaited<ReturnType<typeof fixture>>){
 f.db.sqlite.exec(`CREATE TRIGGER p4b_pool AFTER INSERT ON integration_configs WHEN NEW.kind='hosting' AND NEW.status='active'
  BEGIN INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,state,priority,max_sites,max_databases,observed_at,created_at,updated_at)
  VALUES('pool_'||NEW.id,'Contract fixture','u12345678',100,NEW.id,'accepting',1,10,10,NEW.created_at,NEW.created_at,NEW.created_at); END;`);
 const config={adapter:'hostinger-hpanel',deploymentMode:'hostinger-tus-bootstrap',hostingOrderId:100,accountUsername:'u12345678',cmsReleaseObjectKey:'private/cms-releases/x.zip',cmsReleaseSha256:'a'.repeat(64),cmsReleaseSize:6};
 f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('cfg_p4b','hosting','tus','benos-bridge',1,'active',?,?,'passed','usr_owner',?)").run(JSON.stringify(config),await encryptSecret(JSON.stringify({hostingerApiToken:'test-token-long-enough'}),f.env.ENCRYPTION_KEY,'cfg_p4b'),iso(Date.now()));
}
function legacyJob(f:Awaited<ReturnType<typeof fixture>>,siteId:string,jobId:string){
 f.db.sqlite.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,state,step,idempotency_key,payload_hash,created_at,updated_at) VALUES(?,?,?,'create','pending','configure_hosting',?,?,?,?)").run(jobId,siteId,f.user,'legacy_'+jobId.slice(4,20),'hash',iso(Date.now()),iso(Date.now()));
}

test('deterministic provisioning errors stop with neutral codes and are not retried by the scheduler',async()=>{
 const f=await fixture();try{
  f.subscribe({included:2});await poolFixture(f);f.setCms(async()=>{throw new Error('no network expected');});
  assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain:'www.shop.example.com'},'www_create')).status,400,'www is refused before anything is created');
  // A www job created before the create-time check existed.
  const www=f.site('site_'+'5'.repeat(32),'www.legacy.example.com','pending',Date.now()-2*DAY),wwwJob='job_'+'5'.repeat(32);legacyJob(f,www,wwwJob);
  await runProvisioningJob(f.env,f.user,wwwJob);
  let job=(await json(await f.call('/api/hosting/jobs/'+wwwJob))).data;
  assert.equal(job.state,'failed');assert.equal(job.step,'failed');assert.equal(job.errorCode,'DOMAIN_UNSUPPORTED');
  assert.doesNotMatch(JSON.stringify(job),/hostinger|hpanel|u\d{6,}|TUS_|BOOTSTRAP_/i);
  assert.equal(JSON.parse(String(f.db.sqlite.prepare('SELECT result_json FROM provisioning_jobs WHERE id=?').get(wwwJob)!.result_json)).internalErrorCode,'HOSTINGER_DOMAIN_UNSUPPORTED');
  // Changed provider scope for a recorded intent needs the platform team, not a minute-by-minute retry.
  const ops=f.site('site_'+'6'.repeat(32),'ops.example.com','pending',Date.now()-1*DAY),opsJob='job_'+'6'.repeat(32);legacyJob(f,ops,opsJob);
  f.db.sqlite.prepare("INSERT INTO hosting_provider_intents(job_id,config_version_id,site_id,domain,account_username,hosting_order_id,database_name,database_user,database_secret_ciphertext,created_at,updated_at) VALUES(?,'cfg_p4b',?,'moved.example.com','u12345678',100,'u12345678_bx','u12345678_bx','v1.x',?,?)").run(opsJob,ops,iso(Date.now()),iso(Date.now()));
  await runProvisioningJob(f.env,f.user,opsJob);
  job=(await json(await f.call('/api/hosting/jobs/'+opsJob))).data;assert.equal(job.state,'awaiting_input');assert.equal(job.step,'operator_action');assert.equal(job.errorCode,'HOSTING_OPERATOR_REVIEW');
  assert.doesNotMatch(JSON.stringify(job),/hostinger|TUS_|BOOTSTRAP_/i);
  const attempts=()=>f.db.sqlite.prepare('SELECT id,attempt_count FROM provisioning_jobs ORDER BY id').all().map(row=>row.attempt_count);
  const before=attempts();await processPendingHostingJobs(f.env);assert.deepEqual(attempts(),before);
 }finally{f.close();}
});

test('discard frees the open-release slot when preparation failed before the CMS kept any record',async()=>{
 const f=await fixture();try{
  const project='prj_'+'7'.repeat(32),version='ver_'+'7'.repeat(32),siteId='site_'+'7'.repeat(32),secret='publication-contract-secret-0123456789ab',now=iso(Date.now());
  f.db.sqlite.prepare("INSERT INTO projects(id,user_id,name,status,current_version_id,created_at,updated_at) VALUES(?,?,'Website','draft',?,?,?)").run(project,f.user,version,now,now);
  const manifest=readFileSync(resolve('..','模板制作规范','manifest示例.json'),'utf8').replace(/^﻿/,'');
  f.db.sqlite.prepare("INSERT INTO design_versions(id,project_id,version,source,manifest_json,content_hash,created_by,created_at) VALUES(?,?,1,'manual',?,?,?,?)").run(version,project,manifest,await sha256(manifest),f.user,now);
  f.site(siteId,'publish.example.com');f.db.sqlite.prepare('UPDATE sites SET project_id=? WHERE id=?').run(project,siteId);f.grant('ann_pub',siteId,'annual',Date.now()-DAY,Date.now()+100*DAY);
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_pub',?,'https://publish.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(siteId,await encryptSecret(secret,f.env.ENCRYPTION_KEY,siteId),now,now);
  let reject=true;const records=new Map<string,any>(),ops:string[]=[];
  f.setCms(async request=>{const body=await request.json() as any;ops.push(body.operation);const remote=records.get(body.releaseId);
   if(body.operation==='status')return signedCms(request,remote?200:404,remote||{error:{code:'RELEASE_NOT_FOUND'}},secret);
   if(body.operation==='prepare'&&reject)return signedCms(request,409,{error:{code:'TEMPLATE_INVALID'}},secret);
   if(body.operation==='prepare'){const record={id:body.releaseId,projectId:project,versionId:version,state:'prepared',reviewHash:'d'.repeat(64),summary:{createPages:1,updatePages:0,preserveArticles:0,preserveDrafts:true,replaceGlobalTheme:false,removePages:0}};records.set(body.releaseId,record);return signedCms(request,200,record,secret);}
   throw new Error('unexpected '+body.operation);});
  const first=(await json(await f.call('/api/publishing/sites/'+siteId+'/prepare','POST',{versionId:version},'publish_failed_1'))).data.release;
  assert.equal(first.state,'uncertain');assert.equal(first.reviewHash,null);
  assert.equal((await f.call('/api/publishing/sites/'+siteId+'/prepare','POST',{versionId:version},'publish_failed_2')).status,409,'the failed preparation still holds the slot');
  const reconciled=(await json(await f.call('/api/publishing/releases/'+first.id+'/reconcile','POST',{}))).data.release;assert.equal(reconciled.state,'uncertain');
  ops.length=0;
  const discarded=(await json(await f.call('/api/publishing/releases/'+first.id+'/discard','POST',{}))).data.release;
  assert.equal(discarded.state,'failed');assert.equal(discarded.errorCode,'PUBLICATION_DISCARDED');assert.deepEqual(ops,['status'],'discard only reads the remote status');
  assert.equal((await json(await f.call('/api/publishing/releases/'+first.id+'/discard','POST',{}))).data.release.state,'failed','repeat discard is idempotent');
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='publication.discard'").get()!.n,2);
  reject=false;
  const second=(await json(await f.call('/api/publishing/sites/'+siteId+'/prepare','POST',{versionId:version},'publish_failed_3'))).data.release;
  assert.equal(second.state,'prepared');assert.notEqual(second.id,first.id);
 }finally{f.close();}
});

test('hosted-site list: admin reads (read-only), owner operates, other roles are refused',async()=>{
 const f=await fixture();try{
  const siteId=f.site('site_'+'8'.repeat(32),'list.example.com');
  for(const role of ['user','support'] as const)assert.equal((await f.call('/api/hosting-management/sites','GET',undefined,'k',role)).status,403);
  const admin=await f.call('/api/hosting-management/sites','GET',undefined,'k','admin');assert.equal(admin.status,200);
  const body=(await json(admin)).data;assert.equal(body.items.length,1);assert.equal(body.items[0].id,siteId);assert.equal(body.canOperate,false);
  assert.equal((await json(await f.call('/api/hosting-management/sites','GET',undefined,'k','owner'))).data.canOperate,true);
  const detail=await f.call('/api/hosting-management/sites/'+siteId,'GET',undefined,'k','admin');assert.equal(detail.status,200);assert.equal((await json(detail)).data.canOperate,false);
  assert.equal((await f.call('/api/hosting-management/sites/'+siteId,'GET',undefined,'k','support')).status,404);
  assert.equal((await f.call('/api/hosting-management/sites/'+siteId+'/pause','POST',{reason:'not allowed',requestKey:'admin_pause_001'},'k','admin')).status,403);
  assert.equal((await f.call('/api/hosting-management/sites/'+siteId+'/domain-changes','POST',{domain:'new-list.example.com',reason:'客户在控制台更换域名',requestKey:'admin_domain_01'},'k','admin')).status,404,'admin read access never extends to customer mutations');
 }finally{f.close();}
});

/* ---- Review fixes (REVIEW.md M1–M3 and minors) ---- */
const count=(f:{db:TestD1},sql:string,...args:(string|number)[])=>Number(f.db.sqlite.prepare(sql).get(...args)!.n);

test('M1: an unpaid pay-first site never takes a membership slot; a plan bought later starts it through retry and closes its $30 checkout',async()=>{
 const f=await fixture();try{
  await f.payment();
  const parked=(await json(await f.call('/api/hosting/sites','POST',{...input,billing:'annual'},'slot_parked_01'))).data;
  assert.equal((await json(await f.call('/api/hosting/sites'))).data.entitlement.membershipSitesUsed,0);
  f.subscribe({included:2});
  let entitlement=(await json(await f.call('/api/hosting/sites'))).data.entitlement;
  assert.equal(entitlement.membershipSitesUsed,0,'the unpaid site does not use a slot');assert.equal(entitlement.canCreate,true);assert.equal(entitlement.canCreateAnnual,false);
  // The plan's slot is usable for an ordinary site (previously 409 SITE_LIMIT_REACHED).
  assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain:'member-site.example.com'},'slot_member_01')).status,202);
  // The unpaid site takes the remaining slot through retry: started for free, audited, its open checkout closed at the provider.
  const response=await f.call('/api/hosting/jobs/'+parked.job.id+'/retry','POST',{});assert.equal(response.status,202);
  const job=(await json(response)).data.job;assert.equal(job.awaitingPayment,false);assert.notEqual(job.step,'awaiting_payment');
  assert.deepEqual(f.closedTrades,[parked.payment.orderId]);assert.equal(f.db.sqlite.prepare('SELECT state FROM orders WHERE id=?').get(parked.payment.orderId)!.state,'expired');
  const audit=f.db.sqlite.prepare("SELECT actor_id,details_json FROM audit_logs WHERE action='hosting.annual.provisioning_started'").all();
  assert.equal(audit.length,1);assert.equal(audit[0].actor_id,f.user);assert.deepEqual(JSON.parse(String(audit[0].details_json)),{jobId:parked.job.id,via:'retry',coveredBy:'membership'});
  entitlement=(await json(await f.call('/api/hosting/sites'))).data.entitlement;assert.equal(entitlement.membershipSitesUsed,2);assert.equal(entitlement.canCreate,false);assert.equal(entitlement.canCreateAnnual,true);
  // With every slot used, another unpaid site cannot start without payment, and its quote is a pay-first year.
  const extra=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'extra.example.com',billing:'annual'},'slot_parked_02'))).data;
  const refused=await f.call('/api/hosting/jobs/'+extra.job.id+'/retry','POST',{});assert.equal(refused.status,409);assert.equal((await json(refused)).error.code,'HOSTING_PAYMENT_REQUIRED');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.provisioning_started'"),1);
  assert.equal((await json(await f.call('/api/hosting/sites/'+extra.site.id+'/renewal-quote'))).data.basis,'on_activation');
 }finally{f.close();}
});

test('M1: an unpaid site releases its domain and project on customer cancel or after its checkout closed; a late payment goes to review; per-account cap',async()=>{
 const f=await fixture();try{
  await f.payment();const now=iso(Date.now()),project='prj_'+'c'.repeat(32),annual={...input,billing:'annual'};
  f.db.sqlite.prepare("INSERT INTO projects(id,user_id,name,status,created_at,updated_at) VALUES(?,?,'Brand','draft',?,?)").run(project,f.user,now,now);
  const squat=(await json(await f.call('/api/hosting/sites','POST',{...annual,domain:'victim-brand.com',projectId:project},'squat_create_01'))).data;
  assert.equal(squat.job.step,'awaiting_payment');
  f.db.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,state,auto_renew,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at) VALUES('sub_other','usr_admin','go','paid',?,?,'active',1,1,16250000,1,'grant_sub_other',?)").run(iso(Date.now()-DAY),iso(Date.now()+20*DAY),now);
  // (A paying member of another account now displaces an unpaid claim: see the S1 test.) The same project under a corrected domain is blocked.
  let response=await f.call('/api/hosting/sites','POST',{...annual,domain:'brand-fixed.com',projectId:project},'squat_fix_01');assert.equal(response.status,409);
  // Cancel: the open checkout is expired at the provider; site, job and domain claim are removed in one audited batch.
  response=await f.call('/api/hosting/jobs/'+squat.job.id+'/cancel','POST',{});assert.equal(response.status,200);assert.equal((await json(response)).data.cancelled,true);
  assert.deepEqual(f.closedTrades,[squat.payment.orderId]);assert.equal(f.db.sqlite.prepare('SELECT state FROM orders WHERE id=?').get(squat.payment.orderId)!.state,'expired');
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',squat.site.id),0);assert.equal(count(f,'SELECT COUNT(*) n FROM provisioning_jobs WHERE id=?',squat.job.id),0);
  assert.equal(count(f,"SELECT COUNT(*) n FROM hosting_domains WHERE domain='victim-brand.com'"),0);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.unpaid_site_released' AND actor_id=?",f.user),1);
  assert.equal((await f.call('/api/hosting/jobs/'+squat.job.id+'/cancel','POST',{})).status,404);
  // The domain and the project are free again.
  assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain:'victim-brand.com'},'other_create_02','admin')).status,202);
  const fixed=(await json(await f.call('/api/hosting/sites','POST',{...annual,domain:'brand-fixed.com',projectId:project},'squat_fix_02'))).data;assert.equal(fixed.site.projectId,project);
  // A payment that still completes for the released site is held for review, never granted to a missing site.
  assert.equal((await f.pay(squat.payment.orderId,'evt_released_site')).state,'review');
  assert.equal(f.db.sqlite.prepare('SELECT state FROM orders WHERE id=?').get(squat.payment.orderId)!.state,'review');assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_entitlements'),0);
  // A paid site cannot be cancelled.
  const paidSite=(await json(await f.call('/api/hosting/sites','POST',{...annual,domain:'paid-first.example.com'},'paid_create_01'))).data;await f.pay(paidSite.payment.orderId,'evt_paid_first');
  assert.equal((await json(await f.call('/api/hosting/jobs/'+paidSite.job.id+'/cancel','POST',{}))).error.code,'HOSTING_CANCEL_UNAVAILABLE');
  // Expiry: maintenance releases an unpaid site 24 hours after creation once every checkout has closed; an open order keeps it.
  const late=(await json(await f.call('/api/hosting/sites','POST',{...annual,domain:'later.example.com'},'expire_create_01'))).data;
  f.db.sqlite.prepare('UPDATE provisioning_jobs SET created_at=? WHERE id=?').run(iso(Date.now()-25*3600000),late.job.id);
  assert.equal((await processPendingHostingJobs(f.env)).released,0);assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',late.site.id),1,'a payable order keeps the site');
  f.db.sqlite.prepare('UPDATE orders SET expires_at=? WHERE id=?').run(iso(Date.now()-60000),late.payment.orderId);f.checkoutStates.get(late.payment.orderId).status='expired';
  assert.equal((await processPendingHostingJobs(f.env)).released,1);
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',late.site.id),0);assert.equal(f.db.sqlite.prepare('SELECT state FROM orders WHERE id=?').get(late.payment.orderId)!.state,'expired');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.unpaid_site_released' AND actor_id IS NULL"),1);
  // Cap: at most three unpaid sites per account (brand-fixed is one).
  for(const domain of ['cap-1.example.com','cap-2.example.com'])assert.equal((await f.call('/api/hosting/sites','POST',{...annual,domain},'cap_'+domain.slice(0,5)+'_key')).status,202);
  response=await f.call('/api/hosting/sites','POST',{...annual,domain:'cap-3.example.com'},'cap_over_key_01');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'HOSTING_UNPAID_SITE_LIMIT');
  assert.equal(count(f,"SELECT COUNT(*) n FROM sites WHERE domain='cap-3.example.com'"),0);
 }finally{f.close();}
});

test('M2: a discarded release stays final when its CMS record lands late; reconcile closes it at the CMS, commit is refused, a conflict answers 409 and frees the lease',async()=>{
 const f=await fixture();try{
  const project='prj_'+'d'.repeat(32),version='ver_'+'d'.repeat(32),siteId='site_'+'d'.repeat(32),secret='publication-late-record-secret-012345678',now=iso(Date.now());
  f.db.sqlite.prepare("INSERT INTO projects(id,user_id,name,status,current_version_id,created_at,updated_at) VALUES(?,?,'Website','draft',?,?,?)").run(project,f.user,version,now,now);
  const manifest=readFileSync(resolve('..','模板制作规范','manifest示例.json'),'utf8').replace(/^﻿/,'');
  f.db.sqlite.prepare("INSERT INTO design_versions(id,project_id,version,source,manifest_json,content_hash,created_by,created_at) VALUES(?,?,1,'manual',?,?,?,?)").run(version,project,manifest,await sha256(manifest),f.user,now);
  f.site(siteId,'late.example.com');f.db.sqlite.prepare('UPDATE sites SET project_id=? WHERE id=?').run(project,siteId);f.grant('ann_late',siteId,'annual',Date.now()-DAY,Date.now()+100*DAY);
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_late',?,'https://late.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(siteId,await encryptSecret(secret,f.env.ENCRYPTION_KEY,siteId),now,now);
  const records=new Map<string,any>(),ops:string[]=[];let timeout=true;
  const prepared=(releaseId:string)=>({id:releaseId,projectId:project,versionId:version,state:'prepared',reviewHash:'e'.repeat(64),summary:{createPages:1,updatePages:0,preserveArticles:0,preserveDrafts:true,replaceGlobalTheme:false,removePages:0}});
  f.setCms(async request=>{const body=await request.json() as any,remote=records.get(body.releaseId);ops.push(body.operation+':'+body.releaseId);
   if(body.operation==='status')return signedCms(request,remote?200:404,remote||{error:{code:'RELEASE_NOT_FOUND'}},secret);
   if(body.operation==='prepare'&&timeout)throw new Error('CMS did not answer in time');
   if(body.operation==='prepare'){records.set(body.releaseId,prepared(body.releaseId));return signedCms(request,200,records.get(body.releaseId),secret);}
   if(body.operation==='discard'){if(remote?.state!=='prepared')return signedCms(request,409,{error:{code:'DISCARD_UNAVAILABLE'}},secret);remote.state='failed';remote.errorCode='PUBLICATION_DISCARDED';return signedCms(request,200,remote,secret);}
   if(body.operation==='commit'){remote.state='published';return signedCms(request,200,remote,secret);}
   throw new Error('unexpected '+body.operation);});
  // Prepare times out (outcome unknown), the customer discards it.
  const first=(await json(await f.call('/api/publishing/sites/'+siteId+'/prepare','POST',{versionId:version},'publish_late_1'))).data.release;
  assert.equal(first.state,'uncertain');assert.equal(first.errorCode,'CMS_RELEASE_UNCERTAIN');
  assert.equal((await json(await f.call('/api/publishing/releases/'+first.id+'/discard','POST',{}))).data.release.errorCode,'PUBLICATION_DISCARDED');
  // The CMS finishes the original prepare late.
  records.set(first.id,prepared(first.id));ops.length=0;
  // Replaying the original prepare request never re-sends it.
  const replay=(await json(await f.call('/api/publishing/sites/'+siteId+'/prepare','POST',{versionId:version},'publish_late_1'))).data.release;
  assert.equal(replay.state,'failed');assert.deepEqual(ops,[]);
  // A new release can be prepared (the slot is free).
  timeout=false;const second=(await json(await f.call('/api/publishing/sites/'+siteId+'/prepare','POST',{versionId:version},'publish_late_2'))).data.release;assert.equal(second.state,'prepared');
  // Reconcile of the discarded release: the late record is discarded at the CMS too; the row stays discarded (no 500, no reopening).
  ops.length=0;let response=await f.call('/api/publishing/releases/'+first.id+'/reconcile','POST',{});assert.equal(response.status,202);
  let release=(await json(response)).data.release;assert.equal(release.state,'failed');assert.equal(release.errorCode,'PUBLICATION_DISCARDED');
  assert.deepEqual(ops,['status:'+first.id,'discard:'+first.id]);assert.equal(records.get(first.id).state,'failed');
  assert.equal(f.db.sqlite.prepare('SELECT lease_until FROM publication_releases WHERE id=?').get(first.id)!.lease_until,null);
  // Commit is refused even with the CMS review hash; nothing is published.
  response=await f.call('/api/publishing/releases/'+first.id+'/commit','POST',{reviewHash:'e'.repeat(64)});assert.equal(response.status,409);assert.equal((await json(response)).error.code,'PUBLICATION_DISCARDED');
  assert.notEqual(records.get(first.id).state,'published');assert.equal(f.db.sqlite.prepare('SELECT published_version_id FROM projects WHERE id=?').get(project)!.published_version_id,null);
  // A release that would reopen while another is open answers 409 and releases its lease instead of a 500 with a stuck lease.
  const third='rel_'+'3'.repeat(32);
  f.db.sqlite.prepare("INSERT INTO publication_releases(id,site_id,user_id,project_id,version_id,idempotency_key,payload_hash,state,error_code,created_at,updated_at) VALUES(?,?,?,?,?,'publish_late_3','h','failed','CMS_RELEASE_REJECTED',?,?)").run(third,siteId,f.user,project,version,now,now);
  records.set(third,prepared(third));
  response=await f.call('/api/publishing/releases/'+third+'/reconcile','POST',{});assert.equal(response.status,409);assert.equal((await json(response)).error.code,'PUBLICATION_IN_PROGRESS');
  const stored=f.db.sqlite.prepare('SELECT state,lease_until FROM publication_releases WHERE id=?').get(third)!;assert.equal(stored.state,'failed');assert.equal(stored.lease_until,null);
  release=(await json(await f.call('/api/publishing/releases/'+second.id))).data.release;assert.equal(release.state,'prepared','the open release is untouched');
 }finally{f.close();}
});

test('M3: a year bought after a revoked year starts now, not behind the year the site no longer has',async()=>{
 const f=await fixture();try{
  await f.payment();
  const siteId=f.site('site_'+'b1'.repeat(16),'revoked.example.com','suspended');f.grant('ann_b1_old',siteId,'annual',Date.now()-400*DAY,Date.now()-35*DAY);
  const first=await createCheckout(f.env,f.user,{kind:'hosting',siteId,requestKey:'revoked-first'});await f.pay(first.orderId,'evt_revoked_first');
  f.db.sqlite.prepare("UPDATE hosting_entitlements SET state='revoked' WHERE order_id=?").run(first.orderId);
  assert.equal((await json(await f.call('/api/hosting/sites/'+siteId))).data.canManageHosting,false);
  const quote=(await json(await f.call('/api/hosting/sites/'+siteId+'/renewal-quote'))).data;
  assert.equal(quote.basis,'on_resume');assert.ok(Math.abs(Date.parse(quote.startsAt)-Date.now())<60000);
  const second=await createCheckout(f.env,f.user,{kind:'hosting',siteId,requestKey:'revoked-second'});await f.pay(second.orderId,'evt_revoked_second');
  const granted=f.db.sqlite.prepare("SELECT starts_at,ends_at FROM hosting_entitlements WHERE order_id=? AND state='active'").get(second.orderId)!;
  assert.ok(Math.abs(Date.parse(String(granted.starts_at))-Date.now())<60000,'the new year starts at the payment, never one year later');
  assert.equal((await json(await f.call('/api/hosting/sites/'+siteId))).data.canManageHosting,true);
 }finally{f.close();}
});

test('M3: a year scheduled after membership that ended early is pulled forward: by maintenance, or by the next payment, which then resumes the site',async()=>{
 const f=await fixture();try{
  await f.payment();const membershipEnd=Date.now()+15*DAY;f.subscribe({included:2,state:'cancelled',autoRenew:0,endsMs:membershipEnd});
  const byCron=f.site('site_'+'b2'.repeat(16),'cron-pull.example.com','connected',Date.now()-9*DAY),byPayment=f.site('site_'+'b3'.repeat(16),'pay-pull.example.com','connected',Date.now()-8*DAY);
  const scheduled:Record<string,string>={};
  for(const siteId of [byCron,byPayment]){const order=await createCheckout(f.env,f.user,{kind:'hosting',siteId,requestKey:'scheduled-'+siteId.slice(-6)});await f.pay(order.orderId,'evt_scheduled_'+siteId.slice(-6));scheduled[siteId]=order.orderId;
   assert.equal(entitlements(f,siteId)[0].starts_at,iso(membershipEnd));}
  // The membership is revoked early: both sites lose coverage and are suspended.
  f.db.sqlite.prepare('UPDATE subscriptions SET ends_at=?').run(iso(Date.now()-60000));f.db.sqlite.prepare("UPDATE sites SET state='suspended'").run();
  assert.equal((await json(await f.call('/api/hosting/sites/'+byPayment))).data.canManageHosting,false);
  // The quote already treats the scheduled year as starting now; a new year follows it.
  const yearMs=Date.parse(addHostingYear(iso(membershipEnd)))-membershipEnd,quote=(await json(await f.call('/api/hosting/sites/'+byPayment+'/renewal-quote'))).data;
  assert.equal(quote.basis,'extend_annual');assert.equal(quote.estimated,true);assert.ok(Math.abs(Date.parse(quote.startsAt)-(Date.now()+yearMs))<60000);
  // Payment: the scheduled year moves to the payment time, the new year follows it, the site may resume immediately.
  const renewal=await createCheckout(f.env,f.user,{kind:'hosting',siteId:byPayment,requestKey:'pull-by-payment'});await f.pay(renewal.orderId,'evt_pull_by_payment');
  const paid=entitlements(f,byPayment);assert.equal(paid.length,2);
  assert.ok(Math.abs(Date.parse(paid[0].starts_at)-Date.now())<60000);assert.equal(Date.parse(paid[0].ends_at)-Date.parse(paid[0].starts_at),yearMs,'the scheduled year keeps its length');
  assert.equal(paid[1].order_id,renewal.orderId);assert.equal(paid[1].starts_at,paid[0].ends_at);
  assert.equal((await json(await f.call('/api/hosting/sites/'+byPayment))).data.canManageHosting,true);
  // Maintenance: the other site's scheduled year starts when the coverage actually ended (now), and is re-anchored at the resumption.
  const result=await processPendingHostingJobs(f.env);assert.ok(result.rescheduled>=1);
  const pulled=entitlements(f,byCron);assert.equal(pulled.length,1);assert.ok(Math.abs(Date.parse(pulled[0].starts_at)-Date.now())<60000);
  assert.equal((await json(await f.call('/api/hosting/sites/'+byCron))).data.canManageHosting,true);
  const activation=f.db.sqlite.prepare('SELECT reason,state FROM hosting_annual_activations WHERE order_id=?').get(scheduled[byCron])!;assert.equal(activation.reason,'resume');assert.equal(activation.state,'pending');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.rescheduled'"),2);
  assert.equal((await processPendingHostingJobs(f.env)).rescheduled,0,'applied once');
 }finally{f.close();}
});

test('provider 4xx stops for the platform team (5xx stays retryable); customer codes are neutral; the owner lists and releases stopped jobs with an audit',async()=>{
 const f=await fixture();try{
  f.subscribe({included:2});await poolFixture(f);let status=422;
  f.setCms(async request=>{if(new URL(request.url).origin==='https://developers.hostinger.com')return new Response(JSON.stringify({message:'rejected'}),{status,headers:{'content-type':'application/json'}});throw new Error('unexpected '+request.url);});
  const rejected=f.site('site_'+'c1'.repeat(16),'rejected.example.com','pending',Date.now()-DAY),rejectedJob='job_'+'c1'.repeat(16);legacyJob(f,rejected,rejectedJob);
  await runProvisioningJob(f.env,f.user,rejectedJob);
  let job=(await json(await f.call('/api/hosting/jobs/'+rejectedJob))).data;assert.equal(job.state,'awaiting_input');assert.equal(job.step,'operator_action');assert.equal(job.errorCode,'HOSTING_OPERATOR_REVIEW');
  assert.equal(JSON.parse(String(f.db.sqlite.prepare('SELECT result_json FROM provisioning_jobs WHERE id=?').get(rejectedJob)!.result_json)).internalErrorCode,'HOSTINGER_REQUEST_REJECTED');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.job.operator_review' AND entity_id=?",rejected),1);
  const attempts=()=>Number(f.db.sqlite.prepare('SELECT attempt_count FROM provisioning_jobs WHERE id=?').get(rejectedJob)!.attempt_count);
  const before=attempts();await processPendingHostingJobs(f.env);await processPendingHostingJobs(f.env);assert.equal(attempts(),before,'not retried every pass');
  // An outage stays retryable; the customer never sees a provider-named code.
  status=503;const outage=f.site('site_'+'c2'.repeat(16),'outage.example.com','pending',Date.now()-DAY),outageJob='job_'+'c2'.repeat(16);legacyJob(f,outage,outageJob);
  await runProvisioningJob(f.env,f.user,outageJob);
  job=(await json(await f.call('/api/hosting/jobs/'+outageJob))).data;assert.equal(job.state,'uncertain');assert.equal(job.errorCode,'HOSTING_RESULT_UNCERTAIN');
  assert.doesNotMatch(JSON.stringify(job),/hostinger|hpanel|TUS_/i);
  // Operators: admin and owner list stopped jobs; only the owner releases.
  for(const role of ['user','support'] as const)assert.equal((await f.call('/api/hosting-management/jobs','GET',undefined,'k',role)).status,403);
  const list=(await json(await f.call('/api/hosting-management/jobs','GET',undefined,'k','admin'))).data;assert.equal(list.canOperate,false);
  assert.deepEqual(list.items.map((item:any)=>[item.id,item.step,item.internalErrorCode]),[[rejectedJob,'operator_action','HOSTINGER_REQUEST_REJECTED']]);
  const release={reason:'供应商侧配置已修正',requestKey:'release_job_0001'};
  assert.equal((await f.call('/api/hosting-management/jobs/'+rejectedJob+'/release','POST',release,'k','admin')).status,403);
  let response=await f.call('/api/hosting-management/jobs/'+rejectedJob+'/release','POST',release,'k','owner');assert.equal(response.status,202);
  assert.equal((await json(response)).data.job.state,'pending');assert.equal((await json(await f.call('/api/hosting/jobs/'+rejectedJob))).data.step,'configure_hosting');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.job.released' AND actor_id='usr_owner'"),1);
  assert.equal((await f.call('/api/hosting-management/jobs/'+rejectedJob+'/release','POST',release,'k','owner')).status,202,'a replay changes nothing');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.job.released'"),1);
  response=await f.call('/api/hosting-management/jobs/'+rejectedJob+'/release','POST',{...release,requestKey:'release_job_0002'},'k','owner');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'HOSTING_JOB_NOT_RELEASABLE');
 }finally{f.close();}
});

test('an unopened pay-first year stays usable until the site opens; a job that cannot run moves to the back of the queue',async()=>{
 const f=await fixture();try{
  await f.payment();
  const created=(await json(await f.call('/api/hosting/sites','POST',{...input,billing:'annual'},'unopened_create_01'))).data;await f.pay(created.payment.orderId,'evt_unopened');
  // Eleven and a half months later the site still has not opened (customer slow on DNS).
  f.db.sqlite.prepare('UPDATE hosting_entitlements SET starts_at=?,ends_at=? WHERE order_id=?').run(iso(Date.now()-355*DAY),iso(Date.now()+10*DAY),created.payment.orderId);
  const result=await processPendingHostingJobs(f.env);assert.equal(result.extended,1);
  const extended=entitlements(f,created.site.id)[0];assert.ok(Date.parse(extended.ends_at)>Date.now()+360*DAY);
  const activation=f.db.sqlite.prepare('SELECT state,provisional_ends_at FROM hosting_annual_activations WHERE order_id=?').get(created.payment.orderId)!;assert.equal(activation.state,'pending');assert.equal(activation.provisional_ends_at,extended.ends_at);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.provisional_extended'"),1);
  assert.equal((await processPendingHostingJobs(f.env)).extended,0,'only when it is about to run out');
  // Already lapsed (data from before this fix): still usable from now on.
  f.db.sqlite.prepare('UPDATE hosting_entitlements SET ends_at=? WHERE order_id=?').run(iso(Date.now()-DAY),created.payment.orderId);
  assert.equal((await f.call('/api/hosting/jobs/'+created.job.id+'/retry','POST',{})).status,403);
  assert.equal((await processPendingHostingJobs(f.env)).extended,1);assert.equal((await f.call('/api/hosting/jobs/'+created.job.id+'/retry','POST',{})).status,202);
  // A job whose site has no coverage cannot run; it no longer stays at the head of the scheduler queue.
  const stuck=f.site('site_'+'c3'.repeat(16),'stuck.example.com','pending',Date.now()-DAY),stuckJob='job_'+'c3'.repeat(16);legacyJob(f,stuck,stuckJob);
  f.db.sqlite.prepare('UPDATE provisioning_jobs SET updated_at=? WHERE id=?').run(iso(Date.now()-30*DAY),stuckJob);
  await processPendingHostingJobs(f.env);
  assert.ok(Date.parse(String(f.db.sqlite.prepare('SELECT updated_at FROM provisioning_jobs WHERE id=?').get(stuckJob)!.updated_at))>Date.now()-60000);
 }finally{f.close();}
});

test('anchoring two pending years re-reads each row; the plan never evaluates before the site existed; billing routes pass waitUntil',async()=>{
 const f=await fixture();try{
  await f.payment();
  // POST /api/billing/orders/:id/reconcile runs the pay-first follow-up in the background (waitUntil).
  const parked=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'reconcile.example.com',billing:'annual'},'reconcile_create_01'))).data;
  const session=f.checkoutStates.get(parked.payment.orderId);session.status='complete';session.payment_status='paid';
  f.background.length=0;const response=await f.call('/api/billing/orders/'+parked.payment.orderId+'/reconcile','POST',{});assert.equal(response.status,200);
  assert.equal((await json(response)).data.state,'paid');assert.equal(f.background.length,1,'the started provisioning runs through waitUntil');await Promise.all(f.background);
  // Two pending years on one site (possible after a lapsed or revoked first year).
  const created=(await json(await f.call('/api/hosting/sites','POST',{...input,billing:'annual'},'two_pending_01'))).data;await f.pay(created.payment.orderId,'evt_two_pending');
  const second=await createCheckout(f.env,f.user,{kind:'hosting',siteId:created.site.id,requestKey:'two-pending-second'});await f.pay(second.orderId,'evt_two_pending_2');
  const [one,two]=entitlements(f,created.site.id);assert.equal(two.starts_at,one.ends_at);
  f.db.sqlite.prepare("INSERT INTO hosting_annual_activations(order_id,site_id,user_id,reason,provisional_starts_at,provisional_ends_at,created_at,updated_at) VALUES(?,?,?,'create',?,?,?,?)").run(second.orderId,created.site.id,f.user,two.starts_at,two.ends_at,iso(Date.now()),iso(Date.now()));
  f.db.sqlite.prepare("UPDATE sites SET state='connected' WHERE id=?").run(created.site.id);
  assert.equal(await anchorAnnualActivations(f.env.DB,created.site.id,Date.now()+3*DAY),2);
  const after=entitlements(f,created.site.id),rows=f.db.sqlite.prepare('SELECT anchored_ends_at FROM hosting_annual_activations WHERE site_id=? ORDER BY provisional_starts_at').all(created.site.id);
  assert.equal(after[1].starts_at,after[0].ends_at);assert.deepEqual(rows.map(row=>row.anchored_ends_at),[after[0].ends_at,after[1].ends_at],'each record matches its moved year');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.anchored'"),2);
  // Payment time floored to the second: a membership-covered site created a moment later is still evaluated as covered.
  f.subscribe({included:5,state:'cancelled',autoRenew:0,endsMs:Date.now()+10*DAY});const fresh=f.site('site_'+'c4'.repeat(16),'fresh.example.com','pending',Date.now());
  assert.equal((await annualRenewalPlan(f.env.DB,f.user,fresh,Date.now()-900))!.basis,'after_membership');
 }finally{f.close();}
});

/* ---- bint fix round: defects from REVIEW-money, REVIEW-security and REVIEW-recheck ---- */

test('M1 / R-M3a: a membership freeze never moves a year bought to follow the membership; the unfreeze moves it (and a year bought during the freeze) behind the restored membership',async()=>{
 const f=await fixture();try{
  await f.payment();const membershipEnd=Date.now()+15*DAY;f.subscribe({included:2,state:'cancelled',autoRenew:0,endsMs:membershipEnd});
  const before=f.site('site_'+'f1'.repeat(16),'frozen-a.example.com','connected',Date.now()-9*DAY),during=f.site('site_'+'f2'.repeat(16),'frozen-b.example.com','connected',Date.now()-8*DAY);
  const first=await createCheckout(f.env,f.user,{kind:'hosting',siteId:before,requestKey:'freeze-year-before'});await f.pay(first.orderId,'evt_freeze_before');
  const bought=entitlements(f,before)[0],yearMs=Date.parse(bought.ends_at)-Date.parse(bought.starts_at);assert.equal(bought.starts_at,iso(membershipEnd));
  const frozenAt=Date.now();
  assert.equal((await freezeMembership(f.env,'usr_owner',f.user,{reason:'争议核对期间冻结',requestKey:'freeze-key-0001'},{nowMs:frozenAt})).freeze?.state,'frozen');
  // Maintenance during the freeze: the paused membership still covers, nothing is pulled forward.
  assert.equal((await processPendingHostingJobs(f.env)).rescheduled,0);assert.deepEqual(entitlements(f,before)[0],bought);
  // A quote and a payment during the freeze follow the paused term (as an unfreeze now would restore it), never "now".
  const quote=(await json(await f.call('/api/hosting/sites/'+during+'/renewal-quote'))).data;
  assert.equal(quote.basis,'after_membership');assert.equal(quote.estimated,true);assert.ok(Math.abs(Date.parse(quote.startsAt)-membershipEnd)<60000);
  const second=await createCheckout(f.env,f.user,{kind:'hosting',siteId:during,requestKey:'freeze-year-during'});await f.pay(second.orderId,'evt_freeze_during');
  const duringYear=entitlements(f,during)[0],duringMs=Date.parse(duringYear.ends_at)-Date.parse(duringYear.starts_at);
  assert.ok(Math.abs(Date.parse(duringYear.starts_at)-membershipEnd)<60000);
  // Unfreeze 5 days later: the membership is extended by the frozen time and both years move behind it, keeping their length.
  const resumeAt=frozenAt+5*DAY;
  assert.equal((await unfreezeMembership(f.env,'usr_owner',f.user,{reason:'核对完成解冻',requestKey:'unfreeze-key-0001'},{nowMs:resumeAt})).freeze?.state,'completed');
  const restoredEnd=String(f.db.sqlite.prepare('SELECT ends_at FROM subscriptions WHERE user_id=?').get(f.user)!.ends_at);assert.equal(restoredEnd,iso(membershipEnd+5*DAY));
  for(const [siteId,length] of [[before,yearMs],[during,duringMs]] as const){const year=entitlements(f,siteId)[0];assert.equal(year.starts_at,restoredEnd,'no paid day overlaps the restored membership');assert.equal(Date.parse(year.ends_at)-Date.parse(year.starts_at),length);}
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.deferred'"),2);
  const summary=(await json(await f.call('/api/billing/summary'))).data.hosting.find((row:any)=>row.id===before);
  assert.deepEqual(summary.coverage.current.sources,['annual','membership']);assert.equal(summary.coverage.current.endsAt,entitlements(f,before)[0].ends_at,'membership, then the year without a gap');
  assert.equal((await processPendingHostingJobs(f.env)).rescheduled,0,'stable after the move');
 }finally{f.close();}
});

test('M3: a year placed after membership moves behind the slot when another site no longer takes it back; it never takes a slot another site uses; a 顺延 renewal stays put',async()=>{
 const f=await fixture();try{
  await f.payment();const membershipEnd=Date.now()+60*DAY,annualEnd=Date.now()+10*DAY;f.subscribe({included:1,endsMs:membershipEnd});
  const older=f.site('site_'+'m1'.repeat(16),'older.example.com','connected',Date.now()-30*DAY);f.grant('ann_older',older,'annual',Date.now()-355*DAY,annualEnd);
  const newer=f.site('site_'+'m2'.repeat(16),'newer.example.com','connected',Date.now()-20*DAY);
  const quote=(await json(await f.call('/api/hosting/sites/'+newer+'/renewal-quote'))).data;assert.equal(quote.basis,'after_membership');assert.equal(quote.startsAt,iso(annualEnd));
  const b=await createCheckout(f.env,f.user,{kind:'hosting',siteId:newer,requestKey:'m3-newer-year'});await f.pay(b.orderId,'evt_m3_newer');
  const placed=entitlements(f,newer)[0];assert.equal(placed.starts_at,iso(annualEnd));
  // The older site renews (顺延 from its own end): it never takes the slot back, so the newer site's year moves to the membership end.
  const a=await createCheckout(f.env,f.user,{kind:'hosting',siteId:older,requestKey:'m3-older-year'});await f.pay(a.orderId,'evt_m3_older');
  assert.equal(entitlements(f,older)[1].starts_at,iso(annualEnd),'a renewal continuing its own year is not moved');
  const moved=entitlements(f,newer)[0];assert.equal(moved.starts_at,iso(membershipEnd),'same result as when the older site renews first');
  assert.equal(Date.parse(moved.ends_at)-Date.parse(moved.starts_at),Date.parse(placed.ends_at)-Date.parse(placed.starts_at));
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.deferred' AND entity_id=?",newer),1);
  assert.equal((await processPendingHostingJobs(f.env)).rescheduled,0);
 }finally{f.close();}
 // With a third, newer site waiting for the slot the capacity is not idle: the year stays and the third site keeps the slot.
 const g=await fixture();try{
  await g.payment();const membershipEnd=Date.now()+60*DAY,annualEnd=Date.now()+10*DAY;g.subscribe({included:1,endsMs:membershipEnd});
  const older=g.site('site_'+'m3'.repeat(16),'older2.example.com','connected',Date.now()-30*DAY);g.grant('ann_older2',older,'annual',Date.now()-355*DAY,annualEnd);
  const newer=g.site('site_'+'m4'.repeat(16),'newer2.example.com','connected',Date.now()-20*DAY);g.site('site_'+'m5'.repeat(16),'third.example.com','suspended',Date.now()-10*DAY);
  const b=await createCheckout(g.env,g.user,{kind:'hosting',siteId:newer,requestKey:'m3-newer-year2'});await g.pay(b.orderId,'evt_m3_newer2');
  const a=await createCheckout(g.env,g.user,{kind:'hosting',siteId:older,requestKey:'m3-older-year2'});await g.pay(a.orderId,'evt_m3_older2');
  assert.equal(entitlements(g,newer)[0].starts_at,iso(annualEnd));assert.equal(count(g,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.deferred'"),0);
  await processPendingHostingJobs(g.env);assert.equal(entitlements(g,newer)[0].starts_at,iso(annualEnd));
 }finally{g.close();}
});

test('M2 / m1: one slot rule for the create and retry guards (single current term, Pro first then latest end); membershipSitesUsed never exceeds the plan',async()=>{
 const f=await fixture();try{
  await f.payment();
  f.subscribe({included:1,endsMs:Date.now()+20*DAY});f.subscribe({id:'sub_gift_two',source:'gift',included:2,endsMs:Date.now()+10*DAY,autoRenew:0});
  f.site('site_'+'s1'.repeat(16),'used.example.com','connected',Date.now()-5*DAY);
  let entitlement=(await json(await f.call('/api/hosting/sites'))).data.entitlement;
  assert.equal(entitlement.includedSites,1);assert.equal(entitlement.membershipSitesUsed,1);assert.equal(entitlement.canCreate,false);assert.equal(entitlement.canCreateAnnual,true);
  // The membership path is refused before anything is committed (it used to leave an uncovered, unreleasable site holding its domain).
  let response=await f.call('/api/hosting/sites','POST',{...input,domain:'member-path.example.com'},'m2_member_0001');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'SITE_LIMIT_REACHED');
  assert.equal(count(f,"SELECT COUNT(*) n FROM sites WHERE domain='member-path.example.com'"),0);assert.equal(count(f,"SELECT COUNT(*) n FROM hosting_domains WHERE domain='member-path.example.com'"),0);
  // The advertised pay-first path is accepted.
  const parked=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'pay-first.example.com',billing:'annual'},'m2_annual_0001'))).data;assert.equal(parked.job.awaitingPayment,true);
  // Retry cannot start it "for free" on the gift's larger site count, and its checkout stays open.
  response=await f.call('/api/hosting/jobs/'+parked.job.id+'/retry','POST',{});assert.equal(response.status,409);assert.equal((await json(response)).error.code,'HOSTING_PAYMENT_REQUIRED');
  assert.deepEqual(f.closedTrades,[]);assert.notEqual(f.db.sqlite.prepare('SELECT state FROM orders WHERE id=?').get(parked.payment.orderId)!.state,'expired');
  assert.equal((await json(await f.call('/api/hosting/jobs/'+parked.job.id))).data.awaitingPayment,true);
  // m1: two sites beyond the one slot: used is clamped to the plan, the excess is reported separately.
  f.site('site_'+'s2'.repeat(16),'over.example.com','suspended',Date.now()-4*DAY);
  entitlement=(await json(await f.call('/api/hosting/sites'))).data.entitlement;assert.equal(entitlement.membershipSitesUsed,1);assert.equal(entitlement.sitesOverLimit,1);
 }finally{f.close();}
});

test('R-M1a / m3: no new checkout for an unpaid site past its 24 h lifetime, so it is released once its last checkout closes',async()=>{
 const f=await fixture();try{
  await f.payment();const parked=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'squat-forever.example.com',billing:'annual'},'forever_key_0001'))).data;
  // Within the lifetime a new checkout for the site is still possible.
  assert.equal((await f.call('/api/billing/checkout','POST',{kind:'hosting',siteId:parked.site.id,requestKey:'keepalive-early-01'})).status,201);
  for(const row of f.db.sqlite.prepare('SELECT id FROM orders WHERE hosting_site_id=?').all(parked.site.id) as {id:string}[]){f.db.sqlite.prepare('UPDATE orders SET expires_at=? WHERE id=?').run(iso(Date.now()-60000),row.id);const session=f.checkoutStates.get(row.id);if(session)session.status='expired';}
  f.db.sqlite.prepare('UPDATE provisioning_jobs SET created_at=? WHERE id=?').run(iso(Date.now()-25*3600000),parked.job.id);
  const response=await f.call('/api/billing/checkout','POST',{kind:'hosting',siteId:parked.site.id,requestKey:'keepalive-0001'});assert.equal(response.status,409);assert.equal((await json(response)).error.code,'HOSTING_UNPAID_SITE_EXPIRED');
  assert.equal(count(f,"SELECT COUNT(*) n FROM orders WHERE idempotency_key='keepalive-0001'"),0);
  assert.equal((await processPendingHostingJobs(f.env)).released,1);assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',parked.site.id),0);
  assert.equal(count(f,"SELECT COUNT(*) n FROM hosting_domains WHERE domain='squat-forever.example.com'"),0);
 }finally{f.close();}
});

test('S3: an owner job release key belongs to one job and reason; another payload under the same key is 409',async()=>{
 const f=await fixture();try{
  const siteId=f.site('site_'+'r1'.repeat(16),'stopped.example.com','pending',Date.now()-DAY),jobId='job_'+'r1'.repeat(16),other='job_'+'r2'.repeat(16);
  legacyJob(f,siteId,jobId);const otherSite=f.site('site_'+'r2'.repeat(16),'stopped2.example.com','pending',Date.now()-DAY);legacyJob(f,otherSite,other);
  f.db.sqlite.prepare("UPDATE provisioning_jobs SET state='failed',step='configure_hosting',error_code='DOMAIN_ALREADY_HOSTED'").run();
  const release={reason:'已修复配置',requestKey:'release_key_0001'},url=(job:string)=>'/api/hosting-management/jobs/'+job+'/release';
  let response=await f.call(url(jobId),'POST',release,'k','owner');assert.equal(response.status,202);assert.equal((await json(response)).data.replayed,false);
  response=await f.call(url(jobId),'POST',{...release,reason:'完全不同的原因'},'k','owner');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'IDEMPOTENCY_CONFLICT');
  response=await f.call(url(other),'POST',release,'k','owner');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'IDEMPOTENCY_CONFLICT');
  // The job stops again: the original key is a replay (reported as such, nothing changes); a new key releases it.
  f.db.sqlite.prepare("UPDATE provisioning_jobs SET state='failed',error_code='DOMAIN_ALREADY_HOSTED' WHERE id=?").run(jobId);
  response=await f.call(url(jobId),'POST',release,'k','owner');assert.equal(response.status,202);const replay=(await json(response)).data;assert.equal(replay.replayed,true);assert.equal(replay.job.state,'failed');
  response=await f.call(url(jobId),'POST',{...release,requestKey:'release_key_0002'},'k','owner');assert.equal(response.status,202);assert.equal((await json(response)).data.job.state,'pending');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.job.released'"),2);
 }finally{f.close();}
});

test('S4 / R-WL2: the owner pause note and raw provider codes never reach the customer site view',async()=>{
 const f=await fixture();try{
  f.subscribe({included:1});const siteId=f.site('site_'+'w1'.repeat(16),'paused.example.com','connected',Date.now()-DAY),now=iso(Date.now());
  f.db.sqlite.prepare("INSERT INTO hosting_site_controls(site_id,paused,reason,actor_id,updated_at) VALUES(?,1,'Hostinger srv123 u123456789 abuse report, operator note','usr_owner',?)").run(siteId,now);
  f.db.sqlite.prepare("INSERT INTO hosting_lease_sync(site_id,last_issued_at,state,error_code,updated_at) VALUES(?,1,'uncertain','HOSTINGER_RATE_LIMITED',?)").run(siteId,now);
  f.db.sqlite.prepare("INSERT INTO hosting_domain_changes(id,site_id,user_id,request_key,payload_hash,old_domain,new_domain,challenge,reason,state,error_code,created_at,updated_at) VALUES('dch_w1',?,?,'domain_key_0001','h','paused.example.com','new.example.com','c','换域名','uncertain','HOSTINGER_REQUEST_REJECTED',?,?)").run(siteId,f.user,now,now);
  const view=(await json(await f.call('/api/hosting/sites/'+siteId))).data;
  assert.equal(view.management.operation.reason,'网站已由平台暂停，请联系支持');assert.equal(view.management.operation.paused,true);
  assert.equal(view.management.domainChange.errorCode,'HOSTING_REQUEST_REJECTED');assert.equal(view.hostingLease.errorCode,'HOSTING_RATE_LIMITED');assert.equal(view.management.operation.errorCode,'HOSTING_RATE_LIMITED');
  assert.doesNotMatch(JSON.stringify(view),/hostinger|srv123|u123456789/i);
  const staff=(await json(await f.call('/api/hosting-management/sites/'+siteId,'GET',undefined,'k','owner'))).data;assert.match(staff.operation.reason,/operator note/);
  const admin=(await json(await f.call('/api/hosting-management/sites/'+siteId,'GET',undefined,'k','admin'))).data;assert.match(admin.operation.reason,/operator note/);
 }finally{f.close();}
});

/* ---- bint fix round 2: REVIEW-security2 (R2-S1..S6) ---- */

/** Local DNS-over-HTTPS fake for the ownership TXT record (never a real resolver). */
function dnsFake(f:Awaited<ReturnType<typeof fixture>>){
 const records=new Map<string,string>();
 f.setCms(async request=>{const url=new URL(request.url);if(url.origin!=='https://cloudflare-dns.com')throw new Error('Unexpected network request '+url.href);
  const value=records.get(url.searchParams.get('name')||'');return Response.json({Status:0,Answer:value?[{type:16,data:'"'+value+'"'}]:[]});});
 return records;
}
const otherMember=(f:Awaited<ReturnType<typeof fixture>>,id:string,userId:string,included=1)=>f.db.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,state,auto_renew,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at) VALUES(?,?,'go','paid',?,?,'active',1,?,16250000,1,?,?)")
 .run(id,userId,iso(Date.now()-DAY),iso(Date.now()+20*DAY),included,'grant_'+id,iso(Date.now()));
/** The claim's checkouts closed at the provider long ago (the customer walked away). */
function abandon(f:Awaited<ReturnType<typeof fixture>>,siteId:string,ageMs=3*3600000){
 for(const row of f.db.sqlite.prepare('SELECT id FROM orders WHERE hosting_site_id=?').all(siteId) as {id:string}[]){
  f.db.sqlite.prepare('UPDATE orders SET expires_at=?,created_at=? WHERE id=?').run(iso(Date.now()-60000),iso(Date.now()-ageMs),row.id);
  const session=f.checkoutStates.get(row.id);if(session)session.status='expired';
 }
 f.db.sqlite.prepare('UPDATE provisioning_jobs SET created_at=? WHERE site_id=?').run(iso(Date.now()-ageMs),siteId);
}
const released=(f:{db:TestD1})=>f.db.sqlite.prepare("SELECT actor_id,details_json FROM audit_logs WHERE action='hosting.annual.unpaid_site_released' ORDER BY created_at,id").all().map(row=>({actor:row.actor_id,...JSON.parse(String(row.details_json))}));

test('R2-S2 / R2-S5: a claim with an open checkout yields only to an account that proves the domain by TXT; the release names the displacer, the displaced customer is told and never cooled down',async()=>{
 const f=await fixture();try{
  await f.payment();const dns=dnsFake(f);
  const victim=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'brand-r2.example.com',billing:'annual'},'victim_key_00001'))).data;assert.equal(victim.job.awaitingPayment,true);
  otherMember(f,'sub_admin','usr_admin');
  // A free slot alone is no proof of ownership: the customer who is paying keeps the domain.
  let response=await f.call('/api/hosting/sites','POST',{...input,domain:'brand-r2.example.com'},'member_key_00001','admin');
  assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',victim.site.id),1);assert.deepEqual(f.closedTrades,[]);assert.equal(released(f).length,0);
  // A TXT value published for another account proves nothing.
  const mine=(await json(await f.call('/api/hosting/domain-ownership?domain=brand-r2.example.com'))).data.record;dns.set(mine.name,mine.value);
  assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain:'brand-r2.example.com'},'member_key_00002','admin')).status,409);
  // The member's own record: the claim gives way inside the create batch.
  const record=(await json(await f.call('/api/hosting/domain-ownership?domain=brand-r2.example.com','GET',undefined,'k','admin'))).data.record;
  assert.equal(record.type,'TXT');assert.equal(record.name,'_benos-verification.brand-r2.example.com');assert.notEqual(record.value,mine.value);dns.set(record.name,record.value);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'brand-r2.example.com'},'member_key_00003','admin');assert.equal(response.status,202);
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',victim.site.id),0);assert.deepEqual(f.closedTrades,[victim.payment.orderId]);
  const [audit]=released(f);
  assert.equal(audit.actor,'usr_admin');assert.equal(audit.via,'displaced');assert.equal(audit.userId,f.user);assert.equal(audit.displacedBy,'usr_admin');assert.equal(audit.path,'membership');assert.equal(audit.ownershipProven,true);
  // A payment that still lands for the released claim goes to review, never to the new holder.
  assert.equal((await f.pay(victim.payment.orderId,'evt_late_after_displace')).state,'review');
  assert.equal(String(f.db.sqlite.prepare('SELECT state FROM orders WHERE id=?').get(victim.payment.orderId)!.state),'review');assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_entitlements'),0);
  // The displaced customer sees a neutral, truthful notice (no other account named) and is not put in a cool-down.
  const list=(await json(await f.call('/api/hosting/sites'))).data;
  assert.equal(list.releasedClaims.length,1);assert.equal(list.releasedClaims[0].domain,'brand-r2.example.com');assert.equal(list.releasedClaims[0].reason,'claimed_by_other_account');
  assert.match(list.releasedClaims[0].message,/域名归属验证/);assert.doesNotMatch(JSON.stringify(list.releasedClaims),/usr_admin|admin@/);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'brand-r2.example.com',billing:'annual'},'victim_key_00002');assert.equal((await json(response)).error.code,'SITE_CONFLICT','the domain now belongs to a live site, not a cool-down');
  assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain:'brand-other.example.com',billing:'annual'},'victim_key_00003')).status,202);
 }finally{f.close();}
 // A claim whose payment already arrived is never displaced, even with proof.
 const g=await fixture();try{
  await g.payment();const dns=dnsFake(g);const paid=(await json(await g.call('/api/hosting/sites','POST',{...input,domain:'paid-claim.example.com',billing:'annual'},'paid_claim_0001'))).data;
  const session=g.checkoutStates.get(paid.payment.orderId);session.status='complete';session.payment_status='paid';
  otherMember(g,'sub_late','usr_admin');const record=(await json(await g.call('/api/hosting/domain-ownership?domain=paid-claim.example.com','GET',undefined,'k','admin'))).data.record;dns.set(record.name,record.value);
  const response=await g.call('/api/hosting/sites','POST',{...input,domain:'paid-claim.example.com'},'late_member_0001','admin');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'SITE_CONFLICT');
  assert.equal(count(g,'SELECT COUNT(*) n FROM sites WHERE id=?',paid.site.id),1);
 }finally{g.close();}
});

test('R2-S1: a create that is refused anyway (bound project, unpaid-site cap) never removes another account\'s claim; an abandoned claim yields in the same batch as a create that succeeds',async()=>{
 const f=await fixture();try{
  await f.payment();const now=iso(Date.now()),project='prj_'+'e'.repeat(32);
  const one=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'victim-one.example.com',billing:'annual'},'victim_one_0001','support'))).data;
  const two=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'victim-two.example.com',billing:'annual'},'victim_two_0001','support'))).data;
  abandon(f,one.site.id);abandon(f,two.site.id);
  // R2-S1b: a member (2 free slots) whose project is already bound to its own site.
  f.subscribe({included:3});f.db.sqlite.prepare("INSERT INTO projects(id,user_id,name,status,created_at,updated_at) VALUES(?,?,'Bound','draft',?,?)").run(project,f.user,now,now);
  const own=f.site('site_'+'e1'.repeat(16),'own-bound.example.com');f.db.sqlite.prepare('UPDATE sites SET project_id=? WHERE id=?').run(project,own);
  for(const [domain,key] of [['victim-one.example.com','evict_one_0001'],['victim-two.example.com','evict_two_0001']]){
   const response=await f.call('/api/hosting/sites','POST',{...input,domain,projectId:project},key);assert.equal(response.status,409);assert.equal((await json(response)).error.code,'SITE_CONFLICT');
  }
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id IN (?,?)',one.site.id,two.site.id),2);assert.equal(released(f).length,0);assert.deepEqual(f.closedTrades,[]);
  // R2-S1b2: an account without a plan at the 3-site unpaid cap.
  for(const domain of ['cap-a.example.com','cap-b.example.com','cap-c.example.com'])assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain,billing:'annual'},'cap_'+domain.slice(4,5)+'_key_0001','owner')).status,202);
  let response=await f.call('/api/hosting/sites','POST',{...input,domain:'victim-one.example.com',billing:'annual'},'cap_over_key_001','owner');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'HOSTING_UNPAID_SITE_LIMIT');
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',one.site.id),1);assert.equal(released(f).length,0);
  // The same member with a free project: an abandoned claim still needs the TXT proof (R3-S1a: a slot proves nothing about the domain).
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'victim-one.example.com'},'evict_one_0002');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',one.site.id),1);assert.equal(released(f).length,0);
  // With its own record the claim yields, recorded in the create's own batch.
  const dns=dnsFake(f),record=(await json(await f.call('/api/hosting/domain-ownership?domain=victim-one.example.com'))).data.record;dns.set(record.name,record.value);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'victim-one.example.com'},'evict_one_0003');assert.equal(response.status,202);
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',one.site.id),0);
  const [audit]=released(f);assert.equal(audit.actor,f.user);assert.equal(audit.path,'membership');assert.equal(audit.ownershipProven,true);assert.equal(audit.userId,'usr_support');
  assert.equal(String(f.db.sqlite.prepare("SELECT s.user_id FROM hosting_domains d JOIN sites s ON s.id=d.site_id WHERE d.domain='victim-one.example.com'").get()!.user_id),f.user);
 }finally{f.close();}
});

test('R2-S3 / R2-S6 / R3-S1a: a pay-first claim yields only to a TXT proof, however long it was abandoned; a cancelled claim can be parked again at once but keeps its age; an expired one cools down',async()=>{
 const f=await fixture();try{
  await f.payment();const dns=dnsFake(f);
  const victim=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'rotate.example.com',billing:'annual'},'rotate_key_00001','support'))).data;
  f.db.sqlite.prepare('UPDATE provisioning_jobs SET created_at=? WHERE id=?').run(iso(Date.now()-2*3600000-60000),victim.job.id);
  for(const row of f.db.sqlite.prepare('SELECT id FROM orders WHERE hosting_site_id=?').all(victim.site.id) as {id:string}[])f.db.sqlite.prepare('UPDATE orders SET created_at=? WHERE id=?').run(iso(Date.now()-2*3600000-60000),row.id);
  // The customer opens a fresh checkout seconds before a stranger tries to take the domain.
  assert.equal((await f.call('/api/billing/checkout','POST',{kind:'hosting',siteId:victim.site.id,requestKey:'rotate-fresh-0001'},'k','support')).status,201);
  let response=await f.call('/api/hosting/sites','POST',{...input,domain:'rotate.example.com',billing:'annual'},'stranger_key_0001');
  assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');assert.deepEqual(f.closedTrades,[]);
  // Its checkouts closed, but the newest one is under 2 h old: the claim still holds.
  abandon(f,victim.site.id,3*3600000);f.db.sqlite.prepare("UPDATE orders SET created_at=? WHERE idempotency_key='rotate-fresh-0001'").run(iso(Date.now()-30*60000));
  assert.equal((await json(await f.call('/api/hosting/sites','POST',{...input,domain:'rotate.example.com',billing:'annual'},'stranger_key_0002'))).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  // Abandoned for over 2 h: age alone is still no proof (R3-S1a).
  abandon(f,victim.site.id,3*3600000);
  assert.equal((await json(await f.call('/api/hosting/sites','POST',{...input,domain:'rotate.example.com',billing:'annual'},'stranger_key_0005a'))).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',victim.site.id),1);
  // With its own TXT record the pay-first creation takes it.
  const record=(await json(await f.call('/api/hosting/domain-ownership?domain=rotate.example.com'))).data.record;dns.set(record.name,record.value);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'rotate.example.com',billing:'annual'},'stranger_key_0003');assert.equal(response.status,202);
  const taken=(await json(response)).data;assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',victim.site.id),0);
  const [audit]=released(f);assert.equal(audit.path,'pay_first');assert.equal(audit.actor,f.user);assert.equal(audit.userId,'usr_support');assert.equal(audit.ownershipProven,true);dns.clear();
  // R2-S6: the stranger cancels by mistake and parks again at once; the new claim keeps the first claim's age.
  const firstCreated=String(f.db.sqlite.prepare('SELECT created_at FROM provisioning_jobs WHERE id=?').get(taken.job.id)!.created_at);
  f.db.sqlite.prepare('UPDATE provisioning_jobs SET created_at=? WHERE id=?').run(iso(Date.parse(firstCreated)-3600000),taken.job.id);
  assert.equal((await f.call('/api/hosting/jobs/'+taken.job.id+'/cancel','POST',{})).status,200);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'rotate.example.com',billing:'annual'},'stranger_key_0004');assert.equal(response.status,202);
  const again=(await json(response)).data;assert.equal(String(f.db.sqlite.prepare('SELECT created_at FROM provisioning_jobs WHERE id=?').get(again.job.id)!.created_at),iso(Date.parse(firstCreated)-3600000),'cancel + create never renews the hold');
  // A claim that expired after its full lifetime cools down for its own account.
  abandon(f,again.site.id,25*3600000);assert.equal((await processPendingHostingJobs(f.env)).released,1);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'rotate.example.com',billing:'annual'},'stranger_key_0005');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'HOSTING_UNPAID_DOMAIN_COOLDOWN');
  assert.equal((await f.call('/api/hosting/sites','POST',{...input,domain:'rotate.example.com',billing:'annual'},'support_back_0001','support')).status,202,'the cool-down is per account');
 }finally{f.close();}
});

test('R2-S4: a paying site can change to its own domain while a stranger holds an unpaid claim on it (open checkout only with the TXT proof)',async()=>{
 const f=await fixture();try{
  await f.payment();const dns=dnsFake(f);f.subscribe({included:1});
  const siteId=f.site('site_'+'d4'.repeat(16),'old-name.example.com','connected',Date.now()-30*DAY),secret='domain-change-connection-secret-0123456789';
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_d4',?,'https://old-name.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(siteId,await encryptSecret(secret,f.env.ENCRYPTION_KEY,siteId),iso(Date.now()),iso(Date.now()));
  const squat=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'new-name.example.com',billing:'annual'},'squat_new_00001','support'))).data;
  const change=(key:string)=>f.call('/api/hosting-management/sites/'+siteId+'/domain-changes','POST',{domain:'new-name.example.com',reason:'客户更换品牌域名',requestKey:key});
  let response=await change('change_key_00001');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',squat.site.id),1);
  const record=(await json(await f.call('/api/hosting/domain-ownership?domain=new-name.example.com'))).data.record;dns.set(record.name,record.value);
  response=await change('change_key_00002');assert.equal(response.status,202);assert.equal((await json(response)).data.domainChange.newDomain,'new-name.example.com');
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',squat.site.id),0);assert.deepEqual(f.closedTrades,[squat.payment.orderId]);
  assert.equal(String(f.db.sqlite.prepare("SELECT site_id FROM hosting_domains WHERE domain='new-name.example.com'").get()!.site_id),siteId);
  const [audit]=released(f);assert.equal(audit.path,'domain_change');assert.equal(audit.actor,f.user);assert.equal(audit.ownershipProven,true);
 }finally{f.close();}
});

/* ---- bint fix round 2: REVIEW-money2 (N1..N7) ---- */

/** Runs `hook` right before the first batch that holds a statement prepared from SQL containing `match`
 * (a deterministic interleaving of two requests at a statement boundary, which D1 allows). */
function interleaved(real:TestD1,match:string,hook:()=>Promise<void>):D1Database{
 let fired=false;const tagged=new WeakSet<object>();
 return new Proxy(real,{get(target,prop){
  if(prop==='prepare')return (sql:string)=>{const statement=target.prepare(sql);if(!sql.includes(match))return statement;
   return {bind:(...values:any[])=>{const bound=statement.bind(...values);tagged.add(bound);return bound;},first:(column?:string)=>statement.first(column),all:()=>statement.all(),run:()=>statement.run(),raw:(options?:any)=>statement.raw(options)};};
  if(prop==='batch')return async(statements:any[])=>{if(!fired&&statements.some(statement=>tagged.has(statement))){fired=true;await hook();}return target.batch(statements);};
  const value=(target as any)[prop];return typeof value==='function'?value.bind(target):value;}}) as unknown as D1Database;
}
const GUARD_SQL='INSERT INTO mutation_guards(id,permitted) SELECT ?1,CASE WHEN';
const annualRows=(f:{db:TestD1},siteId:string)=>f.db.sqlite.prepare("SELECT id,starts_at,ends_at FROM hosting_entitlements WHERE site_id=? AND source='annual' AND state='active' ORDER BY starts_at").all(siteId) as {id:string;starts_at:string;ends_at:string}[];

test('N1: a membership term that starts where a year was placed (a gift here; the cycle invoice in payments.test) moves the year at once; quotes behind an auto-renewing plan are estimates',async()=>{
 const f=await fixture();try{
  await f.payment();const membershipEnd=Date.now()+5*DAY;f.subscribe({included:1,state:'cancelled',autoRenew:0,endsMs:membershipEnd});
  const b=f.site('site_'+'n1'.repeat(16),'n1.example.com','connected',Date.now()-40*DAY);
  assert.equal((await json(await f.call('/api/hosting/sites/'+b+'/renewal-quote'))).data.estimated,false);
  f.db.sqlite.prepare("UPDATE subscriptions SET state='active',auto_renew=1").run();
  const quote=(await json(await f.call('/api/hosting/sites/'+b+'/renewal-quote'))).data;assert.equal(quote.basis,'after_membership');assert.equal(quote.estimated,true,'an auto-renewal before the start would move it');
  f.db.sqlite.prepare("UPDATE subscriptions SET state='cancelled',auto_renew=0").run();
  const order=await createCheckout(f.env,f.user,{kind:'hosting',siteId:b,requestKey:'n1-year-00001'});await f.pay(order.orderId,'evt_n1_year');
  assert.equal(annualRows(f,b)[0].starts_at,iso(membershipEnd));
  const gift=await giftMembership(f.env,'usr_owner',f.user,{tier:'go',months:1,reason:'补偿赠送一个月',requestKey:'n1-gift-000001',startsAt:iso(membershipEnd)});
  const giftEnd=String(f.db.sqlite.prepare("SELECT ends_at FROM subscriptions WHERE source='gift'").get()!.ends_at);assert.ok(gift);
  assert.equal(annualRows(f,b)[0].starts_at,giftEnd,'moved by the gift itself, no maintenance pass needed');
  assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_deferral_requests'),0);assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.deferred'"),1);
 }finally{f.close();}
});

test('N2: a pay-first year bought during a freeze and opened after the unfreeze moves behind the restored slot; its activation record follows',async()=>{
 const f=await fixture();try{
  await f.payment();f.subscribe({included:2,state:'cancelled',autoRenew:0,endsMs:Date.now()+20*DAY});
  f.site('site_'+'a2'.repeat(16),'a2.example.com','connected',Date.now()-30*DAY);
  assert.equal((await freezeMembership(f.env,'usr_owner',f.user,{reason:'争议核对期间冻结',requestKey:'n2-freeze-0001'},{nowMs:Date.now()})).freeze?.state,'frozen');
  const created=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'n2c.example.com',billing:'annual'},'n2_create_00001'))).data,c=created.site.id;
  await f.pay(created.payment.orderId,'evt_n2c');
  assert.equal(String(f.db.sqlite.prepare('SELECT state FROM hosting_annual_activations WHERE site_id=?').get(c)!.state),'pending');
  assert.equal((await unfreezeMembership(f.env,'usr_owner',f.user,{reason:'核对完成解冻',requestKey:'n2-unfreeze-01'},{nowMs:Date.now()})).freeze?.state,'completed');
  // The site opens after the unfreeze (DNS took a while): anchoring moves the year behind the restored slot.
  f.db.sqlite.prepare("UPDATE sites SET state='connected' WHERE id=?").run(c);f.db.sqlite.prepare("UPDATE provisioning_jobs SET state='succeeded',step='done' WHERE site_id=?").run(c);
  await anchorAnnualActivations(f.env.DB,c);
  const restoredEnd=String(f.db.sqlite.prepare('SELECT ends_at FROM subscriptions WHERE user_id=?').get(f.user)!.ends_at),[year]=annualRows(f,c);
  assert.equal(year.starts_at,restoredEnd,'no paid day while the restored slot would sit idle');
  assert.equal(String(f.db.sqlite.prepare('SELECT anchored_ends_at FROM hosting_annual_activations WHERE site_id=?').get(c)!.anchored_ends_at),year.ends_at);
  const list=(await json(await f.call('/api/hosting/sites'))).data.entitlement;assert.equal(list.membershipSitesUsed,2);assert.equal(list.canCreate,false);
  assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_deferral_requests'),0);assert.equal((await processPendingHostingJobs(f.env)).rescheduled,0,'stable');
 }finally{f.close();}
});

test('N3: during a freeze a revoked independent year still pulls the next paid year forward, so the site stays active',async()=>{
 const f=await fixture();try{
  await f.payment();f.subscribe({included:1,state:'cancelled',autoRenew:0,endsMs:Date.now()+20*DAY});
  f.site('site_'+'v0'.repeat(16),'v0.example.com','connected',Date.now()-90*DAY);
  const b=f.site('site_'+'v1'.repeat(16),'v1.example.com','connected',Date.now()-60*DAY),y1End=Date.now()+265*DAY;
  f.grant('ann_v1',b,'annual',Date.now()-100*DAY,y1End);f.grant('ann_v2',b,'annual',y1End,Date.parse(addHostingYear(iso(y1End))));
  await freezeMembership(f.env,'usr_owner',f.user,{reason:'争议核对期间冻结',requestKey:'n3-freeze-0001'},{nowMs:Date.now()});
  f.db.sqlite.prepare("UPDATE hosting_entitlements SET state='revoked' WHERE id='ann_v1'").run();
  assert.equal((await processPendingHostingJobs(f.env)).rescheduled,1);
  assert.ok(Math.abs(Date.parse(annualRows(f,b)[0].starts_at)-Date.now())<60000,'the paid year runs now');
  assert.equal((await json(await f.call('/api/hosting/sites/'+b))).data.canManageHosting,true);
 }finally{f.close();}
});

async function idleSlotSetup(f:Awaited<ReturnType<typeof fixture>>){
 await f.payment();const membershipEnd=Date.now()+60*DAY,annualEnd=Date.now()+10*DAY;f.subscribe({included:1,endsMs:membershipEnd});
 const a=f.site('site_'+'r1'.repeat(16),'older.example.com','connected',Date.now()-30*DAY);f.grant('ann_a1',a,'annual',Date.now()-355*DAY,annualEnd);
 const b=f.site('site_'+'r2'.repeat(16),'newer.example.com','connected',Date.now()-20*DAY);
 const order=await createCheckout(f.env,f.user,{kind:'hosting',siteId:b,requestKey:'r-b-year-0001'});await f.pay(order.orderId,'evt_r_b1');
 assert.equal(annualRows(f,b)[0].starts_at,iso(annualEnd));
 // A renews (顺延), inserted directly so that B's deferral is still due, as between two maintenance passes.
 f.grant('ann_a2',a,'annual',annualEnd,Date.parse(addHostingYear(iso(annualEnd))));
 return {a,b,membershipEnd,annualEnd};
}

test('N4 / N5: a deferral that loses a race to a renewal or to another deferral of the same site rolls back whole: no overlap, one audit row',async()=>{
 const f=await fixture();try{
  const {b,membershipEnd}=await idleSlotSetup(f);
  // N4: maintenance has read B's rows; the second-year webhook (with its own deferral) commits before maintenance's batch.
  const second=await createCheckout(f.env,f.user,{kind:'hosting',siteId:b,requestKey:'r-b-year-0002'});
  const racing=interleaved(f.db,GUARD_SQL,async()=>{assert.equal((await f.pay(second.orderId,'evt_r_b2')).state,'processed');});
  await assert.rejects(deferAnnualYearsBehindIdleSlot(racing,f.user,b),AnnualMoveConflict);
  const years=annualRows(f,b);assert.equal(years.length,2);
  assert.equal(years[0].starts_at,iso(membershipEnd));assert.equal(years[1].starts_at,years[0].ends_at,'the two paid years never overlap');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.deferred' AND entity_id=?",b),1);
  assert.equal((await processPendingHostingJobs(f.env)).rescheduled,0);
 }finally{f.close();}
 const g=await fixture();try{
  const {b,membershipEnd}=await idleSlotSetup(g);
  // N5: two deferrals of the same site interleave: one move, one audit row.
  let inner=0;const racing=interleaved(g.db,GUARD_SQL,async()=>{inner=await deferAnnualYearsBehindIdleSlot(g.env.DB,g.user,b);});
  await assert.rejects(deferAnnualYearsBehindIdleSlot(racing,g.user,b),AnnualMoveConflict);
  assert.equal(inner,1);assert.equal(annualRows(g,b)[0].starts_at,iso(membershipEnd));
  assert.equal(count(g,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.deferred'"),1);
 }finally{g.close();}
});

test('N6: deferrals of two sites never take the same idle capacity, so neither site gets a hole',async()=>{
 const f=await fixture();try{
  await f.payment();const T=Date.now()+30*DAY;
  f.subscribe({id:'sub_two',included:2,state:'cancelled',autoRenew:0,endsMs:T});
  const a=f.site('site_'+'q1'.repeat(16),'q1.example.com','connected',Date.now()-30*DAY),b=f.site('site_'+'q2'.repeat(16),'q2.example.com','connected',Date.now()-20*DAY);
  f.grant('ann_qa',a,'annual',T,Date.parse(addHostingYear(iso(T))));f.grant('ann_qb',b,'annual',T,Date.parse(addHostingYear(iso(T))));
  f.subscribe({id:'sub_gift_one',source:'gift',included:1,autoRenew:0,startsMs:T,endsMs:T+30*DAY});
  let inner=0;const racing=interleaved(f.db,GUARD_SQL,async()=>{inner=await deferAnnualYearsBehindIdleSlot(f.env.DB,f.user,b);});
  await assert.rejects(deferAnnualYearsBehindIdleSlot(racing,f.user,a),AnnualMoveConflict);assert.equal(inner,1);
  await processPendingHostingJobs(f.env);
  const summary=(await json(await f.call('/api/billing/summary'))).data.hosting;
  for(const siteId of [a,b]){const coverage=summary.find((row:any)=>row.id===siteId).coverage;
   assert.deepEqual(coverage.upcoming,[],'no hole for '+siteId);assert.equal(coverage.current.endsAt,annualRows(f,siteId)[0].ends_at,'covered without a gap until the paid year ends');}
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.deferred'"),1);
 }finally{f.close();}
});

test('N7: an unfreeze whose deferral fails is retried from the durable request until the year is behind the restored membership',async()=>{
 const f=await fixture();try{
  const M=Date.now()-10*DAY,frozenAt=Date.now()-15*DAY;
  f.subscribe({included:1,state:'cancelled',autoRenew:0,startsMs:Date.now()-40*DAY,endsMs:M});
  const b=f.site('site_'+'u1'.repeat(16),'u1.example.com','connected',Date.now()-60*DAY);f.grant('ann_u1',b,'annual',M,Date.parse(addHostingYear(iso(M))));
  assert.equal((await freezeMembership(f.env,'usr_owner',f.user,{reason:'争议核对期间冻结',requestKey:'n7-freeze-0001'},{nowMs:frozenAt})).freeze?.state,'frozen');
  const failing=new Proxy(f.db,{get(target,prop){if(prop==='prepare')return (sql:string)=>{if(sql.includes('GROUP BY h.site_id ORDER BY MIN(s.created_at)'))throw new Error('D1_ERROR: simulated transient failure');return target.prepare(sql);};
   const value=(target as any)[prop];return typeof value==='function'?value.bind(target):value;}});
  assert.equal((await unfreezeMembership({...f.env,DB:failing as unknown as D1Database},'usr_owner',f.user,{reason:'核对完成解冻',requestKey:'n7-unfreeze-01'},{nowMs:Date.now()})).freeze?.state,'completed');
  assert.equal(annualRows(f,b)[0].starts_at,iso(M),'the first attempt failed');assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_deferral_requests WHERE attempts=1'),1);
  assert.ok((await processPendingHostingJobs(f.env)).rescheduled>=1);
  const restored=String(f.db.sqlite.prepare('SELECT ends_at FROM subscriptions WHERE user_id=?').get(f.user)!.ends_at);
  assert.equal(annualRows(f,b)[0].starts_at,restored);assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_deferral_requests'),0);
 }finally{f.close();}
});

/* ---- bint fix round 3: REVIEW-money2-r3 (R3-M1, R3-1, R3-2, R3-4, R3-5) and REVIEW-security2-r3 (R3-S1a..c, R3-S2, R3-S3) ---- */

const domainHolder=(f:{db:TestD1},domain:string)=>(f.db.sqlite.prepare('SELECT s.user_id AS u FROM hosting_domains d JOIN sites s ON s.id=d.site_id WHERE d.domain=?').get(domain) as {u:string}|undefined)?.u??null;

test('R3-M1 / R3-S2: a cancelled claim parked again keeps its age only while one full checkout still fits: the new checkout opens, maintenance keeps it, no cool-down',async()=>{
 const f=await fixture();try{
  await f.payment();
  // R3-M1: the claim is 25 h old, its last checkout (opened at 23.5 h) still open; the customer cancels and parks again at once.
  const first=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'r3m1.example.com',billing:'annual'},'r3m1_create_0001'))).data;
  f.db.sqlite.prepare('UPDATE provisioning_jobs SET created_at=? WHERE id=?').run(iso(Date.now()-25*3600000),first.job.id);
  assert.equal((await f.call('/api/hosting/jobs/'+first.job.id+'/cancel','POST',{})).status,200);
  let again=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'r3m1.example.com',billing:'annual'},'r3m1_create_0002'))).data;
  assert.equal(again.payment.errorCode,null);assert.ok(again.payment.orderId,'the re-parked claim takes a checkout');assert.equal(again.payment.checkoutState,'open');
  const age=Date.now()-Date.parse(String(f.db.sqlite.prepare('SELECT created_at FROM provisioning_jobs WHERE id=?').get(again.job.id)!.created_at));
  assert.ok(age>=22*3600000-60000&&age<=22*3600000+60000,'aged to 22 h: one 2 h checkout still fits in the 24 h lifetime');
  assert.equal((await processPendingHostingJobs(f.env)).released,0,'kept while its checkout is open');
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.annual.unpaid_site_released' AND json_extract(details_json,'$.via')='expired'"),0);
  // A further create of the same domain by the same account meets its own claim (SITE_CONFLICT), never a cool-down.
  assert.equal((await json(await f.call('/api/hosting/sites','POST',{...input,domain:'r3m1.example.com',billing:'annual'},'r3m1_create_0003'))).error.code,'SITE_CONFLICT');
  // R3-S2: cancelled at 23 h 50 min by mistake, parked again 20 min later (the inherited age is past 24 h): still payable.
  const late=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'r3s2.example.com',billing:'annual'},'r3s2_create_0001'))).data;
  f.db.sqlite.prepare('UPDATE provisioning_jobs SET created_at=? WHERE id=?').run(iso(Date.now()-23*3600000-50*60000),late.job.id);
  assert.equal((await f.call('/api/hosting/jobs/'+late.job.id+'/cancel','POST',{})).status,200);
  f.db.sqlite.prepare("UPDATE audit_logs SET created_at=?,details_json=json_set(details_json,'$.claimCreatedAt',?) WHERE action='hosting.annual.unpaid_site_released' AND json_extract(details_json,'$.domain')='r3s2.example.com'").run(iso(Date.now()-20*60000),iso(Date.now()-24*3600000-10*60000));
  const response=await f.call('/api/hosting/sites','POST',{...input,domain:'r3s2.example.com',billing:'annual'},'r3s2_create_0002');assert.equal(response.status,202);
  again=(await json(response)).data;assert.equal(again.payment.errorCode,null);assert.ok(again.payment.orderId);
  assert.equal((await processPendingHostingJobs(f.env)).released,0);
 }finally{f.close();}
});

test('R3-S1a / R3-S1c: an unproven member never takes a parked domain (lapsed checkout, or one a prover is closing); the prover wins and each checkout it closed is audited',async()=>{
 const f=await fixture();try{
  await f.payment();dnsFake(f);
  const owner=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'real-owner.example.com',billing:'annual'},'owner_park_k0001','support'))).data;
  abandon(f,owner.site.id,2*3600000+5*60000);otherMember(f,'sub_admin','usr_admin');
  const response=await f.call('/api/hosting/sites','POST',{...input,domain:'real-owner.example.com'},'stranger_k_00001','admin');
  assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  assert.equal(domainHolder(f,'real-owner.example.com'),'usr_support');assert.equal(released(f).length,0);
  assert.equal(count(f,"SELECT COUNT(*) n FROM sites WHERE user_id='usr_admin'"),0);
 }finally{f.close();}
 const g=await fixture();try{
  await g.payment();const dns=dnsFake(g);
  const victim=(await json(await g.call('/api/hosting/sites','POST',{...input,domain:'race-proof.example.com',billing:'annual'},'victim_race_0001','support'))).data;assert.equal(victim.payment.checkoutState,'open');
  g.subscribe({included:1});otherMember(g,'sub_admin','usr_admin');
  const record=(await json(await g.call('/api/hosting/domain-ownership?domain=race-proof.example.com'))).data.record;dns.set(record.name,record.value);
  // Right after the prover closed the victim's checkout and before its batch commits, an unproven member tries the same domain.
  const real=g.env.DB;let intruder:Response|null=null,fired=false;
  (g.env as any).DB=new Proxy(real,{get(target:any,prop){if(prop==='batch')return async(statements:any[])=>{
    if(!fired&&g.closedTrades.length>0){fired=true;intruder=await g.call('/api/hosting/sites','POST',{...input,domain:'race-proof.example.com'},'intruder_k_00001','admin');}
    return target.batch(statements);};const value=target[prop];return typeof value==='function'?value.bind(target):value;}});
  const prover=await g.call('/api/hosting/sites','POST',{...input,domain:'race-proof.example.com'},'prover_k_000001');(g.env as any).DB=real;
  assert.ok(fired);assert.equal(intruder!.status,409);assert.equal((await json(intruder!)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  assert.equal(prover.status,202);assert.equal(domainHolder(g,'race-proof.example.com'),g.user);
  const [audit]=released(g);assert.equal(audit.displacedBy,g.user);assert.equal(audit.ownershipProven,true);assert.equal(audit.hadCheckout,true);
  const closed=g.db.sqlite.prepare("SELECT actor_id,details_json FROM audit_logs WHERE action='hosting.annual.unpaid_checkout_closed'").all().map(row=>({actor:row.actor_id,...JSON.parse(String(row.details_json))}));
  assert.equal(closed.length,1);assert.equal(closed[0].orderId,victim.payment.orderId);assert.equal(closed[0].displacedBy,g.user);assert.equal(closed[0].outcome,'closed');assert.equal(closed[0].userId,'usr_support');
 }finally{g.close();}
});

test('R3-S1b / R3-S3: a domain change never takes a lapsed claim without proof; an unproven change is cancellable and expires after 7 days; the displaced notice is truthful',async()=>{
 const f=await fixture();try{
  await f.payment();const dns=dnsFake(f);f.subscribe({included:1});
  const siteId=f.site('site_'+'b3'.repeat(16),'live-b3.example.com','connected',Date.now()-30*DAY);
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_b3',?,'https://live-b3.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(siteId,await encryptSecret('domain-change-connection-secret-0123456789',f.env.ENCRYPTION_KEY,siteId),iso(Date.now()),iso(Date.now()));
  const change=(domain:string,key:string)=>f.call('/api/hosting-management/sites/'+siteId+'/domain-changes','POST',{domain,reason:'客户更换品牌域名',requestKey:key});
  const claim=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'owner-two.example.com',billing:'annual'},'owner2_park_0001','support'))).data;
  abandon(f,claim.site.id,10*60000);
  let response=await change('owner-two.example.com','squat_change_0001');assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  assert.equal(domainHolder(f,'owner-two.example.com'),'usr_support');
  // A change to a free domain waits for its TXT; the customer withdraws it and the domain is free again.
  response=await change('free-one.example.com','free_change_0001');assert.equal(response.status,202);const one=(await json(response)).data.domainChange;
  await reconcilePendingDomainChanges(f.env);assert.equal(String(f.db.sqlite.prepare('SELECT state FROM hosting_domain_changes WHERE id=?').get(one.id)!.state),'awaiting_ownership');
  response=await f.call('/api/hosting-management/sites/'+siteId+'/domain-changes/'+one.id+'/cancel','POST',{});assert.equal(response.status,200);
  assert.equal(domainHolder(f,'free-one.example.com'),null);assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.domain.change_cancelled' AND actor_id=?",f.user),1);
  // Another unproven change expires after 7 days (maintenance), audited, its domain freed.
  response=await change('free-two.example.com','free_change_0002');assert.equal(response.status,202);const two=(await json(response)).data.domainChange;
  f.db.sqlite.prepare('UPDATE hosting_domain_changes SET created_at=? WHERE id=?').run(iso(Date.now()-8*DAY),two.id);
  await reconcilePendingDomainChanges(f.env);
  assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_domain_changes WHERE id=?',two.id),0);assert.equal(domainHolder(f,'free-two.example.com'),null);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.domain.change_expired'"),1);
  // A change the provider was already asked to act on is never withdrawn this way.
  response=await change('free-three.example.com','free_change_0003');const three=(await json(response)).data.domainChange;
  f.db.sqlite.prepare('UPDATE hosting_domain_changes SET provider_attempted=1 WHERE id=?').run(three.id);
  response=await f.call('/api/hosting-management/sites/'+siteId+'/domain-changes/'+three.id+'/cancel','POST',{});assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_CHANGE_NOT_CANCELLABLE');
  f.db.sqlite.prepare('UPDATE hosting_domain_changes SET created_at=? WHERE id=?').run(iso(Date.now()-8*DAY),three.id);await reconcilePendingDomainChanges(f.env).catch(()=>null);
  assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_domain_changes WHERE id=?',three.id),1,'never expired once the provider was involved');
  f.db.sqlite.prepare('DELETE FROM hosting_domain_changes WHERE id=?').run(three.id);f.db.sqlite.prepare("DELETE FROM hosting_domains WHERE domain='free-three.example.com'").run();
  // R3-S3: a claim that never had a checkout, taken by a proven domain change: the notice says exactly that.
  f.db.sqlite.prepare('DELETE FROM alipay_payments WHERE order_id IN (SELECT id FROM orders WHERE hosting_site_id=?)').run(claim.site.id);
  f.db.sqlite.prepare('DELETE FROM orders WHERE hosting_site_id=?').run(claim.site.id);
  const record=(await json(await f.call('/api/hosting/domain-ownership?domain=owner-two.example.com'))).data.record;dns.set(record.name,record.value);
  response=await change('owner-two.example.com','squat_change_0002');assert.equal(response.status,202);assert.equal(domainHolder(f,'owner-two.example.com'),f.user);
  const notice=(await json(await f.call('/api/hosting/sites','GET',undefined,'k','support'))).data.releasedClaims[0];
  assert.equal(notice.reason,'claimed_by_other_account');assert.match(notice.message,/域名归属验证/);assert.match(notice.message,/域名变更/);assert.match(notice.message,/未生成有效付款链接/);
  assert.doesNotMatch(notice.message,/付款链接已过期|付款链接已关闭|开通了网站/);
 }finally{f.close();}
});

test('R3-1: a queued deferral request survives an open freeze; after the unfreeze the year moves behind the renewed term',async()=>{
 const f=await fixture();try{
  await f.payment();const M=Date.now()-3600_000;
  f.subscribe({id:'sub_cycle_1',included:1,startsMs:M-30*DAY,endsMs:M});
  const b=f.site('site_'+'k1'.repeat(16),'k1.example.com','connected',Date.now()-60*DAY);f.grant('ann_k1',b,'annual',M,Date.parse(addHostingYear(iso(M))));
  // The cycle invoice committed the renewal term and its durable request, but its follow-up did not run.
  f.subscribe({id:'sub_cycle_2',included:1,startsMs:M,endsMs:M+30*DAY});
  await deferralRequestStatement(f.env.DB,f.user,iso(M),'membership_term').run();
  assert.equal((await freezeMembership(f.env,'usr_owner',f.user,{reason:'争议核对期间冻结',requestKey:'r31-freeze-001'},{nowMs:Date.now()})).freeze?.state,'frozen');
  assert.equal((await processPendingHostingJobs(f.env)).rescheduled,0);
  assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_deferral_requests WHERE from_at=? AND attempts>=1',iso(M)),1,'postponed, not consumed');
  assert.equal(annualRows(f,b)[0].starts_at,iso(M));
  assert.equal((await unfreezeMembership(f.env,'usr_owner',f.user,{reason:'核对完成解冻',requestKey:'r31-unfreeze-1'},{nowMs:Date.now()})).freeze?.state,'completed');
  await processPendingHostingJobs(f.env);
  const renewed=String(f.db.sqlite.prepare("SELECT ends_at FROM subscriptions WHERE id='sub_cycle_2'").get()!.ends_at);
  assert.equal(annualRows(f,b)[0].starts_at,renewed,'no paid day under the renewed paid slot');assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_deferral_requests'),0);
 }finally{f.close();}
});

test('R3-2: a runner that read an older deferral request never deletes the one queued after it (fresh random revision on every write)',async()=>{
 const f=await fixture();try{
  const revision=()=>Number(f.db.sqlite.prepare('SELECT revision FROM hosting_deferral_requests WHERE user_id=?').get(f.user)!.revision);
  await deferralRequestStatement(f.env.DB,f.user,iso(Date.now()),'hosting_year').run();const r1=revision();
  await deferralRequestStatement(f.env.DB,f.user,iso(Date.now()+DAY),'hosting_year').run();assert.notEqual(revision(),r1);assert.ok(Number.isSafeInteger(revision()));
  // Runner A has read R1 and is about to delete it; runner B processes and deletes R1; then the unfreeze queues R2.
  let fired=false;
  const runnerA=new Proxy(f.db,{get(target,prop){
   if(prop==='prepare')return (sql:string)=>{const statement=target.prepare(sql);if(!sql.startsWith('DELETE FROM hosting_deferral_requests WHERE user_id=? AND revision=?'))return statement;
    return {bind:(...values:any[])=>{const bound=statement.bind(...values);return {run:async()=>{if(!fired){fired=true;await runDeferralRequest(f.env.DB,f.user);assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_deferral_requests'),0);
     await deferralRequestStatement(f.env.DB,f.user,iso(Date.now()-DAY),'membership_unfreeze').run();}return bound.run();}};}};};
   const value=(target as any)[prop];return typeof value==='function'?value.bind(target):value;}}) as unknown as D1Database;
  await runDeferralRequest(runnerA,f.user);
  assert.ok(fired);assert.equal(String(f.db.sqlite.prepare('SELECT reason FROM hosting_deferral_requests WHERE user_id=?').get(f.user)?.reason),'membership_unfreeze','R2 stays queued');
 }finally{f.close();}
});

test('R3-4: an anchored pay-first year moved behind the restored slot keeps one year from the opening, not its pre-opening days',async()=>{
 const f=await fixture();try{
  await f.payment();f.subscribe({included:2,state:'cancelled',autoRenew:0,endsMs:Date.now()+20*DAY});
  f.site('site_'+'a6'.repeat(16),'a6.example.com','connected',Date.now()-30*DAY);
  await freezeMembership(f.env,'usr_owner',f.user,{reason:'争议核对期间冻结',requestKey:'r34-freeze-001'},{nowMs:Date.now()});
  const created=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'r34c.example.com',billing:'annual'},'r34_create_0001'))).data,c=created.site.id;
  await f.pay(created.payment.orderId,'evt_r34c');
  await unfreezeMembership(f.env,'usr_owner',f.user,{reason:'核对完成解冻',requestKey:'r34-unfreeze-1'},{nowMs:Date.now()});
  f.db.sqlite.prepare("UPDATE sites SET state='connected' WHERE id=?").run(c);f.db.sqlite.prepare("UPDATE provisioning_jobs SET state='succeeded',step='done' WHERE site_id=?").run(c);
  await anchorAnnualActivations(f.env.DB,c,Date.now()+10*DAY);
  const restored=String(f.db.sqlite.prepare('SELECT ends_at FROM subscriptions WHERE user_id=?').get(f.user)!.ends_at),[year]=annualRows(f,c);
  assert.equal(year.starts_at,restored);assert.equal(year.ends_at,addHostingYear(restored),'exactly one year after the slot');
  assert.equal(String(f.db.sqlite.prepare('SELECT anchored_ends_at FROM hosting_annual_activations WHERE site_id=?').get(c)!.anchored_ends_at),year.ends_at);
  const audit=JSON.parse(String(f.db.sqlite.prepare("SELECT details_json FROM audit_logs WHERE action='hosting.annual.deferred'").get()!.details_json));assert.ok(audit.preOpeningDaysRemoved>9.9&&audit.preOpeningDaysRemoved<10.1);
  assert.equal((await processPendingHostingJobs(f.env)).rescheduled,0,'stable');
 }finally{f.close();}
});

test('R3-5: the summary labels the current range by what covers the site from now on, never by a membership part already past',async()=>{
 const f=await fixture();try{
  const M=Date.now()-3600_000;f.subscribe({included:1,state:'cancelled',autoRenew:0,startsMs:M-30*DAY,endsMs:M});
  const b=f.site('site_'+'k5'.repeat(16),'k5.example.com','connected',Date.now()-60*DAY);f.grant('ann_k5',b,'annual',M,Date.parse(addHostingYear(iso(M))));
  const [row]=await hostingBillingSummary(f.env.DB,f.user);
  assert.equal(row.coverage.current!.startsAt,iso(M-30*DAY));assert.deepEqual(row.coverage.current!.sources,['annual']);
  const list=(await json(await f.call('/api/hosting/sites'))).data.entitlement;assert.equal(list.membershipSitesUsed,0);
 }finally{f.close();}
});

/* ---- bint fix round 4: REVIEW-security4 (R4-S1, R4-m3, R4-m4) ---- */

test('R4-S1 (a): a membership site of another account stopped at the host ownership gate gives way to a TXT-proven owner in the create batch; unproven accounts and sites past the gate never take it',async()=>{
 const f=await fixture();try{
  await f.payment();const dns=dnsFake(f);f.subscribe({included:1});otherMember(f,'sub_admin_r4','usr_admin',3);
  const hold=async(domain:string,key:string,step='verify_domain_ownership')=>{
   const response=await f.call('/api/hosting/sites','POST',{...input,domain},key,'admin');assert.equal(response.status,202);
   const siteId=(await json(response)).data.site.id;
   f.db.sqlite.prepare("UPDATE provisioning_jobs SET state=?,step=?,error_code=?,lease_until=NULL WHERE site_id=?").run(step==='verify_domain_ownership'?'awaiting_input':'pending',step,step==='verify_domain_ownership'?'DOMAIN_OWNERSHIP_REQUIRED':null,siteId);
   return siteId;};
  const held=await hold('proven-owner.example.com','r4s1_hold_0001');
  // Without the TXT proof: refused with the proof code; the holder keeps the domain.
  let response=await f.call('/api/hosting/sites','POST',{...input,domain:'proven-owner.example.com'},'r4s1_try_00001');
  assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');assert.equal(domainHolder(f,'proven-owner.example.com'),'usr_admin');
  // With the proof: the owner's create goes through and the unverified site is removed in the same batch.
  const record=(await json(await f.call('/api/hosting/domain-ownership?domain=proven-owner.example.com'))).data.record;dns.set(record.name,record.value);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'proven-owner.example.com'},'r4s1_try_00002');
  assert.equal(response.status,202);assert.equal(domainHolder(f,'proven-owner.example.com'),f.user);
  assert.equal(count(f,'SELECT COUNT(*) n FROM sites WHERE id=?',held),0);assert.equal(count(f,'SELECT COUNT(*) n FROM provisioning_jobs WHERE site_id=?',held),0);
  const audit=f.db.sqlite.prepare("SELECT actor_id,details_json FROM audit_logs WHERE action='hosting.unverified_site_released'").all() as {actor_id:string;details_json:string}[];
  assert.equal(audit.length,1);assert.equal(audit[0].actor_id,f.user);
  const details=JSON.parse(audit[0].details_json);assert.deepEqual([details.userId,details.displacedBy,details.path,details.ownershipProven],['usr_admin',f.user,'membership',true]);
  const notice=(await json(await f.call('/api/hosting/sites','GET',undefined,'k','admin'))).data.releasedClaims[0];
  assert.equal(notice.domain,'proven-owner.example.com');assert.equal(notice.reason,'claimed_by_other_account');assert.match(notice.message,/域名归属验证/);assert.doesNotMatch(notice.message,/usr_|@example/);
  // A site whose job already passed the gate (the host was asked to create the website) is never displaced.
  await hold('past-gate.example.com','r4s1_hold_0002','wait_website_setup');
  const second=(await json(await f.call('/api/hosting/domain-ownership?domain=past-gate.example.com'))).data.record;dns.set(second.name,second.value);
  otherMember(f,'sub_user_r4b',f.user,3);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'past-gate.example.com'},'r4s1_try_00003');
  assert.equal(response.status,409);assert.equal((await json(response)).error.code,'SITE_CONFLICT');assert.equal(domainHolder(f,'past-gate.example.com'),'usr_admin');
 }finally{f.close();}
});

test('R4-S1 (b) / R4-m4: a pending domain change of another account gives way to a TXT-proven owner; a change whose TXT check passed never does, and never expires',async()=>{
 const f=await fixture();try{
  await f.payment();const dns=dnsFake(f);f.subscribe({included:1});otherMember(f,'sub_support_r4','usr_support',2);
  const siteId=f.site('site_'+'c4'.repeat(16),'live-c4.example.com','connected',Date.now()-30*DAY);
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_c4',?,'https://live-c4.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(siteId,await encryptSecret('domain-change-connection-secret-0123456789',f.env.ENCRYPTION_KEY,siteId),iso(Date.now()),iso(Date.now()));
  const change=(domain:string,key:string)=>f.call('/api/hosting-management/sites/'+siteId+'/domain-changes','POST',{domain,reason:'客户更换品牌域名',requestKey:key});
  let response=await change('victim-c4.example.com','r4s2_change_0001');assert.equal(response.status,202);
  await reconcilePendingDomainChanges(f.env);assert.equal(domainHolder(f,'victim-c4.example.com'),f.user);
  // Unproven: refused with the proof code.
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'victim-c4.example.com'},'r4s2_try_00001','support');
  assert.equal(response.status,409);assert.equal((await json(response)).error.code,'DOMAIN_OWNERSHIP_PROOF_REQUIRED');
  // Proven: the change is removed with its domain row; the live site keeps its own domain.
  const record=(await json(await f.call('/api/hosting/domain-ownership?domain=victim-c4.example.com','GET',undefined,'k','support'))).data.record;dns.set(record.name,record.value);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'victim-c4.example.com'},'r4s2_try_00002','support');
  assert.equal(response.status,202);assert.equal(domainHolder(f,'victim-c4.example.com'),'usr_support');
  assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_domain_changes WHERE site_id=?',siteId),0);assert.equal(domainHolder(f,'live-c4.example.com'),f.user);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.domain.change_displaced' AND actor_id='usr_support'"),1);
  const notice=(await json(await f.call('/api/hosting/sites'))).data.releasedClaims[0];
  assert.equal(notice.domain,'victim-c4.example.com');assert.match(notice.message,/域名变更/);assert.match(notice.message,/原域名/);
  // R4-m4: a change whose TXT check passed (then stopped before the provider) is neither displaced nor expired.
  response=await change('mine-c4.example.com','r4s2_change_0002');assert.equal(response.status,202);const mine=(await json(response)).data.domainChange;
  f.db.sqlite.prepare("UPDATE hosting_domain_changes SET state='uncertain',error_code='DOMAIN_CHANGE_RESTRICTED',ownership_verified_at=?,created_at=? WHERE id=?").run(iso(Date.now()),iso(Date.now()-8*DAY),mine.id);
  const other=(await json(await f.call('/api/hosting/domain-ownership?domain=mine-c4.example.com','GET',undefined,'k','support'))).data.record;dns.set(other.name,other.value);
  response=await f.call('/api/hosting/sites','POST',{...input,domain:'mine-c4.example.com'},'r4s2_try_00003','support');
  assert.equal(response.status,409);assert.equal((await json(response)).error.code,'SITE_CONFLICT');
  const {expireUnverifiedDomainChanges}=await import('../src/modules/hosting-management');await expireUnverifiedDomainChanges(f.env);
  assert.equal(count(f,'SELECT COUNT(*) n FROM hosting_domain_changes WHERE id=?',mine.id),1);assert.equal(domainHolder(f,'mine-c4.example.com'),f.user);
 }finally{f.close();}
});

test('R4-m3: the notice for an expired claim says whether it ever had a payment link',async()=>{
 const f=await fixture();try{
  await f.payment();
  const claim=(await json(await f.call('/api/hosting/sites','POST',{...input,domain:'expired-m3.example.com',billing:'annual'},'m3_park_00001'))).data;
  f.db.sqlite.prepare('UPDATE orders SET checkout_id=NULL WHERE hosting_site_id=?').run(claim.site.id);
  abandon(f,claim.site.id,25*3600000);
  const {releaseParkedSite}=await import('../src/modules/hosting');
  await releaseParkedSite(f.env,f.user,claim.job.id,'expired');
  const notice=(await json(await f.call('/api/hosting/sites'))).data.releasedClaims[0];
  assert.equal(notice.reason,'expired');assert.match(notice.message,/未生成有效付款链接/);assert.doesNotMatch(notice.message,/付款链接已关闭/);
 }finally{f.close();}
});
