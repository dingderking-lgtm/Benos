import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync,readdirSync } from 'node:fs';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';
import { FakeR2,png } from './media-helper';
import { id } from '../src/lib/crypto';

async function fixture(db=new TestD1()){
 const env=testEnv(db),storage=new FakeR2();env.BUCKET=storage as unknown as R2Bucket;
 const headers:Record<string,string>={origin:env.APP_ORIGIN,'content-type':'application/json'};
 const boot=await app.request('/api/bootstrap',{method:'POST',headers,body:JSON.stringify({token:env.BOOTSTRAP_TOKEN,email:'management@example.test',password:'content-management-password',name:'Owner'})},env),auth=await boot.json() as any;
 assert.equal(boot.status,201);headers.cookie=boot.headers.get('set-cookie')!.split(';')[0];headers['x-csrf-token']=auth.data.csrfToken;
 const request=(path:string,method='GET',value?:unknown)=>app.request(path,{method,headers,body:value===undefined?undefined:JSON.stringify(value)},env);
 const create=async(kind:string,slug:string,content:any={body:'正文'},title=slug)=>{const response=await request('/api/admin/content','POST',{kind,slug,title,content});assert.equal(response.status,201,await response.clone().text());return (await response.json() as any).data;};
 const action=async(item:any,name:string)=>{const response=await request('/api/admin/content/'+item.id+(name==='trash'?'':'/'+name),name==='trash'?'DELETE':'POST',{revision:item.revision});return {response,row:(await response.clone().json() as any).data};};
 const upload=async(requestKey='content_upload_001')=>{const bytes=png(2,3),response=await app.request('/api/admin/content/media',{method:'POST',headers:{...headers,'content-type':'image/png','x-filename':'cover.png','idempotency-key':requestKey},body:bytes},env);return {response,data:(await response.clone().json() as any).data};};
 return {db,env,storage,headers,request,create,action,upload};
}
test('0023 migration preserves existing content, revisions, published slug guard and foreign keys',()=>{
 const db=new DatabaseSync(':memory:');try{
  for(const file of readdirSync('migrations').filter(file=>file.endsWith('.sql')&&file<'0023_content_management.sql').sort())db.exec(readFileSync('migrations/'+file,'utf8'));
  db.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES('migration-owner','m@example.test','owner','hash','owner','now','now')").run();
  db.prepare("INSERT INTO content_entries(id,kind,slug,title,draft_json,published_json,state,created_by,created_at,updated_at) VALUES('old','post','old','Original',?,?, 'published','migration-owner','now','now')").run('{"body":"draft","slug":"new"}','{"body":"live","slug":"old"}');
  db.prepare("INSERT INTO content_revisions(id,entry_id,revision,content_json,actor_id,created_at) VALUES('revision','old',1,'{}','migration-owner','now')").run();
  db.exec('BEGIN');db.exec(readFileSync('migrations/0023_content_management.sql','utf8'));db.exec('COMMIT');
  assert.equal(db.prepare('SELECT title FROM content_entries WHERE id=?').get('old')!.title,'Original');assert.equal(db.prepare('SELECT COUNT(*) n FROM content_revisions').get()!.n,1);assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
  assert.throws(()=>db.prepare("INSERT INTO content_entries SELECT 'duplicate',kind,'different',title,draft_json,published_json,state,revision,created_by,created_at,updated_at,published_at,deleted_at FROM content_entries WHERE id='old'").run(),/UNIQUE/);
 }finally{db.close();}
});
test('Sites schema-only upgrade retains the original six-kind CHECK and existing rows while tags work through API',async()=>{
 const sqlite=new DatabaseSync(':memory:');
 for(const file of readdirSync('migrations').filter(file=>file.endsWith('.sql')&&!['0023_content_management.sql','0025_content_tag_compatibility.sql'].includes(file)).sort())sqlite.exec(readFileSync('migrations/'+file,'utf8'));
 const adapter=Object.assign(Object.create(TestD1.prototype),{sqlite}) as TestD1,f=await fixture(adapter);
 try{
  const original={id:id('cnt')},actor=sqlite.prepare('SELECT id FROM users LIMIT 1').get()!.id,snapshot=JSON.stringify({slug:'kept-page',title:'Original',body:'Original draft'});
  sqlite.prepare("INSERT INTO content_entries(id,kind,slug,title,draft_json,published_json,state,created_by,created_at,updated_at) VALUES(?,'page','kept-page','Original',?,?,'published',?,'before','before')").run(original.id,snapshot,snapshot,actor);
  sqlite.prepare('INSERT INTO content_revisions(id,entry_id,revision,content_json,actor_id,created_at) VALUES(?,?,1,?,?,?)').run(id('rev'),original.id,snapshot,actor,'before');
  const before=sqlite.prepare('SELECT * FROM content_entries WHERE id=?').get(original.id),revisions=sqlite.prepare('SELECT COUNT(*) n FROM content_revisions WHERE entry_id=?').get(original.id)!.n;
  const full=readFileSync('migrations/0023_content_management.sql','utf8'),schemaOnly=full.slice(full.indexOf('CREATE TABLE content_media'),full.indexOf('PRAGMA defer_foreign_keys = OFF;'));
  assert.ok(!/\b(?:INSERT|UPDATE|DELETE)\b/i.test(schemaOnly));sqlite.exec(schemaOnly);sqlite.exec(readFileSync('migrations/0025_content_tag_compatibility.sql','utf8'));
  const after=sqlite.prepare('SELECT * FROM content_entries WHERE id=?').get(original.id)!;assert.equal(after.kind_override,null);delete after.kind_override;assert.deepEqual(after,before);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM content_revisions WHERE entry_id=?').get(original.id)!.n,revisions);
  const schema=sqlite.prepare("SELECT sql FROM sqlite_master WHERE name='content_entries'").get()!.sql as string;assert.ok(schema.includes("'banner','category')"),'old CHECK is unchanged');
  let category=await f.create('category','shared-slug'),tag=await f.create('tag','shared-slug');category=(await f.action(category,'publish')).row;tag=(await f.action(tag,'publish')).row;
  const stored=sqlite.prepare('SELECT kind,kind_override,slug FROM content_entries WHERE id=?').get(tag.id)!;assert.deepEqual({...stored},{kind:'category',kind_override:'tag',slug:'@tag/shared-slug'});assert.equal(tag.kind,'tag');assert.equal(tag.slug,'shared-slug');
  assert.equal((await f.request('/tag/shared-slug')).status,200);assert.equal((await f.request('/category/shared-slug')).status,200);
  const rows=(await (await f.request('/api/admin/content?kind=category')).json() as any).data.items;assert.ok(rows.some((item:any)=>item.id===category.id));assert.ok(!rows.some((item:any)=>item.id===tag.id));assert.deepEqual(sqlite.prepare('PRAGMA foreign_key_check').all(),[]);
 }finally{f.db.close();}
});
test('tags are published independently, linked articles render taxonomy and draft/public references prevent deletion',async()=>{
 const f=await fixture();try{
  let tag=await f.create('tag','design-label'),post=await f.create('post','tagged',{body:'Tagged body',tagIds:[tag.id]});
  assert.equal((await f.action(post,'publish')).response.status,409);tag=(await f.action(tag,'publish')).row;post=(await f.action(post,'publish')).row;
  const page=await f.request('/tag/design-label');assert.equal(page.status,200);assert.ok((await page.text()).includes('/blog/tagged'));
  assert.ok((await (await f.request('/blog/tagged')).text()).includes('/tag/design-label'));
  assert.equal((await f.action(tag,'trash')).response.status,409);
  const patch=await f.request('/api/admin/content/'+post.id,'PATCH',{kind:'post',slug:'tagged',title:'tagged',revision:post.revision,content:{body:'Draft without tags',tagIds:[]}});post=(await patch.json() as any).data;
  assert.equal((await f.action(tag,'trash')).response.status,409,'published snapshot still references the tag');
  post=(await f.action(post,'unpublish')).row;assert.equal((await f.action(tag,'trash')).response.status,200);assert.equal((await f.request('/tag/design-label')).status,404);
 }finally{f.db.close();}
});
test('server content search, taxonomy filters and stable title/position pagination operate beyond first page',async()=>{
 const f=await fixture();try{
  const owner=f.db.sqlite.prepare('SELECT id FROM users LIMIT 1').get()!.id,tag=await f.create('tag','filter-tag'),category=await f.create('category','filter-category');
  for(let n=0;n<105;n++){const value=JSON.stringify({title:'相同标题',slug:'search-'+n,body:'唯一正文关键词',tagIds:[tag.id],categoryId:category.id,position:105-n});f.db.sqlite.prepare("INSERT INTO content_entries(id,kind,slug,title,draft_json,created_by,created_at,updated_at) VALUES(?,'post',?,'相同标题',?,?,?,?)").run(id('cnt'),'search-'+n,value,owner,'2026-11-07','2026-11-07');}
  const query='?q='+encodeURIComponent('唯一正文')+'&kind=post&sort=title_asc&tagId='+tag.id+'&categoryId='+category.id;
  const first=(await (await f.request('/api/admin/content'+query)).json() as any).data,second=(await (await f.request('/api/admin/content'+query+'&cursor='+encodeURIComponent(first.nextCursor))).json() as any).data;
  assert.equal(first.items.length,100);assert.equal(second.items.length,5);assert.equal(new Set([...first.items,...second.items].map(row=>row.id)).size,105);
  assert.equal((await f.request('/api/admin/content?sort=position_asc&cursor='+encodeURIComponent(first.nextCursor))).status,400,'cursor cannot silently switch sort/filter');
  const ordered=(await (await f.request('/api/admin/content?kind=post&sort=position_asc')).json() as any).data;assert.equal(ordered.items[0].content.position,1);
 }finally{f.db.close();}
});
test('bulk actions reuse per-item revision and dependency guards and report partial results',async()=>{
 const f=await fixture();try{
  const category=await f.create('category','bulk-category');await f.create('post','dependent',{body:'body',categoryId:category.id});const free=await f.create('faq','free'),stale=await f.create('faq','stale');
  const response=await f.request('/api/admin/content/bulk','POST',{action:'trash',items:[{id:category.id,revision:category.revision},{id:free.id,revision:free.revision},{id:stale.id,revision:999}]});assert.equal(response.status,200);const rows=(await response.json() as any).data.items;
  assert.deepEqual(rows.map((row:any)=>row.ok),[false,true,false]);assert.equal(f.db.sqlite.prepare('SELECT state FROM content_entries WHERE id=?').get(free.id)!.state,'trashed');assert.equal(f.db.sqlite.prepare('SELECT state FROM content_entries WHERE id=?').get(stale.id)!.state,'draft');
  assert.equal((await app.request('/api/admin/content/bulk',{method:'POST',headers:{origin:f.env.APP_ORIGIN,'content-type':'application/json'},body:'{}'},f.env)).status,401);
 }finally{f.db.close();}
});
test('saved draft preview is authenticated, escaped, noindex and never mutates the public snapshot',async()=>{
 const f=await fixture();try{
  let post=await f.create('post','preview-entry',{body:'Public body'});post=(await f.action(post,'publish')).row;
  await f.request('/api/admin/content/'+post.id,'PATCH',{kind:'post',slug:'preview-entry',title:'Draft title',revision:post.revision,content:{body:'<script>steal()</script> private draft'}});
  const path='/api/admin/content/'+post.id+'/preview',response=await f.request(path);assert.equal(response.status,200);const html=await response.text();assert.ok(html.includes('&lt;script&gt;'));assert.ok(html.includes('private draft'));assert.ok(response.headers.get('content-security-policy')!.includes("default-src 'none'"));assert.equal(response.headers.get('x-robots-tag'),'noindex,nofollow');
  assert.equal((await app.request(path,{},f.env)).status,401);assert.ok(!(await (await f.request('/blog/preview-entry')).text()).includes('private draft'));
 }finally{f.db.close();}
});
test('marketing media stays private until referenced publication, revokes anonymous reads on unpublish and protects references',async()=>{
 const f=await fixture();try{
  const uploaded=await f.upload();assert.equal(uploaded.response.status,201);const media=uploaded.data;
  assert.equal((await app.request(media.publicUrl,{},f.env)).status,404);assert.equal((await app.request(media.previewUrl,{},f.env)).status,401);assert.equal((await f.request(media.previewUrl)).status,200);
  let post=await f.create('post','media-entry',{body:'body',coverMediaId:media.id});assert.equal(post.content.coverUrl,media.publicUrl);
  assert.equal((await app.request(media.publicUrl,{},f.env)).status,404);assert.equal((await f.request('/api/admin/content/media/'+media.id+'/delete','POST',{revision:media.revision})).status,409);
  post=(await f.action(post,'publish')).row;const publicFile=await app.request(media.publicUrl,{},f.env);assert.equal(publicFile.status,200);assert.equal(publicFile.headers.get('cache-control'),'private, no-store');
  post=(await f.action(post,'unpublish')).row;assert.equal((await app.request(media.publicUrl,{},f.env)).status,404);assert.equal((await f.request('/api/admin/content/media/'+media.id+'/delete','POST',{revision:media.revision})).status,409,'unpublished draft still protects media');
  await f.action(post,'trash');const deleted=await f.request('/api/admin/content/media/'+media.id+'/delete','POST',{revision:media.revision});assert.equal(deleted.status,200);const row=(await deleted.json() as any).data;
  assert.equal((await f.request('/api/admin/content/media/'+media.id+'/restore','POST',{revision:row.revision})).status,200);assert.equal((await app.request(media.publicUrl,{},f.env)).status,404,'restore does not make unreferenced media public');
 }finally{f.db.close();}
});
test('media upload lost acknowledgement is safely retried; forged URL, staging reference and mixed bulk are rejected per item',async()=>{
 const f=await fixture();try{
  f.storage.failAfter=true;assert.equal((await f.upload()).response.status,500);const retried=await f.upload();assert.equal(retried.response.status,201);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM content_media').get()!.n,1);
  const media=retried.data,forged=await f.request('/api/admin/content','POST',{kind:'post',slug:'forged',title:'forged',content:{body:'body',coverUrl:media.publicUrl}});assert.equal(forged.status,400);
  const unknown=await f.request('/api/admin/content','POST',{kind:'post',slug:'unknown',title:'unknown',content:{body:'body',coverMediaId:id('cmedia')}});assert.equal(unknown.status,409);
  await f.create('banner','protected',{body:'body',placement:'home',coverMediaId:media.id});const free=(await f.upload('content_upload_002')).data;
  const batch=await f.request('/api/admin/content/media/bulk','POST',{action:'delete',items:[{id:media.id,revision:1},{id:free.id,revision:1}]});assert.deepEqual((await batch.json() as any).data.items.map((item:any)=>item.ok),[false,true]);
 }finally{f.db.close();}
});
test('navigation and banner positions require an actual rendering location; publication uses full-list display order',async()=>{
 const f=await fixture();try{
  for(const [kind,placement] of [['navigation','home'],['banner','footer']])assert.equal((await f.request('/api/admin/content','POST',{kind,slug:'bad-'+kind,title:'invalid',content:{body:'body',placement}})).status,400);
  const a=await f.create('faq','faq-first',{body:'First',position:1}),b=await f.create('faq','faq-second',{body:'Second',position:99});await f.action(a,'publish');await f.action(b,'publish');const html=await (await f.request('/faq')).text();assert.ok(html.indexOf('faq-first')<html.indexOf('faq-second'));
 }finally{f.db.close();}
});
