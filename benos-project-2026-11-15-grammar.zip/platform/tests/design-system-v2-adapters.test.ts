import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { parseFragment } from 'parse5';
import { renderAdaptedAction, adaptedAspectGeometry, BENCHO_ASPECT_SHAPES, renderAdaptedFaq, renderAdaptedFooterGroups, renderAdaptedCard, adaptedAccentStyle, getAdaptedPrimitiveCss, adaptedPrimitivesFingerprint, getAdaptedSourceIdsForPattern } from '../src/design-system/v2/adapted-primitives';
import { V2_SOURCE_IDS, getV2Adaptations, getV2Sources, getV2Notices, assertV2SourceAdaptersReady } from '../src/design-system/v2/provenance';
import { V2_PATTERN_DEFINITIONS } from '../src/design-system/v2/contracts';

function nodes(html: string): any[] { const out: any[] = []; function walk(node: any) { if (node.tagName) out.push(node); for (const child of node.childNodes || []) walk(child); } walk(parseFragment(html)); return out; }
const attr = (node: any, name: string) => node.attrs?.find((a: any) => a.name === name)?.value;
const sourceFile = (id: string, file: string) => readFileSync(resolve('vendor/design-sources', id, 'upstream', file));
const sha = (bytes: string | Buffer) => createHash('sha256').update(bytes).digest('hex');

test('all six adaptations bind real pinned source bytes, exact original line spans, target exports and modification notices', () => {
  const records = getV2Adaptations(); assert.equal(records.length, 6);
  assert.equal(records.reduce((n, a) => n + a.sourceFiles.length, 0), 8);
  const target = readFileSync(resolve('src/design-system/v2/adapted-primitives.ts'), 'utf8');
  for (const record of records) {
    assert.ok(record.targetExports.length); assert.deepEqual(record.runtimePackages, []);
    for (const symbol of record.targetExports) assert.ok(target.includes(`function ${symbol}(`));
    for (const file of record.sourceFiles) {
      const body = sourceFile(record.sourceId, file.path); assert.equal(sha(body), file.sha256);
      const lines = body.toString('utf8').replace(/\r\n/g, '\n').split('\n');
      for (const region of file.regions) assert.equal(lines.slice(region.startLine - 1, region.endLine).join('\n'), region.excerpt);
    }
    assert.equal(sha(record.modificationNotice.text), record.modificationNotice.sha256);
    assert.ok(record.modificationNotice.text.includes('Modified') || record.modificationNotice.text.includes('modified 2026-11-14'));
    const notices = getV2Notices([record.sourceId]); assert.ok(notices.some(n => n.path === 'LICENSE')); assert.ok(notices.some(n => n.path.startsWith('BENOS-MODIFICATIONS-')));
    for (const notice of notices) assert.equal(sha(notice.text), notice.sha256);
  }
});

test('source readiness is derived from built-in helper implementation; unknown/client data cannot unlock it', () => {
  assert.doesNotThrow(() => assertV2SourceAdaptersReady(V2_SOURCE_IDS));
  assert.throws(() => assertV2SourceAdaptersReady([]), /BNX_SOURCE_ADAPTERS_REQUIRED/);
  assert.throws(() => assertV2SourceAdaptersReady(['unapproved-pro']), /BNX_SOURCE_UNKNOWN/);
  const copy = getV2Sources(['boardui']); (copy[0] as any).adaptedFiles = []; (copy[0] as any).adapterReady = false;
  assert.equal(getV2Sources(['boardui'])[0].adapterReady, true); assert.ok(getV2Sources(['boardui'])[0].adaptedFiles.length);
  assert.throws(() => getAdaptedPrimitiveCss(['unapproved-pro']), /BNX_ADAPTER_SOURCE_UNKNOWN/);
});

test('BoardUI action slots use real safe links, wrapped labels and no arbitrary markup or executable URL', () => {
  const html = renderAdaptedAction({ label: '<strong>Get quote</strong>', href: '/contact?a=1&b=2', kind: 'secondary' }), dom = nodes(html);
  assert.equal(dom[0].tagName, 'a'); assert.equal(attr(dom[0], 'href'), '/contact?a=1&b=2');
  assert.equal(dom.some(node => node.tagName === 'strong'), false); assert.equal(dom.filter(node => node.tagName === 'span').length, 2);
  assert.ok(html.includes('bnx-ap-button-secondary')); assert.ok(html.includes('aria-hidden="true"'));
  assert.throws(() => renderAdaptedAction({ label: 'Click', href: 'javascript:alert(1)' }));
  assert.throws(() => renderAdaptedAction({ label: 'Click', href: '/contact', kind: 'bogus' as any }));
  assert.match(getAdaptedPrimitiveCss(['boardui']), /min-height:52px/);
});

test('Bencho formats retain the original equal-area constants while native media keeps exact geometry', () => {
  const original = sourceFile('bencho', 'blocks/aspect/Aspect.tsx').toString();
  for (const shape of Object.values(BENCHO_ASPECT_SHAPES)) assert.ok(original.includes(`w: ${shape.width}, h: ${shape.height}`));
  const areas = Object.values(BENCHO_ASPECT_SHAPES).map(s => s.width * s.height);
  assert.ok((Math.max(...areas) - Math.min(...areas)) / Math.max(...areas) < .0002);
  for (const [width, height] of [[2000, 700], [700, 2000], [900, 900]]) assert.deepEqual([adaptedAspectGeometry({ width, height }).width, adaptedAspectGeometry({ width, height }).height], [width, height]);
  assert.deepEqual([adaptedAspectGeometry({ width: 276, height: 276, format: 'portrait' }).width, adaptedAspectGeometry({ width: 276, height: 276, format: 'portrait' }).height], [207, 276]);
  assert.throws(() => adaptedAspectGeometry({ width: 0, height: 2 })); assert.throws(() => adaptedAspectGeometry({ width: 10, height: 10, format: 'url(evil)' as any }));
});

test('BeUI native details start closed and preserve all question/answer text without script state', () => {
  const html = renderAdaptedFaq([{ question: 'How <soon>?', answer: 'It depends on the agreed brief.' }]), dom = nodes(html), details = dom.find(n => n.tagName === 'details');
  assert.ok(details); assert.equal(attr(details, 'open'), undefined); assert.equal(dom.filter(n => n.tagName === 'summary').length, 1);
  assert.equal(dom.some(n => n.tagName === 'button' || n.tagName === 'script'), false); assert.equal(/aria-expanded=/.test(html), false);
  assert.ok(html.includes('How &lt;soon&gt;?')); assert.match(getAdaptedPrimitiveCss(['beui']), /min-height:54px/);
});

test('Watermelon groups keep directory links but cannot introduce a fake newsletter or raw callback', () => {
  const html = renderAdaptedFooterGroups([{ title: 'Explore', links: [{ label: 'Products', href: '/products' }, { label: 'Contact', href: '/contact' }] }], 'Footer'), dom = nodes(html);
  assert.equal(dom[0].tagName, 'nav'); assert.equal(dom.filter(n => n.tagName === 'a').length, 2); assert.equal(dom.some(n => ['form', 'input', 'button'].includes(n.tagName)), false);
  assert.equal(renderAdaptedFooterGroups([], 'Empty'), ''); assert.throws(() => renderAdaptedFooterGroups([{ title: 'Oops', links: [{ label: 'Unsafe', href: 'javascript:alert(1)' }] }], 'Footer'));
});

test('HeroUI card slots preserve title, body, optional labels and footer without adding website headers/footers', () => {
  const html = renderAdaptedCard({ title: 'Card', text: 'All body text', label: 'Category', value: 'Verified value', href: '/detail', footer: 'Footnote', index: 2 }), dom = nodes(html);
  assert.equal(dom[0].tagName, 'article'); assert.equal(dom.some(n => n.tagName === 'header' || n.tagName === 'footer'), false);
  for (const fragment of ['Category', 'Verified value', 'All body text', 'Footnote', 'bnx-ap-card-header', 'bnx-ap-card-content', 'bnx-ap-card-footer']) assert.ok(html.includes(fragment));
  assert.throws(() => renderAdaptedCard({ title: 'Card', text: 'Body', href: '//external.test' }));
});

test('Libraries.dev static radial builder uses source ellipse data and bounded colors/radii without a driver', () => {
  const result = adaptedAccentStyle({ accent: '#336699', surface: '#ffffff', radius: 16, borderWidth: 2 });
  assert.equal(result.innerRadius, 14); assert.equal((result.gradient.match(/radial-gradient/g) || []).length, 4);
  for (const value of ['2% 68%', '72% -3%', '74% 100%', '100% 27%', '9px 18px', '59px 9px', '42px 7px', '10px 17px']) assert.ok(sourceFile('libraries-dev', 'packages/border-beam/src/styles.ts').toString().includes(value));
  assert.equal(/animation|@keyframes|url\(|script|mask/.test(result.style), false);
  assert.throws(() => adaptedAccentStyle({ accent: '#fff; background:url(evil)', surface: '#ffffff' }));
  assert.throws(() => adaptedAccentStyle({ accent: '#336699', surface: '#ffffff', radius: Infinity }));
});

test('each pattern declares only its actual local adapter dependencies and fingerprints their code/CSS', () => {
  for (const family of V2_PATTERN_DEFINITIONS) assert.deepEqual(family.sourceIds, getAdaptedSourceIdsForPattern(family.id));
  assert.deepEqual(getAdaptedSourceIdsForPattern('faq'), ['boardui', 'beui']);
  assert.ok(!getAdaptedPrimitiveCss(['boardui']).includes('bnx-ap-card'));
  assert.notEqual(adaptedPrimitivesFingerprint(['boardui']), adaptedPrimitivesFingerprint(['boardui', 'beui']));
  const css = getAdaptedPrimitiveCss(V2_SOURCE_IDS);
  assert.equal(/@import|@font-face|url\(|@apply|@keyframes/.test(css), false);
  assert.equal(getAdaptedPrimitiveCss(['boardui', 'boardui']), getAdaptedPrimitiveCss(['boardui']));
});
