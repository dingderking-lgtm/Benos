import test from 'node:test';
import assert from 'node:assert/strict';
import { COMPILED_BODY_PALETTE_VERSION,createCompiledBodyPalette,inheritCompiledBodyPalette,foundationWithCompiledBodyPalette,materializeCompiledBodyPalette } from '../src/lib/compiled-body-palette';
import { createDesignFoundation,foundationAuthoringExample,materializeDesignFoundation,inheritDesignFoundation } from '../src/contracts/design-foundation';
import { createDesignOrder } from '../src/contracts/design-order';
import { DESIGN_STYLES } from '../src/contracts/design-style-catalog';
import { V2_PRESETS,createWebsiteTokenSnapshot,type V2Preset } from '../src/design-system/v2/contracts';
import { foundationContrast } from '../src/contracts/design-coherence';
import { headerCssIsolationIssues } from '../src/lib/site-header-materialization';
import { compileSiteHeader,resolveSiteHeader } from '../src/contracts/site-header';
import { createRequire } from 'node:module';
import { existsSync,mkdirSync,writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const original=createDesignFoundation(DESIGN_STYLES.find(s=>s.id==='editorial')!,'palette-test',{designOrder:createDesignOrder({request:'企业官网'})});
const paletteFor=(preset:V2Preset)=>createCompiledBodyPalette({version:'bnx-generation-1',preset,tokens:createWebsiteTokenSnapshot(preset)})!;
const requirements=(palette:any)=>({compiledBodyPolicy:'bnx-owned-1',compiledBodyPaletteVersion:COMPILED_BODY_PALETTE_VERSION,compiledBodyPalette:palette});
function tokens(css:string){const result:Record<string,string>={};for(const root of css.matchAll(/:root\s*\{([^}]+)\}/g))for(const m of root[1].matchAll(/(--[\w-]+):([^;}]+)/g))result[m[1]]=m[2];return result;}

test('all reviewed palettes provide matched foundation/header text and preserve fonts',()=>{
 for(const preset of V2_PRESETS){const palette=paletteFor(preset),profile=foundationWithCompiledBodyPalette(original,palette),m=materializeDesignFoundation(foundationAuthoringExample(profile),profile),out=materializeCompiledBodyPalette(m,requirements(palette)),t=tokens(out.site.theme.global_css);
  assert.equal(t['--bnf-bg'],palette.colors.background);assert.equal(t['--bnf-ink'],palette.colors.text);assert.equal(t['--bnf-surface'],palette.colors.surface);assert.equal(t['--bnf-accent-ink'],palette.colors.accentText);
  assert.ok(foundationContrast(t['--bnf-bg'],t['--bnf-ink'])>=4.5);assert.ok(foundationContrast(t['--bnf-surface'],t['--bnf-ink'])>=4.5);assert.ok(foundationContrast(t['--bnf-accent'],t['--bnf-accent-ink'])>=4.5);
  assert.equal(profile.tokens.headingFont,original.tokens.headingFont);assert.equal(profile.tokens.bodyFont,original.tokens.bodyFont);assert.deepEqual(out.templates,m.templates);assert.deepEqual(out.assets,m.assets);assert.deepEqual(materializeCompiledBodyPalette(out,requirements(palette)),out);
  assert.deepEqual(headerCssIsolationIssues(out,{templateId:3} as any),[]);
 }
});
test('Mercedes dark background plus old editorial ink is repaired only with explicit capability',()=>{
 const m:any=foundationAuthoringExample(original);m.site.theme.brand_background='#111b26';m.site.theme.brand_color='#a9d6ec';const before=materializeDesignFoundation(m,original),palette=paletteFor('deep-studio');
 assert.ok(foundationContrast(tokens(before.site.theme.global_css)['--bnf-bg'],tokens(before.site.theme.global_css)['--bnf-ink'])<1.1);
 assert.equal(materializeCompiledBodyPalette(before,{}),before);assert.equal(materializeCompiledBodyPalette(before,{compiledBodyPalette:palette}),before);
 const after=materializeCompiledBodyPalette(before,requirements(palette));assert.ok(foundationContrast(tokens(after.site.theme.global_css)['--bnf-bg'],tokens(after.site.theme.global_css)['--bnf-ink'])>16);
 const inherited=inheritDesignFoundation(after,original)!;const replay=materializeCompiledBodyPalette(materializeDesignFoundation(after,inherited),requirements(palette));assert.equal(replay.site.theme.global_css,after.site.theme.global_css);
});
test('valid later theme colors and manual text/font overrides are not reset to the preset',()=>{
 const palette=paletteFor('deep-studio'),profile=foundationWithCompiledBodyPalette(original,palette),m:any=materializeDesignFoundation(foundationAuthoringExample(profile),profile);m.site.theme.brand_background='#ffffff';m.site.theme.brand_color='#9333ea';m.templates[1].document.html='<section style="color:#963210;font-family:Georgia"><h1>保留手动样式</h1></section>';
 const before=JSON.stringify(m.templates),out=materializeCompiledBodyPalette(m,requirements(palette)),t=tokens(out.site.theme.global_css);
 assert.equal(t['--bnf-bg'],'#ffffff');assert.equal(t['--bnf-accent'],'#9333ea');assert.ok(foundationContrast(t['--bnf-bg'],t['--bnf-ink'])>=4.5);assert.ok(foundationContrast(t['--bnf-surface'],t['--bnf-ink'])>=4.5);assert.equal(JSON.stringify(out.templates),before);
 assert.equal(out.site.theme.brand_background,'#ffffff');assert.equal(out.site.theme.brand_color,'#9333ea');
});
test('pre-capability provenance upgrades only in a new whole-site edit; malformed snapshots fail closed',()=>{
 const palette=paletteFor('deep-studio'),source={compiledBodyPolicy:'bnx-owned-1',designSystemV2:{version:'bnx-generation-1',preset:'deep-studio',tokens:createWebsiteTokenSnapshot('deep-studio')}};
 assert.equal(inheritCompiledBodyPalette(source,false),null);assert.deepEqual(inheritCompiledBodyPalette(source,true),palette);assert.equal(inheritCompiledBodyPalette({...source,compiledBodyPolicy:undefined},true),null);
 assert.deepEqual(inheritCompiledBodyPalette({...source,...requirements(palette)},false),palette);
 assert.throws(()=>inheritCompiledBodyPalette({...source,compiledBodyPaletteVersion:COMPILED_BODY_PALETTE_VERSION},true),/配色快照不完整/);
 assert.throws(()=>materializeCompiledBodyPalette(foundationAuthoringExample(original),requirements(palette)),/唯一的受信基础样式/);
 assert.throws(()=>materializeCompiledBodyPalette(foundationAuthoringExample(original),{...requirements(palette),compiledBodyPolicy:'forged'}),/来源无效/);
});

const browserPath='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',localRequire=createRequire(import.meta.url);
let chromium:any;try{chromium=localRequire('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright').chromium;}catch{}
const phpAvailable=spawnSync('php',['-r','echo class_exists("DOMDocument")?"yes":"no";'],{encoding:'utf8',windowsHide:true}).stdout==='yes';
test('formal PHP output has readable brand, desktop/mobile navigation and actions at four widths in all skins',{skip:!chromium||!phpAvailable||!existsSync(browserPath),timeout:60000},async()=>{
 const ctx={seed:'palette-browser',language:'zh-CN',homeHref:'/',menus:[{id:1,items:['首页','车型展示','品牌介绍','联系我们'].map((label,i)=>({id:String(i+1),label,url:i?['/','/products','/about','/contact'][i]:'/',parent_id:null}))}]};
 const header=compileSiteHeader(resolveSiteHeader({version:'bnh-1',pattern:'classic',brand:{text:'梅赛德斯-奔驰',logo:null},menuId:1,actions:[{label:'探索车型',href:'/products',style:'primary'}],options:{mobileMode:'dropdown',sticky:false,allowFixedOverlay:false}},ctx),ctx);
 const probe=String.raw`namespace AACMS\Services {final class MenuService{public function __construct(\PDO $p){}public static function available(\PDO $p):bool{return true;}public function find(int $id):array{return ['items'=>[['id'=>'1','label'=>'首页','url'=>'/','parent_id'=>null],['id'=>'2','label'=>'车型展示','url'=>'/products','parent_id'=>null],['id'=>'3','label'=>'品牌介绍','url'=>'/about','parent_id'=>null],['id'=>'4','label'=>'联系我们','url'=>'/contact','parent_id'=>null]]];}public function resolveItems(array $a):array{return $a;}}} namespace {require $argv[1].'/vendor/autoload.php';require $argv[1].'/src/Services/PageHiddenContent.php';require $argv[1].'/src/Services/Renderer.php';$p=new class extends PDO{public function __construct(){}};$r=new \AACMS\Services\Renderer($p);$in=json_decode(stream_get_contents(STDIN),true);echo json_encode(['html'=>$r->renderDocument(['version'=>1,'html'=>$in['html'],'css'=>'']),'css'=>$r->sanitizeCss($in['css'])],JSON_THROW_ON_ERROR);}`;
 const browser=await chromium.launch({executablePath:browserPath,headless:true}),measurements:any[]=[];
 try{const page=await browser.newPage({javaScriptEnabled:false});await page.route('**/*',(r:any)=>r.abort());
  for(const preset of V2_PRESETS){const palette=paletteFor(preset),profile=foundationWithCompiledBodyPalette(original,palette),manifest=materializeCompiledBodyPalette(materializeDesignFoundation(foundationAuthoringExample(profile),profile),requirements(palette));
   const sanitized=spawnSync('php',['-r',probe,resolve('../reference/aacmss')],{input:JSON.stringify({html:header.html,css:manifest.site.theme.global_css+'\n'+header.css}),encoding:'utf8',windowsHide:true,maxBuffer:2000000});assert.equal(sanitized.status,0,sanitized.stderr);const rendered=JSON.parse(sanitized.stdout);assert.ok(rendered.css.includes('--bnf-ink:'),rendered.css.slice(0,100));
   for(const width of [320,390,768,1440]){await page.setViewportSize({width,height:900});await page.setContent(`<html><head><meta charset="utf-8"><style>${rendered.css}</style></head><body class="aacms-page">${rendered.html}<main><p>本地配色验证样例</p></main></body></html>`);
    if(width<=960)await page.locator('.bnh-mobile-menu>summary').click();
    const rows=await page.evaluate(()=>{const g=globalThis as any,selectors=['.bnh-brand','.bnh-primary-nav a','.bnh-action','.bnh-mobile-menu>summary','.bnh-mobile-nav a'];return {overflow:g.document.documentElement.scrollWidth-g.innerWidth,values:selectors.flatMap(selector=>{const el=g.document.querySelector(selector);if(!el||!el.getBoundingClientRect().width||!el.getBoundingClientRect().height)return[];let parent=el,bg='rgba(0, 0, 0, 0)';while(parent&&bg==='rgba(0, 0, 0, 0)'){bg=g.getComputedStyle(parent).backgroundColor;parent=parent.parentElement;}const style=g.getComputedStyle(el);return [{selector,color:style.color,background:bg,font:style.fontFamily}];})};});
    const hex=(rgb:string)=>'#'+rgb.match(/\d+/g)!.slice(0,3).map(v=>Number(v).toString(16).padStart(2,'0')).join('');
    assert.ok(rows.overflow<=1,`${preset}/${width} overflow`);assert.ok(rows.values.length>=3);
    const values=rows.values.map((row:any)=>({...row,contrast:foundationContrast(hex(row.color),hex(row.background))}));for(const row of values)assert.ok(row.contrast>=4.5,`${preset}/${width} ${JSON.stringify(row)}`);measurements.push({preset,width,...rows,values});
   }
  }
 }finally{await browser.close();}
 if(process.env.BENOS_PALETTE_REPORT){const path=resolve(process.env.BENOS_PALETTE_REPORT);mkdirSync(resolve(path,'..'),{recursive:true});writeFileSync(path,JSON.stringify({kind:'local-isolated-formal-php-browser-fixture',paidCalls:0,count:measurements.length,minimumContrast:Math.min(...measurements.flatMap(m=>m.values.map((v:any)=>v.contrast))),measurements},null,2));}
 assert.equal(measurements.length,12);
});
