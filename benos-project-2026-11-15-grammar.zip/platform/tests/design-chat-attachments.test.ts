import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Browser modules are authored in JavaScript.
import { isChatUploadPending, mountChatAttachments } from '../public/js/design-chat-attachments.js';

function file(name: string) {
  return new File(['image bytes for ' + name], name + '.png', {type:'image/png'});
}

function fixture() {
  const form = Object.assign(new EventTarget(), {isConnected:true});
  const data = {project:{id:'project-a'}, visual:{assets:[] as {id:string}[]}};
  const context = {state:{resource:data, user:{id:'user-a'}, route:'design/project-a'}};
  let selected: string[] = [];
  let report: (value: {error:string}) => void;
  const idle = () => new Promise<{error:string}>(resolve => { report = resolve; });
  mountChatAttachments(form, context, {
    getSelected:() => selected,
    onSelected:(ids: string[]) => { selected = ids; },
    onStatus:(status: {pending:boolean;error:string}) => { if (!status.pending) report?.(status); },
  });
  const drop = (...files: File[]) => form.dispatchEvent(Object.assign(new Event('drop', {cancelable:true}), {dataTransfer:{files}}));
  return {form, context, data, idle, drop, selected:() => selected};
}

function receipt(body: File) {
  return Response.json({ok:true, data:{id:body.name, projectId:'project-a', mimeType:body.type,
    fileName:body.name, byteSize:body.size, state:'ready', deletedAt:null}});
}

test('a second image dropped before the first acknowledgement is queued and attached to the same draft', async t => {
  const view = fixture(), files = [file('first'),file('second')], sent: File[] = [];
  let release!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  t.mock.method(globalThis,'fetch',async (_url: string, init: RequestInit) => {
    const body = init.body as File;
    sent.push(body);
    if (sent.length === 1) await gate;
    return receipt(body);
  });
  const done = view.idle();
  view.drop(files[0]);
  assert.equal(isChatUploadPending(view.form),true);
  view.drop(files[1]);
  release();
  assert.equal((await done).error,'');
  assert.deepEqual(sent,files);
  assert.deepEqual(view.selected(),files.map(image => image.name));
  assert.equal(isChatUploadPending(view.form),false);
});

test('a lost second acknowledgement retries only its original file using its original key', async t => {
  const view = fixture(), requests: Array<{name:string; key:string}> = [];
  t.mock.method(globalThis,'fetch',async (_url: string, init: RequestInit) => {
    const body = init.body as File;
    requests.push({name:body.name, key:new Headers(init.headers).get('Idempotency-Key')!});
    if (requests.length === 2) throw new Error('lost acknowledgement');
    return receipt(body);
  });
  const first = view.idle();
  view.drop(file('one'), file('two'));
  assert.ok((await first).error);
  assert.deepEqual(view.selected(),['one.png']);
  assert.equal(isChatUploadPending(view.form),true);
  const retried = view.idle();
  const click = new Event('click');
  Object.defineProperty(click,'target',{value:{closest:(selector: string) => selector === '[data-chat-upload-retry]'}});
  view.form.dispatchEvent(click);
  assert.equal((await retried).error,'');
  assert.equal(requests.length,3);
  assert.deepEqual(requests[1],requests[2]);
  assert.deepEqual(view.selected(),['one.png','two.png']);
});

test('a late upload receipt cannot attach media to another project after navigation', async t => {
  const view = fixture();
  let release!: () => void, dispatched!: () => void;
  const gate = new Promise<void>(resolve => { release = resolve; });
  const started = new Promise<void>(resolve => { dispatched = resolve; });
  t.mock.method(globalThis,'fetch',async (_url: string, init: RequestInit) => {
    dispatched();
    await gate;
    return receipt(init.body as File);
  });
  view.drop(file('old-project'));
  await started;
  view.context.state.resource = {project:{id:'project-b'},visual:{assets:[]}};
  view.context.state.route = 'design/project-b';
  release();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(isChatUploadPending(view.form),false);
  assert.deepEqual(view.selected(),[]);
  assert.deepEqual(view.context.state.resource.visual.assets,[]);
});
