import test from 'node:test';
import assert from 'node:assert/strict';
import { prepareV2Generation, compileV2GenerationSubmission, v2GenerationTool } from '../src/design-system/v2/generation';
import { getV2Fixture } from '../src/design-system/v2/fixtures';
import { sha256 } from '../src/lib/crypto';

function submission(plan: Awaited<ReturnType<typeof prepareV2Generation>>) {
  return { planHash: plan.planHash, pages: plan.pages.map(page => ({ key: page.key, composition: { version: 'bnx-compose-1', preset: plan.preset, sections: page.sections.map(section => {
    const fixture = getV2Fixture(section.recommended.patternId, section.recommended.variantId, plan.preset);
    return { ...fixture.input, id: section.id, media: [] as NonNullable<typeof fixture.input.media> };
  }) } })) };
}
const ctx = { mode: 'review' as const, ownedAssets: [], verifiedFactRefs: [] };
test('one sentence creates a frozen multi-page plan with content and inner-page visual responsibilities', async () => {
  const plan = await prepareV2Generation({ request: '做一个工业设备官网，包括首页、产品中心、关于我们和联系我们', preset: 'deep-studio' });
  assert.ok(plan.pages.length >= 4); assert.equal(plan.siteKind, 'industrial-b2b'); assert.equal(plan.outputTokenLimit, 24000);
  assert.ok(plan.pages[0].sections.length >= 7); assert.ok(plan.pages.slice(1).some(p => p.visual.minimum > 0));
  // A contact page opens with the contact details; every other page opens with an uncropped hero.
  assert.ok(plan.pages.every(p => p.sections[0].choices.every(choice => choice.patternId === (p.sections[0].responsibility === 'contact' ? 'contact' : 'hero-stage'))));
  assert.equal(plan.customerExportReady, false); assert.equal(plan.productionEnabled, false); assert.ok(Object.isFrozen(plan.pages));
  assert.equal(v2GenerationTool(plan).name, 'compose_design_preview');
  const result = await compileV2GenerationSubmission(plan, submission(plan), ctx);
  assert.equal(result.pages.length, plan.pages.length); assert.equal(result.paidModelCalls, 0); assert.equal(result.visualAcceptance, false);
  assert.ok(result.warnings.some(w => w.code === 'BNX_PAGE_MEDIA_MISSING'));
});
test('same inputs are deterministic; last signature changes the next recommendation without changing content duties', async () => {
  const input = { request: '做一个山间民宿官网', seed: 'account-sequence-1' };
  const first = await prepareV2Generation(input), repeated = await prepareV2Generation(input);
  assert.deepEqual(first, repeated);
  const next = await prepareV2Generation({ ...input, previousSignature: first.signature });
  assert.notEqual(first.signature, next.signature);
  assert.deepEqual(first.pages.map(p => p.sections.map(s => s.responsibility)), next.pages.map(p => p.sections.map(s => s.responsibility)));
});
test('explicit simplicity and no-image request remain effective', async () => {
  const plan = await prepareV2Generation({ request: '做一个简单的纯文字咖啡店首页，不要图片' });
  assert.ok(plan.pages[0].sections.length <= 5); assert.equal(plan.imageBudget.max, 0);
  await compileV2GenerationSubmission(plan, submission(plan), ctx);
  const forged = submission(plan);
  forged.pages[0].composition.sections[0].media = [{ id: 'injected', kind: 'planned', prompt: 'image', purpose: 'hero', alt: 'hero', subjectPolicy: 'crop-safe', textSafeArea: 'none', focalPoint: 'center' }];
  await assert.rejects(compileV2GenerationSubmission(plan, forged, ctx), /BNX_IMAGE_GENERATION_DISABLED/);
});
test('missing pages, content duties, foreign presets and invented markup never compile', async () => {
  const plan = await prepareV2Generation({ request: '做一个软件网站，包含首页和关于我们' });
  const full = submission(plan);
  await assert.rejects(compileV2GenerationSubmission(plan, { ...full, planHash: '0'.repeat(64) }, ctx), /BNX_PLAN_CHANGED/);
  await assert.rejects(compileV2GenerationSubmission(plan, { ...full, pages: full.pages.slice(1) }, ctx), /BNX_ALL_PAGES_REQUIRED/);
  const missing = structuredClone(full); missing.pages[0].composition.sections.splice(1, 1);
  await assert.rejects(compileV2GenerationSubmission(plan, missing, ctx), /BNX_CONTENT_RESPONSIBILITIES_MISSING/);
  const html = { ...full, html: '<script>alert(1)</script>' };
  await assert.rejects(compileV2GenerationSubmission(plan, html, ctx));
  const changed = structuredClone(plan); changed.tokens.colors.accent = '#ff0000';
  await assert.rejects(compileV2GenerationSubmission(changed, full, ctx), /BNX_PLAN_CHANGED/);
});

test('a previously sealed plan fails closed when its exact compiler artifact is unavailable', async () => {
  const plan = structuredClone(await prepareV2Generation({ request: '做一个简单的工业首页' }));
  assert.equal(plan.compilerSnapshot.length, 32);
  plan.compilerSnapshot[0].artifactHash = 'a'.repeat(64);
  const { planHash: _previous, ...payload } = plan;
  plan.planHash = await sha256(JSON.stringify(payload));
  await assert.rejects(compileV2GenerationSubmission(plan, submission(plan), ctx), /BNX_FROZEN_COMPILER_UNAVAILABLE/);
});

test('uploaded-only and real-evidence pages reject generated concept assets', async () => {
  for (const request of ['做一个简单的工业首页，只用上传图片', '做一个简单的工业首页，只使用我上传的真实照片', '做一个简单的工业首页，只用真实图片']) {
    const plan = await prepareV2Generation({ request, availableImageCount: 1 });
    const body = submission(plan), section = body.pages[0].composition.sections[0];
    const fixture = getV2Fixture(section.patternId, section.variantId, plan.preset);
    section.media = [fixture.input.media![0]];
    await assert.rejects(compileV2GenerationSubmission(plan, body, fixture.context), /BNX_(?:UPLOADED_IMAGES_REQUIRED|REAL_IMAGE_EVIDENCE_REQUIRED)/);
    const assetPath = section.media[0].assetPath;
    const uploaded = fixture.context.ownedAssets.map(asset => ({ ...asset, source: asset.path === assetPath ? 'uploaded' as const : asset.source }));
    const result = await compileV2GenerationSubmission(plan, body, { ...fixture.context, ownedAssets: uploaded });
    assert.equal(result.paidModelCalls, 0);
  }
});
