import test from 'node:test';
import assert from 'node:assert/strict';
import { createDesignBrief } from '../src/contracts/design-brief';
import { createSitePlan } from '../src/contracts/site-plan';
import { getV2Catalog } from '../src/design-system/v2/render';
import { prepareApprovedV2Generation,permittedV2Presets,assertV2ManifestSkeleton,assertV2ProductionPlan,type V2ProductionPlan } from '../src/design-system/v2/production-plan';
import { sha256 } from '../src/lib/crypto';
import { v2ApprovalKey } from '../src/design-system/v2/registry';

async function input() {
 const request='做一个工业设备官网，网站页面：首页、产品、关于我们、联系我们。';
 const brief=createDesignBrief({request,scope:'site',hasExistingSite:false})!;
 const sitePlan=createSitePlan({request,brief,availableImageCount:0,maxImages:4})!;
 const approvedSnapshot=(await getV2Catalog()).patterns.flatMap(f=>f.variants.flatMap(v=>v.artifacts)).map(a=>({...v2ApprovalKey(a),state:'approved' as const,reviewerId:'fixture-owner',reviewedAt:'2026-11-14T00:00:00.000Z'}));
 return{request,seed:'fixed-account-sequence',sitePlan,availableImageCount:0,approvedSnapshot};
}
test('production planning requires a complete reviewed preset, preserves exact site duties and image budget',async()=>{
 const value=await input();assert.equal(await prepareApprovedV2Generation({...value,approvedSnapshot:[]}),null);
 assert.equal(await prepareApprovedV2Generation({...value,approvedSnapshot:value.approvedSnapshot.filter(a=>a.patternId!=='features'&&a.patternId!=='manifesto')}),null);
 const plan=await prepareApprovedV2Generation(value);assert.ok(plan);assert.equal(plan.version,'bnx-generation-1');assert.equal(plan.imageBudget.max,4);assert.ok(Object.isFrozen(plan));
 // Every duty is kept; the order of the middle sections is drawn per task.
 assert.deepEqual(plan.pages.map(p=>[p.key,p.sections.map(s=>s.responsibility).sort()]),value.sitePlan.pages.map(p=>[p.key,p.roles.map(r=>r.id).sort()]));assert.deepEqual(plan.pages.map(p=>p.sections[0].responsibility),value.sitePlan.pages.map(p=>p.roles[0].id));
 assert.ok(plan.pages.flatMap(p=>p.sections).every(s=>s.choices.every(c=>plan.approvedSnapshot.some(a=>a.preset===plan.preset&&a.patternId===c.patternId&&a.variantId===c.variantId))));
});
function compositionOf(plan:V2ProductionPlan){return {pages:plan.pages.map(p=>({pageKey:p.key,composition:{preset:plan.preset,sections:p.sections.map(s=>({id:s.id,patternId:s.recommended.patternId,variantId:s.recommended.variantId,media:[]}))}})),footer:{templateId:4}};}
test('model chooses approved alternatives, records actual layout, and cannot escape role or replay old plans differently',async()=>{
 const plan=(await prepareApprovedV2Generation(await input()))!;
 assert.equal(plan.componentSelection?.version,'model-choice-1');
 assert.equal(new Set(plan.catalog.flatMap((f:any)=>f.sourceIds)).size,6);
 const body=compositionOf(plan),first=plan.pages[0].sections[0];
 const alternative=first.choices.find(c=>c.layoutKey!==first.recommended.layoutKey)!;
 Object.assign(body.pages[0].composition.sections[0],{patternId:alternative.patternId,variantId:alternative.variantId});
 const selected=await assertV2ProductionPlan(plan,plan.planHash,body,[]);
 assert.notEqual(selected.signature,plan.signature);assert.equal(selected.pages[0].sections[0].layoutKey,alternative.layoutKey);
 const foreign=structuredClone(body);foreign.pages[0].composition.sections[0].patternId='faq';foreign.pages[0].composition.sections[0].variantId='split';
 await assert.rejects(()=>assertV2ProductionPlan(plan,plan.planHash,foreign,[]),/BNX_SECTION_OUTSIDE_PLAN/);
 const {componentSelection:_policy,planHash:_hash,...oldPayload}=plan;
 const oldPlan={...oldPayload,planHash:await sha256(JSON.stringify(oldPayload))};
 await assertV2ProductionPlan(oldPlan,oldPlan.planHash,compositionOf(oldPlan),[]);
 await assert.rejects(()=>assertV2ProductionPlan(oldPlan,oldPlan.planHash,body,[]),/BNX_SECTION_OUTSIDE_PLAN/);
 const next=(await prepareApprovedV2Generation({...await input(),previousSignature:selected.signature}))!;
 await assert.rejects(()=>assertV2ProductionPlan(next,next.planHash,body,[]),/BNX_LAYOUT_REPEATED/);
 await assertV2ProductionPlan(next,next.planHash,compositionOf(next),[]);
});
test('repeat protection uses the approved pool and never unlocks a foreign preset or stale artifact',async()=>{
 const value=await input();value.approvedSnapshot=value.approvedSnapshot.filter(a=>a.preset==='calm-paper');
 const first=await prepareApprovedV2Generation(value);assert.ok(first);
 const next=await prepareApprovedV2Generation({...value,previousSignature:first.signature});assert.ok(next);assert.equal(next.preset,'calm-paper');assert.notEqual(first.signature,next.signature);
 assert.equal(await prepareApprovedV2Generation({...value,approvedSnapshot:value.approvedSnapshot.map(a=>({...a,artifactHash:'f'.repeat(64)}))}),null);
});
test('explicit light/dark and accent directions filter reviewed presets before assigning a plan',async()=>{
 assert.deepEqual(permittedV2Presets('白底，不要深色背景'),['calm-paper','bold-signal']);
 assert.deepEqual(permittedV2Presets('dark theme'),['deep-studio']);
 assert.deepEqual(permittedV2Presets('白色背景，紫色主色'),['bold-signal']);
 assert.deepEqual(permittedV2Presets('主色使用红色'),[]);
 const value=await input();assert.equal(await prepareApprovedV2Generation({...value,request:value.request+'，主色使用红色'}),null);
 const light=await prepareApprovedV2Generation({...value,request:value.request+'，白底，不要深色背景'});assert.ok(light);assert.notEqual(light.preset,'deep-studio');
});
test('ordinary raw footer, global CSS, extra pages and editor data cannot bypass the approved composition',async()=>{
 const value=await input(),plan=await prepareApprovedV2Generation(value);assert.ok(plan);
 const pages=plan.pages.map((p,i)=>({key:p.key,template_id:i+10}));
 const composition={pages:pages.map(p=>({pageKey:p.key,templateId:p.template_id})),footer:{templateId:4}};
 const empty={version:1,html:'',css:''};
 const manifest={site:{pages,theme:{global_css:''}},templates:[...pages.map(p=>({id:p.template_id,type:'page',document:{...empty}})),{id:4,type:'footer',document:{...empty}}]};
 assertV2ManifestSkeleton(plan,composition,manifest,{templates:[]});
 assert.throws(()=>assertV2ManifestSkeleton(plan,{...composition,footer:null},manifest,{templates:[]}),/BNX_SHARED_FOOTER_REQUIRED/);
 const styled=structuredClone(manifest);styled.site.theme.global_css='h1{transform:rotate(45deg)}';assert.throws(()=>assertV2ManifestSkeleton(plan,composition,styled,{templates:[]}),/BNX_AUTHOR_GLOBAL_STYLE_FORBIDDEN/);
 const raw=structuredClone(manifest);raw.templates.at(-1)!.document.html='<footer>Unreviewed content</footer>';assert.throws(()=>assertV2ManifestSkeleton(plan,composition,raw,{templates:[]}),/BNX_TEMPLATE_BODY_MUST_BE_EMPTY/);
 const extra=structuredClone(manifest);extra.site.pages.push({key:'unplanned',template_id:99});assert.throws(()=>assertV2ManifestSkeleton(plan,composition,extra,{templates:[]}),/BNX_MANIFEST_PAGES_OUTSIDE_PLAN/);
 const editor:any=structuredClone(manifest);editor.templates[0].document.components=[{tagName:'script'}];assert.throws(()=>assertV2ManifestSkeleton(plan,composition,editor,{templates:[]}),/BNX_TEMPLATE_BODY_MUST_BE_EMPTY/);
});
