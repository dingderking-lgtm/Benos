﻿// The bnl-0 grammar engine: what it accepts, what it refuses, and what its output must never do.
// Runs under `npm test` (tsx --test) and under plain `node --test` with the repo's loader.
import assert from 'node:assert/strict';
import test from 'node:test';
import { compilePage, ELEMENT_TYPES } from '../src/design-system/grammar/compile';
import { compileSite } from '../src/design-system/grammar/site';
import { grammarTool, prepareGrammarGeneration, compileGrammarSubmission, grammarRepairBrief } from '../src/design-system/grammar/generation';
import { contrast, resolveBrand, type Issue } from '../src/design-system/grammar/brand';
import { ARKPM_HOME_EXEMPLAR } from '../src/design-system/grammar/exemplars';

const brand = {
  colors: { paper: '#f7f7f4', tint: '#eceee9', ink: '#16181b', copy: '#4a5056', line: '#d8dbd6', accent: '#1f6feb', accentInk: '#ffffff', mark: '#c2571a', dark: '#12161a', darkInk: '#f2f4f3' },
  type: { head: 'grotesk', body: 'humanist', weight: 600, tracking: 'tight', scale: 'regular' },
  shape: { radius: 'large', button: 'pill' },
  styles: { kicker: 'square', link: 'underline', card: 'soft', figure: 'framed' },
  space: { container: 1280, density: 'regular' },
};
const images = {
  a: { src: '/uploads/2026/11/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.webp', w: 1600, h: 1000, alt: 'a workshop floor' },
  b: { src: '/uploads/2026/11/bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.webp', w: 1200, h: 1200, alt: 'a finished part' },
};
const section = (id: string, body: any[], extra: Record<string, unknown> = {}) => ({ id, tone: 'paper', space: 'normal', body, ...extra });
const page = (over: Record<string, any> = {}): any => ({
  lang: 'en', title: 'Workshop', brand, images, links: ['/', '/about'],
  sections: [
    section('hero', [{ t: 'kicker', text: 'Precision machining' }, { t: 'display', lines: ['Parts that fit'] }, { t: 'text', text: 'Turning and milling for short runs.', role: 'lead' }, { t: 'actions', items: [{ label: 'Talk to us', href: '/about', kind: 'primary' }] }], { space: 'hero' }),
    section('work', [{ t: 'title', text: 'What we make' }, { t: 'grid', cols: [5, 7], children: [{ t: 'figure', image: 'a', ratio: '3:2' }, { t: 'stack', children: [{ t: 'text', text: 'Brackets, housings and shafts in aluminium and steel.' }, { t: 'list', items: ['One-off prototypes', 'Runs of fifty to five thousand'], marker: 'number' }] }] }]),
    section('next', [{ t: 'title', text: 'Send a drawing' }, { t: 'link', label: 'Start a quote', href: '/about' }], { space: 'band', tone: 'dark' }),
  ],
  ...over,
});
const errors = (issues: readonly Issue[]) => issues.filter(issue => issue.level === 'error');
const warnings = (issues: readonly Issue[]) => issues.filter(issue => issue.level === 'warn');

test('a well-formed page compiles without errors', () => {
  const result = compilePage(page());
  assert.equal(result.ok, true, JSON.stringify(errors(result.issues)));
  assert.equal(result.stats.sections, 3);
  assert.match(result.body, /^<main class="bnl /);
  assert.ok(result.sharedCss.length > 1000 && result.pageCss.length > 0);
});

test('the compiler is deterministic and its CSS obeys the CMS rules', () => {
  const first = compilePage(page(), { scope: 'home' });
  const second = compilePage(page(), { scope: 'home' });
  assert.equal(first.css, second.css);
  assert.equal(first.body, second.body);
  // A single backslash makes the CMS drop the whole stylesheet.
  assert.equal(/[<\\\u0000]|javascript\s*:|expression\s*\(/i.test(first.css), false);
  assert.equal(/!important/.test(first.css), false);
  // Not in the CMS property whitelist.
  assert.equal(/text-wrap|@font-face|@import|@container/.test(first.css), false);
  // Every selector stays inside the page: no bare body/html/:root rules.
  assert.equal(/(^|[},])\s*(body|html|:root)\s*\{/.test(first.css), false);
  assert.equal(/(^|[},])\s*\*\{/.test(first.css), false);
  // Every class the markup uses is prefixed (the root class is the prefix itself), so a theme
  // cannot collide with the page.
  for (const match of first.body.matchAll(/class="([^"]*)"/g)) for (const token of match[1].split(/\s+/)) if (token) assert.match(token, /^bnl(-|$)/, `unprefixed class ${token}`);
  // Counters are not whitelisted: the numerals have to be text.
  assert.equal(/counter\(/.test(first.css), false);
  assert.match(first.body, /<span class="bnl-l-num">01<\/span>/);
});

test('the page stays inside the platform CSS budget', () => {
  const result = compilePage(page());
  assert.ok(result.stats.cssBytes < 45_000, `${result.stats.cssBytes} bytes`);
});

test('structure mistakes are refused with the path that names them', () => {
  const twoDisplays = compilePage(page({ sections: [section('a', [{ t: 'display', lines: ['One'] }, { t: 'display', lines: ['Two'] }]), ...page().sections.slice(1)] }));
  assert.equal(twoDisplays.ok, false);
  assert.ok(errors(twoDisplays.issues).some(issue => /exactly one display/.test(issue.message)));

  const unknownElement = compilePage(page({ sections: [section('a', [{ t: 'carousel', children: [] }]), ...page().sections.slice(1)] }));
  assert.ok(errors(unknownElement.issues).some(issue => issue.path.endsWith('[0]') && /unknown element type/.test(issue.message)));

  const unknownProperty = compilePage(page({ sections: [section('a', [{ t: 'kicker', text: 'Hi', colour: 'red' }]), ...page().sections.slice(1)] }));
  assert.ok(errors(unknownProperty.issues).some(issue => /has no property "colour"/.test(issue.message)));

  const tooFew = compilePage(page({ sections: page().sections.slice(0, 2) as never }));
  assert.ok(errors(tooFew.issues).some(issue => /3 to 10 sections/.test(issue.message)));

  const unknownImage = compilePage(page({ sections: [page().sections[0], section('w', [{ t: 'figure', image: 'zzz' }]), page().sections[2]] }));
  assert.ok(errors(unknownImage.issues).some(issue => /unknown image/.test(issue.message)));

  const outsideLink = compilePage(page(), { links: ['/'] });
  assert.ok(errors(outsideLink.issues).some(issue => /not one of the allowed links/.test(issue.message)));
  assert.ok(ELEMENT_TYPES.includes('display') && ELEMENT_TYPES.includes('cover'));
});

test('unreadable colour systems are refused, not shipped', () => {
  const issues: Issue[] = [];
  const readable = resolveBrand(brand as never, issues);
  assert.ok(readable && errors(issues).length === 0);
  assert.ok(contrast(brand.colors.ink, brand.colors.paper) >= 7);

  const greyOnGrey = compilePage(page({ brand: { ...brand, colors: { ...brand.colors, copy: '#e7e7e4' } } }));
  assert.equal(greyOnGrey.ok, false);
  assert.ok(errors(greyOnGrey.issues).some(issue => /contrast of copy on paper/.test(issue.message)));
  // A malformed brand system is fatal: no page is compiled at all.
  const noColours = compilePage(page({ brand: { ...brand, colors: { ...brand.colors, paper: 'ivory' } } }));
  assert.equal(noColours.body, '<main class="bnl"></main>');
  assert.ok(errors(noColours.issues).some(issue => /must be a 6-digit hex colour/.test(issue.message)));
});

test('long CJK runs are broken into clause boxes so a line never ends on one character', () => {
  const cjk = '我们把每一件零件都当作整车的一部分来做。公差控制在百分之一毫米以内，交付前逐件复核。需要打样时，三天内寄出。';
  const result = compilePage(page({ lang: 'zh-CN', sections: [page().sections[0], section('t', [{ t: 'text', text: cjk }]), page().sections[2]] }));
  assert.equal(result.ok, true, JSON.stringify(errors(result.issues)));
  assert.match(result.body, /<span class="bnl-t-phrase">/);
  assert.match(result.body, /<span class="bnl-t-tail">/);
  assert.match(result.sharedCss, /\.bnl-t-phrase\{display:inline-block/);
});

test('a picture shown far from its own proportions is warned about', () => {
  const result = compilePage(page({ sections: [page().sections[0], section('f', [{ t: 'figure', image: 'b', ratio: '21:9' }]), page().sections[2]] }));
  assert.equal(result.ok, true);
  assert.ok(warnings(result.issues).some(issue => /pick a closer ratio or set fit "cover"/.test(issue.message)));
  const covered = compilePage(page({ sections: [page().sections[0], section('f', [{ t: 'figure', image: 'b', ratio: '21:9', fit: 'cover' }]), page().sections[2]] }));
  assert.equal(warnings(covered.issues).some(issue => /pick a closer ratio/.test(issue.message)), false);
});

test('links may point at a section of a page, but never at a page that does not exist', () => {
  const withAnchors = page({ sections: [
    page().sections[0],
    section('steps', [{ t: 'title', text: 'Process' }, { t: 'link', label: 'See the process', href: '#steps' }, { t: 'link', label: 'Home process', href: '/#hero' }]),
    page().sections[2],
  ] });
  const ok = compilePage(withAnchors, { links: ['/', '/about'] });
  assert.equal(ok.ok, true, JSON.stringify(errors(ok.issues)));
  // Same shape, but the path does not exist in this site.
  const foreign = compilePage(page({ sections: [
    page().sections[0],
    section('steps', [{ t: 'link', label: 'Elsewhere', href: '/pricing#plans' }]),
    page().sections[2],
  ] }), { links: ['/', '/about'] });
  assert.equal(foreign.ok, false);
  assert.ok(errors(foreign.issues).some(issue => /not one of the allowed links/.test(issue.message)));
});

test('the contact form is a CMS slot, never hand-written markup', () => {
  const withForm = page({ sections: [page().sections[0], section('talk', [{ t: 'title', text: 'Tell us what you need' }, { t: 'form', title: 'Send a drawing', note: 'We reply within one working day.' }]), page().sections[2]] });
  const result = compilePage(withForm);
  assert.equal(result.ok, true, JSON.stringify(errors(result.issues)));
  // The CMS replaces this node with the native inquiry form: no inputs, labels or buttons here.
  assert.match(result.body, /data-aacms="form" data-form="contact"/);
  assert.doesNotMatch(result.body, /<(?:input|select|textarea)\b/);
  assert.match(result.body, /Send a drawing/);
  assert.deepEqual(result.stats.forms, ['contact']);
  // An unusable reference is refused instead of shipping a slot nothing can render.
  const badRef = compilePage(page({ sections: [page().sections[0], section('talk', [{ t: 'form', ref: 'not a ref!' }]), page().sections[2]] }));
  assert.equal(badRef.ok, false);
  assert.ok(errors(badRef.issues).some(issue => /form reference/.test(issue.message)));
});

test('the master kit lives on as a verified exemplar', () => {
  // The five ported kit sections are frozen as this exemplar: the grammar line adds no new block
  // library entries, and every test run proves the reference still compiles inside the CMS rules.
  const document = ARKPM_HOME_EXEMPLAR as any;
  const text = JSON.stringify(document);
  const imageIds = [...new Set([...text.matchAll(/"image":"([^"]+)"/g)].map(match => match[1]))];
  const hrefs = [...new Set([...text.matchAll(/"href":"([^"]+)"/g)].map(match => match[1]))];
  const exemplarImages = Object.fromEntries(imageIds.map(id => [id, { src: `/uploads/2026/11/${id.padEnd(32, '0')}.webp`, w: 1600, h: 1000, alt: id }]));
  const result = compilePage({ ...document, links: hrefs }, { images: exemplarImages });
  assert.equal(result.ok, true, JSON.stringify(errors(result.issues)));
  assert.equal(result.stats.sections, 7);
  assert.ok(result.stats.nodes > 80, `${result.stats.nodes} nodes`);
  assert.match(result.body, /<main class="bnl /);
  assert.equal(/(^|[},])\s*(body|html|:root)\s*\{/.test(result.css), false);
  assert.equal(/[<\\\u0000]|!important|@font-face/.test(result.css), false);
  assert.ok(result.stats.cssBytes < 45_000);
});
test('a site shares one brand stylesheet and scopes each page', () => {
  const about = page();
  const result = compileSite({ brand: brand as never, images, pages: [
    { key: 'home', path: '/', title: 'Home', sections: page().sections as never },
    { key: 'about', path: '/about', title: 'About', sections: about.sections as never },
  ] });
  assert.equal(result.ok, true, JSON.stringify(errors(result.issues)));
  assert.equal(result.pages.length, 2);
  // One shared stylesheet, page CSS only for the instance rules, and no class shared between pages.
  assert.match(result.sharedCss, /^\.bnl\{--paper:/);
  assert.match(result.pages[0].css, /\.bnl \.bnl-home-/);
  assert.match(result.pages[1].css, /\.bnl \.bnl-about-/);
  assert.equal(result.pages[0].body.includes('bnl-about-'), false);
});

test('a site without a home page is refused', () => {
  const result = compileSite({ brand: brand as never, images, pages: [{ key: 'about', path: '/about', title: 'About', sections: page().sections as never }] });
  assert.equal(result.ok, false);
  assert.ok(errors(result.issues).some(issue => /must live at "\/"/.test(issue.message)));
});

test('the model gets a frozen plan, one tool and a repair brief', async () => {
  const plan = await prepareGrammarGeneration({ request: 'machining shop site', pageCount: 2, images: [{ id: 'a', src: images.a.src, width: 1600, height: 1000, alt: 'floor' }] });
  assert.equal(plan.version, 'bnl-generation-1');
  assert.equal(plan.pages.length, 2);
  assert.ok(plan.spec.includes('You are the design model inside a website builder'));

  const tool = grammarTool(plan);
  assert.equal(tool.name, 'compose_site_grammar');
  assert.deepEqual((tool.parameters.properties.pages.items.properties.key as { enum: string[] }).enum, ['home', 'page-2']);

  // The plan fixes the links: a page may only point at a path the site really has.
  const homeSections = page().sections.map((entry: any) => ({ ...entry, body: JSON.parse(JSON.stringify(entry.body).replaceAll('"/about"', '"/page-2"')) }));
  const submission = {
    planHash: plan.planHash, palette: { industry: 'industrial', direction: 'professional' },
    pages: [{ key: 'home', sections: homeSections }, { key: 'page-2', sections: homeSections }],
  };
  const compiled = await compileGrammarSubmission(plan, submission);
  assert.equal(compiled.ok, true, JSON.stringify(errors(compiled.issues)));
  assert.equal(compiled.stats.pages, 2);
  assert.equal(compiled.reviewOnly, true);
  assert.equal(compiled.customerExportReady, false);
  // The same document twice must produce different instance classes, never a collision.
  assert.notEqual(compiled.site!.pages[0].css, compiled.site!.pages[1].css);

  const wrongPlan = await compileGrammarSubmission(plan, { ...submission, planHash: 'a'.repeat(64) });
  assert.equal(wrongPlan.ok, false);
  assert.ok(errors(wrongPlan.issues).some(issue => /not the plan this task froze/.test(issue.message)));

  const missingPage = await compileGrammarSubmission(plan, { ...submission, pages: [{ key: 'home', sections: homeSections }] });
  assert.equal(missingPage.ok, false);
  assert.ok(errors(missingPage.issues).some(issue => /page page-2 is missing/.test(issue.message)));

  const broken = await compileGrammarSubmission(plan, { ...submission, pages: [{ key: 'home', sections: homeSections.slice(0, 1) }, submission.pages[1]] });
  assert.equal(broken.ok, false);
  const brief = grammarRepairBrief(broken.issues);
  assert.match(brief, /must be fixed/);
  assert.match(brief, /sections: a page has 3 to 10 sections/);
});
