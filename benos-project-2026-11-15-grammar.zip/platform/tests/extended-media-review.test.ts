import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync,spawnSync} from 'node:child_process';
import {inspectGif,inspectSvg,inspectPdf} from '../src/lib/extended-media';
import {validateStaticPdf} from '../src/lib/pdf-static';
import {inspectMediaBytes,saveMedia,listMedia,readMedia,setMediaDeleted,resolveProjectAssets} from '../src/modules/media';
import {mediaFixture,png} from './media-helper';
import example from '../src/contracts/site-example.json';

const text=(value:string)=>new TextEncoder().encode(value);
const svg=text('<svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"><rect width="12" height="10" fill="#fff"/></svg>');
const basePdfObjects=(extra='')=>['<< /Type /Catalog /Pages 2 0 R '+extra+' >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 100 100] /Resources <<>> /Contents 4 0 R >>','<< /Length 0 >>\nstream\n\nendstream'];
function objectsPdf(objects:string[],trailerExtra=''){
 let body='%PDF-1.7\n',offsets=[0];for(let i=0;i<objects.length;i++){offsets.push(Buffer.byteLength(body));body+=`${i+1} 0 obj\n${objects[i]}\nendobj\n`;}
 const size=objects.length+1,xref=Buffer.byteLength(body);body+=`xref\n0 ${size}\n0000000000 65535 f \n${offsets.slice(1).map(n=>String(n).padStart(10,'0')+' 00000 n \n').join('')}trailer\n<< /Size ${size} /Root 1 0 R ${trailerExtra} >>\nstartxref\n${xref}\n%%EOF\n`;return text(body);
}
const plainPdf=(extra='')=>objectsPdf(basePdfObjects(extra));
/** Literal-code GIF fixtures include explicit widths; Pillow independently
 * decodes them, so the platform decoder is not its own validity oracle. */
function literalGif(minimum:number,pixels:number[],width=pixels.length,resetEvery=0){
 const colours=1<<minimum,clear=colours,end=clear+1;let bits=0,buffer=0,size=minimum+1,next=end+1,previous=false;
 const payload:number[]=[],put=(value:number)=>{buffer|=value<<bits;bits+=size;while(bits>=8){payload.push(buffer&255);buffer>>>=8;bits-=8;}};
 put(clear);for(let i=0;i<pixels.length;i++){if(resetEvery&&i&&i%resetEvery===0){put(clear);size=minimum+1;next=end+1;previous=false;}
  put(pixels[i]);if(previous&&next<4096){next++;if(next===(1<<size)&&size<12)size++;}previous=true;
 }put(end);if(bits)payload.push(buffer&255);
 const header=Buffer.alloc(13);header.write('GIF89a');header.writeUInt16LE(width,6);header.writeUInt16LE(pixels.length/width,8);header[10]=128|(minimum-1);
 const descriptor=Buffer.alloc(10);descriptor[0]=0x2c;descriptor.writeUInt16LE(width,5);descriptor.writeUInt16LE(pixels.length/width,7);
 const table=Buffer.alloc(colours*3);for(let i=0;i<colours;i++){table[3*i]=i;table[3*i+1]=i;table[3*i+2]=i;}
 const blocks:Buffer[]=[];for(let i=0;i<payload.length;i+=255){const chunk=Buffer.from(payload.slice(i,i+255));blocks.push(Buffer.from([chunk.length]),chunk);}
 return new Uint8Array(Buffer.concat([header,table,descriptor,Buffer.from([minimum]),...blocks,Buffer.from([0,0x3b])]));
}
function pillowDecode(bytes:Uint8Array){return JSON.parse(execFileSync('python',['-c','import sys,io,json,base64; from PIL import Image; b=base64.b64decode(sys.stdin.read()); im=Image.open(io.BytesIO(b)); im.load(); print(json.dumps({"size":im.size,"pixels":base64.b64encode(im.tobytes()).decode()}))'],{input:Buffer.from(bytes).toString('base64'),encoding:'utf8'}));}

test('independent Pillow decodes GIF minimum widths 2..8, width growth, explicit clear and full dictionary fixtures',()=>{
 for(let minimum=2;minimum<=8;minimum++){
  const pixels=Array.from({length:8192},(_,i)=>i% (1<<minimum));
  for(const reset of [0,257]){const bytes=literalGif(minimum,pixels,128,reset),decoded=pillowDecode(bytes);assert.deepEqual(decoded.size,[128,64]);assert.deepEqual(Buffer.from(decoded.pixels,'base64'),Buffer.from(pixels));assert.deepEqual(inspectGif(bytes),{mimeType:'image/gif',extension:'gif',width:128,height:64});}
 }
});

test('Pillow-produced interlaced noise and animated local palettes pass GIF inspection',()=>{
 const fixtures=JSON.parse(execFileSync('python',['-c',`from PIL import Image
import io,json,base64,random
r=random.Random(1729); frames=[]
for n in range(4):
 im=Image.frombytes('P',(128,64),bytes(r.randrange(256) for _ in range(8192))); im.putpalette([c for i in range(256) for c in (i,(i+n*17)%256,255-i)]);frames.append(im)
result=[]
for animated in (False,True):
 out=io.BytesIO(); frames[0].save(out,format='GIF',save_all=animated,append_images=frames[1:] if animated else [],duration=90,loop=0,disposal=2,interlace=True,optimize=False); result.append(base64.b64encode(out.getvalue()).decode())
print(json.dumps(result))`],{encoding:'utf8'})) as string[];
 for(const fixture of fixtures)assert.equal(inspectGif(Buffer.from(fixture,'base64')).width,128);
});

test('GIF invalid palette indices, pixel counts and truncated subblocks fail closed',()=>{
 const bytes=literalGif(2,[0,1,2,3],4);const invalidPalette=new Uint8Array(bytes);invalidPalette[10]=128;const shortPalette=Buffer.concat([invalidPalette.subarray(0,19),invalidPalette.subarray(25)]);
 assert.throws(()=>inspectGif(shortPalette));const wrongPixels=new Uint8Array(bytes);wrongPixels[6]=3;assert.throws(()=>inspectGif(wrongPixels));assert.throws(()=>inspectGif(bytes.subarray(0,-3)));
});

test('SVG namespaces and decoded entities cannot introduce executable nodes or external references',()=>{
 assert.equal(inspectSvg(svg).width,12);
 for(const source of [
  '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"><x:script xmlns:x="http://www.w3.org/2000/svg">alert(1)</x:script></svg>',
  '<svg xmlns="http://www.w3.org/1999/xhtml" width="12" height="10"/>',
  '<svg xmlns="http://www.w3.org/2000/svg" xmlns:x="http://www.w3.org/1999/xlink" width="12" height="10"><use x:href="&#x6a;avascript:alert(1)"/></svg>',
  '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="10"><use href="&#x2f;&#x2f;attacker.example/x.svg#x"/></svg>',
  '<!DOCTYPE svg [<!ENTITY secret SYSTEM "file:///private">]><svg width="12" height="10">&secret;</svg>',
  '<?xml-stylesheet href="https://attacker.example/a.css"?><svg width="12" height="10"/>',
  '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" xml:base="https://attacker.example/"><use href="#x"/></svg>',
 ])assert.throws(()=>inspectSvg(text(source)));
});

test('PDF names decoded with hex escapes still reject active actions, encrypted files and object streams',()=>{
 assert.equal(inspectPdf(plainPdf()).extension,'pdf');const independent=spawnSync('pdfinfo',['-'],{input:plainPdf(),encoding:'utf8'});assert.equal(independent.status,0,independent.stderr);assert.match(independent.stdout,/Pages:\s+1/);
 for(const name of ['JavaScript','JS','OpenAction','AA','Encrypt','ObjStm','EmbeddedFiles','XFA']){
  const encoded=[...name].map(c=>'#'+c.charCodeAt(0).toString(16)).join('');assert.throws(()=>inspectPdf(plainPdf('/'+encoded+' 5 0 R')));
 }
});

test('a PDF with no valid trailer, root or page tree must not become an accepted upload',async()=>{
 const malformed=text('%PDF-1.7\n1 0 obj\nnull\nendobj\nstartxref\n0\n%%EOF\n');const independent=spawnSync('pdfinfo',['-'],{input:malformed,encoding:'utf8'});assert.notEqual(independent.status,0);
 await assert.rejects(()=>inspectMediaBytes(malformed,'application/pdf'));
});

test('Chromium-exported ordinary and multi-page PDF downloads validate without changing their bytes',async()=>{
 const generated=JSON.parse(execFileSync('python',['-c',`from playwright.sync_api import sync_playwright
import json,base64
result=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(); page=browser.new_page();page.context.set_offline(True)
 for multiple in (False,True):
  page.set_content('<h1>Benos PDF fixture</h1><p>Ordinary static download.</p>'+('<div style="break-before:page">Second page</div>' if multiple else '')); result.append(base64.b64encode(page.pdf()).decode())
 browser.close()
print(json.dumps(result))`],{encoding:'utf8'})) as string[];
 for(let i=0;i<generated.length;i++){const bytes=Buffer.from(generated[i],'base64'),before=Buffer.from(bytes);assert.equal(validateStaticPdf(bytes).pages,i+1);assert.equal((await inspectMediaBytes(bytes)).extension,'pdf');assert.deepEqual(bytes,before);const independent=spawnSync('pdfinfo',['-'],{input:bytes,encoding:'utf8'});assert.equal(independent.status,0,independent.stderr);assert.match(independent.stdout,new RegExp('Pages:\\s+'+(i+1)));}
});

test('PDF tokenizer supports escaped literal/hex strings, comments, arrays and valid indirect stream Length',()=>{
 const objects=basePdfObjects('/Lang (en\\050US\\051) /MetadataText <FEFF0041F> /Extra [(nested (text) \\) end) true false null -1.25 +2 .5]');
 objects[3]='<< /Length 5 0 R >>\nstream\nq\nQ\nendstream';objects.push('4');const bytes=objectsPdf(objects);assert.equal(validateStaticPdf(bytes).pages,1);assert.equal(spawnSync('pdfinfo',['-'],{input:bytes}).status,0);
 const nameEscapes=basePdfObjects();nameEscapes[0]=nameEscapes[0].replace('/Type /Catalog /Pages','/Ty#70e /Cata#6Cog /Pa#67es');assert.equal(validateStaticPdf(objectsPdf(nameEscapes)).pages,1);
});

test('PDF rejects wrong xref byte offsets/generations, duplicate encoded keys and dangling references',()=>{
 const original=new TextDecoder().decode(plainPdf());
 assert.throws(()=>validateStaticPdf(text(original.replace(/(\d{10}) 00000 n/,(_all,offset)=>String(Number(offset)+1).padStart(10,'0')+' 00000 n'))));
 assert.throws(()=>validateStaticPdf(text(original.replace(/(\d{10}) 00000 n/,'$1 00001 n'))));
 assert.throws(()=>validateStaticPdf(plainPdf('/Ty#70e /Catalog')));
 const dangling=basePdfObjects();dangling[0]=dangling[0].replace('2 0 R','999 0 R');assert.throws(()=>validateStaticPdf(objectsPdf(dangling)));
 assert.throws(()=>validateStaticPdf(text(original.replace(/startxref\n\d+/,'startxref\n1'))));
});

test('PDF rejects missing/wrong page trees, cycles and unmatched counts even with a correct xref',()=>{
 for(const change of [
  (o:string[])=>o[0]=o[0].replace('/Pages 2 0 R',''),
  (o:string[])=>o[1]=o[1].replace('/Count 1','/Count 2'),
  (o:string[])=>o[1]=o[1].replace('[3 0 R]','[2 0 R]'),
  (o:string[])=>o[1]=o[1].replace('[3 0 R]','[3 0 R 3 0 R]').replace('/Count 1','/Count 2'),
  (o:string[])=>o[2]=o[2].replace('/Parent 2 0 R','/Parent 1 0 R'),
  (o:string[])=>o[2]=o[2].replace('[0 0 100 100]','[100 100 0 0]'),
 ]){const objects=basePdfObjects();change(objects);assert.throws(()=>validateStaticPdf(objectsPdf(objects)));}
});

test('PDF streams require exact boundaries and safe Length references; unsupported structures are explicit failures',()=>{
 for(const stream of ['<< /Length 2 >>\nstream\n\nendstream','<< /Length 100000 >>\nstream\nx\nendstream','<< /Length 5 0 R >>\nstream\nx\nendstream','<< /Length 0 /F (external.dat) >>\nstream\n\nendstream']){const objects=basePdfObjects();objects[3]=stream;assert.throws(()=>validateStaticPdf(objectsPdf(objects)));}
 const cyclic=basePdfObjects();cyclic[3]='<< /Length 5 0 R >>\nstream\n\nendstream';cyclic.push('4 0 R');assert.throws(()=>validateStaticPdf(objectsPdf(cyclic)));
 for(const extra of ['/Prev 9','/XRefStm 9','/Encrypt 4 0 R'])assert.throws(()=>validateStaticPdf(objectsPdf(basePdfObjects(),extra)));
 const streamIndex=basePdfObjects();streamIndex[3]='<< /Type /XRef /Length 0 >>\nstream\n\nendstream';assert.throws(()=>validateStaticPdf(objectsPdf(streamIndex)));
 const deep=basePdfObjects('/Nested '+'['.repeat(42)+'0'+']'.repeat(42));assert.throws(()=>validateStaticPdf(objectsPdf(deep)));
});

test('extended/raster uploads share one request identity and retained inventory across lost acknowledgements',async()=>{
 const f=mediaFixture();try{
  const choices=await Promise.allSettled([saveMedia(f.env,'u','p',{bytes:svg,fileName:'logo.svg',requestKey:'same-format-independent-key'}),saveMedia(f.env,'u','p',{bytes:png(),fileName:'logo.png',requestKey:'same-format-independent-key'})]);
  assert.equal(choices.filter(c=>c.status==='fulfilled').length,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media_inventory').get()!.n,1);assert.equal(f.storage.objects.size,1);
  f.storage.failAfter=true;await assert.rejects(()=>saveMedia(f.env,'u','p',{bytes:svg,fileName:'recover.svg',requestKey:'extended-lost-ack'}));const restored=await saveMedia(f.env,'u','p',{bytes:svg,fileName:'recover.svg',requestKey:'extended-lost-ack'});assert.equal(restored.state,'ready');
  assert.deepEqual((await readMedia(f.env,'u',restored.id)).bytes,svg);await setMediaDeleted(f.env,'u',restored.id,true);assert.equal((await listMedia(f.env,'u','p',true)).find(x=>x.id===restored.id)!.state,'deleted');await setMediaDeleted(f.env,'u',restored.id,false);
  const manifest={...example,assets:[{file:'assets/0.svg',path:restored.assetPath,sha256:restored.sha256,size:restored.byteSize}]};assert.deepEqual((await resolveProjectAssets(f.env,'u','p',manifest)).files[0].bytes,svg);
 }finally{f.db.close();}
});

function seedQuota(f:ReturnType<typeof mediaFixture>,table:string,count:number,bytes:number){
 const now=new Date().toISOString();const extended=table==='project_media_extended',ext=extended?'svg':'png',mime=extended?'image/svg+xml':'image/png';
 for(let i=0;i<count;i++)f.db.sqlite.prepare(`INSERT INTO ${table}(id,user_id,project_id,request_key,request_hash,object_key,filename,mime_type,extension,byte_size,width,height,sha256,source,state,created_at,updated_at) VALUES(?,'u','p',?,?,?,?,?,?,?,1,1,'fixture','upload','ready',?,?)`).run(table+i,table+i,'fixture','quota/'+table+i,'quota.'+ext,mime,ext,bytes,now,now);
}
test('mixed-format concurrent uploads cannot overrun the combined 500-file cap',async()=>{
 const f=mediaFixture();try{seedQuota(f,'project_media',498,70);seedQuota(f,'project_media_extended',1,svg.length);
  const result=await Promise.allSettled([saveMedia(f.env,'u','p',{bytes:svg,fileName:'last.svg',requestKey:'quota-svg-last'}),saveMedia(f.env,'u','p',{bytes:png(),fileName:'last.png',requestKey:'quota-png-last'})]);assert.equal(result.filter(r=>r.status==='fulfilled').length,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media_inventory').get()!.n,500);assert.equal(f.storage.objects.size,1);
 }finally{f.db.close();}
});
test('retained and staging media count toward bytes; 0036 preserves the original image-job FK',async()=>{
 const f=mediaFixture();try{seedQuota(f,'project_media',42,12*1048576);seedQuota(f,'project_media_extended',8,1048576);
  await assert.rejects(()=>saveMedia(f.env,'u','p',{bytes:svg,fileName:'over.svg',requestKey:'over-total-bytes'}));assert.equal(f.storage.puts,0);
  const foreign=f.db.sqlite.prepare("PRAGMA foreign_key_list('image_jobs')").all().find(row=>row.from==='result_media_id');assert.equal(foreign!.table,'project_media');assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media').get()!.n,42);
 }finally{f.db.close();}
});
