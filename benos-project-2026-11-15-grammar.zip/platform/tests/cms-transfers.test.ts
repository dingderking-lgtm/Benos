import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash,createHmac } from 'node:crypto';
import { TestD1,testEnv } from './d1-helper';
import { saveVersion } from '../src/modules/ai';
import { starterManifest } from '../src/contracts/starter-library';
import { encryptSecret } from '../src/lib/crypto';
import { ensureCmsBundleTransfer,advanceCmsBundleTransfer,cmsBundleTransferStatus } from '../src/modules/cms-transfers';
import type { CmsBundleState } from '../src/lib/cms-bundle';
import { runPublicationOperation,continuePublicationPreparations } from '../src/modules/publishing';
const user='usr-transfer',project='prj_'+'5'.repeat(32),site='site_'+'5'.repeat(32),MIB=1048576;
const digest=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
class Storage{
 objects=new Map<string,Uint8Array>();ranges:number[]=[];
 async put(key:string,bytes:Uint8Array,options?:any){if(options?.onlyIf&&this.objects.has(key))return null;this.objects.set(key,bytes.slice());return {key};}
 async head(key:string){const b=this.objects.get(key);return b?{key,size:b.length,etag:digest(b)}:null;}
 async get(key:string,options?:any){const b=this.objects.get(key);if(!b)return null;const etag=digest(b);if(options?.onlyIf?.etagMatches!==undefined&&options.onlyIf.etagMatches!==etag)return {size:b.length,etag};let out=b;if(options?.range){out=b.slice(options.range.offset,options.range.offset+options.range.length);this.ranges.push(out.length);}return {size:b.length,etag,body:true,arrayBuffer:async()=>out.slice().buffer};}
 async delete(key:string){this.objects.delete(key);}
}
async function fixture(){
 const db=new TestD1(),env=testEnv(db),storage=new Storage();env.BUCKET=storage as unknown as R2Bucket;const now=new Date().toISOString(),future=new Date(Date.now()+86400000).toISOString();
 db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,'transfer@example.test','Transfer','test','user','active',?,?)").run(user,now,now);
 db.sqlite.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES(?,?,'Transfer',?,?)").run(project,user,now,now);
 const manifest=starterManifest('studio')!;manifest.templates[0].document.css+='/*'+'x'.repeat(3*MIB)+'*/';const version=await saveVersion(env,user,project,manifest,'manual',null,'transfer-version-save');
 db.sqlite.prepare("INSERT INTO sites(id,user_id,project_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,?,?,'Transfer','transfer.example.com','cms@example.test','connected',?,?)").run(site,user,project,now,now);
 db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES('hosting-transfer',?,?,'annual',?,?,'active',?)").run(user,site,now,future,now);
 db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,cms_version,last_verified_at,created_at,updated_at) VALUES('connection-transfer',?,'https://transfer.example.com','testkey',?,'1.9.21',?,?,?)").run(site,await encryptSecret('transfer-test-secret-at-least-thirty-two-bytes',env.ENCRYPTION_KEY,site),now,now,now);
 return {db,env,storage,version,manifest};
}
function remote(){let current:CmsBundleState|null=null,lost=false,loseNext=false,wrongIdentity=false;const files=new Map<string,Uint8Array[]>(),calls:string[]=[],offsets:number[]=[];
 const send=async(_credentials:unknown,input:any,_key:string)=>{
  if(input instanceof Uint8Array){calls.push('chunk');const headerLength=new DataView(input.buffer,input.byteOffset).getUint32(4,false),header=JSON.parse(new TextDecoder().decode(input.subarray(8,8+headerLength))),bytes=input.subarray(8+headerLength),file=current!.files.find(f=>f.file===header.file)!;assert.equal(header.sha256,digest(bytes));assert.equal(header.offset,file.received);offsets.push(header.offset);files.get(header.file)!.push(bytes.slice());file.received+=bytes.length;
   if(loseNext){loseNext=false;lost=true;throw new Error('response lost after write');}
  }else {calls.push(input.operation);if(input.operation==='bundle-status'&&!current)return {status:404,data:{error:{code:'BUNDLE_NOT_FOUND'}}};
   if(input.operation==='bundle-begin'){const metadata=[input.manifest,...input.assets];current={protocol:'benos-bundle-v2',bundleId:input.bundleId,siteId:site,projectId:input.projectId,versionId:input.versionId,purpose:input.purpose,state:'receiving',expiresAt:input.expiresAt,expired:false,pinned:false,chunkBytes:MIB,zipBytes:22+metadata.reduce((n:number,f:any)=>n+f.size+76+2*f.file.length,0),zipSha256:null,nativeValidated:false,files:metadata.map((f:any)=>({...f,received:0}))};for(const f of metadata)files.set(f.file,[]);}
   if(input.operation==='bundle-seal'){for(const file of current!.files){assert.equal(file.received,file.size);assert.equal(digest(Buffer.concat(files.get(file.file)!)),file.sha256);}current!.state='sealed';current!.zipSha256='a'.repeat(64);}
  }const data=structuredClone(current)!;if(wrongIdentity)data.siteId='site_'+'f'.repeat(32);return {status:200,data};
 };return {send,calls,offsets,get lost(){return lost;},lose(){loseNext=true;},wrong(){wrongIdentity=true;}};
}
test('durable CMS transfer advances at most two bounded chunks and retries lost acknowledgement from signed remote offset',async()=>{
 const f=await fixture(),r=remote();try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'bundle-test-request','publish');assert.equal(task.id,(await ensureCmsBundleTransfer(f.env,user,site,f.version,'bundle-test-request','publish')).id);assert.ok(f.db.sqlite.prepare('SELECT length(metadata_json)+length(sources_json) n FROM cms_bundle_transfers').get()!.n as number<10000);
  r.lose();let view=await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send});assert.equal(view.sealed,false);assert.equal(view.errorCode,'CMS_BUNDLE_UNCERTAIN');assert.equal(r.lost,true);assert.deepEqual(r.offsets,[0]);
  view=await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send});assert.equal(view.state,'transferring');assert.deepEqual(r.offsets,[0,MIB,2*MIB]);
  view=await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send});assert.equal(view.state,'sealed');assert.equal(view.bytesSent,view.totalBytes);assert.equal(r.offsets.at(-1),3*MIB);assert.ok(f.storage.ranges.every(n=>n<=MIB));
  const count=r.calls.length;await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send});assert.deepEqual(r.calls.slice(count),['bundle-status']);assert.equal(f.db.sqlite.prepare('SELECT published_version_id FROM projects').get()!.published_version_id,null,'transport must never publish');
  await assert.rejects(cmsBundleTransferStatus(f.env,'other',task.id),/不存在/);await assert.rejects(ensureCmsBundleTransfer(f.env,user,site,f.version,'bundle-test-request','preview'),/其他版本/);
 }finally{f.db.close();}
});
test('transfer rejects signed identity substitution and stops outgoing data when hosting or account access changes',async()=>{
 const f=await fixture(),r=remote();try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'bundle-test-identity','publish');r.wrong();const bad=await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send});assert.equal(bad.errorCode,'CMS_BUNDLE_IDENTITY_INVALID');assert.equal(r.offsets.length,0);
  f.db.sqlite.prepare("UPDATE users SET status='restricted' WHERE id=?").run(user);const count=r.calls.length;assert.equal((await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send})).errorCode,'ACCOUNT_RESTRICTED');assert.equal(r.calls.length,count);
  f.db.sqlite.prepare("UPDATE users SET status='active' WHERE id=?").run(user);f.db.sqlite.prepare("UPDATE hosting_entitlements SET starts_at=?,ends_at=? WHERE id='hosting-transfer'").run(new Date(Date.now()-10000).toISOString(),new Date(Date.now()-1000).toISOString());assert.equal((await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send})).errorCode,'HOSTING_EXPIRED');assert.equal(r.calls.length,count);
 }finally{f.db.close();}
});
test('concurrent step lease prevents duplicate network work; expiration stops transfer without provider calls',async()=>{
 const f=await fixture(),r=remote();try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'bundle-test-lease','publish');let entered!:()=>void,release!:()=>void;const gate=new Promise<void>(resolve=>release=resolve),ready=new Promise<void>(resolve=>entered=resolve),send=async(...args:Parameters<typeof r.send>)=>{entered();await gate;return r.send(...args);};
  const pending=advanceCmsBundleTransfer(f.env,user,task.id,{send});await ready;const duplicate=await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send});assert.equal(duplicate.state,'pending');assert.equal(r.calls.length,0);release();await pending;assert.equal(r.offsets.length,2);
  const count=r.calls.length,expired=await advanceCmsBundleTransfer(f.env,user,task.id,{send:r.send,now:()=>Date.now()+2*86400000});assert.equal(expired.state,'expired');assert.equal(r.calls.length,count);
 }finally{f.db.close();}
});
test('large publication resumes durable binary preparation in maintenance and requires explicit review before commit',async()=>{
 const f=await fixture(),r=remote(),original=globalThis.fetch,releaseId='rel_'+'9'.repeat(32);let prepared:any=null,commits=0;
 const respond=async(request:Request,status:number,data:unknown,protocol:string)=>{const text=JSON.stringify(data),timestamp=String(Math.floor(Date.now()/1000)),hash=createHash('sha256').update(text).digest('hex'),signature=createHmac('sha256','transfer-test-secret-at-least-thirty-two-bytes').update([protocol+'-RESPONSE',request.headers.get('X-Benos-Nonce'),String(status),timestamp,hash].join('\n')).digest('base64url');return new Response(text,{status,headers:{'X-Benos-Timestamp':timestamp,'X-Benos-Signature':signature}});};
 globalThis.fetch=async(input,init)=>{const request=new Request(input,init),path=new URL(request.url).pathname;assert.equal(new URL(request.url).origin,'https://transfer.example.com');
  if(path==='/benos-health.php')return respond(request,200,{siteId:site,installed:true,capabilities:['bundlePublishV2']},'BENOS-CMS-V1');
  if(path==='/benos-bundle.php'){const input=request.headers.get('content-type')?.startsWith('application/vnd')?new Uint8Array(await request.arrayBuffer()):await request.json(),result=await r.send({},input,'fixture');return respond(request,result.status,result.data,'BENOS-CMS-BUNDLE-V2');}
  assert.equal(path,'/benos-connect.php');const body=await request.json() as any;assert.equal(body.releaseId,releaseId);
  if(body.operation==='status')return respond(request,prepared?200:404,prepared??{error:{code:'RELEASE_NOT_FOUND'}},'BENOS-CMS-V1');
  if(body.operation==='prepare'){assert.equal(typeof body.bundleId,'string');assert.ok(!('manifest' in body)&&!('assets' in body));assert.ok(r.calls.includes('bundle-seal'));prepared={id:releaseId,projectId:project,versionId:f.version,state:'prepared',reviewHash:'b'.repeat(64),summary:{createPages:2,updatePages:0,preserveArticles:0,preserveDrafts:true,replaceGlobalTheme:true,removePages:0}};}
  if(body.operation==='commit'){commits++;assert.equal(body.reviewHash,'b'.repeat(64));prepared.state='published';prepared.backup={id:1,size:100,checksum:'c'.repeat(64)};}
  return respond(request,200,prepared,'BENOS-CMS-V1');
 };
 try{const now=new Date().toISOString();f.db.sqlite.prepare("INSERT INTO publication_releases(id,site_id,user_id,project_id,version_id,idempotency_key,payload_hash,state,created_at,updated_at) VALUES(?,?,?,?,?,'bundle-publication',?,'preparing',?,?)").run(releaseId,site,user,project,f.version,'0'.repeat(64),now,now);
  await runPublicationOperation(f.env,user,releaseId,'prepare');let release=f.db.sqlite.prepare('SELECT * FROM publication_releases WHERE id=?').get(releaseId)!;assert.equal(release.state,'preparing');assert.ok(release.bundle_transfer_id);assert.ok(JSON.parse(String(release.result_json)).transfer.bytesSent>0);assert.equal(commits,0);
  await assert.rejects(runPublicationOperation(f.env,user,releaseId,'commit','b'.repeat(64)),/核对|确认/);
  const result=await continuePublicationPreparations(f.env);assert.equal(result.failed,0);release=f.db.sqlite.prepare('SELECT * FROM publication_releases WHERE id=?').get(releaseId)!;assert.equal(release.state,'prepared');assert.equal(commits,0);assert.equal(f.db.sqlite.prepare('SELECT published_version_id FROM projects').get()!.published_version_id,null);
  await assert.rejects(runPublicationOperation(f.env,user,releaseId,'commit','d'.repeat(64)),/确认/);await runPublicationOperation(f.env,user,releaseId,'commit','b'.repeat(64));assert.equal(commits,1);assert.equal(f.db.sqlite.prepare('SELECT published_version_id FROM projects').get()!.published_version_id,f.version);
 }finally{globalThis.fetch=original;f.db.close();}
});
