import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { randomToken,sha256,encryptSecret } from '../src/lib/crypto';
import { deleteAiConfiguration } from '../src/modules/integrations';
import { functionalTestQuote,runFunctionalTest,listFunctionalTests } from '../src/modules/integration-tests';
import { seedCapabilityFixture } from './integration-test-helper';
import { app } from '../src/index';
import type { User } from '../src/env';

const pricing={baseUrl:'https://api.openai.com/v1',model:'gpt-6-sol',protocol:'responses',providerPoolId:'openai',inputMicrosPerMillion:2_000_000,cachedInputMicrosPerMillion:200_000,outputMicrosPerMillion:10_000_000,contextTokens:1_050_000,maxOutputTokens:10000,billingProfile:'openai-gpt6-standard-2026-11-07',cacheTtl:'30m',pricingConfirmedAt:new Date().toISOString()};
const reason={reason:'移除不再使用的配置'};
async function fixture(){
 const db=new TestD1(),env=testEnv(db),now=new Date().toISOString();
 for(const role of ['owner','admin','user','support'])db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(role,role+'@example.test',role,'fixture',role,now,now);
 db.sqlite.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES('p','user','P',?,?)").run(now,now);
 db.sqlite.prepare("INSERT INTO provider_pools(provider_id,funded_micros,updated_at_ms) VALUES('openai',1000000,?)").run(Date.now());
 const secret=await encryptSecret(JSON.stringify({apiKey:'fixture-never-live'}),env.ENCRYPTION_KEY,'cfg');
 db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,secret_hint,test_status,tested_at,created_by,created_at) VALUES('cfg','text','Text','openai',1,'tested',?,?,'live','passed',?,'owner',?)").run(JSON.stringify(pricing),secret,now,now);
 async function request(path:string,method='POST',data:unknown={},role='owner',csrfValid=true){
  const token=randomToken(),csrf=randomToken();db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run(token,await sha256(token),role,csrf,now,'2099-01-01T00:00:00.000Z','fixture');
  return app.fetch(new Request(env.APP_ORIGIN+'/api/admin/integrations'+path,{method,headers:{origin:env.APP_ORIGIN,cookie:'benos_session='+token,'x-csrf-token':csrfValid?csrf:'wrong','content-type':'application/json'},body:method==='GET'?undefined:JSON.stringify(data)}),env);
 }
 function job(table:'ai_jobs'|'image_jobs',state:string,reservationId:string|null=null,jobId='job'){
  db.sqlite.prepare(`INSERT INTO ${table}(id,user_id,project_id,config_version_id,request_key,request_hash,reservation_id,state,request_json,pricing_json,created_at,updated_at) VALUES(?,'user','p','cfg',?,?,?,?,'{}',?,?,?)`).run(jobId,jobId,'fixture',reservationId,state,JSON.stringify(pricing),now,now);
 }
 function workflow(state='ready'){
  db.sqlite.prepare("INSERT INTO ai_workflows(id,user_id,project_id,config_version_id,provider_id,request_key,request_hash,scope_json,requirements_json,pricing_json,reference_images_json,manifest_json,max_steps,max_cost_micros,per_step_micros,state,created_at,updated_at) VALUES('w','user','p','cfg','openai','workflow','fixture','{}','{}',?,'[]','{}',1,100,100,?,?,?)").run(JSON.stringify(pricing),state,now,now);
 }
 return {db,env,now,request,job,workflow};
}

test('deletion is atomic, idempotent, clears only credentials and preserves historical accounting',async()=>{
 const f=await fixture();try{
  await seedCapabilityFixture(f.env.DB,'cfg');f.job('ai_jobs','succeeded');f.job('image_jobs','failed',null,'image');f.workflow('succeeded');
  const before=f.db.sqlite.prepare('SELECT * FROM integration_function_tests').get(),pool=f.db.sqlite.prepare('SELECT * FROM provider_pools').get();
  const replies=await Promise.all(Array.from({length:6},()=>deleteAiConfiguration(f.env,'owner','cfg',reason)));assert.equal(replies.filter(x=>!x.alreadyDeleted).length,1);
  const row=f.db.sqlite.prepare("SELECT * FROM integration_configs WHERE id='cfg'").get()!;assert.ok(row.deleted_at);assert.equal(row.deleted_by,'owner');assert.equal(row.deleted_reason,reason.reason);assert.equal(row.secret_ciphertext,null);assert.equal(row.secret_hint,null);assert.equal(row.public_config_json,JSON.stringify(pricing));
  assert.deepEqual(f.db.sqlite.prepare('SELECT * FROM integration_function_tests').get(),before);assert.deepEqual(f.db.sqlite.prepare('SELECT * FROM provider_pools').get(),pool);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM ai_jobs').get()!.n,1);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='integration.delete'").get()!.n,1);assert.equal((await listFunctionalTests(f.env,'cfg')).items.length,1);
  assert.equal((await deleteAiConfiguration(f.env,'owner','cfg',{reason:'重复请求不改原原因'})).alreadyDeleted,true);assert.equal(f.db.sqlite.prepare('SELECT deleted_reason FROM integration_configs').get()!.deleted_reason,reason.reason);
  const list=await (await f.request('','GET')).json() as any;assert.deepEqual(list.data.items,[]);
  const historical=await (await f.request('/cfg','GET')).json() as any;assert.equal(historical.data.id,'cfg');assert.equal(historical.data.deletedBy,'owner');assert.equal(historical.data.deletionReason,reason.reason);assert.equal(historical.data.hasSecret,false);
 }finally{f.db.close();}
});

test('only owner can delete inactive AI configurations with a valid reason and CSRF',async()=>{
 const f=await fixture();try{
  for(const role of ['admin','support','user'])assert.equal((await f.request('/cfg','DELETE',reason,role)).status,403);
  assert.equal((await f.request('/cfg','DELETE',reason,'owner',false)).status,403);
  for(const data of [{},{reason:'短'},{reason:'x'.repeat(501)},{...reason,force:true}])assert.equal((await f.request('/cfg','DELETE',data)).status,400);
  f.db.sqlite.prepare("UPDATE integration_configs SET status='active'").run();assert.equal((await f.request('/cfg','DELETE',reason)).status,409);
  f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled',kind='email'").run();const blocked=await f.request('/cfg','DELETE',reason);assert.equal((await blocked.json() as any).error.code,'DELETE_KIND_UNSUPPORTED');
  assert.equal((await f.request('/missing','DELETE',reason)).status,404);assert.equal(f.db.sqlite.prepare('SELECT deleted_at FROM integration_configs').get()!.deleted_at,null);
 }finally{f.db.close();}
});

test('deleted configurations cannot be tested, activated, disabled, reused or issue a new billable test',async()=>{
 const f=await fixture();try{
  await deleteAiConfiguration(f.env,'owner','cfg',reason);
  for(const [path,data] of [['/cfg/test',{}],['/cfg/activate',{}],['/cfg/disable',reason]] as const){const res=await f.request(path,'POST',data);assert.equal(res.status,409);assert.equal((await res.json() as any).error.code,'CONFIG_DELETED');}
  const quote=await functionalTestQuote(f.env,'cfg');assert.equal(quote.available,false);assert.ok('reason' in quote);assert.equal(quote.reason,'CONFIG_DELETED');
  const res=await f.request('','POST',{kind:'text',name:'Reuse',provider:'openai',publicConfig:pricing,secretSourceConfigId:'cfg'});assert.equal(res.status,409);assert.equal((await res.json() as any).error.code,'CONFIG_DELETED');
  let calls=0;const actor=f.db.sqlite.prepare("SELECT * FROM users WHERE id='owner'").get() as unknown as User;
  await assert.rejects(()=>runFunctionalTest(f.env,actor,'cfg',{requestKey:'deleted-no-new-test',quoteHash:'a'.repeat(64),maxCostMicros:10000000,confirmedCharge:true},{fetch:async()=>{calls++;return Response.json({});}}),/已删除/);assert.equal(calls,0);
  assert.throws(()=>f.db.sqlite.prepare("UPDATE integration_configs SET status='active' WHERE id='cfg'").run(),/config_deleted/);
 }finally{f.db.close();}
});

test('every outstanding AI/image job and held reservation prevents deletion even when marked failed',async()=>{
 for(const table of ['ai_jobs','image_jobs'] as const)for(const state of ['preparing','reserved','running','uncertain',...(table==='image_jobs'?['output_pending']:[])]){
  const f=await fixture();try{f.job(table,state);await assert.rejects(()=>deleteAiConfiguration(f.env,'owner','cfg',reason),(error:any)=>error.code==='CONFIG_IN_USE');assert.ok(f.db.sqlite.prepare('SELECT secret_ciphertext FROM integration_configs').get()!.secret_ciphertext);}finally{f.db.close();}
 }
 const f=await fixture();try{
  f.db.sqlite.prepare("INSERT INTO api_reservations(id,user_id,provider_id,request_key,amount_micros,state,created_at_ms) VALUES('held','user','openai','held',10,'uncertain',0)").run();f.job('ai_jobs','failed','held');
  await assert.rejects(()=>deleteAiConfiguration(f.env,'owner','cfg',reason),(error:any)=>error.code==='CONFIG_IN_USE');
 }finally{f.db.close();}
});

test('unfinished workflows, steps and operations tests block deletion',async()=>{
 for(const state of ['ready','processing','uncertain']){const f=await fixture();try{f.workflow(state);await assert.rejects(()=>deleteAiConfiguration(f.env,'owner','cfg',reason),(error:any)=>error.code==='CONFIG_IN_USE');}finally{f.db.close();}}
 const f=await fixture();try{f.workflow('failed');f.db.sqlite.prepare("INSERT INTO ai_workflow_steps(id,workflow_id,ordinal,reservation_id,state,created_at,updated_at) VALUES('step','w',1,'no-reservation','responded',?,?)").run(f.now,f.now);await assert.rejects(()=>deleteAiConfiguration(f.env,'owner','cfg',reason),(error:any)=>error.code==='CONFIG_IN_USE');}finally{f.db.close();}
 for(const state of ['created','reserved','running','uncertain']){const f=await fixture();try{
  await seedCapabilityFixture(f.env.DB,'cfg');f.db.sqlite.prepare("UPDATE integration_function_tests SET state=?,accounting_state='held',actual_micros=NULL").run(state);
  await assert.rejects(()=>deleteAiConfiguration(f.env,'owner','cfg',reason),(error:any)=>error.code==='CONFIG_IN_USE');
 }finally{f.db.close();}}
});

test('deletion audits roll back with credential removal and permission is checked in the mutation transaction',async()=>{
 const f=await fixture();try{
  f.db.sqlite.exec("CREATE TRIGGER fail_delete_audit BEFORE INSERT ON audit_logs WHEN NEW.action='integration.delete' BEGIN SELECT RAISE(ABORT,'fixture-audit-fail'); END;");
  await assert.rejects(()=>deleteAiConfiguration(f.env,'owner','cfg',reason));assert.equal(f.db.sqlite.prepare('SELECT deleted_at FROM integration_configs').get()!.deleted_at,null);assert.ok(f.db.sqlite.prepare('SELECT secret_ciphertext FROM integration_configs').get()!.secret_ciphertext);
  f.db.sqlite.exec('DROP TRIGGER fail_delete_audit');const batch=f.db.batch.bind(f.db);let revoke=true;
  f.db.batch=async<T=Record<string,unknown>>(statements:Parameters<typeof batch>[0])=>{if(revoke){revoke=false;f.db.sqlite.prepare("UPDATE users SET role='admin' WHERE id='owner'").run();}return batch<T>(statements);};
  await assert.rejects(()=>deleteAiConfiguration(f.env,'owner','cfg',reason),(error:any)=>error.code==='FORBIDDEN');assert.equal(f.db.sqlite.prepare('SELECT deleted_at FROM integration_configs').get()!.deleted_at,null);
 }finally{f.db.close();}
});

test('database guards close racing new-job, activation and deletion windows',async()=>{
 const f=await fixture();try{
  await deleteAiConfiguration(f.env,'owner','cfg',reason);
  assert.throws(()=>f.job('ai_jobs','preparing'),/config_deleted/);assert.throws(()=>f.job('image_jobs','preparing'),/config_deleted/);assert.throws(()=>f.workflow(),/config_deleted/);
  await assert.rejects(()=>seedCapabilityFixture(f.env.DB,'cfg'),/config_deleted/);
 }finally{f.db.close();}
 const g=await fixture();try{
  const batch=g.db.batch.bind(g.db);let inject=true;
  g.db.batch=async<T=Record<string,unknown>>(statements:Parameters<typeof batch>[0])=>{if(inject){inject=false;g.job('ai_jobs','preparing');}return batch<T>(statements);};
  await assert.rejects(()=>deleteAiConfiguration(g.env,'owner','cfg',reason),(error:any)=>error.code==='CONFIG_IN_USE');assert.equal(g.db.sqlite.prepare('SELECT deleted_at FROM integration_configs').get()!.deleted_at,null);
 }finally{g.db.close();}
});
