import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash,createHmac } from 'node:crypto';
import { encodeCmsBundleChunk,signCmsBundleRequest,cmsBundleRequest,CMS_BUNDLE_PROTOCOL } from '../src/lib/cms-bundle';
const credentials={url:'https://cms.benos-fixture.com/benos-bundle.php',siteId:'site_'+'1'.repeat(32),keyId:'bundle-key',secret:'private-bundle-fixture-'.repeat(3)};
const hash=(value:Uint8Array|string)=>createHash('sha256').update(value).digest('hex');
test('binary CMS envelope hashes exact bytes and binds all metadata to the existing HMAC canonical format',async()=>{
 const payload=new Uint8Array([0,1,255,0,128]),frame=await encodeCmsBundleChunk('bundle_'+'2'.repeat(32),'assets/0.gif',0,payload),size=new DataView(frame.buffer).getUint32(4,false),metadata=JSON.parse(new TextDecoder().decode(frame.subarray(8,8+size)));
 assert.equal(new TextDecoder().decode(frame.subarray(0,4)),'BNB2');assert.deepEqual(frame.subarray(8+size),payload);assert.equal(metadata.sha256,hash(payload));assert.equal(metadata.size,payload.length);
 const headers=await signCmsBundleRequest(credentials,frame,'binary_fixture_request',true),canonical=[CMS_BUNDLE_PROTOCOL,credentials.keyId,credentials.siteId,headers['X-Benos-Timestamp'],headers['X-Benos-Nonce'],'POST','/benos-bundle.php',hash(frame),'binary_fixture_request'].join('\n');assert.equal(headers['X-Benos-Signature'],createHmac('sha256',credentials.secret).update(canonical).digest('base64url'));assert.equal(headers['Content-Type'],'application/vnd.benos.bundle-v2');
 await assert.rejects(encodeCmsBundleChunk('bundle_'+'2'.repeat(32),'../config/local.php',0,payload));await assert.rejects(encodeCmsBundleChunk('bundle_'+'2'.repeat(32),'assets/0.gif',1,payload));await assert.rejects(encodeCmsBundleChunk('bundle_'+'2'.repeat(32),'assets/0.gif',0,new Uint8Array(1048577)));
});
test('CMS bundle client verifies signed responses and never follows redirects or retries a lost acknowledgement',async()=>{
 const original=globalThis.fetch;let calls=0;
 try{
  globalThis.fetch=(async(_url:any,init:any)=>{calls++;assert.equal(init.redirect,'manual');const raw=JSON.stringify({state:'receiving'}),time=String(Math.floor(Date.now()/1000)),signature=createHmac('sha256',credentials.secret).update([CMS_BUNDLE_PROTOCOL+'-RESPONSE',init.headers['X-Benos-Nonce'],'200',time,hash(raw)].join('\n')).digest('base64url');return new Response(raw,{headers:{'X-Benos-Timestamp':time,'X-Benos-Signature':signature}});}) as typeof fetch;
  assert.deepEqual(await cmsBundleRequest(credentials,{operation:'bundle-status',bundleId:'bundle_'+'2'.repeat(32)},'status_request_one'),{status:200,data:{state:'receiving'}});
  globalThis.fetch=(async()=>{calls++;throw new Error('Acknowledgement lost');}) as typeof fetch;await assert.rejects(cmsBundleRequest(credentials,{operation:'bundle-seal'},'seal_request_one'),/Acknowledgement/);assert.equal(calls,2);
  globalThis.fetch=(async()=>new Response('{}',{status:302,headers:{location:'https://other.example.com'}})) as typeof fetch;await assert.rejects(cmsBundleRequest(credentials,{},'redirect_request_one'),/重定向/);
  globalThis.fetch=(async()=>new Response('{}',{headers:{'X-Benos-Timestamp':String(Math.floor(Date.now()/1000)),'X-Benos-Signature':'forged'}})) as typeof fetch;await assert.rejects(cmsBundleRequest(credentials,{},'forged_request_one'),/签名/);
  globalThis.fetch=(async()=>new Response('x'.repeat(65537))) as typeof fetch;await assert.rejects(cmsBundleRequest(credentials,{},'oversized_response_one'),/过大/);
  await assert.rejects(cmsBundleRequest({...credentials,url:'http://127.0.0.1/benos-bundle.php'},{},'private_network_one'),/HTTPS/);
 }finally{globalThis.fetch=original;}
});
