import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { TestD1,testEnv } from './d1-helper';
import { allocateHostingJob,syncHostingPool,availableHostingPool,listHostingPools,refreshHostingPools } from '../src/modules/hosting-pools';
import { encryptSecret,sha256 } from '../src/lib/crypto';
import { app } from '../src/index';
import { maintenance } from '../src/modules/maintenance';
import { reconcileHostingEntitlements,runProvisioningJob } from '../src/modules/hosting';

async function fixture(){
 const db=new TestD1(),env=testEnv(db),now=new Date().toISOString();
 db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES('owner','owner@example.test','Owner','unused','owner',?,?)").run(now,now);
 for(const [name,username,order,priority] of [['a','u100001',1,1],['b','u100002',2,2]] as const){
  const configId='cfg_'+name,config={adapter:'hostinger-hpanel',deploymentMode:'hostinger-tus-bootstrap',accountUsername:username,hostingOrderId:order};
  db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES(?,'hosting',?,'benos-bridge',1,'active',?,?,'passed','owner',?)").run(configId,name,JSON.stringify(config),await encryptSecret(JSON.stringify({hostingerApiToken:'fixture-token-only'}),env.ENCRYPTION_KEY,configId),now);
  db.sqlite.prepare("INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,state,priority,max_sites,max_databases,observed_at,created_at,updated_at) VALUES(?,?,?,?,?,'accepting',?,100,100,?,?,?)").run(name,name,username,order,configId,priority,now,now,now);
 }
 const job=(n:number)=>{
  const siteId='site_'+n,jobId='job_'+n;
  db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,created_at,updated_at) VALUES(?,'owner','Customer',?,'cms@example.test',?,?)").run(siteId,`customer${n}.example.com`,now,now);
  db.sqlite.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,step,idempotency_key,payload_hash,lease_token,created_at,updated_at) VALUES(?,?,'owner','create','allocate',?,'hash','lease',?,?)").run(jobId,siteId,jobId,now,now);return jobId;
 };return {db,env,job};
}
test('concurrent customers fill A at 100 and use B; replay or uncertain jobs never release or double allocate',async()=>{
 const f=await fixture();try{
  const ids=Array.from({length:101},(_,n)=>f.job(n));
  const choices=await Promise.all(ids.map(j=>allocateHostingJob(f.env,j,'lease')));
  assert.equal(choices.filter(c=>c==='cfg_a').length,100);assert.equal(choices.filter(c=>c==='cfg_b').length,1);
  assert.equal(await allocateHostingJob(f.env,ids[0],'lease'),'cfg_a');
  f.db.sqlite.prepare("UPDATE provisioning_jobs SET state='uncertain' WHERE id=?").run(ids[0]);
  assert.equal((await listHostingPools(f.env)).items[0].allocated,100);
  f.db.sqlite.prepare("UPDATE hosting_pools SET state='draining' WHERE id='a'").run();
  assert.equal(await allocateHostingJob(f.env,ids[0],'lease'),'cfg_a');
  assert.equal(await allocateHostingJob(f.env,f.job(102),'lease'),'cfg_b');
  assert.throws(()=>f.db.sqlite.prepare('DELETE FROM hosting_allocations WHERE job_id=?').run(ids[0]),/hosting_allocation_no_delete/);
 }finally{f.db.close();}
});

test('pre-pool jobs reserve their original capacity before adoption and remain pinned across credential rotation',async()=>{
 const f=await fixture();try{
  const ids=Array.from({length:100},(_,n)=>f.job(n));
  f.db.sqlite.prepare("UPDATE provisioning_jobs SET config_version_id='cfg_a',state='uncertain'").run();
  assert.equal((await listHostingPools(f.env)).items[0].allocated,100);
  assert.equal(await allocateHostingJob(f.env,f.job(100),'lease'),'cfg_b');
  await syncHostingPool(f.env,'a',{inspect:async()=>({domains:ids.map((_,n)=>`customer${n}.example.com`),databases:[]})});
  assert.equal((await listHostingPools(f.env)).items[0].external_sites,0);
  f.db.sqlite.prepare(`INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at)
   SELECT 'cfg_a2',kind,name,provider,2,status,public_config_json,secret_ciphertext,test_status,created_by,created_at FROM integration_configs WHERE id='cfg_a'`).run();
  f.db.sqlite.prepare("UPDATE hosting_pools SET config_version_id='cfg_a2',state='draining',observed_at='2020-01-01T00:00:00.000Z' WHERE id='a'").run();
  assert.equal(await allocateHostingJob(f.env,ids[0],'lease'),'cfg_a');
  assert.equal(await allocateHostingJob(f.env,ids[0],'lease'),'cfg_a');
  assert.equal(await allocateHostingJob(f.env,ids[1],'wrong-lease'),null);
  assert.equal((await listHostingPools(f.env)).items[0].allocated,100);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_allocations WHERE pool_id=\'a\'').get()!.n,1);
  assert.equal(await allocateHostingJob(f.env,f.job(101),'lease'),'cfg_b');
 }finally{f.db.close();}
});

test('unaccounted legacy task cannot dispatch outside a registered pool',async()=>{
 const f=await fixture(),original=globalThis.fetch;let requests=0;
 try{
  const jobId=f.job(1),now=new Date().toISOString(),end=new Date(Date.now()+86400000).toISOString();
  f.db.sqlite.prepare("UPDATE provisioning_jobs SET config_version_id='cfg_a' WHERE id=?").run(jobId);
  f.db.sqlite.prepare("DELETE FROM hosting_pools WHERE id='a'").run();
  f.db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES('annual','owner','site_1','annual',?,?,'active',?)").run(now,end,now);
  globalThis.fetch=async()=>{requests++;throw Error('No external call allowed');};
  await runProvisioningJob(f.env,'owner',jobId);
  assert.equal(requests,0);
  assert.equal(f.db.sqlite.prepare('SELECT error_code FROM provisioning_jobs WHERE id=?').get(jobId)!.error_code,'HOSTING_NOT_CONFIGURED');
  assert.equal(f.db.sqlite.prepare('SELECT config_version_id FROM provisioning_jobs WHERE id=?').get(jobId)!.config_version_id,'cfg_a');
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_allocations').get()!.n,0);
 }finally{globalThis.fetch=original;f.db.close();}
});

test('draining A and disabling its provisioning credential preserves existing CMS leases on A',async()=>{
 const f=await fixture(),original=globalThis.fetch,secret='site-owned-lease-fixture-'.repeat(3);let calls=0;
 try{
  const job=f.job(1),now=new Date().toISOString(),end=new Date(Date.now()+86400000).toISOString();
  await allocateHostingJob(f.env,job,'lease');
  f.db.sqlite.prepare("UPDATE provisioning_jobs SET state='succeeded' WHERE id=?").run(job);
  f.db.sqlite.prepare("UPDATE sites SET state='connected' WHERE id='site_1'").run();
  f.db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES('annual','owner','site_1','annual',?,?,'active',?)").run(now,end,now);
  f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_a','site_1','https://customer1.example.com','site-key',?,'/benos-health.php','1.9.21',?,?)").run(await encryptSecret(secret,f.env.ENCRYPTION_KEY,'site_1'),now,now);
  f.db.sqlite.prepare("UPDATE hosting_pools SET state='draining' WHERE id='a'").run();
  f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled' WHERE id='cfg_a'").run();
  globalThis.fetch=async(input,init)=>{
   calls++;const req=new Request(input,init);assert.equal(req.url,'https://customer1.example.com/benos-connect.php');
   const payload=await req.json() as any;delete payload.operation;assert.equal(payload.hostingActive,true);
   const raw=JSON.stringify({siteId:'site_1',...payload}),stamp=String(Math.floor(Date.now()/1000));
   const sig=createHmac('sha256',secret).update(['BENOS-CMS-V1-RESPONSE',req.headers.get('X-Benos-Nonce'),'200',stamp,await sha256(raw)].join('\n')).digest('base64url');
   return new Response(raw,{headers:{'Content-Type':'application/json','X-Benos-Timestamp':stamp,'X-Benos-Signature':sig}});
  };
  assert.deepEqual(await reconcileHostingEntitlements(f.env,'site_1'),{synced:1,failed:0});assert.equal(calls,1);
  assert.equal(f.db.sqlite.prepare("SELECT state FROM sites WHERE id='site_1'").get()!.state,'connected');
  assert.equal(await allocateHostingJob(f.env,f.job(2),'lease'),'cfg_b');
  assert.equal(f.db.sqlite.prepare('SELECT config_version_id FROM hosting_allocations WHERE job_id=?').get(job)!.config_version_id,'cfg_a');
 }finally{globalThis.fetch=original;f.db.close();}
});
test('external inventory, database capacity, freshness, disabled credentials and scope mismatch prevent over-allocation',async()=>{
 const f=await fixture();try{
  await syncHostingPool(f.env,'a',{inspect:async()=>({domains:Array.from({length:99},(_,n)=>`external${n}.example.com`),databases:[]})});
  assert.equal(await allocateHostingJob(f.env,f.job(1),'lease'),'cfg_a');
  assert.equal(await allocateHostingJob(f.env,f.job(2),'lease'),'cfg_b');
  f.db.sqlite.prepare("UPDATE hosting_pools SET external_databases=100 WHERE id='b'").run();assert.equal(await allocateHostingJob(f.env,f.job(3),'lease'),null);
  await syncHostingPool(f.env,'a',{inspect:async()=>({domains:['customer1.example.com'],databases:[]})});
  assert.equal((await listHostingPools(f.env)).items[0].external_sites,0);
  f.db.sqlite.prepare("UPDATE hosting_pools SET observed_at='2020-01-01T00:00:00.000Z'").run();assert.equal(await availableHostingPool(f.env),null);
  f.db.sqlite.prepare("UPDATE hosting_pools SET config_version_id='cfg_b' WHERE id='a'").run();await assert.rejects(syncHostingPool(f.env,'a',{inspect:async()=>{throw Error('must not inspect');}}),/账号与订单/);
  f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled' WHERE id='cfg_b'").run();assert.equal(await availableHostingPool(f.env),null);
 }finally{f.db.close();}
});

test('failed oldest inventory checks rotate behind other connections while stale capacity remains unavailable',async()=>{
 const f=await fixture();try{
  const old='2000-01-01T00:00:00.000Z',now=Date.now();
  for(const [index,name] of ['c','d','e','f'].entries()){
   const number=index+3,configId='cfg_'+name,config={adapter:'hostinger-hpanel',deploymentMode:'hostinger-tus-bootstrap',accountUsername:'u10000'+number,hostingOrderId:number};
   f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES(?,'hosting',?,'benos-bridge',1,'active',?,?,'passed','owner',?)").run(configId,name,JSON.stringify(config),await encryptSecret(JSON.stringify({hostingerApiToken:'fixture-token-only'}),f.env.ENCRYPTION_KEY,configId),old);
   f.db.sqlite.prepare("INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,state,priority,max_sites,max_databases,observed_at,created_at,updated_at) VALUES(?,?,?,?,?,'accepting',?,100,100,?,?,?)").run(name,name,config.accountUsername,number,configId,number,old,old,old);
  }
  f.db.sqlite.prepare('UPDATE hosting_pools SET observed_at=?,updated_at=?').run(old,old);const visited:string[]=[];
  const inspect=async(config:{accountUsername:string;hostingOrderId:number})=>{visited.push(config.accountUsername);if(config.hostingOrderId<=3)throw Error('Persistent fixture provider failure');return {domains:[],databases:[]};};
  assert.deepEqual(await refreshHostingPools(f.env,{nowMs:now,inspect}),{synced:0,failed:3});assert.deepEqual(visited,['u100001','u100002','u100003']);assert.equal(await availableHostingPool(f.env,now),null);assert.equal(await allocateHostingJob(f.env,f.job(301),'lease',now),null);
  for(const name of ['a','b','c']){const row=f.db.sqlite.prepare('SELECT observed_at,updated_at,sync_error FROM hosting_pools WHERE id=?').get(name)!;assert.equal(row.observed_at,old);assert.equal(row.updated_at,new Date(now).toISOString());assert.equal(row.sync_error,'HOSTING_INVENTORY_UNCONFIRMED');}
  assert.deepEqual(await refreshHostingPools(f.env,{nowMs:now+1000,inspect}),{synced:3,failed:0});assert.deepEqual(visited.slice(3),['u100004','u100005','u100006']);for(const name of ['d','e','f']){const row=f.db.sqlite.prepare('SELECT observed_at,updated_at FROM hosting_pools WHERE id=?').get(name)!;assert.equal(row.observed_at,new Date(now+1000).toISOString());assert.equal(row.updated_at,new Date(now+1000).toISOString());}
  assert.equal(await allocateHostingJob(f.env,f.job(302),'lease',now+1000),'cfg_d');
 }finally{f.db.close();}
});

test('an in-flight inventory lease is excluded from refresh batches and becomes eligible after expiry',async()=>{
 const f=await fixture();try{
  const now=Date.now(),old='2000-01-01T00:00:00.000Z';f.db.sqlite.prepare('UPDATE hosting_pools SET observed_at=?,updated_at=?').run(old,old);f.db.sqlite.prepare("UPDATE hosting_pools SET inventory_lease_token='existing-attempt',inventory_lease_until_ms=? WHERE id='a'").run(now+5000);const visited:number[]=[];
  const inspect=async(config:{hostingOrderId:number})=>{visited.push(config.hostingOrderId);return {domains:[],databases:[]};};assert.deepEqual(await refreshHostingPools(f.env,{nowMs:now,inspect}),{synced:1,failed:0});assert.deepEqual(visited,[2]);assert.equal(f.db.sqlite.prepare("SELECT updated_at FROM hosting_pools WHERE id='a'").get()!.updated_at,old);
  assert.deepEqual(await refreshHostingPools(f.env,{nowMs:now+5000,inspect}),{synced:1,failed:0});assert.deepEqual(visited,[2,1]);const row=f.db.sqlite.prepare("SELECT inventory_lease_token,updated_at FROM hosting_pools WHERE id='a'").get()!;assert.equal(row.inventory_lease_token,null);assert.equal(row.updated_at,new Date(now+5000).toISOString());
 }finally{f.db.close();}
});

test('manual capacity edits fence an in-flight snapshot even when the credential version is unchanged',async()=>{
 const f=await fixture();try{
  const now=new Date().toISOString(),session='same-config-owner'.padEnd(43,'x'),observed=f.db.sqlite.prepare("SELECT observed_at FROM hosting_pools WHERE id='a'").get()!.observed_at;
  f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session','owner',await sha256(session),'csrf',now,'2099-01-01T00:00:00.000Z','test');
  await assert.rejects(syncHostingPool(f.env,'a',{inspect:async()=>{
   const response=await app.request('/api/admin/hosting-pools/a',{method:'PATCH',headers:{origin:f.env.APP_ORIGIN,cookie:'benos_session='+session,'x-csrf-token':'csrf','content-type':'application/json'},body:JSON.stringify({name:'Edited A',configId:'cfg_a',maxSites:90,maxDatabases:90,priority:1,state:'accepting',reason:'核对期间调整连接容量',revision:1})},f.env);assert.equal(response.status,200);return {domains:['unexpected.example.com'],databases:[]};
  }}),/连接发生变化/);
  const row=f.db.sqlite.prepare("SELECT revision,max_sites,external_sites,observed_at,sync_error FROM hosting_pools WHERE id='a'").get()!;assert.equal(row.revision,2);assert.equal(row.max_sites,90);assert.equal(row.external_sites,0);assert.equal(row.observed_at,observed);assert.equal(row.sync_error,'HOSTING_INVENTORY_CHANGED');assert.equal(await allocateHostingJob(f.env,f.job(401),'lease'),'cfg_b');
 }finally{f.db.close();}
});
test('recovery mode rejects all traffic and scheduled work before any storage or external operation',async()=>{
 const f=await fixture();try{
  f.env.RECOVERY_MODE='true';let tasks=0;
  for(const path of ['/','/api/health','/api/webhooks/stripe/cfg_'+'a'.repeat(32)]){
   const response=await app.request(path,{method:path.includes('webhooks')?'POST':'GET'},f.env);
   assert.equal(response.status,503);assert.equal(response.headers.get('cache-control'),'no-store');
  }
  const result=await maintenance(f.env,{tasks:[{name:'must-not-run',run:async()=>{tasks++;}}]});assert.equal(result.state,'recovery_mode');assert.equal(tasks,0);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM maintenance_runs').get()!.n,0);
 }finally{f.db.close();}
});
test('resource inventory sync is serialized; configuration changes cannot accept stale success',async()=>{
 const f=await fixture();let release!:()=>void;
 try{
  const waiting=new Promise<void>(resolve=>release=resolve);let started!:()=>void;const entered=new Promise<void>(resolve=>started=resolve);
  const first=syncHostingPool(f.env,'a',{inspect:async()=>{started();await waiting;return {domains:[],databases:[]};}});
  await entered;await assert.rejects(syncHostingPool(f.env,'a',{inspect:async()=>({domains:[],databases:[]})}),/正在核对/);
  f.db.sqlite.prepare("UPDATE hosting_pools SET config_version_id='cfg_b' WHERE id='a'").run();release();await assert.rejects(first,/连接发生变化/);
  assert.ok(f.db.sqlite.prepare("SELECT sync_error FROM hosting_pools WHERE id='a'").get()!.sync_error);
 }finally{release?.();f.db.close();}
});

test('an inventory result arriving after its lease expires cannot refresh the capacity snapshot',async()=>{
 const f=await fixture();try{
  const observed=f.db.sqlite.prepare("SELECT observed_at FROM hosting_pools WHERE id='a'").get()!.observed_at;
  await assert.rejects(syncHostingPool(f.env,'a',{inspect:async()=>{
   f.db.sqlite.prepare("UPDATE hosting_pools SET inventory_lease_until_ms=0 WHERE id='a'").run();
   return {domains:[],databases:[]};
  }}),/核对期间/);
  const row=f.db.sqlite.prepare("SELECT observed_at,sync_error,inventory_lease_token FROM hosting_pools WHERE id='a'").get()!;
  assert.equal(row.observed_at,observed);assert.equal(row.sync_error,'HOSTING_INVENTORY_CHANGED');assert.equal(row.inventory_lease_token,null);
  assert.equal(await allocateHostingJob(f.env,f.job(1),'lease'),'cfg_b');
 }finally{f.db.close();}
});

test('changing a pool configuration away and back fences the earlier inventory snapshot',async()=>{
 const f=await fixture();let release!:()=>void;
 try{
  const now=new Date().toISOString(),session='pool-owner-session'.padEnd(43,'x');
  f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session','owner',await sha256(session),'csrf',now,'2099-01-01T00:00:00.000Z','test');
  f.db.sqlite.prepare(`INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at)
   SELECT 'cfg_a2',kind,name,provider,2,status,public_config_json,secret_ciphertext,test_status,created_by,created_at FROM integration_configs WHERE id='cfg_a'`).run();
  const call=(configId:string,revision:number)=>app.request('/api/admin/hosting-pools/a',{method:'PATCH',headers:{origin:f.env.APP_ORIGIN,cookie:'benos_session='+session,'x-csrf-token':'csrf','content-type':'application/json'},body:JSON.stringify({name:'A',configId,maxSites:100,maxDatabases:100,priority:1,state:'draining',reason:'轮换连接凭据',revision})},f.env);
  const waiting=new Promise<void>(resolve=>release=resolve);let started!:()=>void;const entered=new Promise<void>(resolve=>started=resolve);
  const sync=syncHostingPool(f.env,'a',{inspect:async()=>{started();await waiting;return {domains:[],databases:[]};}});await entered;
  assert.equal((await call('cfg_a2',1)).status,200);assert.equal((await call('cfg_a',2)).status,200);
  release();await assert.rejects(sync,/连接发生变化/);
  const row=f.db.sqlite.prepare("SELECT observed_at,inventory_lease_token FROM hosting_pools WHERE id='a'").get()!;
  assert.equal(row.observed_at,null);assert.equal(row.inventory_lease_token,null);
  await syncHostingPool(f.env,'a',{inspect:async()=>({domains:[],databases:[]})});
  assert.ok(f.db.sqlite.prepare("SELECT observed_at FROM hosting_pools WHERE id='a'").get()!.observed_at);
 }finally{release?.();f.db.close();}
});
test('pool administration denies ordinary users and rejects cross-account replacement or capacity reduction below allocations',async()=>{
 const f=await fixture();try{
  const now=new Date().toISOString();
  for(const role of ['user','admin','support'])f.db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,'User','unused',?,?,?)").run(role,role+'@example.test',role,now,now);
  for(const role of ['owner','user','admin','support'])f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run(role,role,await sha256((role+'-session').padEnd(43,'x')),'csrf',now,'2099-01-01T00:00:00.000Z','test');
  const call=(role:string,method:string,path:string,data?:unknown)=>app.request('/api/admin/hosting-pools'+path,{method,headers:{origin:f.env.APP_ORIGIN,cookie:'benos_session='+(role+'-session').padEnd(43,'x'),'x-csrf-token':'csrf','content-type':'application/json'},body:data?JSON.stringify(data):undefined},f.env);
  assert.equal((await call('user','GET','')).status,403);
  assert.equal((await call('support','GET','')).status,403);
  assert.equal((await call('admin','GET','')).status,200);
  const input={name:'A account',configId:'cfg_a',maxSites:100,maxDatabases:100,priority:1,state:'draining',reason:'运营容量配置',revision:1};
  for(const [method,path,data] of [['POST','',input],['PATCH','/a',input],['POST','/a/sync',{}]] as const)assert.equal((await call('admin',method,path,data)).status,403);
  assert.equal((await call('user','GET','/a/sites')).status,403);
  assert.equal((await call('owner','POST','',input)).status,409);
  assert.equal((await call('owner','PATCH','/a',{...input,configId:'cfg_b'})).status,409);
  await allocateHostingJob(f.env,f.job(1),'lease');await allocateHostingJob(f.env,f.job(2),'lease');
  assert.equal((await call('owner','PATCH','/a',{...input,maxSites:1})).status,409);
  assert.equal((await call('owner','PATCH','/a',input)).status,200);
  assert.equal((await call('owner','PATCH','/a',input)).status,409);
  assert.equal(await allocateHostingJob(f.env,f.job(3),'lease'),'cfg_b');
  const sites=await (await call('owner','GET','/a/sites')).json() as any;assert.equal(sites.data.items.length,2);assert.ok(!JSON.stringify(sites).includes('ciphertext'));
 }finally{f.db.close();}
});
