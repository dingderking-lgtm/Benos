import assert from 'node:assert/strict';
import test from 'node:test';
import { createHmac } from 'node:crypto';
import { Hono } from 'hono';
import { type App } from '../src/lib/http';
import { AppError } from '../src/lib/errors';
import { encryptSecret,sha256 } from '../src/lib/crypto';
import { hostingRoutes,hasHostingAccess,normalizeHostingDomain,runProvisioningJob,testHostingConfiguration,reconcileHostingEntitlements } from '../src/modules/hosting';
import { TestD1,testEnv } from './d1-helper';

const app=new Hono<App>();
app.use('*',async(c,next)=>{c.set('requestId','hosting-test');await next();});
app.route('/api/hosting',hostingRoutes);
app.onError((error,c)=>c.json({ok:false,error:{code:error instanceof AppError?error.code:'UNEXPECTED'}},(error instanceof AppError?error.status:500) as 400));
const now=()=>new Date().toISOString();
const future=()=>new Date(Date.now()+86400000).toISOString();
const past=()=>new Date(Date.now()-86400000).toISOString();
const input={name:'Benos 客户网站',domain:'customer.example.com',cmsAdminEmail:'cms@example.com',cmsAdminPassword:'test-cms-password-12345'};
async function fixture(){
  const db=new TestD1(),env=testEnv(db),user='usr_hosting',token='a'.repeat(43),csrf='csrf-testing';
  // These protocol fixtures model an operator-verified hosting resource pool.
  // Pool inventory, concurrency and ownership are tested independently.
  db.sqlite.exec(`CREATE TRIGGER fixture_hosting_pool AFTER INSERT ON integration_configs WHEN NEW.kind='hosting' AND NEW.status='active'
   BEGIN INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,state,priority,max_sites,max_databases,observed_at,created_at,updated_at)
   VALUES('pool_'||NEW.id,'Protocol fixture','u12345678',100,NEW.id,'accepting',1,10,10,NEW.created_at,NEW.created_at,NEW.created_at); END;`);
  db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,'test','user','active',?,?)").run(user,'host@example.com','Owner',now(),now());
  db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('ses_hosting',await sha256(token),user,csrf,now(),future(),'test');
  const call=async(path:string,method='GET',data?:unknown,key='create_site_0001')=>app.fetch(new Request(env.APP_ORIGIN+'/api/hosting'+path,{method,headers:{origin:env.APP_ORIGIN,cookie:'benos_session='+token,'x-csrf-token':csrf,'content-type':'application/json','Idempotency-Key':key},body:data===undefined?undefined:JSON.stringify(data)}),env);
  const subscribe=(includedSites=1)=>db.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,state,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at) VALUES(?,?,'go','paid',?,?,'active',?,16250000,1,?,?)").run('sub_hosting',user,past(),future(),includedSites,'grant_hosting',now());
  return {db,env,user,call,subscribe};
}
async function json(response:Response){return await response.json() as any;}

test('four-field hosting creates an encrypted, idempotent waiting task without inventing a connection',async()=>{
  const f=await fixture();try{
    assert.equal((await f.call('/sites','POST',input)).status,403);
    f.subscribe();
    const response=await f.call('/sites','POST',input);assert.equal(response.status,202);
    const data=(await json(response)).data;
    assert.equal(data.site.state,'pending');assert.equal(data.job.state,'awaiting_input');assert.equal(data.job.errorCode,'HOSTING_NOT_CONFIGURED');
    assert.equal(data.job.result.cmsInstalled,false);assert.equal(data.job.result.httpsVerified,false);
    assert.ok(!JSON.stringify(data).includes(input.cmsAdminPassword));
    const stored=f.db.sqlite.prepare('SELECT * FROM provisioning_jobs WHERE id=?').get(data.job.id)!;
    assert.match(stored.secret_ciphertext as string,/^v1\./);assert.ok(!(stored.secret_ciphertext as string).includes(input.cmsAdminPassword));
    const installWindow=Date.parse(String(stored.secret_expires_at))-Date.parse(String(stored.created_at));
    assert.ok(installWindow>=86400000&&installWindow<=86401000,'encrypted install credentials allow one day for payment and DNS');
    const repeat=(await json(await f.call('/sites','POST',input))).data;assert.equal(repeat.site.id,data.site.id);
    await runProvisioningJob(f.env,f.user,data.job.id);
    assert.equal(f.db.sqlite.prepare('SELECT secret_expires_at FROM provisioning_jobs WHERE id=?').get(data.job.id)!.secret_expires_at,stored.secret_expires_at,'background retries never extend password retention');
    assert.equal((await f.call('/sites','POST',{...input,name:'changed'})).status,409);
    assert.equal((await f.call('/sites','POST',{...input,domain:'other.example.com'},'create_site_0002')).status,409);
    assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM sites').get()!.n,1);
    assert.equal((await json(await f.call('/sites'))).data.entitlement.canCreate,false);
  }finally{f.db.close();}
});

test('ownership, expired membership, annual hosting and publish freeze are enforced server-side',async()=>{
  const f=await fixture();try{
    f.subscribe();const data=(await json(await f.call('/sites','POST',input))).data;
    assert.equal((await f.call('/sites/site_'+'f'.repeat(32))).status,404);
    assert.equal((await f.call('/jobs/job_'+'f'.repeat(32))).status,404);
    f.db.sqlite.prepare('UPDATE subscriptions SET ends_at=?').run(new Date(Date.now()-1000).toISOString());
    assert.equal(await hasHostingAccess(f.env,f.user,data.site.id),false);
    assert.equal((await f.call('/jobs/'+data.job.id+'/retry','POST',{})).status,403);
    f.db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES(?,?,?,'annual',?,?,'active',?)").run('annual_hosting',f.user,data.site.id,past(),future(),now());
    assert.equal(await hasHostingAccess(f.env,f.user,data.site.id),true);
    assert.equal((await f.call('/jobs/'+data.job.id+'/retry','POST',{})).status,202);
    assert.equal((await f.call('/sites/'+data.site.id+'/publish','POST',{})).status,409);
    f.db.sqlite.prepare("INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,actor_id,created_at) VALUES(?,?,'publish','test freeze',?,?,?)").run('rst_hosting',f.user,past(),f.user,now());
    assert.equal((await f.call('/sites/'+data.site.id+'/publish','POST',{})).status,403);
    assert.equal((await f.call('/jobs/'+data.job.id+'/retry','POST',{})).status,403);
    assert.equal((await f.call('/sites','POST',{...input,domain:'new.example.com'},'create_site_0003')).status,403);
  }finally{f.db.close();}
});

test('password expiry scrubs the encrypted payload and retry can receive a fresh one',async()=>{
  const f=await fixture();try{
    f.subscribe();const data=(await json(await f.call('/sites','POST',input))).data;
    f.db.sqlite.prepare('UPDATE provisioning_jobs SET secret_expires_at=? WHERE id=?').run(past(),data.job.id);
    await f.call('/sites');
    assert.equal(f.db.sqlite.prepare('SELECT secret_ciphertext FROM provisioning_jobs WHERE id=?').get(data.job.id)!.secret_ciphertext,null);
    assert.equal((await json(await f.call('/jobs/'+data.job.id))).data.requiresPassword,true);
    const renewed=(await json(await f.call('/jobs/'+data.job.id+'/retry','POST',{cmsAdminPassword:'replacement-password-123'}))).data;
    assert.equal(renewed.job.requiresPassword,false);
  }finally{f.db.close();}
});

test('domain parsing refuses URLs, IPs, reserved names, port tricks and whitespace',()=>{
  assert.equal(normalizeHostingDomain('CUSTOMER.Example.com'),'customer.example.com');
  for(const domain of ['https://example.com','127.0.0.1','localhost','foo.local','foo.test','example.com:443','a/b.com','user@example.com','x.com%2fsecret','a .com'])assert.throws(()=>normalizeHostingDomain(domain));
});

async function signedResponse(request:Request,status:number,value:unknown,secret:string,protocol='BENOS-BRIDGE-V1'){
  const body=JSON.stringify(value),timestamp=String(Math.floor(Date.now()/1000));
  const canonical=[protocol+'-RESPONSE',request.headers.get('X-Benos-Nonce'),String(status),timestamp,await sha256(body)].join('\n');
  return new Response(body,{status,headers:{'content-type':'application/json','X-Benos-Timestamp':timestamp,'X-Benos-Signature':createHmac('sha256',secret).update(canonical).digest('base64url')}});
}

test('a signed bridge install remains awaiting DNS until the independent signed HTTPS health check passes',async()=>{
  const f=await fixture(),original=globalThis.fetch;const bridgeSecret='bridge-secret-'.repeat(4),siteSecret='site-secret-'.repeat(5);let healthy=false,posts=0,remote:any=null;
  try{
    f.subscribe();const configId='cfg_hosting';
    f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES(?,'hosting','bridge','benos-bridge',1,'active',?,?,'passed',?,?)").run(configId,JSON.stringify({endpoint:'https://bridge.example.com/benos-bridge/v1',keyId:'primary'}),await encryptSecret(JSON.stringify({signingSecret:bridgeSecret}),f.env.ENCRYPTION_KEY,configId),f.user,now());
    globalThis.fetch=async(value,init)=>{
      const req=value instanceof Request?value:new Request(value,init),url=new URL(req.url);
      if(url.hostname==='customer.example.com'){
        if(!healthy)throw new Error('DNS not ready');
        if(url.pathname==='/benos-connect.php'){const lease=await req.json() as any;delete lease.operation;return signedResponse(req,200,{siteId:remote.siteId,...lease},siteSecret,'BENOS-CMS-V1');}
        return signedResponse(req,200,{siteId:remote.siteId,installed:true,database:'ready',cmsVersion:'1.9.21'},siteSecret,'BENOS-CMS-V1');
      }
      if(url.pathname.endsWith('/capabilities'))return signedResponse(req,200,{protocol:'benos-bridge-v1',capabilities:['isolated-cms-initialize'],cmsVersion:'1.9.21'},bridgeSecret);
      if(req.method==='GET')return signedResponse(req,remote?200:404,remote??{error:{code:'NOT_FOUND'}},bridgeSecret);
      posts++;const payload=await req.json() as any;
      remote={jobId:payload.jobId,siteId:payload.siteId,state:'awaiting_input',step:'verify_domain_https',cmsInstalled:true,cmsVersion:'1.9.21',connection:{origin:'https://customer.example.com',keyId:'site-key',healthPath:'/benos-health.php',signingSecret:siteSecret}};
      return signedResponse(req,202,remote,bridgeSecret);
    };
    const probe=await testHostingConfiguration(f.env,{id:configId,provider:'benos-bridge',public_config_json:JSON.stringify({endpoint:'https://bridge.example.com/benos-bridge/v1',keyId:'primary'}),secret_ciphertext:null},{signingSecret:bridgeSecret});assert.equal(probe.passed,true);
    let data=(await json(await f.call('/sites','POST',input))).data;
    assert.equal(data.site.state,'awaiting_dns');assert.equal(data.job.state,'awaiting_input');assert.equal(data.job.result.cmsInstalled,true);assert.equal(data.job.result.httpsVerified,false);
    assert.equal(f.db.sqlite.prepare('SELECT secret_ciphertext FROM provisioning_jobs WHERE id=?').get(data.job.id)!.secret_ciphertext,null);
    assert.ok(!JSON.stringify(data).includes(siteSecret));assert.equal(posts,1);
    healthy=true;data=(await json(await f.call('/jobs/'+data.job.id+'/retry','POST',{}))).data;
    assert.equal(data.site.state,'connected');assert.equal(data.job.state,'succeeded');assert.equal(data.job.result.httpsVerified,true);assert.equal(posts,1);
    await runProvisioningJob(f.env,f.user,data.job.id);assert.equal(posts,1);
  }finally{globalThis.fetch=original;f.db.close();}
});

test('hosting leases pause expired membership, preserve annual hosting, and independently freeze publishing',async()=>{
 const f=await fixture(),original=globalThis.fetch,siteSecret='lease-test-secret-'.repeat(4);let last:any;
 try{
   f.subscribe();const data=(await json(await f.call('/sites','POST',input))).data,siteId=data.site.id;
   f.db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,health_path,cms_version,created_at,updated_at) VALUES('conn_lease',?,'https://customer.example.com','primary',?,'/benos-health.php','1.9.21',?,?)").run(siteId,await encryptSecret(siteSecret,f.env.ENCRYPTION_KEY,siteId),now(),now());
   f.db.sqlite.prepare("UPDATE sites SET state='connected'").run();
   globalThis.fetch=async(input,init)=>{const request=new Request(input,init),payload=await request.json() as any;delete payload.operation;last=payload;return signedResponse(request,200,{siteId,...payload},siteSecret,'BENOS-CMS-V1');};
   assert.equal((await reconcileHostingEntitlements(f.env)).synced,1);assert.equal(last.hostingActive,true);assert.equal(last.publishAllowed,true);assert.ok(last.validUntil-last.issuedAt<=21600);
   f.db.sqlite.prepare('UPDATE subscriptions SET ends_at=?').run(new Date(Date.now()-1000).toISOString());await reconcileHostingEntitlements(f.env);assert.equal(last.hostingActive,false);assert.equal(f.db.sqlite.prepare('SELECT state FROM sites').get()!.state,'suspended');
   f.db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES('ann_lease',?,?,'annual',?,?,'active',?)").run(f.user,siteId,past(),future(),now());await reconcileHostingEntitlements(f.env);assert.equal(last.hostingActive,true);assert.equal(f.db.sqlite.prepare('SELECT state FROM sites').get()!.state,'connected');
   f.db.sqlite.prepare("INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,actor_id,created_at) VALUES('rst_lease',?,'publish','test freeze',?,?,?)").run(f.user,past(),f.user,now());await reconcileHostingEntitlements(f.env);assert.equal(last.hostingActive,true);assert.equal(last.publishAllowed,false);
   globalThis.fetch=async()=>new Response('{}');const failed=await reconcileHostingEntitlements(f.env);assert.equal(failed.failed,1);assert.equal(f.db.sqlite.prepare('SELECT state FROM hosting_lease_sync').get()!.state,'uncertain');
 }finally{globalThis.fetch=original;f.db.close();}
});

test('forged bridge success cannot create a connection',async()=>{
  const f=await fixture(),original=globalThis.fetch;try{
    f.subscribe();const configId='cfg_bad';
    f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES(?,'hosting','bridge','benos-bridge',1,'active',?,?,'passed',?,?)").run(configId,JSON.stringify({endpoint:'https://bridge.example.com/benos-bridge/v1',keyId:'primary'}),await encryptSecret(JSON.stringify({signingSecret:'x'.repeat(43)}),f.env.ENCRYPTION_KEY,configId),f.user,now());
    globalThis.fetch=async()=>new Response(JSON.stringify({cmsInstalled:true,state:'succeeded'}),{headers:{'X-Benos-Timestamp':String(Math.floor(Date.now()/1000)),'X-Benos-Signature':'forged'}});
    const data=(await json(await f.call('/sites','POST',input))).data;
    assert.equal(data.job.state,'uncertain');assert.equal(data.site.state,'pending');assert.equal(data.job.errorCode,'HOSTING_RESPONSE_INVALID');
    assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM site_connections').get()!.n,0);
  }finally{globalThis.fetch=original;f.db.close();}
});

test('TUS bootstrap proves the public endpoint before sending any CMS or database password',async()=>{
 const f=await fixture(),original=globalThis.fetch,release=new Uint8Array([80,75,3,4,0,0]),objectKey='private/cms-releases/test.zip',configId='cfg_tus';let probeCount=0,created=0;const offsets=new Map<string,{offset:number;size:number}>(),requests:string[]=[];
 try{
   f.subscribe();const data=(await json(await f.call('/sites','POST',input))).data;
   f.env.BUCKET={get:async(key:string)=>key===objectKey?{size:release.length,arrayBuffer:async()=>release.buffer}:null} as unknown as R2Bucket;
   const config={adapter:'hostinger-hpanel',deploymentMode:'hostinger-tus-bootstrap',hostingOrderId:100,accountUsername:'u12345678',cmsReleaseObjectKey:objectKey,cmsReleaseSha256:await sha256(release),cmsReleaseSize:release.length};
   f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES(?,'hosting','tus','benos-bridge',1,'active',?,?,'passed',?,?)").run(configId,JSON.stringify(config),await encryptSecret(JSON.stringify({hostingerApiToken:'test-token-long-enough'}),f.env.ENCRYPTION_KEY,configId),f.user,now());
   f.db.sqlite.prepare('INSERT INTO hosting_pool_dns_targets(pool_id,records_json,actor_id,reason,confirmed_at) VALUES(?,?,?,?,?)').run('pool_'+configId,JSON.stringify([{type:'A',value:'93.184.216.34'}]),f.user,'Verified fixture target',now());
   const dbPassword='database-password-must-not-leak-12345',dbName='u12345678_btest';
   f.db.sqlite.prepare('INSERT INTO hosting_provider_intents(job_id,config_version_id,site_id,domain,account_username,hosting_order_id,website_create_attempted,website_ready,database_name,database_user,database_secret_ciphertext,database_create_attempted,database_ready,root_directory,created_at,updated_at) VALUES(?,?,?,?,?,100,1,1,?,?,?,1,1,?,?,?)').run(data.job.id,configId,data.site.id,input.domain,'u12345678',dbName,dbName,await encryptSecret(dbPassword,f.env.ENCRYPTION_KEY,'hosting-database:'+data.job.id),'/home/u12345678/domains/'+input.domain+'/public_html',now(),now());
   globalThis.fetch=async(value,init)=>{const request=new Request(value,init),url=new URL(request.url),raw=request.method==='HEAD'?'':await request.text();requests.push(raw);
     if(url.origin==='https://developers.hostinger.com'){
       if(url.pathname.endsWith('/ssl/status'))return new Response(JSON.stringify({status:'active',is_https_redirect_enabled:true}));
       if(url.pathname.endsWith('/databases'))return new Response(JSON.stringify({data:[{name:dbName,user:dbName,domain:input.domain}],meta:{current_page:1,per_page:100,total:1}}));
       if(url.pathname.endsWith('/upload-urls'))return new Response(JSON.stringify({url:'https://uploads.hostinger.com/files',auth_key:'upload-key',rest_auth_key:'rest-key'}));
     }
     if(url.origin==='https://cloudflare-dns.com')return new Response(JSON.stringify({Status:0,Answer:url.searchParams.get('type')==='A'?[{type:1,data:'93.184.216.34'}]:[]}));
     if(url.hostname==='uploads.hostinger.com'){
       if(request.method==='HEAD'){const row=offsets.get(url.pathname);return new Response(null,{status:row?200:404,headers:row?{'Tus-Resumable':'1.0.0','Upload-Offset':String(row.offset),'Upload-Length':String(row.size)}:{}});}
       if(request.method==='POST'){created++;offsets.set(url.pathname,{offset:0,size:Number(request.headers.get('Upload-Length'))});return new Response(null,{status:201});}
       if(request.method==='PATCH'){const row=offsets.get(url.pathname)!;row.offset+=new TextEncoder().encode(raw).length;return new Response(null,{status:204,headers:{'Upload-Offset':String(row.offset)}});}
     }
     if(url.hostname==='customer.example.com'){probeCount++;assert.equal(JSON.parse(raw).operation,'probe');return new Response(JSON.stringify({bootstrapReady:true}));}
     throw new Error('Unexpected request');
   };
   await runProvisioningJob(f.env,f.user,data.job.id);const result=await json(await f.call('/jobs/'+data.job.id));assert.equal(result.data.state,'uncertain');assert.equal(result.data.errorCode,'HOSTING_RESPONSE_INVALID');assert.equal(probeCount,1);assert.equal(created,2);
   assert.ok(requests.every(raw=>!raw.includes(input.cmsAdminPassword)&&!raw.includes(dbPassword)));
   const intent=f.db.sqlite.prepare('SELECT * FROM hosting_bootstrap_intents').get()!;assert.match(String(intent.secret_ciphertext),/^v1\./);assert.ok(!JSON.stringify(result).includes('signingSecret'));
 }finally{globalThis.fetch=original;f.db.close();}
});
