import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { existsSync } from 'node:fs';
import { compileImageFramePlan, imageFramePlanSignature, plannedImageFrame, resolvePlannedImageFrame, imagePromptForPlannedFrame, validateImageFramePresentation, imageFramePlanInputSchema } from '../src/lib/image-frame-plan';
import { png } from './media-helper';

const input=(framePolicy:'adapt'|'fixed'='adapt')=>({sections:[{id:'equipment',layout:'Equipment beside a concise explanation of its actual purpose.',frames:[{id:'equipment-main',purpose:'Complete equipment and its immediate surroundings',slot:{width:1440,height:640,fit:'contain' as const,focalPoint:'center' as const,textSafeArea:'none' as const},subjectPolicy:'complete' as const,framePolicy}]}]});

test('the persisted frame plan is deterministic, globally identified and leaves the design input untouched',()=>{
 const raw=input(),copy=structuredClone(raw),plan=compileImageFramePlan(raw);
 assert.deepEqual(raw,copy);assert.equal(imageFramePlanSignature(plan),imageFramePlanSignature(compileImageFramePlan(raw)));
 assert.deepEqual(plan.sections[0].frameIds,['equipment-main']);assert.equal(plannedImageFrame(plan,'equipment-main').elementId,'bnf-image-equipment-main');
 assert.throws(()=>plannedImageFrame(plan,'unplanned'),/IMAGE_FRAME_NOT_PLANNED/);
 assert.ok(imageFramePlanSignature(plan).length<1600,'one frame stays a compact durable receipt');
});

test('complete subjects adapt their frame to actual supported pixels instead of letterboxing a wide banner',()=>{
 const frame=compileImageFramePlan(input()).frames[0],receipt=resolvePlannedImageFrame(frame,1536,1024);
 assert.equal(frame.generation.size,'1536x1024');assert.equal(frame.resolvedSlot.width,960);assert.equal(frame.resolvedSlot.height,640);
 assert.equal(frame.resolvedSlot.fit,'cover');assert.equal(receipt.display.cropFraction,0);assert.equal(receipt.display.letterboxFraction,0);
 assert.equal(receipt.layout.maxWidth,960);assert.equal(receipt.layout.width,'100%');assert.equal(receipt.layout.height,'auto');assert.equal(receipt.subjectVerified,false);
 assert.match(imagePromptForPlannedFrame('A real-sized recycling machine.',frame),/complete subject/);
 assert.match(imagePromptForPlannedFrame('A real-sized recycling machine.',frame),/no bars, padding, borders/i);
});

test('fixed wide frames use a bounded crop-safe composition but do not claim semantic subject verification',()=>{
 const frame=compileImageFramePlan(input('fixed')).frames[0],receipt=resolvePlannedImageFrame(frame,1536,1024);
 assert.equal(frame.resolvedSlot.width,1440);assert.equal(receipt.display.objectFit,'cover');assert.equal(receipt.display.cropFraction,.333);
 assert.equal(receipt.subjectVerified,false);assert.match(imagePromptForPlannedFrame('A machine in its factory.',frame),/16\.7% top/);
 assert.match(imagePromptForPlannedFrame('A machine in its factory.',frame),/8% inset/);
});

test('explicit user contain is preserved only through trusted options, with truthful letterbox geometry',()=>{
 const frame=compileImageFramePlan(input('fixed'),{preserveExplicitContainIds:['equipment-main']}).frames[0];
 const receipt=resolvePlannedImageFrame(frame,1536,1024);assert.equal(receipt.display.objectFit,'contain');assert.equal(receipt.display.letterboxFraction,.3333);
 const geometry={frameWidth:1440,frameHeight:640,imageWidth:1440,imageHeight:640,objectFit:'contain',naturalWidth:1536,naturalHeight:1024,viewportWidth:1440};
 const result=validateImageFramePresentation(frame,receipt.actual,geometry);assert.equal(result.valid,true);assert.deepEqual(result.warnings,['explicit_contain_letterboxing']);
 assert.ok(validateImageFramePresentation(frame,receipt.actual,{...geometry,objectFit:'cover'}).issues.includes('explicit_contain_not_preserved'));
 assert.equal(imageFramePlanInputSchema.safeParse({...input(),preserveExplicitContainIds:['equipment-main']}).success,false,'model args cannot assert user consent');
 const ignoredPreference:any=input('fixed');ignoredPreference.sections[0].frames[0].slot.fit='cover';
 assert.equal(compileImageFramePlan(ignoredPreference,{preserveExplicitContainIds:['equipment-main']}).frames[0].resolvedSlot.fit,'contain','an explicit user fit wins over a model choice');
});

test('validation rejects duplicate or injected frame IDs and geometry outside the established image contract',()=>{
 const duplicate=input();duplicate.sections[0].frames.push(structuredClone(duplicate.sections[0].frames[0]));assert.throws(()=>compileImageFramePlan(duplicate));
 const repeatedSection=input();repeatedSection.sections.push(structuredClone(repeatedSection.sections[0]));assert.throws(()=>compileImageFramePlan(repeatedSection));
 for(const id of ['../../other','hero" onclick="bad','a#b','', 'x'.repeat(61)]){const value=input();value.sections[0].frames[0].id=id;assert.throws(()=>compileImageFramePlan(value));}
 for(const width of [0,1,4097,NaN]){const value=input();value.sections[0].frames[0].slot.width=width;assert.throws(()=>compileImageFramePlan(value));}
 const frame=compileImageFramePlan(input()).frames[0];assert.throws(()=>resolvePlannedImageFrame(frame,0,100));
 const receipt=resolvePlannedImageFrame(frame,1601,1000);assert.equal(receipt.generationMatches,false);assert.ok(receipt.slot.width<=1440&&receipt.slot.height<=640);assert.ok(Math.abs(receipt.slot.width/receipt.slot.height-1.601)<.0001);
});

test('observed DOM checks report gray bars, crop changes, wrong media and overflow rather than only comparing metadata',()=>{
 const frame=compileImageFramePlan(input()).frames[0],actual={width:1536,height:1024};
 const observed={frameWidth:1440,frameHeight:640,imageWidth:1440,imageHeight:640,objectFit:'contain',naturalWidth:1536,naturalHeight:1024,viewportWidth:1440};
 assert.deepEqual(validateImageFramePresentation(frame,actual,observed).issues,['image_letterboxing','frame_ratio_changed']);
 const clipped=validateImageFramePresentation(frame,actual,{...observed,objectFit:'cover'});assert.ok(clipped.issues.includes('complete_subject_frame_cropped'));
 assert.ok(validateImageFramePresentation(frame,actual,{...observed,objectFit:'cover',objectPosition:'0% 0%'}).issues.includes('crop_position_changed'));
 const wrong=validateImageFramePresentation(frame,actual,{...observed,naturalWidth:1024,viewportWidth:320});assert.ok(wrong.issues.includes('image_source_dimensions_mismatch'));assert.ok(wrong.issues.includes('image_overflows_viewport'));
 assert.equal(validateImageFramePresentation(frame,actual,{...observed,imageHeight:NaN}).valid,false);
});

const require=createRequire(import.meta.url);let chromium:any=null;
try{chromium=require(process.env.BENOS_TEST_PLAYWRIGHT||'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright').chromium;}catch{}
const executablePath=process.env.BENOS_TEST_BROWSER||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
test('responsive browser image frames use the stored plan without bars at desktop, tablet and narrow phone widths',{skip:!chromium||!existsSync(executablePath)?'Requires local browser tooling':false,timeout:60000},async()=>{
 const browser=await chromium.launch({executablePath,headless:true});
 try{const page=await browser.newPage();await page.route('**/*',(route:any)=>route.abort());
  for(const [width,height] of [[1440,640],[400,600],[500,500],[1440,400]] as const){
   const value=input();value.sections[0].frames[0].slot.width=width;value.sections[0].frames[0].slot.height=height;
   const frame=compileImageFramePlan(value).frames[0],receipt=resolvePlannedImageFrame(frame,frame.generation.width,frame.generation.height),src='data:image/png;base64,'+Buffer.from(png(receipt.actual.width,receipt.actual.height)).toString('base64');
   for(const viewportWidth of[1440,768,390,320]){
    await page.setViewportSize({width:viewportWidth,height:1000});
    await page.setContent(`<meta http-equiv="Content-Security-Policy" content="default-src 'none';script-src 'none';style-src 'unsafe-inline';img-src data:"><style>*{box-sizing:border-box}body{margin:16px}.frame{width:100%;max-width:${receipt.layout.maxWidth}px;aspect-ratio:${receipt.display.aspectRatio};background:#999}.frame img{display:block;width:100%;height:100%;object-fit:${receipt.display.objectFit};object-position:${receipt.display.objectPosition}}</style><div id="${receipt.elementId}" class="frame"><img src="${src}" width="${receipt.actual.width}" height="${receipt.actual.height}" alt="Geometry fixture"></div>`);
    await page.locator('img').evaluate((img:any)=>img.decode());
    const observed=await page.evaluate(()=>{const {document,innerWidth,getComputedStyle}=globalThis as any;const img=document.querySelector('img'),frame=img.parentElement.getBoundingClientRect(),image=img.getBoundingClientRect(),css=getComputedStyle(img);return{frameWidth:frame.width,frameHeight:frame.height,imageWidth:image.width,imageHeight:image.height,objectFit:css.objectFit,objectPosition:css.objectPosition,naturalWidth:img.naturalWidth,naturalHeight:img.naturalHeight,viewportWidth:innerWidth};});
    const result=validateImageFramePresentation(frame,receipt.actual,observed);assert.equal(result.valid,true,JSON.stringify({width,height,viewportWidth,result,observed}));assert.equal(result.letterboxFraction,0);assert.ok(result.cropFraction!<.002);
   }
  }
 }finally{await browser.close();}
});
