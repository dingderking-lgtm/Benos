import test from 'node:test';
import assert from 'node:assert/strict';
import { verifiedImagePricing,createImageRequest,meteredImageContract,imageResponseUsage,imageReservationCost } from '../src/lib/image-billing';

const pricing={baseUrl:'https://api.openai.com/v1',model:'gpt-image-2.6-flare',protocol:'images',providerPoolId:'image-pool',n:1,size:'1536x1024',quality:'medium',complexity:'low',outputFormat:'png',textInputMicrosPerMillion:5_000_000,cachedTextInputMicrosPerMillion:1_250_000,imageInputMicrosPerMillion:8_000_000,cachedImageInputMicrosPerMillion:2_000_000,imageOutputMicrosPerMillion:30_000_000,pricingConfirmedAt:'2026-11-14T00:00:00.000Z',billingContract:{kind:'metered-reserve-v1'}};
test('medium is explicitly sent with low complexity and retains metered reservation and usage billing',()=>{
 const parsed=verifiedImagePricing(pricing),contract=meteredImageContract(parsed),request=createImageRequest(parsed,'A single landscape image.');
 assert.equal(request.quality,'medium');assert.equal(request.complexity,'low');assert.equal(request.size,'1536x1024');
 assert.equal(imageReservationCost(parsed,contract),1_000_000);
 const response={model:pricing.model,size:pricing.size,quality:'medium',usage:{input_tokens:200,input_tokens_details:{text_tokens:200,image_tokens:0},output_tokens:3000,total_tokens:3200}};
 assert.equal(imageResponseUsage(parsed,response,contract).actualMicros,91_000);
 assert.throws(()=>imageResponseUsage(parsed,{...response,quality:'low'},contract),{code:'IMAGE_PRICING_MISMATCH'});
});
test('medium support does not silently allow high quality, extra complexity or changed rates',()=>{
 for(const change of [{quality:'high'},{quality:'max'},{complexity:'medium'},{imageOutputMicrosPerMillion:1}])assert.throws(()=>verifiedImagePricing({...pricing,...change}));
});
