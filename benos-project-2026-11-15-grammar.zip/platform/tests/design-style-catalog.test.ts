import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { URL } from 'node:url';
import { DESIGN_STYLE_CATALOG, DESIGN_STYLES, findDesignStyle, getDesignStyle, suggestDesignStyles } from '../src/contracts/design-style-catalog';
import { createDesignFoundation, foundationAuthoringContext } from '../src/contracts/design-foundation';

test('catalog keeps all ten persisted direction IDs and six structurally different additions', () => {
  assert.deepEqual(DESIGN_STYLES.slice(0, 10).map(style => style.id), ['modern', 'industrial', 'trust', 'luxury', 'warm', 'fresh', 'tech', 'dark', 'editorial', 'bold']);
  assert.equal(DESIGN_STYLES.length, 16);
  assert.equal(new Set(DESIGN_STYLES.map(style => style.id)).size, 16);
  assert.equal(new Set(DESIGN_STYLES.map(style => style.layout.hero)).size, 16);
  assert.equal(new Set(DESIGN_STYLES.slice(10).map(style => style.preview.layout)).size, 6);
  for (const style of DESIGN_STYLES) {
    assert.ok(style.brief.length <= 200);
    assert.equal(style.scope, 'customer-website');
    assert.ok(style.bestFor.length && style.layout.sections.length && style.imagery.length && style.antiPatterns.length);
  }
});

test('style lookup accepts saved IDs and old name-prefixed briefs without guessing custom requests', () => {
  assert.equal(getDesignStyle('industrial')?.name, '工业专业');
  assert.equal(findDesignStyle('  \u200B工业专业；旧版简短描述 ')?.id, 'industrial');
  assert.equal(findDesignStyle('杂志编辑')?.id, 'editorial');
  assert.equal(findDesignStyle('清晰服务：沿用客户色彩')?.id, 'civic');
  assert.equal(findDesignStyle('请不要采用工业专业；我要自己的水彩风格'), undefined);
  assert.equal(findDesignStyle('由 AI 自由创意'), undefined);
  assert.equal(findDesignStyle(''), undefined);
  for (const style of DESIGN_STYLES) assert.equal(findDesignStyle(style.brief)?.id, style.id);
});

test('body and supporting text tokens have readable contrast on both supplied surfaces', () => {
  const luminance = (hex: string) => {
    const rgb = hex.slice(1).match(/../g)!.map(value => parseInt(value, 16) / 255).map(value => value <= .04045 ? value / 12.92 : ((value + .055) / 1.055) ** 2.4);
    return rgb[0] * .2126 + rgb[1] * .7152 + rgb[2] * .0722;
  };
  const contrast = (a: string, b: string) => (Math.max(luminance(a), luminance(b)) + .05) / (Math.min(luminance(a), luminance(b)) + .05);
  for (const style of DESIGN_STYLES) {
    for (const background of [style.tokens.background, style.tokens.surface]) {
      assert.ok(contrast(style.tokens.ink, background) >= 4.5, `${style.id}: ink contrast`);
      assert.ok(contrast(style.tokens.muted, background) >= 4.5, `${style.id}: muted contrast`);
      // The foundation compiler may select light or dark text on the accent.
      assert.ok(Math.max(contrast('#ffffff', style.tokens.accent), contrast('#111111', style.tokens.accent)) >= 4.5, `${style.id}: button contrast`);
    }
    assert.ok(style.tokens.container >= 960 && style.tokens.container <= 1440);
    assert.ok(style.tokens.radius >= 0 && style.tokens.radius <= 32);
    assert.match(style.tokens.bodyFont, /system-ui/);
    assert.ok(style.typography.scale.every((size, index, array) => size >= 14 && (index === 0 || size < array[index - 1])));
  }
});

test('layout, density and principles resolve to independently recorded official sources', () => {
  const sources = readFileSync(new URL('../src/contracts/design-style-sources.txt', import.meta.url), 'utf8');
  const ids = new Set([...sources.matchAll(/^\[([a-z-]+)\]/gm)].map(match => match[1]));
  assert.equal(ids.size, 16);
  assert.match(sources, /Accessed: 2026-11-13/);
  for (const style of DESIGN_STYLES) {
    const refs = [...style.sourceIds, ...style.layout.sourceIds, ...style.typography.sourceIds, ...style.density.sourceIds, ...style.principles.flatMap(principle => principle.sourceIds)];
    assert.ok(refs.length > 0);
    for (const id of refs) assert.ok(ids.has(id), `${style.id}: unresolved ${id}`);
  }
});

test('catalog remains a serializable creative foundation rather than an obligatory page template', () => {
  assert.deepEqual(JSON.parse(JSON.stringify(DESIGN_STYLE_CATALOG)), DESIGN_STYLE_CATALOG);
  assert.equal(DESIGN_STYLE_CATALOG.creativeContract.layoutSections, 'suggestions-only');
  assert.match(DESIGN_STYLE_CATALOG.creativeContract.rule, /局部 CSS/);
  assert.match(DESIGN_STYLE_CATALOG.creativeContract.contentRule, /删除、合并或缩短/);
  assert.match(DESIGN_STYLE_CATALOG.creativeContract.imageRule, /比例与构图相近/);
});

test('automatic suggestions follow explicit site tasks in Chinese and English with room for variety', () => {
  const cases: [string, string][] = [
    ['制作一个塑料再生机械制造企业官网', 'industrial'], ['Build an industrial machinery manufacturer website', 'industrial'],
    ['为客户建立使用手册和知识库网站', 'documentation'], ['Build a developer documentation portal', 'documentation'],
    ['制作2026年度行业报告网站', 'data'], ['Create a research report and data story website', 'data'],
    ['设计摄影作品集', 'portfolio'], ['Create an architecture portfolio website', 'portfolio'],
    ['建立在线商城与商品目录', 'commerce'], ['Create an ecommerce storefront', 'commerce'],
    ['设计一家咖啡餐厅官网', 'warm'], ['Design a boutique hotel website', 'warm'],
  ];
  for (const [brief, expected] of cases) {
    const choices = suggestDesignStyles(brief);
    assert.equal(choices[0].id, expected, brief);
    assert.ok(choices.length >= 3 && choices.length <= 6, brief);
    assert.equal(new Set(choices.map(style => style.id)).size, choices.length);
    assert.ok(choices.every(style => DESIGN_STYLES.includes(style)));
  }
});

test('business suggestions retain task clarity while crossing industry aesthetic stereotypes', () => {
  for (const request of ['做机械官网', 'Build an industrial machinery manufacturer website', '咖啡机厂家官网']) {
    const choices = suggestDesignStyles(request), ids = choices.map(style => style.id);
    for (const id of ['industrial', 'editorial', 'bold', 'expressive', 'warm']) assert.ok(ids.includes(id), `${request}: ${id}`);
    assert.ok(new Set(choices.map(style => style.tokens.accent)).size >= 4, request);
    assert.ok(!ids.some(id => ['documentation', 'data', 'commerce'].includes(id)), request);
  }
  assert.ok(suggestDesignStyles('咖啡店网站').some(style => style.id === 'bold'));
  assert.ok(suggestDesignStyles('软件产品官网').some(style => style.id === 'editorial'));
  assert.ok(suggestDesignStyles('A healthcare company website').some(style => style.id === 'editorial'));
  // Purpose-specific content stays supported; cross-industry style choices must
  // not turn a documentation task into a decorative company landing page.
  assert.equal(suggestDesignStyles('机械厂家知识库网站')[0].id, 'documentation');
  assert.equal(suggestDesignStyles('咖啡店行业年度报告网站')[0].id, 'data');
  assert.equal(suggestDesignStyles('咖啡品牌产品目录网站')[0].id, 'commerce');
});

test('generic company words and secondary features do not force a specialized site category', () => {
  for (const brief of ['数据科技公司官网', 'Data technology company website', '展示我们处理数据的技术服务']) {
    const choices = suggestDesignStyles(brief);
    assert.ok(!choices.some(style => ['data', 'documentation', 'commerce', 'portfolio'].includes(style.id)), brief);
  }
  assert.deepEqual(suggestDesignStyles('为新品牌制作官网').map(style => style.id), ['modern', 'trust', 'editorial', 'bold']);
  assert.deepEqual(suggestDesignStyles('').map(style => style.id), ['modern', 'trust', 'editorial', 'bold']);
  assert.equal(suggestDesignStyles('机械企业官网，包括帮助中心和行业报告')[0].id, 'industrial');
  assert.equal(suggestDesignStyles('Software product website with a help center')[0].id, 'tech');
  assert.ok(!suggestDesignStyles('不要商城，做一个公司官网').some(style => style.id === 'commerce'));
});

test('whole-page direction guidance survives the selected foundation projection without copying the catalog', () => {
  for (const id of ['tech', 'dark', 'expressive']) {
    const style = getDesignStyle(id)!;
    const context = foundationAuthoringContext(createDesignFoundation(style));
    const intent = context.designIntent || '';
    for (const rule of [style.layout.hero, style.layout.mobile, style.density.rule, ...style.imagery, ...style.antiPatterns]) {
      assert.ok(intent.includes(rule), `${id}: selected rule was dropped or truncated: ${rule}`);
    }
    assert.ok(intent.length <= 1800, `${id}: selected guidance stays bounded`);
    assert.ok(!JSON.stringify(context).includes('sourceIds'), 'research records are not sent on every generation');
    assert.ok(!JSON.stringify(context).includes(getDesignStyle('industrial')!.brief), 'unselected directions are not included');
  }
});
