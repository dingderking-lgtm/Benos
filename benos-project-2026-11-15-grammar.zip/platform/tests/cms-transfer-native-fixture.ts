import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { TestD1,testEnv } from './d1-helper';
import { encryptSecret } from '../src/lib/crypto';
import { prepareDesignManifestStorage } from '../src/lib/design-storage';
import { ensureCmsBundleTransfer,advanceCmsBundleTransfer } from '../src/modules/cms-transfers';
import type { CmsBundleCredentials } from '../src/lib/cms-bundle';

const hash=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
/** Actual bytes and conditional/range reads, with no Cloudflare network claim. */
class PrivateObjectFixture {
 objects=new Map<string,Uint8Array>();ranges:number[]=[];
 async put(key:string,bytes:Uint8Array,options?:any){if(options?.onlyIf&&this.objects.has(key))return null;this.objects.set(key,bytes.slice());return {key};}
 async head(key:string){const value=this.objects.get(key);return value?{key,size:value.length,etag:hash(value)}:null;}
 async get(key:string,options?:any){const value=this.objects.get(key);if(!value)return null;const etag=hash(value);if(options?.onlyIf?.etagMatches&&options.onlyIf.etagMatches!==etag)return {size:value.length,etag};const bytes=options?.range?value.slice(options.range.offset,options.range.offset+options.range.length):value;if(options?.range)this.ranges.push(bytes.length);return {size:value.length,etag,body:true,arrayBuffer:async()=>Uint8Array.from(bytes).buffer};}
 async delete(key:string){this.objects.delete(key);}
}

/** Runs production task/state/chunk readers. Only the transport sender is
 * injected to deliver signed requests to the isolated local PHP server. */
export async function pushWithNativeTransferEngine(options:{credentials:CmsBundleCredentials;projectId:string;versionId:string;manifest:any;files:Array<{file:string;bytes:Buffer}>;send:(credentials:CmsBundleCredentials,input:unknown,key:string)=>Promise<{status:number;data:any}>}){
 const db=new TestD1(),env=testEnv(db),storage=new PrivateObjectFixture();env.BUCKET=storage as unknown as R2Bucket;
 const user='usr-native-transfer',now=new Date().toISOString(),future=new Date(Date.now()+86400000).toISOString(),{projectId,versionId,credentials,manifest,files}=options;
 try{
  db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,'native@example.test','Native','test','user','active',?,?)").run(user,now,now);
  db.sqlite.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES(?,?,'Native transfer',?,?)").run(projectId,user,now,now);
  const stored=await prepareDesignManifestStorage(env,user,projectId,manifest);assert.ok(stored.objectId,'Large manifest must live in private object storage');
  db.sqlite.prepare("INSERT INTO design_versions(id,project_id,version,source,manifest_json,manifest_object_id,content_hash,created_by,created_at) VALUES(?,?,1,'manual',?,?,?,?,?)").run(versionId,projectId,stored.manifestJson,stored.objectId,stored.contentHash,user,now);
  db.sqlite.prepare("INSERT INTO sites(id,user_id,project_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,?,?,'Native transfer','bundle.example.com','cms@example.test','connected',?,?)").run(credentials.siteId,user,projectId,now,now);
  db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES('native-entitlement',?,?,'annual',?,?,'active',?)").run(user,credentials.siteId,now,future,now);
  db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,cms_version,last_verified_at,created_at,updated_at) VALUES('native-connection',?,'https://bundle.example.com',?,?,'1.9.21',?,?,?)").run(credentials.siteId,credentials.keyId,await encryptSecret(credentials.secret,env.ENCRYPTION_KEY,credentials.siteId),now,now,now);
  for(const [index,file] of files.entries()){
   const ext=file.file.split('.').at(-1)!,pdf=ext==='pdf',objectKey='private/native-fixture/'+index+'.'+ext,table=pdf?'project_media_extended':'project_media';await storage.put(objectKey,file.bytes);
   db.sqlite.prepare(`INSERT INTO ${table}(id,user_id,project_id,request_key,request_hash,object_key,filename,mime_type,extension,byte_size,width,height,sha256,source,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'upload','ready',?,?)`).run('media-native-'+index,user,projectId,'native-media-'+index,hash(file.bytes),objectKey,file.file,pdf?'application/pdf':'image/png',ext,file.bytes.length,pdf?0:8,pdf?0:8,hash(file.bytes),now,now);
  }
  const task=await ensureCmsBundleTransfer(env,user,credentials.siteId,versionId,'native-engine-transfer','publish');assert.equal((await ensureCmsBundleTransfer(env,user,credentials.siteId,versionId,'native-engine-transfer','publish')).id,task.id);
  let lost=false,steps=0,chunksThisStep=0;const offsets:string[]=[],send=async(c:CmsBundleCredentials,input:any,key:string)=>{
   assert.equal(c.url,'https://bundle.example.com/benos-bundle.php');assert.equal(c.secret,credentials.secret);
   const response=await options.send(c,input,key);if(input instanceof Uint8Array){chunksThisStep++;const length=new DataView(input.buffer,input.byteOffset).getUint32(4,false),header=JSON.parse(new TextDecoder().decode(input.subarray(8,8+length)));offsets.push(header.file+':'+header.offset);if(!lost){lost=true;throw new Error('Test: drop acknowledgement after PHP persisted first chunk');}}return response;
  };
  let view=task;
  do{chunksThisStep=0;view=await advanceCmsBundleTransfer(env,user,task.id,{send});steps++;assert.ok(chunksThisStep<=2);if(steps===1){assert.equal(view.errorCode,'CMS_BUNDLE_UNCERTAIN');assert.equal(view.bytesSent,0);}else assert.equal(view.errorCode,null,JSON.stringify(view));assert.ok(steps<90);}while(!view.sealed);
  assert.equal(new Set(offsets).size,offsets.length,'Lost acknowledgement must reconcile instead of retransmitting an acknowledged block');assert.ok(lost&&steps>30);assert.ok(storage.ranges.every(size=>size<=1048576));assert.equal(db.sqlite.prepare('SELECT published_version_id FROM projects').get()!.published_version_id,null);
  assert.ok(Number(db.sqlite.prepare('SELECT length(manifest_json) bytes FROM design_versions').get()!.bytes)<65536);assert.ok(Number(db.sqlite.prepare('SELECT length(metadata_json)+length(sources_json) bytes FROM cms_bundle_transfers').get()!.bytes)<65536);
  const progress=JSON.parse(String(db.sqlite.prepare('SELECT progress_json FROM cms_bundle_transfers').get()!.progress_json));return {bundleId:task.id,rawBytes:stored.byteSize,zipBytes:progress.zipBytes,steps,chunks:offsets.length,lostAcknowledgementRecovered:lost,maxRangeBytes:Math.max(...storage.ranges)};
 }finally{db.close();}
}
