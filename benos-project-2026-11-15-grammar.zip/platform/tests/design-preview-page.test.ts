import test from 'node:test';
import assert from 'node:assert/strict';
import { liveManifest } from '../src/lib/workflow-progress';
import { livePreviewBody } from '../src/modules/design-preview';

const manifest={site:{name:'站点',home:'home',header_template_id:1,footer_template_id:5,pages:[{key:'home',slug:'',template_id:2},{key:'products',slug:'equipment',template_id:3},{key:'contact',slug:'contact',template_id:4}]},
 templates:[{id:1,type:'header',document:{html:'<header>导航</header>',css:''}},{id:2,type:'page',document:{html:'<section>首页</section>',css:''}},{id:3,type:'page',document:{html:'<section>产品</section>',css:''}},{id:4,type:'page',document:{html:'<section>联系</section>',css:''}},{id:5,type:'footer',document:{html:'<footer>页脚</footer>',css:''}}],assets:[]};
const draft=(id:number)=>liveManifest(manifest,[{path:`templates/${id}.html`,content:`<${id===1?'header':id===5?'footer':'section'}>正在修改</${id===1?'header':id===5?'footer':'section'}>`}])!;

test('editing shared header or footer stays on the requested page instead of the last existing page',()=>{
 for(const id of [1,5]){
  const live=draft(id);
  assert.equal(livePreviewBody(live,'home',false)?.id,2);
  assert.equal(livePreviewBody(live,'products',false)?.id,3);
  assert.equal(livePreviewBody(live,'equipment',false)?.id,3,'existing preview URLs may use a slug');
  assert.equal(livePreviewBody(live,'contact',false)?.id,4);
 }
});

test('shared chrome without an explicit page defaults to home, even if it is not the last template',()=>{
 for(const id of [1,5]){
  assert.equal(livePreviewBody(draft(id),undefined,false)?.id,2);
  assert.equal(livePreviewBody(draft(id),'missing',false)?.id,2);
  assert.equal(livePreviewBody(draft(id),'',false)?.id,2);
 }
});

test('an actual page edit is the live body even when the client was reading another page',()=>{
 const live=draft(3);
 assert.equal(livePreviewBody(live,'home',false)?.id,3);
 assert.equal(livePreviewBody(live,'contact',false)?.id,3);
});

test('a new whole manifest continues showing its last written page while footer is streaming',()=>{
 const live=liveManifest(null,[{path:'manifest.json',content:JSON.stringify(manifest)}])!;
 assert.equal(live.latest,5);assert.equal(livePreviewBody(live,'home',true)?.id,4);
 const partial=structuredClone(manifest);partial.templates.splice(3,1);
 const earlier=liveManifest(null,[{path:'manifest.json',content:JSON.stringify(partial)}])!;
 assert.equal(livePreviewBody(earlier,undefined,true)?.id,3);
});

test('empty or unrelated template bodies do not become the preview page',()=>{
 const live=draft(1);live.templates.find(t=>t.id===2)!.document.html='';
 live.templates.push({id:99,name:'共享说明',type:'section',document:{html:'<aside>共享说明</aside>',css:''}});
 assert.equal(livePreviewBody(live,undefined,false)?.id,3);
 assert.equal(livePreviewBody(live,undefined,true)?.id,4);
});

test('persisted image layouts show home or the requested page, never a system-appended contact page',()=>{
 const scaffold=structuredClone(manifest),contact=scaffold.templates.splice(3,1)[0];scaffold.templates.push(contact);
 const live=liveManifest(null,[{path:'manifest.json',content:JSON.stringify(scaffold)}])!;
 assert.equal(live.latest,4);
 assert.equal(livePreviewBody(live,undefined,true)?.id,4,'incomplete streams still follow the body being written');
 assert.equal(livePreviewBody(live,undefined,true,true)?.id,2,'the committed framework returns to home during image generation');
 assert.equal(livePreviewBody(live,'products',true,true)?.id,3,'an explicitly selected page remains selected');
 assert.equal(livePreviewBody(live,'missing',true,true)?.id,2);
});
