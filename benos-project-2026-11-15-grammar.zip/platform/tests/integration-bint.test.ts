import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { notificationCandidates,processServiceNotifications } from '../src/modules/notifications';
import { hostingBillingSummary } from '../src/modules/hosting-billing';
import { releaseParkedSite } from '../src/modules/hosting';

/** Cross-package integration checks for the combined P2.B-P6.B workspace. */
const DAY=86400000;
const iso=(value:number)=>new Date(value).toISOString();

function fixture(){
 const db=new TestD1(),env=testEnv(db),now=Date.now();
 db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,created_at,updated_at) VALUES('u','u@example.test','u','fixture',?,?)").run(iso(now-60*DAY),iso(now));
 // Go membership with one hosting slot, ending in 5 days (inside the 7-day notice window).
 db.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,auto_renew,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at) VALUES('member','u','go','paid',?,?,0,1,16250000,1,'member',?)").run(iso(now-25*DAY),iso(now+5*DAY),iso(now));
 const site=(id:string,state:string,createdMs:number)=>db.sqlite.prepare('INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(id,'u',id,id+'.example.test','cms@example.test',state,iso(createdMs),iso(createdMs));
 // P4.B pay-first site, created first and never paid: its job is parked at awaiting_payment.
 site('parked','pending',now-30*DAY);
 db.sqlite.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,state,step,error_code,idempotency_key,payload_hash,created_at,updated_at) VALUES('job_parked','parked','u','create','awaiting_input','awaiting_payment','HOSTING_PAYMENT_REQUIRED','annual_parked_key_0001','hash',?,?)").run(iso(now-30*DAY),iso(now-30*DAY));
 // A later site that really uses the membership slot.
 site('member_site','connected',now-20*DAY);
 return {db,env,now};
}

test('an unpaid pay-first site never takes the membership slot in expiry notices (P5.B allocation vs P4.B parked sites)',async()=>{
 const f=fixture();try{
  const notices=await notificationCandidates(f.env,'u',f.now);
  assert.equal(notices.some(n=>n.siteId==='parked'),false,'a parked unpaid site gets no hosting notice');
  const memberSite=notices.find(n=>n.siteId==='member_site');
  assert.ok(memberSite,'the site that holds the slot is warned');assert.equal(memberSite.endsAt,iso(f.now+5*DAY));assert.equal(memberSite.stage,'before_7_days');
  // The notice allocation agrees with the billing summary coverage.
  const summary=await hostingBillingSummary(f.env.DB,'u',f.now);
  assert.equal(summary.find(s=>s.id==='parked')!.coverage.current,null);
  assert.equal(summary.find(s=>s.id==='member_site')!.coverage.current?.endsAt,iso(f.now+5*DAY));
 }finally{f.db.close();}
});

test('a notification scan never blocks releasing an unpaid pay-first site (no stuck domain claim)',async()=>{
 const f=fixture();try{
  await processServiceNotifications(f.env,{nowMs:f.now,fetch:async()=>{throw new Error('no email expected');}});
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM service_notifications WHERE site_id='parked'").get()!.n,0);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM service_notifications WHERE site_id='member_site'").get()!.n,1);
  const released=await releaseParkedSite(f.env,'u','job_parked','customer');
  assert.equal(released.siteId,'parked');
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM sites WHERE id='parked'").get()!.n,0);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM provisioning_jobs WHERE id='job_parked'").get()!.n,0);
 }finally{f.db.close();}
});
