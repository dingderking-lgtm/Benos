import assert from 'node:assert/strict';
import { beforeEach,afterEach,test } from 'node:test';
import { TestD1,testEnv } from './d1-helper';
import type { Env } from '../src/env';
import { encryptSecret,hashPassword,verifyPassword } from '../src/lib/crypto';
import { AppError } from '../src/lib/errors';
import { requestPasswordReset,requestEmailVerification,resetPassword,verifyEmail,changePassword,listSessions,revokeSessions } from '../src/modules/account-security';
import { processEmailOutbox,probeEmailConfiguration,type EmailRuntime } from '../src/modules/email';

const NOW=Date.parse('2026-11-07T01:00:00.000Z'),ISO=new Date(NOW).toISOString(),OLD='old-password-long-enough',NEW='new-password-long-enough';
let database:TestD1,env:Env,runtime:EmailRuntime,sends:{payload:Record<string,any>;key:string|null}[],failSend:boolean;
beforeEach(async()=>{
 database=new TestD1();env=testEnv(database);sends=[];failSend=false;
 const hash=await hashPassword(OLD);
 database.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,created_at,updated_at) VALUES('u','user@example.test','User',?,?,?),('other','other@example.test','Other',?,?,?)").run(hash,ISO,ISO,hash,ISO,ISO);
 database.sqlite.prepare("INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES('current','session-hash-one','u','csrf-current',?,?,'ip'),('other-session','session-hash-two','u','csrf-other',?,?,'ip'),('foreign','session-hash-three','other','csrf-foreign',?,?,'ip')")
  .run(ISO,new Date(NOW+86400_000).toISOString(),ISO,new Date(NOW+86400_000).toISOString(),ISO,new Date(NOW+86400_000).toISOString());
 const secret=await encryptSecret(JSON.stringify({apiKey:'re_this_is_only_a_local_test_key'}),env.ENCRYPTION_KEY,'email');
 database.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('email','email','Resend','resend',1,'active',?,?,'passed','u',?)")
  .run(JSON.stringify({fromEmail:'account@example.test',fromName:'Benos'}),secret,ISO);
 runtime={nowMs:NOW,fetch:async(input,init)=>{
  const url=new URL(String(input));assert.equal(url.origin,'https://api.resend.com');
  if(url.pathname==='/domains')return Response.json({data:[{id:'domain',name:'example.test',status:'verified'}],has_more:false});
  assert.equal(url.pathname,'/emails');assert.equal(init?.method,'POST');
  const payload=JSON.parse(String(init?.body)),key=new Headers(init?.headers).get('idempotency-key');sends.push({payload,key});
  if(failSend)throw new Error('Simulated lost provider response');return Response.json({id:'email-provider-id'});
 }};
});
afterEach(()=>database.close());
const code=(value:string)=>(error:unknown)=>error instanceof AppError&&error.code===value;
function mailedToken(index=0):string {const match=String(sends[index]?.payload.text).match(/#token=([A-Za-z0-9_-]{43})/);assert(match);return match[1];}
async function resetLink(){await requestPasswordReset(env,'USER@example.test',runtime);await processEmailOutbox(env,runtime);return mailedToken();}

test('unconfigured email fails explicitly and identically for known and unknown addresses',async()=>{
 database.sqlite.exec("UPDATE integration_configs SET status='disabled'");
 await assert.rejects(requestPasswordReset(env,'user@example.test',runtime),code('EMAIL_NOT_CONFIGURED'));
 await assert.rejects(requestPasswordReset(env,'unknown@example.test',runtime),code('EMAIL_NOT_CONFIGURED'));
 assert.equal(sends.length,0);assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM account_tokens').get()!.count,0);
});

test('email configuration probe is read-only and validates the verified sender domain',async()=>{
 await probeEmailConfiguration({fromEmail:'account@example.test',fromName:'Benos'},{apiKey:'re_this_is_only_a_local_test_key'},runtime);
 assert.equal(sends.length,0);
 await assert.rejects(probeEmailConfiguration({fromEmail:'account@unverified.test'},{apiKey:'re_this_is_only_a_local_test_key'},runtime),code('EMAIL_DOMAIN_UNVERIFIED'));
});

test('forgot password queues work with identical responses and never awaits or claims delivery',async()=>{
 const known=await requestPasswordReset(env,'user@example.test',runtime),unknown=await requestPasswordReset(env,'unknown@example.test',runtime);
 assert.deepEqual(known,unknown);assert.equal(sends.length,0);
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM email_outbox').get()!.count,1);
 assert.equal(database.sqlite.prepare('SELECT state FROM email_outbox').get()!.state,'queued');
});

test('account tokens are hashed and email payloads encrypted, then erased after provider acceptance',async()=>{
 await requestPasswordReset(env,'user@example.test',runtime);
 const before=database.sqlite.prepare('SELECT * FROM email_outbox').get()!;assert(String(before.payload_ciphertext).startsWith('v1.'));assert(!String(before.payload_ciphertext).includes('user@example.test'));
 await processEmailOutbox(env,runtime);const token=mailedToken();
 const tokenRow=database.sqlite.prepare('SELECT * FROM account_tokens').get()!;
 assert.equal(String(tokenRow.token_hash).length,64);assert.notEqual(tokenRow.token_hash,token);
 assert(!JSON.stringify(tokenRow).includes(token));
 const after=database.sqlite.prepare('SELECT state,payload_ciphertext FROM email_outbox').get()!;assert.equal(after.state,'accepted');assert.equal(after.payload_ciphertext,null);
 assert(String(sends[0].payload.text).includes('/account/reset-password#token='));
 await processEmailOutbox(env,runtime);assert.equal(sends.length,1);
});

test('unknown email delivery is retained and retried under the same idempotency key and payload',async()=>{
 await requestPasswordReset(env,'user@example.test',runtime);failSend=true;
 const first=await processEmailOutbox(env,runtime);assert.equal(first.items[0].state,'uncertain');
 assert(database.sqlite.prepare('SELECT payload_ciphertext FROM email_outbox').get()!.payload_ciphertext);
 failSend=false;await processEmailOutbox(env,runtime);
 assert.equal(sends.length,2);assert.equal(sends[0].key,sends[1].key);assert.deepEqual(sends[0].payload,sends[1].payload);
});

test('expired queued links are erased without sending',async()=>{
 await requestPasswordReset(env,'user@example.test',runtime);
 await processEmailOutbox(env,{...runtime,nowMs:NOW+30*60_000});
 assert.equal(sends.length,0);const row=database.sqlite.prepare('SELECT state,payload_ciphertext FROM email_outbox').get()!;
 assert.equal(row.state,'expired');assert.equal(row.payload_ciphertext,null);
});

test('password reset consumes token once and revokes every old session and outstanding token',async()=>{
 const token=await resetLink();
 await requestEmailVerification(env,'u',runtime);
 const result=await resetPassword(env,token,NEW,runtime);assert.equal(result.signInRequired,true);
 const user=database.sqlite.prepare("SELECT password_hash FROM users WHERE id='u'").get()!;
 assert.equal(await verifyPassword(NEW,String(user.password_hash)),true);assert.equal(await verifyPassword(OLD,String(user.password_hash)),false);
 assert.equal(database.sqlite.prepare("SELECT COUNT(*) AS count FROM sessions WHERE user_id='u' AND revoked_at IS NULL").get()!.count,0);
 assert.equal(database.sqlite.prepare("SELECT COUNT(*) AS count FROM account_tokens WHERE user_id='u' AND used_at IS NULL").get()!.count,0);
 await assert.rejects(resetPassword(env,token,'another-password-long-enough',runtime),code('TOKEN_INVALID'));
 await processEmailOutbox(env,runtime);assert.equal(sends.length,1);
});

test('concurrent token consumption permits exactly one password reset',async()=>{
 const token=await resetLink();
 const results=await Promise.allSettled([resetPassword(env,token,NEW,runtime),resetPassword(env,token,'a-different-new-password',runtime)]);
 assert.equal(results.filter(result=>result.status==='fulfilled').length,1);
 assert.equal(database.sqlite.prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action='account.password_reset'").get()!.count,1);
});

test('expired, wrong-purpose and changed-email tokens cannot change passwords',async()=>{
 const token=await resetLink();
 await assert.rejects(resetPassword(env,token,NEW,{...runtime,nowMs:NOW+30*60_000}),code('TOKEN_INVALID'));
 database.sqlite.exec("UPDATE users SET email='changed@example.test' WHERE id='u'");
 await assert.rejects(resetPassword(env,token,NEW,runtime),code('TOKEN_INVALID'));
 database.sqlite.exec("UPDATE users SET email='user@example.test' WHERE id='u'");
 await requestEmailVerification(env,'u',runtime);await processEmailOutbox(env,runtime);
 await assert.rejects(resetPassword(env,mailedToken(1),NEW,runtime),code('TOKEN_INVALID'));
 assert.equal(await verifyPassword(OLD,String(database.sqlite.prepare("SELECT password_hash FROM users WHERE id='u'").get()!.password_hash)),true);
});

test('email verification consumes only matching email-purpose tokens',async()=>{
 const queued=await requestEmailVerification(env,'u',runtime);assert.equal(queued.deliveryState,'queued');
 await processEmailOutbox(env,runtime);const token=mailedToken();
 assert.equal((await verifyEmail(env,token,runtime)).verified,true);
 assert.equal(database.sqlite.prepare("SELECT email_verified_at FROM users WHERE id='u'").get()!.email_verified_at,ISO);
 await assert.rejects(verifyEmail(env,token,runtime),code('TOKEN_INVALID'));
 const repeated=await requestEmailVerification(env,'u',runtime);assert.equal(repeated.verified,true);assert.equal(repeated.queued,false);
});

test('change password requires current password and a live session then signs out all sessions',async()=>{
 await assert.rejects(changePassword(env,'u','current','wrong-password',NEW,runtime),code('CURRENT_PASSWORD_INVALID'));
 await assert.rejects(changePassword(env,'u','foreign',OLD,NEW,runtime),code('SESSION_CHANGED'));
 assert.equal((await changePassword(env,'u','current',OLD,NEW,runtime)).signInRequired,true);
 assert.equal(database.sqlite.prepare("SELECT COUNT(*) AS count FROM sessions WHERE user_id='u' AND revoked_at IS NULL").get()!.count,0);
});

test('session inventory never leaks hashes and revocation is ownership constrained',async()=>{
 const list=await listSessions(env,'u','current',runtime);assert.equal(list.items.length,2);assert.equal(list.items.filter(item=>item.current).length,1);
 assert(!JSON.stringify(list).includes('session-hash'));assert(!JSON.stringify(list).includes('csrf-'));
 await assert.rejects(revokeSessions(env,'u','current','foreign',runtime),code('SESSION_NOT_FOUND'));
 const result=await revokeSessions(env,'u','current','others',runtime);assert.equal(result.revoked,1);
 assert.equal((await listSessions(env,'u','current',runtime)).items.length,1);
 assert.equal((await revokeSessions(env,'u','current','current',runtime)).signInRequired,true);
});

test('forgot-password per-address rate limiting applies to nonexistent accounts too',async()=>{
 for(let index=0;index<3;index++)await requestPasswordReset(env,'unknown@example.test',{...runtime,ip:`ip-${index}`});
 await assert.rejects(requestPasswordReset(env,'unknown@example.test',{...runtime,ip:'another-ip'}),code('RATE_LIMITED'));
 assert.equal(sends.length,0);
});
