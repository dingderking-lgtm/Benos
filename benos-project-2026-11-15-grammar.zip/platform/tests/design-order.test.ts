import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { parseFragment } from 'parse5';
import hashes from './fixtures/foundation-before-design-order.json';
import { DESIGN_STYLES } from '../src/contracts/design-style-catalog';
import { createDesignOrder,materializeDesignOrder,designOrderAuthoringRules,orderCreativeBrief,compileDesignOrder,designOrderFonts } from '../src/contracts/design-order';
import { createDesignFoundation,compileDesignFoundation,foundationAuthoringExample,foundationAuthoringContext,foundationFromRequirements,materializeDesignFoundation,inheritDesignFoundation } from '../src/contracts/design-foundation';
import { createCreativeDirection } from '../src/contracts/creative-direction';
import { createTypographySnapshot } from '../src/contracts/design-typography';
import { enforceTypographySnapshot } from '../src/lib/design-typography';

const order=createDesignOrder({request:'为机械企业设计官网'});
function fixture(html:string,footer='<footer><h2 style="font-weight:400">了解更多</h2><p>真实内容</p></footer>') {
 const m=foundationAuthoringExample(createDesignFoundation(DESIGN_STYLES[0]));
 m.templates.find(t=>t.id===1)!.document.html=html;
 m.templates.find(t=>t.id===4)!.document.html=footer;
 return m;
}
function elements(html:string){const result:any[]=[],stack:any[]=[parseFragment(html)];while(stack.length){const n=stack.pop();if(n.tagName)result.push(n);stack.push(...(n.childNodes||[]));}return result;}
function element(html:string,id:string){return elements(html).find(n=>n.attrs.some((a:any)=>a.name==='id'&&a.value===id));}
const attr=(node:any,name:string)=>node?.attrs.find((a:any)=>a.name===name)?.value;

test('regular is default even for bold creative industry tasks; only explicit experimental intent opts in',()=>{
 for(const request of ['做一个大胆的出海科技企业网站','工业企业官网，突破传统蓝灰','不要实验性设计，规整清晰','Make a bold software website','No experimental design. Keep it orderly.'])assert.equal(createDesignOrder({request}).layoutMode,'regular',request);
 assert.equal(createDesignOrder({request:'我想要杂志感和错位构图'}).layoutMode,'experimental');
 assert.equal(createDesignOrder({request:'做一个网站',stylePreference:'editorial'}).modeSource,'explicit-style');
 assert.equal(createDesignOrder({request:'用英文制作网站'}).language,'en');
 assert.equal(createDesignOrder({request:'موقع شركة',language:'ar'}).language,'ar');
 assert.equal(createDesignOrder({request:'AR product website'}).language,'auto','product acronym is not a language choice');
});

test('all 32 legacy foundation outputs retain their pre-order exact bytes; bnf-3 requires explicit capability',()=>{
 for(const saved of hashes){const style=DESIGN_STYLES.find(s=>s.id===saved.id)!;const p={...createDesignFoundation(style),version:saved.version as 'bnf-1'|'bnf-2'};assert.equal(createHash('sha256').update(compileDesignFoundation(p)).digest('hex'),saved.sha256,saved.id+'/'+saved.version);}
 const base=createDesignFoundation(DESIGN_STYLES[0]);assert.equal(base.version,'bnf-2');assert.equal(base.designOrder,undefined);
 assert.equal(foundationFromRequirements({foundation:{...base,version:'bnf-3'}}),null);
 assert.equal(foundationFromRequirements({foundation:{...base,designOrder:order}}),null);
});

test('new ordered foundation uses only local stacks, six named scales and survives trusted inheritance',()=>{
 for(const style of DESIGN_STYLES){const p=createDesignFoundation(style,style.id,{designOrder:order}),css=compileDesignFoundation(p),context=JSON.stringify(foundationAuthoringContext(p));assert.equal(p.version,'bnf-3');assert.ok(css.includes('benos-design-order:dq-1'));assert.ok(css.includes('hero-cover'));assert.doesNotMatch(css,/@font-face|@import|https?:/);assert.equal(p.tokens.headingFont,designOrderFonts(style.id,order).headingFont);assert.ok(css.length<40000);assert.ok(!context.includes('bnf-nav-center'));assert.ok(!context.includes('bnf-header-masthead'));assert.ok(context.includes('页头只提交 header 数据'));const manifest=materializeDesignFoundation(foundationAuthoringExample(p),p),inherited=inheritDesignFoundation(manifest,p)!;assert.ok(inherited);assert.equal(compileDesignFoundation(inherited,manifest.site.theme),manifest.site.theme.global_css);}
 assert.equal(new Set(DESIGN_STYLES.map(s=>designOrderFonts(s.id,order).headingFont)).size,16);
 assert.match(compileDesignOrder(order),/--bnf-order-tracking:0/);
 assert.match(compileDesignOrder(createDesignOrder({request:'English website'})),/--bnf-order-tracking:-.01em/);
});

test('source span normalization preserves content, images, links and header; typography includes ordinary footer',()=>{
 const source='<!-- do not reserialize --><section id="hero"><div class="copy"><p class="bnf-eyebrow">LABEL</p><h1 id="title" style="font-weight:900;color:red">Hello <span>world</span></h1><p class="bnf-lead">Read <strong id="em">carefully</strong></p><div><a id="action" href="#facts">了解设备</a><a href="/contact">联系</a></div></div><img src="/media/pic.png" width="1024" height="1536" alt="真实图片"></section><section id="facts"><h2>设备信息</h2></section>';
 const m=fixture(source),original=JSON.stringify(m),header=m.templates.find(t=>t.id===3)!.document.html,result=materializeDesignOrder(m,order),html=result.manifest.templates.find(t=>t.id===1)!.document.html,footer=result.manifest.templates.find(t=>t.id===4)!.document.html;
 assert.equal(JSON.stringify(m),original);assert.equal(result.manifest.templates.find(t=>t.id===3)!.document.html,header);assert.ok(html.startsWith('<!-- do not reserialize -->'));assert.ok(html.includes('<img src="/media/pic.png" width="1024" height="1536" alt="真实图片">'));
 assert.match(attr(element(html,'title'),'style'),/font-weight:700!important/);assert.match(attr(element(html,'title'),'style'),/color:red/);assert.match(attr(element(html,'em'),'style'),/font-weight:600!important/);assert.match(attr(element(html,'em'),'style'),/font-size:inherit!important/);
 assert.match(footer,/font-weight:700!important/);assert.equal(result.receipts.filter(r=>r.kind==='primary-action').length,1);assert.equal(result.receipts.find(r=>r.kind==='primary-action')!.href,'#facts');assert.ok(html.includes('bnf-order-group'));
 assert.deepEqual(materializeDesignOrder(result.manifest,order).manifest,result.manifest,'repeated materialization is byte stable');
});

test('one primary and one secondary reuse valid real links and downgrade excess hero actions',()=>{
 const m=fixture('<section><div><h1>业务</h1><p>说明</p><a id="bad" class="bnf-button" href="javascript:alert(1)">危险</a><a id="a" class="bnf-button" href="#detail">详情</a><a id="b" class="bnf-button" href="/contact">联系页</a><a id="c" class="bnf-button" href="#extra">其他</a></div></section><section id="detail"></section><section id="extra"></section>');
 const result=materializeDesignOrder(m,order),html=result.manifest.templates.find(t=>t.id===1)!.document.html;
 assert.match(attr(element(html,'a'),'class'),/bnf-order-primary/);assert.match(attr(element(html,'b'),'class'),/bnf-order-secondary/);assert.doesNotMatch(attr(element(html,'c'),'class'),/bnf-button/);assert.doesNotMatch(attr(element(html,'bad'),'class'),/bnf-order-primary/);assert.equal(attr(element(html,'bad'),'href'),'javascript:alert(1)','normalizer must not conceal invalid URLs from the existing validator');
});

test('missing or ambiguous actions do not invent contact destinations, phone numbers or content',()=>{
 for(const href of ['#missing','#duplicate','/missing','https://unknown.example','tel:12345678']){const m=fixture(`<section><div><h1>企业</h1><p>说明</p><a href="${href}">下一步</a></div></section><div id="duplicate"></div><div id="duplicate"></div>`);const result=materializeDesignOrder(m,order);assert.ok(result.issues.some(i=>i.code==='DESIGN_ORDER_PRIMARY_MISSING'));assert.ok(!result.receipts.some(r=>r.kind==='primary-action'));assert.ok(result.manifest.templates.find(t=>t.id===1)!.document.html.includes(`href="${href}"`));}
 const provided=createDesignOrder({request:'网站，真实预约地址 https://example.org/book'}),allowed=materializeDesignOrder(fixture('<section><h1>预约</h1><a href="https://example.org/book">预约</a></section>'),provided);assert.equal(allowed.receipts.find(r=>r.kind==='primary-action')?.href,'https://example.org/book');
});

test('binding, form, template, picture and navigation subtrees remain byte-identical',()=>{
 const protectedMarkup='<div data-aacms="post-list"><h2 style="font-weight:300">{{title}}</h2><a href="{{url}}">链接</a></div><form><label>邮箱</label><button>提交</button></form><template><h2>动态</h2></template><nav><a href="/">菜单</a></nav><picture><source srcset="/a.webp"><img src="/a.png"></picture>';
 const result=materializeDesignOrder(fixture('<section><h1>普通</h1>'+protectedMarkup+'</section>',`<footer>${protectedMarkup}<h2>普通结尾</h2></footer>`),order);
 assert.ok(result.manifest.templates.find(t=>t.id===1)!.document.html.includes(protectedMarkup));assert.ok(result.manifest.templates.find(t=>t.id===4)!.document.html.includes(protectedMarkup));
});

test('experimental mode retains the author-chosen group layout while enforcing readable type and truthful actions',()=>{
 const experimental=createDesignOrder({request:'实验性设计'}),m=fixture('<section><div style="display:grid"><h1>标题</h1><p>文案</p><a href="#details">探索</a></div></section><section id="details"></section>'),result=materializeDesignOrder(m,experimental),html=result.manifest.templates.find(t=>t.id===1)!.document.html;assert.ok(!html.includes('bnf-order-group'));assert.ok(html.includes('display:grid'));assert.ok(html.includes('font-weight:700!important'));assert.ok(html.includes('bnf-order-primary'));
 assert.equal(materializeDesignOrder(m,null).manifest,m);
});

test('real first-run hero with direct heading, split labels and a right action becomes one aligned group',()=>{
 const m=fixture('<section class="zx-hero"><div class="zx-hero-top"><span>Brand</span><span>Position</span></div><h1 id="title">A different angle.<br><em>A clearer identity.</em></h1><div id="intro" class="zx-intro"><p>Connecting ideas and identities.</p><a class="zx-link" href="/#work">Explore the work <span aria-hidden="true">↘</span></a></div></section><section id="work"><img src="/keep.png" width="1024" height="1024"></section>','<footer><p id="signoff" class="zx-signoff" style="font-weight:400;font-size:90px">Stay open to a new angle.</p></footer>');
 const result=materializeDesignOrder(m,order),html=result.manifest.templates.find(t=>t.id===1)!.document.html,footer=result.manifest.templates.find(t=>t.id===4)!.document.html;
 assert.ok(html.includes('zx-hero bnf-order-group'));assert.match(attr(element(html,'intro'),'style'),/flex-direction:column!important/);assert.match(attr(element(html,'title'),'style'),/margin-block:0!important/);assert.match(attr(element(footer,'signoff'),'style'),/font-weight:700!important/);assert.match(attr(element(footer,'signoff'),'style'),/font-size:var\(--bnf-order-size-h2\)!important/);assert.equal(result.receipts.find(r=>r.kind==='primary-action')?.href,'/#work');
 assert.deepEqual(materializeDesignOrder(result.manifest,order).manifest,result.manifest);
});

test('regular normalization never collapses a media grid or a dynamic sibling into a text group',()=>{
 for(const extra of ['<img src="/x.png">','<div id="bnf-image-hero"></div>','<div data-aacms="posts"><p>CMS</p></div>']){const result=materializeDesignOrder(fixture('<section style="display:grid"><h1>标题</h1><p>说明</p>'+extra+'</section>'),order),html=result.manifest.templates.find(t=>t.id===1)!.document.html;assert.ok(!html.includes('bnf-order-group'));assert.ok(html.includes('style="display:grid"'));assert.ok(html.includes(extra));}
});

test('attribute editing safely escapes quoted CSS and bounds malicious depth without rewriting source',()=>{
 const m=fixture('<section><h1 style="color:red;background-image:url(&quot;/a?x=1&amp;y=2&quot;)">A &amp; B</h1><a href="#x">查看</a></section><div id="x"></div>'),result=materializeDesignOrder(m,order),html=result.manifest.templates.find(t=>t.id===1)!.document.html;
 assert.ok(html.includes('A &amp; B'));assert.match(attr(elements(html).find(n=>n.tagName==='h1'),'style'),/url\("\/a\?x=1&y=2"\)/);
 const deep=fixture('<div>'.repeat(140)+'<h1>深层</h1>'+'</div>'.repeat(140)),guard=materializeDesignOrder(deep,order);assert.equal(guard.manifest,deep);assert.equal(guard.issues[0].code,'DESIGN_ORDER_COMPLEXITY');
});

test('new authoring and creative snapshots remove conflicting defaults without changing legacy rules or factual brief',()=>{
 const old='designBrief.creativeDirection支持跨行业构图、编辑叙事、空间与文字实验，不把行业当审美模板。核心章节改变尺度和阅读路径，避免连续“标题+三列表”；';assert.equal(designOrderAuthoringRules(old,null),old);const next=designOrderAuthoringRules(old,order);assert.ok(!next.includes('支持跨行业构图'));assert.ok(next.includes('set_site_header'));assert.ok(next.includes('header:null'));assert.ok(next.includes('sample off'));
 const brief={source:{request:'用户原文'},creativeDirection:createCreativeDirection({hasExistingSite:false})},saved=JSON.stringify(brief),replaced=orderCreativeBrief(brief,order);assert.equal(JSON.stringify(brief),saved);assert.equal(replaced.source,brief.source);assert.equal((replaced.creativeDirection as any).version,'dq-1');assert.ok(!(replaced.creativeDirection as any).composition.includes('主张与证据错位'));
});

const alignmentMarkup=(style='',className='copy',dir='')=>`<section ${dir?`dir="${dir}"`:''}><div id="copy" class="${className}" style="${style}"><h1 id="headline">Clear title</h1><p id="lead">Useful content</p><div id="actions" class="bnf-actions"><a href="#facts">Explore</a><a href="/contact">Contact</a></div></div></section><section id="facts"><h2>Facts</h2></section>`;
function aligned(style='',css='',className='copy',dir='') {const m=fixture(alignmentMarkup(style,className,dir));m.templates.find(t=>t.id===1)!.document.css=css;return materializeDesignOrder(m,order);}
const homeHtml=(result:ReturnType<typeof aligned>)=>result.manifest.templates.find(t=>t.id===1)!.document.html;

test('ga-1 keeps centered and end-aligned text/action groups; default start stays grouped',()=>{
 for(const alignment of ['start','center','end']){const result=aligned(alignment==='start'?'':`text-align:${alignment}`),html=homeHtml(result),cross=alignment==='start'?'flex-start':alignment==='end'?'flex-end':'center';
  assert.match(attr(element(html,'copy'),'style'),new RegExp(`text-align:${alignment}!important`));assert.match(attr(element(html,'headline'),'style'),new RegExp(`align-self:${cross}!important`));
  assert.match(attr(element(html,'actions'),'style'),/flex-direction:row!important;flex-wrap:wrap!important/);assert.match(attr(element(html,'actions'),'style'),new RegExp(`justify-content:${cross}!important`));
  assert.deepEqual(materializeDesignOrder(result.manifest,order),result,'materialization including receipts is stable');
 }
 assert.equal(order.groupAlignmentVersion,'ga-1');assert.match(designOrderAuthoringRules('rules',order),/成组不等于左对齐/);
});

test('ga-1 resolves bounded ordinary CSS cascade and inherited alignment, including real foundation center',()=>{
 for(const [style,css,expected]of [
  ['','.copy {text-align:center}','center'],['','section {text-align:end}','end'],
  ['text-align:end','.copy{text-align:center!important}','center'],
  ['text-align:end!important','.copy{text-align:center!important}','end'],
  ['','.copy{text-align:end}.copy{text-align:center}','center'],
  ['','.copy{display:flex;flex-direction:column;align-items:center}','center'],
 ] as const)assert.match(attr(element(homeHtml(aligned(style,css)),'copy'),'style'),new RegExp(`text-align:${expected}!important`));
 const profile=createDesignFoundation(DESIGN_STYLES[0],'alignment-fixture',{designOrder:order}),m=materializeDesignFoundation(fixture(alignmentMarkup('','copy bnf-center')),profile),result=materializeDesignOrder(m,order);
 assert.match(attr(element(homeHtml(result),'copy'),'style'),/text-align:center!important/);assert.ok(result.receipts.some(r=>r.kind==='group'));
});

test('ga-1 respects physical alignment by actual direction, preserving logical behavior in RTL',()=>{
 for(const [dir,physical,expected]of [['rtl','right','start'],['rtl','left','end'],['ltr','right','end'],['ltr','left','start']] as const){const html=homeHtml(aligned(`text-align:${physical}`,'','copy',dir));assert.match(attr(element(html,'copy'),'style'),new RegExp(`text-align:${expected}!important`));assert.ok(html.includes(`dir="${dir}"`));}
 const result=aligned('','.copy{direction:rtl;text-align:right}');assert.match(attr(element(homeHtml(result),'copy'),'style'),/text-align:start!important/);
 const m=fixture(alignmentMarkup().replace('id="copy"','id="copy" dir="rtl"'));m.templates.find(t=>t.id===1)!.document.css='section{text-align:left}';
 assert.match(attr(element(homeHtml(materializeDesignOrder(m,order)),'copy'),'style'),/text-align:end!important/,'physical inherited left does not flip when a descendant changes direction');
});

test('ga-1 uses rendered header/page/footer CSS order rather than template storage order',()=>{
 const m=fixture(alignmentMarkup());m.templates.find(t=>t.id===3)!.document.css='.copy{text-align:end}';m.templates.find(t=>t.id===1)!.document.css='.copy{text-align:center}';
 m.templates.sort((a,b)=>[1,3,4,2].indexOf(a.id)-[1,3,4,2].indexOf(b.id));
 assert.match(attr(element(homeHtml(materializeDesignOrder(m,order)),'copy'),'style'),/text-align:center!important/);
 m.templates.find(t=>t.id===4)!.document.css='.copy{text-align:start}';
 assert.match(attr(element(homeHtml(materializeDesignOrder(m,order)),'copy'),'style'),/text-align:start!important/,'footer CSS is rendered after page CSS');
});

test('ga-1 does not infer DOM direction from an Arabic language preference',()=>{
 const arabic=createDesignOrder({request:'موقع شركة',language:'ar'}),m=fixture(alignmentMarkup('text-align:left'));
 assert.match(attr(element(homeHtml(materializeDesignOrder(m,arabic)),'copy'),'style'),/text-align:start!important/,'no dir or direction means browser default LTR');
 m.templates.find(t=>t.id===1)!.document.html=alignmentMarkup('text-align:left','','rtl');
 assert.match(attr(element(homeHtml(materializeDesignOrder(m,arabic)),'copy'),'style'),/text-align:end!important/,'an actual RTL attribute changes physical left to logical end');
});

test('ga-1 preserves conditional, unknown and deliberately complex group layouts instead of guessing',()=>{
 for(const [style,css]of [
  ['','@media(max-width:640px){.copy{text-align:center}}'],
  ['','.copy:is(.copy){text-align:center}'],
  ['','.co\\py{text-align:center}'],
  ['','.copy[data-direction]{text-align:center}'],
  ['','.copy + .other{text-align:center}'],
  ['','@supports(display:grid){.copy{text-align:center}}'],
  ['text-align:var(--alignment)',''],['display:grid;grid-template-columns:1fr 1fr',''],
  ['transform:translateX(10px)',''],['','.copy>h1{text-align:center}'],
  ['','.copy{direction:rtl}.copy>p{direction:ltr}'],
 ] as const){const result=aligned(style,css),html=homeHtml(result);assert.ok(!result.receipts.some(r=>r.kind==='group'),style+' '+css);assert.doesNotMatch(attr(element(html,'copy'),'class'),/bnf-order-group/);assert.equal(attr(element(html,'copy'),'style'),style);assert.equal(result.manifest.templates.find(t=>t.id===1)!.document.css,css);}
 const unaffected=aligned('text-align:center','@media(max-width:640px){.unrelated-header :where(a){text-align:end}}');assert.ok(unaffected.receipts.some(r=>r.kind==='group'),'provably unrelated navigation CSS does not disable correction');
});

test('ga-1 bounds selector work and does not turn a very large text group into guessed layout',()=>{
 const m=fixture('<section><div id="copy"><h1>Title</h1>'+Array.from({length:65},(_,i)=>`<p>Item ${i}</p>`).join('')+'<a href="#facts">More</a></div></section><section id="facts"></section>');
 const result=materializeDesignOrder(m,order);assert.ok(!result.receipts.some(r=>r.kind==='group'));assert.doesNotMatch(attr(element(homeHtml(result),'copy'),'class')||'',/bnf-order-group/);
});

test('ga-1 never substitutes an AI font for a saved local override',()=>{
 const m=fixture(alignmentMarkup('text-align:center').replace('id="headline"','id="headline" class="btf-local-12345678"'));
 const snapshot=createTypographySnapshot({headingFontId:'helvetica',bodyFontId:'helvetica'});snapshot.overrides.push({templateId:1,anchor:'btf-local-12345678',font:{id:'zh-song',stack:'"Songti SC", "Noto Serif CJK SC", SimSun, serif'}});
 const final=enforceTypographySnapshot(materializeDesignOrder(m,order).manifest,snapshot),html=final.templates.find((t:any)=>t.id===1).document.html;
 assert.match(attr(element(html,'headline'),'style'),/font-family:"Songti SC", "Noto Serif CJK SC", SimSun, serif!important/);assert.match(attr(element(html,'headline'),'class'),/btf-local-12345678/);assert.match(attr(element(html,'copy'),'style'),/text-align:center!important/);
});

test('legacy dq-1 without ga-1 retains exact pre-fix CSS, output and authoring bytes',()=>{
 const {groupAlignmentVersion:_,...old}=createDesignOrder({request:'英文企业官网'}),hash=(value:string)=>createHash('sha256').update(value).digest('hex');
 const m={site:{home:'home',header_template_id:3,footer_template_id:4,pages:[{key:'home',template_id:1,slug:'home'}]},templates:[{id:1,type:'page',document:{html:'<!-- keep --><section><div id="copy" style="text-align:center"><h1>Clear title</h1><p>Useful content</p><div class="bnf-actions"><a href="#facts">Explore</a></div></div></section><section id="facts"><h2>Facts</h2></section>',css:''}}]};
 assert.equal(hash(compileDesignOrder(old)),'891dde64972cb23419eae75d3eb218c7c6ce31a7eae1d0054efbde12df00951a');
 assert.equal(hash(JSON.stringify(materializeDesignOrder(m,old))),'787dc4b07e865a9bd99733663cb11a5c7ac7f7548b5df2e8a63cc3ac1a131a33');
 assert.equal(hash(designOrderAuthoringRules('baseline rules',old)),'c9e64fe1fbd6e20c0e8b55e004669513e6bc161766bce6fcfad3c022377fd32d');
});
