import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { createTypographySnapshot, DESIGN_FONT_CATALOG } from '../src/contracts/design-typography';
import { WEB_FONT_FAMILIES,webFontImport,stripManagedFontImports } from '../src/contracts/design-web-fonts';
import { typographyForStyle,patchTypographySelection } from '../src/lib/design-typography';
import { materializeTypography } from '../src/lib/typography-materialization';
import { typographyScopeProjection } from '../src/lib/header-typography';
import { validateSiteManifest } from '../src/modules/template-contract';
import { assertDesignScope } from '../src/modules/design-nodes';
import example from '../src/contracts/site-example.json';
test('Helvetica is the default independent of language/style; selectable catalog exposes 33 actual names',()=>{
 for(const style of ['industrial','modern','editorial','luxury']){const s=typographyForStyle(style);assert.equal(s.heading?.id,'helvetica');assert.equal(s.body?.id,'helvetica');assert.match(s.body!.stack,/^Helvetica,/);}
 assert.equal(DESIGN_FONT_CATALOG.filter(f=>!f.legacy).length,33);assert.equal(WEB_FONT_FAMILIES.length,32);
});
test('managed imports are first, deduplicated, removable and retained through replay',()=>{
 const profile=createTypographySnapshot({headingFontId:'google-inter',bodyFontId:'google-inter'}),m=materializeTypography(structuredClone(example),profile);assert.deepEqual(m.issues,[]);assert.ok(m.manifest.site.theme.global_css.startsWith(webFontImport('Inter')));assert.equal(m.manifest.site.theme.global_css.split(webFontImport('Inter')).length,2);assert.equal(validateSiteManifest(m.manifest).valid,true);assert.deepEqual(materializeTypography(m.manifest,profile).manifest,m.manifest);
 const reset=materializeTypography(m.manifest,typographyForStyle('modern'));assert.doesNotMatch(reset.manifest.site.theme.global_css,/@import/);
});
test('arbitrary imports and forged managed URLs remain rejected',()=>{
 for(const css of ['@import url("https://evil.test/font.css");',webFontImport('Inter').replace('Inter','Unlisted'),webFontImport('Inter').replace('fonts.googleapis.com','fonts.googleapis.com.evil.test'),'@font-face{font-family:Bad;src:url(https://evil.test/a)}']){const m=structuredClone(example);m.site.theme.global_css+=css;assert.equal(validateSiteManifest(m).valid,false);assert.notEqual(stripManagedFontImports(css),'');}
});
test('local managed font changes stay within the requested node after exact import projection',async()=>{
 const scope={kind:'node' as const,templateId:1,nodeKey:'n1'},result=await patchTypographySelection(structuredClone(example) as any,scope,{fontId:'google-inter'},null,'google-local-font-001');assert.match(result.manifest.site.theme!.global_css!,/@import/);assertDesignScope(example as any,typographyScopeProjection(example as any,result.manifest,result.profile),scope);
});
test('native managed renderer retains only the allowlisted font import',()=>{
 const code=String.raw`require $argv[1].'/vendor/autoload.php';require $argv[2];$source=file_get_contents($argv[1].'/src/Services/Renderer.php');$source=\Benos\FontsOverlay::transform('src/Services/Renderer.php',str_replace("\r\n","\n",$source));eval(substr($source,5));$p=new class extends PDO{public function __construct(){}};$r=new \AACMS\Services\Renderer($p);echo $r->sanitizeCss(stream_get_contents(STDIN));`;
 const css=webFontImport('Inter')+'h1{font-family:Inter}'+ '@import url("https://evil.test/fonts");';const r=spawnSync(process.env.BENOS_TEST_PHP||'php',['-r',code,resolve('../reference/aacmss'),resolve('cms-connector/src/FontsOverlay.php')],{input:css,encoding:'utf8',windowsHide:true});assert.equal(r.status,0,r.stderr);assert.ok(r.stdout.startsWith(webFontImport('Inter')));assert.doesNotMatch(r.stdout,/evil/);assert.match(r.stdout,/font-family:Inter/);
});
