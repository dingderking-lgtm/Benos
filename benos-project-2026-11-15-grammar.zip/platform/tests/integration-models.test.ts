import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { encryptSecret,decryptSecret,randomToken,sha256 } from '../src/lib/crypto';
import { seedCapabilityFixture } from './integration-test-helper';
import { app } from '../src/index';

const pricing={baseUrl:'https://api.openai.com/v1',model:'gpt-6.1-sol',protocol:'responses',providerPoolId:'openai',inputMicrosPerMillion:2000000,cachedInputMicrosPerMillion:100000,outputMicrosPerMillion:10000000,contextTokens:1050000,maxOutputTokens:10000,billingProfile:'openai-gpt6-standard-2026-11-07',cacheTtl:'30m',pricingConfirmedAt:new Date().toISOString()};
async function fixture(){
 const db=new TestD1(),env=testEnv(db),time=new Date().toISOString();
 for(const role of ['owner','admin','user'])db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(role,role+'@example.test',role,'fixture',role,time,time);
 db.sqlite.prepare("INSERT INTO provider_pools(provider_id,funded_micros,updated_at_ms) VALUES('openai',100000000,?)").run(Date.now());
 const key='fixture-credential-never-live';
 async function seed(configId:string,model='gpt-6.1-sol',status='tested'){
  const config={...pricing,model,cachedInputMicrosPerMillion:model==='gpt-6-sol'?200000:100000};
  db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,tested_at,created_by,created_at) VALUES(?,'text',?,'openai',1,?,?,?,'passed',?,'owner',?)").run(configId,configId,status,JSON.stringify(config),await encryptSecret(JSON.stringify({apiKey:key}),env.ENCRYPTION_KEY,configId),time,time);
  await seedCapabilityFixture(env.DB,configId);
 }
 async function request(path:string,data:unknown,role='owner'){
  const token=randomToken(),csrf=randomToken();db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run(token,await sha256(token),role,csrf,time,'2099-01-01T00:00:00.000Z','fixture');
  return app.fetch(new Request(env.APP_ORIGIN+'/api/admin/integrations'+(path==='/'?'':path),{method:'POST',headers:{origin:env.APP_ORIGIN,cookie:'benos_session='+token,'x-csrf-token':csrf,'content-type':'application/json'},body:JSON.stringify(data)}),env);
 }
 await seed('source','gpt-6.1-sol','active');return {db,env,key,seed,request};
}
test('AI credential reuse re-encrypts for the new config and never returns the key',async()=>{
 const f=await fixture();try{
  const response=await f.request('/',{kind:'text',name:'Second model',provider:'openai',publicConfig:{...pricing,model:'gpt-6-sol',cachedInputMicrosPerMillion:200000},secretSourceConfigId:'source'});
  assert.equal(response.status,201);const body=await response.json() as any;assert.ok(!JSON.stringify(body).includes(f.key));
  const created=f.db.sqlite.prepare("SELECT * FROM integration_configs WHERE name='Second model'").get()!;
  assert.deepEqual(JSON.parse(await decryptSecret(String(created.secret_ciphertext),f.env.ENCRYPTION_KEY,String(created.id))),{apiKey:f.key});
  assert.equal(created.status,'draft');assert.equal(f.db.sqlite.prepare("SELECT status FROM integration_configs WHERE id='source'").get()!.status,'active');
 }finally{f.db.close();}
});
test('credential reuse rejects cross-provider, invalid source, mixed credentials and non-owner requests',async()=>{
 const f=await fixture();try{
  const input={kind:'text',name:'Blocked',provider:'openai',publicConfig:pricing,secretSourceConfigId:'source'};
  for(const data of [{...input,provider:'deepseek'},{...input,secretSourceConfigId:'missing'},{...input,secret:{apiKey:f.key}},{...input,kind:'email'}])assert.ok((await f.request('/',data)).status>=400);
  for(const role of ['admin','user'])assert.equal((await f.request('/',input,role)).status,403);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM integration_configs').get()!.n,1);
 }finally{f.db.close();}
});
test('enabling another code model replaces the prior model from the same provider',async()=>{
 const f=await fixture();try{
  await f.seed('second','gpt-6-sol');assert.equal((await f.request('/second/activate',{})).status,200);
  assert.deepEqual(f.db.sqlite.prepare("SELECT id FROM integration_configs WHERE status='active' ORDER BY id").all().map(row=>row.id),['second']);
  await f.seed('replacement');assert.equal((await f.request('/replacement/activate',{})).status,200);
  assert.deepEqual(f.db.sqlite.prepare("SELECT id FROM integration_configs WHERE status='active' ORDER BY id").all().map(row=>row.id),['replacement']);
  assert.equal(f.db.sqlite.prepare("SELECT status FROM integration_configs WHERE id='source'").get()!.status,'disabled');
 }finally{f.db.close();}
});
test('database prevents two active models from the same provider and purpose',async()=>{
 const f=await fixture();try{await f.seed('duplicate','gpt-6-sol');assert.throws(()=>f.db.sqlite.prepare("UPDATE integration_configs SET status='active' WHERE id='duplicate'").run(),/UNIQUE/);}finally{f.db.close();}
});

test('compatible credential reuse is pinned to the same normalized base URL including path',async()=>{
 const f=await fixture();try{
  const config={...pricing,baseUrl:'https://provider-a.com/v1',billingProfile:'unverified'};
  f.db.sqlite.prepare("UPDATE integration_configs SET provider='openai-compatible',public_config_json=? WHERE id='source'").run(JSON.stringify(config));
  const input={kind:'text',name:'Compatible reuse',provider:'openai-compatible',publicConfig:config,secretSourceConfigId:'source'};
  for(const baseUrl of ['https://provider-b.com/v1','https://provider-a.com/other/v1']){
   const response=await f.request('/',{...input,publicConfig:{...config,baseUrl}});assert.equal(response.status,409);assert.equal((await response.json() as any).error.code,'INVALID_SECRET_SOURCE');
  }
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM integration_configs').get()!.n,1);
  const response=await f.request('/',{...input,publicConfig:{...config,baseUrl:'https://PROVIDER-A.com:443/v1/'}});assert.equal(response.status,201);
  const created=f.db.sqlite.prepare("SELECT * FROM integration_configs WHERE name='Compatible reuse'").get()!;
  assert.deepEqual(JSON.parse(await decryptSecret(String(created.secret_ciphertext),f.env.ENCRYPTION_KEY,String(created.id))),{apiKey:f.key});
 }finally{f.db.close();}
});
