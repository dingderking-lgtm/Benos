﻿// The production package: the grammar's pages inside a real AACMS site package, checked by the
// platform's own importer contract, plus the picture frames the image pipeline fills.
import test from 'node:test';
import assert from 'node:assert/strict';
import { compileGrammarManifest } from '../src/design-system/grammar/manifest';
import { bindingFrames } from '../src/design-system/grammar/frames';
import { compileSite } from '../src/design-system/grammar/site';
import { validateSiteManifest } from '../src/modules/template-contract';
import { compilePage } from '../src/design-system/grammar/compile';
const page = (over: Record<string, any> = {}): any => ({ lang: 'en', title: 'Workshop', brand, images, links: ['/', '/about'], ...over, sections: over.sections ?? [] });
const errors = (list: any[]) => list.filter(issue => issue.level === 'error');
import { bindGrammarImages } from '../src/design-system/grammar/bind';
import { freezeGrammarComposition, grammarSnapshot, validateGrammarComposition } from '../src/lib/grammar-workflow';
import { GRAMMAR_IDENTITY } from '../src/design-system/grammar/identity';

const brand = {
  colors: { paper: '#f7f7f4', tint: '#eceee9', ink: '#16181b', copy: '#4a5056', line: '#d8dbd6', accent: '#1f6feb', accentInk: '#ffffff', mark: '#c2571a', dark: '#12161a', darkInk: '#f2f4f3' },
  type: { head: 'grotesk', body: 'humanist', weight: 600, tracking: 'tight', scale: 'regular' },
  shape: { radius: 'large', button: 'pill' },
  styles: { kicker: 'square', link: 'underline', card: 'soft', figure: 'framed' },
  space: { container: 1280, density: 'regular' },
};
const images = {
  hero: { src: '/uploads/2026/11/' + 'a'.repeat(32) + '.webp', w: 1600, h: 1000, alt: 'the workshop' },
  detail: { src: '/uploads/2026/11/' + 'b'.repeat(32) + '.webp', w: 1200, h: 1200, alt: 'a finished part' },
};
const sections = (title: string) => [
  { id: 'hero', tone: 'paper', space: 'hero', body: [{ t: 'kicker', text: 'Precision machining' }, { t: 'display', lines: [title] }, { t: 'text', text: 'Turning and milling for short runs.', role: 'lead' }, { t: 'actions', items: [{ label: 'Talk to us', href: '/about', kind: 'primary' }] }] },
  { id: 'work', tone: 'paper', body: [{ t: 'title', text: 'What we make' }, { t: 'grid', cols: [5, 7], children: [{ t: 'figure', image: 'hero', ratio: '3:2' }, { t: 'stack', children: [{ t: 'text', text: 'Brackets, housings and shafts.' }, { t: 'figure', image: 'detail', ratio: '1:1' }] }] }] },
  { id: 'next', tone: 'dark', space: 'band', body: [{ t: 'title', text: 'Send a drawing' }, { t: 'actions', items: [{ label: 'Start a quote', href: '/about', kind: 'primary' }] }] },
];
const asset = (key: keyof typeof images, file: string) => ({ path: images[key].src, file: 'assets/' + file + '.webp', sha256: (key === 'hero' ? 'a' : 'b').repeat(64), size: 240000 });
const site = () => ({ brand: brand as never, images, pages: [
  { key: 'home', path: '/', title: 'Home', sections: sections('Parts that fit') as never },
  { key: 'about', path: '/about', title: 'About', sections: sections('How we work') as never },
] });

test('a compiled site becomes a package the platform importer accepts', () => {
  const result = compileGrammarManifest(site(), { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z', assets: [asset('hero', '01'), asset('detail', '02')] });
  assert.equal(result.ok, true, JSON.stringify(result.issues.filter(issue => issue.level === 'error').slice(0, 5)));
  const manifest = result.manifest as any;
  // Header, footer and one template per page.
  assert.deepEqual(manifest.templates.map((template: any) => template.type), ['header', 'footer', 'page', 'page']);
  assert.equal(manifest.site.header_template_id, 1);
  assert.equal(manifest.site.footer_template_id, 2);
  assert.equal(manifest.site.navigation_menu_id, 1);
  assert.equal(manifest.site.home, 'home');
  assert.equal(manifest.root_id, 3);
  // The site-wide stylesheet carries the brand tokens once; each page only adds its own rules.
  assert.match(manifest.site.theme.global_css, /^\.bnl\{--paper:/);
  assert.match(manifest.site.theme.global_css, /\.bnl-site-header\{/);
  assert.match(manifest.templates[2].document.css, /\.bnl-home-/);
  assert.doesNotMatch(manifest.templates[2].document.css, /--paper:#/);
  // Navigation is a CMS menu, so links can be re-pointed on import.
  assert.match(manifest.templates[0].document.html, /data-aacms="site-navigation" data-aacms-menu="1"/);
  assert.equal(manifest.menus[0].items.length, 2);
  assert.deepEqual(manifest.menus[0].items.map((item: any) => item.url), ['/', '/about']);
  // The platform's own contract agrees.
  assert.equal(validateSiteManifest(manifest).valid, true);
});

test('a package without a second page is refused before the importer sees it', () => {
  const result = compileGrammarManifest({ brand: brand as never, images, pages: [{ key: 'home', path: '/', title: 'Home', sections: sections('Parts that fit') as never }] }, { name: 'Workshop', slug: 'workshop' });
  assert.equal(result.ok, false);
  assert.ok(result.issues.some(issue => /at least two pages/.test(issue.message)));
});

test('every picture gets exactly one frame the image pipeline can fill', () => {
  const compiled = compileSite(site());
  assert.equal(compiled.ok, true);
  const { frames, issues } = bindingFrames(compiled, { containerWidth: 1280 });
  assert.equal(issues.length, 0);
  // Two pages, two pictures each.
  assert.equal(frames.length, 4);
  assert.equal(new Set(frames.map(frame => frame.frameId)).size, 4);
  for (const frame of frames) assert.match(frame.frameId, /^bnf-image-[a-z]+-[a-z-]+-\d+$/);
  const figure = frames.find(frame => frame.purpose === 'figure')!;
  assert.equal(figure.slot.fit, 'cover');
  // A figure shows the whole picture (fit contain is the grammar's default), so the subject is complete.
  assert.equal(figure.subjectPolicy, 'complete');
  assert.ok(figure.slot.width > 0 && figure.slot.height > 0);
  // A frame that crops (fit cover) says so, so the image pipeline knows it may lose edges.
  const cropped = bindingFrames(compileSite({ brand: brand as never, images, pages: [
    { key: 'home', path: '/', title: 'Home', sections: [
      { id: 'hero', tone: 'paper', space: 'hero', body: [{ t: 'display', lines: ['Parts'] }, { t: 'text', text: 'Short runs.' }] },
      { id: 'shot', tone: 'paper', body: [{ t: 'figure', image: 'hero', ratio: '16:9', fit: 'cover' }] },
      { id: 'end', tone: 'dark', space: 'band', body: [{ t: 'title', text: 'Send a drawing' }] },
    ] as never },
    { key: 'about', path: '/about', title: 'About', sections: sections('How we work') as never },
  ] }));
  assert.equal(cropped.frames.find(frame => frame.purpose === 'figure')!.subjectPolicy, 'crop-safe');
  const square = frames.filter(frame => frame.native.width === frame.native.height)[0];
  assert.equal(square.slot.width, square.slot.height);
  // The frame ids in the package and in the markup are the same ids.
  const result = compileGrammarManifest(site(), { name: 'Workshop', slug: 'workshop', assets: [asset('hero', '01'), asset('detail', '02')] });
  for (const page of result.pages) {
    const template = (result.manifest as any).templates.find((entry: any) => entry.id === page.templateId);
    for (const frameId of page.frames) assert.match(template.document.html, new RegExp(`id="${frameId}"`));
  }
});

test('a form page declares its form in the package', () => {
  const withForm = (title: string) => [
    { id: 'hero', tone: 'paper', space: 'hero', body: [{ t: 'display', lines: [title] }, { t: 'text', text: 'Short runs, checked part by part.', role: 'lead' }] },
    { id: 'talk', tone: 'paper', body: [{ t: 'title', text: 'Send a drawing' }, { t: 'form', title: 'Start a quote' }] },
    { id: 'end', tone: 'dark', space: 'band', body: [{ t: 'title', text: 'We reply within one working day' }] },
  ];
  const result = compileGrammarManifest({ brand: brand as never, pages: [
    { key: 'home', path: '/', title: 'Home', sections: withForm('Parts that fit') as never },
    { key: 'contact', path: '/contact', title: 'Contact', sections: withForm('Talk to us') as never },
  ] }, { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z' });
  assert.equal(result.ok, true, JSON.stringify(result.issues.filter(issue => issue.level === 'error').slice(0, 5)));
  const manifest = result.manifest as any;
  assert.deepEqual(manifest.forms.map((form: any) => form.ref), ['contact']);
  assert.equal(manifest.site.forms.length, 1);
  assert.ok(manifest.site.forms[0].definition.fields.length >= 4);
  assert.equal(manifest.site.forms[0].definition.fields[0].type, 'text');
  assert.equal(validateSiteManifest(manifest).valid, true);
});

test('a blog-enabled package carries the CMS article shells', () => {
  const result = compileGrammarManifest({ brand: brand as never, images, pages: [
    { key: 'home', path: '/', title: 'Home', sections: sections('Parts that fit') as never },
    { key: 'about', path: '/about', title: 'About', sections: sections('How we work') as never },
  ] }, { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z', assets: [asset('hero', '01'), asset('detail', '02')], blog: { enabled: true, title: '笔记' } });
  assert.equal(result.ok, true, JSON.stringify(result.issues.filter(issue => issue.level === 'error').slice(0, 5)));
  const manifest = result.manifest as any;
  const archive = manifest.templates.find((template: any) => template.type === 'archive');
  const single = manifest.templates.find((template: any) => template.type === 'single');
  assert.ok(archive && single, 'archive and single templates');
  for (const template of [archive, single]) assert.match(template.document.html, /data-aacms="page-content"/);
  assert.equal(manifest.site.blog.enabled, true);
  assert.equal(manifest.site.blog.archive_template_id, archive.id);
  assert.equal(manifest.site.blog.single_template_id, single.id);
  assert.equal(validateSiteManifest(manifest).valid, true);
  // Without the option the package stays a plain marketing site.
  const plain = compileGrammarManifest({ brand: brand as never, images, pages: [
    { key: 'home', path: '/', title: 'Home', sections: sections('Parts that fit') as never },
    { key: 'about', path: '/about', title: 'About', sections: sections('How we work') as never },
  ] }, { name: 'Workshop', slug: 'workshop', assets: [asset('hero', '01'), asset('detail', '02')] });
  assert.equal((plain.manifest as any).site.blog, undefined);
  assert.equal((plain.manifest as any).templates.some((template: any) => template.type === 'archive'), false);
});

test('an SVG icon rides a picture slot like any other owned file', () => {
  const svg = { src: '/uploads/2026/11/' + 'c'.repeat(32) + '.svg', w: 24, h: 24, alt: 'tolerance icon' };
  const result = compileGrammarManifest({ brand: brand as never, images: { ...images, icon: svg }, pages: [
    { key: 'home', path: '/', title: 'Home', sections: [
      { id: 'hero', tone: 'paper', space: 'hero', body: [{ t: 'display', lines: ['Parts'] }, { t: 'text', text: 'Short runs.', role: 'lead' }] },
      { id: 'proof', tone: 'paper', body: [{ t: 'title', text: 'Why us' }, { t: 'row', gap: 4, align: 'center', children: [{ t: 'figure', image: 'icon', ratio: '1:1', max: 'xs' }, { t: 'text', text: 'Tolerances checked part by part.' }] }] },
      { id: 'end', tone: 'dark', space: 'band', body: [{ t: 'title', text: 'Send a drawing' }] },
    ] as never },
    { key: 'about', path: '/about', title: 'About', sections: sections('How we work') as never },
  ] }, { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z', assets: [
    { path: svg.src, file: 'assets/01.svg', sha256: 'c'.repeat(64), size: 2048 },
    asset('hero', '02'), asset('detail', '03'),
  ] });
  assert.equal(result.ok, true, JSON.stringify(result.issues.filter(issue => issue.level === 'error').slice(0, 5)));
  const manifest = result.manifest as any;
  assert.match(manifest.templates[2].document.html, /<img id="bnf-image-home-proof-\d+" src="\/uploads\/2026\/11\/c{32}\.svg"/);
  assert.match(manifest.templates[2].document.html, /class="[^"]*bnl-mx-xs/);
  assert.deepEqual(manifest.assets.map((entry: any) => entry.file), ['assets/01.svg', 'assets/02.webp', 'assets/03.webp']);
  assert.equal(validateSiteManifest(manifest).valid, true);
});

test('frozen grammar bytes are enforced, never advisory', () => {
  const built = compileGrammarManifest({ brand: brand as never, images, pages: [
    { key: 'home', path: '/', title: 'Home', sections: sections('Parts that fit') as never },
    { key: 'about', path: '/about', title: 'About', sections: sections('How we work') as never },
  ] }, { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z', assets: [asset('hero', '01'), asset('detail', '02')] });
  assert.equal(built.ok, true);
  const manifest = built.manifest as any;
  const frozen = freezeGrammarComposition(manifest, grammarSnapshot(manifest));
  assert.equal(frozen.identity, GRAMMAR_IDENTITY.digest);
  assert.deepEqual(validateGrammarComposition(manifest, frozen), []);

  // A held page edited after the freeze is refused with the template that changed.
  const edited = structuredClone(manifest);
  edited.templates.find((template: any) => template.type === 'page').document.html += '<p>late edit</p>';
  const drift = validateGrammarComposition(edited, frozen);
  assert.ok(drift.some(issue => issue.code === 'GRAMMAR_OUTPUT_CHANGED'), JSON.stringify(drift));
  // A missing snapshot is refused too, and a different grammar identity makes the task stale.
  assert.ok(validateGrammarComposition(manifest, null).some(issue => issue.code === 'GRAMMAR_SNAPSHOT_MISSING'));
  assert.ok(validateGrammarComposition(manifest, { ...frozen, identity: 'f'.repeat(64) }).some(issue => issue.code === 'GRAMMAR_IDENTITY_CHANGED'));
  // Re-freezing after a legitimate platform rewrite keeps the task valid.
  const refrozen = freezeGrammarComposition(edited, frozen);
  assert.deepEqual(validateGrammarComposition(edited, refrozen), []);
});

test('a pending frame gains its picture when it is generated', () => {
  const pendingSections = (title: string) => [
    { id: 'hero', tone: 'paper', space: 'hero', body: [{ t: 'display', lines: [title] }, { t: 'figure', pending: true, ratio: '3:2' }, { t: 'text', text: 'Short runs, checked part by part.', role: 'lead' }] },
    { id: 'work', tone: 'tint', body: [{ t: 'title', text: 'What we make' }, { t: 'list', items: ['Prototypes', 'Small runs'] }] },
    { id: 'end', tone: 'dark', space: 'band', body: [{ t: 'title', text: 'Send a drawing' }] },
  ];
  const compiled = compilePage(page({ sections: pendingSections('Parts that fit') as never }), { scope: 'home' });
  assert.equal(compiled.ok, true, JSON.stringify(errors(compiled.issues)));
  assert.equal(compiled.stats.pendingFrames.length, 1);
  // The placeholder reserves the frame and carries no source at all.
  assert.match(compiled.body, new RegExp('<img id="' + compiled.stats.pendingFrames[0] + '"[^>]*width="1600"'));
  assert.doesNotMatch(compiled.body, /\ssrc="/);

  const manifest = compileGrammarManifest({ brand: brand as never, images, pages: [
    { key: 'home', path: '/', title: 'Home', sections: pendingSections('Parts that fit') as never },
    { key: 'about', path: '/about', title: 'About', sections: sections('How we work') as never },
  ] }, { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z', assets: [asset('hero', '01'), asset('detail', '02')] });
  assert.equal(manifest.ok, true, JSON.stringify(manifest.issues.filter(issue => issue.level === 'error').slice(0, 3)));
  const bound = bindGrammarImages(manifest.manifest as any, [{
    frameId: 'bnf-image-home-hero-1', src: '/uploads/2026/11/' + 'f'.repeat(32) + '.webp', width: 1536, height: 1024,
    asset: { path: '/uploads/2026/11/' + 'f'.repeat(32) + '.webp', file: 'assets/11.webp', sha256: 'f'.repeat(64), size: 700_000 },
  }]);
  assert.deepEqual(bound.bound, ['bnf-image-home-hero-1']);
  const patched = (bound.manifest as any).templates.find((template: any) => template.type === 'page').document.html as string;
  assert.match(patched, new RegExp('id="bnf-image-home-hero-1" src="/uploads/2026/11/' + 'f'.repeat(32) + '\\.webp"'), 'the source is inserted, not replaced');
  assert.match(patched, /width="1536" height="1024"/);
  assert.equal(validateSiteManifest(bound.manifest).valid, true);
});

test('a generated picture lands in the frame the page asked for', () => {
  const built = compileGrammarManifest({ brand: brand as never, images, pages: [
    { key: 'home', path: '/', title: 'Home', sections: sections('Parts that fit') as never },
    { key: 'about', path: '/about', title: 'About', sections: sections('How we work') as never },
  ] }, { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z', assets: [asset('hero', '01'), asset('detail', '02')] });
  assert.equal(built.ok, true, JSON.stringify(built.issues.filter(issue => issue.level === 'error').slice(0, 3)));
  const manifest = built.manifest as any;
  // The compiler reserved a frame for every picture; the generated file replaces only its <img>.
  const frameId = (manifest.templates[2].document.html.match(/id="(bnf-image-home-[a-z-]+-\d+)"/) ?? [])[1];
  assert.ok(frameId, 'a frame id in the home page');
  const bound = bindGrammarImages(manifest, [{
    frameId, src: '/uploads/2026/11/' + 'd'.repeat(32) + '.webp', width: 1536, height: 1024,
    asset: { path: '/uploads/2026/11/' + 'd'.repeat(32) + '.webp', file: 'assets/09.webp', sha256: 'd'.repeat(64), size: 512_000 },
  }]);
  assert.deepEqual(bound.bound, [frameId]);
  assert.deepEqual(bound.missing, []);
  const html = (bound.manifest as any).templates[2].document.html as string;
  assert.match(html, new RegExp('id="' + frameId + '"[^>]*src="/uploads/2026/11/' + 'd'.repeat(32) + '\\.webp"'));
  assert.match(html, /width="1536" height="1024"/);
  assert.ok((bound.manifest as any).assets.some((entry: any) => entry.file === 'assets/09.webp'));
  assert.equal(validateSiteManifest(bound.manifest).valid, true);
  // A frame id that no page carries is reported, never silently dropped.
  const nothing = bindGrammarImages(manifest, [{
    frameId: 'bnf-image-home-nope-1', src: '/uploads/2026/11/' + 'e'.repeat(32) + '.webp', width: 800, height: 600,
    asset: { path: '/uploads/2026/11/' + 'e'.repeat(32) + '.webp', file: 'assets/10.webp', sha256: 'e'.repeat(64), size: 1000 },
  }]);
  assert.deepEqual(nothing.bound, []);
  assert.deepEqual(nothing.missing, ['bnf-image-home-nope-1']);
});

test('the same site always produces the same package', () => {
  const first = compileGrammarManifest(site(), { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z' });
  const second = compileGrammarManifest(site(), { name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z' });
  assert.equal(JSON.stringify(first.manifest), JSON.stringify(second.manifest));
});
