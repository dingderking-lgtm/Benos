import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { AppError } from '../src/lib/errors';
import { probeModelAccess,safeProbeFailure } from '../src/lib/integration-probe';
import { TestD1,testEnv } from './d1-helper';

const secret='sk-PRIVATE_PROBE_FIXTURE_0123456789';
const model='fixture-model';
const config={baseUrl:'https://api.openai.com/v1',model,listing:false};
const hostile=`${secret} https://private.example.invalid/secret <script>private</script>`;

async function fixture(){
 const db=new TestD1(),env=testEnv(db);
 let session:{cookie:string;csrf:string}|undefined;
 const request=(path:string,method='GET',data?:unknown)=>app.fetch(new Request(env.APP_ORIGIN+path,{method,headers:{origin:env.APP_ORIGIN,...(data?{'content-type':'application/json'}:{}),...(session?{cookie:session.cookie,'x-csrf-token':session.csrf}:{})},body:data?JSON.stringify(data):undefined}),env);
 const response=await request('/api/bootstrap','POST',{token:env.BOOTSTRAP_TOKEN,email:'owner@example.test',password:'long-probe-fixture-password',name:'Owner'}),user=await response.json() as any;
 assert.equal(response.status,201);
 session={cookie:response.headers.get('set-cookie')!.split(';')[0],csrf:user.data.csrfToken};
 const created=await request('/api/admin/integrations','POST',{kind:'text',provider:'openai',name:'模型访问',publicConfig:{baseUrl:config.baseUrl,model,protocol:'responses',providerPoolId:'probe-fixture',inputMicrosPerMillion:1000,cachedInputMicrosPerMillion:100,outputMicrosPerMillion:1000,contextTokens:1024,maxOutputTokens:16,pricingConfirmedAt:new Date().toISOString()},secret:{apiKey:secret}});
 assert.equal(created.status,201,await created.clone().text());
 const row=(await created.json() as any).data;
 return {db,env,request,id:row.id};
}

const failures:[string,string,()=>Promise<Response>,Record<string,unknown>][]=[
 ['invalid credentials','PROBE_CREDENTIALS_INVALID',async()=>new Response(hostile,{status:401}),{upstreamStatus:401}],
 ['access denied','PROBE_ACCESS_DENIED',async()=>new Response(hostile,{status:403}),{upstreamStatus:403}],
 ['model unavailable','PROBE_MODEL_UNAVAILABLE',async()=>new Response(hostile,{status:404}),{upstreamStatus:404}],
 ['rate limited','PROBE_RATE_LIMITED',async()=>new Response(hostile,{status:429}),{upstreamStatus:429}],
 ['upstream unavailable','PROBE_UPSTREAM_UNAVAILABLE',async()=>new Response(hostile,{status:503}),{upstreamStatus:503}],
 ['redirect refused','PROBE_RESPONSE_INVALID',async()=>new Response(hostile,{status:302,headers:{location:'https://private.example.invalid/collect'}}),{upstreamStatus:302}],
 ['timeout','PROBE_TIMEOUT',async()=>{throw new DOMException(hostile,'TimeoutError');},{networkReason:'TIMEOUT'}],
 ['DNS failure','PROBE_NETWORK_ERROR',async()=>{throw new TypeError(hostile,{cause:Object.assign(new Error(hostile),{code:'ENOTFOUND'})});},{networkReason:'DNS'}],
 ['TLS failure','PROBE_NETWORK_ERROR',async()=>{throw new TypeError(hostile,{cause:Object.assign(new Error(hostile),{code:'CERT_HAS_EXPIRED'})});},{networkReason:'TLS'}],
 ['connection failure','PROBE_NETWORK_ERROR',async()=>{throw Object.assign(new Error(hostile),{code:'ECONNRESET'});},{networkReason:'CONNECTION'}],
 ['malformed response','PROBE_RESPONSE_INVALID',async()=>new Response(hostile),{upstreamStatus:200}],
 ['wrong model','PROBE_MODEL_UNAVAILABLE',async()=>Response.json({id:'other-model',private:hostile}),{upstreamStatus:200}],
];

for(const [label,code,reply,details] of failures)test(`model access ${label} is a safe 409, persists failed status, and never generates`,async t=>{
 const f=await fixture();
 try{
  // A failed recheck must revoke the earlier access result, without activation.
  f.db.sqlite.prepare("UPDATE integration_configs SET status='tested',test_status='passed' WHERE id=?").run(f.id);
  let calls=0;
  t.mock.method(globalThis,'fetch',async(url:RequestInfo|URL,init?:RequestInit)=>{
   calls++;assert.equal(String(url),config.baseUrl+'/models/'+model);assert.equal(init?.method,'GET');assert.equal(init?.redirect,'manual');assert.ok(init?.signal instanceof AbortSignal);assert.equal((init?.headers as Record<string,string>).Authorization,'Bearer '+secret);assert.equal(init?.body,undefined);
   return reply();
  });
  const response=await f.request('/api/admin/integrations/'+f.id+'/test','POST',{}),text=await response.text(),body=JSON.parse(text);
  assert.equal(response.status,409);assert.equal(body.error.code,code);assert.match(body.error.requestId,/^req_/);assert.equal(calls,1);
  assert.deepEqual({...f.db.sqlite.prepare('SELECT status,test_status FROM integration_configs WHERE id=?').get(f.id)},{status:'draft',test_status:'failed'});
  const audit=f.db.sqlite.prepare("SELECT details_json,request_id FROM audit_logs WHERE action='integration.test' AND entity_id=?").get(f.id)!;
  assert.deepEqual(JSON.parse(String(audit.details_json)),{outcome:'failed',scope:'access_only_no_generation',failureCode:code,...details});assert.equal(audit.request_id,body.error.requestId);
  const exposed=text+String(audit.details_json)+(await(await f.request('/api/admin/integrations')).text());
  for(const privateText of [secret,hostile,'private.example.invalid','<script>'])assert.ok(!exposed.includes(privateText));
  for(const table of ['api_reservations','ledger_events','ai_jobs','ai_workflows'])assert.equal(f.db.sqlite.prepare(`SELECT COUNT(*) count FROM ${table}`).get()!.count,0);
 }finally{f.db.close();}
});

test('a passed model access probe records only read access and is enough to enable the configuration',async t=>{
 const f=await fixture();try{
  let calls=0;
  t.mock.method(globalThis,'fetch',async()=>{calls++;return Response.json({id:model,private:hostile});});
  const response=await f.request('/api/admin/integrations/'+f.id+'/test','POST',{});
  assert.equal(response.status,200);assert.deepEqual((await response.json() as any).data,{tested:true,scope:'access_only',billableGenerationTested:false});assert.equal(calls,1);
  assert.deepEqual({...f.db.sqlite.prepare('SELECT status,test_status FROM integration_configs WHERE id=?').get(f.id)},{status:'tested',test_status:'passed'});
  const activation=await f.request('/api/admin/integrations/'+f.id+'/activate','POST',{});
  assert.equal(activation.status,200);assert.deepEqual((await activation.json() as any).data,{active:true});assert.equal(calls,1);
  const audit=f.db.sqlite.prepare("SELECT details_json FROM audit_logs WHERE action='integration.test' AND entity_id=?").get(f.id)!;
  assert.deepEqual(JSON.parse(String(audit.details_json)),{outcome:'passed',scope:'access_only_no_generation'});
 }finally{f.db.close();}
});

test('listing providers use one GET and require the exact selected model, without fallback',async()=>{
 for(const baseUrl of ['https://api.deepseek.com','https://api.moonshot.ai/v1']){
  const calls:string[]=[];
  const fetcher:typeof fetch=async(url,init)=>{calls.push(String(url));assert.equal(init?.method,'GET');return Response.json({data:[{id:model}]});};
  await probeModelAccess({...config,baseUrl,listing:true},secret,fetcher);assert.deepEqual(calls,[baseUrl+'/models']);
  await assert.rejects(()=>probeModelAccess({...config,baseUrl,listing:true},secret,async()=>Response.json({data:[{id:'different'}]})),error=>safeProbeFailure(error).code==='PROBE_MODEL_UNAVAILABLE');
 }
});

test('all redirects are refused without following their Location or reusing the credential',async()=>{
 for(const status of [301,302,303,304,307,308]){
  let calls=0;
  await assert.rejects(()=>probeModelAccess(config,secret,async(url,init)=>{
   calls++;assert.equal(String(url),config.baseUrl+'/models/'+model);assert.equal(init?.redirect,'manual');
   return new Response(null,{status,headers:{location:'https://private.example.invalid/collect'}});
  }),error=>{assert.equal(safeProbeFailure(error).code,'PROBE_RESPONSE_INVALID');assert.equal(safeProbeFailure(error).upstreamStatus,status);return true;});
  assert.equal(calls,1);
 }
});

test('bounded model responses reject missing bodies, malformed structures and oversized data',async()=>{
 for(const response of [new Response(null),Response.json([]),Response.json({}),new Response('x'.repeat(1024*1024+1))]){
  await assert.rejects(()=>probeModelAccess(config,secret,async()=>response),error=>safeProbeFailure(error).code==='PROBE_RESPONSE_INVALID');
 }
 await assert.rejects(()=>probeModelAccess({...config,listing:true},secret,async()=>Response.json({data:{id:model}})),error=>safeProbeFailure(error).code==='PROBE_RESPONSE_INVALID');
});

test('stream transport failures retain only safe network classification',async()=>{
 const stream=new ReadableStream<Uint8Array>({start(controller){controller.enqueue(new TextEncoder().encode('{'));controller.error(Object.assign(new Error(hostile),{code:'ECONNRESET'}));}});
 await assert.rejects(()=>probeModelAccess(config,secret,async()=>new Response(stream)),error=>{
  assert.deepEqual(safeProbeFailure(error),{code:'PROBE_NETWORK_ERROR',message:'服务器无法连接服务，请检查网络、代理和证书配置',networkReason:'CONNECTION'});return true;
 });
});

test('foreign errors cannot inject public or audit diagnostics even when they imitate probe codes',()=>{
 for(const error of [new AppError('PROBE_NETWORK_ERROR',hostile,503),{probeCode:'PROBE_ACCESS_DENIED',details:{networkReason:hostile}},new Error(hostile)]){
  assert.deepEqual(safeProbeFailure(error),{code:'PROBE_FAILED',message:'服务访问验证失败，请检查配置后重试'});
 }
});
