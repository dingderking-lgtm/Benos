import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac,createHash } from 'node:crypto';
import { Hono } from 'hono';
import { TestD1,testEnv } from './d1-helper';
import type { App } from '../src/lib/http';
import { AppError } from '../src/lib/errors';
import { encryptSecret,sha256 } from '../src/lib/crypto';
import { hostingManagementRoutes,reconcileDomainChange } from '../src/modules/hosting-management';
import { reconcileHostingEntitlements } from '../src/modules/hosting';
const time=()=>new Date().toISOString(),future=()=>new Date(Date.now()+86400000).toISOString();
const siteId='site_'+'3'.repeat(32),jobId='job_'+'4'.repeat(32),secret='fixture-connection-secret-that-is-not-a-real-credential';
const app=new Hono<App>();app.route('/api/hosting-management',hostingManagementRoutes);app.onError((error,c)=>c.json({error:{code:error instanceof AppError?error.code:'UNEXPECTED',message:error.message}},(error instanceof AppError?error.status:500) as 400));
async function fixture(){const db=new TestD1(),env=testEnv(db),token='t'.repeat(43),ownerToken='o'.repeat(43);
 for(const [id,role,t] of [['usr_customer','user',token],['usr_owner','owner',ownerToken]]){db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,'fixture',?,'active',?,?)").run(id,id+'@fixture.dev',id,role,time(),time());db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('ses_'+id,await sha256(t),id,'csrf',time(),future(),'test');}
 db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,'usr_customer','Website','old.fixture.dev','cms@fixture.dev','connected',?,?)").run(siteId,time(),time());
 db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,cms_version,last_verified_at,created_at,updated_at) VALUES('conn_fixture',?,'https://old.fixture.dev','site_key',?,'1.9.21',?,?,?)").run(siteId,await encryptSecret(secret,env.ENCRYPTION_KEY,siteId),time(),time(),time());
 db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES('ent_fixture','usr_customer',?,'annual',?,?,'active',?)").run(siteId,time(),future(),time());
 const call=async(path:string,method='GET',body?:unknown,owner=false)=>app.fetch(new Request(env.APP_ORIGIN+'/api/hosting-management'+path,{method,headers:{origin:env.APP_ORIGIN,cookie:'benos_session='+(owner?ownerToken:token),'x-csrf-token':'csrf','content-type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)}),env);
 return {db,env,call};}
function signed(request:Request,data:unknown,status=200){const raw=JSON.stringify(data),stamp=String(Math.floor(Date.now()/1000)),sig=createHmac('sha256',secret).update(['BENOS-CMS-V1-RESPONSE',request.headers.get('X-Benos-Nonce'),String(status),stamp,createHash('sha256').update(raw).digest('hex')].join('\n')).digest('base64url');return new Response(raw,{status,headers:{'X-Benos-Timestamp':stamp,'X-Benos-Signature':sig}});}
test('archived hosting connections reject DNS edits, including an archive between read and atomic update',async()=>{
 const f=await fixture();try{
  f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,test_status,created_by,created_at) VALUES('cfg_dns','hosting','Fixture','benos-bridge',1,'active','{}','passed','usr_owner',?)").run(time());
  f.db.sqlite.prepare("INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,state,max_sites,max_databases,created_at,updated_at) VALUES('pool_dns','Pool','u12345678',100,'cfg_dns','draining',10,10,?,?)").run(time(),time());
  const path='/pools/pool_dns/dns-targets',input={reason:'已核对原网站解析记录',records:[{type:'A',value:'8.8.8.8'}]};
  assert.equal((await f.call(path,'PUT',input,true)).status,200);const before=f.db.sqlite.prepare('SELECT * FROM hosting_pool_dns_targets').get(),audits=f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.dns_targets.confirmed'").get()!.n;
  const batch=f.db.batch.bind(f.db);f.db.batch=async statements=>{f.db.sqlite.prepare("UPDATE hosting_pools SET archived_at=?,archived_by='usr_owner',archive_reason='停止新分配' WHERE id='pool_dns'").run(time());return batch(statements);};
  assert.equal((await f.call(path,'PUT',{...input,records:[{type:'A',value:'1.1.1.1'}]},true)).status,409);
  assert.deepEqual(f.db.sqlite.prepare('SELECT * FROM hosting_pool_dns_targets').get(),before);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='hosting.dns_targets.confirmed'").get()!.n,audits);
  assert.equal((await f.call(path,'PUT',input,true)).status,409);assert.deepEqual((await (await f.call('/dns-targets','GET',undefined,true)).json() as any).data.items,[]);
 }finally{f.db.close();}
});
test('only owner explicitly pauses one site; annual rights and records survive, retries are idempotent and signed resume is required',async()=>{const f=await fixture(),original=fetch;let last:any;
 try{globalThis.fetch=async(value,init)=>{const req=new Request(value,init),body=await req.json() as any;last=body;return signed(req,{siteId,...body});};
  assert.equal((await f.call('/sites/'+siteId+'/pause','POST',{reason:'客户申请暂停',requestKey:'pause_key_001'})).status,403);
  let response=await f.call('/sites/'+siteId+'/pause','POST',{reason:'客户申请暂停',requestKey:'pause_key_001'},true);assert.equal(response.status,202);let info=(await response.json() as any).data;assert.equal(info.operation.effectivePaused,true);assert.equal(last.hostingActive,false);assert.equal(info.publicUrl,'https://old.fixture.dev');assert.equal(info.adminUrl,'https://old.fixture.dev/admin');
  assert.equal((await f.call('/sites/'+siteId+'/pause','POST',{reason:'客户申请暂停',requestKey:'pause_key_001'},true)).status,202);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_control_requests').get()!.n,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_entitlements').get()!.n,1);
  await reconcileHostingEntitlements(f.env);assert.equal(last.hostingActive,false,'cron must not undo manual hold');
  globalThis.fetch=async()=>new Response('{}');response=await f.call('/sites/'+siteId+'/resume','POST',{reason:'客户申请恢复',requestKey:'resume_key_001'},true);info=(await response.json() as any).data;assert.equal(info.operation.syncState,'uncertain');assert.equal(f.db.sqlite.prepare('SELECT state FROM sites').get()!.state,'suspended');
  globalThis.fetch=async(value,init)=>{const req=new Request(value,init),body=await req.json() as any;return signed(req,{siteId,...body});};await reconcileHostingEntitlements(f.env);assert.equal(f.db.sqlite.prepare('SELECT state FROM sites').get()!.state,'connected');
 }finally{globalThis.fetch=original;f.db.close();}});
test('domain request reserves a unique name and missing ownership never mutates provider or live domain',async()=>{const f=await fixture(),original=fetch;try{
 assert.equal((await f.call('/sites')).status,403);assert.equal((await f.call('/sites','GET',undefined,true)).status,200);
 const input={domain:'new.fixture.dev',reason:'客户升级品牌域名',requestKey:'domain_change_001'},result=await f.call('/sites/'+siteId+'/domain-changes','POST',input);assert.equal(result.status,202);const change=(await result.json() as any).data.domainChange;
 assert.equal(change.dnsRecords[0].name,'_benos-verification.new.fixture.dev');assert.equal((await f.call('/sites/'+siteId+'/domain-changes','POST',input)).status,202);assert.equal((await f.call('/sites/'+siteId+'/domain-changes','POST',{...input,domain:'different.fixture.dev'})).status,409);
 globalThis.fetch=async(value)=>{assert.match(String(value),/^https:\/\/cloudflare-dns.com\/dns-query/);return new Response(JSON.stringify({Status:0,Answer:[]}));};await reconcileDomainChange(f.env,change.id);assert.equal(f.db.sqlite.prepare('SELECT state FROM hosting_domain_changes').get()!.state,'awaiting_ownership');assert.equal(f.db.sqlite.prepare('SELECT domain FROM sites').get()!.domain,'old.fixture.dev');
 assert.throws(()=>f.db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES('another','usr_customer','Other','new.fixture.dev','cms@fixture.dev','pending',?,?)").run(time(),time()));
 assert.equal((await f.call('/sites/site_'+'f'.repeat(32))).status,404);
 }finally{globalThis.fetch=original;f.db.close();}});
test('lost alias response reconciles GET without duplicate provisioning and only signed CMS switch changes the canonical domain',async()=>{const f=await fixture(),original=fetch;let alias=false,posts=0,loseResponse=true;
 try{
 const config={adapter:'hostinger-hpanel',deploymentMode:'registered-php-bridge',accountUsername:'u12345678',hostingOrderId:100};
 f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('cfg_domain','hosting','Fixture','benos-bridge',1,'active',?,?,'passed','usr_owner',?)").run(JSON.stringify(config),await encryptSecret(JSON.stringify({hostingerApiToken:'fixture-long-provider-token'}),f.env.ENCRYPTION_KEY,'cfg_domain'),time());
 f.db.sqlite.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,state,step,idempotency_key,payload_hash,created_at,updated_at) VALUES(?,?,'usr_customer','create','succeeded','connected','fixture_job','fixture_hash',?,?)").run(jobId,siteId,time(),time());
 f.db.sqlite.prepare("INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,state,max_sites,max_databases,created_at,updated_at) VALUES('pool_domain','Pool','u12345678',100,'cfg_domain','accepting',10,10,?,?)").run(time(),time());
 f.db.sqlite.prepare("INSERT INTO hosting_allocations(job_id,site_id,pool_id,config_version_id,created_at) VALUES(?,?,'pool_domain','cfg_domain',?)").run(jobId,siteId,time());
 assert.equal((await f.call('/pools/pool_domain/dns-targets','PUT',{reason:'已核对解析记录',records:[{type:'A',value:'127.0.0.1'}]},true)).status,400);
 assert.equal((await f.call('/pools/pool_domain/dns-targets','PUT',{reason:'已核对解析记录',records:[{type:'A',value:'8.8.8.8'}]},true)).status,200);
 f.db.sqlite.prepare("INSERT INTO hosting_provider_intents(job_id,config_version_id,site_id,domain,account_username,hosting_order_id,database_name,database_user,database_secret_ciphertext,created_at,updated_at) VALUES(?,'cfg_domain',?,'old.fixture.dev','u12345678',100,'db_fixture','db_fixture','cipher_fixture',?,?)").run(jobId,siteId,time(),time());
 const response=await f.call('/sites/'+siteId+'/domain-changes','POST',{domain:'new.fixture.dev',reason:'客户升级品牌域名',requestKey:'domain_change_001'}),change=(await response.json() as any).data.domainChange;
 globalThis.fetch=async(value,init)=>{const req=new Request(value,init),url=new URL(req.url);if(url.hostname==='cloudflare-dns.com'){const type=url.searchParams.get('type');return new Response(JSON.stringify({Status:0,Answer:type==='TXT'?[{type:16,data:'"'+change.dnsRecords[0].value+'"'}]:type==='A'?[{type:1,data:'8.8.8.8'}]:[]}));}
 if(url.hostname==='developers.hostinger.com'){assert.ok(url.pathname.endsWith('/parked-domains'));if(req.method==='POST'){posts++;alias=true;throw new Error('lost response');}return new Response(JSON.stringify({data:alias?[{domain:'new.fixture.dev',username:'u12345678',parent_domain:'old.fixture.dev'}]:[]}));}
 if(url.pathname==='/benos-health.php')return signed(req,{siteId,installed:true,cmsVersion:'1.9.21'});
 const body=await req.json() as any;if(loseResponse)return new Response('{}');return signed(req,{siteId,changeId:body.changeId,origin:body.origin});};
 await reconcileDomainChange(f.env,change.id);assert.equal(posts,1);assert.equal(f.db.sqlite.prepare('SELECT domain FROM sites').get()!.domain,'old.fixture.dev');
 await reconcileDomainChange(f.env,change.id);assert.equal(posts,1);assert.equal(f.db.sqlite.prepare('SELECT domain FROM sites').get()!.domain,'old.fixture.dev');
 loseResponse=false;await reconcileDomainChange(f.env,change.id);assert.equal(posts,1);assert.equal(f.db.sqlite.prepare('SELECT domain FROM sites').get()!.domain,'new.fixture.dev');assert.equal(f.db.sqlite.prepare('SELECT origin FROM site_connections').get()!.origin,'https://new.fixture.dev');assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_domains').get()!.n,2);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_allocations').get()!.n,1);
 }finally{globalThis.fetch=original;f.db.close();}});
