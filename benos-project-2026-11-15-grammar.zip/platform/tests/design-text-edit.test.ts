import test from 'node:test';
import assert from 'node:assert/strict';
import { patchDesignText,annotateDesignHtml,assertDesignScope } from '../src/modules/design-nodes';

const manifest=()=>({site:{name:'站',home:'home',pages:[]},assets:[],templates:[{id:7,name:'首页',type:'page',document:{version:1,css:'',html:'<section><h1 class="t">旧标题<br>第二行</h1><p>正文 <strong>加粗</strong></p><a href="/contact">联系</a><p data-aacms="field">CMS 字段</p><p>{{title}}</p></section>'}}]});
const keyOf=(html:string,needle:string)=>{const at=annotateDesignHtml(html,7).split(needle)[0];return at.slice(at.lastIndexOf('data-benos-node="')+17).split('"')[0];};
test('the words of one plain text element are replaced, escaped, and nothing else changes',()=>{
 const base=manifest(),html=base.templates[0].document.html,scope={kind:'node' as const,templateId:7,nodeKey:keyOf(html,'>旧标题')};
 const next=patchDesignText(base,scope,'  新标题 <b>&\n第二行  ') as any;
 assert.equal(next.templates[0].document.html,html.replace('旧标题<br>第二行','新标题 &lt;b&gt;&amp;<br>第二行'));
 assert.equal(base.templates[0].document.html,html,'the source design is not modified');
 assertDesignScope(base,next,scope);
 // A link keeps its address: only its words change.
 const link={kind:'node' as const,templateId:7,nodeKey:keyOf(html,'>联系')};
 assert.match((patchDesignText(base,link,'联系我们') as any).templates[0].document.html,/<a href="\/contact">联系我们<\/a>/);
});
test('markup, CMS fields, placeholders and empty text are refused',()=>{
 const base=manifest(),html=base.templates[0].document.html,scope=(needle:string)=>({kind:'node' as const,templateId:7,nodeKey:keyOf(html,needle)});
 assert.throws(()=>patchDesignText(base,scope('>正文'),'x'),/具体的一段文字/);
 assert.throws(()=>patchDesignText(base,scope('><h1'),'x'),/CMS|具体的一段文字/);
 assert.throws(()=>patchDesignText(base,scope('>CMS 字段'),'x'),/CMS/);
 assert.throws(()=>patchDesignText(base,scope('>{{title}}'),'x'),/CMS/);
 assert.throws(()=>patchDesignText(base,scope('>旧标题'),'   '),/不能为空/);
 assert.throws(()=>patchDesignText(base,{kind:'node',templateId:7,nodeKey:'n999'},'x'),/重新选择/);
});
test('text with inline emphasis keeps its emphasised elements and replaces only the words around and inside them',async()=>{
 const { patchDesignInlineText }=await import('../src/modules/design-nodes');
 const base={site:{name:'站',home:'home',pages:[]},assets:[],templates:[{id:7,name:'首页',type:'page',document:{version:1,css:'',html:'<h1 class="hero">让废塑料，<br>进入<span class="accent" style="color:#c8432b">下一次循环。</span></h1><p>文 <a href="/x">链接</a></p>'}}]};
 const html=base.templates[0].document.html,scope={kind:'node' as const,templateId:7,nodeKey:keyOf(html,'>让废塑料')};
 const next=patchDesignInlineText(base,scope,{slots:['让旧塑料 <再>，\n开始','。'],children:['新的循环']}) as any;
 assert.equal(next.templates[0].document.html,'<h1 class="hero">让旧塑料 &lt;再&gt;，<br>开始<span class="accent" style="color:#c8432b">新的循环</span>。</h1><p>文 <a href="/x">链接</a></p>');
 assertDesignScope(base,next,scope);
 assert.throws(()=>patchDesignInlineText(base,scope,{slots:['a','b','c'],children:['x','y']}),/不能增减/);
 assert.throws(()=>patchDesignInlineText(base,scope,{slots:[' ',''],children:['']}),/不能为空/);
 // A link is not inline emphasis: its address must never be reachable through a text edit.
 assert.throws(()=>patchDesignInlineText(base,{kind:'node',templateId:7,nodeKey:keyOf(html,'>文 ')},{slots:['a','b'],children:['x']}),/交给 AI/);
});
