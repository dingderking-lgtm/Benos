import test from 'node:test';
import assert from 'node:assert/strict';
import fixture from './fixtures/design-coherence-tech.json';
import { diagnoseDesignCoherence, filterExplicitCoherenceIntent, designCoherenceFeedback, type DesignCoherenceCode } from '../src/modules/design-coherence';
import { createDesignFoundation, foundationAuthoringManifest, materializeDesignFoundation } from '../src/contracts/design-foundation';
import { DESIGN_STYLES } from '../src/contracts/design-style-catalog';

const make = (html: string, css = '', key = 'home') => ({
  site: { home: key, pages: [{ key, template_id: 1 }], theme: { global_css: css } },
  templates: [{ id: 1, type: 'page', name: '首页', document: { html, css: '' } }],
});
const codes = (input: unknown) => diagnoseDesignCoherence(input).diagnostics.map(d => d.code);
const has = (input: unknown, code: DesignCoherenceCode) => codes(input).includes(code);
const item = (name = '实际问题') => `<div><h3>${name}</h3><p>把相关的资料与具体使用背景放在一起，保留来源和讨论时的上下文，让后来阅读的人知道这份信息的用途。</p></div>`;
const listSection = (id: string, extra = '') => `<section id="${id}"><h2>清楚了解 ${id} 的工作</h2><p>以下内容解释团队在实际工作中常见的问题，以及整理这些资料时需要保留的信息。</p>${item('起点')}${item('过程')}${item('结果')}${extra}</section>`;
const three = listSection('one') + listSection('two') + listSection('three');
const bands = '<section id="one"><h2>起点</h2></section><section id="two" class="light"><h2>过程</h2></section><section id="three"><h2>结果</h2></section>';
const darkLight = 'body{background:#101010}.light{background:#f5f5f5}';
const legalSection = `<section id="boundary"><div class="padded"><p>概念边界</p><h2>不是功能承诺</h2><p>这是产品概念展示。我们仅用于表达整理资料的设计思路，并非可使用的软件服务；它不是可供团队真实工作使用的产品。</p><p>流程是设想，不是操作演示。页面未提供文件上传、数据存储、自动分类或搜索能力，也不代表这些能力已经实现。</p><p>图像用于表达，不作为产品证据。生成式概念配图不是产品截图、客户记录或真实使用案例，请勿据此判断实际服务能力。</p></div></section>`;
const withBoundary = (css = '.padded{padding-block:64px}') => make('<section><h1>首页</h1></section>' + legalSection + '<section><h2>下一步阅读</h2></section>', css);

test('actual Flowbeam candidate yields three evidence-based advisories with exact parse5 locations', () => {
  const before = JSON.stringify(fixture), report = diagnoseDesignCoherence(fixture);
  assert.deepEqual(report.diagnostics.map(d => d.code), ['repeated_heading_list_sections', 'oversized_disclaimer_section', 'alternating_section_backgrounds']);
  assert.deepEqual(report.coverage, { templates: 1, sections: 6, cssSkipped: 0, truncated: false });
  assert.deepEqual(report.diagnostics[0].locations.map(l => l.sectionId), ['problems', 'method', 'scenarios']);
  assert.equal(report.diagnostics[1].locations[0].sectionId, 'boundary');
  assert.match(report.diagnostics[1].evidence[1], /112px/);
  assert.match(report.diagnostics[2].evidence[0], /#0b1020 → #eaf0f4 → #0b1020/);
  for (const d of report.diagnostics) {
    assert.equal(d.severity, 'advisory');
    for (const location of d.locations) {
      assert.match(fixture.templates[0].document.html.slice(location.startOffset, location.endOffset), new RegExp(`^<section id="${location.sectionId}"`));
      assert.equal(location.templateId, 1); assert.equal(location.pageKey, 'home');
    }
  }
  assert.equal(JSON.stringify(fixture), before, 'review cannot rewrite a draft');
  assert.deepEqual(diagnoseDesignCoherence(fixture), report, 'deterministic without network or browser state');
});

test('new materialized foundation retains all three checks despite unused/local pseudo-elements and bridge primitives', () => {
  const profile = createDesignFoundation(DESIGN_STYLES.find(s => s.id === 'tech')!);
  const current = materializeDesignFoundation(foundationAuthoringManifest(structuredClone(fixture), profile), profile);
  assert.match(current.site.theme.global_css, /benos-coherence:1/);
  const expected = ['repeated_heading_list_sections', 'oversized_disclaimer_section', 'alternating_section_backgrounds'];
  assert.deepEqual(codes(current), expected);
  assert.equal(diagnoseDesignCoherence(current).coverage.cssSkipped, 0);
  current.templates[0].document.html = current.templates[0].document.html.replace('class="fb-flow"', 'class="fb-flow bnf-sequence"');
  assert.deepEqual(codes(current), expected, 'bounded step numbers and connectors do not cover the section');
  current.templates[0].document.html = current.templates[0].document.html.replace('class="fb-light"', 'class="fb-light bnf-bridge"');
  current.templates[0].document.css = '.bnf-bridge{background:linear-gradient(#111,#fff)}';
  assert.ok(!has(current, 'alternating_section_backgrounds'), 'an actual gradient on the target band remains unknown');
  assert.ok(has(current, 'oversized_disclaimer_section'), 'unrelated gradient does not invalidate known disclaimer spacing');
});

test('responsive hiding in header/footer subtrees does not erase body color or disclaimer evidence', () => {
  const input: any = structuredClone(fixture), before = codes(input);
  input.site.header_template_id = 901; input.site.footer_template_id = 902;
  input.templates.push({ id: 901, type: 'header', document: { html: '<header class="brand-shell"><nav class="desktop-links"><a href="/">首页</a></nav></header>', css: '@media(max-width:960px){.brand-shell .desktop-links{display:none!important}}' } });
  input.templates.push({ id: 902, type: 'footer', document: { html: '<footer><nav class="footer-links"><a href="/">首页</a></nav></footer>', css: '@media(max-width:640px){footer .footer-links{visibility:hidden}}' } });
  const serialized = JSON.stringify(input), report = diagnoseDesignCoherence(input);
  assert.deepEqual(report.diagnostics.map(d => d.code), before);
  assert.equal(report.coverage.cssSkipped, 0);
  assert.equal(JSON.stringify(input), serialized, 'the proof neither strips CSS nor changes the candidate');
});

test('responsive hiding still abstains when chrome classes actually match body content or its ancestors', () => {
  const cases = [
    { html: bands.replace('class="light"', 'class="light bnf-chrome-desktop"'), rule: '.bnf-chrome-desktop{display:none}' },
    { html: '<main class="bnf-site-header">' + bands.replace('class="light"', 'class="light bnf-chrome-desktop"') + '</main>', rule: '.bnf-site-header .bnf-chrome-desktop{display:none}' },
    { html: '<main class="bnf-site-header">' + bands + '</main>', rule: '.bnf-site-header{visibility:hidden}' },
    { html: bands, rule: '.missing-header, .light{display:NONE!important}' },
    { html: bands, rule: 'body{display:none}' },
  ];
  for (const { html, rule } of cases) {
    const report = diagnoseDesignCoherence(make(html, darkLight + '@media(max-width:960px){' + rule + '}'));
    assert.equal(report.coverage.cssSkipped, 1, rule);
    assert.ok(!report.diagnostics.some(d => d.code === 'alternating_section_backgrounds'), rule);
  }
});

test('unknown or cross-subtree responsive hiding cannot be excused by a chrome marker or an absent prefix', () => {
  const rules = [
    'header + section{display:none}',
    '.bnf-site-header ~ .light{display:none}',
    ':where(.bnf-site-header,.light){display:none}',
    '[data-chrome]{display:none}',
    '.light:hover{display:none}',
    '.missing::before, .light[data-visible]{visibility:hidden}',
    '.missing :is(.one + .light){display:none}',
    '@supports(display:grid){.missing-header{display:none}}',
  ];
  for (const rule of rules) {
    const report = diagnoseDesignCoherence(make(bands, darkLight + '/* benos-site-chrome:bnc-1 */@media(max-width:960px){' + rule + '}'));
    assert.equal(report.coverage.cssSkipped, 1, rule);
  }
  for (const rule of ['.missing-header{background:#fff}', '.light{--band:#fff}']) {
    assert.equal(diagnoseDesignCoherence(make(bands, darkLight + '@media(max-width:960px){' + rule + '}')).coverage.cssSkipped, 1, 'the existing conditional paint/variable boundary remains unchanged');
  }
  for (const extra of ['@keyframes disappear{from{display:none}to{display:block}}', '@supports(display:grid){.missing-header{display:none}}']) {
    assert.equal(diagnoseDesignCoherence(make(bands, darkLight + extra)).coverage.cssSkipped, 1, 'only media rule selectors receive the visibility proof; keyframe names are not HTML tags');
  }
});

test('unused responsive media variables preserve body diagnostics without trusting a foundation marker', () => {
  const expected = codes(make(bands, darkLight));
  for (const rules of [
    '.bnf-hero-cover{--bnf-hero-cover-height:56vh}',
    '.absent-media > .frame{--media-height:56vh}.light{padding:12px}',
    '.missing-one,.missing-two{--band:#fff}',
  ]) {
    const input = make(bands, darkLight + '@media(max-width:640px){' + rules + '}'), before = JSON.stringify(input);
    assert.deepEqual(codes(input), expected, rules);
    assert.equal(diagnoseDesignCoherence(input).coverage.cssSkipped, 0, rules);
    assert.equal(JSON.stringify(input), before);
  }
});

test('conditional variables on real nodes, ancestors, mixed or unknown selectors still abstain', () => {
  for (const rules of [
    '.light{--band:#000}', 'body{--band:#000}', 'html{--band:#000}',
    '.missing,.light{--band:#000}', '.missing + .light{--band:#000}',
    ':where(.missing){--band:#000}', '.missing:hover{--band:#000}',
    '.missing{--band:#000}@supports(display:grid){.light{--band:#fff}}',
    '.missing{--band:#000}.light{background:#000}',
    '.missing{--band:#000}.light{display:none}',
  ]) {
    const report = diagnoseDesignCoherence(make(bands, darkLight + '/* benos-hero-cover:1 */@media(max-width:640px){' + rules + '}'));
    assert.equal(report.coverage.cssSkipped, 1, rules);
    assert.ok(!report.diagnostics.some(d => d.code === 'alternating_section_backgrounds'), rules);
  }
  const actual = bands.replace('class="light"', 'class="light bnf-hero-cover"');
  assert.equal(diagnoseDesignCoherence(make(actual, darkLight + '@media(max-width:640px){.bnf-hero-cover{--media-height:56vh}}')).coverage.cssSkipped, 1);
  const ancestor = '<main class="bnf-hero-cover">' + bands + '</main>';
  assert.equal(diagnoseDesignCoherence(make(ancestor, darkLight + '@media(max-width:640px){.bnf-hero-cover{--band:#fff}}')).coverage.cssSkipped, 1);
});

test('only a run of at least three substantial heading/list sections creates a repeated-structure advisory', () => {
  assert.ok(has(make(three), 'repeated_heading_list_sections'));
  assert.ok(!has(make(listSection('one') + listSection('two')), 'repeated_heading_list_sections'));
  const breakSection = '<section><h2>另一种内容</h2><blockquote>一段独立的观察</blockquote></section>';
  assert.ok(!has(make(listSection('one') + listSection('two') + breakSection + listSection('three')), 'repeated_heading_list_sections'));
  assert.ok(!has(make('<section><h2>说明</h2><ul><li>短</li><li>短</li><li>短</li></ul></section>'.repeat(3)), 'repeated_heading_list_sections'));
});

test('nested sections, inert examples, navigation, and hidden content do not become separate chapters', () => {
  for (const wrapper of ['<template>', '<nav>', '<div hidden>', '<div aria-hidden="true">', '<div style="display:none">']) {
    const tag = wrapper.match(/^<([a-z]+)/)![1]; assert.deepEqual(codes(make(wrapper + three + `</${tag}>`)), []);
  }
  assert.ok(!has(make(`<section><h2>一个章节</h2>${three}</section>`), 'repeated_heading_list_sections'));
  assert.ok(!has(make(`<div class="off">${three}</div>`, '.off{display:none}'), 'repeated_heading_list_sections'));
});

test('functional tables, forms, FAQ controls, and image-led item grids are not reduced to a text-list pattern', () => {
  for (const extra of ['<form><input></form>', '<table><tr><td>资料</td></tr></table>', '<details><summary>问题</summary>解答</details>']) {
    assert.ok(!has(make(listSection('one', extra) + listSection('two', extra) + listSection('three', extra)), 'repeated_heading_list_sections'));
  }
  const cards = three.replaceAll('<h3>', '<img src="/image.png" alt="具体物件"><h3>');
  assert.ok(!has(make(cards), 'repeated_heading_list_sections'));
});

test('a disclaimer needs dominant limiting copy, its own chapter, and declared large spacing', () => {
  assert.ok(has(withBoundary(), 'oversized_disclaimer_section'));
  assert.ok(!has(withBoundary('.padded{padding-block:16px}'), 'oversized_disclaimer_section'));
  assert.ok(!has(withBoundary(''), 'oversized_disclaimer_section'), 'no inferred pixel size');
  assert.ok(!has(make(legalSection, '.padded{padding:64px}'), 'oversized_disclaimer_section'), 'a dedicated one-section page is not a landing-page interruption');
  const brief = withBoundary(); brief.templates[0].document.html = brief.templates[0].document.html.replace(legalSection, '<section><h2>概念说明</h2><p>页面用于概念展示。</p></section>');
  assert.ok(!has(brief, 'oversized_disclaimer_section'));
});

test('legal/privacy pages and substantial functional content are preserved', () => {
  const privacy = withBoundary(); privacy.templates[0].document.html = privacy.templates[0].document.html.replace('概念边界', '隐私与法律声明');
  assert.ok(!has(privacy, 'oversized_disclaimer_section'));
  const dedicated = withBoundary(); dedicated.site.pages[0].key = 'privacy';
  assert.ok(!has(dedicated, 'oversized_disclaimer_section'));
  const functional = withBoundary(); functional.templates[0].document.html = functional.templates[0].document.html.replace('</section>', '<form><label>资料名称<input name="title"></label></form></section>').replace(legalSection, legalSection.replace('</section>', '<form><input name="query"></form></section>'));
  assert.ok(!has(functional, 'oversized_disclaimer_section'));
});

test('plain opaque CSS recognizes a complete dark/light/dark triplet, never one contrast or low contrast', () => {
  assert.ok(has(make(bands, darkLight), 'alternating_section_backgrounds'));
  assert.ok(!has(make(bands.slice(0, bands.lastIndexOf('<section')), darkLight), 'alternating_section_backgrounds'));
  assert.ok(!has(make(bands, 'body{background:#303030}.light{background:#555}'), 'alternating_section_backgrounds'));
  assert.ok(!has(make(bands, '.light{background:white}'), 'alternating_section_backgrounds'), 'no assumed canvas background');
  assert.ok(!has(make(bands, darkLight + '.light{max-width:700px}'), 'alternating_section_backgrounds'), 'a local panel is not a full-width band');
});

test('CSS variables, specificity, importance, descendants, child selectors and shorthand resets are respected', () => {
  const css = ':root{--paper:#fff;--ink:#111}body{background:var(--ink)}body > section.light{background:var(--paper)}.light{background:#111}';
  assert.ok(has(make(bands, css), 'alternating_section_backgrounds'));
  assert.ok(!has(make(bands, css + '.light{background:#111!important}'), 'alternating_section_backgrounds'));
  assert.ok(!has(make(bands, css + '#two{background-color:#111}'), 'alternating_section_backgrounds'));
  assert.ok(has(make(bands, ':root{--Ink:#111;--Paper:#fff}body{background:var(--Ink)}.light{background:var(--Paper)}'), 'alternating_section_backgrounds'));
  assert.ok(!has(make(bands, ':root{--alias:var(--base);--base:#111}body{background:var(--alias)}.light{--base:#fff;background:var(--alias)}'), 'alternating_section_backgrounds'), 'inherited custom-property aliases are computed before inheritance');
});

test('gradients, images, translucent paint, complex conditions and unsupported paint selectors abstain', () => {
  const uncertain = [
    darkLight + '.light{background:linear-gradient(#fff,#ddd)}',
    darkLight + '.light{background-image:url("/image.jpg")}',
    darkLight + '.light{background:rgba(255,255,255,.8)}',
    darkLight + '.light{background:linear-gradient(#fff,#ddd);background-color:#fff}',
    darkLight + '@media(max-width:600px){.light{background:#111}}',
    darkLight + '@supports(display:grid){.light{background:#111}}',
    darkLight + '.light::before{background:#111}',
    darkLight + '[data-band]{background:#111}',
    darkLight + '.light{opacity:.5}',
    darkLight + '.light{background:var(--unknown)}',
    darkLight + '@import "/theme.css";',
  ];
  for (const css of uncertain) assert.ok(!has(make(bands, css), 'alternating_section_backgrounds'), css);
  assert.ok(!has(make(`<main class="blend">${bands}</main>`, darkLight + '.blend{opacity:.5}'), 'alternating_section_backgrounds'));
  assert.ok(has(make(bands, darkLight + '.button:hover{filter:brightness(.9)}@media(max-width:640px){.links{display:flex}}'), 'alternating_section_backgrounds'), 'irrelevant base-state controls do not erase reliable background evidence');
});

test('selected page CSS follows the real preview order including header and footer; unrelated templates cannot interfere', () => {
  const input: any = make(bands, darkLight);
  input.site.header_template_id = 2; input.site.footer_template_id = 3;
  input.templates.push({ id: 2, type: 'header', document: { html: '<header></header>', css: '.light{background:#111}' } });
  input.templates[0].document.css = '.light{background:white}';
  assert.ok(has(input, 'alternating_section_backgrounds'), 'page CSS comes after header CSS');
  input.templates.push({ id: 3, type: 'footer', document: { html: '<footer></footer>', css: '.light{background:#111}' } });
  assert.ok(!has(input, 'alternating_section_backgrounds'), 'footer CSS comes last');
  input.templates[2].document.css = ''; input.templates.push({ id: 9, type: 'page', document: { html: '<h1>别的页面</h1>', css: '.light{background:#111}' } });
  assert.ok(has(input, 'alternating_section_backgrounds'), 'unselected page CSS is not loaded by preview');
  assert.equal(diagnoseDesignCoherence(input, { pageKey: 'missing' }).coverage.templates, 0);
});

test('an abstract image or its alt text cannot become an aesthetic or factual image diagnosis', () => {
  const input = make('<section><h1>新想法</h1><img src="/abstract.png" alt="抽象几何、光线和概念空间"></section>');
  assert.deepEqual(codes(input), []);
});

test('explicit positive user/style intent suppresses only its corresponding advisory', () => {
  const diagnostics = diagnoseDesignCoherence(fixture).diagnostics;
  assert.deepEqual(filterExplicitCoherenceIntent(diagnostics, '用深空蓝黑、浅色文字、电光青蓝、有节制的明暗章节形成精致产品发布感。').map(d => d.code), ['repeated_heading_list_sections', 'oversized_disclaimer_section']);
  assert.deepEqual(filterExplicitCoherenceIntent(diagnostics, '让概念边界作为单独的大区；每个章节都采用三项列表。').map(d => d.code), ['alternating_section_backgrounds']);
  assert.deepEqual(filterExplicitCoherenceIntent(diagnostics, 'Use alternating dark and light sections. Keep a separate disclaimer. Each section uses a three items list.').map(d => d.code), []);
  assert.equal(filterExplicitCoherenceIntent(diagnostics, '科技风格，概念边界清楚。列出工作方式。').length, 3, 'generic style words or boundary copy are not explicit large-structure requests');
});

test('negation is not mistaken for an explicit request to retain the reported pattern', () => {
  const diagnostics = diagnoseDesignCoherence(fixture).diagnostics;
  for (const text of ['不要使用明暗章节。', '避免黑白切换；不要把概念边界做成独立大区；不要每个章节都是三项列表。', 'Do not use alternating dark and light sections. Avoid separate disclaimer sections.']) {
    assert.equal(filterExplicitCoherenceIntent(diagnostics, text).length, 3, text);
  }
  assert.equal(filterExplicitCoherenceIntent(diagnostics, '不要玻璃卡片，保留明暗章节。').length, 2, 'independent positive clauses still count');
});

test('model feedback is actionable, bounded to 3000 characters, and no score or mandatory rejection is invented', () => {
  const diagnostics = diagnoseDesignCoherence(fixture).diagnostics, feedback = designCoherenceFeedback(diagnostics);
  assert.ok(feedback.length > 400 && feedback.length <= 3000);
  assert.match(feedback, /模板1\/home第2节#problems/); assert.match(feedback, /advisory/); assert.match(feedback, /不编造/);
  assert.ok(designCoherenceFeedback(Array(50).fill(diagnostics[0])).length <= 3000);
  assert.equal(designCoherenceFeedback([]), '');
});

test('malformed, oversized, deeply nested and many-page inputs stay bounded instead of breaking generation', () => {
  for (const input of [null, {}, { templates: null }, { site: null }]) assert.deepEqual(codes(input), []);
  assert.equal(diagnoseDesignCoherence(make('x'.repeat(750_001))).coverage.truncated, true);
  const deep = make('<div>'.repeat(140) + three + '</div>'.repeat(140));
  assert.equal(diagnoseDesignCoherence(deep).coverage.truncated, true);
  const invalid = make('<section><h2>起点</h2><p>缺少结束标签'); assert.doesNotThrow(() => diagnoseDesignCoherence(invalid));
  const large = make(Array.from({ length: 1000 }, (_, i) => `<div><h3>内容 ${i}</h3><p>具体解释这一项实际内容。</p></div>`).join(''));
  assert.doesNotThrow(() => diagnoseDesignCoherence(large));
  const nestedCss = '@media(max-width:640px){'.repeat(2000) + '.missing-header{display:none}' + '}'.repeat(2000);
  const nestedReport = diagnoseDesignCoherence(make(bands, darkLight + nestedCss));
  assert.equal(nestedReport.coverage.cssSkipped, 1, 'visibility probes stop after one level instead of recursively evaluating nested conditions');
  assert.equal(nestedReport.coverage.mobileSizingSkipped, 1, 'the pre-existing mobile parser depth limit is retained');
});


// Reduced from actual candidate_5d24f0557ec9436197eec4789f5b0ec7. The original
// mobile declaration produced a 508.39px content panel in a 358px grid track.
const content = `<div class="flow-map"><div class="flow-map-top"><strong>上下文归位图</strong><span>01 / 入职指南</span></div><div class="flow-sources"><span>会议记录</span><span>参考链接</span><span>未完草稿</span></div><article class="flow-dossier"><p>同一个主题 · 同一份脉络</p><h2>新成员入职指南</h2><p>01　开始之前 <span>准备事项</span></p><p>02　第一天 <span>认识团队</span></p><p>03　第一周 <span>建立节奏</span></p></article><p>资料不只被放到一起，它们共同指向一个可以继续整理的主题，并保留每条线索的来路。</p></div>`;
const css = `.flow-hero{display:grid;grid-template-columns:1fr 1fr}.flow-map{position:relative;aspect-ratio:620/500;overflow:hidden;display:flex;flex-direction:column;padding:26px}@media(max-width:1000px){.flow-map{padding:18px;aspect-ratio:auto;min-height:410px}}@media(max-width:700px){.flow-hero{grid-template-columns:1fr}.flow-map{min-height:410px;aspect-ratio:620/500}}`;
const candidate = (extra = '', html = content) => ({ site: { home: 'home', pages: [{ key: 'home', template_id: 1 }], theme: { global_css: css + extra } }, templates: [{ id: 1, type: 'page', document: { html: '<section id="intro" class="bnf-container flow-hero"><h1>让资料归位，让思路继续。</h1>' + html + '</section>', css: '' } }] });
const risks = (input: unknown) => diagnoseDesignCoherence(input).diagnostics.filter(d => d.code === 'mobile_ratio_min_height_risk');

test('actual mobile ratio/min-height combination yields one located advisory, not a claimed pixel measurement', () => {
  const input = candidate(), before = JSON.stringify(input), result = risks(input);
  assert.equal(result.length, 1); assert.equal(result[0].severity, 'advisory'); assert.equal(result[0].locations[0].sectionId, 'intro');
  assert.match(result[0].evidence[0], /\.flow-map/); assert.match(result[0].evidence[0], /390px/); assert.match(result[0].evidence[0], /508px/); assert.match(result[0].evidence[0], /未测量实际溢出/);
  assert.equal(JSON.stringify(input), before);
});

test('new foundation chrome keeps the existing mobile text-panel risk observable', () => {
  const profile = createDesignFoundation(DESIGN_STYLES.find(s => s.id === 'tech')!);
  const input = materializeDesignFoundation(candidate(), profile), report = diagnoseDesignCoherence(input);
  assert.match(input.site.theme.global_css, /benos-site-chrome:bnc-1/);
  assert.equal(report.coverage.mobileSizingSkipped ?? 0, 0);
  assert.deepEqual(risks(input), risks(candidate()), 'unrelated chrome selectors do not change mobile evidence or locations');
});

test('mobile unknown descendants may be ignored only behind an absent, known subtree origin', () => {
  const isolated = [
    '.unused-navigation :where(ul,ol){max-width:100%}',
    '.unused-navigation .submenu[open]>.links{display:grid;width:100%}',
    ':where(.unused-header,.unused-footer) :where(a,button){max-width:100%}',
    ':is(header,footer) [data-size]{max-width:100%}',
    '@media(max-width:700px){.unused-navigation .submenu:not([hidden]){width:100%}}',
  ];
  for (const extra of isolated) {
    const report = diagnoseDesignCoherence(candidate(extra));
    assert.equal(report.coverage.mobileSizingSkipped ?? 0, 0, extra);
    assert.equal(report.diagnostics.filter(d => d.code === 'mobile_ratio_min_height_risk').length, 1, extra);
  }
});

test('mobile sizing remains unknown for matching chrome origins, mixed lists, sibling reach and unknown first compounds', () => {
  const uncertain = [
    '.flow-map :where(p,article){width:100%}',
    ':where(.unused-header,.flow-map) :where(p,article){width:100%}',
    '.unused-header + .flow-map{max-width:100%}',
    '.unused-header ~ .flow-map{max-width:100%}',
    '.unused-header :is(.one + .flow-map){max-width:100%}',
    '[data-header] .flow-map{max-width:100%}',
    ':where(.unused-header,[data-header]) .flow-map{max-width:100%}',
    '.unused-header [data-size], .flow-map[data-size]{max-width:100%}',
    '.unused\\-header .flow-map{max-width:100%}',
  ];
  for (const extra of uncertain) {
    const report = diagnoseDesignCoherence(candidate(extra));
    assert.equal(report.coverage.mobileSizingSkipped, 1, extra);
    assert.equal(report.diagnostics.filter(d => d.code === 'mobile_ratio_min_height_risk').length, 0, extra);
  }
  const input = candidate('.bnf-site-header :where(.flow-map){max-width:100%}');
  input.templates[0].document.html = input.templates[0].document.html.replace('class="bnf-container flow-hero"', 'class="bnf-container flow-hero bnf-site-header"');
  assert.equal(diagnoseDesignCoherence(input).coverage.mobileSizingSkipped, 1, 'a chrome class used on a real section is not trusted as site chrome');
});

test('mobile ratio:auto, minimum-height reset, and explicit width containment clear the advisory', () => {
  for (const declaration of ['aspect-ratio:auto', 'min-height:0', 'min-height:0px', 'max-width:100%', 'width:100%', 'max-inline-size:100%']) {
    assert.equal(risks(candidate(`@media(max-width:700px){.flow-map{${declaration}}}`)).length, 0, declaration);
  }
  assert.equal(risks(candidate('.flow-map{aspect-ratio:auto!important}')).length, 0);
  assert.equal(risks(candidate('', content.replace('class="flow-map"', 'class="flow-map" style="aspect-ratio:auto"'))).length, 0);
});

test('desktop declarations and inactive print media are not mistaken for mobile resets', () => {
  assert.equal(risks(candidate('@media(min-width:1000px){.flow-map{aspect-ratio:auto}}')).length, 1);
  assert.equal(risks(candidate('@media print{.flow-map{aspect-ratio:auto}}')).length, 1);
  assert.equal(risks(candidate('@media screen and (max-width:700px){.flow-map{aspect-ratio:auto}}')).length, 0);
  assert.equal(risks(candidate('@media(min-width:300px) and (max-width:700px){.flow-map{aspect-ratio:auto}}')).length, 0);
});

test('unsupported responsive sizing conditions abstain rather than assert a width outcome', () => {
  const report = diagnoseDesignCoherence(candidate('@media(orientation:portrait){.flow-map{aspect-ratio:auto}}'));
  assert.equal(report.coverage.mobileSizingSkipped, 1); assert.equal(report.diagnostics.filter(d => d.code === 'mobile_ratio_min_height_risk').length, 0);
  assert.equal(risks(candidate('[data-size]{max-width:100%}')).length, 0);
});

test('image/media frames, figures, scrollable tables and deliberately horizontally scrolling compositions remain allowed', () => {
  assert.equal(risks(candidate('', content.replace('<article', '<img src="/photo.png" width="1240" height="1000" alt="真实画面"><article'))).length, 0);
  assert.equal(risks(candidate('', '<figure>' + content + '</figure>')).length, 0);
  assert.equal(risks(candidate('', content.replace('<article', '<table><tr><td>完整规格表</td></tr></table><article'))).length, 0);
  assert.equal(risks(candidate('.flow-map{overflow-x:auto}')).length, 0);
  assert.equal(risks(candidate('.flow-hero{overflow-x:scroll}')).length, 0);
  assert.equal(risks(candidate('', content.replace(/<article[\s\S]*<\/article>/, ''))).length, 0, 'short decorative compositions are outside the text-panel rule');
});

test('the rule is independent of unrelated unknown painting and respects intentional mobile horizontal layouts', () => {
  const report = diagnoseDesignCoherence(candidate('.flow-map:before{content:"";width:22px;background:#333}'));
  assert.equal(report.coverage.cssSkipped, 1); assert.equal(report.diagnostics.filter(d => d.code === 'mobile_ratio_min_height_risk').length, 1);
  const diagnostic = risks(candidate());
  assert.equal(filterExplicitCoherenceIntent(diagnostic, '手机保留横向画布，允许自由构图。').length, 0);
  assert.equal(filterExplicitCoherenceIntent(diagnostic, '不要手机横向滑动。').length, 1);
});
