import test from 'node:test';
import assert from 'node:assert/strict';
import { DESIGN_STYLES,getDesignStyle } from '../src/contracts/design-style-catalog';
import { foundationContrast,foundationSurfaces,foundationTextColors,readableAccentText,TEXT_COLOR_MARKER,designTextColorCss } from '../src/contracts/design-coherence';
import { createDesignFoundation,compileDesignFoundation,foundationAuthoringContext,foundationAuthoringExample,inheritDesignFoundation,materializeDesignFoundation,supportsFoundationTextColor,FOUNDATION_END } from '../src/contracts/design-foundation';

test('all 16 directions have readable accent text on base, surface, tone, raised, deep and nested deep surfaces',()=>{
 for(const style of DESIGN_STYLES){
  const t=style.tokens,shades=foundationSurfaces(t),colors=foundationTextColors(t),profile=createDesignFoundation(style),css=compileDesignFoundation(profile);
  const backgrounds={base:t.background,surface:t.surface,tone:shades.tone.background,raised:shades.raised.background,deep:shades.deep.background,deepRaised:shades.deepRaised.background};
  for(const [key,bg] of Object.entries(backgrounds))assert.ok(foundationContrast(colors[key as keyof typeof backgrounds],bg)>=4.5,`${style.id}/${key}`);
  for(const bg of [t.background,shades.tone.background])assert.ok(foundationContrast(colors.bridge,bg)>=4.5,`${style.id}/bridge`);
  assert.match(css,new RegExp(`--bnf-accent:${t.accent}`));
  assert.match(css,/background:var\(--bnf-accent\);color:var\(--bnf-accent-ink\)/,'button fill and contrasting button label remain separate');
  assert.equal(css.split(TEXT_COLOR_MARKER).length-1,1);
  const context=foundationAuthoringContext(profile);assert.equal(context.tokens['--bnf-accent-text'],colors.base);assert.match(context.classes,/bnf-accent-text/);assert.match(context.classes,/自行改背景/);
 }
});

test('the observed industrial brand stays intact while its small labels reach 4.5 on both observed fills',()=>{
 for(const bg of ['#e8eceb','#e7ebf5']){assert.ok(foundationContrast('#265bff',bg)<4.5);const readable=readableAccentText('#265bff',[bg]);assert.notEqual(readable,'#265bff');assert.ok(foundationContrast(readable,bg)>=4.5);}
 assert.equal(readableAccentText('#17375e',['#ffffff']),'#17375e','already readable requested colors are preserved');
 const css=designTextColorCss(getDesignStyle('tech')!.tokens);
 assert.match(css,/\.bnf-inverse\{[^}]*--bnf-raised-accent-text:var\(--bnf-deep-raised-accent-text\)/);
 assert.match(css,/\.bnf-panel,\.bnf-workbench>\*\{--bnf-accent-text:var\(--bnf-raised-accent-text\)/);
 assert.match(css,/\.bnf-surface,\.bnf-card,\.bnf-cta,\.bnf-nav-float\{--bnf-accent-text:var\(--bnf-surface-accent-text\)/);
 assert.match(css,/\.bnf-hero-band\{--bnf-accent-text:var\(--bnf-accent-ink\)/);
});

test('old frozen CSS is byte-exact and does not advertise unavailable text colors',()=>{
 const profile=createDesignFoundation(getDesignStyle('industrial')!),manifest=materializeDesignFoundation(foundationAuthoringExample(profile),profile);
 // An earlier adopted coherence foundation has no text-color extension.
 const oldCss=manifest.site.theme.global_css.replace(new RegExp(TEXT_COLOR_MARKER.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'[\\s\\S]*?(?='+FOUNDATION_END.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')'),'');
 const old={...manifest,site:{...manifest.site,theme:{...manifest.site.theme,global_css:oldCss}}},frozen=inheritDesignFoundation(old,profile)!;
 assert.equal(compileDesignFoundation(frozen,old.site.theme),oldCss);assert.equal(supportsFoundationTextColor(frozen),false);assert.ok(!foundationAuthoringContext(frozen).classes.includes('bnf-accent-text'));
 const changed=compileDesignFoundation(frozen,{...old.site.theme,brand_color:'#265bff'});assert.ok(!changed.includes(TEXT_COLOR_MARKER));assert.ok(!changed.includes('--bnf-accent-text'));
});

test('new adopted foundations preserve their bytes, and explicit brand edits refresh text tokens against retained surfaces',()=>{
 const profile=createDesignFoundation(getDesignStyle('tech')!),manifest=materializeDesignFoundation(foundationAuthoringExample(profile),profile),frozen=inheritDesignFoundation(manifest,profile)!;
 assert.equal(compileDesignFoundation(frozen,manifest.site.theme),manifest.site.theme.global_css);
 const changed=materializeDesignFoundation({...manifest,site:{...manifest.site,theme:{...manifest.site.theme,brand_color:'#ffff00'}}},frozen),css=changed.site.theme.global_css;
 assert.equal(css.split(TEXT_COLOR_MARKER).length-1,1);assert.match(css,/--bnf-accent:#ffff00/);
 const shades=foundationSurfaces(profile.tokens),expected=foundationTextColors({...profile.tokens,accent:'#ffff00'},{tone:shades.tone.background,raised:shades.raised.background,deep:shades.deep.background,deepRaised:shades.deepRaised.background});
 assert.ok(css.includes(`--bnf-accent-text:${expected.base}`));assert.ok(css.includes(`--bnf-deep-accent-text:${expected.deep}`));
 const inherited=inheritDesignFoundation(changed,frozen)!;assert.equal(foundationAuthoringContext(inherited).tokens['--bnf-accent-text'],expected.base);assert.equal(compileDesignFoundation(inherited,changed.site.theme),css);
});
