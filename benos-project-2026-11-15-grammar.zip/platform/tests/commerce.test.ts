import assert from 'node:assert/strict';
import { beforeEach, afterEach, test } from 'node:test';
import { TestD1 } from './d1-helper';
import { canTopup, createOrder, quoteOrder, activeSubscription } from '../src/modules/commerce';
import { grantCredit, getWallet } from '../src/modules/ledger';
import { AppError } from '../src/lib/errors';

let database:TestD1,db:D1Database;
const time=Date.parse('2026-11-06T01:00:00.000Z'),iso=new Date(time).toISOString();
beforeEach(()=>{
 database=new TestD1();db=database as unknown as D1Database;
 database.sqlite.exec(`INSERT INTO users(id,email,name,password_hash,created_at,updated_at) VALUES ('u','u@example.test','User','unused','${iso}','${iso}'),('other','o@example.test','Other','unused','${iso}','${iso}');
  INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,test_status,created_by,created_at) VALUES ('pay','payment','Stripe','stripe',1,'active','{}','passed','u','${iso}');
  INSERT INTO sites(id,user_id,name,domain,cms_admin_email,created_at,updated_at) VALUES ('site','u','Site','example.test','u@example.test','${iso}','${iso}');`);
});
afterEach(()=>database.close());
function subscription(source='paid',state='active',end=time+3600_000){
 database.sqlite.prepare('INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,state,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
  .run('sub','u','go',source,new Date(time-3600_000).toISOString(),new Date(end).toISOString(),state,1,16_250_000,1,'sub',iso);
}
const rejected=(code:string)=>(error:unknown)=>error instanceof AppError&&error.code===code;

test('server prices Go, Pro, minimum topup and site hosting exactly in integer cents and micros',()=>{
 assert.deepEqual(quoteOrder({kind:'subscription',tier:'go',requestKey:'request-go'}),{amountCents:2500,creditMicros:16_250_000,tier:'go',siteId:null});
 assert.equal(quoteOrder({kind:'subscription',tier:'pro',requestKey:'request-pro'}).creditMicros,65_000_000);
 assert.equal(quoteOrder({kind:'topup',amountCents:500,requestKey:'request-topup'}).creditMicros,3_250_000);
 assert.equal(quoteOrder({kind:'topup',amountCents:1000,requestKey:'request-topup'}).creditMicros,6_500_000);
 assert.equal(quoteOrder({kind:'hosting',siteId:'site',requestKey:'request-host'}).amountCents,3000);
 for(const invalid of [499,0,-1,500.5,NaN,Infinity])assert.throws(()=>quoteOrder({kind:'topup',amountCents:invalid,requestKey:'request-topup'}));
 assert.throws(()=>quoteOrder({kind:'subscription',tier:'go',requestKey:'request-go',amountCents:1} as never));
});

test('gift membership does not silently confer paid topup privilege',async()=>{
 subscription('gift');assert.equal(await canTopup(db,'u',iso),false);
 await assert.rejects(createOrder(db,'u',{kind:'topup',amountCents:500,requestKey:'topup-gift'},'pay',time),rejected('PURCHASE_NOT_ALLOWED'));
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM orders').get()!.count,0);
});

test('cancelled renewal retains paid eligibility until the paid period boundary',async()=>{
 subscription('paid','cancelled');assert.equal(await canTopup(db,'u',iso),true);
 assert.equal(await canTopup(db,'u',new Date(time+3600_000).toISOString()),false);
 assert.equal((await activeSubscription(db,'u',iso))?.source,'paid');
 await createOrder(db,'u',{kind:'topup',amountCents:500,requestKey:'valid-topup'},'pay',time);
 await assert.rejects(createOrder(db,'u',{kind:'topup',amountCents:500,requestKey:'expired-topup'},'pay',time+3600_000),rejected('PURCHASE_NOT_ALLOWED'));
});

test('AI balance survives subscription expiry while new topups stop',async()=>{
 subscription('paid','active',time+1000);
 await grantCredit(db,{id:'monthly',userId:'u',source:'subscription',amountMicros:16_250_000,startsAtMs:time,expiresAtMs:time+1000,referenceId:'month',nowMs:time});
 await grantCredit(db,{id:'topup',userId:'u',source:'topup',amountMicros:6_500_000,referenceId:'topup',nowMs:time});
 assert.equal((await getWallet(db,'u',time+1000)).availableMicros,6_500_000);
 assert.equal(await canTopup(db,'u',new Date(time+1000).toISOString()),false);
});

test('topup restrictions and restricted account status block new purchases atomically',async()=>{
 subscription();database.sqlite.prepare('INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,actor_id,created_at) VALUES(?,?,?,?,?,?,?)').run('freeze','u','topup','review',iso,'u',iso);
 assert.equal(await canTopup(db,'u',iso),false);
 await assert.rejects(createOrder(db,'u',{kind:'topup',amountCents:500,requestKey:'frozen-topup'},'pay',time),rejected('PURCHASE_NOT_ALLOWED'));
 database.sqlite.exec("UPDATE users SET status='restricted' WHERE id='u'");
 await assert.rejects(createOrder(db,'u',{kind:'hosting',siteId:'site',requestKey:'frozen-hosting'},'pay',time),rejected('PURCHASE_NOT_ALLOWED'));
});

test('order retries use the same snapshot and changed payloads conflict',async()=>{
 subscription();const input={kind:'topup' as const,amountCents:500,requestKey:'same-topup-request'};
 const first=await createOrder(db,'u',input,'pay',time),repeat=await createOrder(db,'u',input,'pay',time+100);
 assert.equal(first.id,repeat.id);assert.equal(first.credit_micros,3_250_000);
 await assert.rejects(createOrder(db,'u',{...input,amountCents:1000},'pay',time),rejected('IDEMPOTENCY_CONFLICT'));
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM orders').get()!.count,1);
});

test('concurrent subscription checkout creation permits only one outstanding subscription',async()=>{
 const results=await Promise.allSettled(Array.from({length:10},(_,i)=>createOrder(db,'u',{kind:'subscription',tier:'go',requestKey:`subscription-${i}`},'pay',time)));
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM orders').get()!.count,1);
});

test('hosting purchases require ownership and an activated payment configuration',async()=>{
 await assert.rejects(createOrder(db,'other',{kind:'hosting',siteId:'site',requestKey:'other-site-order'},'pay',time),rejected('PURCHASE_NOT_ALLOWED'));
 database.sqlite.exec("UPDATE integration_configs SET status='disabled'");
 await assert.rejects(createOrder(db,'u',{kind:'hosting',siteId:'site',requestKey:'own-site-order'},'pay',time),rejected('PURCHASE_NOT_ALLOWED'));
});
