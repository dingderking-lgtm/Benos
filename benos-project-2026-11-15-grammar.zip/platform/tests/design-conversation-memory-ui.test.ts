import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Browser modules are authored in JavaScript.
import { mergeConversationPages, renderConversationHistory } from '../public/js/design-workflow.js';

function turn(n: number, requestPrompt: string, assistantReply = '') {
  return {
    transcriptId: 'turn-' + n, requestKey: 'conversation-request-' + n, projectId: 'history-proj',
    workflowId: 'workflow-' + n, recordKind: 'workflow', requestPrompt, assistantReply,
    referenceMediaIds: [], state: 'succeeded', createdAt: new Date(1700000000000 + n * 1000).toISOString(),
  };
}

test('updating the latest conversation page preserves earlier loaded turns and uses the definitive reply', () => {
  const first = turn(1,'A 的原文'), second = turn(2,'B 的原文'), third = turn(3,'C 的原文');
  const previous = { conversation: {items:[second,first], nextCursor:null, loadedEarlier:true} };
  const revised = {...second, assistantReply:'已调整首页间距。'};
  const updated = { conversation: {items:[third,revised], nextCursor:'first-page-boundary', loadedEarlier:false} };
  mergeConversationPages(previous,updated);
  assert.deepEqual(updated.conversation.items.map(item => item.requestPrompt),['C 的原文','B 的原文','A 的原文']);
  assert.equal(updated.conversation.items[1].assistantReply,revised.assistantReply);
  assert.equal(updated.conversation.nextCursor,null);
});

test('the visible conversation keeps the full original request and reply, independently of execution details', () => {
  const raw = '  A：保留以下缩进\n    <article>\n' + '首页的说明。'.repeat(360) + '\n    </article>\n';
  const older = turn(1,raw,'已保留你指定的排版。'), latest = turn(2,'B：请调整字号','标题已调整。');
  const data = {
    project:{id:'history-proj'}, jobs:[], visual:{assets:[],candidates:[]},
    workflow:{
      items:[{id:latest.workflowId, projectId:'history-proj', state:'succeeded', requestPrompt:'工具内部请求',
        maxCostMicros:12345678, steps:[{ordinal:1,tools:[{name:'propose_files',code:'INTERNAL_TOOL_SENTINEL'}]}]}],
      conversation:{items:[latest,older], nextCursor:null, loadedEarlier:false},
    },
  };
  const html = renderConversationHistory(data,{id:'conversation-reader'});
  assert.ok(html.includes(raw.replaceAll('<','&lt;').replaceAll('>','&gt;')));
  assert.ok(html.includes(older.assistantReply));
  assert.ok(html.includes(latest.requestPrompt));
  assert.ok(html.includes(latest.assistantReply));
  assert.ok(html.indexOf('A：保留以下缩进') < html.indexOf('B：请调整字号'));
  assert.doesNotMatch(html,/INTERNAL_TOOL_SENTINEL|工具内部请求|propose_files|额度明细|本地工具处理记录/);
});
