// The grammar engine's gate: default off, owner only, and a policy row written before the flag
// existed still parses.
import assert from 'node:assert/strict';
import test from 'node:test';
import { generationPolicySchema } from '../src/lib/generation-policy';
import { resolveSiteEngine, SITE_ENGINES } from '../src/lib/engine-access';

test('the generation policy keeps the grammar engine off by default', () => {
  const policy = generationPolicySchema.parse({});
  assert.equal(policy.newSiteEngine, 'compose-v2');
  assert.deepEqual([...SITE_ENGINES], ['compose-1', 'compose-v2', 'syntax-1']);
  // A settings row written before the flag existed must keep working.
  const legacy = generationPolicySchema.parse({ version: 'gp-1', pipeline: 'frame-first-2', imageQuality: 'low', maxImages: 8, imageConcurrency: 3, costTargetMicros: 400_000, optionalReview: true, optionalReviewEstimateMicros: 60_000, imageEstimation: 'image-estimate-v1' });
  assert.equal(legacy.newSiteEngine, 'compose-v2');
  // An unknown engine name is refused instead of quietly becoming something else.
  assert.equal(generationPolicySchema.safeParse({ newSiteEngine: 'syntax-2' }).success, false);
});

test('turning the flag on only ever reaches the owner account', () => {
  const on = { newSiteEngine: 'syntax-1' as const };
  assert.equal(resolveSiteEngine(on, 'owner'), 'syntax-1');
  for (const role of ['admin', 'user', null, undefined, '']) assert.equal(resolveSiteEngine(on, role as never), 'compose-v2', String(role));
  // Off means off, whatever the role is.
  assert.equal(resolveSiteEngine({ newSiteEngine: 'compose-2' as never }, 'owner'), 'compose-2');
  assert.equal(resolveSiteEngine({ newSiteEngine: 'compose-v2' }, 'owner'), 'compose-v2');
  assert.equal(resolveSiteEngine({ newSiteEngine: 'compose-1' }, 'owner'), 'compose-1');
});
