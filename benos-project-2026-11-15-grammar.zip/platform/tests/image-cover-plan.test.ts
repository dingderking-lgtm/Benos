import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { compileImageFramePlan, IMAGE_FRAME_PLAN_V2_VERSION, imageCoverGeometry, imageCoverSafeRegion, imagePromptForPlannedFrame, resolvePlannedImageFrame, validateImageFramePresentation } from '../src/lib/image-frame-plan';
import { imageDisplay } from '../src/lib/image-layout';
import { prepareSiteLayout, bindPreparedImages, validatePreparedImageCompletion } from '../src/lib/prepared-site-layout';
import { compileDesignFoundation, createDesignFoundation } from '../src/contracts/design-foundation';
import { DESIGN_STYLES } from '../src/contracts/design-style-catalog';

type SafeArea = 'none' | 'left' | 'right' | 'top' | 'bottom';
const v2 = { version: IMAGE_FRAME_PLAN_V2_VERSION } as const;
function input(presentation: 'hero-cover' | 'standard' = 'hero-cover', textSafeArea: SafeArea = 'left') {
 return { sections: [{ id: 'hero', layout: 'An atmospheric cover with an independent readable text face', frames: [{ id: 'hero', purpose: 'A distinct factory scene', presentation, subjectPolicy: 'crop-safe' as const, framePolicy: 'fixed' as const, slot: { width: 1440, height: 760, fit: 'cover' as const, focalPoint: 'center' as const, textSafeArea } }] }] };
}
const html = (title = 'Equipment designed around the needs of real production', direction = 'ltr') => `<section class="bnf-hero-cover" dir="${direction}"><div id="bnf-image-hero" style="height:300px;max-width:800px;aspect-ratio:1/1;position:absolute"></div><div class="bnf-container bnf-hero-cover-content"><div class="bnf-hero-cover-panel"><h1 class="bnf-title">${title}</h1><p class="bnf-muted">A focused view of the material, mechanism and process.</p><a class="bnf-button" href="#details">Explore the process</a></div></div></section><section id="details"><h2>Real next section</h2></section>`;
const manifest = (markup = html()) => ({ site: { home: 'home' }, templates: [{ id: 1, document: { html: markup, css: '.existing{color:blue}' } }], assets: [{ path: '/uploads/original.png' }] });
const binding = { frameId: 'hero', asset: { id: 'media-fixture', width: 1536, height: 1024 }, src: '/uploads/cover.svg', alt: 'A landscape scene' };

test('cover is an explicit v2 capability and standard v2 preserves v1 frame bytes', () => {
 const value = input(); assert.throws(() => compileImageFramePlan(value), /unrecognized|presentation/i);
 const standard = input('standard'), legacy = structuredClone(standard);
 delete (legacy.sections[0].frames[0] as any).presentation;
 const old = compileImageFramePlan(legacy), current = compileImageFramePlan(standard, v2);
 assert.equal(old.version, 'image-frame-plan-v1'); assert.equal(old.frames[0].presentation, undefined);
 assert.equal(current.version, 'image-frame-plan-v2'); assert.equal(current.frames[0].presentation, 'standard');
 const raw = manifest('<div id="bnf-image-hero"></div>');
 assert.deepEqual(prepareSiteLayout(raw, old).manifest, prepareSiteLayout(raw, current).manifest);
 assert.deepEqual(bindPreparedImages(raw, old, [binding]).manifest, bindPreparedImages(raw, current, [binding]).manifest);
 const forged = compileImageFramePlan(value, v2); forged.version = 'image-frame-plan-v1';
 assert.equal(prepareSiteLayout(manifest(), forged).issues[0].code, 'INVALID_FRAME_PLAN');
});

test('cover rejects complete/adapt/contain and explicit user contain instead of widening equipment frames', () => {
 for (const change of [{ subjectPolicy: 'complete' }, { framePolicy: 'adapt' }, { slot: { ...input().sections[0].frames[0].slot, fit: 'contain' } }]) {
  const value = input(); Object.assign(value.sections[0].frames[0], change); assert.throws(() => compileImageFramePlan(value, v2));
 }
 assert.throws(() => compileImageFramePlan(input(), { ...v2, preserveExplicitContainIds: ['hero'] }), /EXPLICIT_CONTAIN/);
 const duplicate = input(); duplicate.sections[0].frames.push({ ...duplicate.sections[0].frames[0] });
 assert.throws(() => compileImageFramePlan(duplicate, v2), /unique/);
 const tooMany = input(); tooMany.sections = Array.from({ length: 13 }, (_, i) => ({ ...tooMany.sections[0], id: 's' + i, frames: [{ ...tooMany.sections[0].frames[0], id: 'f' + i }] }));
 assert.throws(() => compileImageFramePlan(tooMany, v2));
});

test('v2 permits eight distinct frames in one gallery without changing the legacy four-frame section cap', () => {
 const value=input('standard');value.sections[0].frames=Array.from({length:8},(_,index)=>({...value.sections[0].frames[0],id:'view-'+index}));
 assert.equal(compileImageFramePlan(value,v2).frames.length,8);
 const legacy={sections:value.sections.map(section=>({...section,frames:section.frames.map(({presentation,...frame})=>frame)}))};
 assert.throws(()=>compileImageFramePlan(legacy));
 value.sections[0].frames.push({...value.sections[0].frames[0],id:'ninth'});assert.throws(()=>compileImageFramePlan(value,v2));
});

test('cover direction selects a consistent focal side and shares the intersection of representative crops', () => {
 const expected = { left: '100% 50%', right: '0% 50%', top: '50% 100%', bottom: '50% 0%', none: '50% 50%' };
 for (const safe of Object.keys(expected) as SafeArea[]) {
  const frame = compileImageFramePlan(input('hero-cover', safe), v2).frames[0], receipt = resolvePlannedImageFrame(frame, 1536, 1024), region = imageCoverSafeRegion(frame);
  assert.equal(frame.generation.size, '1536x1024'); assert.equal(receipt.display.objectPosition, expected[safe]);
  assert.equal(receipt.display.aspectRatio, 'auto'); assert.equal(receipt.subjectVerified, false);
  assert.ok(region.width > 0 && region.height > 0);
  for (const [width, height] of [[1440, 900], [768, 1024], [390, 844], [320, 568]]) {
   const visible = imageDisplay({ ...frame.resolvedSlot, ...imageCoverGeometry(width, height) }, 1536, 1024).visibleRegion;
   assert.ok(region.left >= visible.left && region.top >= visible.top);
   assert.ok(region.left + region.width <= visible.left + visible.width + .001);
   assert.ok(region.top + region.height <= visible.top + visible.height + .001);
  }
  assert.match(imagePromptForPlannedFrame('Explain this production mechanism.', frame), /shared desktop\/phone crop/);
 }
});

test('cover preparation binds only the independent media and deterministically installs its safe-area layout', () => {
 const plan = compileImageFramePlan(input('hero-cover', 'right'), v2), raw = manifest(), original = structuredClone(raw);
 const prepared = prepareSiteLayout(raw, plan); assert.deepEqual(prepared.issues, []); assert.deepEqual(raw, original);
 const markup = prepared.manifest.templates[0].document.html;
 assert.match(markup, /bnf-hero-cover-text-right/); assert.match(markup, /bnf-hero-cover-media/);
 assert.match(markup, /height:var\(--bnf-hero-cover-height,min\(88vh,760px\)\)!important/);
 assert.doesNotMatch(markup, /height:300px|max-width:800px|position:absolute/);
 assert.deepEqual(prepareSiteLayout(prepared.manifest, plan), prepared);
 const bound = bindPreparedImages(prepared.manifest, plan, [binding]); assert.deepEqual(bound.issues, []);
 assert.match(bound.manifest.templates[0].document.html, /width="1536" height="1024"/);
 assert.match(bound.manifest.templates[0].document.html, /height:100%!important.*aspect-ratio:auto!important.*object-position:0% 50%/);
 assert.equal(bound.manifest.assets, raw.assets); assert.equal(bound.manifest.templates[0].document.css, raw.templates[0].document.css);
 assert.deepEqual(bindPreparedImages(bound.manifest, plan, [binding]), bound);
 assert.deepEqual(validatePreparedImageCompletion(bound.manifest, plan), []);
});

test('cover structure and measured geometry are checked without claiming pixel semantics', () => {
 const plan = compileImageFramePlan(input(), v2), frame = plan.frames[0];
 for (const markup of ['<div id="bnf-image-hero"></div>', html().replace('bnf-hero-cover-panel', 'ordinary-panel'), html().replace('<div id="bnf-image-hero"', '<figure><div id="bnf-image-hero"').replace('</div><div class="bnf-container', '</div></figure><div class="bnf-container')]) {
  const raw = manifest(markup), result = prepareSiteLayout(raw, plan); assert.ok(result.issues.some(i => i.code === 'INVALID_COVER_STRUCTURE')); assert.equal(result.manifest, raw);
 }
 const geometry = imageCoverGeometry(390, 844), observed = { frameWidth: geometry.width, frameHeight: geometry.height, imageWidth: geometry.width, imageHeight: geometry.height, objectFit: 'cover', objectPosition: '100% 50%', naturalWidth: 1536, naturalHeight: 1024, viewportWidth: 390, viewportHeight: 844 };
 const good = validateImageFramePresentation(frame, { width: 1536, height: 1024 }, observed);
 assert.equal(good.valid, true); assert.equal(good.letterboxFraction, 0); assert.ok(good.cropFraction! > 0); assert.equal(good.subjectVerified, false);
 assert.ok(validateImageFramePresentation(frame, { width: 1536, height: 1024 }, { ...observed, viewportHeight: undefined }).issues.includes('cover_viewport_height_missing'));
 assert.ok(validateImageFramePresentation(frame, { width: 1536, height: 1024 }, { ...observed, imageHeight: 260, frameHeight: 260 }).issues.includes('cover_height_changed'));
 assert.ok(validateImageFramePresentation(frame, { width: 1536, height: 1024 }, { ...observed, objectFit: 'contain' }).issues.includes('cover_fit_changed'));
});

const php = process.env.BENOS_TEST_PHP || 'php', renderer = resolve('..', 'reference', 'aacmss', 'src', 'Services', 'Renderer.php');
const localRequire = createRequire(import.meta.url); let chromium: any;
try { chromium = localRequire(process.env.BENOS_TEST_PLAYWRIGHT || 'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright').chromium; } catch { /* CI can run pure checks alone. */ }
const browserPath = process.env.BENOS_TEST_BROWSER || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const phpAvailable = existsSync(renderer) && spawnSync(php, ['-r', 'echo class_exists("DOMDocument")?"yes":"no";'], { windowsHide: true, encoding: 'utf8' }).stdout === 'yes';

test('formal CMS rendered covers fit four widths with RTL, long headings and readable text over extreme images', { skip: !phpAvailable || !chromium || !existsSync(browserPath) ? 'Requires pinned PHP renderer and local browser' : false, timeout: 90000 }, async () => {
 const cases: any[] = [], report: any = { method: 'Isolated Edge with real pinned AACMS Renderer sanitization and solid SVG image fixtures at 1536x1024. RTL is inherited from the host html element and explicitly measured; the pinned renderer removes component dir attributes. No application session, database or provider requests.', paidCalls: 0, cases };
 const styles = ['modern', 'dark', 'warm', 'industrial'].map(id => DESIGN_STYLES.find(style => style.id === id)!);
 const fixtures = styles.flatMap((style, i) => ['ltr', 'rtl'].map(direction => {
  const plan = compileImageFramePlan(input('hero-cover', direction === 'rtl' ? 'right' : 'left'), v2);
  const title = direction === 'rtl' ? 'معدات صناعية دقيقة تبدأ بفهم احتياجات الإنتاج والمواد وخطوات العمل' : 'A clearer perspective on industrial production, materials and the choices that shape a complete process';
  const prepared = prepareSiteLayout(manifest(html(title, direction)), plan); assert.deepEqual(prepared.issues, []);
  const bound = bindPreparedImages(prepared.manifest, plan, [binding]); assert.deepEqual(bound.issues, []);
  const css = compileDesignFoundation(createDesignFoundation(style)) + '\n#bnf-image-hero{height:123px!important;max-width:500px!important}.bnf-hero-cover-media img{position:absolute;inset:0;height:300px!important;object-fit:contain!important}';
  return { style: style.id, direction, plan, darkImage: i % 2 === 0, html: bound.manifest.templates[0].document.html, css };
 }));
 const result = spawnSync(php, ['-r', 'require dirname($argv[1])."/PageHiddenContent.php";require dirname($argv[1])."/ResponsiveImages.php";require $argv[1];$r=new AACMS\\Services\\Renderer();$out=[];foreach(json_decode(stream_get_contents(STDIN),true) as $x){$out[]=$r->renderDocument(["version"=>1,"html"=>$x["html"],"css"=>$x["css"]]);}echo json_encode($out,JSON_THROW_ON_ERROR);', renderer], { windowsHide: true, encoding: 'utf8', input: JSON.stringify(fixtures), timeout: 15000, maxBuffer: 2 * 1024 * 1024 });
 assert.equal(result.status, 0, result.stderr); const rendered: string[] = JSON.parse(result.stdout);
 const browser = await chromium.launch({ executablePath: browserPath, headless: true });
 try {
  const page = await browser.newPage(); let fill = 'black';
  await page.route('**/*', (route: any) => route.request().url() === 'https://cover.fixture/uploads/cover.svg' ? route.fulfill({ contentType: 'image/svg+xml', body: `<svg xmlns="http://www.w3.org/2000/svg" width="1536" height="1024"><rect width="100%" height="100%" fill="${fill}"/></svg>` }) : route.abort());
  for (let i = 0; i < fixtures.length; i++) for (const width of [1440, 768, 390, 320]) {
   const fixture = fixtures[i]; fill = fixture.darkImage ? 'black' : 'white'; await page.setViewportSize({ width, height: 900 });
   await page.setContent('<!doctype html><html dir="' + fixture.direction + '"><head><base href="https://cover.fixture/"><meta http-equiv="Content-Security-Policy" content="default-src \'none\';script-src \'none\';style-src \'unsafe-inline\';img-src https://cover.fixture"></head><body style="margin:0"><div class="aacms-page">' + rendered[i] + '</div></body></html>');
   await page.locator('img').evaluate((image: any) => image.decode());
   const measured = await page.evaluate(`(() => {
    const { document, innerWidth, innerHeight, getComputedStyle } = globalThis;
    const image = document.querySelector('img'), media = image.parentElement, frame = media.getBoundingClientRect(), imageRect = image.getBoundingClientRect(), css = getComputedStyle(image), panel = document.querySelector('.bnf-hero-cover-panel'), panelRect = panel.getBoundingClientRect(), content = document.querySelector('.bnf-hero-cover-content').getBoundingClientRect();
    const luminance = (value) => { const rgb = value.match(/[\\d.]+/g).slice(0, 3).map(Number).map(v => v / 255).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4); return rgb[0] * .2126 + rgb[1] * .7152 + rgb[2] * .0722; };
    const colors = [...panel.querySelectorAll('h1,p')].map((node) => { const foreground = getComputedStyle(node).color, background = getComputedStyle(panel).backgroundColor, a = luminance(foreground), b = luminance(background), r = node.getBoundingClientRect(); return { foreground, background, contrast: (Math.max(a, b) + .05) / (Math.min(a, b) + .05), left: r.left, right: r.right, top: r.top, bottom: r.bottom }; });
    return { observed: { frameWidth: frame.width, frameHeight: frame.height, imageWidth: imageRect.width, imageHeight: imageRect.height, objectFit: css.objectFit, objectPosition: css.objectPosition, naturalWidth: image.naturalWidth, naturalHeight: image.naturalHeight, viewportWidth: innerWidth, viewportHeight: innerHeight }, direction: getComputedStyle(panel).direction, overflow: document.documentElement.scrollWidth - innerWidth, mediaBottom: frame.bottom, contentTop: content.top, nextSectionTop: document.querySelector('#details').getBoundingClientRect().top, panel: { left: panelRect.left, right: panelRect.right, top: panelRect.top, bottom: panelRect.bottom }, colors };
   })()`);
   const validation = validateImageFramePresentation(fixture.plan.frames[0], { width: 1536, height: 1024 }, measured.observed), label = `${fixture.style}/${fixture.direction}/${width}`;
   const evidence: any = { label, fill, ...measured, validation }; cases.push(evidence);
   if (process.env.BENOS_COVER_REPORT) {
    const screenshots = resolve(process.env.BENOS_COVER_REPORT, '..', 'image-cover-screenshots'); mkdirSync(screenshots, { recursive: true });
    evidence.screenshot = resolve(screenshots, label.replaceAll('/', '-') + '.png');
    await page.screenshot({ path: evidence.screenshot, fullPage: true });
   }
   assert.equal(validation.valid, true, JSON.stringify(cases.at(-1))); assert.equal(validation.letterboxFraction, 0); assert.equal(validation.subjectVerified, false);
   assert.equal(measured.direction, fixture.direction, label + ': actual text direction');
   assert.ok(measured.overflow <= 1, label + ': overflow'); assert.ok(measured.colors.every((color: any) => color.contrast >= 4.5 && color.left >= -1 && color.right <= width + 1), label + ': readable uncut text');
   assert.ok(measured.colors.every((color: any) => color.top >= measured.panel.top - 1 && color.bottom <= measured.panel.bottom + 1), label + ': text remains on the opaque face');
   assert.ok(measured.nextSectionTop >= Math.max(measured.panel.bottom, measured.mediaBottom) - 1, label + ': long copy does not overlap the next section');
   if (width <= 640) assert.ok(measured.contentTop >= measured.mediaBottom - 1, label + ': mobile copy follows the image');
  }
  report.passed = true;
 } finally {
  await browser.close();
  const files = ['src/lib/image-frame-plan.ts', 'src/lib/prepared-site-layout.ts', 'src/contracts/design-foundation.ts', 'tests/image-cover-plan.test.ts'];
  report.sources = files.map(file => ({ file: 'platform/' + file, sha256: createHash('sha256').update(readFileSync(file)).digest('hex') }));
  report.boundary = 'Crop geometry is verified only at the measured viewports. Composition guidance does not prove subject completeness or absence of borders baked into generated pixels.';
  if (process.env.BENOS_COVER_REPORT) { const destination = resolve(process.env.BENOS_COVER_REPORT); mkdirSync(resolve(destination, '..'), { recursive: true }); writeFileSync(destination, JSON.stringify(report, null, 2)); }
 }
});
