import test from 'node:test';
import assert from 'node:assert/strict';
import { createLegacyDesignBrief as createDesignBrief, designBriefAuthoringContext, type DesignBrief } from '../src/contracts/design-brief';

// Explicit db-2 compatibility suite; db-3 behavior is covered in design-blueprint.test.ts.
const DESIGN_BRIEF_VERSION = 'db-2';
const fresh = (request: string, referenceImageCount = 0) => createDesignBrief({ request, hasExistingSite: false, referenceImageCount })!;

test('plain one-line requests receive different visitor tasks without requiring design vocabulary', () => {
  const industrial = fresh('做个机械官网'), cafe = fresh('做一个咖啡店网站'), photo = fresh('做我的个人摄影作品集');
  assert.equal(industrial.inference.siteKind, 'industrial');
  assert.equal(cafe.inference.siteKind, 'cafe');
  assert.equal(photo.inference.siteKind, 'photography');
  assert.match(industrial.visitorGoal, /采购|选型/);
  assert.match(cafe.visitorGoal, /饮品|到访/);
  assert.match(photo.visitorGoal, /作者|作品/);
  assert.equal(new Set([industrial, cafe, photo].map(brief => brief.cta.primary)).size, 3);
  assert.match(industrial.visualTasks.join(''), /没提图片.*主视觉/);
  assert.match(photo.visualTasks.join(''), /没提图片.*主视觉/);
});

test('db-2 plans purposeful image roles once, with uploads first and no compulsory image quota', () => {
  for (const request of ['机械官网', '咖啡店网站', '个人摄影作品集', '一个无人机官网', 'Build a software product website']) {
    const brief = fresh(request, 2), plan = brief.imagePlan!;
    assert.equal(brief.version, 'db-2'); assert.equal(plan.mode, 'standard');
    assert.deepEqual(plan.targetRange, [5, 8]);
    assert.deepEqual(plan.roles.map(role => role.role), ['hero', 'detail', 'process', 'closing']);
    assert.match(plan.assetPolicy, /真实上传.*生成只补缺口/);
    assert.match(plan.completionPolicy, /不是硬配额|非硬配额/);
    assert.match(brief.artDirection!, /色调.*光线.*镜头/);
    assert.ok(JSON.stringify(brief).length <= 3000, request + ': compact saved brief');
  }
  assert.notDeepEqual(fresh('机械官网').imagePlan!.roles, fresh('咖啡店网站').imagePlan!.roles);
});

test('simple, no-image and existing-images-only requests override the standard image target', () => {
  for (const request of ['一个简单介绍首页', '咖啡店网站，少图', 'Make a simple website']) {
    assert.equal(fresh(request).imagePlan!.mode, 'minimal');
    assert.deepEqual(fresh(request).imagePlan!.targetRange, [0, 3]);
  }
  for (const request of ['机械官网，不要图片', '纯文字网站', 'Build a website without images', 'Text-only homepage']) {
    const plan = fresh(request).imagePlan!;
    assert.equal(plan.mode, 'none', request); assert.equal(plan.generation, 'disabled');
    assert.deepEqual(plan.targetRange, [0, 0]); assert.deepEqual(plan.roles, []);
  }
  for (const request of ['做摄影网站，不生成图片', '仅用上传作品', 'Do not generate new images; use my uploads']) {
    const plan = fresh(request).imagePlan!;
    assert.equal(plan.generation, 'disabled', request); assert.notEqual(plan.mode, 'none');
  }
  for (const request of ['不要纯文字，做机械官网', '不要简单，做完整作品集', '不要生成虚假参数，做机械官网']) {
    assert.equal(fresh(request).imagePlan!.mode, 'standard', request);
    assert.equal(fresh(request).imagePlan!.generation, 'fill-gaps', request);
  }
});

test('serialized db-1 snapshots do not acquire db-2 image or art direction decisions', () => {
  const { imagePlan: _image, artDirection: _art, ...current } = fresh('机械官网');
  const legacy: DesignBrief = { ...current, version: 'db-1' };
  const before = JSON.stringify(legacy), context = designBriefAuthoringContext(legacy);
  assert.equal(JSON.stringify(legacy), before);
  assert.ok(context.includes('"version":"db-1"'));
  assert.ok(!context.includes('"imagePlan"') && !context.includes('"artDirection"'));
});

test('English requests and negated or secondary business mentions keep the intended scenario', () => {
  for (const [request, kind] of [
    ['Build a machinery company website', 'industrial'],
    ['Create a coffee shop site', 'cafe'],
    ['Make a personal photography portfolio', 'photography'],
    ['不是咖啡店，是机械官网', 'industrial'],
    ['不要工业设备，做咖啡店网站', 'cafe'],
    ['做机械官网，包括咖啡店客户的设备应用介绍', 'industrial'],
    ['做咖啡店官网，附带摄影作品展示', 'cafe'],
    ['Make a cafe website, not a machinery site', 'cafe'],
    ['咖啡机厂家官网', 'industrial'],
  ] as const) assert.equal(fresh(request).inference.siteKind, kind, request);
});

test('unrecognized or minimal requests still receive useful professional responsibilities', () => {
  for (const request of ['帮我给澄野做个网站', '为新的想法做一个页面', 'Build something for my project', '']) {
    const brief = fresh(request);
    assert.equal(brief.inference.siteKind, 'general');
    assert.match(brief.visitorGoal, /提供什么|下一步/);
    assert.ok(brief.informationPriorities.length);
    assert.match(brief.cta.whenDetailsMissing, /已有内容|不做按钮/);
    assert.match(brief.visualTasks.join(''), /主动判断|图框/);
    assert.match(brief.inference.reason, /通用设计推断/);
  }
});

test('a brief separates supplied facts from inferences and never invents operational destinations', () => {
  const request = '建泰塑料机械有限公司官网，电话 13912345678，品牌主色红色';
  const brief = fresh(request);
  assert.equal(brief.source.requestExcerpt, request);
  assert.match(brief.source.factsPolicy, /设计推断.*不是用户确认/);
  assert.match(brief.missingFactsPolicy, /不把真实公司一律称为虚构演示/);
  assert.match(brief.missingFactsPolicy, /电话.*价格.*不得编造/);
  assert.match(brief.cta.whenDetailsMissing, /页内.*不造电话或假提交表单/);
  assert.match(fresh('咖啡店网站').cta.whenDetailsMissing, /风味方向.*不能伪装成在售清单/);
  assert.match(fresh('摄影作品集').cta.whenDetailsMissing, /无真实联系方式.*不放假联系按钮/);
  const withoutExcerpt = JSON.stringify({ ...brief, source: { ...brief.source, requestExcerpt: '' } });
  assert.doesNotMatch(withoutExcerpt, /13912345678|tel:|mailto:|https?:\/\/|¥|￥/);
});

test('reference counts do not pretend to identify uploads and absent assets have an honest fallback', () => {
  const supplied = fresh('摄影作品集', 2), absent = fresh('机械官网');
  assert.equal(supplied.source.referenceImageCount, 2);
  assert.match(supplied.referenceUse, /先识别.*不凭数量判断/);
  assert.match(supplied.visualTasks.join(''), /不推定每张参考图都是作者作品/);
  assert.match(absent.referenceUse, /生图失败.*原生.*不声称图片已成功/);
  assert.equal(fresh('网站', Number.NaN).source.referenceImageCount, 0);
  assert.equal(fresh('网站', -2).source.referenceImageCount, 0);
});

test('existing websites and local edits never receive a replacement business plan', () => {
  for (const request of ['换成咖啡店风格', '修改机械官网的电话', '帮我重新设计首页']) {
    assert.equal(createDesignBrief({ request, hasExistingSite: true }), null);
  }
  for (const scope of ['page', 'node'] as const) assert.equal(createDesignBrief({ request: '做机械官网', hasExistingSite: false, scope }), null);
  assert.equal(designBriefAuthoringContext(undefined), '');
  assert.equal(designBriefAuthoringContext(null), '');
});

test('brief snapshots are bounded, deterministic, independent and preserve creative freedom', () => {
  for (const request of ['机械官网', '咖啡店网站', '摄影作品集', '澄野网站', '网站😀'.repeat(2000)]) {
    const brief = fresh(request), serialized = JSON.stringify(brief);
    assert.equal(brief.version, DESIGN_BRIEF_VERSION);
    assert.ok(Array.from(brief.source.requestExcerpt).length <= 160);
    assert.ok(serialized.length <= 3000, `${brief.inference.siteKind}: ${serialized.length}`);
    assert.deepEqual(JSON.parse(serialized), fresh(request));
    assert.match(brief.creativeFreedom, /用户明确目的、风格与限制优先/);
    assert.match(brief.creativeFreedom, /不固定区块顺序、配色、卡片数量或图片数量/);
    assert.ok(designBriefAuthoringContext(brief).includes(serialized));
  }
  const a = fresh('机械官网');
  a.informationPriorities[0] = 'changed'; a.cta.primary = 'changed'; a.visualTasks.push('changed');
  assert.doesNotMatch(JSON.stringify(fresh('机械官网')), /changed/);
  assert.equal(fresh('很长的需求'.repeat(1000)).source.excerptTruncated, true);
});

test('ordinary business requests persist creative judgment without replacing visitor goals or factual boundaries', () => {
  for (const request of ['做机械官网', '给咖啡店做网站', '做个人摄影作品集', '医疗服务企业出海网站', 'Create a software brand website']) {
    const brief = fresh(request);
    assert.equal(brief.creativeDirection?.version, 'cd-1');
    assert.match(brief.creativeDirection!.judgment, /行业只决定信息责任/);
    assert.match(brief.creativeDirection!.composition, /不是必选区块或固定页序/);
    assert.match(brief.creativeDirection!.internationalization, /不因“出海”擅改英文/);
    assert.ok(designBriefAuthoringContext(brief).includes('RTL'));
    assert.ok(JSON.stringify(brief).length <= 3000);
    assert.match(brief.missingFactsPolicy, /不得编造/);
  }
  const constrained = createDesignBrief({ request: '工业官网，保留红色品牌和中文', hasExistingSite: false, stylePreference: '客户自己的极简红色方向', referenceImageCount: 2 })!;
  assert.equal(constrained.creativeDirection?.styleSource, 'user');
  assert.match(constrained.creativeDirection!.judgment, /明确品牌和用户风格为准/);
  assert.match(constrained.creativeDirection!.imagery, /先辨认上传/);
  const legacy = fresh('机械官网');
  delete legacy.creativeDirection;
  assert.ok(designBriefAuthoringContext(legacy).includes(legacy.visitorGoal));
  assert.ok(!designBriefAuthoringContext(legacy).includes('cd-1'), 'old snapshots are not replanned during serialization');
});
