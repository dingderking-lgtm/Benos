﻿import test from 'node:test';
import assert from 'node:assert/strict';
import type { Env } from '../src/env';
import { generationPolicySchema, GENERATION_POLICY_KEY, loadGenerationPolicy, workflowGenerationPolicy, canStartOptionalReview } from '../src/lib/generation-policy';

function settings(initial: string | null) {
 let value = initial;
 const calls: { sql: string; key?: string }[] = [];
 const env = { DB: { prepare(sql: string) {
  const call: { sql: string; key?: string } = { sql }; calls.push(call);
  assert.match(sql, /^SELECT value_json FROM settings WHERE key=\?$/);
  return { bind(key: string) { call.key = key; return { async first() { return value === null ? null : { value_json: value }; } }; } };
 } } } as unknown as Env;
 return { env, calls, replace(next: string | null) { value = next; } };
}

test('new settings default to low and three concurrent images with a soft 40-cent target', async () => {
 const store = settings(null), policy = await loadGenerationPolicy(store.env);
 assert.deepEqual(policy, { version: 'gp-1', pipeline: 'frame-first-2', imageQuality: 'low', maxImages: 8, imageConcurrency: 3, costTargetMicros: 400_000, optionalReview: true, optionalReviewEstimateMicros: 60_000, imageEstimation: 'image-estimate-v1', newSiteEngine: 'compose-v2' });
 assert.equal(store.calls[0].key, GENERATION_POLICY_KEY);
 assert.equal(canStartOptionalReview(policy, 340_000), true);
 assert.equal(canStartOptionalReview(policy, 340_001), false);
 assert.equal(canStartOptionalReview(policy, 500_000), false, 'exceeding the target only declines optional work; it does not throw a payment error');
 assert.ok(!('maxCostMicros' in policy), 'target is not serialized as the workflow hard budget');
 assert.equal(generationPolicySchema.safeParse({ maxCostMicros: 400_000 }).success, false);
});

test('workflow snapshot stays fixed when live quality, concurrency and legacy switches change', async () => {
 const store = settings(JSON.stringify({ imageQuality: 'low', imageConcurrency: 3 }));
 const first = await loadGenerationPolicy(store.env), requirements = JSON.stringify({ request: 'Existing task', generationPolicy: first });
 store.replace(JSON.stringify({ pipeline: 'frame-first-1', imageQuality: 'medium', imageConcurrency: 4, maxImages: 4, imageEstimation: 'legacy', optionalReview: false, costTargetMicros: 800_000 }));
 const next = await loadGenerationPolicy(store.env), old = workflowGenerationPolicy(requirements)!;
 assert.equal(next.pipeline, 'frame-first-1'); assert.equal(next.imageQuality, 'medium'); assert.equal(next.imageConcurrency, 4);
 assert.equal(next.imageEstimation, 'legacy'); assert.equal(next.optionalReview, false);
 assert.deepEqual(old, first); assert.equal(old.imageQuality, 'low'); assert.equal(old.imageConcurrency, 3);
 next.imageQuality = 'low'; old.imageConcurrency = 1;
 assert.equal(workflowGenerationPolicy(requirements)!.imageConcurrency, 3, 'callers cannot mutate the persisted snapshot through a returned object');
 assert.equal((await loadGenerationPolicy(store.env)).imageQuality, 'medium');
 assert.equal(store.calls.length, 3, 'snapshot access performs no settings load');
 assert.equal(workflowGenerationPolicy('{"request":"legacy task"}'), null);
});

test('optional review is independently switchable and does not require a target-sized wallet', () => {
 const policy = generationPolicySchema.parse({ costTargetMicros: 1, optionalReviewEstimateMicros: 0 });
 assert.equal(canStartOptionalReview(policy, 1), true);
 assert.equal(canStartOptionalReview({ ...policy, optionalReview: false }, 0), false);
 assert.equal(canStartOptionalReview({ ...policy, optionalReviewEstimateMicros: 1 }, 1), false);
});

test('invalid policy settings use a controlled error and never write configuration', async () => {
 for (const raw of ['{bad json', JSON.stringify({ imageConcurrency: 5 }), JSON.stringify({ imageQuality: 'high' }), JSON.stringify({ version: 'gp-next' }), JSON.stringify({ unknown: true })]) {
  const store = settings(raw);
  await assert.rejects(loadGenerationPolicy(store.env), (error: any) => error?.code === 'GENERATION_POLICY_INVALID' && error.status === 503, raw);
  assert.equal(store.calls.length, 1);
 }
});
