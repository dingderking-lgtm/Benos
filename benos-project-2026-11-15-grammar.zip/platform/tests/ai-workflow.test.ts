import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createWorkflow,sendDesignMessage,findDesignMessage,continueWorkflow,workflowQuote,workflowView,reconcileWorkflowStep,aiWorkflowRoutes,workflowAvailableAssets,type WorkflowInput } from '../src/modules/ai-workflow';
import { encryptSecret,randomToken,sha256 } from '../src/lib/crypto';
import { AppError } from '../src/lib/errors';
import { textReservationCost } from '../src/modules/ai-billing';
import { type App } from '../src/lib/http';
import { Hono } from 'hono';
import { saveVersion } from '../src/modules/ai';
import { grantCredit,fundProvider,getWallet,reserve } from '../src/modules/ledger';
import { saveMedia } from '../src/modules/media';
import { seedCapabilityFixture } from './integration-test-helper';
import { mediaFixture,png } from './media-helper';
import example from '../src/contracts/site-example.json';

const pricing={baseUrl:'https://api.openai.com/v1',model:'gpt-6.1-sol',protocol:'responses',providerPoolId:'openai-main',inputMicrosPerMillion:2_000_000,cachedInputMicrosPerMillion:100_000,outputMicrosPerMillion:10_000_000,contextTokens:1050000,maxOutputTokens:10000,billingProfile:'openai-gpt6-standard-2026-11-07',cacheTtl:'30m',pricingConfirmedAt:new Date().toISOString()};
const designPerStep=textReservationCost({...pricing,maxOutputTokens:24000} as never);
async function fixture(balance=50_000_000){const f=mediaFixture(),now=new Date().toISOString(),encrypted=await encryptSecret(JSON.stringify({apiKey:'sk-fixture-only'}),f.env.ENCRYPTION_KEY,'cfg');
 f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('cfg','text','AI','openai',1,'active',?,?,'passed','u',?)").run(JSON.stringify(pricing),encrypted,now);
 if(balance)await grantCredit(f.env.DB,{id:'g',userId:'u',source:'topup',amountMicros:balance,referenceId:'receipt'});await fundProvider(f.env.DB,{id:'f',providerId:'openai-main',amountMicros:100_000_000,referenceId:'deposit'});await seedCapabilityFixture(f.env.DB,'cfg');
 const quote=await workflowQuote(f.env,'u','p');assert.equal(quote.available,true);const input:WorkflowInput={requestKey:'workflow-request-001',prompt:'制作实际企业网站，主页标题改为 Benos 工作室',baseVersionId:null,scope:{kind:'site'},maxSteps:6,maxCostMicros:10_000_000,quoteHash:quote.quoteHash!,referenceMediaIds:[],confirmedCharge:true};return {...f,input};
}
const output=(name:string,args:unknown={})=>({id:'resp_'+name,model:pricing.model,service_tier:'default',status:'completed',usage:{input_tokens:100,output_tokens:20,input_tokens_details:{cached_tokens:50,cache_write_tokens:0,cache_write_tokens_details:{ttl_30m_tokens:0,ttl_12h_tokens:0}}},output:[{type:'reasoning',id:'rs_fixture',summary:[],encrypted_content:'opaque_fixture'},{type:'function_call',id:'fc_'+name,call_id:'call_'+name,name,arguments:JSON.stringify(args)}]});
function proposed(){const manifest=structuredClone(example);manifest.templates[0].document.html=manifest.templates[0].document.html.replace('首页结构示例','Benos 工作室');return manifest;}
const response=(name:string,args:unknown={})=>new Response(JSON.stringify(output(name,args)));

const message = {requestKey:'account-message-0001',prompt:'继续',baseVersionId:null,scope:{kind:'site'}};
const hasCode = (code:string) => (error:unknown) => error instanceof AppError && error.code === code;

test('direct send snapshots verified rates and account limits, uses historical top-up, and replays independently of current funds and model',async()=>{
 const f=await fixture(designPerStep);
 try{
  let calls=0;
  const runtime={fetch:async()=>{
   calls++;
   assert.equal((await getWallet(f.env.DB,'u')).heldMicros,designPerStep);
   assert.equal(f.db.sqlite.prepare("SELECT reserved_micros FROM provider_pools WHERE provider_id='openai-main'").get()!.reserved_micros,designPerStep);
   return response('read_project');
  }};
  const copies=await Promise.all(Array.from({length:8},()=>sendDesignMessage(f.env,'u','p',message,runtime)));
  const saved=await findDesignMessage(f.env,'u','p',message.requestKey);
  assert.equal(new Set(copies.map(copy=>copy.id)).size,1);assert.equal(calls,1);
  assert.equal(saved.requestPrompt,'继续');assert.equal(saved.requestOrigin,'account');
  assert.equal(saved.maxCostMicros,designPerStep);assert.equal(saved.maxSteps,24);
  assert.equal(saved.consumedMicros,305);assert.equal((await getWallet(f.env.DB,'u')).topupMicros,(designPerStep-305));
  assert.equal((await continueWorkflow(f.env,'u',saved.id,runtime,2)).state,'budget_exhausted');
  f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled' WHERE id='cfg'").run();
  assert.equal((await sendDesignMessage(f.env,'u','p',message,runtime)).id,saved.id);
  await assert.rejects(sendDesignMessage(f.env,'u','p',{...message,prompt:'不同需求'},runtime),hasCode('IDEMPOTENCY_CONFLICT'));
  await assert.rejects(sendDesignMessage(f.env,'u','p2',message,runtime),hasCode('IDEMPOTENCY_CONFLICT'));
  await assert.rejects(createWorkflow(f.env,'u','p',{...f.input,requestKey:message.requestKey},runtime),hasCode('IDEMPOTENCY_CONFLICT'));
  await assert.rejects(findDesignMessage(f.env,'other','p',message.requestKey),hasCode('NOT_FOUND'));
  await assert.rejects(findDesignMessage(f.env,'u','p2',message.requestKey),hasCode('NOT_FOUND'));
  assert.equal(calls,1);
 }finally{f.db.close();}
});

test('a short provider pool no longer refuses a direct send; an unknown response is never sent again',async()=>{
 const f=await fixture();
 try{
  f.db.sqlite.prepare("UPDATE provider_pools SET safety_micros=funded_micros-? WHERE provider_id='openai-main'").run(designPerStep);
  let calls=0;const runtime={fetch:async()=>{calls++;throw new Error('fixture lost response');}};
  const rows=await Promise.all(['p','p2'].map(project=>sendDesignMessage(f.env,'u',project,{...message,requestKey:'unknown-message-'+project},runtime)));
  const held=rows[0];
  // A message task is never parked for a cost check: the lost round is closed on an estimate, nothing stays on
  // hold, and the same round can be asked again.
  assert.deepEqual(rows.map(row=>row.state),['processing','processing']);assert.deepEqual(rows.map(row=>row.recoverable),[true,true]);assert.deepEqual(rows.map(row=>row.heldMicros),[0,0]);
  assert.ok(held.consumedMicros>0&&held.consumedMicros<designPerStep,'the estimate is charged, the rest is returned');
  assert.equal(held.maxCostMicros,50_000_000,'the wallet is the only limit of a message');assert.equal(calls,2);
  assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM provider_funding WHERE reference_id LIKE 'auto:%'").get()!.n,1);
  const requestKey='unknown-message-'+held.projectId;
  assert.equal((await sendDesignMessage(f.env,'u',held.projectId,{...message,requestKey},runtime)).id,held.id);
  assert.equal((await findDesignMessage(f.env,'u',held.projectId,requestKey)).state,'processing');assert.equal(calls,2,'reading a task never sends anything');
 }finally{f.db.close();}
});

test('different account messages cannot both use the last available top-up allowance',async()=>{
 const f=await fixture(designPerStep);
 try{
  let calls=0;const runtime={fetch:async()=>{calls++;throw new Error('fixture unknown cost');}};
  const attempts=await Promise.allSettled(['p','p2'].map(project=>sendDesignMessage(f.env,'u',project,
   {...message,requestKey:'wallet-contention-'+project},runtime)));
  const outcomes=attempts.map(attempt=>attempt.status==='fulfilled'?(attempt.value.errorCode??attempt.value.state):(attempt.reason as AppError).code);
  assert.ok(outcomes.includes('INSUFFICIENT_CREDIT'));assert.ok(outcomes.includes('processing'));assert.equal(calls,1);
  // The round that was sent and lost is closed on an estimate at once: nothing is left on hold.
  const wallet=await getWallet(f.env.DB,'u');assert.equal(wallet.heldMicros,0);assert.ok(wallet.availableMicros>0&&wallet.availableMicros<designPerStep);
  assert.equal(f.db.sqlite.prepare("SELECT reserved_micros FROM provider_pools WHERE provider_id='openai-main'").get()!.reserved_micros,0);
 }finally{f.db.close();}
});

test('direct HTTP endpoints authenticate, reject client billing fields, lookup legacy receipts and fail before dispatch on insufficient funds',async t=>{
 const f=await fixture();
 try{
  const legacy=await createWorkflow(f.env,'u','p',f.input,{fetch:async()=>response('read_project')});
  const token=randomToken(),now=new Date().toISOString();
  f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)')
   .run('account-message-session','u',await sha256(token),'csrf',now,new Date(Date.now()+3600000).toISOString(),'fixture');
  const app=new Hono<App>();app.onError((err,c)=>c.json({code:(err as AppError).code},(err instanceof AppError?err.status:500) as any));app.route('/api/ai',aiWorkflowRoutes);
  const headers={'Content-Type':'application/json','Cookie':'benos_session='+token,'X-CSRF-Token':'csrf'};
  const path='/api/ai/projects/p/messages',send=(input:unknown,auth:Record<string,string>=headers)=>app.request(path,{method:'POST',headers:auth,body:JSON.stringify(input)},f.env);
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return response('read_project');});
  assert.equal((await send(message,{'Content-Type':'application/json'})).status,401);
  assert.equal((await send(message,{...headers,'X-CSRF-Token':'incorrect'})).status,403);
  for(const key of ['confirmedCharge','maxSteps','maxCostMicros','quoteHash','userId','providerId']){
   assert.equal((await send({...message,[key]:key==='confirmedCharge'?true:'client setting'})).status,400);
  }
  const lookup=await app.request(path+'/'+f.input.requestKey,{headers},f.env);
  assert.equal(lookup.status,200);const old=(await lookup.json() as any).data;assert.equal(old.id,legacy.id);assert.equal(old.requestOrigin,'quoted');
  assert.equal((await send({...message,requestKey:f.input.requestKey})).status,409);
  const sent=await send(message);assert.equal(sent.status,202);
  const direct=(await sent.json() as any).data;assert.equal(direct.requestOrigin,'account');assert.ok(direct.maxCostMicros>10_800_000,'no per-message cap below the wallet');
  assert.equal((await (await app.request(path+'/'+message.requestKey,{headers},f.env)).json() as any).data.id,direct.id);
  const balance=(await getWallet(f.env.DB,'u')).availableMicros;
  await reserve(f.env.DB,{id:'another-budget-hold',userId:'u',providerId:'openai-main',amountMicros:balance-1000,requestKey:'other-known-reservation'});
  const insufficient=await send({...message,requestKey:'account-low-funds-0001'});assert.equal(insufficient.status,409);assert.equal((await insufficient.json() as any).code,'INSUFFICIENT_CREDIT');
  assert.equal((await app.request(path+'/account-low-funds-0001',{headers},f.env)).status,404);assert.equal(calls,1);
 }finally{f.db.close();}
});

test('a follow-up restores the original message and sends only this project’s prior turns to the model', async () => {
  const f = await fixture();
  try {
    const runtime = { fetch: async () => response('read_project') };
    const firstPrompt = '把产品目录放在导航第一项';
    const first = await createWorkflow(f.env, 'u', 'p', { ...f.input, maxSteps: 1, prompt: firstPrompt }, runtime);
    await createWorkflow(f.env, 'u', 'p2', { ...f.input, maxSteps: 1, requestKey: 'other-project-turn-001', prompt: '另一个站点的私人需求' }, runtime);
    const original = await workflowView(f.env, 'u', first.id);
    assert.equal(original.requestPrompt, firstPrompt);
    assert.deepEqual(original.referenceMediaIds, []);
    assert.equal(original.referenceMode, 'none');
    await assert.rejects(() => workflowView(f.env, 'other', first.id), /不存在/);

    let seen = false;
    await createWorkflow(f.env, 'u', 'p', { ...f.input, maxSteps: 1, requestKey: 'follow-up-turn-002', prompt: '把刚才那一项改名为作品目录' }, {
      fetch: async (_url, init) => {
        const body = JSON.parse(String(init?.body));
        const brief = JSON.parse(body.input[0].content[0].text);
        assert.deepEqual(brief.previousRequests.map((turn: {request: string}) => turn.request), [firstPrompt]);
        assert.equal(brief.previousRequests[0].workflowState, first.state);
        assert.equal(brief.previousRequests[0].candidateState, null);
        seen = true;
        return response('read_project');
      },
    });
    assert.equal(seen, true);
  } finally { f.db.close(); }
});

test('three separately funded tool rounds create a candidate, replay reasoning, and never adopt current design',async()=>{
 const f=await fixture();try{let calls=0;const send:typeof fetch=async(_url,init)=>{calls++;const p=JSON.parse(String(init?.body));assert.equal(p.parallel_tool_calls,false);assert.equal(p.store,false);assert.deepEqual(p.include,['reasoning.encrypted_content']);assert.equal(p.tool_choice,'required');assert.ok(p.tools.every((x:any)=>x.type==='function'&&x.strict===true));assert.equal(f.db.sqlite.prepare("SELECT reserved_micros FROM provider_pools").get()!.reserved_micros,designPerStep);if(calls===1)return response('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(proposed())}]});assert.equal(p.input[1].encrypted_content,'opaque_fixture');assert.equal(p.input[2].type,'function_call');assert.equal(p.input[3].type,'function_call_output');assert.equal(p.input[3].call_id,'call_propose_files');return calls===2?response('check_preview'):response('finish');};
 let w=await createWorkflow(f.env,'u','p',f.input,{fetch:send});assert.equal(w.state,'ready');assert.equal(w.consumedMicros,305);w=await continueWorkflow(f.env,'u',w.id,{fetch:send},2);assert.equal(w.state,'ready');w=await continueWorkflow(f.env,'u',w.id,{fetch:send},3);assert.equal(w.state,'succeeded');assert.ok(w.candidateId);assert.equal(w.stepsUsed,3);assert.equal(w.consumedMicros,915);assert.equal(w.heldMicros,0);assert.equal(calls,3);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,915);assert.equal(f.db.sqlite.prepare('SELECT current_version_id FROM projects WHERE id=?').get('p')!.current_version_id,null);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_candidates').get()!.n,1);
 assert.equal((await createWorkflow(f.env,'u','p',f.input,{fetch:send})).id,w.id);assert.equal((await continueWorkflow(f.env,'u',w.id,{fetch:send},3)).state,'succeeded');assert.equal(calls,3);
 await assert.rejects(()=>createWorkflow(f.env,'u','p',{...f.input,prompt:'另一个需求'},{fetch:send}),/请求编号/);
 }finally{f.db.close();}
});

test('concurrent creation and exact step replays cannot advance another paid round',async()=>{
 const f=await fixture();try{let calls=0;const send:typeof fetch=async()=>{calls++;return response('read_project');};const initial=await Promise.all(Array.from({length:8},()=>createWorkflow(f.env,'u','p',f.input,{fetch:send})));assert.equal(new Set(initial.map(x=>x.id)).size,1);assert.equal(calls,1);const workflowId=initial[0].id;await Promise.all(Array.from({length:8},()=>continueWorkflow(f.env,'u',workflowId,{fetch:send},2)));assert.equal(calls,2);await continueWorkflow(f.env,'u',workflowId,{fetch:send},2);assert.equal(calls,2);assert.equal((await workflowView(f.env,'u',workflowId)).stepsUsed,2);
 }finally{f.db.close();}
});

test('task cap stops the next reservation despite sufficient wallet and provider money',async()=>{
 const f=await fixture();try{let calls=0;const send:typeof fetch=async()=>{calls++;return response('read_project');};await assert.rejects(()=>createWorkflow(f.env,'u','p',{...f.input,maxCostMicros:(designPerStep-1)},{fetch:send}),new RegExp(String(designPerStep)));assert.equal(calls,0);const w=await createWorkflow(f.env,'u','p',{...f.input,maxCostMicros:designPerStep},{fetch:send});assert.equal(w.state,'ready');const done=await continueWorkflow(f.env,'u',w.id,{fetch:send},2);assert.equal(done.state,'budget_exhausted');assert.equal(done.consumedMicros,305);assert.equal(calls,1);assert.equal(done.heldMicros,0);
 }finally{f.db.close();}
});

test('SQL budget trigger serializes competing reservations within the existing ledger transaction',async()=>{
 const f=await fixture();try{const w=await createWorkflow(f.env,'u','p',{...f.input,maxCostMicros:(designPerStep+305)},{fetch:async()=>response('read_project')});f.db.sqlite.prepare("UPDATE ai_workflows SET state='processing' WHERE id=?").run(w.id);for(const n of [2,3])f.db.sqlite.prepare('INSERT INTO ai_workflow_steps(id,workflow_id,ordinal,reservation_id,created_at,updated_at) VALUES(?,?,?,?,?,?)').run('s'+n,w.id,n,'r'+n,new Date().toISOString(),new Date().toISOString());
 const results=await Promise.allSettled([2,3].map(n=>reserve(f.env.DB,{id:'r'+n,userId:'u',providerId:'openai-main',amountMicros:designPerStep,requestKey:'workflow-budget-'+n})));assert.equal(results.filter(x=>x.status==='fulfilled').length,1);assert.equal(results.filter(x=>x.status==='rejected').length,1);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,designPerStep);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,designPerStep);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM ledger_commands WHERE status='pending'").get()!.n,0);
 }finally{f.db.close();}
});

test('unknown network cost stops the workflow, retains both holds and never retries HTTP',async()=>{
 const f=await fixture();try{let calls=0;const send:typeof fetch=async()=>{calls++;throw new Error('ack lost');};const w=await createWorkflow(f.env,'u','p',f.input,{fetch:send});assert.equal(w.state,'uncertain');assert.equal(w.heldMicros,designPerStep);await continueWorkflow(f.env,'u',w.id,{fetch:send},1);assert.equal(calls,1);
 f.db.sqlite.prepare("UPDATE ai_workflows SET state='processing',lease_until_ms=0 WHERE id=?").run(w.id);const retry=await continueWorkflow(f.env,'u',w.id,{fetch:send},1);assert.equal(retry.state,'uncertain');assert.equal(calls,1);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,designPerStep);
 }finally{f.db.close();}
});

for(const status of [302,307])test(`provider ${status} redirect preserves workflow holds and cannot replay the paid request`,async()=>{
 const f=await fixture();
 try{
  let calls=0;
  const send:typeof fetch=async(url,init)=>{
   calls++;
   assert.equal(String(url),pricing.baseUrl+'/responses');
   assert.equal(init?.method,'POST');
   assert.equal(init?.redirect,'manual');
   assert.equal((init?.headers as Record<string,string>).Authorization,'Bearer sk-fixture-only');
   return new Response('redirect body must not become billing evidence',{status,headers:{Location:'https://untrusted.example.test/collect'}});
  };
  const first=await createWorkflow(f.env,'u','p',f.input,{fetch:send});
  assert.equal(first.state,'uncertain');assert.equal(first.errorCode,'AI_PROVIDER_UNCERTAIN');
  assert.equal(first.heldMicros,designPerStep);assert.equal(first.consumedMicros,0);
  const replay=await createWorkflow(f.env,'u','p',f.input,{fetch:send});
  assert.equal(replay.id,first.id);assert.equal(replay.state,'uncertain');
  const continued=await continueWorkflow(f.env,'u',first.id,{fetch:send},1);
  assert.equal(continued.state,'uncertain');assert.equal(calls,1);
  const wallet=await getWallet(f.env.DB,'u');
  assert.equal(wallet.heldMicros,designPerStep);assert.equal(wallet.consumedMicros,0);
  const pool=f.db.sqlite.prepare("SELECT reserved_micros,consumed_micros FROM provider_pools WHERE provider_id='openai-main'").get()!;
  assert.equal(pool.reserved_micros,designPerStep);assert.equal(pool.consumed_micros,0);
  const step=f.db.sqlite.prepare('SELECT state,response_json FROM ai_workflow_steps WHERE workflow_id=?').get(first.id)!;
  assert.equal(step.state,'uncertain');assert.equal(step.response_json,null);
 }finally{f.db.close();}
});

test('persisted response acknowledgement loss is recovered locally, including after disabling old config',async()=>{
 const f=await fixture();try{let calls=0,once=true;const original=f.env.DB.prepare.bind(f.env.DB);f.env.DB.prepare=((sql:string)=>{const statement=original(sql);if(sql.includes("state='responded',response_json=")){const bind=statement.bind.bind(statement);statement.bind=((...args:any[])=>{const bound=bind(...args),run=bound.run.bind(bound);bound.run=(async()=>{const result=await run();if(once){once=false;throw new Error('lost write acknowledgement');}return result;}) as any;return bound;}) as any;}return statement;}) as any;
 const send:typeof fetch=async()=>{calls++;return response('read_project');};let w=await createWorkflow(f.env,'u','p',f.input,{fetch:send});assert.equal(w.state,'processing');assert.equal(w.recoverable,true);assert.equal(w.heldMicros,designPerStep);f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled' WHERE id='cfg'").run();w=await continueWorkflow(f.env,'u',w.id,{fetch:send},1);assert.equal(w.state,'ready');assert.equal(w.consumedMicros,305);assert.equal(w.heldMicros,0);assert.equal(calls,1);
 }finally{f.db.close();}
});

test('private reference image bytes are sent as input_image; foreign project IDs fail before charging',async()=>{
 const f=await fixture();try{const own=await saveMedia(f.env,'u','p',{bytes:png(),fileName:'reference.png',requestKey:'reference-image-1'}),other=await saveMedia(f.env,'u','p2',{bytes:png(),fileName:'other.png',requestKey:'reference-image-2'});let calls=0;const send:typeof fetch=async(_url,init)=>{calls++;const input=JSON.parse(String(init?.body)).input[0].content;assert.equal(input[1].type,'input_image');assert.equal(input[1].image_url,'data:image/png;base64,'+Buffer.from(png()).toString('base64'));assert.ok(!JSON.stringify(input).includes('private/users'));return response('read_project');};
 await assert.rejects(()=>createWorkflow(f.env,'u','p',{...f.input,referenceMediaIds:[other.id]},{fetch:send}),/参考图必须/);assert.equal(calls,0);const w=await createWorkflow(f.env,'u','p',{...f.input,referenceMediaIds:[own.id]},{fetch:send});assert.equal(w.referenceMode,'model-input-image');assert.equal(calls,1);
 const receipt=await workflowView(f.env,'u',w.id);
 assert.deepEqual(receipt.referenceMediaIds,[own.id]);assert.deepEqual(w.referenceMediaIds,receipt.referenceMediaIds);
 const serialized=JSON.stringify(receipt);
 assert.doesNotMatch(serialized,/private\/users\/|data:image\//);assert.ok(!serialized.includes(own.sha256));
 await assert.rejects(()=>workflowView(f.env,'other',w.id),/不存在/);
 }finally{f.db.close();}
});

test('a small AI manifest can validate more than 6 MiB of owned media without sending those bytes to the model',async()=>{
 const f=await fixture();try{
  const bytes=new Uint8Array(execFileSync('python',['-c','import io,sys,random;from PIL import Image\nim=Image.frombytes("RGB",(1600,1600),random.Random(537).randbytes(1600*1600*3));out=io.BytesIO();im.save(out,format="PNG",compress_level=0);b=out.getvalue();Image.open(io.BytesIO(b)).load();sys.stdout.buffer.write(b)'],{maxBuffer:12*1048576}));assert.ok(bytes.length>6*1048576);
  const media=await saveMedia(f.env,'u','p',{bytes,fileName:'large-site-image.png',requestKey:'workflow-large-owned-image'}),manifest={...structuredClone(example),assets:[{file:'assets/0.png',path:media.assetPath,sha256:media.sha256,size:media.byteSize}]};manifest.templates[0].document.html+=`<img src="${media.assetPath}" alt="图片">`;
  const base=await saveVersion(f.env,'u','p',manifest,'manual',null,'workflow-large-image-base');let calls=0;const send:typeof fetch=async(_url,init)=>{calls++;const payload=String(init?.body);assert.ok(payload.length<600000);assert.doesNotMatch(payload,/data:image|private\/users/);return calls===1?response('propose_files',{files:[{path:'templates/1.html',content:manifest.templates[0].document.html+'<p>Updated design</p>'}]}):response(calls===2?'check_preview':'finish');};
  let w=await createWorkflow(f.env,'u','p',{...f.input,quoteHash:(await workflowQuote(f.env,'u','p')).quoteHash!,baseVersionId:base},{fetch:send});w=await continueWorkflow(f.env,'u',w.id,{fetch:send},2);assert.equal(w.steps[1].tools[0].ok,true);w=await continueWorkflow(f.env,'u',w.id,{fetch:send},3);assert.equal(w.state,'succeeded');assert.ok(w.candidateId);assert.equal(calls,3);assert.equal(f.db.sqlite.prepare("SELECT current_version_id FROM projects WHERE id='p'").get()!.current_version_id,base);assert.equal(w.heldMicros,0);assert.equal(w.consumedMicros,915);
 }finally{f.db.close();}
});

test('later uploads reuse the original manifest asset metadata and allocate collision-free files',async()=>{
 const f=await fixture();try{
  const old=await saveMedia(f.env,'u','p',{bytes:png(),fileName:'original.png',requestKey:'old-project-image'});
  const original={...structuredClone(example),assets:[{file:'assets/0.png',path:'/uploads/2025/01/'+old.sha256+'.png',sha256:old.sha256,size:old.byteSize,media_id:7}]};
  const base=await saveVersion(f.env,'u','p',original,'manual',null,'base-with-original');
  const newer=await saveMedia(f.env,'u','p',{bytes:png(2,1),fileName:'newer.png',requestKey:'new-project-image'});
  f.db.sqlite.prepare("UPDATE project_media SET created_at='2026-12-01T00:00:00Z' WHERE id=?").run(newer.id);
  let w=await createWorkflow(f.env,'u','p',{...f.input,quoteHash:(await workflowQuote(f.env,'u','p')).quoteHash!,baseVersionId:base},{fetch:async()=>response('read_project')});
  const available=JSON.parse(String(f.db.sqlite.prepare('SELECT requirements_json FROM ai_workflows WHERE id=?').get(w.id)!.requirements_json)).availableAssets;
  assert.deepEqual(available[0].asset,original.assets[0]);assert.equal(available[0].id,old.id);
  assert.equal(available[1].id,newer.id);assert.equal(available[1].asset.file,'assets/1.png');assert.equal(new Set(available.map((x:any)=>x.asset.file)).size,2);
  const next={...original,assets:available.map((x:any)=>x.asset)};
  w=await continueWorkflow(f.env,'u',w.id,{fetch:async()=>response('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(next)}]})},2);
  w=await continueWorkflow(f.env,'u',w.id,{fetch:async()=>response('check_preview')},3);
  assert.equal(w.steps[2].tools[0].ok,true,String(f.db.sqlite.prepare('SELECT tool_results_json FROM ai_workflow_steps WHERE workflow_id=? AND ordinal=3').get(w.id)!.tool_results_json));
 }finally{f.db.close();}
});

test('available media is deduplicated and the shared base/new inventory stays within 64 assets',()=>{
 const media=Array.from({length:80},(_,n)=>({id:'m'+n,fileName:'image.png',width:1,height:1,extension:'png',assetPath:'/uploads/2026/11/'+n+'.png',sha256:String(n).padStart(64,'0'),byteSize:67})) as any;
 const existing=[{file:'assets/0.png',path:'/uploads/2025/01/existing.png',sha256:media[0].sha256,size:67}];
 const mapped=workflowAvailableAssets([media[1],{...media[1],id:'duplicate'},...media],existing);
 assert.equal(mapped.length,64);assert.deepEqual(mapped[0].asset,existing[0]);assert.equal(new Set(mapped.map(m=>m.asset.sha256)).size,64);assert.equal(new Set(mapped.map(m=>m.asset.file)).size,64);
});

test('tools cannot escape virtual paths, execute arbitrary functions, or claim unchecked completion',async()=>{
 const f=await fixture();try{let n=0;const send:typeof fetch=async()=>{n++;return n===1?response('read_file',{path:'../../.env'}):n===2?response('run_shell',{command:'whoami'}):response('finish');};let w=await createWorkflow(f.env,'u','p',{...f.input,maxSteps:3},{fetch:send});assert.equal(w.steps[0].tools[0].code,'WORKFLOW_PATH_DENIED');w=await continueWorkflow(f.env,'u',w.id,{fetch:send},2);assert.equal(w.steps[1].tools[0].code,'WORKFLOW_TOOL_DENIED');w=await continueWorkflow(f.env,'u',w.id,{fetch:send},3);assert.equal(w.steps[2].tools[0].code,'PREVIEW_CHECK_REQUIRED');assert.equal(w.state,'steps_exhausted');assert.equal(w.candidateId,null);assert.equal(n,3);await continueWorkflow(f.env,'u',w.id,{fetch:send},4);assert.equal(n,3);
 }finally{f.db.close();}
});

test('insufficient wallet and restriction applied between rounds prevent paid dispatch',async()=>{
 const f=await fixture(1);try{let calls=0;const send:typeof fetch=async()=>{calls++;return response('read_project');};const failed=await createWorkflow(f.env,'u','p',f.input,{fetch:send});assert.equal(failed.errorCode,'INSUFFICIENT_CREDIT');assert.equal(calls,0);assert.equal(failed.heldMicros,0);await grantCredit(f.env.DB,{id:'more',userId:'u',source:'topup',amountMicros:10_000_000,referenceId:'more'});const w=await createWorkflow(f.env,'u','p',{...f.input,requestKey:'workflow-request-002'},{fetch:send});assert.equal(calls,1);f.db.sqlite.prepare("UPDATE users SET status='restricted' WHERE id='u'").run();const stopped=await continueWorkflow(f.env,'u',w.id,{fetch:send},2);assert.equal(stopped.errorCode,'ACCOUNT_RESTRICTED');assert.equal(calls,1);assert.equal(stopped.heldMicros,0);
 }finally{f.db.close();}
});

test('missing or contradictory usage suspends the provider pool and preserves the original reservation',async()=>{
 const f=await fixture();try{let calls=0;const send:typeof fetch=async()=>{calls++;const out:any=output('read_project');delete out.usage;return new Response(JSON.stringify(out));};const w=await createWorkflow(f.env,'u','p',f.input,{fetch:send});assert.equal(w.state,'uncertain');assert.equal(w.errorCode,'AI_USAGE_INVALID');assert.equal(w.heldMicros,designPerStep);assert.equal(f.db.sqlite.prepare('SELECT enabled FROM provider_pools').get()!.enabled,0);assert.equal(calls,1);
 }finally{f.db.close();}
});

test('owner reconciliation is idempotent, rejects contradictory cost, never dispatches or resumes the task',async()=>{
 const f=await fixture();try{let calls=0;const send:typeof fetch=async()=>{calls++;throw new Error('fixture unknown');};let w=await createWorkflow(f.env,'u','p',f.input,{fetch:send});const step=w.steps[0].id;
 await assert.rejects(()=>reconcileWorkflowStep(f.env,'u',step,{outcome:'confirmed_cost',actualMicros:150,evidence:'供应商已逐单核对 fixture only'}),(e:unknown)=>e instanceof AppError&&e.code==='FORBIDDEN');f.db.sqlite.prepare("UPDATE users SET role='owner' WHERE id='u'").run();const command={outcome:'confirmed_cost' as const,actualMicros:150,evidence:'供应商已逐单核对 fixture only'};await reconcileWorkflowStep(f.env,'u',step,command);await reconcileWorkflowStep(f.env,'u',step,command);await assert.rejects(()=>reconcileWorkflowStep(f.env,'u',step,{...command,actualMicros:151}));
 w=await continueWorkflow(f.env,'u',w.id,{fetch:send},1);assert.equal(calls,1);assert.equal(w.state,'failed');assert.equal(w.errorCode,'COST_RECONCILED');assert.equal(w.heldMicros,0);assert.equal(w.consumedMicros,150);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,150);
 }finally{f.db.close();}
});

test('administrative steps require role, expose bounded pricing/usage metadata and accept exact pagination filters',async()=>{
 const f=await fixture();try{const w=await createWorkflow(f.env,'u','p',f.input,{fetch:async()=>{throw new Error('unknown');}}),token=randomToken();f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session','u',await sha256(token),'csrf',new Date().toISOString(),new Date(Date.now()+3600000).toISOString(),'fixture');const app=new Hono<App>();app.onError((e,c)=>c.json({error:(e as AppError).code},(e instanceof AppError?e.status:500) as any));app.route('/api/ai',aiWorkflowRoutes);const headers={Cookie:'benos_session='+token};
 assert.equal((await app.request('/api/ai/admin/workflow-steps',{headers},f.env)).status,403);f.db.sqlite.prepare("UPDATE users SET role='admin' WHERE id='u'").run();const response=await app.request('/api/ai/admin/workflow-steps?page=1&limit=1&state=uncertain&userId=u',{headers},f.env);assert.equal(response.status,200);const text=await response.text(),data=JSON.parse(text).data;assert.equal(data.items.length,1);assert.equal(data.items[0].workflowId,w.id);assert.equal(data.items[0].reservedMicros,designPerStep);assert.equal(data.items[0].pricing.model,pricing.model);assert.equal(data.hasMore,false);assert.ok(!text.includes('sk-fixture'));assert.ok(!text.includes('secret_ciphertext'));assert.ok(!text.includes('encrypted_content'));assert.equal((await app.request('/api/ai/admin/workflow-steps/'+w.steps[0].id+'/reconcile',{method:'POST',headers:{...headers,'Content-Type':'application/json','X-CSRF-Token':'csrf'},body:JSON.stringify({outcome:'confirmed_unused',evidence:'fixture evidence only'})},f.env)).status,403);
 }finally{f.db.close();}
});

test('selected node cannot mutate sibling templates and remains unchanged until user adoption',async()=>{
 const f=await fixture();try{const base=await saveVersion(f.env,'u','p',example,'manual',null,'fixture-base'),changed=proposed();changed.templates[1].document.html+='<p>越界修改</p>';const w=await createWorkflow(f.env,'u','p',{...f.input,quoteHash:(await workflowQuote(f.env,'u','p')).quoteHash!,baseVersionId:base,scope:{kind:'node',templateId:1,nodeKey:'n0'}},{fetch:async()=>response('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(changed)}]})});assert.equal(w.steps[0].tools[0].ok,false);assert.equal(w.steps[0].tools[0].code,'DESIGN_SCOPE');assert.equal(f.db.sqlite.prepare('SELECT current_version_id FROM projects WHERE id=?').get('p')!.current_version_id,base);assert.equal(f.db.sqlite.prepare('SELECT manifest_json FROM ai_workflows WHERE id=?').get(w.id)!.manifest_json,JSON.stringify(example));
 }finally{f.db.close();}
});

test('invalid structure is reported by preview check, repaired in virtual files and saved only after a fresh pass',async()=>{
 const f=await fixture();try{let count=0;const broken=proposed();broken.templates[0].document.html='<section><script>alert(1)</script></section>';const send:typeof fetch=async()=>{count++;return count===1?response('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(broken)}]}):count===2?response('check_preview'):count===3?response('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(proposed())}]}):count===4?response('check_preview'):response('finish');};let w=await createWorkflow(f.env,'u','p',f.input,{fetch:send});w=await continueWorkflow(f.env,'u',w.id,{fetch:send},2);assert.equal(w.steps[1].tools[0].ok,false);const report=JSON.parse(String(f.db.sqlite.prepare('SELECT tool_results_json FROM ai_workflow_steps WHERE workflow_id=? AND ordinal=2').get(w.id)!.tool_results_json))[0].result;assert.equal(report.browserRendered,false);assert.ok(report.issues.some((issue:any)=>issue.severity==='error'));for(const n of [3,4,5])w=await continueWorkflow(f.env,'u',w.id,{fetch:send},n);assert.equal(w.state,'succeeded');assert.ok(w.candidateId);assert.equal(count,5);
 }finally{f.db.close();}
});

test('a rejected null manifest cannot turn the seed into a candidate and remains repairable',async()=>{
 const f=await fixture();try{let n=0;const send:typeof fetch=async()=>{n++;return n===1?response('propose_files',{files:[{path:'manifest.json',content:'null'}]}):n===2||n===5?response('check_preview'):n===3||n===6?response('finish'):response('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(proposed())}]});};
 let w=await createWorkflow(f.env,'u','p',f.input,{fetch:send});assert.equal(w.steps[0].tools[0].ok,false);assert.equal(w.candidateId,null);
 w=await continueWorkflow(f.env,'u',w.id,{fetch:send},2);assert.equal(w.candidateId,null);
 w=await continueWorkflow(f.env,'u',w.id,{fetch:send},3);assert.equal(w.steps[2].tools[0].code,'WORKFLOW_NO_CHANGES');assert.equal(w.candidateId,null);
 w=await continueWorkflow(f.env,'u',w.id,{fetch:send},4);assert.equal(w.steps[3].tools[0].ok,true);
 for(const ordinal of [5,6])w=await continueWorkflow(f.env,'u',w.id,{fetch:send},ordinal);
 assert.equal(w.state,'succeeded');assert.ok(w.candidateId);assert.equal(n,6);const saved=JSON.parse(String(f.db.sqlite.prepare('SELECT manifest_json FROM ai_workflows WHERE id=?').get(w.id)!.manifest_json));assert.match(saved.templates[0].document.html,/Benos 工作室/);
 }finally{f.db.close();}
});



test('a message-started task is not cut off at the old six-step limit: step seven reserves and runs like any other',async()=>{
 const f=await fixture();
 try{
  let calls=0;const runtime={fetch:(async()=>{calls++;return response('read_project');}) as typeof fetch};
  let w=await sendDesignMessage(f.env,'u','p',{...message,requestKey:'past-six-steps-0001'},runtime);
  for(let step=2;step<=8;step++)w=await continueWorkflow(f.env,'u',w.id,runtime,step);
  assert.equal(w.state,'ready');assert.equal(w.stepsUsed,8);assert.equal(w.errorCode,null);assert.equal(calls,8);assert.equal(w.maxSteps,24);
  assert.deepEqual(w.steps.map((step:any)=>step.state),Array(8).fill('completed'));
 }finally{f.db.close();}
});

test('a written design is corrected in place: a second whole-site write is refused and edit_file fixes the reported issue',async()=>{
 const f=await fixture();
 try{
  const broken=proposed(),id=broken.templates[0].id;broken.templates[0].document.html+='<script>alert(1)</script>';
  let calls=0;const runtime={fetch:(async()=>{calls++;
   if(calls===1)return response('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(broken)}]});
   if(calls===2)return response('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(proposed())}]});
   return response('edit_file',{path:`templates/${id}.html`,edits:[{find:'<script>alert(1)</script>',replace:''}]});}) as typeof fetch};
  let w=await sendDesignMessage(f.env,'u','p',{...message,requestKey:'no-rewrite-test-0001'},runtime);
  assert.equal(w.state,'ready','a design that fails its check is not saved');assert.equal(w.candidateId,null);
  w=await continueWorkflow(f.env,'u',w.id,runtime,2);
  assert.equal(w.state,'ready');assert.deepEqual(w.steps[1].tools.map(({name,ok,code}:{name:string;ok:boolean;code:string|null})=>({name,ok,code})),[{name:'propose_files',ok:false,code:'WORKFLOW_REWRITE_DENIED'}]);
  w=await continueWorkflow(f.env,'u',w.id,runtime,3);
  assert.equal(w.state,'succeeded');assert.ok(w.candidateId);assert.deepEqual(w.steps[2].tools.map(({name,ok,code}:{name:string;ok:boolean;code:string|null})=>({name,ok,code})),[{name:'edit_file',ok:true,code:null}]);assert.equal(calls,3);
  const saved=JSON.parse(String(f.db.sqlite.prepare('SELECT manifest_json FROM design_candidates WHERE id=?').get(w.candidateId)!.manifest_json));
  assert.doesNotMatch(JSON.stringify(saved),/<script>/);
 }finally{f.db.close();}
});
