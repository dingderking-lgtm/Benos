import test from 'node:test';
import assert from 'node:assert/strict';
import { ensureTusUpload,type TusCheckpoint,type TusUploadInput } from '../src/modules/hosting-tus';
import { sha256 } from '../src/lib/crypto';

async function fixture(){
 const bytes=new TextEncoder().encode('trusted archive fixture'),hash=await sha256(bytes);
 let checkpoint:TusCheckpoint|undefined;
 const saved:TusCheckpoint[]=[];
 const input:TusUploadInput={apiToken:'secret-api',accountUsername:'u12345678',domain:'client.example.com',relativePath:`benos-release-${hash}.zip`,bytes,sha256:hash,persist:async v=>{checkpoint={...v};saved.push({...v});}};
 let exists=false,offset=0,post=0,patch=0,losePost=false,losePatch=false,preexisting=false,length=bytes.length;
 const send:typeof fetch=async(url:any,init?:RequestInit)=>{
  const u=String(url),method=init?.method,headers=new Headers(init?.headers);
  assert.equal(init?.redirect,'manual');
  if(u==='https://developers.hostinger.com/api/hosting/v1/files/upload-urls'){
   assert.deepEqual(JSON.parse(String(init?.body)),{username:input.accountUsername,domain:input.domain});assert.equal(headers.get('authorization'),'Bearer secret-api');
   return Response.json({url:'https://files.provider-domain.com/tus',auth_key:'secret-x',rest_auth_key:'secret-rest'});
  }
  assert.equal(u,`https://files.provider-domain.com/tus/${input.relativePath}`);assert.equal(headers.get('X-Auth'),'secret-x');assert.equal(headers.get('X-Auth-Rest'),'secret-rest');assert.equal(headers.get('authorization'),null);assert.equal(headers.get('Tus-Resumable'),'1.0.0');assert.equal(new URL(u).search,'');
  const progress=()=>({'Tus-Resumable':'1.0.0','Upload-Offset':String(offset),'Upload-Length':String(length)});
  if(method==='HEAD')return new Response(null,{status:exists||preexisting?200:404,headers:exists||preexisting?progress():{}});
  if(method==='POST'){assert.equal(checkpoint?.attempted,true,'persist creation intent before network');assert.equal(exists||preexisting,false);post++;exists=true;if(losePost){losePost=false;throw new Error('lost secret-x acknowledgement');}return new Response(null,{status:201,headers:{Location:u}});}
  if(method==='PATCH'){patch++;assert.equal(Number(headers.get('Upload-Offset')),offset);const chunk=init?.body as Uint8Array;assert.deepEqual([...chunk],[...bytes.subarray(offset,offset+chunk.length)]);if(losePatch){losePatch=false;offset+=Math.min(2,chunk.length);throw new Error('lost secret-rest patch response');}offset+=chunk.length;return new Response(null,{status:204,headers:progress()});}
  throw Error('unexpected method');
 };
 return {input,saved,send,get checkpoint(){return checkpoint;},get stats(){return {post,patch,offset};},loseCreate:()=>{losePost=true;},loseChunk:()=>{losePatch=true;},setPreexisting:()=>{preexisting=true;},setLength:(n:number)=>{length=n;}};
}
test('TUS grants are scoped, destination is never overwritten, bounded chunks resume with verified final length',async()=>{
 const f=await fixture();let done=await ensureTusUpload(f.input,{fetch:f.send,chunkBytes:5,maxChunks:1});assert.equal(done.complete,false);assert.equal(done.checkpoint.offset,5);
 while(!done.complete)done=await ensureTusUpload({...f.input,checkpoint:f.checkpoint},{fetch:f.send,chunkBytes:5,maxChunks:1});
 assert.equal(f.stats.post,1);assert.equal(f.stats.offset,f.input.bytes.length);assert.ok(f.saved.length>3);assert.doesNotMatch(JSON.stringify(f.saved),/secret|https|auth_key|apiToken/);
 const replay=await ensureTusUpload({...f.input,checkpoint:f.checkpoint},{fetch:f.send});assert.equal(replay.complete,true);assert.equal(f.stats.post,1);
});
test('lost creation and partial PATCH acknowledgements reconcile by HEAD without a second POST or lost bytes',async()=>{
 const f=await fixture();f.loseCreate();const first=await ensureTusUpload(f.input,{fetch:f.send});assert.equal(first.complete,false);assert.equal(f.stats.post,1);f.loseChunk();
 const second=await ensureTusUpload({...f.input,checkpoint:f.checkpoint},{fetch:f.send});assert.equal(second.complete,false);assert.equal(second.checkpoint.offset,0);assert.equal(f.stats.offset,2);
 const recovered=await ensureTusUpload({...f.input,checkpoint:f.checkpoint},{fetch:f.send});assert.equal(recovered.complete,true);assert.equal(f.stats.post,1);assert.equal(f.stats.offset,f.input.bytes.length);
});
test('preexisting destination, mismatched checkpoint or changed artifact fail before upload mutations',async()=>{
 const f=await fixture();f.setPreexisting();await assert.rejects(()=>ensureTusUpload(f.input,{fetch:f.send}),/已存在文件/);assert.equal(f.stats.post,0);assert.equal(f.stats.patch,0);
 await assert.rejects(()=>ensureTusUpload({...f.input,bytes:new TextEncoder().encode('tampered')},{fetch:f.send}),/校验失败/);
 await assert.rejects(()=>ensureTusUpload({...f.input,relativePath:'../index.php'},{fetch:f.send}),/路径无效/);
 const other=await fixture();await ensureTusUpload(other.input,{fetch:other.send,maxChunks:1,chunkBytes:1});
 await assert.rejects(()=>ensureTusUpload({...other.input,domain:'different.example.com',checkpoint:other.checkpoint},{fetch:other.send}),/不一致/);
});
test('unsafe or redirected grants never receive credentials, retryable provisioning status makes no upload attempt',async()=>{
 const f=await fixture();let calls=0;
 for(const url of ['http://files.provider-domain.com','https://127.0.0.1/tus','https://user:password@files.provider-domain.com/tus','https://files.provider-domain.com/tus?token=secret','https://localhost/tus']){
  await assert.rejects(()=>ensureTusUpload(f.input,{fetch:async()=>{calls++;return Response.json({url,auth_key:'x',rest_auth_key:'y'});}}),/安全要求/);
 }
 assert.equal(calls,5);const pending=await ensureTusUpload(f.input,{fetch:async()=>new Response(null,{status:409,headers:{'Retry-After':'90'}})});assert.equal(pending.complete,false);assert.equal(pending.retryAfterSeconds,90);assert.equal(pending.checkpoint.attempted,false);
});
test('known failed creation is not blindly replayed and remote length mismatch cannot complete',async()=>{
 const f=await fixture();let post=0;
 const rejected:typeof fetch=async(u,i)=>{if(i?.method==='POST'&&!String(u).endsWith('/upload-urls')){post++;return new Response(null,{status:503});}return f.send(u,i);};
 await assert.rejects(()=>ensureTusUpload(f.input,{fetch:rejected}),/创建结果待核对/);
 await assert.rejects(()=>ensureTusUpload({...f.input,checkpoint:f.checkpoint},{fetch:rejected}),/先前文件创建结果/);assert.equal(post,1);
 const g=await fixture();g.loseCreate();await ensureTusUpload(g.input,{fetch:g.send});g.setLength(g.input.bytes.length-1);
 await assert.rejects(()=>ensureTusUpload({...g.input,checkpoint:g.checkpoint},{fetch:g.send}),/不一致/);
});
