import test from 'node:test';
import assert from 'node:assert/strict';
import { encryptSecret,decryptSecret,hashPassword,verifyPassword,randomToken } from '../src/lib/crypto';
test('credentials use authenticated encryption bound to their config ID',async()=>{
 const key=randomToken(),cipher=await encryptSecret('not-a-real-api-secret',key,'config-1');
 assert.ok(!cipher.includes('not-a-real-api-secret'));
 assert.equal(await decryptSecret(cipher,key,'config-1'),'not-a-real-api-secret');
 await assert.rejects(()=>decryptSecret(cipher,key,'config-2'));
 await assert.rejects(()=>decryptSecret(cipher,randomToken(),'config-1'));
});
test('passwords receive independent salts and verify only the correct password',async()=>{
 const one=await hashPassword('long-password'),two=await hashPassword('long-password');
 assert.notEqual(one,two);assert.equal(await verifyPassword('long-password',one),true);assert.equal(await verifyPassword('wrong-password',one),false);
});
