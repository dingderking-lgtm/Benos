import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';
import { id } from '../src/lib/crypto';
import { listPublishedContent } from '../src/modules/content';

async function fixture(){const db=new TestD1(),env=testEnv(db),headers:Record<string,string>={origin:env.APP_ORIGIN,'content-type':'application/json'};
 const boot=await app.request('/api/bootstrap',{method:'POST',headers,body:JSON.stringify({token:env.BOOTSTRAP_TOKEN,email:'content-owner@example.test',password:'content-owner-password',name:'Owner'})},env);const json=await boot.json() as any;
 headers.cookie=boot.headers.get('set-cookie')!.split(';')[0];headers['x-csrf-token']=json.data.csrfToken;
 const request=(path:string,method='GET',data?:unknown)=>app.request(path,{method,headers,body:data?JSON.stringify(data):undefined},env);
 const create=async(kind:string,slug:string,content:any={body:'正文'},title=slug)=>{const r=await request('/api/admin/content','POST',{kind,slug,title,content});assert.equal(r.status,201,await r.clone().text());return (await r.json() as any).data;};
 const action=async(row:any,action:string)=>{const r=await request('/api/admin/content/'+row.id+(action==='trash'?'':'/'+action),action==='trash'?'DELETE':'POST',{revision:row.revision});return {response:r,row:(await r.clone().json() as any).data};};
 return {db,env,headers,request,create,action};}
test('published slug and SEO snapshots stay live while drafts change; HTML is escaped and references protect categories',async()=>{
 const f=await fixture();try{
  let category=await f.create('category','design',{body:'设计分类'});
  let post=await f.create('post','safe-entry',{body:'<script>window.stolen=true</script>\n\n内容段落',categoryId:category.id,seoTitle:'正式 SEO 标题',seoDescription:'正式描述'});
  assert.equal((await f.action(post,'publish')).response.status,409,'cannot publish broken draft reference');
  category=(await f.action(category,'publish')).row;post=(await f.action(post,'publish')).row;
  const changed=await f.request('/api/admin/content/'+post.id,'PATCH',{kind:'post',slug:'draft-new-slug',title:'未发布标题',revision:post.revision,content:{body:'未发布正文',categoryId:category.id,seoTitle:'草稿SEO'}});assert.equal(changed.status,200);post=(await changed.json() as any).data;
  const live=await f.request('/blog/safe-entry');assert.equal(live.status,200);const html=await live.text();assert.ok(html.includes('<title>正式 SEO 标题 · Benos</title>'));assert.ok(html.includes('&lt;script&gt;window.stolen=true&lt;/script&gt;'));assert.ok(!html.includes('未发布正文'));assert.ok(html.includes('noindex,nofollow'));assert.ok(html.includes('application/ld+json'));
  assert.equal((await f.request('/blog/draft-new-slug')).status,404);
  assert.equal((await f.request('/api/content/post/safe-entry')).status,200);
  assert.equal((await f.request('/api/content/post/draft-new-slug')).status,404);
  assert.equal((await f.action(category,'trash')).response.status,409,'cannot break referenced category');
  assert.equal((await f.action(category,'unpublish')).response.status,409);
  post=(await f.action(post,'trash')).row;assert.equal((await f.request('/blog/safe-entry')).status,404);assert.equal((await f.action(category,'trash')).response.status,200);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM mutation_guards').get()!.n,0);
 }finally{f.db.close();}
});
test('content URL validation, active publication collisions and private options are enforced on the server',async()=>{
 const f=await fixture();try{
  for(const url of ['javascript:alert(1)','//outside.example','/\\outside.example','https://user:password@outside.example']){const r=await f.request('/api/admin/content','POST',{kind:'post',slug:'unsafe',title:'Unsafe',content:{body:'text',coverUrl:url}});assert.equal(r.status,400);}
  let one=await f.create('post','original');one=(await f.action(one,'publish')).row;
  const updated=await f.request('/api/admin/content/'+one.id,'PATCH',{kind:'post',slug:'draft-path',title:'one',content:{body:'draft'},revision:one.revision});assert.equal(updated.status,200);
  const second=await f.create('post','original');assert.equal((await f.action(second,'publish')).response.status,409,'published snapshot slug remains reserved');
  const options=await f.request('/api/admin/content/options');assert.equal(options.status,200);assert.ok((await options.json() as any).data.targets.length>=2);
  assert.equal((await app.request('/api/admin/content/options',{},f.env)).status,401);
 }finally{f.db.close();}
});
test('public cursor pagination has no duplicates at equal timestamps and indexing is explicitly gated',async()=>{
 const f=await fixture();try{
  const actor=f.db.sqlite.prepare('SELECT id FROM users LIMIT 1').get()!.id,now='2026-11-07T00:00:00.000Z';
  for(let n=0;n<27;n++){const content=JSON.stringify({title:'Article '+n,slug:'entry-'+n,body:'Real fixture body'});f.db.sqlite.prepare("INSERT INTO content_entries(id,kind,slug,title,draft_json,published_json,state,created_by,created_at,updated_at,published_at) VALUES(?,'post',?,?,?,?,'published',?,?,?,?)").run(id('cnt'),'entry-'+n,'Article '+n,content,content,actor,now,now,now);}
  const a=await listPublishedContent(f.env,{kind:'post',limit:12}),b=await listPublishedContent(f.env,{kind:'post',limit:12,cursor:a.nextCursor!}),c=await listPublishedContent(f.env,{kind:'post',limit:12,cursor:b.nextCursor!});assert.equal(new Set([...a.items,...b.items,...c.items].map(x=>x.id)).size,27);assert.equal(c.nextCursor,null);
  assert.ok(!(await (await f.request('/sitemap.xml')).text()).includes('<url>'));
  f.env.APP_ENV='production';f.env.APP_ORIGIN='https://benos.example.com';f.env.INDEXING_ENABLED='true';
  const sitemap=await (await f.request('/sitemap.xml')).text();assert.equal((sitemap.match(/<url>/g)||[]).length,30);assert.ok(sitemap.includes('/blog/entry-26'));
  const robots=await (await f.request('/robots.txt')).text();assert.ok(robots.includes('Disallow: /api/'));assert.ok(robots.includes('Sitemap: https://benos.example.com/sitemap.xml'));
  const html=await (await f.request('/blog/entry-0')).text();assert.ok(html.includes('content="index,follow"'));
  const faq=await (await f.request('/faq')).text();assert.ok(faq.includes('帮助内容正在准备中'));
 }finally{f.db.close();}
});
