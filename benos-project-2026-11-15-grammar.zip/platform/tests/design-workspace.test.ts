import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { saveVersion } from '../src/modules/ai';
import { adoptDesignCandidate,saveDesignCandidate } from '../src/modules/design-workspace';
import { annotateDesignHtml,assertDesignScope,describeDesignNodes,patchDesignStyle,patchDesignImage } from '../src/modules/design-nodes';
import example from '../src/contracts/site-example.json';
import { app } from '../src/index';
import { sha256 } from '../src/lib/crypto';
import { starterManifest,starterTemplates } from '../src/contracts/starter-library';
import { validateSiteManifest } from '../src/modules/template-contract';
import { templateZip } from '../src/lib/template-zip';
const fresh=()=>structuredClone(example);
test('starter library contains complete valid multi-page themes and export produces standard ZIP file records',()=>{
 for(const template of starterTemplates){const manifest=starterManifest(template.id,'Example & Co')!;const check=validateSiteManifest(manifest);assert.equal(check.valid,true,JSON.stringify(check.issues));assert.equal(manifest.site.pages.length,3);assert.equal(manifest.site.forms[0].ref,'contact');assert.ok(manifest.templates.find((t:any)=>t.type==='archive'));assert.ok(manifest.templates.find((t:any)=>t.type==='single'));assert.doesNotMatch(JSON.stringify(manifest),/结构示例/);
  const archive=templateZip(manifest,[]),view=new DataView(archive.buffer);assert.equal(view.getUint32(0,true),0x04034b50);const nameLength=view.getUint16(26,true);assert.equal(new TextDecoder().decode(archive.subarray(30,30+nameLength)),'manifest.json');assert.deepEqual(JSON.parse(new TextDecoder().decode(archive.subarray(30+nameLength,30+nameLength+view.getUint32(18,true)))),manifest);assert.equal(view.getUint32(archive.length-22,true),0x06054b50);assert.equal(view.getUint16(archive.length-12,true),1);
 }
});
async function fixture(){const db=new TestD1(),env=testEnv(db),now=new Date().toISOString();for(const u of ['a','b'])db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,'User','unused','user',?,?)").run(u,u+'@example.test',now,now);db.sqlite.prepare("INSERT INTO projects(id,user_id,name,description,status,created_at,updated_at) VALUES('p','a','Website','','draft',?,?)").run(now,now);const base=await saveVersion(env,'a','p',fresh(),'manual',null,'fixture');return {db,env,base};}
test('selected-node styles change only the chosen source span and preserve bindings and untouched data',()=>{
 const base=fresh(),scope={kind:'node' as const,templateId:1,nodeKey:'n1'},next=patchDesignStyle(base,scope,{fontSize:36,color:'#334455'});
 assertDesignScope(base,next,scope);assert.match(next.templates[0].document.html,/font-size:36px/);assert.deepEqual(next.templates.slice(1),base.templates.slice(1));
 const outside=structuredClone(next);outside.templates[2].document.html+='Changed';assert.throws(()=>assertDesignScope(base,outside,scope),/范围|保持不变/);
 const links=structuredClone(base);links.templates[0].document.html=links.templates[0].document.html.replace('/contact','/about');assert.doesNotThrow(()=>assertDesignScope(base,links,{kind:'site'}));assert.throws(()=>assertDesignScope(base,links,{kind:'node',templateId:1,nodeKey:'n0'}),/绑定|链接/);
 const menu=structuredClone(base);menu.menus=[];assert.throws(()=>assertDesignScope(base,menu,{kind:'site'}),/业务内容|组件配置/);
 const conditions=structuredClone(base);conditions.templates[0].conditions.all=true;assert.throws(()=>assertDesignScope(base,conditions,{kind:'site'}),/挂载条件/);
});
test('confirmed global styles remain part of subsequent AI proposals and unsafe style values are rejected',()=>{
 const base=fresh(),branded=patchDesignStyle(base,{kind:'site'},{fontFamily:'Georgia, serif',backgroundColor:'#fff'});assertDesignScope(base,branded,{kind:'site'});
 assert.throws(()=>assertDesignScope(branded,base,{kind:'site'}),/品牌样式/);
 for(const props of [{position:'fixed'},{fontSize:0},{color:'red;position:fixed'},{fontFamily:'url(https://bad.test)'}])assert.throws(()=>patchDesignStyle(base,{kind:'node',templateId:1,nodeKey:'n1'},props as any));
 assert.throws(()=>patchDesignStyle(base,{kind:'site'},{paddingTop:40}),/全站仅支持/);
});
test('editor node IDs use parsed source locations and cannot be spoofed by template attributes',()=>{
 const html='<section data-benos-node="forged"><p title=">">Hello <strong>world</strong></p><img src="/logo.png" alt="logo"></section>',marked=annotateDesignHtml(html,2);
 assert.equal((marked.match(/data-benos-node=/g)||[]).length,4);assert.doesNotMatch(marked,/forged/);assert.match(marked,/title=">"/);
 const manifest=fresh();manifest.templates[0].document.html=html;const nodes=describeDesignNodes(manifest).filter(x=>x.templateId===1);assert.deepEqual(nodes.map(x=>x.nodeKey),['n0','n1','n2','n3']);assert.equal(nodes.at(-1)!.canReplaceImage,true);
 const changed=patchDesignImage(manifest,{kind:'node',templateId:1,nodeKey:'n3'},{file:'assets/0.png',path:'/replacement.png',sha256:'a'.repeat(64),size:1},'New image');assert.match(changed.templates[0].document.html,/src="\/replacement.png"/);assert.match(changed.templates[0].document.html,/alt="New image"/);assertDesignScope(manifest,changed,{kind:'node',templateId:1,nodeKey:'n3'});
});
test('candidate preview never changes current design; adoption is atomic and replay-safe',async()=>{
 const f=await fixture();try{const scope={kind:'node' as const,templateId:1,nodeKey:'n1'},manifest=patchDesignStyle(fresh(),scope,{fontSize:36}),input={userId:'a',projectId:'p',requestKey:'candidate-request-1',baseVersionId:f.base,scope,manifest,source:'manual' as const};
 const candidate=await saveDesignCandidate(f.env,input);assert.equal(f.db.sqlite.prepare("SELECT current_version_id FROM projects WHERE id='p'").get()!.current_version_id,f.base);
 assert.equal((await saveDesignCandidate(f.env,input)).id,candidate.id);
 const [one,two]=await Promise.all([adoptDesignCandidate(f.env,'a','p',candidate.id),adoptDesignCandidate(f.env,'a','p',candidate.id)]);assert.equal(one.versionId,two.versionId);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM design_versions WHERE project_id='p'").get()!.n,2);
 assert.equal((await saveDesignCandidate(f.env,input)).state,'adopted');
 await assert.rejects(saveDesignCandidate(f.env,{...input,manifest:patchDesignStyle(fresh(),scope,{fontSize:40})}),/编号已用于/);
 }finally{f.db.close();}
});
test('a stale candidate cannot replace newer work; scope validation is independent of frontend controls',async()=>{
 const f=await fixture();try{const scope={kind:'node' as const,templateId:1,nodeKey:'n1'};
 const a=await saveDesignCandidate(f.env,{userId:'a',projectId:'p',requestKey:'candidate-keep-001',baseVersionId:f.base,scope,manifest:patchDesignStyle(fresh(),scope,{fontSize:36}),source:'manual'});
 const b=await saveDesignCandidate(f.env,{userId:'a',projectId:'p',requestKey:'candidate-keep-002',baseVersionId:f.base,scope,manifest:patchDesignStyle(fresh(),scope,{fontSize:40}),source:'manual'});const adopted=await adoptDesignCandidate(f.env,'a','p',a.id);await assert.rejects(adoptDesignCandidate(f.env,'a','p',b.id),/已有|变化/);assert.equal(f.db.sqlite.prepare("SELECT current_version_id FROM projects WHERE id='p'").get()!.current_version_id,adopted.versionId);
 await assert.rejects(adoptDesignCandidate(f.env,'b','p',b.id),/项目不存在/);
 }finally{f.db.close();}
});
test('candidate HTTP routes require ownership and CSRF and discard cannot erase an adopted version',async()=>{
 const f=await fixture();try{const now=new Date().toISOString();for(const u of ['a','b'])f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run(u,u,await sha256((u+'-session').padEnd(43,'x')),'csrf',now,'2099-01-01T00:00:00.000Z','test');
 const call=(user:string,path:string,method='GET',data?:unknown,csrf=true)=>app.request('/api/design/projects/p'+path,{method,headers:{origin:f.env.APP_ORIGIN,cookie:'benos_session='+(user+'-session').padEnd(43,'x'),...(csrf?{'x-csrf-token':'csrf'}:{}),'content-type':'application/json'},body:data?JSON.stringify(data):undefined},f.env);
 assert.equal((await call('b','/nodes?version='+f.base)).status,404);
 const input={requestKey:'http-candidate-0001',baseVersionId:f.base,scope:{kind:'node',templateId:1,nodeKey:'n1'},operation:{kind:'style',properties:{fontSize:34}}};assert.equal((await call('a','/candidates','POST',input,false)).status,403);
 const response=await call('a','/candidates','POST',input);assert.equal(response.status,201);const c=(await response.json() as any).data;
 assert.equal((await call('a','/candidates/'+c.id+'/discard','POST',{})).status,200);assert.equal((await call('a','/candidates/'+c.id+'/adopt','POST',{})).status,409);
 const r=await call('a','/candidates','POST',{...input,requestKey:'http-candidate-0002'}),next=(await r.json() as any).data;assert.equal((await call('a','/candidates/'+next.id+'/adopt','POST',{})).status,200);assert.equal((await call('a','/candidates/'+next.id+'/discard','POST',{})).status,409);
 }finally{f.db.close();}
});
