import { DatabaseSync } from 'node:sqlite';
import { readFileSync,readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import type { Env } from '../src/env';
type SqlValue=string|number|null|Uint8Array;
class Statement {
  constructor(private db:DatabaseSync,private sql:string,private values:SqlValue[]=[]){}
  bind(...values:SqlValue[]) {return new Statement(this.db,this.sql,values);}
  private prepared(){
    if(maxCompoundTerms(this.sql)>D1_COMPOUND_SELECT_LIMIT)throw new Error('D1_ERROR: too many terms in compound SELECT: SQLITE_ERROR');
    const ordered:SqlValue[]=[];
    const sql=this.sql.replace(/\?(\d+)/g,(_match,index:string)=>{const value=this.values[Number(index)-1];if(value===undefined)throw new Error('Unbound SQL parameter');ordered.push(value);return '?';});
    return {stmt:this.db.prepare(sql),values:ordered.length?ordered:this.values};
  }
  async first<T=Record<string,unknown>>(column?:string):Promise<T|null>{
    const {stmt,values}=this.prepared(),row=stmt.get(...values);
    if(!row)return null;return (column?row[column]:row) as T;
  }
  execute<T=Record<string,unknown>>() {
    const {stmt,values}=this.prepared(),results=stmt.all(...values) as T[];
    const changes=this.db.prepare('SELECT changes() AS count').get()?.count;
    return {success:true,results,meta:{changes:Number(changes),duration:0,last_row_id:0,rows_read:results.length,rows_written:Number(changes),size_after:0,changed_db:!!changes}};
  }
  async all<T=Record<string,unknown>>() {return this.execute<T>();}
  async run<T=Record<string,unknown>>(){return this.all<T>();}
  async raw<T=unknown[]>(options?:{columnNames?:boolean}):Promise<T[]> {
    const {stmt,values}=this.prepared();stmt.setReturnArrays(true);const rows=stmt.all(...values) as unknown as T[];
    if(options?.columnNames)rows.unshift(stmt.columns().map(c=>c.name) as T);return rows;
  }
}
/** Cloudflare D1 (workerd) sets SQLITE_LIMIT_COMPOUND_SELECT to 5, while
 * node:sqlite allows 500. A statement whose compound SELECT has more than 5
 * terms works here but fails in production with "too many terms in compound
 * SELECT" (R4-M2), so the test database refuses it the same way. Terms are
 * counted per parenthesis group, outside string literals and comments. */
export const D1_COMPOUND_SELECT_LIMIT=5;
export function maxCompoundTerms(sql:string):number{
  const text=sql.replace(/'(?:[^']|'')*'|"(?:[^"]|"")*"|--[^\n]*|\/\*[\s\S]*?\*\//g,' ');
  const stack:number[]=[0];let max=0;
  const re=/[()]|\b(?:UNION|INTERSECT|EXCEPT)\b/gi;let match:RegExpExecArray|null;
  while((match=re.exec(text))){
    if(match[0]==='('){stack.push(0);continue;}
    if(match[0]===')'){if(stack.length>1)stack.pop();continue;}
    stack[stack.length-1]++;max=Math.max(max,stack[stack.length-1]);
  }
  return max+1;
}
export class TestD1 {
  readonly sqlite=new DatabaseSync(':memory:');
  constructor(){for(const file of readdirSync(resolve('migrations')).filter(f=>f.endsWith('.sql')).sort())this.sqlite.exec(readFileSync(resolve('migrations',file),'utf8'));}
  prepare(sql:string){return new Statement(this.sqlite,sql);}
  async batch<T=Record<string,unknown>>(statements:Statement[]){
    this.sqlite.exec('BEGIN IMMEDIATE');
    try{const results=[];for(const statement of statements)results.push(statement.execute<T>());this.sqlite.exec('COMMIT');return results;}
    catch(error){this.sqlite.exec('ROLLBACK');throw error;}
  }
  async exec(sql:string){this.sqlite.exec(sql);return {count:1,duration:0};}
  close(){this.sqlite.close();}
}
export function testEnv(db:TestD1):Env {
  return {DB:db as unknown as D1Database,ASSETS:undefined as unknown as Fetcher,APP_ENV:'test',APP_ORIGIN:'http://127.0.0.1:4190',REGISTRATION_ENABLED:'true',SESSION_SECRET:'test-session-secret-with-at-least-thirty-two-bytes',ENCRYPTION_KEY:'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',BOOTSTRAP_TOKEN:'test-bootstrap-secret'};
}
