﻿// The owner-only grammar workshop: it compiles documents and shows pages, and it never spends,
// writes a site or approves anything.
import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { randomToken, sha256 } from '../src/lib/crypto';
import { TestD1, testEnv } from './d1-helper';

const base = '/api/admin/design-grammar';
const brand = {
  colors: { paper: '#f7f7f4', tint: '#eceee9', ink: '#16181b', copy: '#4a5056', line: '#d8dbd6', accent: '#1f6feb', accentInk: '#ffffff', mark: '#c2571a', dark: '#12161a', darkInk: '#f2f4f3' },
  type: { head: 'grotesk', body: 'humanist', weight: 600, tracking: 'tight', scale: 'regular' },
  shape: { radius: 'large', button: 'pill' },
  styles: { kicker: 'square', link: 'underline', card: 'soft', figure: 'framed' },
  space: { container: 1280, density: 'regular' },
};
const sections = [
  { id: 'hero', tone: 'paper', space: 'hero', body: [{ t: 'kicker', text: 'Precision machining' }, { t: 'display', lines: ['Parts that fit'] }, { t: 'text', text: 'Turning and milling for short runs.', role: 'lead' }] },
  { id: 'work', tone: 'paper', body: [{ t: 'title', text: 'What we make' }, { t: 'list', items: ['Prototypes', 'Small runs'] }] },
  { id: 'next', tone: 'dark', space: 'band', body: [{ t: 'title', text: 'Send a drawing' }, { t: 'actions', items: [{ label: 'Start a quote', href: '/about', kind: 'primary' }] }] },
];

async function fixture() {
  const db = new TestD1(), env = testEnv(db), now = new Date().toISOString(), headers: Record<string, Record<string, string>> = {};
  for (const role of ['owner', 'admin', 'user']) {
    db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(role, `${role}@grammar.test`, role, 'unused', role, 'active', now, now);
    const token = randomToken();
    db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('g-' + role, await sha256(token), role, 'csrf-' + role, now, new Date(Date.now() + 3600000).toISOString(), 'fixture');
    headers[role] = { cookie: 'benos_session=' + token, origin: env.APP_ORIGIN, 'x-csrf-token': 'csrf-' + role, 'content-type': 'application/json' };
  }
  return { db, env, headers };
}

test('the grammar workshop is owner only', async () => {
  const f = await fixture();
  try {
    assert.equal((await app.request(base + '/spec', {}, f.env)).status, 401);
    for (const role of ['admin', 'user']) {
      assert.equal((await app.request(base + '/spec', { headers: f.headers[role] }, f.env)).status, 403, role);
      assert.equal((await app.request(base + '/preview', { method: 'POST', headers: f.headers[role], body: JSON.stringify({ brand, sections }) }, f.env)).status, 403, role);
    }
  } finally { f.db.close(); }
});

test('the owner can read the grammar the model writes in', async () => {
  const f = await fixture();
  try {
    const response = await app.request(base + '/spec', { headers: f.headers.owner }, f.env);
    assert.equal(response.status, 200);
    const data = (await response.json() as any).data;
    assert.equal(data.version, 'bnl-0');
    assert.match(data.spec, /You are the design model inside a website builder/);
    assert.match(data.spec, /Exactly one `display`/);
  } finally { f.db.close(); }
});

test('a valid document becomes an inert page', async () => {
  const f = await fixture();
  try {
    const response = await app.request(base + '/preview', { method: 'POST', headers: f.headers.owner, body: JSON.stringify({ lang: 'en', title: 'Workshop', brand, sections }) }, f.env);
    assert.equal(response.status, 200);
    const html = await response.text();
    assert.match(response.headers.get('content-security-policy')!, /script-src 'none'/);
    assert.match(html, /<main class="bnl /);
    assert.match(html, /class="bnl-l-sec/);
    assert.doesNotMatch(html, /<script\b|@font-face|@import|!important/);
    // Nothing is recorded: no reservation, no approval, no candidate.
    assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM api_reservations').get()!.n, 0);
    assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM design_pattern_reviews').get()!.n, 0);
  } finally { f.db.close(); }
});

test('a broken document comes back with the list a repair round needs', async () => {
  const f = await fixture();
  try {
    const broken = [...sections.slice(0, 2), { id: 'next', tone: 'dark', body: [{ t: 'display', lines: ['Second'] }] }];
    const response = await app.request(base + '/preview', { method: 'POST', headers: f.headers.owner, body: JSON.stringify({ brand, sections: broken }) }, f.env);
    assert.equal(response.status, 422);
    const data = (await response.json() as any);
    assert.equal(data.error, 'GRAMMAR_DOCUMENT_INVALID');
    assert.ok(data.issues.some((issue: any) => /exactly one display/.test(issue.message)));
    assert.match(data.brief, /must be fixed/);
  } finally { f.db.close(); }
});

test('a whole site compiles to pages that share one brand stylesheet', async () => {
  const f = await fixture();
  try {
    const response = await app.request(base + '/site', {
      method: 'POST', headers: f.headers.owner,
      body: JSON.stringify({ brand, pages: [
        { key: 'home', path: '/', title: 'Home', sections },
        { key: 'about', path: '/about', title: 'About', sections: sections.map((entry, index) => index === 0 ? { ...entry, body: entry.body.map((node: any) => node.t === 'display' ? { t: 'display', lines: ['About us'] } : node) } : entry) },
      ] }),
    }, f.env);
    assert.equal(response.status, 200);
    const data = (await response.json() as any).data;
    assert.equal(data.ok, true);
    assert.equal(data.pages.length, 2);
    assert.ok(data.sharedCssBytes > 1000 && data.sharedCssBytes < 100_000);
    for (const page of data.pages) {
      assert.ok(page.cssBytes < 45_000, `${page.key} css`);
      assert.match(page.html, /^<main class="bnl /);
      assert.doesNotMatch(page.html, /<script\b/);
    }
    // Each page carries its own instance classes.
    assert.match(data.pages[0].css, /\.bnl \.bnl-home-/);
    assert.match(data.pages[1].css, /\.bnl \.bnl-about-/);
  } finally { f.db.close(); }
});

test('the owner panel can compile a document and get the page back as JSON', async () => {
  const f = await fixture();
  try {
    const response = await app.request(base + '/compile', { method: 'POST', headers: f.headers.owner, body: JSON.stringify({ lang: 'en', title: 'Workshop', brand, sections }) }, f.env);
    assert.equal(response.status, 200);
    const data = (await response.json() as any).data;
    assert.equal(data.ok, true);
    assert.match(data.html, /^<main class="bnl /);
    assert.match(data.css, /^\.bnl\{--paper:/);
    assert.ok(data.stats.cssBytes > 1000 && data.stats.cssBytes < 45_000);
    assert.doesNotMatch(data.html, /<script\b|<style/);
    // A broken document answers with the same list the model would get.
    const broken = await app.request(base + '/compile', { method: 'POST', headers: f.headers.owner, body: JSON.stringify({ brand, sections: sections.slice(0, 2) }) }, f.env);
    const brokenData = (await broken.json() as any).data;
    assert.equal(brokenData.ok, false);
    assert.equal(brokenData.html, '');
    assert.ok(brokenData.issues.some((issue: any) => /3 to 10 sections/.test(issue.message)));
  } finally { f.db.close(); }
});
