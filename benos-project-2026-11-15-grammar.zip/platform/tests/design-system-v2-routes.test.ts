import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { randomToken, sha256 } from '../src/lib/crypto';
import { TestD1, testEnv } from './d1-helper';
import { V2_FIXTURE_ASSETS } from '../src/design-system/v2/fixtures';

async function fixture() {
  const db = new TestD1(), env = testEnv(db), now = new Date().toISOString(), headers: Record<string, Record<string, string>> = {};
  for (const role of ['owner', 'admin', 'user']) {
    db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(role,role+'@v2.test',role,'unused',role,'active',now,now);
    const token = randomToken();
    db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('v2-'+role,await sha256(token),role,'csrf-'+role,now,new Date(Date.now()+3600000).toISOString(),'fixture');
    headers[role] = { cookie:'benos_session='+token, origin:env.APP_ORIGIN, 'x-csrf-token':'csrf-'+role, 'content-type':'application/json' };
  }
  const reads: string[] = [];
  env.ASSETS = { fetch: async (request: Request) => { reads.push(new URL(request.url).pathname); return new Response(new Uint8Array([137,80,78,71]),{headers:{'Content-Type':'image/png'}}); } } as unknown as Fetcher;
  return { db, env, headers, reads };
}
const base = '/api/admin/design-system-v2';
test('v2 previews, sources and asset aliases remain staff-only and never grant approvals', async () => {
  const f = await fixture(); try {
    const paths = [base+'/gallery',base+'/catalog',base+'/preview?pattern=hero-stage&variant=split',base+'/page',base+'/notices',base+'/gallery.js',base+'/assets/'+V2_FIXTURE_ASSETS[0].file,V2_FIXTURE_ASSETS[0].path];
    for (const route of paths) {
      assert.equal((await app.request(route, {}, f.env)).status,401);
      assert.equal((await app.request(route, {headers:f.headers.user}, f.env)).status,403);
    }
    assert.equal(f.reads.length,0);
    const catalog = await app.request(base+'/catalog',{headers:f.headers.admin},f.env);
    assert.equal(catalog.status,200); const data:any=(await catalog.json() as any).data;
    assert.equal(data.patterns.length,17); assert.equal(data.customerExportReady,false);
    assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM design_pattern_reviews').get()!.n,0);
    assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM api_reservations').get()!.n,0);
  } finally { f.db.close(); }
});
test('preview documents are inert and gallery scripts have their own authenticated route', async () => {
  const f = await fixture(); try {
    for(const route of [base+'/preview?pattern=hero-stage&variant=split',base+'/page?example=industrial',base+'/page?example=stay']) {
      const response=await app.request(route,{headers:f.headers.admin},f.env);assert.equal(response.status,200,route);
      assert.match(response.headers.get('content-security-policy')!,/script-src 'none'/);
      const html=await response.text();assert.match(html,/data-review-only="true"/);assert.doesNotMatch(html,/<script\b|@font-face|@import/);
    }
    const gallery=await app.request(base+'/gallery',{headers:f.headers.admin},f.env);assert.equal(gallery.status,200);
    assert.match(await gallery.text(),/仅审阅/);
    const notices=await app.request(base+'/notices',{headers:f.headers.admin},f.env);const text=await notices.text();assert.match(text,/Apache License/);assert.match(text,/MIT License/);
  } finally { f.db.close(); }
});
test('planning requires origin and CSRF but has zero wallet/project/approval side effects', async () => {
  const f = await fixture(); try {
    const request={request:'做一个工业设备官网，包含首页和产品中心',preset:'deep-studio'};
    const invalid={...f.headers.owner};delete invalid['x-csrf-token'];
    assert.equal((await app.request(base+'/plan',{method:'POST',headers:invalid,body:JSON.stringify(request)},f.env)).status,403);
    const response=await app.request(base+'/plan',{method:'POST',headers:f.headers.owner,body:JSON.stringify(request)},f.env);assert.equal(response.status,200);
    const result:any=(await response.json() as any).data;assert.equal(result.tool.name,'compose_design_preview');assert.ok(result.plan.pages.length>=2);assert.equal(result.paidModelCalls,0);
    for(const table of ['projects','ai_workflows','api_reservations','design_pattern_reviews'])assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM '+table).get()!.n,0,table);
  } finally { f.db.close(); }
});
