import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { encryptSecret,randomToken,sha256 } from '../src/lib/crypto';
import { fundProvider,grantCredit,reserve,getWallet } from '../src/modules/ledger';
import { functionalTestQuote,runFunctionalTest,setOperationsBudget,reconcileFunctionalTest,assertIntegrationCapability } from '../src/modules/integration-tests';
import { textGenerationQuote,createGeneration } from '../src/modules/ai';
import { app } from '../src/index';
import type { User } from '../src/env';
import { png } from './media-helper';
const pricing={baseUrl:'https://api.openai.com/v1',model:'gpt-6.1-sol',protocol:'responses',providerPoolId:'provider',inputMicrosPerMillion:2000000,cachedInputMicrosPerMillion:100000,outputMicrosPerMillion:10000000,contextTokens:1050000,maxOutputTokens:10000,billingProfile:'openai-gpt6-standard-2026-11-07',cacheTtl:'30m',pricingConfirmedAt:new Date().toISOString()};
const required=5250240;
async function fixture(pool=20000000,budget=20000000){
 const db=new TestD1(),env=testEnv(db),time=new Date().toISOString();
 for(const role of ['owner','admin','user'])db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(role,role+'@example.test',role,'fixture',role,time,time);
 const secret=await encryptSecret(JSON.stringify({apiKey:'sk-fixture-never-live'}),env.ENCRYPTION_KEY,'cfg');
 db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,tested_at,created_by,created_at) VALUES('cfg','text','Text','openai',1,'tested',?,?,'passed',?,'owner',?)").run(JSON.stringify(pricing),secret,time,time);
 await fundProvider(env.DB,{id:'fund',providerId:'provider',amountMicros:pool,referenceId:'receipt-real-fixture'});const owner=db.sqlite.prepare("SELECT * FROM users WHERE id='owner'").get() as unknown as User;
 await setOperationsBudget(env,owner,'provider',{limitMicros:budget,reason:'运营测试额度授权'});
 async function request(path:string,method:string,body:unknown,role='owner'){const token=randomToken(),csrf=randomToken();db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run(token,await sha256(token),role,csrf,time,'2099-01-01T00:00:00.000Z','fixture');return app.fetch(new Request(env.APP_ORIGIN+'/api/admin/integrations'+path,{method,headers:{origin:env.APP_ORIGIN,cookie:'benos_session='+token,'x-csrf-token':csrf,'content-type':'application/json'},body:method==='GET'?undefined:JSON.stringify(body)}),env);}
 async function input(key='confirmed-functional-test'){const quote=await functionalTestQuote(env,'cfg');assert.equal(quote.available,true);assert.ok('quoteHash' in quote);return {requestKey:key,quoteHash:quote.quoteHash!,maxCostMicros:required,confirmedCharge:true as const};}
 return {db,env,owner,request,input};
}
const usage={input_tokens:20,output_tokens:5,total_tokens:25,input_tokens_details:{cached_tokens:0,cache_write_tokens:0,cache_write_tokens_details:{ttl_30m_tokens:0,ttl_12h_tokens:0}},output_tokens_details:{reasoning_tokens:0}};
const response=(extra:Record<string,unknown>={})=>({id:'resp_functional_fixture',model:pricing.model,service_tier:'default',status:'completed',usage,output:[{type:'message',content:[{type:'output_text',text:'BENOS_TEST_OK'}]}],...extra});
test('read-only access is enough to activate text, and an active config needs no paid test to issue real generation',async()=>{
 const f=await fixture();try{assert.equal((await f.request('/cfg/activate','POST',{})).status,200);assert.notEqual((await textGenerationQuote(f.env,'user')).reason,'CAPABILITY_TEST_REQUIRED');return;
  f.db.sqlite.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES('p','user','P',?,?)").run(new Date().toISOString(),new Date().toISOString());let sent=0;await assert.rejects(()=>createGeneration(f.env,'user','p',{prompt:'设计网站',requestKey:'before-capability'},{fetch:async()=>{sent++;return Response.json({});}}),/真实小额/);assert.equal(sent,0);
 }finally{f.db.close();}
});
test('quote is exact; owner-confirmed short test consumes only independent operations and shared provider budget',async()=>{
 const f=await fixture();try{const quote=await functionalTestQuote(f.env,'cfg');assert.ok('requiredReservationMicros' in quote);assert.equal(quote.requiredReservationMicros,required);let sent=0;
  const job=await runFunctionalTest(f.env,f.owner,'cfg',await f.input(),{fetch:async(url,init)=>{sent++;assert.equal(String(url),'https://api.openai.com/v1/responses');const payload=JSON.parse(String(init!.body));assert.equal(payload.max_output_tokens,16);assert.equal(payload.store,false);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM operations_budgets').get()!.reserved_micros,required);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,required);return Response.json(response());}});
  assert.equal(job.state,'passed');assert.equal(job.actualMicros,90);assert.equal(sent,1);assert.equal(f.db.sqlite.prepare('SELECT consumed_micros FROM operations_budgets').get()!.consumed_micros,90);assert.equal(f.db.sqlite.prepare('SELECT consumed_micros FROM provider_pools').get()!.consumed_micros,90);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM credit_grants').get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM api_reservations').get()!.n,0);await assertIntegrationCapability(f.env.DB,'cfg','text');assert.equal((await f.request('/cfg/activate','POST',{})).status,200);
 }finally{f.db.close();}
});
test('owner limit, explicit charge confirmation, matching quote and both budgets are required before HTTP',async()=>{
 for(const [pool,budget] of [[100,20000000],[20000000,100]]){const f=await fixture(pool,budget);try{let sent=0;const input=await f.input();await assert.rejects(()=>runFunctionalTest(f.env,f.owner,'cfg',input,{fetch:async()=>{sent++;return Response.json(response());}}),/不足/);assert.equal(sent,0);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,0);}finally{f.db.close();}}
 const f=await fixture();try{const input=await f.input();assert.equal((await f.request('/cfg/functional-tests','POST',input,'admin')).status,403);assert.equal((await f.request('/cfg/functional-tests','POST',{...input,confirmedCharge:false})).status,400);await assert.rejects(()=>runFunctionalTest(f.env,f.owner,'cfg',{...input,maxCostMicros:required-1}),/不足/);await assert.rejects(()=>runFunctionalTest(f.env,f.owner,'cfg',{...input,quoteHash:'a'.repeat(64)}),/报价/);}finally{f.db.close();}
});
test('concurrent duplicate confirmation dispatches exactly once; changed request data cannot reuse a key',async()=>{
 const f=await fixture();try{let sends=0;const input=await f.input(),runtime={fetch:async()=>{sends++;return Response.json(response());}};const jobs=await Promise.all(Array.from({length:8},()=>runFunctionalTest(f.env,f.owner,'cfg',input,runtime)));assert.equal(sends,1);assert.equal(new Set(jobs.map(j=>j.id)).size,1);assert.equal((await runFunctionalTest(f.env,f.owner,'cfg',input,runtime)).state,'passed');assert.equal(sends,1);await assert.rejects(()=>runFunctionalTest(f.env,f.owner,'cfg',{...input,maxCostMicros:required+1},runtime),/编号/);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM operations_budget_events').get()!.n,2);
 }finally{f.db.close();}
});
test('operations and customer requests compete atomically for the same provider money',async()=>{
 const f=await fixture(required,required);try{await grantCredit(f.env.DB,{id:'user-credit',userId:'user',source:'topup',amountMicros:required,referenceId:'paid'});let sends=0;const input=await f.input();const jobs=await Promise.allSettled([runFunctionalTest(f.env,f.owner,'cfg',input,{fetch:async()=>{sends++;throw new Error('transport unknown');}}),reserve(f.env.DB,{id:'user-request',userId:'user',providerId:'provider',amountMicros:required,requestKey:'customer-request'})]);
  const pool=f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!;assert.equal(pool.reserved_micros,required);const ops=f.db.sqlite.prepare('SELECT reserved_micros FROM operations_budgets').get()!,wallet=await getWallet(f.env.DB,'user');assert.equal(Number(ops.reserved_micros)+wallet.heldMicros,required);assert.ok(sends<=1);assert.equal(jobs.length,2);
 }finally{f.db.close();}
});
test('unknown cost keeps both holds and manual reconciliation never permits contradictory cost',async()=>{
 const f=await fixture();try{let sends=0;const input=await f.input(),job=await runFunctionalTest(f.env,f.owner,'cfg',input,{fetch:async()=>{sends++;throw new Error('unknown');}});assert.equal(job.state,'uncertain');assert.equal(job.accountingState,'held');await runFunctionalTest(f.env,f.owner,'cfg',input,{fetch:async()=>{sends++;return Response.json(response());}});assert.equal(sends,1);await assert.rejects(()=>setOperationsBudget(f.env,f.owner,'provider',{limitMicros:required-1,reason:'不能削减预留额度'}),/预占/);
  await assert.rejects(()=>reconcileFunctionalTest(f.env,f.owner,'cfg',job.id,{outcome:'confirmed_cost',actualMicros:required+1,evidence:'外部账单核对证据至少十字'}),/超出/);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM operations_budgets').get()!.reserved_micros,required);
  const settled=await reconcileFunctionalTest(f.env,f.owner,'cfg',job.id,{outcome:'confirmed_cost',actualMicros:123,evidence:'外部账单核对证据至少十字'});assert.equal(settled.state,'failed');await reconcileFunctionalTest(f.env,f.owner,'cfg',job.id,{outcome:'confirmed_cost',actualMicros:123,evidence:'外部账单核对证据至少十字'});await assert.rejects(()=>reconcileFunctionalTest(f.env,f.owner,'cfg',job.id,{outcome:'confirmed_unused',evidence:'与原费用冲突的核对证据'}),/不同/);assert.equal(f.db.sqlite.prepare('SELECT consumed_micros FROM operations_budgets').get()!.consumed_micros,123);
 }finally{f.db.close();}
});
test('known fee with a wrong capability response is charged as operations',async()=>{
 const f=await fixture();try{const job=await runFunctionalTest(f.env,f.owner,'cfg',await f.input(),{fetch:async()=>Response.json(response({output:[]}))});assert.equal(job.state,'failed');assert.equal(job.actualMicros,90);assert.equal(job.accountingState,'settled');}finally{f.db.close();}
});
test('invalid image configuration and malformed text usage fail closed',async()=>{
 const f=await fixture();try{f.db.sqlite.prepare("UPDATE integration_configs SET kind='image'").run();assert.deepEqual(await functionalTestQuote(f.env,'cfg'),{available:false,reason:'IMAGE_CONFIG_INVALID',maxOutputTokens:16});assert.equal((await f.request('/cfg/activate','POST',{})).status,409);f.db.sqlite.prepare("UPDATE integration_configs SET kind='text'").run();const job=await runFunctionalTest(f.env,f.owner,'cfg',await f.input(),{fetch:async()=>Response.json(response({usage:undefined}))});assert.equal(job.state,'uncertain');assert.equal(job.actualMicros,null);assert.equal(f.db.sqlite.prepare('SELECT enabled FROM provider_pools').get()!.enabled,0);
 }finally{f.db.close();}
});

const imagePricing={baseUrl:'https://api.openai.com/v1',model:'gpt-image-2.6-sunburst',protocol:'images',providerPoolId:'provider',n:1,size:'1024x1024',quality:'low',complexity:'low',outputFormat:'png',textInputMicrosPerMillion:5_000_000,cachedTextInputMicrosPerMillion:1_250_000,imageInputMicrosPerMillion:8_000_000,cachedImageInputMicrosPerMillion:2_000_000,imageOutputMicrosPerMillion:30_000_000,pricingConfirmedAt:new Date().toISOString(),billingContract:{kind:'metered-reserve-v1'}};
test('GPT-6 Sol capability probe disables reasoning without increasing its quoted output cap',async()=>{
 const f=await fixture();try{
  f.db.sqlite.prepare('UPDATE integration_configs SET public_config_json=?').run(JSON.stringify({...pricing,model:'gpt-6-sol',cachedInputMicrosPerMillion:200000}));
  const quote=await functionalTestQuote(f.env,'cfg');assert.ok(quote.available);assert.equal(quote.requiredReservationMicros,required);
  const job=await runFunctionalTest(f.env,f.owner,'cfg',{requestKey:'gpt6-sol-probe-none',quoteHash:quote.quoteHash,maxCostMicros:required,confirmedCharge:true},{fetch:async(_url,init)=>{
   const payload=JSON.parse(String(init!.body));assert.deepEqual(payload.reasoning,{effort:'none'});assert.equal(payload.max_output_tokens,16);
   return Response.json(response({model:'gpt-6-sol'}));
  }});assert.equal(job.state,'passed');
 }finally{f.db.close();}
});
async function imageFixture(){const f=await fixture();f.db.sqlite.prepare("UPDATE integration_configs SET kind='image',public_config_json=?").run(JSON.stringify(imagePricing));return f;}
function imageResponse(output=823,valid=true){return {created:1770000000,model:imagePricing.model,size:'1024x1024',quality:'low',output_format:'png',data:[{b64_json:valid?Buffer.from(png(1024,1024)).toString('base64'):'broken'}],usage:{input_tokens:100,input_tokens_details:{text_tokens:100,image_tokens:0},output_tokens:output,total_tokens:100+output,output_tokens_details:{image_tokens:output,text_tokens:0}}};}
test('image capability test reserves an explicit estimate, settles actual usage and enables only after valid PNG',async()=>{
 const f=await imageFixture();try{
  const quote=await functionalTestQuote(f.env,'cfg');assert.ok(quote.available);assert.equal(quote.reservationIsEstimate,true);assert.equal(quote.requiredReservationMicros,1_000_000);
  const input={requestKey:'image-capability-once',quoteHash:quote.quoteHash,maxCostMicros:1_000_000,confirmedCharge:true as const};let sent=0;
  const runtime={fetch:async(url:any,init:any)=>{sent++;assert.equal(String(url),'https://api.openai.com/v1/images/generations');assert.equal(JSON.parse(init.body).n,1);assert.equal(init.redirect,'manual');return Response.json(imageResponse());}};
  const job=await runFunctionalTest(f.env,f.owner,'cfg',input,runtime);assert.equal(job.state,'passed');assert.equal(job.accountingState,'settled');assert.equal(job.actualMicros,25190);assert.equal(job.requestKey,input.requestKey);
  assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,0);assert.ok(!String(f.db.sqlite.prepare('SELECT response_json FROM integration_function_tests').get()!.response_json).includes('b64_json'));
  await runFunctionalTest(f.env,f.owner,'cfg',input,runtime);assert.equal(sent,1);assert.equal((await f.request('/cfg/activate','POST',{})).status,200);
 }finally{f.db.close();}
});
test('invalid image bytes settle known usage',async()=>{
 const f=await imageFixture();try{
  const quote=await functionalTestQuote(f.env,'cfg');assert.ok(quote.available);
  const job=await runFunctionalTest(f.env,f.owner,'cfg',{requestKey:'image-invalid-output',quoteHash:quote.quoteHash,maxCostMicros:1_000_000,confirmedCharge:true},{fetch:async()=>Response.json(imageResponse(823,false))});
  assert.equal(job.state,'failed');assert.equal(job.accountingState,'settled');assert.equal(job.actualMicros,25190);
 }finally{f.db.close();}
});
test('image cost above the operating reservation stays uncertain, disables provider and does not resend',async()=>{
 const f=await imageFixture();try{
  const quote=await functionalTestQuote(f.env,'cfg');assert.ok(quote.available);let sent=0;
  const input={requestKey:'image-over-reservation',quoteHash:quote.quoteHash,maxCostMicros:1_000_000,confirmedCharge:true as const},runtime={fetch:async()=>{sent++;return Response.json(imageResponse(40000));}};
  const job=await runFunctionalTest(f.env,f.owner,'cfg',input,runtime);assert.equal(job.state,'uncertain');assert.equal(job.accountingState,'held');assert.equal(job.errorCode,'COST_EXCEEDS_RESERVATION');assert.equal(f.db.sqlite.prepare('SELECT enabled FROM provider_pools').get()!.enabled,0);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,1_000_000);
  await runFunctionalTest(f.env,f.owner,'cfg',input,runtime);assert.equal(sent,1);
 }finally{f.db.close();}
});
test('settlement acknowledgement loss cannot charge twice',async()=>{
 const f=await fixture();try{const original=f.env.DB.batch.bind(f.env.DB);let injected=false;
  f.env.DB.batch=(async(statements:any[])=>{const result=await original(statements);if(!injected&&f.db.sqlite.prepare("SELECT id FROM integration_function_tests WHERE state='passed'").get()){injected=true;throw new Error('lost settlement ack');}return result;}) as D1Database['batch'];
  const input=await f.input(),job=await runFunctionalTest(f.env,f.owner,'cfg',input,{fetch:async()=>Response.json(response())});assert.equal(job.state,'passed');assert.equal(f.db.sqlite.prepare('SELECT consumed_micros FROM provider_pools').get()!.consumed_micros,90);await runFunctionalTest(f.env,f.owner,'cfg',input);assert.equal(f.db.sqlite.prepare('SELECT consumed_micros FROM provider_pools').get()!.consumed_micros,90);
 }finally{f.db.close();}
});
