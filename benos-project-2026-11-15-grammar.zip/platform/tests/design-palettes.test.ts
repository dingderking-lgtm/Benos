// The palette engine must satisfy the owner's rules on every industry and direction: readable pairings,
// and a brand system the grammar itself accepts.
import test from 'node:test';
import assert from 'node:assert/strict';
import { compilePage } from '../src/design-system/grammar/compile';
import { resolveBrand, type Issue } from '../src/design-system/grammar/brand';
import { DIRECTIONS, INDUSTRY_PALETTES, contrastReport, isDirection, isIndustry, paletteTokens, ramp } from '../src/design-system/grammar/palettes';

const ids = INDUSTRY_PALETTES.map(palette => palette.id);

test('all thirteen industries are covered, with three directions each', () => {
  assert.equal(INDUSTRY_PALETTES.length, 13);
  assert.deepEqual(ids, ['ai-saas', 'finance', 'health', 'food', 'education', 'luxury', 'beauty', 'environment', 'industrial', 'property', 'travel', 'legal', 'gaming']);
  assert.deepEqual(DIRECTIONS.map(direction => direction.id), ['professional', 'editorial', 'contrast']);
  for (const id of ids) for (const direction of DIRECTIONS) assert.doesNotThrow(() => paletteTokens(id, direction.id));
  assert.equal(isIndustry('industrial'), true);
  assert.equal(isIndustry('unknown'), false);
  assert.equal(isDirection('contrast'), true);
});

test('every palette produces a brand system the grammar accepts, in every direction', () => {
  for (const id of ids) for (const direction of DIRECTIONS) {
    const tokens = paletteTokens(id, direction.id);
    const issues: Issue[] = [];
    const resolved = resolveBrand(tokens.brand as never, issues);
    const errors = issues.filter(issue => issue.level === 'error');
    assert.ok(resolved, `${id}/${direction.id}: ${JSON.stringify(errors)}`);
    assert.equal(errors.length, 0, `${id}/${direction.id}: ${errors.map(issue => issue.message).join('; ')}`);
  }
});

test('every readable pairing the owner asked for passes', () => {
  for (const id of ids) for (const direction of DIRECTIONS) {
    const report = contrastReport(paletteTokens(id, direction.id));
    for (const check of report) assert.ok(check.ok, `${id}/${direction.id}: ${check.pair} is ${check.ratio}, needs ${check.required}`);
  }
});

test('the ramps run light to dark and stay in one hue', () => {
  for (const id of ids) {
    const tokens = paletteTokens(id, 'professional');
    const steps = Object.entries(tokens.ramps.primary);
    assert.equal(steps.length, 11);
    const luminance = steps.map(([, value]) => Number(value.slice(1, 3), ) );
    // Each step must be darker than the one before it (the ramp never doubles back).
    for (let index = 1; index < steps.length; index++) {
      const previous = luminanceOf(steps[index - 1][1]);
      const current = luminanceOf(steps[index][1]);
      assert.ok(current < previous + 0.001, `${id}: step ${steps[index][0]} is not darker than ${steps[index - 1][0]}`);
    }
  }
  function luminanceOf(value: string) {
    const [r, g, b] = [1, 3, 5].map(offset => parseInt(value.slice(offset, offset + 2), 16) / 255).map(v => (v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4));
    return .2126 * r + .7152 * g + .0722 * b;
  }
});

test('a page built from any palette keeps its sections quiet', () => {
  const sections = (accentTone: string) => [
    { id: 'hero', tone: 'paper', space: 'hero', body: [{ t: 'kicker', text: 'Precision machining' }, { t: 'display', lines: ['Parts that fit'] }, { t: 'text', text: 'Short runs, checked part by part.', role: 'lead' }, { t: 'actions', items: [{ label: 'Start a quote', href: '/contact', kind: 'primary' }] }] },
    { id: 'work', tone: 'tint', body: [{ t: 'title', text: 'What we make' }, { t: 'list', items: ['Prototypes', 'Small runs'], marker: 'number' }] },
    { id: 'close', tone: accentTone, space: 'band', body: [{ t: 'title', text: 'Send a drawing' }, { t: 'actions', items: [{ label: 'Talk to us', href: '/contact', kind: 'primary' }] }] },
  ];
  for (const id of ids) for (const direction of DIRECTIONS) {
    const tokens = paletteTokens(id, direction.id);
    const result = compilePage({ brand: tokens.brand as never, sections: sections('dark') as never });
    assert.equal(result.ok, true, `${id}/${direction.id}: ${JSON.stringify(result.issues.filter(issue => issue.level === 'error').slice(0, 3))}`);
    // One accent band at most, one dark band at most: the 60/30/10 rule, from the page side.
    const tones = (result.body.match(/bnl-tone-(?:dark|accent)/g) ?? []).length;
    assert.ok(tones <= 1, `${id}/${direction.id}: ${tones} loud sections`);
    assert.ok(result.stats.cssBytes < 45_000);
  }
});

test('the accent is the only saturated colour, and it stays readable', () => {
  const luxury = paletteTokens('luxury', 'professional');
  // The luxury brand colour is near-black, so button text on it is white; the gold stays a mark, never a button.
  assert.equal(luxury.brand.colors.accent, '#181818');
  assert.equal(luxury.brand.colors.accentInk, '#ffffff');
  assert.notEqual(luxury.brand.colors.mark, luxury.brand.colors.accent);
  const industrial = paletteTokens('industrial', 'professional');
  assert.equal(industrial.brand.colors.accent, '#183B64');
  // The mark colour is a text colour, so it is darkened until it reads on the page.
  assert.ok(contrastOn(industrial.brand.colors.mark, industrial.brand.colors.paper) >= 4.5);
  function contrastOn(a: string, b: string) {
    const value = (colour: string) => {
      const [r, g, bl] = [1, 3, 5].map(offset => parseInt(colour.slice(offset, offset + 2), 16) / 255).map(v => (v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4));
      return .2126 * r + .7152 * g + .0722 * bl;
    };
    const x = value(a), y = value(b);
    return (Math.max(x, y) + .05) / (Math.min(x, y) + .05);
  }
});

test('the ramp helper is deterministic and ordered', () => {
  const first = ramp('#635BFF'), second = ramp('#635BFF');
  assert.deepEqual(first, second);
  assert.equal(first[500], '#635BFF');
  assert.match(first[50], /^#[0-9a-f]{6}$/);
});
