import test from 'node:test';
import assert from 'node:assert/strict';
// @ts-expect-error Browser modules are authored in JavaScript.
import { renderConversationComposer, renderConversationHistory, handleWorkflowAction, primeWorkflowDraft, submitWorkflowForm } from '../public/js/design-workflow.js';
// @ts-expect-error Browser modules are authored in JavaScript.
import { visualState, renderVisualPanel, submitVisualForm } from '../public/js/design-editor.js';

let sequence = 0;
const user = { id: 'ui-owner' };
const form = { elements: { prompt: {} } };
const types = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/svg+xml', 'application/pdf'];

function fixture() {
  return {
    project: { id: `scope-${++sequence}`, current_version_id: 'v1' as string | null, description: '' },
    selected: { id: 'v1' } as { id: string } | null,
    jobs: [],
    visual: {
      nodes: [
        { templateId: 1, nodeKey: 'n1', label: 'Hero image', tag: 'img', canReplaceImage: true },
        { templateId: 1, nodeKey: 'n2', label: 'Second block', tag: 'section' },
      ],
      fonts: [],
      assets: types.map((mimeType, i) => ({
        id: `asset-${i}`, assetPath: `assets/file-${i}`, fileName: `file-${i}`, mimeType, state: 'ready',
        deletedAt: null as string | null, contentUrl: `/safe/${i}`, byteSize: 100,
      })),
      candidates: [], proposal: null as { id: string } | null,
    },
    workflow: {
      items: [], quote: { available: true, canReserve: true, referenceImagesSupported: true, perStepReservationMicros: 1000 },
    },
  };
}

function contextFor(resource: ReturnType<typeof fixture>) {
  // The offscreen context isolates transport and draft behavior from browser DOM mounting.
  return { state: { resource, user, route: 'home' }, notify() {}, async reload() {},
    showModal() { assert.fail('Sending an account message opened a confirmation dialog'); } };
}

function receipt(projectId: string) {
  return Response.json({ ok: true, data: { id: 'workflow', projectId, requestOrigin: 'account', state: 'succeeded' } });
}

test('composer infers the selected current block or site, retains custom style, and exposes no billing or scope form', () => {
  const data = fixture(), editor = visualState(data, user);
  const html = () => renderConversationComposer(data, user);
  assert.match(html(), /data-form="design-conversation-message"/);
  assert.match(html(), /data-conversation-scope>当前网站</);
  assert.doesNotMatch(html(), /name="(?:scope|confirmedCharge|maxSteps|maxCostMicros|quoteHash|budget)"/);
  editor.selectedKey = '1:n1';
  assert.match(html(), /当前区块 · Hero image/);
  editor.selectedKey = '1:n2';
  assert.match(html(), /当前区块 · Second block/);
  primeWorkflowDraft(user.id, data.project.id, { style: '暖沙色 · 标题留白', prompt: '保留草稿' });
  assert.match(html(), /value="暖沙色 · 标题留白" checked/);
  assert.match(html(), /保留草稿/);
  data.project.current_version_id = null;
  data.selected = null;
  assert.match(html(), /data-conversation-scope>完整网站</);
});

test('AI references show only ready owned PNG/JPEG/WebP while visual replacement includes GIF/SVG and excludes PDF and deleted assets', () => {
  const data = fixture();
  data.visual.assets.push({ ...data.visual.assets[0], id: 'removed', assetPath: 'assets/removed', deletedAt: 'now' });
  visualState(data, user).selectedKey = '1:n1';
  const ai = renderConversationComposer(data, user), visual = renderVisualPanel(data, user);
  for (let i = 0; i < 3; i++) assert.match(ai, new RegExp(`value="asset-${i}"`));
  for (let i = 3; i < 6; i++) assert.doesNotMatch(ai, new RegExp(`value="asset-${i}"`));
  for (let i = 0; i < 5; i++) assert.match(visual, new RegExp(`value="assets/file-${i}"`));
  assert.doesNotMatch(visual, /value="assets\/file-5"/);
  assert.doesNotMatch(ai, /value="removed"/);
  assert.doesNotMatch(visual, /value="assets\/removed"/);
});

test('direct sends infer whole-site, node, and first design, and submit only the message intent', async t => {
  const data = fixture(), context = contextFor(data), editor = visualState(data, user);
  const writes: Array<{path: string; body: Record<string, unknown>}> = [];
  t.mock.method(globalThis, 'fetch', async (url: string, init: RequestInit) => {
    assert.equal(init.method, 'POST');
    writes.push({ path: url, body: JSON.parse(String(init.body)) });
    return receipt(data.project.id);
  });
  const send = () => submitWorkflowForm('design-conversation-message', form,
    { prompt: '改', scope: 'site', confirmedCharge: 'on', maxCostMicros: 999, maxSteps: 1, quoteHash: 'ignored', userId: 'other' }, context);
  await send();
  editor.selectedKey = '1:n2';
  primeWorkflowDraft(user.id, data.project.id, { referenceMediaIds: ['asset-0', 'asset-2'], style: '现代科技' });
  await send();
  data.project.current_version_id = null;
  data.selected = null;
  await send();
  assert.deepEqual(writes.map(write => write.body.scope), [{kind:'site'}, {kind:'node', templateId:1, nodeKey:'n2'}, {kind:'site'}]);
  assert.deepEqual(writes.map(write => write.body.baseVersionId), ['v1', 'v1', null]);
  assert.deepEqual(writes[1].body.referenceMediaIds, ['asset-0', 'asset-2']);
  assert.equal(writes[1].body.prompt, '改');
  assert.equal(writes[1].body.style, '现代科技');
  assert.equal(new Set(writes.map(write => write.body.requestKey)).size, 3);
  for (const {path, body} of writes) {
    assert.equal(path, `/api/ai/projects/${data.project.id}/messages`);
    const expected = ['baseVersionId','prompt','referenceMediaIds','requestKey','scope'];
    if (body.style) expected.push('style');
    assert.deepEqual(Object.keys(body).sort(), expected);
  }
});

test('a stale selection, history/candidate view, foreign or unsupported attachment, excessive count or size cannot dispatch', async t => {
  const data = fixture(), context = contextFor(data), editor = visualState(data, user);
  const transport = t.mock.method(globalThis, 'fetch', async () => receipt(data.project.id));
  const send = () => submitWorkflowForm('design-conversation-message', form, { prompt: '修改区块' }, context);
  editor.selectedKey = '1:n999';
  await assert.rejects(send, /重新选择/);
  editor.selectedKey = '1:n1';
  data.selected = { id: 'old-version' };
  await assert.rejects(send, /历史版本/);
  data.selected = { id: 'v1' };
  data.visual.proposal = { id: 'candidate' };
  await assert.rejects(send, /审阅设计方案/);
  data.visual.proposal = null;
  data.visual.assets.push({ ...data.visual.assets[0], id: 'other-png' }, { ...data.visual.assets[0], id: 'deleted', deletedAt: 'now' });
  for (const id of ['asset-3','asset-4','asset-5','deleted','not-in-current-project']) {
    primeWorkflowDraft(user.id, data.project.id, { referenceMediaIds: [id] });
    await assert.rejects(send, /PNG、JPEG 或 WebP/);
  }
  primeWorkflowDraft(user.id, data.project.id, { referenceMediaIds: ['asset-0', 'asset-1', 'asset-2', 'other-png'] });
  await assert.rejects(send, /3 张/);
  data.visual.assets[0].byteSize = 6 * 1024 * 1024;
  primeWorkflowDraft(user.id, data.project.id, { referenceMediaIds: ['asset-0', 'asset-1'] });
  await assert.rejects(send, /6 MiB/);
  assert.equal(transport.mock.callCount(), 0);
  primeWorkflowDraft(user.id, data.project.id, { referenceMediaIds: ['asset-0'] });
  await send();
  assert.equal(transport.mock.callCount(), 1);
});

test('lost acknowledgement is looked up read-only; a confirmed-missing retry preserves the original scope, attachment, text and key', async t => {
  const data = fixture(), editor = visualState(data,user), context = contextFor(data);
  const calls: Array<{method: string; path: string; body?: string}> = [];
  t.mock.method(globalThis, 'fetch', async (path: string, init: RequestInit) => {
    calls.push({ method: String(init.method), path, body: init.body as string | undefined });
    if (init.method === 'GET') return Response.json({ ok:false, error:{code:'NOT_FOUND',message:'未找到'} }, { status:404 });
    if (calls.length === 1) throw new Error('lost response');
    return receipt(data.project.id);
  });
  editor.selectedKey = '1:n1';
  primeWorkflowDraft(user.id, data.project.id, { referenceMediaIds: ['asset-0'] });
  await submitWorkflowForm('design-conversation-message', form, {prompt:'修改原来的首屏图片'}, context);
  assert.deepEqual(calls.map(call => call.method), ['POST','GET']);
  const original = JSON.parse(calls[0].body!);
  assert.deepEqual(original.scope, { kind:'node', templateId:1, nodeKey:'n1' });
  assert.deepEqual(original.referenceMediaIds, ['asset-0']);
  assert.match(renderConversationHistory(data,user), /data-action="design-message-check"/);
  assert.doesNotMatch(renderConversationHistory(data,user), /data-action="design-message-retry"/);
  editor.selectedKey = '1:n2';
  primeWorkflowDraft(user.id, data.project.id, { prompt:'下一条草稿', referenceMediaIds:['asset-1'] });
  await submitWorkflowForm('design-conversation-message', form, {prompt:'新建另一个请求'}, context);
  assert.equal(calls.length,2);
  await handleWorkflowAction('design-message-check', {}, context);
  assert.match(renderConversationHistory(data,user), /data-action="design-message-retry"/);
  await handleWorkflowAction('design-message-retry', {}, context);
  assert.deepEqual(calls.map(call => call.method), ['POST','GET','GET','GET','POST']);
  assert.deepEqual(calls[0],calls[4]);
  for (const call of calls.filter(call => call.method === 'GET')) assert.equal(call.path, calls[0].path + '/' + original.requestKey);
  assert.doesNotMatch(renderConversationHistory(data,user), /data-action="design-message-retry"/);
  assert.match(renderConversationComposer(data,user), /下一条草稿/);
});

test('PDF cannot be injected into image replacement; SVG remains a valid project image', async t => {
  const data = fixture(), context = {state:{resource:data,user},notify() {},navigate() {}};
  const writes: Array<{operation:{assetPath:string}}> = [];
  visualState(data,user).selectedKey = '1:n1';
  t.mock.method(globalThis, 'fetch', async (_url: unknown, init: RequestInit) => {
    writes.push(JSON.parse(String(init.body)));return Response.json({ok:true,data:{id:'candidate'}});
  });
  const visualForm = { dataset:{} };
  await assert.rejects(submitVisualForm('design-visual-image',visualForm,{assetPath:'assets/file-5',alt:'PDF'},context), /PDF 不能替换图片/);
  assert.equal(writes.length,0);
  await submitVisualForm('design-visual-image',visualForm,{assetPath:'assets/file-4',alt:'SVG'},context);
  assert.equal(writes[0].operation.assetPath,'assets/file-4');
});
