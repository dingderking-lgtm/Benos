import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { createWorkflow,continueWorkflow,workflowQuote,sendDesignMessage,designMessageSchema,WORKFLOW_TOOLS,PROJECTED_WORKFLOW_TOOLS,type WorkflowInput } from '../src/modules/ai-workflow';
import { encryptSecret,randomToken,sha256 } from '../src/lib/crypto';
import { AppError } from '../src/lib/errors';
import { saveVersion } from '../src/modules/ai';
import { grantCredit,fundProvider,getWallet } from '../src/modules/ledger';
import { textReservationCost } from '../src/modules/ai-billing';
import { publicText,whiteLabel,pricingTerms,finalRefusal,customerRefusal,receiveMessage,rejectMessage } from '../src/modules/design-conversation';
import { seedCapabilityFixture } from './integration-test-helper';
import { mediaFixture } from './media-helper';
import example from '../src/contracts/site-example.json';

const pricing={baseUrl:'https://api.openai.com/v1',model:'gpt-6.1-sol',protocol:'responses',providerPoolId:'openai-main',inputMicrosPerMillion:2_000_000,cachedInputMicrosPerMillion:100_000,outputMicrosPerMillion:10_000_000,contextTokens:1050000,maxOutputTokens:10000,billingProfile:'openai-gpt6-standard-2026-11-07',cacheTtl:'30m',pricingConfirmedAt:new Date().toISOString()};
const ORIGIN='http://127.0.0.1:4190';
type Fixture=Awaited<ReturnType<typeof fixture>>;

async function configure(f:ReturnType<typeof mediaFixture>,capabilityTested=true){
 const encrypted=await encryptSecret(JSON.stringify({apiKey:'sk-fixture-only'}),f.env.ENCRYPTION_KEY,'cfg');
 f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('cfg','text','AI','openai',1,'active',?,?,'passed','u',?)").run(JSON.stringify(pricing),encrypted,new Date().toISOString());
 if(capabilityTested)await seedCapabilityFixture(f.env.DB,'cfg');
}
async function session(f:ReturnType<typeof mediaFixture>,user:string){
 const token=randomToken(),now=new Date().toISOString();
 f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session-'+user,user,await sha256(token),'csrf-'+user,now,new Date(Date.now()+3600000).toISOString(),'fixture');
 return {Cookie:'benos_session='+token,'X-CSRF-Token':'csrf-'+user};
}
async function fixture(options:{configured?:boolean;balance?:number}={}){
 const f=mediaFixture();
 if(options.balance!==0)await grantCredit(f.env.DB,{id:'g',userId:'u',source:'topup',amountMicros:options.balance??50_000_000,referenceId:'receipt'});
 await fundProvider(f.env.DB,{id:'f',providerId:'openai-main',amountMicros:100_000_000,referenceId:'deposit'});
 if(options.configured!==false)await configure(f);
 const headers=await session(f,'u'),otherHeaders=await session(f,'other');
 const call=async(method:string,path:string,body?:unknown,auth:Record<string,string>=headers)=>{
  const response=await app.request(path,{method,headers:{...auth,...(body===undefined?{}:{'Content-Type':'application/json',Origin:ORIGIN})},body:body===undefined?undefined:JSON.stringify(body)},f.env);
  const json=await response.json() as any;return {status:response.status,json,data:json.data,error:json.error};
 };
 return {...f,headers,otherHeaders,call};
}
/** Model output with an assistant message beside the single tool call. */
function output(name:string,args:unknown={},text?:string){
 return {id:'resp_'+name,model:pricing.model,service_tier:'default',status:'completed',
  usage:{input_tokens:100,output_tokens:20,input_tokens_details:{cached_tokens:50,cache_write_tokens:0,cache_write_tokens_details:{ttl_30m_tokens:0,ttl_12h_tokens:0}}},
  output:[{type:'reasoning',id:'rs_fixture',summary:[],encrypted_content:'opaque_reasoning_fixture'},
   ...(text?[{type:'message',id:'msg_'+name,role:'assistant',content:[{type:'output_text',text}]}]:[]),
   {type:'function_call',id:'fc_'+name,call_id:'call_'+name,name,arguments:JSON.stringify(args)}]};
}
const respond=(name:string,args:unknown={},text?:string)=>new Response(JSON.stringify(output(name,args,text)));
function proposed(){const manifest=structuredClone(example);manifest.templates[0].document.html=manifest.templates[0].document.html.replace('首页结构示例','Benos 工作室');return manifest;}
/** A quoted task keeps the explicit propose → check → finish rounds; a message saves its proposal by itself once the check passes. */
const quotedRun=async(f:Fixture,n:string,send:typeof fetch)=>{const quote=await workflowQuote(f.env,'u','p') as any;return createWorkflow(f.env,'u','p',{...message(n),maxSteps:6,maxCostMicros:quote.perStepReservationMicros*6,quoteHash:quote.quoteHash,referenceMediaIds:[],confirmedCharge:true} as WorkflowInput,{fetch:send});};
const message=(n:string,extra:Record<string,unknown>={})=>({requestKey:'conversation-route-'+n.padStart(4,'0'),prompt:'把首页标题改成 Benos 工作室',baseVersionId:null,scope:{kind:'site'},...extra});
const count=(f:Fixture,sql:string,...args:(string|number)[])=>Number(f.db.sqlite.prepare(sql).get(...args)!.n);
const base='/api/ai/projects/p';

test('style is optional, trimmed, at most 200 characters, and an absent or blank style keeps the original request hash',async()=>{
 assert.equal(designMessageSchema.safeParse(message('1',{style:'x'.repeat(200)})).success,true);
 const tooLong=designMessageSchema.safeParse(message('1',{style:'x'.repeat(201)}));
 assert.equal(tooLong.success,false);assert.match(tooLong.error!.issues[0].message,/200/);
 assert.equal(designMessageSchema.safeParse(message('1',{style:12})).success,false);
 assert.equal(designMessageSchema.parse(message('1',{style:'  暖沙色  '})).style,'暖沙色');
 for(const blank of ['','   ',null])assert.equal(designMessageSchema.parse(message('1',{style:blank})).style,undefined);
 assert.equal(JSON.stringify(designMessageSchema.parse(message('1',{style:''}))),JSON.stringify(designMessageSchema.parse(message('1'))));
 const f=await fixture();
 try{
  let calls=0;const runtime={fetch:async()=>{calls++;return respond('read_project');}};
  const plain=await sendDesignMessage(f.env,'u','p',message('2'),runtime);
  assert.equal((await sendDesignMessage(f.env,'u','p',message('2',{style:'  '}),runtime)).id,plain.id);
  assert.equal((await sendDesignMessage(f.env,'u','p',message('2',{style:null}),runtime)).id,plain.id);
  await assert.rejects(sendDesignMessage(f.env,'u','p',message('2',{style:'现代科技'}),runtime),(e:unknown)=>e instanceof AppError&&e.code==='IDEMPOTENCY_CONFLICT');
  assert.equal(calls,1);
  const tooLongHttp=await f.call('POST',base+'/messages',message('3',{style:'风'.repeat(201)}));
  assert.equal(tooLongHttp.status,400);assert.equal(tooLongHttp.error.code,'VALIDATION');assert.match(tooLongHttp.error.message,/视觉风格/);
  assert.equal(calls,1);assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns WHERE request_key=?',message('3').requestKey),0);
 }finally{f.db.close();}
});

// The request identity of a message without a style must never change: this is
// the exact string and digest the server produced before the `style` field existed.
const PINNED_KEY='conversation-route-0090';
const PINNED_IDENTITY='{"origin":"account-design-message-v1","projectId":"p","requestKey":"conversation-route-0090","prompt":"把首页标题改成 Benos 工作室","baseVersionId":null,"scope":{"kind":"site"},"referenceMediaIds":[]}';
const PINNED_HASH='a33f00364578552d32714ea2db02e10dc3663d4439e1fbbe6c68d4e7d8dfe26d';
test('a message without a style keeps the pinned request hash from before the style field, and a style changes it',async t=>{
 assert.equal(await sha256(PINNED_IDENTITY),PINNED_HASH);
 const f=await fixture();
 try{
  t.mock.method(globalThis,'fetch',async()=>respond('read_project'));
  assert.equal(message('90').requestKey,PINNED_KEY);
  const plain=await f.call('POST',base+'/messages',message('90'));assert.equal(plain.status,202,JSON.stringify(plain.json));
  assert.equal(f.db.sqlite.prepare('SELECT request_hash h FROM ai_workflows WHERE id=?').get(plain.data.id)!.h,PINNED_HASH);
  assert.equal(f.db.sqlite.prepare('SELECT request_hash h FROM design_conversation_turns WHERE request_key=?').get(PINNED_KEY)!.h,PINNED_HASH);
  // A style made only of invisible characters is no style: the same identity formula.
  const invisible=await f.call('POST',base+'/messages',message('92',{style:'​ ﻿'}));assert.equal(invisible.status,202,JSON.stringify(invisible.json));
  assert.equal(f.db.sqlite.prepare('SELECT request_hash h FROM ai_workflows WHERE id=?').get(invisible.data.id)!.h,await sha256(PINNED_IDENTITY.replace(PINNED_KEY,message('92').requestKey)));
  assert.equal(f.db.sqlite.prepare('SELECT style FROM design_conversation_turns WHERE request_key=?').get(message('92').requestKey)!.style,null);
  const styled=await f.call('POST',base+'/messages',message('91',{style:'暖沙色'}));assert.equal(styled.status,202);
  assert.equal(f.db.sqlite.prepare('SELECT request_hash h FROM ai_workflows WHERE id=?').get(styled.data.id)!.h,await sha256(PINNED_IDENTITY.replace(PINNED_KEY,message('91').requestKey).replace(/}$/,',"style":"暖沙色"}')));
 }finally{f.db.close();}
});

test('style is one visible line: line breaks and control characters are rejected, invisible characters are removed, and the limit counts characters',async t=>{
 const parse=(style:unknown)=>designMessageSchema.safeParse(message('1',{style}));
 for(const bad of ['a\nb','a\r\nb','a\u0000b','a\tb','a b','a\u001Bb','a\n\n<script>alert(1)</script>\u0000b']){
  const result=parse(bad);assert.equal(result.success,false,JSON.stringify(bad));assert.match(result.error!.issues[0].message,/一行文字/);
 }
 for(const blank of ['​','​‌‍﻿','  ⁠ ','‮'])assert.equal(designMessageSchema.parse(message('1',{style:blank})).style,undefined,JSON.stringify(blank));
 assert.equal(designMessageSchema.parse(message('1',{style:'​暖‍沙﻿色 ‮'})).style,'暖沙色');
 // Leading and trailing line breaks are whitespace and are trimmed like spaces.
 assert.equal(designMessageSchema.parse(message('1',{style:'\n 简洁 \n'})).style,'简洁');
 assert.equal(parse('😀'.repeat(200)).success,true);
 const emoji=parse('😀'.repeat(201));assert.equal(emoji.success,false);assert.match(emoji.error!.issues[0].message,/200/);
 for(const wrong of [5,['x'],{a:1},true])assert.equal(parse(wrong).success,false);
 const f=await fixture();
 try{
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return respond('read_project');});
  const refused=await f.call('POST',base+'/messages',message('95',{style:'a\n\n<script>alert(1)</script>\u0000b'}));
  assert.equal(refused.status,400);assert.equal(refused.error.code,'VALIDATION');assert.match(refused.error.message,/视觉风格/);
  assert.equal(calls,0);assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns'),0);
 }finally{f.db.close();}
});

test('a styled message is accepted over HTTP, persisted on the turn, given to the model and returned with the assistant reply',async t=>{
 const f=await fixture();
 try{
  let seen:any=null;
  t.mock.method(globalThis,'fetch',async(_url:string,init:RequestInit)=>{seen=JSON.parse(String(init.body));return respond('read_project',{},'我先阅读项目需求和现有页面。\n```html\n<div>internal</div>\n```\n{"arguments":"secret"}');});
  const sent=await f.call('POST',base+'/messages',message('10',{style:'暖沙色 · 标题留白'}));
  assert.equal(sent.status,202,JSON.stringify(sent.json));assert.equal(sent.json.ok,true);
  const view=sent.data;
  assert.equal(view.style,'暖沙色 · 标题留白');assert.equal(view.state,'ready');assert.equal(view.stepsUsed,1);
  assert.deepEqual(view.assistantReplies,[{ordinal:1,text:'我先阅读项目需求和现有页面。'}]);assert.equal(view.assistantReply,'我先阅读项目需求和现有页面。');
  assert.equal(JSON.parse(seen.input[0].content[0].text).style,'暖沙色 · 标题留白');
  assert.ok(seen.tools.find((x:any)=>x.name==='finish').parameters.required.includes('summary'));
  // The designer is told to stay white-label in everything the customer reads.
  assert.match(seen.instructions,/你是 Benos 网站设计师/);
  assert.match(seen.instructions,/不输出内部源码、工具、计费、厂商或服务器信息/);
  assert.match(seen.instructions,/不披露模型、厂商、接口地址或内部工具/);
  assert.equal(f.db.sqlite.prepare('SELECT style FROM design_conversation_turns WHERE request_key=?').get(message('10').requestKey)!.style,'暖沙色 · 标题留白');
  assert.equal(f.db.sqlite.prepare('SELECT public_reply FROM ai_workflow_steps WHERE workflow_id=?').get(view.id)!.public_reply,'我先阅读项目需求和现有页面。');
  const page=await f.call('GET',base+'/conversation');
  assert.equal(page.status,200);assert.equal(page.json.ok,true);assert.equal(page.data.nextCursor,null);
  assert.equal(page.data.items.length,1);
  const turn=page.data.items[0];
  assert.equal(turn.workflowId,view.id);assert.equal(turn.id,view.id);assert.equal(turn.recordKind,'workflow');assert.equal(turn.requestOrigin,'account');
  assert.equal(turn.requestKey,message('10').requestKey);assert.equal(turn.requestPrompt,message('10').prompt);assert.equal(turn.style,'暖沙色 · 标题留白');
  assert.equal(turn.state,'ready');assert.equal(turn.stepsUsed,1);assert.equal(turn.consumedMicros,view.consumedMicros);assert.equal(turn.heldMicros,0);
  assert.deepEqual(turn.assistantReplies,view.assistantReplies);assert.equal(turn.errorMessage,null);assert.equal(turn.recoverable,false);
  const byKey=await f.call('GET',base+'/conversation/'+message('10').requestKey);
  assert.equal(byKey.status,200);assert.deepEqual(byKey.data,turn);
  const serialized=JSON.stringify(page.json)+JSON.stringify(sent.json);
  assert.doesNotMatch(serialized,/sk-fixture|opaque_reasoning|encrypted_content|openai|internal|secret|<div|```/i);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='ai.message_received' AND actor_id='u'"),1);
 }finally{f.db.close();}
});

test('assistant replies are stored per round, the finish summary appears only when a candidate exists, and older rounds are still readable',async()=>{
 const f=await fixture();
 try{
  let n=0;const send:typeof fetch=async()=>{n++;
   if(n===1)return respond('finish',{summary:'这句不应出现：尚未检查'},'');
   if(n===2)return respond('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(proposed())}]},'我把首页标题改为 Benos 工作室。');
   if(n===3)return respond('check_preview');
   return respond('finish',{summary:'首页标题已改为“Benos 工作室”，其余内容保持不变。<script>x</script>'});
  };
  let w=await sendDesignMessage(f.env,'u','p',message('20',{style:'简洁'}),{fetch:send});
  assert.equal(w.steps[0].tools[0].code,'PREVIEW_CHECK_REQUIRED');assert.deepEqual(w.assistantReplies,[]);
  // A message is checked and saved by the system as soon as its design passes: no further round is spent.
  w=await continueWorkflow(f.env,'u',w.id,{fetch:send},2);
  assert.equal(w.state,'succeeded');assert.ok(w.candidateId);assert.equal(w.stepsUsed,2);
  assert.deepEqual(w.assistantReplies,[{ordinal:2,text:'我把首页标题改为 Benos 工作室。'}]);
  // A round persisted before replies were stored keeps working from its inline response.
  f.db.sqlite.prepare('UPDATE ai_workflow_steps SET public_reply=NULL WHERE workflow_id=? AND ordinal=2').run(w.id);
  const turn=(await f.call('GET',base+'/conversation/'+message('20').requestKey)).data;
  assert.equal(turn.candidateId,w.candidateId);assert.equal(turn.previewUrl,w.previewUrl);assert.equal(turn.candidateState,'draft');
  assert.deepEqual(turn.assistantReplies.map((r:any)=>r.ordinal),[2]);assert.equal(turn.assistantReply,'我把首页标题改为 Benos 工作室。');
  assert.equal(n,2);
  // That fallback is stored once, so later reads do not parse the response again,
  // and the workflow view shows the same text whichever view derives it first.
  assert.equal(f.db.sqlite.prepare('SELECT public_reply FROM ai_workflow_steps WHERE workflow_id=? AND ordinal=2').get(w.id)!.public_reply,'我把首页标题改为 Benos 工作室。');
  f.db.sqlite.prepare('UPDATE ai_workflow_steps SET public_reply=NULL WHERE workflow_id=? AND ordinal=2').run(w.id);
  const viewed=(await f.call('GET','/api/ai/workflows/'+w.id)).data;
  assert.deepEqual(viewed.assistantReplies,turn.assistantReplies);assert.equal(viewed.assistantReply,turn.assistantReply);
  assert.equal(f.db.sqlite.prepare('SELECT public_reply FROM ai_workflow_steps WHERE workflow_id=? AND ordinal=2').get(w.id)!.public_reply,'我把首页标题改为 Benos 工作室。');
  assert.deepEqual((await f.call('GET',base+'/workflows')).data.items.find((x:any)=>x.id===w.id).assistantReplies,turn.assistantReplies);
  // Rounds without any assistant text store an empty reply once and are not shown.
  assert.deepEqual(f.db.sqlite.prepare('SELECT ordinal,public_reply FROM ai_workflow_steps WHERE workflow_id=? ORDER BY ordinal').all(w.id).map(r=>[r.ordinal,r.public_reply]),[[1,''],[2,'我把首页标题改为 Benos 工作室。']]);
  // Recorded `finish` calls without arguments remain valid.
  let m=0;const legacy:typeof fetch=async()=>{m++;return m===1?respond('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(proposed())}]}):respond(m===2?'check_preview':'finish');};
  let old=await createWorkflow(f.env,'u','p2',{...await quoted(f),requestKey:'legacy-finish-0001'},{fetch:legacy});
  for(const step of [2,3])old=await continueWorkflow(f.env,'u',old.id,{fetch:legacy},step);
  assert.equal(old.state,'succeeded');assert.deepEqual(old.assistantReplies,[]);assert.equal(old.assistantReply,null);
  for(const tools of [WORKFLOW_TOOLS,PROJECTED_WORKFLOW_TOOLS])assert.deepEqual((tools.find(x=>x.name==='finish')!.parameters as any).required,['summary']);
 }finally{f.db.close();}
});

async function quoted(f:Fixture):Promise<WorkflowInput>{
 const quote=await workflowQuote(f.env,'u','p2');
 return {requestKey:'quoted-request-0001',prompt:'制作实际企业网站，主页标题改为 Benos 工作室',baseVersionId:null,scope:{kind:'site'},maxSteps:6,maxCostMicros:10_000_000,quoteHash:quote.quoteHash!,referenceMediaIds:[],confirmedCharge:true};
}

test('a refused message is stored before any reservation, listed in the conversation, replays its refusal and never reaches billing',async t=>{
 const f=await fixture({balance:1000});
 try{
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return respond('read_project');});
  const body=message('30',{style:'极简'});
  const refused=await f.call('POST',base+'/messages',body);
  assert.equal(refused.status,409);assert.equal(refused.json.ok,false);assert.equal(refused.error.code,'INSUFFICIENT_CREDIT');assert.ok(refused.error.requestId);
  // The stored text names the stable per-round requirement, never the balance of the moment.
  assert.match(refused.error.message,/本轮需预留 \$\d/);assert.doesNotMatch(refused.error.message,/0\.001|当前可用/);
  const page=await f.call('GET',base+'/conversation?limit=20');
  assert.equal(page.status,200);assert.equal(page.data.items.length,1);
  const turn=page.data.items[0];
  assert.equal(turn.recordKind,'message');assert.equal(turn.workflowId,null);assert.match(turn.id,/^turn_/);assert.equal(turn.transcriptId,turn.id);
  assert.equal(turn.state,'failed');assert.equal(turn.errorCode,'INSUFFICIENT_CREDIT');assert.equal(turn.errorMessage,refused.error.message);
  assert.equal(turn.requestPrompt,body.prompt);assert.equal(turn.style,'极简');assert.deepEqual(turn.scope,{kind:'site'});assert.equal(turn.recoverable,false);
  assert.deepEqual(turn.assistantReplies,[]);assert.equal(turn.assistantReply,null);assert.equal(turn.stepsUsed,0);assert.equal(turn.heldMicros,0);
  assert.deepEqual((await f.call('GET',base+'/conversation/'+body.requestKey)).data,turn);
  // The workflow receipt does not exist; the conversation turn does.
  assert.equal((await f.call('GET',base+'/messages/'+body.requestKey)).status,404);
  // The refusal is final for this key and replays word for word, even after a top-up.
  await grantCredit(f.env.DB,{id:'more',userId:'u',source:'topup',amountMicros:40_000_000,referenceId:'more'});
  const replay=await f.call('POST',base+'/messages',body);
  assert.equal(replay.status,409);assert.equal(replay.error.code,'INSUFFICIENT_CREDIT');assert.equal(replay.error.message,refused.error.message);
  const conflict=await f.call('POST',base+'/messages',{...body,prompt:'另一个需求'});
  assert.equal(conflict.status,409);assert.equal(conflict.error.code,'IDEMPOTENCY_CONFLICT');
  const otherProject=await f.call('POST','/api/ai/projects/p2/messages',body);
  assert.equal(otherProject.status,409);assert.equal(otherProject.error.code,'IDEMPOTENCY_CONFLICT');
  // A legacy quoted workflow cannot reuse a refused key either.
  await assert.rejects(createWorkflow(f.env,'u','p',{...await quoted(f),requestKey:body.requestKey}),(e:unknown)=>e instanceof AppError&&e.code==='IDEMPOTENCY_CONFLICT');
  assert.equal(calls,0);assert.equal(count(f,'SELECT COUNT(*) n FROM ai_workflows'),0);
  assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns'),1);
  assert.equal(count(f,'SELECT COUNT(*) n FROM api_reservations'),0);
  assert.deepEqual(f.db.sqlite.prepare("SELECT state,error_code,error_status FROM design_conversation_turns").all().map(r=>({...r})),[{state:'failed',error_code:'INSUFFICIENT_CREDIT',error_status:409}]);
  // One audit row for the receipt and one for the refusal; neither holds the prompt or the style.
  const audits=f.db.sqlite.prepare("SELECT action,actor_id,entity_type,entity_id,details_json,request_id FROM audit_logs WHERE action LIKE 'ai.message%' ORDER BY action").all().map(r=>({...r,details:JSON.parse(String(r.details_json))})) as Record<string,any>[];
  assert.deepEqual(audits.map(a=>[a.action,a.actor_id,a.entity_type,a.entity_id,a.request_id]),[['ai.message_received','u','design_conversation_turn',turn.id,body.requestKey],['ai.message_refused','u','design_conversation_turn',turn.id,body.requestKey]]);
  assert.deepEqual(audits[0].details,{projectId:'p',requestKey:body.requestKey,scope:'site',referenceCount:0,style:true});
  assert.deepEqual(audits[1].details,{projectId:'p',requestKey:body.requestKey,code:'INSUFFICIENT_CREDIT',status:409});
  assert.doesNotMatch(JSON.stringify(audits),/首页标题|Benos 工作室|极简|另一个需求/);
  // A new key is a new attempt and now succeeds.
  f.db.sqlite.prepare("UPDATE design_conversation_turns SET created_at='2026-01-01T00:00:00.000Z'").run();
  const fresh=await f.call('POST',base+'/messages',message('31'));
  assert.equal(fresh.status,202);assert.equal(fresh.data.state,'ready');assert.equal(calls,1);
  const items=(await f.call('GET',base+'/conversation')).data.items;
  assert.deepEqual(items.map((i:any)=>[i.requestKey,i.state]),[[message('31').requestKey,'ready'],[body.requestKey,'failed']]);
 }finally{f.db.close();}
});

test('5xx answers and platform-side conditions are never stored as refusals: the turn stays resumable and the same key works once the service is back',async t=>{
 // Which refusals stick to a key.
 for(const [error,final] of [[new AppError('VERSION_CONFLICT','x',409),true],[new AppError('ASSET_LIMIT','x'),true],[new AppError('WORKSPACE_TOO_LARGE','x',413),true],
  [new AppError('AI_NOT_CONFIGURED','x',503),false],[new AppError('AI_BILLING_UNVERIFIED','x',503),false],[new AppError('AI_BILLING_UNVERIFIED','x',409),false],[new AppError('CAPABILITY_TEST_REQUIRED','x',409),false],
  [new AppError('VISION_BILLING_UNVERIFIED','x',503),false],[new AppError('DESIGN_MANIFEST_UNAVAILABLE','x',503),false],[new AppError('RATE_LIMITED','x',429),false],[new AppError('IDEMPOTENCY_CONFLICT','x',409),false],
  [new AppError('STORAGE_FAILURE','x',503),false],[new Error('unexpected'),false]] as const)assert.equal(finalRefusal(error),final,String((error as AppError).code??error));
 // Operator wording never reaches a customer; code and status are kept.
 for(const [code,status,raw] of [['CAPABILITY_TEST_REQUIRED',409,'需要先完成此配置版本的真实小额功能与计费测试'],['AI_BILLING_UNVERIFIED',503,'模型价格与已审核计费版本不一致，请核对新版本'],['VISION_BILLING_UNVERIFIED',503,'当前模型的参考图输入计费尚未核验；这些图片只能用于人工设计参考']] as const){
  const shown=customerRefusal(new AppError(code,raw,status)) as AppError;
  assert.equal(shown.code,code);assert.equal(shown.status,status);assert.doesNotMatch(shown.message,/计费|核验|审核|配置版本|小额|模型/);assert.match(shown.message,/重新发送/);
 }
 const untouched=new AppError('VERSION_CONFLICT','当前设计已变化，请刷新后重新发送',409);assert.equal(customerRefusal(untouched),untouched);
 const f=await fixture({configured:false});
 try{
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return respond('read_project');});
  const body=message('35',{style:'极简'});
  // 503: the service is not configured. Unknown outcome for the client, nothing final.
  const down=await f.call('POST',base+'/messages',body);
  assert.equal(down.status,503);assert.equal(down.error.code,'AI_NOT_CONFIGURED');
  const pending=(await f.call('GET',base+'/conversation/'+body.requestKey)).data;
  assert.equal(pending.recordKind,'message');assert.equal(pending.state,'received');assert.equal(pending.recoverable,true);assert.equal(pending.errorCode,null);assert.equal(pending.errorMessage,null);
  assert.equal((await f.call('GET',base+'/messages/'+body.requestKey)).status,404);
  // The paid capability test is no longer a platform-side condition: a configured service with a passed access
  // check takes the message. Refusals an earlier build stored under that code keep their neutral wording below.
  const untested={error:{message:'AI 设计服务正在维护，暂时无法处理新消息，请稍后重新发送'}};
  assert.equal(calls,0);assert.equal(count(f,'SELECT COUNT(*) n FROM api_reservations'),0);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='ai.message_refused'"),0);
  assert.doesNotMatch(JSON.stringify(f.db.sqlite.prepare('SELECT * FROM design_conversation_turns').all()),/计费测试|配置版本/);
  // A refusal stored with operator wording by an earlier build is shown and replayed in neutral words.
  f.db.sqlite.prepare("INSERT INTO design_conversation_turns(id,user_id,project_id,request_key,request_hash,prompt,scope_json,reference_ids_json,state,error_code,error_message,error_status,created_at,updated_at) VALUES('turn_old','u','p',?,?,?,'{\"kind\":\"site\"}','[]','failed','CAPABILITY_TEST_REQUIRED','需要先完成此配置版本的真实小额功能与计费测试',409,'2026-01-01T00:00:00.000Z','2026-01-01T00:00:00.000Z')")
   .run(message('36').requestKey,await sha256(JSON.stringify({origin:'account-design-message-v1',projectId:'p',...designMessageSchema.parse(message('36'))})),message('36').prompt);
  const old=(await f.call('GET',base+'/conversation/'+message('36').requestKey)).data;
  assert.equal(old.state,'failed');assert.equal(old.errorCode,'CAPABILITY_TEST_REQUIRED');assert.equal(old.errorMessage,untested.error.message);
  const oldReplay=await f.call('POST',base+'/messages',message('36'));
  assert.equal(oldReplay.status,409);assert.equal(oldReplay.error.code,'CAPABILITY_TEST_REQUIRED');assert.equal(oldReplay.error.message,untested.error.message);
  f.db.sqlite.prepare("DELETE FROM design_conversation_turns WHERE id='turn_old'").run();
  // Once the service is back, the SAME key and body start the workflow on the same turn.
  await configure(f,false);
  const resumed=await f.call('POST',base+'/messages',body);
  assert.equal(resumed.status,202,JSON.stringify(resumed.json));assert.equal(resumed.data.state,'ready');assert.equal(resumed.data.style,'极简');assert.equal(calls,1);
  const turn=(await f.call('GET',base+'/conversation/'+body.requestKey)).data;
  assert.equal(turn.transcriptId,pending.transcriptId);assert.equal(turn.workflowId,resumed.data.id);assert.equal(turn.state,'ready');
  assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns'),1);assert.equal(count(f,'SELECT COUNT(*) n FROM ai_workflows'),1);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='ai.message_received'"),1);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='ai.message_refused'"),0);
 }finally{f.db.close();}
});

test('insufficient credit and a stale base version are refused without a hold and appear in history',async t=>{
 const f=await fixture({balance:1000});
 try{
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return respond('read_project');});
  const poor=await f.call('POST',base+'/messages',message('40'));
  assert.equal(poor.status,409);assert.equal(poor.error.code,'INSUFFICIENT_CREDIT');
  const wallet=await getWallet(f.env.DB,'u');assert.equal(wallet.heldMicros,0);assert.equal(wallet.availableMicros,1000);
  assert.equal(Number(f.db.sqlite.prepare("SELECT reserved_micros FROM provider_pools WHERE provider_id='openai-main'").get()!.reserved_micros),0);
  f.db.sqlite.prepare("UPDATE design_conversation_turns SET created_at='2026-01-01T00:00:00.000Z'").run();
  await grantCredit(f.env.DB,{id:'more',userId:'u',source:'topup',amountMicros:20_000_000,referenceId:'more'});
  const version=await saveVersion(f.env,'u','p',example,'manual',null,'conversation-route-base');
  const stale=await f.call('POST',base+'/messages',message('41'));
  assert.equal(stale.status,409);assert.equal(stale.error.code,'VERSION_CONFLICT');
  const items=(await f.call('GET',base+'/conversation')).data.items;
  assert.deepEqual(items.map((i:any)=>[i.requestKey,i.state,i.errorCode]),[[message('41').requestKey,'failed','VERSION_CONFLICT'],[message('40').requestKey,'failed','INSUFFICIENT_CREDIT']]);
  assert.match(items[1].errorMessage,/本轮需预留/);
  const ok=await f.call('POST',base+'/messages',message('42',{baseVersionId:version}));
  assert.equal(ok.status,202);assert.equal(calls,1);
  assert.equal(count(f,'SELECT COUNT(*) n FROM api_reservations'),1);
 }finally{f.db.close();}
});

test('a transient local failure leaves the message resumable with the same key and links the later workflow to the same turn',async t=>{
 for(const failure of [()=>new Error('fixture D1 hiccup'),()=>new AppError('STORAGE_FAILURE','存储暂时不可用',503)]){
  const f=await fixture();
  try{
   let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return respond('read_project');});
   const prepare=f.db.prepare.bind(f.db);let fail=true;
   (f.db as any).prepare=(sql:string)=>{if(fail&&sql.includes("FROM integration_configs WHERE kind='text'")){fail=false;throw failure();}return prepare(sql);};
   const body=message('50');
   const first=await f.call('POST',base+'/messages',body);
   assert.ok(first.status>=500);assert.equal(calls,0);
   const pending=(await f.call('GET',base+'/conversation/'+body.requestKey)).data;
   assert.equal(pending.state,'received');assert.equal(pending.recordKind,'message');assert.equal(pending.recoverable,true);assert.equal(pending.errorCode,null);
   const resumed=await f.call('POST',base+'/messages',body);
   assert.equal(resumed.status,202);assert.equal(resumed.data.state,'ready');assert.equal(calls,1);
   const turn=(await f.call('GET',base+'/conversation/'+body.requestKey)).data;
   assert.equal(turn.workflowId,resumed.data.id);assert.equal(turn.transcriptId,pending.transcriptId);assert.equal(turn.state,'ready');
   assert.equal(f.db.sqlite.prepare('SELECT state FROM design_conversation_turns').get()!.state,'linked');
   assert.equal((await f.call('GET',base+'/conversation')).data.items.length,1);
   assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='ai.message_refused'"),0);
  }finally{f.db.close();}
  t.mock.restoreAll();
 }
});

test('concurrent identical sends create one turn, one workflow and one paid round',async()=>{
 const f=await fixture();
 try{
  let calls=0;const runtime={fetch:async()=>{calls++;return respond('read_project',{},'开始阅读项目。');}};
  const copies=await Promise.all(Array.from({length:8},()=>sendDesignMessage(f.env,'u','p',message('60',{style:'温暖'}),runtime)));
  assert.equal(new Set(copies.map(c=>c.id)).size,1);assert.equal(calls,1);
  assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns'),1);assert.equal(count(f,'SELECT COUNT(*) n FROM ai_workflows'),1);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='ai.message_received'"),1);
  assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
  const items=(await f.call('GET',base+'/conversation')).data.items;
  assert.equal(items.length,1);assert.equal(items[0].workflowId,copies[0].id);assert.equal(items[0].assistantReply,'开始阅读项目。');
 }finally{f.db.close();}
});

test('conversation pages are newest first, cursor-bounded per project, owner-only and validated',async t=>{
 const f=await fixture();
 try{
  t.mock.method(globalThis,'fetch',async()=>respond('read_project'));
  const keys:string[]=[];
  for(const n of ['70','71','72']){
   const sent=await f.call('POST',base+'/messages',message(n));assert.equal(sent.status,202);keys.push(message(n).requestKey);
   f.db.sqlite.prepare('UPDATE design_conversation_turns SET created_at=? WHERE request_key=?').run(new Date(Date.UTC(2026,10,1,0,0,Number(n))).toISOString(),message(n).requestKey);
  }
  // A legacy quoted workflow has no turn and is still part of the history.
  const legacy=await createWorkflow(f.env,'u','p',{...await quoted(f),requestKey:'quoted-legacy-turn-001'},{fetch:async()=>respond('read_project')});
  f.db.sqlite.prepare('UPDATE ai_workflows SET created_at=? WHERE id=?').run('2026-10-01T00:00:00.000Z',legacy.id);
  await f.call('POST','/api/ai/projects/p2/messages',message('73'));
  const first=await f.call('GET',base+'/conversation?limit=2');
  assert.deepEqual(first.data.items.map((i:any)=>i.requestKey),[keys[2],keys[1]]);assert.ok(first.data.nextCursor);
  const second=await f.call('GET',base+'/conversation?limit=2&before='+encodeURIComponent(first.data.nextCursor));
  assert.deepEqual(second.data.items.map((i:any)=>i.requestKey),[keys[0],'quoted-legacy-turn-001']);assert.equal(second.data.nextCursor,null);
  assert.equal(second.data.items[1].requestOrigin,'quoted');assert.equal(second.data.items[1].recordKind,'workflow');
  assert.equal((await f.call('GET',base+'/conversation?limit=50')).data.items.length,4);
  for(const query of ['limit=0','limit=51','limit=abc','limit=1.5']){
   const bad=await f.call('GET',base+'/conversation?'+query);assert.equal(bad.status,400,query);assert.equal(bad.error.code,'VALIDATION');
  }
  for(const cursor of ['not-a-cursor','x'.repeat(901)]){
   const bad=await f.call('GET',base+'/conversation?before='+cursor);assert.equal(bad.status,400);
  }
  const foreignCursor=(await f.call('GET','/api/ai/projects/p2/conversation?limit=1')).data;
  assert.equal(foreignCursor.items.length,1);
  const p2Cursor=Buffer.from(JSON.stringify({p:'p2',t:'2030-01-01T00:00:00.000Z',i:'turn_x'})).toString('base64url');
  const crossed=await f.call('GET',base+'/conversation?before='+p2Cursor);assert.equal(crossed.status,400);assert.equal(crossed.error.code,'INVALID_CURSOR');
  // Ownership: other users, archived and unknown projects are not found.
  assert.equal((await f.call('GET',base+'/conversation',undefined,f.otherHeaders)).status,404);
  assert.equal((await f.call('GET',base+'/conversation/'+keys[0],undefined,f.otherHeaders)).status,404);
  assert.equal((await f.call('GET','/api/ai/projects/missing/conversation')).status,404);
  const others=await f.call('GET','/api/ai/projects/other-project/conversation',undefined,f.otherHeaders);
  assert.equal(others.status,200);assert.deepEqual(others.data,{items:[],nextCursor:null});
  assert.equal((await f.call('GET',base+'/conversation/unknown-request-key-0001')).status,404);
  const malformed=await f.call('GET',base+'/conversation/short');assert.equal(malformed.status,400);assert.equal(malformed.error.code,'VALIDATION');
  f.db.sqlite.prepare("UPDATE projects SET archived_at=? WHERE id='p'").run(new Date().toISOString());
  assert.equal((await f.call('GET',base+'/conversation')).status,404);
  // Authentication is required.
  const anonymous=await app.request(base+'/conversation',{},f.env);assert.equal(anonymous.status,401);
 }finally{f.db.close();}
});

test('large-workspace rounds store their reply at completion and an unreadable old receipt never breaks the history',async()=>{
 const f=await fixture();
 try{
  const get=f.storage.get.bind(f.storage);
  (f.storage as any).get=async(key:string,options?:{range?:{offset:number;length:number}})=>{const object=await get(key);if(!object)return null;const bytes=f.storage.objects.get(key)!;return {...object,arrayBuffer:async()=>new Uint8Array(options?.range?bytes.subarray(options.range.offset,options.range.offset+options.range.length):bytes).buffer};};
  (f.storage as any).delete=async(key:string|string[])=>{for(const item of Array.isArray(key)?key:[key])f.storage.objects.delete(item);};
  const manifest=structuredClone(example);manifest.templates[0].document.html+='<!--'+'x'.repeat(3*1048576)+'-->';
  const version=await saveVersion(f.env,'u','p',manifest,'manual',null,'conversation-large-source');
  let calls=0;const send:typeof fetch=async(_url,init)=>{calls++;const payload=JSON.parse(String(init?.body));
   if(calls===1)return respond('find_text',{path:'templates/1.html',query:'首页结构示例',offset:0},'我先找到首页标题的位置。');
   if(calls===2){const found=JSON.parse(payload.input.find((x:any)=>x.type==='function_call_output').output);return respond('propose_edits',{expectedRevision:found.revision,edits:[{path:found.path,expectedSha:found.fileSha,spanRef:found.matches[0].spanRef,replacement:'Benos 大站设计'}],mediaIds:[]});}
   return calls===3?respond('check_preview'):respond('finish',{summary:'首页标题已更新。'});};
  let w=await sendDesignMessage(f.env,'u','p',message('80',{baseVersionId:version}),{fetch:send});
  assert.ok(w.workspaceId);
  for(let step=2;step<=4;step++)w=await continueWorkflow(f.env,'u',w.id,{fetch:send},step);
  assert.equal(w.state,'succeeded');assert.equal(calls,4);
  assert.deepEqual(w.assistantReplies,[{ordinal:1,text:'我先找到首页标题的位置。'},{ordinal:4,text:'首页标题已更新。'}]);
  // A round written before this release: the reply is recovered from the private receipt once.
  f.db.sqlite.prepare('UPDATE ai_workflow_steps SET public_reply=NULL WHERE workflow_id=? AND ordinal=1').run(w.id);
  assert.equal((await f.call('GET',base+'/conversation')).data.items[0].assistantReplies[0].text,'我先找到首页标题的位置。');
  assert.equal(f.db.sqlite.prepare('SELECT public_reply FROM ai_workflow_steps WHERE workflow_id=? AND ordinal=1').get(w.id)!.public_reply,'我先找到首页标题的位置。');
  const stored=()=>f.db.sqlite.prepare('SELECT public_reply FROM ai_workflow_steps WHERE workflow_id=? AND ordinal=1').get(w.id)!.public_reply;
  const forget=()=>f.db.sqlite.prepare('UPDATE ai_workflow_steps SET public_reply=NULL WHERE workflow_id=? AND ordinal=1').run(w.id);
  const both=[{ordinal:1,text:'我先找到首页标题的位置。'},{ordinal:4,text:'首页标题已更新。'}],last=both.slice(1);
  // The workflow view derives the same text through the same loader, and stores it as well.
  forget();
  assert.deepEqual((await f.call('GET','/api/ai/workflows/'+w.id)).data.assistantReplies,both);assert.equal(stored(),'我先找到首页标题的位置。');
  forget();
  assert.deepEqual((await f.call('GET',base+'/workflows')).data.items[0].assistantReplies,both);assert.equal(stored(),'我先找到首页标题的位置。');
  // Once stored, reading the history does not touch storage at all.
  let reads=f.storage.gets;
  for(const path of [base+'/conversation','/api/ai/workflows/'+w.id,base+'/conversation/'+message('80').requestKey])assert.equal((await f.call('GET',path)).status,200);
  assert.equal(f.storage.gets,reads);
  // Storage that cannot be reached right now is not a verdict: nothing is stored and the next read recovers.
  forget();
  const working=f.storage.get;(f.storage as any).get=async()=>{throw new Error('fixture storage outage');};
  const outage=await f.call('GET',base+'/conversation');
  assert.equal(outage.status,200);assert.deepEqual(outage.data.items[0].assistantReplies,last);assert.equal(stored(),null);
  assert.deepEqual((await f.call('GET','/api/ai/workflows/'+w.id)).data.assistantReplies,last);assert.equal(stored(),null);
  (f.storage as any).get=working;
  assert.deepEqual((await f.call('GET',base+'/conversation')).data.items[0].assistantReplies,both);assert.equal(stored(),'我先找到首页标题的位置。');
  // A receipt that is missing or fails verification stays that way: the turn is
  // listed without the reply, an empty reply is stored, and storage is read once.
  forget();
  const key=String(f.db.sqlite.prepare("SELECT o.object_key k FROM ai_workflow_steps s JOIN design_edit_objects o ON o.id=s.response_object_id WHERE s.workflow_id=? AND s.ordinal=1").get(w.id)!.k);
  const receipt=f.storage.objects.get(key)!;
  f.storage.objects.delete(key);
  reads=f.storage.gets;
  const page=await f.call('GET',base+'/conversation');
  assert.equal(page.status,200);assert.deepEqual(page.data.items[0].assistantReplies,last);
  assert.equal(stored(),'');assert.equal(f.storage.gets,reads+1);
  for(const path of [base+'/conversation',base+'/conversation?limit=50','/api/ai/workflows/'+w.id,base+'/workflows']){
   const again=await f.call('GET',path);assert.equal(again.status,200);
   assert.deepEqual((again.data.items?.[0]??again.data).assistantReplies,last);
  }
  assert.equal(f.storage.gets,reads+1);
  // The same holds for a receipt whose bytes no longer match their digest.
  forget();const tampered=new Uint8Array(receipt);tampered[tampered.length-2]^=1;f.storage.objects.set(key,tampered);
  reads=f.storage.gets;
  for(let i=0;i<3;i++)assert.deepEqual((await f.call('GET','/api/ai/workflows/'+w.id)).data.assistantReplies,last);
  assert.equal(stored(),'');assert.equal(f.storage.gets,reads+1);
 }finally{f.db.close();}
});

test('another user cannot post into a project they do not own: nothing is stored, audited or dispatched, and request keys are per user',async t=>{
 const f=await fixture();
 try{
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return respond('read_project');});
  const foreign=await f.call('POST',base+'/messages',message('100'),f.otherHeaders);
  assert.equal(foreign.status,404);assert.equal(foreign.error.code,'NOT_FOUND');
  assert.equal(calls,0);assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns'),0);assert.equal(count(f,'SELECT COUNT(*) n FROM ai_workflows'),0);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action LIKE 'ai.message%'"),0);assert.equal(count(f,'SELECT COUNT(*) n FROM api_reservations'),0);
  // The same key used by two users is two independent messages.
  assert.equal((await f.call('POST',base+'/messages',message('101'))).status,202);
  const theirs=await f.call('POST','/api/ai/projects/other-project/messages',message('101'),f.otherHeaders);
  assert.equal(theirs.status,409);assert.equal(theirs.error.code,'INSUFFICIENT_CREDIT'); // `other` has no credit
  assert.equal((await f.call('GET','/api/ai/projects/other-project/conversation/'+message('101').requestKey,undefined,f.otherHeaders)).data.state,'failed');
  assert.equal((await f.call('GET',base+'/conversation/'+message('101').requestKey)).data.state,'ready');
  assert.equal((await f.call('GET',base+'/conversation/'+message('101').requestKey,undefined,f.otherHeaders)).status,404);
  assert.equal((await f.call('GET',base+'/messages/'+message('101').requestKey,undefined,f.otherHeaders)).status,404);
  assert.equal(calls,1);
  // Without a session nothing is accepted either.
  const anonymous=await app.request(base+'/messages',{method:'POST',headers:{'Content-Type':'application/json',Origin:ORIGIN},body:JSON.stringify(message('102'))},f.env);
  assert.ok([401,403].includes(anonymous.status));assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns WHERE request_key=?',message('102').requestKey),0);
 }finally{f.db.close();}
});

test('a copy that finds no credit because the first identical copy already used it returns that workflow and never refuses the turn',async()=>{
 const perStep=textReservationCost({...pricing,maxOutputTokens:24000} as never);
 const f=await fixture({balance:perStep});
 try{
  const body=message('110');let dispatched=0,armed=true,first:any;
  const prepare=f.db.prepare.bind(f.db);
  // The outer copy is paused at its configuration lookup (after it stored the
  // turn, before it reads the wallet) while an identical copy runs to completion.
  (f.db as any).prepare=(sql:string)=>{
   const statement=prepare(sql);
   if(armed&&sql.includes("FROM integration_configs WHERE kind='text'")){
    armed=false;const bind=statement.bind.bind(statement);
    // The multi-provider lookup binds optional configId (including an empty
    // bind for legacy clients), so intercept the final bound statement.
    (statement as any).bind=(...values:Parameters<typeof statement.bind>)=>{const bound=bind(...values),read=bound.first.bind(bound);(bound as any).first=async()=>{first=await sendDesignMessage(f.env,'u','p',body,{fetch:async()=>{dispatched++;return respond('read_project',{},'开始阅读项目。');}});return read();};return bound;};
   }
   return statement;
  };
  const second=await sendDesignMessage(f.env,'u','p',body,{fetch:async()=>{throw new Error('the paused copy must not dispatch');}});
  assert.equal(first.state,'ready');assert.equal(second.id,first.id);assert.equal(second.state,'ready');assert.equal(dispatched,1);
  // The paused copy really had no credit left for a round of its own.
  assert.ok((await getWallet(f.env.DB,'u')).availableMicros<perStep);
  assert.deepEqual({...f.db.sqlite.prepare('SELECT state,error_code,workflow_id FROM design_conversation_turns').get()!},{state:'linked',error_code:null,workflow_id:first.id});
  assert.equal(count(f,'SELECT COUNT(*) n FROM ai_workflows'),1);assert.equal(count(f,'SELECT COUNT(*) n FROM api_reservations'),1);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='ai.message_refused'"),0);
  const items=(await f.call('GET',base+'/conversation')).data.items;
  assert.deepEqual(items.map((i:any)=>[i.recordKind,i.state,i.errorCode,i.errorMessage]),[['workflow','ready',null,null]]);
 }finally{f.db.close();}
});

test('an idempotency conflict is never stored as a refusal, and a key taken by a quoted request gets no second history entry',async t=>{
 const f=await fixture();
 try{
  t.mock.method(globalThis,'fetch',async()=>respond('read_project'));
  // A quoted request takes the key in the instant before the account message stores its turn.
  const body=message('120'),authorization={...await quoted(f),requestKey:body.requestKey};
  const batch=f.db.batch.bind(f.db);let armed=true,quotedId='';
  (f.db as any).batch=async(statements:any[])=>{
   if(armed&&String(statements[0]?.sql).includes('INSERT INTO design_conversation_turns')){armed=false;quotedId=(await createWorkflow(f.env,'u','p',authorization)).id;}
   return batch(statements);
  };
  await assert.rejects(sendDesignMessage(f.env,'u','p',body),(e:unknown)=>e instanceof AppError&&e.code==='IDEMPOTENCY_CONFLICT'&&e.status===409);
  assert.equal(armed,false);assert.ok(quotedId);
  assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns'),0);
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action LIKE 'ai.message%'"),0);
  const entries=(await f.call('GET',base+'/conversation')).data.items.filter((i:any)=>i.requestKey===body.requestKey);
  assert.deepEqual(entries.map((i:any)=>[i.recordKind,i.requestOrigin,i.state,i.errorCode,i.id]),[['workflow','quoted','ready',null,quotedId]]);
  assert.equal((await f.call('GET',base+'/conversation/'+body.requestKey)).data.id,quotedId);
  // The account message keeps answering with the conflict; it still leaves no record.
  const again=await f.call('POST',base+'/messages',body);assert.equal(again.status,409);assert.equal(again.error.code,'IDEMPOTENCY_CONFLICT');
  assert.equal(count(f,'SELECT COUNT(*) n FROM design_conversation_turns'),0);assert.equal(count(f,'SELECT COUNT(*) n FROM ai_workflows'),1);
  // Even if a conflict is reported for a turn that is still waiting, it is not persisted.
  const waiting=designMessageSchema.parse(message('121'));
  await receiveMessage(f.env,'u','p','a'.repeat(64),waiting);
  await rejectMessage(f.env,'u','p',waiting.requestKey,'a'.repeat(64),new AppError('IDEMPOTENCY_CONFLICT','请求编号已用于其他设计任务',409));
  assert.deepEqual({...f.db.sqlite.prepare('SELECT state,error_code FROM design_conversation_turns WHERE request_key=?').get(waiting.requestKey)!},{state:'received',error_code:null});
  assert.equal(count(f,"SELECT COUNT(*) n FROM audit_logs WHERE action='ai.message_refused'"),0);
 }finally{f.db.close();}
});

test('a cosmetic finish summary never fails finish: any value is accepted and only a trimmed string cut to the declared limit is shown',async()=>{
 for(const tools of [WORKFLOW_TOOLS,PROJECTED_WORKFLOW_TOOLS])assert.equal((tools.find(x=>x.name==='finish')!.parameters as any).properties.summary.maxLength,600);
 const cases:[unknown,string|null][]=[['  '+'字'.repeat(601)+'  ','字'.repeat(600)],['好'.repeat(2001),'好'.repeat(600)],['😀'.repeat(601),'😀'.repeat(600)],[null,null],[123,null],[{text:'x'},null],['   ',null]];
 for(const [summary,shown] of cases){
  const f=await fixture();
  try{
   let n=0;const send:typeof fetch=async()=>{n++;
    if(n===1)return respond('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(proposed())}]});
    return n===2?respond('check_preview'):respond('finish',{summary});};
   let w=await quotedRun(f,'130',send);
   for(const step of [2,3])w=await continueWorkflow(f.env,'u',w.id,{fetch:send},step);
   const label=JSON.stringify(summary)?.slice(0,30);
   assert.equal(w.state,'succeeded',label);assert.ok(w.candidateId,label);assert.equal(w.stepsUsed,3,label);
   assert.deepEqual(w.steps[2].tools,[{name:'finish',ok:true,code:null,layoutSaved:false,reviewPassed:false,imageFailures:0}],label);
   assert.equal(w.assistantReply,shown,label);
   assert.equal(count(f,'SELECT COUNT(*) n FROM design_candidates'),1,label);
  }finally{f.db.close();}
 }
});

test('assistant text never names the model, its vendor, the hosting provider, servers, endpoints or tools',async()=>{
 // Sentence-level filter: the offending sentence goes, the useful one stays.
 assert.equal(publicText('我是 OpenAI 的 GPT-6.1 模型，正在调用 read_project 工具。我先调整首页标题。'),'我先调整首页标题。');
 assert.equal(publicText('服务器位于 Hostinger 美国机房 srv123.hstgr.io'),'');
 assert.equal(publicText('参见 [链接](javascript:alert(1)) 与 https://api.openai.com/v1'),'');
 assert.equal(publicText('点击 <img/src=x onerror=alert(1)> 查看'),'');
 assert.equal(publicText('call_id=call_abc resp_123 sk-live-abcdef'),'');
 assert.equal(publicText('可在 hPanel 中查看；配色已统一为暖沙色。'),'配色已统一为暖沙色。');
 assert.equal(publicText('由 ＯｐｅｎＡＩ 提供。由 Open-AI 提供！由 ChatGPT 生成？由 O​pen​AI 生成。版式已更新。'),'版式已更新。');
 assert.equal(publicText('站点运行在 Cloudflare 上，地址 203.0.113.7。\n导航已简化。'),'导航已简化。');
 // Ordinary design notes pass unchanged.
 for(const note of ['我把首页标题改为 Benos 工作室。','An open air layout with more whitespace.','标题字号调大；按钮改为圆角！要继续调整吗？','第一段说明。\n\n第二段说明。'])assert.equal(publicText(note),note);
 // The configured model, endpoint and pool names are denied even when they are not on the fixed list.
 const terms=pricingTerms(JSON.stringify({model:'sol-large-2',baseUrl:'https://llm.vendor-example.net/v1',providerPoolId:'vendor-pool-a',billingProfile:'vendor-standard-2026'}));
 assert.deepEqual(terms,['sol-large-2','vendor-pool-a','vendor-standard-2026','llm.vendor-example.net']);
 assert.deepEqual(pricingTerms(JSON.stringify(pricing)),['gpt-6.1-sol','openai-main','openai-gpt6-standard-2026-11-07','api.openai.com','openai.com']);
 assert.equal(whiteLabel('本轮由 Sol-Large-2 生成。接口为 llm.vendor-example.net。资金池 vendor-pool-a。布局已更新。',terms),'布局已更新。');
 assert.equal(whiteLabel('布局已更新。',terms),'布局已更新。');assert.deepEqual(pricingTerms('not json'),[]);assert.deepEqual(pricingTerms(null),[]);
 const f=await fixture();
 try{
  let n=0;const send:typeof fetch=async()=>{n++;
   if(n===1)return respond('propose_files',{files:[{path:'manifest.json',content:JSON.stringify(proposed())}]},'我是 OpenAI 的 GPT-6.1 模型，正在调用 read_project 工具。我把首页标题改为 Benos 工作室。\n接口地址是 https://api.openai.com/v1 。');
   if(n===2)return respond('check_preview',{},'本轮使用 gpt-6.1-sol 检查结构！结构检查已通过。');
   return respond('finish',{summary:'服务器位于 Hostinger 美国机房 srv123.hstgr.io。首页标题已改为“Benos 工作室”。'});};
  let w=await quotedRun(f,'140',send);
  for(const step of [2,3])w=await continueWorkflow(f.env,'u',w.id,{fetch:send},step);
  assert.equal(w.state,'succeeded');
  const clean=[{ordinal:1,text:'我把首页标题改为 Benos 工作室。'},{ordinal:2,text:'结构检查已通过。'},{ordinal:3,text:'首页标题已改为“Benos 工作室”。'}];
  assert.deepEqual(w.assistantReplies,clean);
  const turn=(await f.call('GET',base+'/conversation')).data.items[0],view=(await f.call('GET','/api/ai/workflows/'+w.id)).data,listed=(await f.call('GET',base+'/workflows')).data.items[0],receipt=(await f.call('GET',base+'/messages/'+message('140').requestKey)).data;
  for(const shown of [turn,view,listed,receipt]){
   assert.deepEqual(shown.assistantReplies,clean);
   assert.doesNotMatch(JSON.stringify(shown),/open\s*ai|gpt|hostinger|hstgr|srv123|机房|api\./i);
   assert.doesNotMatch(shown.assistantReply,/read_project|propose_files|check_preview|工具/);
  }
  // Nothing private is stored as public text either.
  assert.doesNotMatch(JSON.stringify(f.db.sqlite.prepare('SELECT public_reply FROM ai_workflow_steps').all()),/open\s*ai|gpt|hostinger|hstgr|srv123|api\./i);
  // Text stored before this filter existed is filtered again whenever it is read.
  f.db.sqlite.prepare("UPDATE ai_workflow_steps SET public_reply='本方案由 OpenAI 的 gpt-6.1-sol 生成。标题已更新。' WHERE workflow_id=? AND ordinal=1").run(w.id);
  for(const path of [base+'/conversation/'+message('140').requestKey,'/api/ai/workflows/'+w.id]){
   const shown=(await f.call('GET',path)).data;
   assert.equal(shown.assistantReplies[0].text,'标题已更新。');assert.doesNotMatch(JSON.stringify(shown),/open\s*ai|gpt/i);
  }
  // A round recorded before replies were stored is filtered when it is derived from the saved response.
  f.db.sqlite.prepare('UPDATE ai_workflow_steps SET public_reply=NULL WHERE workflow_id=?').run(w.id);
  assert.deepEqual((await f.call('GET','/api/ai/workflows/'+w.id)).data.assistantReplies,clean.slice(0,2));
  assert.deepEqual((await f.call('GET',base+'/conversation')).data.items[0].assistantReplies,clean.slice(0,2));
 }finally{f.db.close();}
});

test('S2 / R-D1a: the white-label filter folds look-alikes and spaced letters and covers more vendors, IPv6 and named hosts, without removing ordinary design advice',()=>{
 const removed=[
  '我是由 Google 训练的大型语言模型。','本回复由通义千问生成。','我是深度求索公司开发的助手。','I am Llama, made by Meta.','Powered by Azure.','我基于 Qwen 模型。',
  '服务器地址是 2606:4700::6810:84e5。','部署在 example-host.net 的节点上。','我是 O p e n A I 训练的 G P T 模型。','我由 Ο𝗉𝖾𝗇ΑΙ 提供。','我是 Сlaude（西里尔 С）。',
  'We run on Microsoft Azure;','后端 IP 是 2001:db8::1。','我们用的是 o3-mini 和 o4 推理模型。','本模型来自 Mistral AI。','我是文心一言。','我是豆包。','我是 Kimi。','我是智谱 GLM-4。',
  '[点我](javascript&#58;alert(1))。','我是 G.P.T 模型。','由 Ｃｌａｕｄｅ 生成。','我是 C‍l­aude。',
 ];
 for(const text of removed)assert.equal(whiteLabel(publicText(text)),'',text);
 // The rest of a reply survives: only the sentence that names the vendor or host goes.
 assert.equal(publicText('我是由 Google 训练的模型。首页标题已改为暖色。'),'首页标题已改为暖色。');
 const kept=['建议使用 Google Fonts 的思源黑体，并补充 meta 描述。','按钮使用 azure 蓝色，hover 时加深。','用 a::before 伪元素做装饰线。','活动时间 10:30 至 12:00。','网站地址 mybrand.com 已在页脚展示。','把联系方式放在 Contact 区块。'];
 for(const text of kept)assert.equal(publicText(text),text,text);
});

test('R2-WL1 / R2-WL2: ordinary SEO and design advice, customer brands and file names stay; self-identification, vendors, hosting location and hidden spellings go',()=>{
 const kept=[
  'Google Fonts are hosted on Google servers; self-host Inter for speed.','Add a meta description before the site is deployed.','部署前请补全 meta 描述和标题。',
  '为提升 Google 搜索排名，首页打造清晰的 H1 结构。','Google indexes server-rendered pages more reliably.','为华为授权经销商打造专业的产品展示页。','阿里山高山茶系列由我们自有茶园出品。',
  '产品 3D 模型在华为手机上也能流畅查看。','你的网站已部署在 shop.example.com，可以预览。','这个节点的颜色来自 theme.css 中的变量。','This node takes its colour from theme.css.',
  'The server returns index.html for every route.','为 Gemini Trading 设计的首页采用深蓝色。','Llama Coffee 的菜单页使用暖色调。','Mistral Yachts 的首屏使用全幅海景图。',
  '产品页展示豆包和豆沙包的图片。','标题引用《文心雕龙》增加文化感。','Use .msg_box for the enquiry form.','Use a serif for headings. Keep body text at 16px. Contrast must be 4.5:1.',
  'Hero: navy #1E3A8A. Fonts: Inter from Google Fonts, hosted locally for speed.','首页加载 logo.png 和 hero.webp，服务器开启 gzip 压缩。','在 Microsoft Edge 和 Chrome 中测试过渲染效果。',
  'As your design assistant, I updated the hero on example.com.','I added a Google Maps embed on the contact page.','An open air layout with more whitespace.',
 ];
 for(const text of kept)assert.equal(whiteLabel(text),text,text);
 const removed=[
  'This assistant is built by Anthrօpic.','我是 Claսde。','I am Ꮯlaude, your design helper.','我是 Gemını 模型。','I am Clɑude.','I am Clau؜de.','Powered by G\u{1D173}PT.',
  'I am Clau de, made for design.','I am Anth-ropic based.','Built on 0penAI tech.',
  '我是讯飞星火大模型。','我基于商汤日日新。','我基于 MiniMax 的海螺模型。','我是百川智能的助手。','我来自阶跃星辰。','I am Grok, made by xAI.','I am Microsoft Copilot.','我是 Meta AI。',
  "I'm from Google.",'我来自谷歌。','I run on Amazon Bedrock.','这张图由 DALL·E 生成。','视频由 Sora 生成。','我是 Sonnet 4.5 模型。',
  '你的网站托管在新加坡机房。','Your site runs on a server in Singapore.','网站部署在立陶宛的数据中心。','素材保存在 R2 存储桶，数据库是 D1。','The API runs as a Worker with KV and Durable Objects.',
  '[后台](https://%68panel.%68ostinger.com)','服务器地址 203。0。113。5','origin is 0xCB007105','Images go through generativelanguage.googleapis.com.',
 ];
 for(const text of removed)assert.equal(publicText(text),'',text);
 // Only the offending sentence goes, also in English prose.
 assert.equal(whiteLabel('Use a serif for headings. Keep body text at 16px. I was trained by Google. Contrast must be 4.5:1.'),'Use a serif for headings. Keep body text at 16px. Contrast must be 4.5:1.');
 assert.equal(whiteLabel('配色已更新。\n我是 Cla\nude 助手。\n导航已简化。'),'配色已更新。\n\n导航已简化。','a name split across two lines removes both lines');
 assert.equal(whiteLabel('[x](java\tscript:alert(1))'),'');
});

test('R3-WL1 / R3-WL2: embeds, registrars, people and products, codes and DOM advice stay; hosting places, object-form makers, more vendors and configured codenames go',()=>{
 const kept=[
  '建议对 fonts.googleapis.com 和 fonts.gstatic.com 加 preconnect，加快 Google Fonts 加载。','询盘按钮可以链接到 https://api.whatsapp.com/send?phone=8613800000000。',
  'Contact page: embed the map from maps.googleapis.com with your factory address.','请在阿里云域名控制台添加这条 CNAME 记录。','如果域名在腾讯云注册，在 DNSPod 里添加 TXT 记录即可。',
  'If your domain uses Cloudflare DNS, set the record to DNS only.','首页可以参考 Claude Monet 睡莲系列的柔和配色。','Garamond 字体源自 16 世纪的 Claude Garamond，适合高端品牌标题。',
  '产品页重点展示 O3 臭氧发生器的产量参数。','首页 Banner 放 O2 工业氧气瓶的实拍图。','在资质栏写明通过 AWS D1.1 焊接认证。','医药客户最关心 GMP 和 GCP 合规，建议放在首屏。','企业理念可以写：苟日新，日日新，又日新。',
  '我基于谷歌的 Material Design 规范调整了按钮阴影。','I took the icons from Google Material Symbols.','I based it on Google Material colours.','联系页加一个由谷歌地图驱动的门店查询。','该型号由华为研发团队联合设计。',
  'Mistral Yachts has three new models this year.','Bedrock Stone 的石材可以用 3D 模型展示纹理。','首页基于 Gemini Trading 的品牌故事展开。','这个节点在 header 下方，建议改成 sticky。','服务器在 200ms 内响应首字节，对 SEO 更友好。',
  '按钮位于卡片节点内部。','主色用 0xFF1E3A8A，辅色用 0xFFF59E0B。','产品编号 SK-2024-BLUE 放在标题下方。','Images are hosted on cdn.yourbrand.com for faster loading.','Our marathon runs in London every April.','工厂位于德国，产品出口到美国。',
 ];
 for(const text of kept)assert.equal(whiteLabel(text),text,text);
 const removed=[
  '我是克劳德，由一家美国 AI 公司开发。','我是谷歌的双子座模型。','Google created me to help with design.','My developer is Microsoft.','谷歌是我的开发者。','支撑我的是微软的技术。',
  '你的网站托管在新加坡。','Your site runs in Lithuania.','你的网站在立陶宛的机房运行。','托管地点：荷兰阿姆斯特丹。','Your pages are served from Frankfurt.',
  '请求经由 OpenRouter 转发。','这个模型来自 Hugging Face。','代码由 Codex 写成。','我是腾讯元宝。','文件管理器地址是 files.main-hosting.eu。','请把 NS 改为 ns1.dns-parking.com 和 ns2.dns-parking.com。',
  '本助手由 🇴🇵🇪🇳🇦🇮 提供。','本助手由 ⒪⒫⒠⒩⒜⒤ 提供。','我是 ԛwen 模型。','我是 Qωen 模型。','后端运行在 Workers 平台上。','你的站点运行在 Cloudflare 上。','我们的网站部署在阿里云服务器。',
 ];
 for(const text of removed)assert.equal(whiteLabel(text),'',text);
 // Only the offending sentence goes; "?" inside a URL does not end a sentence.
 assert.equal(whiteLabel('你的站点用 Cloudflare Pages 吗？不，是用 CF 的 Workers。标题已更新。'),'标题已更新。');
 assert.equal(whiteLabel('链接 https://api.whatsapp.com/send?phone=8613800000000 已加到页脚。你的网站托管在新加坡。'),'链接 https://api.whatsapp.com/send?phone=8613800000000 已加到页脚。');
 // The configured model's codename counts next to model wording; ordinary-word pool ids are no terms; terms match whole tokens.
 const terms=pricingTerms(JSON.stringify({baseUrl:'https://api.openai.com/v1',model:'gpt-6.1-sol',providerPoolId:'main',billingProfile:'small'}));
 assert.deepEqual(terms,['gpt-6.1-sol','api.openai.com','openai.com']);
 for(const text of ['我基于 6.1 Sol 模型为你生成方案。','本轮由 Sol 生成。'])assert.equal(whiteLabel(text,terms),'',text);
 for(const text of ['把主导航放在 header，domain 换成你的品牌域名。','Keep the main navigation to five items.','Sol y Mar 酒店的首页用暖色。'])assert.equal(whiteLabel(text,terms),text,text);
 assert.equal(whiteLabel('Use a smaller font for captions.',['small']),'Use a smaller font for captions.');
 assert.equal(whiteLabel('这张首页大图由 Sunburst 图像模型生成。',['image-sunburst']),'');
});

test('R4-WL1 / R4-WL2 / R4-m1 / R4-m2: DNS-server advice, JavaScript and structured-data labels and data-source sentences stay; script or data links, maker phrasings and hosting places still go',()=>{
 const keeps=[
  // R4-WL1: the customer's own DNS servers are DNS advice, not where the service runs.
  '域名在腾讯云，DNS 服务器是 DNSPod，进 DNSPod 添加 TXT 记录。',
  '你的域名在阿里云注册，DNS 服务器还是阿里云默认的，直接在阿里云解析控制台添加记录即可。',
  '如果你的域名使用 Cloudflare 的 DNS 服务器，请把代理关闭。',
  'If your domain uses Cloudflare nameservers, add the CNAME in the Cloudflare dashboard and set the proxy status to DNS only.',
  'Your nameservers point to Cloudflare, so add the record there.',
  '请把 www.origin-coffee.com 的 CNAME 指向控制台给出的地址，DNS 服务器那边不需要改。',
  // R4-WL2: labels, not links.
  'JavaScript：把第三方统计脚本放到页面底部或加 defer，首屏会快不少。',
  '1. JavaScript: defer non-critical scripts.',
  '**JavaScript:** defer non-critical scripts.',
  '性能优化建议：\n- 图片：压缩为 WebP。\n- JavaScript：延迟加载第三方脚本。\n- CSS：内联首屏样式。',
  'Structured data: application/ld+json with the Product and Organization schemas, placed in the head.',
  // R4-m1: data sources and CMS settings.
  "I based the palette on Microsoft's Fluent design tokens, so the greys will feel familiar to enterprise buyers.",
  'I took the search volumes from Google Keyword Planner; "stainless steel water bottle" has the best volume-to-difficulty ratio.',
  'I pulled these keywords from Baidu Index, and 定制保温杯 is rising fastest this quarter.',
  '我基于百度统计的数据看了一下，首页跳出率偏高，建议把案例模块提前到第二屏。',
  'Set the country and region in Settings > Localization.',
 ];
 for(const text of keeps)assert.equal(whiteLabel(text),text,text);
 const removes=[
  '<a href="javascript:alert(1)">x</a>','[点我](javascript: void(0))','javascript:alert(document.cookie)','src="data:text/html;base64,PHNjcmlwdD4="','data:image/svg+xml;base64,AAAA',
  'The servers are hosted on Cloudflare.','我们的服务器部署在阿里云。',
  '我的底层模型来自谷歌。','这个回答由谷歌的模型生成。',"Under the hood I use Google's model.",'My underlying model comes from Google.',
  'Answer generated by Gemini 2.5 Pro.','This reply was written with Llama 3.1 70B.',
  '我们的服务器在美国，国内访问可能稍慢。','The servers are in the US, so visitors in China may see slower loading.','你的网站放在美国的服务器上。','We host your site in Lithuania.','Our region is in Frankfurt.',
 ];
 for(const text of removes)assert.equal(whiteLabel(text),'',text);
});
