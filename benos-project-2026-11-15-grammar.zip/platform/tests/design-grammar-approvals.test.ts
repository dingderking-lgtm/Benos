// The approval model: an owner approves the exact grammar identity plus the brand ranges a model may
// choose from, and only then can a production package be built. Everything else stays a preview.
import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { randomToken, sha256 } from '../src/lib/crypto';
import { TestD1, testEnv } from './d1-helper';

const base = '/api/admin/design-grammar';
const brand = {
  colors: { paper: '#f7f7f4', tint: '#eceee9', ink: '#16181b', copy: '#4a5056', line: '#d8dbd6', accent: '#1f6feb', accentInk: '#ffffff', mark: '#c2571a', dark: '#12161a', darkInk: '#f2f4f3' },
  type: { head: 'grotesk', body: 'humanist', weight: 600, tracking: 'tight', scale: 'regular' },
  shape: { radius: 'large', button: 'pill' },
  styles: { kicker: 'square', link: 'underline', card: 'soft', figure: 'framed' },
  space: { container: 1280, density: 'regular' },
};
const sections = (lead: string) => [
  { id: 'hero', tone: 'paper', space: 'hero', body: [{ t: 'kicker', text: 'Precision machining' }, { t: 'display', lines: [lead] }, { t: 'text', text: 'Turning and milling for short runs.', role: 'lead' }] },
  { id: 'work', tone: 'paper', body: [{ t: 'title', text: 'What we make' }, { t: 'list', items: ['Prototypes', 'Small runs'] }] },
  { id: 'next', tone: 'dark', space: 'band', body: [{ t: 'title', text: 'Send a drawing' }, { t: 'actions', items: [{ label: 'Start a quote', href: '/about', kind: 'primary' }] }] },
];
const siteBody = (over: Record<string, unknown> = {}) => ({
  brand,
  pages: [
    { key: 'home', path: '/', title: 'Home', sections: sections('Parts that fit') },
    { key: 'about', path: '/about', title: 'About', sections: sections('How we work') },
  ],
  production: true, name: 'Workshop', slug: 'workshop', createdAt: '2026-11-15T00:00:00.000Z',
  ...over,
});
const ranges = { type: { weight: [400, 600], head: ['grotesk'] }, space: { container: [1280] } };

async function fixture() {
  const db = new TestD1(), env = testEnv(db), now = new Date().toISOString(), headers: Record<string, Record<string, string>> = {};
  for (const role of ['owner', 'admin']) {
    db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(role, `${role}@grammar.test`, role, 'unused', role, 'active', now, now);
    const token = randomToken();
    db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('ga-' + role, await sha256(token), role, 'csrf-' + role, now, new Date(Date.now() + 3600000).toISOString(), 'fixture');
    headers[role] = { cookie: 'benos_session=' + token, origin: env.APP_ORIGIN, 'x-csrf-token': 'csrf-' + role, 'content-type': 'application/json' };
  }
  return { db, env, headers };
}
const post = (env: any, path: string, headers: Record<string, string>, payload: unknown) =>
  app.request(base + path, { method: 'POST', headers, body: JSON.stringify(payload) }, env);

test('production is refused until the owner approves this exact grammar', async () => {
  const f = await fixture();
  try {
    const before = await app.request(base + '/approvals', { headers: f.headers.owner }, f.env);
    assert.equal(before.status, 200);
    const state = (await before.json() as any).data;
    assert.equal(state.approved, false);
    assert.equal(typeof state.identity.digest, 'string');

    const refused = await post(f.env, '/site', f.headers.owner, siteBody());
    assert.equal(refused.status, 409);
    assert.match(JSON.stringify(await refused.json()), /GRAMMAR_NOT_APPROVED/);

    // A preview is always allowed: it never becomes a site.
    const preview = await post(f.env, '/site', f.headers.owner, siteBody({ production: false }));
    assert.equal(preview.status, 200);
    const previewData = (await preview.json() as any).data;
    assert.equal(previewData.ok, true);
    assert.equal(previewData.manifest === undefined || previewData.manifest === null, true);
  } finally { f.db.close(); }
});

test('only the owner can record a decision, and it binds the running identity', async () => {
  const f = await fixture();
  try {
    assert.equal((await post(f.env, '/approve', f.headers.admin, { decision: 'approved', brandRanges: ranges })).status, 403);

    const approved = await post(f.env, '/approve', f.headers.owner, { decision: 'approved', brandRanges: ranges });
    assert.equal(approved.status, 200);
    const data = (await approved.json() as any).data;
    assert.equal(data.created, true);
    assert.equal(data.approval.state, 'approved');
    assert.equal(data.approval.reviewerId, 'owner');
    // The row names the grammar the server is running, not a client-supplied digest.
    assert.equal(data.approval.grammarDigest, data.identity.digest);

    const state = (await (await app.request(base + '/approvals', { headers: f.headers.owner }, f.env)).json() as any).data;
    assert.equal(state.approved, true);
    assert.equal(state.current.reviewerId, 'owner');
    assert.equal(state.rows.length, 1);

    // Approving again updates the same row instead of piling up.
    const again = await post(f.env, '/approve', f.headers.owner, { decision: 'approved', brandRanges: { ...ranges, shape: { radius: ['large'] } } });
    assert.equal((await again.json() as any).data.created, false);
  } finally { f.db.close(); }
});

test('an approved grammar produces a shippable package inside the approved brand ranges', async () => {
  const f = await fixture();
  try {
    await post(f.env, '/approve', f.headers.owner, { decision: 'approved', brandRanges: ranges });
    const response = await post(f.env, '/site', f.headers.owner, siteBody());
    assert.equal(response.status, 200, JSON.stringify(await response.clone().json()));
    const data = (await response.json() as any).data;
    assert.equal(data.ok, true);
    assert.equal(data.manifest.format, 'aacms-site-package');
    assert.match(data.manifestDigest, /^[a-f0-9]{64}$/);
    assert.equal(data.manifest.templates.filter((template: any) => template.type === 'page').length, 2);
    assert.match(data.manifest.site.theme.global_css, /^\.bnl\{--paper:/);
    assert.equal(data.identity, data.approval.grammarDigest);

    // A brand value outside the approved ranges is refused, and says what was approved.
    const outside = await post(f.env, '/site', f.headers.owner, siteBody({ brand: { ...brand, type: { ...brand.type, weight: 700 } } }));
    assert.equal(outside.status, 422);
    const outsideData = (await outside.json() as any);
    assert.equal(outsideData.error, 'GRAMMAR_BRAND_OUTSIDE_RANGE');
    assert.ok(outsideData.issues.some((issue: any) => issue.path === 'brand.type.weight'));

    // Rejecting the grammar closes production again.
    await post(f.env, '/approve', f.headers.owner, { decision: 'rejected', brandRanges: ranges });
    const closed = await post(f.env, '/site', f.headers.owner, siteBody());
    assert.equal(closed.status, 409);
  } finally { f.db.close(); }
});
