import test from 'node:test';
import assert from 'node:assert/strict';
import { previewLinkTarget } from '../src/modules/design-preview';
import example from '../src/contracts/site-example.json';
test('preview navigation stays on its private design version and disables unresolvable/external links',()=>{
 const site=example.site,base='/preview/project/version';
 assert.equal(previewLinkTarget('/',site,base),base+'?page='+site.home);
 assert.equal(previewLinkTarget('/contact#phone',site,base),base+'?page=contact#phone');
 assert.equal(previewLinkTarget('contact/',site,base),base+'?page=contact');
 assert.equal(previewLinkTarget('#section',site,base),'#section');
 for(const href of ['//evil.example','https://evil.example/contact','javascript:alert(1)','/api/session','/unknown','/%ZZ','mailto:owner@example.com'])assert.equal(previewLinkTarget(href,site,base),null);
});
