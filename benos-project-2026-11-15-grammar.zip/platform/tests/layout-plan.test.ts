import test from 'node:test';
import assert from 'node:assert/strict';
import {createLayoutPlan,type LayoutPlan,MEDIA_COMPOSITIONS} from '../src/contracts/layout-plan';
import {createDesignBrief} from '../src/contracts/design-brief';
const input=(seed:string,request='给澄野做一个品牌网站',history:LayoutPlan[]=[])=>({seed,allocationId:'allocation-'+seed,request,referenceImageCount:0,brief:createDesignBrief({request,hasExistingSite:false})!,history});
test('rolling automatic distribution limits eight media forms and changes structural signatures',async()=>{
 const history:LayoutPlan[]=[];for(let i=0;i<24;i++){const plan=await createLayoutPlan(input('seed'+i,undefined,history));assert.notEqual(plan.combinationHash,history[0]?.combinationHash);assert.equal(plan.rendering,'intent-only');assert.ok(!JSON.stringify(plan).includes('patternRef'));
  assert.ok(history.slice(0,7).filter(p=>p.primaryMediaComposition===plan.primaryMediaComposition).length<2);const sections=plan.pages[0].sections;assert.equal(sections[0].role,'orientation');assert.equal(sections.at(-2)!.role,'faq');assert.equal(sections.at(-1)!.role,'action');for(let n=1;n<sections.length;n++){assert.notEqual(sections[n].composition,sections[n-1].composition);assert.notEqual(sections[n].headingLayout,sections[n-1].headingLayout);}history.unshift(plan);}
 assert.equal(new Set(history.map(p=>p.primaryMediaComposition)).size,MEDIA_COMPOSITIONS.length);
 const a=await createLayoutPlan(input('same')),b=await createLayoutPlan(input('same'));assert.deepEqual(a,b);
});
test('media cardinality and uncropped products constrain the eligible pool before selection',async()=>{
 for(let i=0;i<32;i++){const three=await createLayoutPlan(input(String(i),'品牌官网，只用3张图片'));assert.notEqual(three.primaryMediaComposition,'bento');const machine=await createLayoutPlan(input(String(i),'完整机械设备官网'));assert.ok(!['bento','one-large-two-small','full-bleed-caption'].includes(machine.primaryMediaComposition));assert.notEqual(machine.heroComposition,'cover');const r=machine.pages[0].sections.map(s=>s.role);assert.ok(r.indexOf('capabilities')<r.indexOf('details'));assert.ok(r.indexOf('capabilities')<r.indexOf('selection'));}
 const none=await createLayoutPlan({...input('disabled','摄影网站，只用上传作品，不生成图片'),availableImageCount:0});assert.equal(none.primaryMediaComposition,'native-explanation');assert.notEqual(none.heroComposition,'cover');assert.ok(none.exceptions.length);
 const one=await createLayoutPlan({...input('one','摄影网站，只用上传作品，不生成图片'),availableImageCount:1});assert.ok(['full-bleed-caption','lead-image-list','image-caption-strip'].includes(one.primaryMediaComposition));
});
test('explicit layout and references remain recorded; no-image and first-hero scope win',async()=>{
 const requested=await createLayoutPlan(input('x','做一个品牌网站，图文交替'));assert.equal(requested.source,'user');assert.equal(requested.primaryMediaComposition,'alternating');
 const refs=await createLayoutPlan({...input('x'),referenceImageCount:1});assert.equal(refs.source,'reference');
 const noImages=await createLayoutPlan(input('x','无图片的网站'));assert.equal(noImages.primaryMediaComposition,'native-explanation');
 const one=await createLayoutPlan(input('x','只做首屏'));assert.equal(one.pages[0].sections.length,1);assert.ok(!['bento','one-large-two-small','horizontal-rail'].includes(one.primaryMediaComposition));
});
