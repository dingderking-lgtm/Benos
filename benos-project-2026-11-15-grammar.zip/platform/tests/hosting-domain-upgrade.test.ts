import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync,readdirSync } from 'node:fs';

const backfill='INSERT INTO hosting_domains(domain,site_id,created_at) SELECT domain,id,created_at FROM sites;';
function fixture(schemaOnly=true){
 const db=new DatabaseSync(':memory:');db.exec('PRAGMA foreign_keys=ON');
 const files=readdirSync('migrations').filter(file=>file.endsWith('.sql')).sort();
 for(const file of files.filter(file=>file<'0029_hosting_management.sql'))db.exec(readFileSync('migrations/'+file,'utf8'));
 for(const user of ['owner-a','owner-b'])db.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,'fixture','user','before','before')").run(user,user+'@fixture.test',user);
 const create=(id:string,owner:string,domain:string)=>db.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,?,?,?,?,'connected','before','before')").run(id,owner,id,domain,owner+'@fixture.test');
 create('old-a','owner-a','historical-a.fixture.test');create('old-b','owner-b','historical-b.fixture.test');
 const oldSites=db.prepare('SELECT * FROM sites ORDER BY id').all();
 for(const file of files.filter(file=>file>='0029_hosting_management.sql'&&file<='0035_hosting_domain_ownership.sql')){
  let sql=readFileSync('migrations/'+file,'utf8');if(file==='0029_hosting_management.sql'&&schemaOnly){assert.equal(sql.split(backfill).length,2,'only the exact historical backfill is omitted');sql=sql.replace(backfill,'');}
  db.exec('BEGIN');try{db.exec(sql);db.exec('COMMIT');}catch(error){db.exec('ROLLBACK');db.close();throw error;}
 }
 assert.deepEqual(db.prepare('SELECT * FROM sites ORDER BY id').all(),oldSites,'upgrade retains all existing site rows');
 return {db,create,claim:(domain:string,site:string)=>db.prepare("INSERT INTO hosting_domains(domain,site_id,created_at) VALUES(?,?,'now')").run(domain,site)};
}

test('schema-only historical upgrade blocks another site from claiming existing canonical domains before external mutation',()=>{
 const {db,claim,create}=fixture();try{
  assert.equal(db.prepare('SELECT COUNT(*) n FROM hosting_domains').get()!.n,0,'the skipped backfill is not silently replaced by migration data writes');
  assert.throws(()=>claim('historical-b.fixture.test','old-a'),/hosting_domain_claimed/);
  assert.throws(()=>create('new-bad','owner-a','historical-b.fixture.test'),/UNIQUE constraint failed: sites.domain/);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM hosting_domains').get()!.n,0);
  claim('historical-a.fixture.test','old-a');assert.equal(db.prepare('SELECT site_id FROM hosting_domains WHERE domain=?').get('historical-a.fixture.test')!.site_id,'old-a');
  assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
 }finally{db.close();}
});

test('schema-only upgrade retains old and new domains atomically and rejects parked-domain reuse by new or existing sites',()=>{
 const {db,claim,create}=fixture();try{
  // Match the application: claim the target before creating an alias, then switch.
  claim('renamed.fixture.test','old-a');db.prepare("UPDATE sites SET domain='renamed.fixture.test',updated_at='renamed' WHERE id='old-a'").run();
  const claims=db.prepare("SELECT domain,site_id FROM hosting_domains WHERE site_id='old-a' ORDER BY domain").all().map(row=>({...row}));
  assert.deepEqual(claims,[{domain:'historical-a.fixture.test',site_id:'old-a'},{domain:'renamed.fixture.test',site_id:'old-a'}]);
  assert.throws(()=>claim('historical-a.fixture.test','old-b'),/UNIQUE constraint failed: hosting_domains.domain/);
  assert.throws(()=>claim('renamed.fixture.test','old-b'),/hosting_domain_claimed/);
  assert.throws(()=>create('new-old-alias','owner-b','historical-a.fixture.test'),/UNIQUE constraint failed: hosting_domains.domain/);
  assert.equal(db.prepare("SELECT id FROM sites WHERE id='new-old-alias'").get(),undefined,'AFTER INSERT claim rejection rolls back the new site too');
  assert.throws(()=>db.prepare("UPDATE sites SET domain='historical-a.fixture.test' WHERE id='old-b'").run(),/hosting_domain_claimed/);
  assert.equal(db.prepare("SELECT domain FROM sites WHERE id='old-b'").get()!.domain,'historical-b.fixture.test');
  // Even a database-driven switch cannot forget an unbackfilled original domain.
  db.prepare("UPDATE sites SET domain='direct-change.fixture.test',updated_at='changed' WHERE id='old-b'").run();
  for(const domain of ['historical-b.fixture.test','direct-change.fixture.test'])assert.equal(db.prepare('SELECT site_id FROM hosting_domains WHERE domain=?').get(domain)!.site_id,'old-b');
  db.prepare("UPDATE sites SET domain='historical-b.fixture.test' WHERE id='old-b'").run();
  assert.equal(db.prepare("SELECT COUNT(*) n FROM hosting_domains WHERE site_id='old-b'").get()!.n,2,'switching back preserves unique historical claims');
  assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
 }finally{db.close();}
});

test('0035 remains compatible with the full historical backfill and existing site insert/update guards',()=>{
 const {db,claim,create}=fixture(false);try{
  assert.equal(db.prepare('SELECT COUNT(*) n FROM hosting_domains').get()!.n,2);
  create('new-site','owner-a','fresh.fixture.test');assert.equal(db.prepare('SELECT site_id FROM hosting_domains WHERE domain=?').get('fresh.fixture.test')!.site_id,'new-site');
  claim('changed.fixture.test','new-site');db.prepare("UPDATE sites SET domain='changed.fixture.test' WHERE id='new-site'").run();
  assert.equal(db.prepare("SELECT COUNT(*) n FROM hosting_domains WHERE site_id='new-site'").get()!.n,2);
  assert.throws(()=>claim('historical-b.fixture.test','new-site'),/hosting_domain_claimed/);
  assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
 }finally{db.close();}
});
