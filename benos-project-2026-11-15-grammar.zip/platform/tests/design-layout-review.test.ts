import test from 'node:test';
import assert from 'node:assert/strict';
import { reviewHeroLayout, publicDesignTool } from '../src/lib/design-layout-review';
import { materializeDesignOrder, createDesignOrder } from '../src/contracts/design-order';
import example from '../src/contracts/site-example.json';
const sample=()=>{const m=structuredClone(example);m.templates.find(t=>t.id===1)!.document.html='<section class="bnf-hero"><div class="bnf-container"><div><h1>Machines for recycling</h1><p>Keep this copy.</p><div class="bnf-actions"><a class="bnf-button" href="/contact">Explore</a><a href="#detail">Process</a></div></div><figure><div id="bnf-image-hero"><img src="/machine.png" alt="Machine"></div></figure></div></section><section id="detail">Process detail</section>';return m;};
test('review repairs a stacked copy/media hero once, retaining text, links and image geometry',()=>{
 const m=sample(),result=reviewHeroLayout(m);assert.equal(result.repairs.length,1);assert.notEqual(result.manifest,m);assert.match(result.manifest.templates[0].document.html,/bnf-reviewed-hero/);assert.match(result.manifest.templates[0].document.html,/src="\/machine.png"/);assert.match(result.manifest.site.theme.global_css,/max-width:960px/);assert.deepEqual(reviewHeroLayout(result.manifest).repairs,[]);assert.doesNotMatch(m.templates[0].document.html,/bnf-reviewed-hero/);
});
test('review preserves deliberate cover, centered and existing split layouts',()=>{
 for(const marker of ['bnf-hero-cover','bnf-hero-center','bnf-split']){const m=sample();m.templates[0].document.html=m.templates[0].document.html.replace(marker==='bnf-split'?'bnf-container':'bnf-hero',marker==='bnf-split'?'bnf-container bnf-split':'bnf-hero '+marker);assert.deepEqual(reviewHeroLayout(m).repairs,[]);}
});
test('order normalizer keeps the hero action row horizontal with wrapping',()=>{
 const result=materializeDesignOrder(sample(),createDesignOrder({request:'Industrial site in English'}));assert.match(result.manifest.templates[0].document.html,/<div class="bnf-actions"[^>]*flex-direction:row!important/);assert.match(result.manifest.templates[0].document.html,/flex-wrap:wrap!important/);
});
test('saved layout with failed image is distinct from rejected layout and completed review',()=>{
 const saved=publicDesignTool({name:'prepare_layout',result:{ok:false,changedFiles:['manifest.json'],images:[{ok:true},{ok:false,code:'IMAGE_PROVIDER_UNCERTAIN'}],check:{passed:false}}});assert.equal(saved.ok,true);assert.equal(saved.layoutSaved,true);assert.equal(saved.imageFailures,1);assert.equal(saved.reviewPassed,false);
 const rejected=publicDesignTool({name:'prepare_layout',result:{ok:false,code:'IMAGE_LAYOUT_INVALID'}});assert.equal(rejected.ok,false);assert.equal(rejected.layoutSaved,false);
 assert.equal(publicDesignTool({name:'edit_file',result:{ok:true,check:{passed:true}}}).reviewPassed,true);
 const recorded=publicDesignTool({name:'discard_prepared_images',result:{ok:true,recorded:true,frameIds:['hero'],reason:'private model detail'}});
 assert.equal(recorded.label,'记录图片弃用');assert.match(recorded.message!,/没有删除图片/);assert.equal('reason' in recorded,false);
 assert.equal(publicDesignTool({name:'discard_prepared_images',result:{ok:false}}).message,undefined);
});
