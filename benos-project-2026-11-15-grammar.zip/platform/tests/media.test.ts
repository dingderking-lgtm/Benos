import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Hono } from 'hono';
import { type App } from '../src/lib/http';
import { sha256,randomToken } from '../src/lib/crypto';
import { AppError } from '../src/lib/errors';
import { inspectMediaBytes,saveMedia,readMedia,listMedia,setMediaDeleted,resolveProjectAssets,mediaRoutes,boundedBytes,mediaReferencesAvailableStatement } from '../src/modules/media';
import { mediaFixture,png } from './media-helper';
import example from '../src/contracts/site-example.json';
const upload={bytes:png(),fileName:'logo.png',mimeType:'image/png',requestKey:'upload-logo-once'};

test('native JPEG and bundled WebP fixtures have independently parsed dimensions',async()=>{
 const jpeg=Buffer.from('/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAABAAEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9U6KKKAP/2Q==','base64');
 const decoded=await inspectMediaBytes(jpeg,'image/jpeg');assert.equal(decoded.width,1);assert.equal(decoded.height,1);assert.equal(decoded.extension,'jpg');
 const webp=await inspectMediaBytes(readFileSync('public/assets/studio.webp'),'image/webp');assert.ok(webp.width>0&&webp.height>0);assert.equal(webp.extension,'webp');await assert.rejects(()=>inspectMediaBytes(Buffer.concat([jpeg,Buffer.from('<?php bad(); ?>')])));
});

test('real PNG bytes, CRC, dimensions, SHA256 view and claimed MIME are validated',async()=>{
 const bytes=png(),padded=new Uint8Array(bytes.length+20);padded.set(bytes,10);const result=await inspectMediaBytes(padded.subarray(10,-10),'image/png');assert.equal(result.width,1);assert.equal(result.height,1);assert.equal(result.sha256,await sha256(bytes));assert.equal(result.byteSize,bytes.length);
 await assert.rejects(()=>inspectMediaBytes(bytes,'image/jpeg'),/类型/);const broken=new Uint8Array(bytes);broken[30]^=1;await assert.rejects(()=>inspectMediaBytes(broken),/校验和/);
 await assert.rejects(()=>inspectMediaBytes(bytes.subarray(0,-1)));await assert.rejects(()=>inspectMediaBytes(new Uint8Array([...bytes,0])));await assert.rejects(()=>inspectMediaBytes(new TextEncoder().encode('<svg onload="alert(1)"></svg>')));
});
test('oversized dimensions, invalid WebP containers and JPEG trailing payloads are rejected',async()=>{
 await assert.rejects(()=>inspectMediaBytes(png(8193,1)),/8192/);
 const webp=Buffer.from('RIFF\x04\x00\x00\x00WEBP','binary');await assert.rejects(()=>inspectMediaBytes(webp));
 const jpeg=new Uint8Array([255,216,255,217,60,63,112,104,112,32,49,50]);await assert.rejects(()=>inspectMediaBytes(jpeg));
});
test('uploads remain private and owner/project scoped; duplicates are idempotent and changed bytes conflict',async()=>{
 const f=mediaFixture();try{const media=await saveMedia(f.env,'u','p',upload),again=await saveMedia(f.env,'u','p',upload);assert.equal(again.id,media.id);assert.equal(f.storage.puts,1);assert.equal(media.width,1);assert.equal((await listMedia(f.env,'u','p')).length,1);assert.equal((await listMedia(f.env,'u','p2')).length,0);assert.ok(!JSON.stringify(media).includes('private/users'));assert.deepEqual((await readMedia(f.env,'u',media.id)).bytes,upload.bytes);
 await assert.rejects(()=>saveMedia(f.env,'u','p',{...upload,bytes:png(2,1)}),/请求编号/);await assert.rejects(()=>readMedia(f.env,'other',media.id),/不存在/);await assert.rejects(()=>saveMedia(f.env,'other','p',{...upload,requestKey:'other-owner-upload'}),/不存在/);
 }finally{f.db.close();}
});
test('soft deletion hides authenticated reads and package resolution; restore reuses the original object',async()=>{
 const f=mediaFixture();try{const media=await saveMedia(f.env,'u','p',upload),manifest={...example,assets:[{file:'assets/0.png',path:media.assetPath,size:media.byteSize,sha256:media.sha256}]};const resolved=await resolveProjectAssets(f.env,'u','p',manifest);assert.deepEqual(resolved.files,[{file:'assets/0.png',bytes:upload.bytes}]);assert.equal(resolved.mapping[media.assetPath],media.contentUrl);
 await assert.rejects(()=>resolveProjectAssets(f.env,'u','p2',manifest),/素材/);await setMediaDeleted(f.env,'u',media.id,true);await assert.rejects(()=>readMedia(f.env,'u',media.id),/不存在/);await assert.rejects(()=>resolveProjectAssets(f.env,'u','p',manifest),/素材/);assert.equal((await listMedia(f.env,'u','p')).length,0);assert.equal((await listMedia(f.env,'u','p',true))[0].state,'deleted');await setMediaDeleted(f.env,'u',media.id,false);assert.deepEqual((await readMedia(f.env,'u',media.id)).bytes,upload.bytes);assert.equal(f.storage.puts,1);
 }finally{f.db.close();}
});
test('lost R2 PUT acknowledgement stays staging and same upload safely repairs it',async()=>{
 const f=mediaFixture();try{f.storage.failAfter=true;await assert.rejects(()=>saveMedia(f.env,'u','p',upload));assert.equal(f.db.sqlite.prepare('SELECT state FROM project_media').get()!.state,'staging');assert.equal((await listMedia(f.env,'u','p')).length,0);const media=await saveMedia(f.env,'u','p',upload);assert.equal(media.state,'ready');assert.equal(f.storage.objects.size,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media').get()!.n,1);
 }finally{f.db.close();}
});
test('concurrent identical uploads create one row and corrupted stored bytes are not served',async()=>{
 const f=mediaFixture();try{const result=await Promise.all(Array.from({length:10},()=>saveMedia(f.env,'u','p',upload)));assert.equal(new Set(result.map(x=>x.id)).size,1);const key=[...f.storage.objects.keys()][0],bytes=new Uint8Array(upload.bytes);bytes[30]^=1;f.storage.objects.set(key,bytes);await assert.rejects(()=>readMedia(f.env,'u',result[0].id),/校验失败/);
 }finally{f.db.close();}
});
test('authenticated asset response is private, nosniff and cannot be read without a session',async()=>{
 const f=mediaFixture();try{const media=await saveMedia(f.env,'u','p',upload),token=randomToken();f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('s','u',await sha256(token),'csrf',new Date().toISOString(),new Date(Date.now()+3600000).toISOString(),'fixture');const app=new Hono<App>();app.onError((e,c)=>c.json({code:(e as AppError).code},(e instanceof AppError?e.status:500) as any));app.route('/api/media',mediaRoutes);
 const denied=await app.request(media.contentUrl,{},f.env);assert.equal(denied.status,401);const response=await app.request(media.contentUrl,{headers:{Cookie:'benos_session='+token}},f.env);assert.equal(response.status,200);assert.equal(response.headers.get('content-type'),'image/png');assert.equal(response.headers.get('cache-control'),'private, no-store');assert.equal(response.headers.get('x-content-type-options'),'nosniff');assert.deepEqual(new Uint8Array(await response.arrayBuffer()),upload.bytes);
 }finally{f.db.close();}
});
test('bounded streaming reads stop before accepting oversized bodies',async()=>{
 let cancelled=false;const stream=new ReadableStream<Uint8Array>({start(c){c.enqueue(new Uint8Array(11));},cancel(){cancelled=true;}});await assert.rejects(()=>boundedBytes(stream,10));assert.equal(cancelled,true);
});

test('publication transfer cap is checked from validated declarations before any R2 read',async()=>{
 const f=mediaFixture();try{const media=await saveMedia(f.env,'u','p',upload);const tooLarge={...example,assets:[{file:'assets/0.png',path:media.assetPath,size:6*1024*1024+1,sha256:media.sha256}]};await assert.rejects(()=>resolveProjectAssets(f.env,'u','p',tooLarge),(error:unknown)=>error instanceof AppError&&error.code==='MEDIA_TRANSFER_LIMIT');assert.equal(f.storage.gets,0);
 }finally{f.db.close();}
});
test('referenced historical media cannot be deleted and failed guard rolls back every mutation',async()=>{
 const f=mediaFixture();try{const media=await saveMedia(f.env,'u','p',upload),manifest={...example,assets:[{file:'assets/0.png',path:media.assetPath,size:media.byteSize,sha256:media.sha256}]};
 await f.env.DB.batch([mediaReferencesAvailableStatement(f.env.DB,'u','p',manifest,'media-save-guard'),f.env.DB.prepare("INSERT INTO design_versions(id,project_id,version,source,manifest_json,content_hash,created_by,created_at) VALUES('old-version','p',1,'manual',?,'hash','u',?)").bind(JSON.stringify(manifest),new Date().toISOString()),f.env.DB.prepare("DELETE FROM mutation_guards WHERE id='media-save-guard'")]);
 await assert.rejects(()=>setMediaDeleted(f.env,'u',media.id,true),(error:unknown)=>error instanceof AppError&&error.code==='MEDIA_IN_USE');assert.equal((await listMedia(f.env,'u','p'))[0].state,'ready');assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='media.deleted'").get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM mutation_guards').get()!.n,0);
 }finally{f.db.close();}
});
test('when deletion wins the race a stale prepared manifest cannot commit a version referencing it',async()=>{
 const f=mediaFixture();try{const media=await saveMedia(f.env,'u','p',upload),manifest={...example,assets:[{file:'assets/0.png',path:media.assetPath,size:media.byteSize,sha256:media.sha256}]};await resolveProjectAssets(f.env,'u','p',manifest);await setMediaDeleted(f.env,'u',media.id,true);
 await assert.rejects(()=>f.env.DB.batch([mediaReferencesAvailableStatement(f.env.DB,'u','p',manifest,'stale-save-guard'),f.env.DB.prepare("INSERT INTO design_versions(id,project_id,version,source,manifest_json,content_hash,created_by,created_at) VALUES('stale-version','p',1,'manual',?,'hash','u',?)").bind(JSON.stringify(manifest),new Date().toISOString()),f.env.DB.prepare("DELETE FROM mutation_guards WHERE id='stale-save-guard'")]));assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM mutation_guards').get()!.n,0);
 await setMediaDeleted(f.env,'u',media.id,false);await f.env.DB.batch([mediaReferencesAvailableStatement(f.env.DB,'u','p',manifest,'restored-save'),f.env.DB.prepare("DELETE FROM mutation_guards WHERE id='restored-save'")]);
 }finally{f.db.close();}
});

