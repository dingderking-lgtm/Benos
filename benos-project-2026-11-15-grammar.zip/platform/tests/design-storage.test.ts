import test from 'node:test';
import assert from 'node:assert/strict';
import { inlineManifestJson,MAX_INLINE_MANIFEST_BYTES,MAX_DESIGN_MANIFEST_BYTES,serializeDesignManifest,prepareDesignManifestStorage,readStoredManifest,purgeUnreferencedDesignManifests,designManifestObjectKey,type ManifestObjectRow } from '../src/lib/design-storage';
import { saveVersion } from '../src/modules/ai';
import { importTemplatePackage } from '../src/modules/template-import';
import { templateZip } from '../src/lib/template-zip';
import { mediaFixture,png } from './media-helper';
import { starterManifest } from '../src/contracts/starter-library';
import { sha256 } from '../src/lib/crypto';
import { saveDesignCandidate,adoptDesignCandidate,readDesignCandidate,readDesignVersion } from '../src/modules/design-workspace';
import { setMediaDeleted,saveMedia } from '../src/modules/media';
import { validateSiteManifest } from '../src/modules/template-contract';

const MIB=1048576,DAY=86400000;
function largeManifest(target=3*MIB){const manifest=starterManifest('studio')!,padding=target-new TextEncoder().encode(JSON.stringify(manifest)).length-10;
 manifest.templates[0].document.css+='/*'+'x'.repeat(Math.floor(padding/2))+'*/\n';manifest.templates[1].document.css+='/*'+'y'.repeat(padding-Math.floor(padding/2))+'*/\n';assert.equal(new TextEncoder().encode(JSON.stringify(manifest)).length,target+2);return manifest;
}
function fixture(){const f=mediaFixture(),put=f.storage.put.bind(f.storage),deletes:string[]=[];let loseDelete=false;
 (f.storage as any).put=async(key:string,bytes:Uint8Array,options?:R2PutOptions)=>{if(options?.onlyIf&&f.storage.objects.has(key))return null;return put(key,bytes);};
 (f.storage as any).delete=async(key:string)=>{deletes.push(key);f.storage.objects.delete(key);if(loseDelete){loseDelete=false;throw new Error('fixture lost DELETE acknowledgement');}};
 return {...f,deletes,loseNextDelete:()=>loseDelete=true};
}
function enforceD1BoundValues(f:ReturnType<typeof fixture>){const prepare=f.db.prepare.bind(f.db);let maximum=0;f.db.prepare=(sql:string)=>{const statement=prepare(sql),bind=statement.bind.bind(statement);statement.bind=(...values:any[])=>{for(const value of values)if(typeof value==='string'){const bytes=new TextEncoder().encode(value).length;maximum=Math.max(maximum,bytes);assert.ok(bytes<=1_000_000,'a full large manifest must never be bound to D1 SQL');}return bind(...values);};return statement;};return ()=>maximum;}

test('the legacy inline guard remains byte-based and the R2 channel rejects above 10 MiB before any writes',async()=>{
 assert.equal(new TextEncoder().encode(inlineManifestJson('x'.repeat(MAX_INLINE_MANIFEST_BYTES-2))).byteLength,MAX_INLINE_MANIFEST_BYTES);
 assert.throws(()=>inlineManifestJson('界'.repeat(340000)),/清单文本最多/);
 const f=fixture();try{const manifest=largeManifest(MAX_DESIGN_MANIFEST_BYTES+10);assert.throws(()=>serializeDesignManifest(manifest),/10 MiB/);
  await assert.rejects(saveVersion(f.env,'u','p',manifest,'manual',null,'over-ten-mib'),/10 MiB/);
  assert.equal(f.storage.puts,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT current_version_id FROM projects WHERE id=\'p\'').get()!.current_version_id,null);
 }finally{f.db.close();}
});

test('valid >2 MiB and near-10 MiB manifests save, read and adopt with only small D1 index bindings',async()=>{
 const f=fixture();try{const maximum=enforceD1BoundValues(f),manifest=largeManifest(),before=process.memoryUsage();assert.equal(validateSiteManifest(manifest).valid,true);
  const first=await saveVersion(f.env,'u','p',manifest,'manual',null,'large-version-1'),row=f.db.sqlite.prepare('SELECT * FROM design_versions WHERE id=?').get(first)!;
  assert.ok(row.manifest_object_id);assert.ok(String(row.manifest_json).length<20000);assert.equal(row.content_hash,await sha256(JSON.stringify(manifest)));assert.deepEqual(await readDesignVersion(f.env,'u','p',first),manifest);
  const near=largeManifest(MAX_DESIGN_MANIFEST_BYTES-258);assert.equal(new TextEncoder().encode(JSON.stringify(near)).length,MAX_DESIGN_MANIFEST_BYTES-256);assert.equal(validateSiteManifest(near).valid,true);
  const candidate=await saveDesignCandidate(f.env,{userId:'u',projectId:'p',requestKey:'near-ten-mib-candidate',baseVersionId:first,scope:{kind:'site'},manifest:near,source:'manual'});
  assert.deepEqual(JSON.parse((await readDesignCandidate(f.env,'u','p',candidate.id)).manifest_json),near);
  const adopted=await adoptDesignCandidate(f.env,'u','p',candidate.id);assert.deepEqual(await readDesignVersion(f.env,'u','p',adopted.versionId!),near);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_manifest_objects').get()!.n,2);assert.ok(maximum()<20000);
  const gets=f.storage.gets;await assert.rejects(()=>readDesignVersion(f.env,'u','p',adopted.versionId!,600000),/AI 工作流/);assert.equal(f.storage.gets,gets);
  const delta=process.memoryUsage();console.log(JSON.stringify({evidence:'node-only-large-manifest-storage',manifestBytes:MAX_DESIGN_MANIFEST_BYTES-256,maxD1BoundBytes:maximum(),heapUsedDelta:delta.heapUsed-before.heapUsed,externalDelta:delta.external-before.external,notWorkerdPeak:true}));
 }finally{f.db.close();}
});

test('legacy inline rows still read without R2 and repeated save requests cannot rewind newer versions',async()=>{
 const f=fixture();try{const small=starterManifest('studio')!,first=await saveVersion(f.env,'u','p',small,'manual',null,'stable-first');assert.equal(f.db.sqlite.prepare('SELECT manifest_object_id FROM design_versions').get()!.manifest_object_id,null);assert.equal(f.storage.puts,0);
  const changed=structuredClone(small);changed.templates[0].document.css+='\n.new{color:red}';const newer=await saveVersion(f.env,'u','p',changed,'manual',first,'stable-next');assert.equal(await saveVersion(f.env,'u','p',small,'manual',null,'stable-first'),first);assert.equal(f.db.sqlite.prepare("SELECT current_version_id FROM projects WHERE id='p'").get()!.current_version_id,newer);
  await assert.rejects(()=>saveVersion(f.env,'u','p',changed,'manual',null,'stable-first'),/编号/);assert.deepEqual(await readDesignVersion(f.env,'u','p',first),small);
 }finally{f.db.close();}
});

test('lost R2 and D1 acknowledgements are recovered without duplicate objects or versions',async()=>{
 const f=fixture();try{const manifest=largeManifest(1100000);f.storage.failAfter=true;const stored=await prepareDesignManifestStorage(f.env,'u','p',manifest);assert.ok(stored.objectId);assert.equal(f.storage.objects.size,1);
  const batch=f.db.batch.bind(f.db);let injected=false;(f.db as any).batch=async(statements:any[])=>{const result=await batch(statements);if(!injected&&statements.some(s=>String(s.sql).includes('INSERT INTO design_versions'))){injected=true;throw new Error('fixture lost D1 commit acknowledgement');}return result;};
  const version=await saveVersion(f.env,'u','p',manifest,'manual',null,'lost-commit-request');assert.equal(await saveVersion(f.env,'u','p',manifest,'manual',null,'lost-commit-request'),version);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n,1);assert.equal(f.storage.objects.size,1);
 }finally{f.db.close();}
});

test('same-SHA concurrent preparations produce one immutable object and busy calls retry the same lifecycle',async()=>{
 const f=fixture();try{const manifest=largeManifest(1100000),results=await Promise.allSettled(Array.from({length:5},()=>prepareDesignManifestStorage(f.env,'u','p',manifest)));assert.ok(results.some(r=>r.status==='fulfilled'));
  const retry=await prepareDesignManifestStorage(f.env,'u','p',manifest);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_manifest_objects').get()!.n,1);assert.equal(f.storage.objects.size,1);assert.equal(f.storage.puts,1);assert.equal((await readStoredManifest(f.env,{manifest_json:retry.manifestJson,manifest_object_id:retry.objectId},{userId:'u',projectId:'p'})).site.name,manifest.site.name);
 }finally{f.db.close();}
});

test('object ownership, exact asset/summary indexes and private bytes are verified without trusting browser pointers',async()=>{
 const f=fixture();try{const manifest=largeManifest(1100000),stored=await prepareDesignManifestStorage(f.env,'u','p',manifest),row={manifest_json:stored.manifestJson,manifest_object_id:stored.objectId};
  await assert.rejects(()=>readStoredManifest(f.env,row,{userId:'other',projectId:'p'}),/归属/);
  const changed=JSON.parse(stored.manifestJson);changed.summary.siteName='forged';await assert.rejects(()=>readStoredManifest(f.env,{...row,manifest_json:JSON.stringify(changed)},{userId:'u',projectId:'p'}),/校验/);
  assert.throws(()=>f.db.sqlite.prepare("UPDATE design_manifest_objects SET index_json='{}'").run(),/immutable/);
  assert.throws(()=>f.db.sqlite.prepare("INSERT INTO design_versions(id,project_id,version,source,manifest_json,manifest_object_id,content_hash,created_by,created_at) VALUES('bad','p',1,'manual',?,?,?,'u','now')").run(JSON.stringify(changed),stored.objectId,stored.contentHash),/pointer/);
  const key=[...f.storage.objects.keys()][0],damaged=new Uint8Array(f.storage.objects.get(key)!);damaged[damaged.length-2]^=1;f.storage.objects.set(key,damaged);await assert.rejects(()=>readStoredManifest(f.env,row,{userId:'u',projectId:'p'}),/校验/);
 }finally{f.db.close();}
});

test('large-manifest asset references preserve deletion guards in both save/delete race directions',async()=>{
 const f=fixture();try{const asset=await saveMedia(f.env,'u','p',{bytes:png(),fileName:'keep.png',requestKey:'large-kept-asset'}),manifest=largeManifest(1100000);manifest.assets=[{file:'assets/0.png',path:asset.assetPath,sha256:asset.sha256,size:asset.byteSize}];
  const batch=f.db.batch.bind(f.db);let deleted=false;f.db.batch=async(statements:any[])=>{if(!deleted&&statements.some(s=>String(s.sql).includes('INSERT INTO design_versions'))){deleted=true;await setMediaDeleted(f.env,'u',asset.id,true);}return batch(statements);};
  await assert.rejects(()=>saveVersion(f.env,'u','p',manifest,'manual',null,'delete-before-save'),/素材/);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n,0);
  await setMediaDeleted(f.env,'u',asset.id,false);const version=await saveVersion(f.env,'u','p',manifest,'manual',null,'saved-reference');await assert.rejects(()=>setMediaDeleted(f.env,'u',asset.id,true),/引用/);assert.deepEqual(await readDesignVersion(f.env,'u','p',version),manifest);
  const draft=await saveDesignCandidate(f.env,{userId:'u',projectId:'p2',requestKey:'candidate-reference',baseVersionId:null,scope:{kind:'site'},manifest:largeManifest(1100000),source:'manual'});assert.ok(draft.id);
 }finally{f.db.close();}
});

test('expired unreferenced lifecycle cleans up safely; a tombstone re-sweep cannot delete a newer same-SHA object',async()=>{
 const f=fixture();try{const manifest=largeManifest(1100000),time=Date.now(),old=await prepareDesignManifestStorage(f.env,'u','p',manifest,time-2*DAY),oldRow=f.db.sqlite.prepare('SELECT * FROM design_manifest_objects WHERE id=?').get(old.objectId!)!;
  assert.equal((await purgeUnreferencedDesignManifests(f.env,time)).removed,1);assert.equal(f.storage.objects.size,0);
  const current=await prepareDesignManifestStorage(f.env,'u','p',manifest,time),version=await saveVersion(f.env,'u','p',manifest,'manual',null,'new-after-gc');assert.notEqual(current.objectId,old.objectId);
  f.storage.objects.set(String(oldRow.object_key),new TextEncoder().encode(JSON.stringify(manifest)));assert.equal((await purgeUnreferencedDesignManifests(f.env,time+2*DAY)).removed,1);assert.equal(f.storage.objects.has(String(oldRow.object_key)),false);assert.equal(f.storage.objects.size,1);assert.deepEqual(await readDesignVersion(f.env,'u','p',version),manifest);
 }finally{f.db.close();}
});

test('unknown deletion retains a nonreferencable lifecycle until retry, and committed references prevent cleanup',async()=>{
 const f=fixture();try{const now=Date.now(),manifest=largeManifest(1100000),stored=await prepareDesignManifestStorage(f.env,'u','p',manifest,now-2*DAY);f.loseNextDelete();assert.equal((await purgeUnreferencedDesignManifests(f.env,now)).uncertain,1);assert.equal(f.db.sqlite.prepare('SELECT state FROM design_manifest_objects').get()!.state,'purging');await assert.rejects(()=>prepareDesignManifestStorage(f.env,'u','p',manifest),/清理/);
  assert.equal((await purgeUnreferencedDesignManifests(f.env,now+2*DAY)).removed,1);const version=await saveVersion(f.env,'u','p',manifest,'manual',null,'gc-protected-version');assert.ok(version);assert.throws(()=>f.db.sqlite.prepare("UPDATE design_manifest_objects SET state='purging' WHERE id=(SELECT manifest_object_id FROM design_versions LIMIT 1)").run(),/referenced/);assert.equal(f.storage.objects.size,1);assert.ok(stored.objectId);
 }finally{f.db.close();}
});

test('combined staging quota is atomic and neither rejected attempt uploads a blob nor consumes history capacity',async()=>{
 const f=fixture();try{const now=new Date().toISOString();for(let n=0;n<19;n++){const objectId='manifest_'+n.toString(16).padStart(32,'0'),digest=n.toString(16).padStart(64,'0');f.db.sqlite.prepare("INSERT INTO design_manifest_objects(id,user_id,project_id,object_key,sha256,byte_size,index_json,state,created_at,updated_at) VALUES(?,'u','p',?,?,1000001,'{}','staging',?,?)").run(objectId,designManifestObjectKey({userId:'u',projectId:'p'},objectId,digest),digest,now,now);}
  const results=await Promise.allSettled([prepareDesignManifestStorage(f.env,'u','p',largeManifest(1100000)),prepareDesignManifestStorage(f.env,'u','p',largeManifest(1100010))]);assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(f.storage.puts,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_manifest_objects').get()!.n,20);
 }finally{f.db.close();}
});

test('large draft candidates alone block referenced-media deletion and adopted retries keep one version',async()=>{
 const f=fixture();try{const asset=await saveMedia(f.env,'u','p',{bytes:png(),fileName:'draft.png',requestKey:'large-draft-asset'}),manifest=largeManifest(1100000);manifest.assets=[{file:'assets/0.png',path:asset.assetPath,sha256:asset.sha256,size:asset.byteSize}];
  const candidate=await saveDesignCandidate(f.env,{userId:'u',projectId:'p',requestKey:'large-draft-protection',baseVersionId:null,scope:{kind:'site'},manifest,source:'manual'});assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n,0);await assert.rejects(()=>setMediaDeleted(f.env,'u',asset.id,true),/引用/);
  const batch=f.db.batch.bind(f.db);let injected=false;(f.db as any).batch=async(statements:any[])=>{const result=await batch(statements);if(!injected&&statements.some(s=>String(s.sql).includes('INSERT INTO design_versions'))){injected=true;throw new Error('adoption acknowledgement lost');}return result;};
  await assert.rejects(()=>adoptDesignCandidate(f.env,'u','p',candidate.id),/acknowledgement/);const adopted=await adoptDesignCandidate(f.env,'u','p',candidate.id);assert.ok(adopted.versionId);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n,1);await assert.rejects(()=>setMediaDeleted(f.env,'u',asset.id,true),/引用/);
 }finally{f.db.close();}
});

test('cleanup winning before the version commit cannot leave a dangling R2 pointer or change current design',async()=>{
 const f=fixture();try{const manifest=largeManifest(1100000),batch=f.db.batch.bind(f.db);let injected=false;f.db.batch=async(statements:any[])=>{if(!injected&&statements.some(s=>String(s.sql).includes('INSERT INTO design_versions'))){injected=true;assert.equal((await purgeUnreferencedDesignManifests(f.env,Date.now()+2*DAY)).removed,1);}return batch(statements);};
  await assert.rejects(()=>saveVersion(f.env,'u','p',manifest,'manual',null,'gc-before-commit'),/pointer/);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n,0);assert.equal(f.db.sqlite.prepare("SELECT current_version_id FROM projects WHERE id='p'").get()!.current_version_id,null);
  const version=await saveVersion(f.env,'u','p',manifest,'manual',null,'gc-before-commit');assert.deepEqual(await readDesignVersion(f.env,'u','p',version),manifest);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM design_manifest_objects WHERE state='purged'").get()!.n,1);
 }finally{f.db.close();}
});
