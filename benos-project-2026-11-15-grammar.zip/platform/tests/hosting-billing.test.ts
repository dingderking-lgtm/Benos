import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1 } from './d1-helper';
import { hostingBillingSummary } from '../src/modules/hosting-billing';
import { app } from '../src/index';
import { testEnv } from './d1-helper';
import { publishTestPolicies } from './policy-fixture';

const NOW=Date.parse('2026-06-15T00:00:00.000Z'),date=(v:string)=>v+'T00:00:00.000Z';
function fixture(){const db=new TestD1();db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES('u','u@example.test','User','unused','user',?,?),('other','other@example.test','Other','unused','user',?,?)").run(date('2024-01-01'),date('2024-01-01'),date('2024-01-01'),date('2024-01-01'));return db;}
function site(db:TestD1,id='s',created='2025-01-01',user='u'){db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,?,?,?,'cms@example.test','connected',?,?)").run(id,user,id,id+'.example.com',date(created),date(created));}
function annual(db:TestD1,id:string,start:string,end:string,siteId='s',state='active',user='u'){db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES(?,?,?,'annual',?,?,?,?)").run(id,user,siteId,date(start),date(end),state,date(start));}
function membership(db:TestD1,id:string,start:string,end:string,sites=1,tier='go'){db.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,included_sites,credit_micros,grant_reference_id,created_at) VALUES(?,'u',?,'gift',?,?,?,1,?,?)").run(id,tier,date(start),date(end),sites,id,date(start));}
async function summary(db:TestD1){return hostingBillingSummary(db as unknown as D1Database,'u',NOW);}

test('adjacent and overlapping annual periods yield one site and one continuous paid-through interval',async()=>{
 const db=fixture();try{site(db);annual(db,'old','2025-01-01','2026-01-01');annual(db,'current','2026-01-01','2027-01-01');annual(db,'renewed','2027-01-01','2028-01-01');annual(db,'overlap','2026-12-01','2027-06-01');const rows=await summary(db);assert.equal(rows.length,1);assert.equal(rows[0].endsAt,date('2028-01-01'));assert.deepEqual(rows[0].coverage.current,{startsAt:date('2025-01-01'),endsAt:date('2028-01-01'),sources:['annual']});assert.deepEqual(rows[0].coverage.upcoming,[]);}finally{db.close();}
});
test('membership hosting displays the granted end and allocates only remaining oldest site slots',async()=>{
 const db=fixture();try{site(db,'first','2025-01-01');site(db,'second','2025-02-01');site(db,'third','2025-03-01');membership(db,'member','2026-06-01','2026-07-01');annual(db,'independent','2026-01-01','2027-01-01','first');const rows=await summary(db);assert.equal(rows[0].endsAt,date('2027-01-01'));assert.equal(rows[1].endsAt,date('2026-07-01'));assert.deepEqual(rows[1].coverage.current?.sources,['membership']);assert.equal(rows[2].coverage.current,null);}finally{db.close();}
});
test('confirmed membership renewal and annual handoff merge without extending through unpaid automatic renewals',async()=>{
 const db=fixture();try{site(db);membership(db,'m1','2026-06-01','2026-07-01');membership(db,'m2','2026-07-01','2026-08-01');annual(db,'year','2026-08-01','2027-08-01');const [row]=await summary(db);assert.equal(row.endsAt,date('2027-08-01'));assert.deepEqual(row.coverage.current?.sources,['annual','membership']);}finally{db.close();}
});
test('a future disjoint period is scheduled separately and never masquerades as current continuous coverage',async()=>{
 const db=fixture();try{site(db);annual(db,'current','2026-01-01','2026-07-01');annual(db,'future','2026-09-01','2027-09-01');const [row]=await summary(db);assert.equal(row.endsAt,date('2026-07-01'));assert.equal(row.coverage.upcoming.length,1);assert.equal(row.coverage.upcoming[0].startsAt,date('2026-09-01'));assert.equal(row.coverage.upcoming[0].endsAt,date('2027-09-01'));}finally{db.close();}
});
test('expired or not-yet-started coverage exposes no effective end; revoked and foreign grants never contribute',async()=>{
 const db=fixture();try{site(db);site(db,'other-site','2025-01-01','other');annual(db,'expired','2025-01-01','2026-01-01');annual(db,'future','2026-09-01','2027-09-01');annual(db,'revoked','2026-01-01','2028-01-01','s','revoked');annual(db,'foreign','2026-01-01','2029-01-01','s','active','other');const [row]=await summary(db);assert.equal(row.endsAt,null);assert.equal(row.coverage.current,null);assert.equal(row.coverage.state,'scheduled');assert.equal(row.coverage.lastEndedAt,date('2026-01-01'));assert.equal(row.coverage.upcoming.length,1);db.sqlite.prepare("UPDATE hosting_entitlements SET state='revoked' WHERE id='future'").run();const [expired]=await summary(db);assert.equal(expired.coverage.state,'expired');}finally{db.close();}
});
test('future slot reassignment respects a gap when older independent hosting expires',async()=>{
 const db=fixture();try{site(db,'first','2025-01-01');site(db,'second','2025-02-01');membership(db,'member','2026-06-01','2026-12-01');annual(db,'first-year','2026-01-01','2026-07-01','first');annual(db,'first-again','2026-09-01','2027-01-01','first');const rows=await summary(db),second=rows[1];assert.equal(second.endsAt,date('2026-07-01'));assert.equal(second.coverage.upcoming[0].startsAt,date('2026-09-01'));assert.equal(second.coverage.upcoming[0].endsAt,date('2026-12-01'));}finally{db.close();}
});
test('frozen membership is disclosed without inventing an expiry extension or suspending independent annual coverage',async()=>{
 const db=fixture();try{site(db,'first');site(db,'second');membership(db,'member','2026-06-01','2026-07-01',2);db.sqlite.prepare("INSERT INTO membership_freezes(id,user_id,actor_id,request_key,payload_hash,reason,state,requested_at_ms,frozen_at_ms,updated_at) VALUES('freeze','u','u','freeze-key','hash','test','frozen',?,?,?)").run(NOW,NOW,date('2026-06-15'));db.sqlite.prepare("UPDATE subscriptions SET membership_frozen_by='freeze'").run();annual(db,'independent','2026-01-01','2027-01-01','first');const rows=await summary(db);assert.equal(rows[0].endsAt,date('2027-01-01'));assert.equal(rows[1].endsAt,null);assert.equal(rows[1].coverage.membershipFrozen,true);}finally{db.close();}
});

test('authenticated billing summary returns one owned site, safe checkout hints and no topup recovery after membership expiry',async()=>{
 const db=new TestD1(),env=testEnv(db);
 try{
  publishTestPolicies(db);
  const auth=await app.request('/api/auth/register',{method:'POST',headers:{origin:env.APP_ORIGIN,'content-type':'application/json'},body:JSON.stringify({email:'billing@example.test',name:'Billing',password:'billing-test-password'})},env);assert.equal(auth.status,201);const user=(await auth.json() as any).data.user,cookie=auth.headers.get('set-cookie')!.split(';')[0];
  db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,created_at,updated_at) VALUES('site',?,'Site','billing.example.test','cms@example.test',?,?)").run(user.id,date('2025-01-01'),date('2025-01-01'));
  annual(db,'annual-a','2025-01-01','2027-01-01','site','active',user.id);annual(db,'annual-b','2027-01-01','2028-01-01','site','active',user.id);
  for(const kind of ['subscription','topup'])db.sqlite.prepare("INSERT INTO orders(id,user_id,kind,amount_cents,credit_micros,currency,state,idempotency_key,payload_hash,created_at,expires_at,checkout_id,checkout_url) VALUES(?,?,?,500,3250000,'USD','pending',?,'hash',?,?,?,'https://checkout.stripe.com/private')").run(kind,user.id,kind,kind,date('2026-01-01'),date('2099-01-01'),'private-session-'+kind);
  const response=await app.request('/api/billing/summary',{headers:{cookie}},env);assert.equal(response.status,200);const data=(await response.json() as any).data;
  assert.equal(data.hosting.length,1);assert.equal(data.hosting[0].endsAt,date('2028-01-01'));assert.equal(data.orders.find((o:any)=>o.kind==='subscription').canResumeCheckout,true);assert.equal(data.orders.find((o:any)=>o.kind==='topup').canResumeCheckout,false);assert.equal(data.canTopup,false);
  assert.equal(data.orders[0].checkoutExpiresAt,date('2099-01-01'));assert.doesNotMatch(JSON.stringify(data),/private-session|checkout_url|checkout_id/);
 }finally{db.close();}
});
