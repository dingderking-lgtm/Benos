import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { app } from '../src/index';
import { sha256,randomToken } from '../src/lib/crypto';
test('CMS release upload is owner-only, hash-bound, private and recoverable after lost storage acknowledgement',async()=>{
 const db=new TestD1(),env=testEnv(db),time=new Date().toISOString(),token=randomToken(32),csrf=randomToken(24),objects=new Map<string,{bytes:Uint8Array;metadata:any}>();let puts=0,loseAck=true;
 try{
  for(const role of ['owner','user'])db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(role,role+'@example.test',role,'unused',role,time,time);
  db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session','owner',await sha256(token),csrf,time,new Date(Date.now()+3600000).toISOString(),'test-ip');
  env.BUCKET={head:async(key:string)=>{const obj=objects.get(key);return obj?{size:obj.bytes.length,customMetadata:obj.metadata}:null;},put:async(key:string,bytes:Uint8Array,options:any)=>{puts++;objects.set(key,{bytes:new Uint8Array(bytes),metadata:options.customMetadata});if(loseAck){loseAck=false;throw Error('lost storage response');}return {key};}} as unknown as R2Bucket;
  const bytes=new Uint8Array(40);bytes.set([0x50,0x4b,3,4]);const hash=await sha256(bytes),headers={origin:env.APP_ORIGIN,'content-type':'application/zip','x-content-sha256':hash,cookie:'benos_session='+token,'x-csrf-token':csrf};
  const send=(h:Record<string,string>=headers,data=bytes)=>app.request('/api/admin/cms-releases/upload',{method:'POST',headers:h,body:data},env);
  assert.equal((await send({...headers,cookie:''})).status,401);
  db.sqlite.prepare("UPDATE sessions SET user_id='user'").run();assert.equal((await send()).status,403);assert.equal(puts,0);db.sqlite.prepare("UPDATE sessions SET user_id='owner'").run();
  assert.equal((await send({...headers,'x-content-sha256':'0'.repeat(64)})).status,400);assert.equal(puts,0);
  assert.equal((await send()).status,500);const retry=await send();assert.equal(retry.status,201);const result=(await retry.json() as any).data;assert.equal(result.cmsReleaseObjectKey,'private/cms-releases/'+hash+'.zip');assert.equal(result.verified,true);assert.equal(puts,1);
  assert.deepEqual([...objects.values()][0].bytes,bytes);assert.equal((await send({...headers,'content-length':String(49*1024*1024)})).status,413);
 }finally{db.close();}
});
