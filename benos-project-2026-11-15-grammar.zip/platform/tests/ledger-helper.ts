import { DatabaseSync, type SQLInputValue } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { URL } from 'node:url';

type ResultRow = Record<string, unknown>;

class Statement {
  constructor(readonly owner: LedgerTestDatabase, readonly sql: string, readonly values: SQLInputValue[] = []) {}
  bind(...values: SQLInputValue[]): Statement { return new Statement(this.owner, this.sql, values); }
  execute(): D1Result<ResultRow> {
    // D1 binds ?1 by index; node:sqlite treats it as a named parameter. Expand
    // numbered placeholders to positional placeholders without changing SQL semantics.
    const argumentsInOrder: SQLInputValue[] = [];
    const sql = this.sql.replace(/\?(\d+)/g, (_match, index: string) => {
      const value = this.values[Number(index) - 1];
      if (value === undefined) throw new Error(`Unbound SQL parameter ${index}`);
      argumentsInOrder.push(value);
      return '?';
    });
    const values = argumentsInOrder.length ? argumentsInOrder : this.values;
    const rows = this.owner.sqlite.prepare(sql).all(...values) as ResultRow[];
    const change = this.owner.sqlite.prepare('SELECT changes() AS changes, last_insert_rowid() AS rowid').get()!;
    return { success: true, results: rows, meta: {
      changes: Number(change.changes), last_row_id: Number(change.rowid), duration: 0,
      changed_db: Number(change.changes) > 0, size_after: 0, rows_read: 0, rows_written: Number(change.changes),
    } };
  }
  async all<T = ResultRow>(): Promise<D1Result<T>> { return this.execute() as D1Result<T>; }
  async run<T = ResultRow>(): Promise<D1Result<T>> { return this.execute() as D1Result<T>; }
  async first<T = ResultRow>(column?: string): Promise<T | null> {
    const row = this.execute().results[0];
    return (row ? column ? row[column] : row : null) as T | null;
  }
}

/** Real SQLite SQL and real transaction rollback; not a mocked balance store.
 * This is a local adapter test, not evidence of a remote D1 deployment. */
export class LedgerTestDatabase {
  readonly sqlite = new DatabaseSync(':memory:');
  failAfterStatement: number | null = null;
  failAfterCommit = false;

  constructor() {
    this.sqlite.exec(`PRAGMA foreign_keys = ON;
      CREATE TABLE users (id TEXT PRIMARY KEY, status TEXT NOT NULL DEFAULT 'active');
      CREATE TABLE user_restrictions (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
        scope TEXT NOT NULL, starts_at TEXT NOT NULL, ends_at TEXT, revoked_at TEXT);`);
    this.sqlite.exec(readFileSync(new URL('../migrations/0002_billing.sql', import.meta.url), 'utf8'));
    // The membership migration adds this nullable link without changing accounting semantics.
    this.sqlite.exec('ALTER TABLE credit_grants ADD COLUMN membership_frozen_by TEXT');
    this.sqlite.exec('ALTER TABLE credit_grants ADD COLUMN entitlement_revoked_by TEXT');
    this.sqlite.exec("ALTER TABLE credit_grants ADD COLUMN reversed_micros INTEGER NOT NULL DEFAULT 0 CONSTRAINT ledger_grant_reversal_balance CHECK(typeof(reversed_micros)='integer' AND reversed_micros>=0 AND reversed_micros+consumed_micros+reserved_micros<=amount_micros)");
    this.sqlite.prepare("INSERT INTO users (id) VALUES ('user-a'), ('user-b')").run();
  }
  prepare(sql: string): Statement { return new Statement(this, sql); }
  async batch<T = ResultRow>(statements: Statement[]): Promise<D1Result<T>[]> {
    const failAt = this.failAfterStatement;
    this.failAfterStatement = null;
    this.sqlite.exec('BEGIN IMMEDIATE');
    const results: D1Result<ResultRow>[] = [];
    try {
      for (let i = 0; i < statements.length; i++) {
        results.push(statements[i].execute());
        if (failAt === i) throw new Error('Simulated failure inside D1 batch');
      }
      this.sqlite.exec('COMMIT');
    } catch (error) {
      this.sqlite.exec('ROLLBACK');
      throw error;
    }
    if (this.failAfterCommit) {
      this.failAfterCommit = false;
      throw new Error('Simulated lost commit acknowledgement');
    }
    return results as D1Result<T>[];
  }
  asD1(): D1Database { return this as unknown as D1Database; }
  row(sql: string, ...values: SQLInputValue[]): ResultRow {
    return this.sqlite.prepare(sql).get(...values) as ResultRow;
  }
  rows(sql: string, ...values: SQLInputValue[]): ResultRow[] {
    return this.sqlite.prepare(sql).all(...values) as ResultRow[];
  }
  close(): void { this.sqlite.close(); }
}
