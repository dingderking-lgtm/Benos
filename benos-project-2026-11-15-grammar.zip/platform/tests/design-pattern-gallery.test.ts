import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parse } from 'parse5';
import { app } from '../src/index';
import { randomToken,sha256 } from '../src/lib/crypto';
import { TestD1,testEnv } from './d1-helper';
import { PATTERN_GALLERY_ASSETS } from '../src/contracts/pattern-gallery-assets';
import { getSectionPatternCatalog,filterCurrentPatternApprovals } from '../src/lib/page-composer';
import { readApprovedPatterns } from '../src/lib/pattern-approvals';

const base='/api/admin/design-patterns',asset=PATTERN_GALLERY_ASSETS[0];
async function fixture(){
 const db=new TestD1(),env=testEnv(db),now=new Date().toISOString(),headers:Record<string,Record<string,string>>={},assetReads:string[]=[];
 for(const role of ['owner','admin','user']){
  db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(role,role+'@gallery.test',role,'unused',role,'active',now,now);
  const token=randomToken();db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('session-'+role,await sha256(token),role,'csrf-'+role,now,new Date(Date.now()+3600000).toISOString(),'fixture');
  headers[role]={cookie:'benos_session='+token,origin:env.APP_ORIGIN,'x-csrf-token':'csrf-'+role,'content-type':'application/json'};
 }
 env.ASSETS={fetch:async(request:Request)=>{const path=new URL(request.url).pathname;assetReads.push(path);return new Response(new Uint8Array([137,80,78,71]),{headers:{'Content-Type':'image/png'}});}} as unknown as Fetcher;
 return{db,env,headers,assetReads};
}
async function reviewInput(requestKey='gallery-review-request-001'){
 const catalog=await getSectionPatternCatalog(),family=catalog.families[0],variant=family.variants[0];
 return{patternId:family.id,variantId:variant.id,revision:family.revision,compiledHash:variant.compiledHash,skin:variant.allowedSkins[0],state:'approved' as const,requestKey};
}
function nodes(html:string){const result:any[]=[],stack:any[]=[parse(html)];while(stack.length){const n=stack.pop();if(n.tagName)result.push(n);stack.push(...n.childNodes??[]);}return result;}

test('every gallery document and both private asset aliases reject anonymous and ordinary accounts before ASSETS',async()=>{
 const f=await fixture();try{
  const paths=[base,base+'/preview?pattern=hero-stage&variant=product-stage&skin=soft-gradient',base+'/page?skin=soft-gradient',base+'/collection?skin=soft-gradient',base+'/assets/'+asset.file,asset.path];
  for(const path of paths){assert.equal((await app.request(path,{},f.env)).status,401,path);assert.equal((await app.request(path,{headers:f.headers.user},f.env)).status,403,path);}
  assert.deepEqual(f.assetReads,[]);assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM design_pattern_reviews').get()!.n,0);
  assert.match(readFileSync('wrangler.jsonc','utf8'),/"run_worker_first"\s*:\s*true/,'backing files must not bypass Worker auth');
 }finally{f.db.close();}
});

test('admin can read current catalog but only an owner with CSRF may review',async()=>{
 const f=await fixture();try{
  const listing=await app.request(base,{headers:f.headers.admin},f.env);assert.equal(listing.status,200);const body:any=await listing.json();assert.equal(body.data.patterns.length,12);
  const value=await reviewInput(),post=(headers:Record<string,string>)=>app.request(base+'/review',{method:'POST',headers,body:JSON.stringify(value)},f.env);
  assert.equal((await post(f.headers.admin)).status,403);
  const noCsrf={...f.headers.owner};delete noCsrf['x-csrf-token'];assert.equal((await post(noCsrf)).status,403);
  assert.equal((await post({...f.headers.owner,origin:'https://foreign.example'})).status,403);
  f.db.sqlite.prepare("UPDATE users SET status='restricted' WHERE id='owner'").run();assert.equal((await post(f.headers.owner)).status,403);
  assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM design_pattern_review_requests').get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM api_reservations').get()!.n,0);
 }finally{f.db.close();}
});

test('owner cannot approve a stale hash, revision, variant or unavailable skin',async()=>{
 const f=await fixture();try{
  const value=await reviewInput();for(const change of [{compiledHash:'0'.repeat(64)},{revision:value.revision+1},{variantId:'missing-variant'},{skin:'missing-skin'}]){
   const response=await app.request(base+'/review',{method:'POST',headers:f.headers.owner,body:JSON.stringify({...value,...change})},f.env);assert.equal(response.status,409);assert.equal((await response.json() as any).error.code,'PATTERN_REVIEW_STALE');
  }
  assert.deepEqual(await readApprovedPatterns(f.env.DB),[]);assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM design_pattern_review_requests').get()!.n,0);
 }finally{f.db.close();}
});

test('review races/replays write one receipt and audit; old replay never undoes a later withdrawal',async()=>{
 const f=await fixture();try{
  const value=await reviewInput(),post=(v:unknown)=>app.request(base+'/review',{method:'POST',headers:f.headers.owner,body:JSON.stringify(v)},f.env);
  const responses=await Promise.all([post(value),post(value),post(value)]);for(const r of responses)assert.equal(r.status,200);
  const bodies=await Promise.all(responses.map(async r=>(await r.json() as {data:unknown}).data));assert.deepEqual(bodies,[bodies[0],bodies[0],bodies[0]]);
  assert.equal(f.db.sqlite.prepare("SELECT count(*) n FROM audit_logs WHERE action='design.pattern_reviewed'").get()!.n,1);assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM design_pattern_review_requests').get()!.n,1);
  const approvals=await filterCurrentPatternApprovals(await readApprovedPatterns(f.env.DB));assert.deepEqual(approvals,[{patternId:value.patternId,variantId:value.variantId,revision:value.revision,compiledHash:value.compiledHash,skins:[value.skin]}]);
  assert.equal((await post({...value,state:'rejected'})).status,409);
  assert.equal((await post({...value,state:'draft',requestKey:'gallery-review-withdraw-001'})).status,200);assert.deepEqual(await readApprovedPatterns(f.env.DB),[]);
  assert.equal((await post(value)).status,200);assert.deepEqual(await readApprovedPatterns(f.env.DB),[]);
  assert.equal(f.db.sqlite.prepare("SELECT count(*) n FROM audit_logs WHERE action='design.pattern_reviewed'").get()!.n,2);assert.equal(f.db.sqlite.prepare('SELECT count(*) n FROM api_reservations').get()!.n,0);
 }finally{f.db.close();}
});

test('preview, complete page and collection are inert documents with same-origin gallery images only',async()=>{
 const f=await fixture();try{
  for(const path of [base+'/preview?pattern=hero-stage&variant=product-stage&skin=soft-gradient',base+'/preview?pattern=media-mosaic&variant=bento&skin=bold-outline&fixture=rtl',base+'/page?skin=clean-business',base+'/collection?skin=soft-gradient&variants=all']){
   const response=await app.request(path,{headers:f.headers.admin},f.env);assert.equal(response.status,200,path);const csp=response.headers.get('content-security-policy')!;
   for(const rule of ["sandbox allow-same-origin","script-src 'none'","font-src 'none'","connect-src 'none'","form-action 'none'","frame-ancestors 'self'"])assert.ok(csp.includes(rule),csp);
   assert.equal(response.headers.get('x-frame-options'),'SAMEORIGIN');assert.match(response.headers.get('cache-control')!,/private.*no-store/);
   const html=await response.text(),elements=nodes(html);assert.ok(elements.some(n=>n.tagName==='section'||n.tagName==='footer'));
   assert.equal(elements.some(n=>['script','iframe','form','link','object','embed'].includes(n.tagName)),false);
   for(const n of elements)for(const a of n.attrs??[]){assert.ok(!/^on/i.test(a.name));if(a.name==='src')assert.ok(PATTERN_GALLERY_ASSETS.some(x=>a.value===base+'/assets/'+x.file),a.value);if(a.name==='href')assert.ok(a.value.startsWith('#'),a.value);}
   assert.doesNotMatch(html,/@import|url\(\s*["']?https?:/i);
   const ids=elements.flatMap(n=>(n.attrs??[]).filter((a:any)=>a.name==='id').map((a:any)=>a.value));assert.equal(new Set(ids).size,ids.length,'all rendered IDs must be unique');
  }
  assert.deepEqual(f.assetReads,[],'rendering fixture HTML does not fetch media or call a model');
 }finally{f.db.close();}
});

test('authorized assets are allowlisted, while unknown names never reach the backing store',async()=>{
 const f=await fixture();try{
  for(const path of [base+'/assets/'+asset.file,asset.path]){const response=await app.request(path,{headers:f.headers.admin},f.env);assert.equal(response.status,200);assert.equal(response.headers.get('content-type'),'image/png');assert.equal(response.headers.get('x-content-type-options'),'nosniff');assert.equal(response.headers.get('etag'),'"'+asset.sha256+'"');assert.match(response.headers.get('cache-control')!,/^private, no-store$/);assert.deepEqual([...new Uint8Array(await response.arrayBuffer())],[137,80,78,71]);}
  assert.deepEqual(f.assetReads,[asset.path,asset.path]);for(const path of [base+'/assets/unknown.png','/assets/pattern-gallery/unknown.png'])assert.equal((await app.request(path,{headers:f.headers.owner},f.env)).status,404);
  assert.equal(f.assetReads.length,2);
 }finally{f.db.close();}
});


test('encoded private backing paths cannot fall through to the public ASSETS handler',async()=>{
 const f=await fixture();try{
  for(const path of ['/assets/%70attern-gallery/'+asset.file,'/%61ssets/pattern-gallery/'+asset.file,'/assets/pattern%2Dgallery/'+asset.file]){
   const response=await app.request(path,{},f.env);assert.ok([400,401,403,404].includes(response.status),`${path}: ${response.status}`);
  }
  assert.deepEqual(f.assetReads,[],'private aliases must be rejected before a static backend can decode them');
 }finally{f.db.close();}
});
