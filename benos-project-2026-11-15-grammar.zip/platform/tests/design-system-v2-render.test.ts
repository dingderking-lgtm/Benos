import test from 'node:test';
import assert from 'node:assert/strict';
import { parseFragment } from 'parse5';
import { compileV2Page, getV2Catalog, renderV2Section, type V2RenderContext } from '../src/design-system/v2/render';
import { V2_PATTERN_DEFINITIONS, V2_PRESETS, createWebsiteTokenSnapshot } from '../src/design-system/v2/contracts';
import { getV2Fixture, createV2PageFixture } from '../src/design-system/v2/fixtures';
import { v2TokenCss } from '../src/design-system/v2/styles';

function nodes(html:string){const all:any[]=[];const visit=(node:any)=>{if(node.tagName)all.push(node);for(const child of node.childNodes||[])visit(child);};visit(parseFragment(html));return all;}
const attr=(node:any,name:string)=>node.attrs?.find((a:any)=>a.name===name)?.value;
const text=(node:any):string=>node.nodeName==='#text'?node.value:(node.childNodes||[]).map(text).join('');

test('all 111 reviewed variants compile to native scoped markup with exact provenance and no executable embeds',async()=>{
 const hashes=new Set<string>();
 for(const preset of V2_PRESETS)for(const family of V2_PATTERN_DEFINITIONS)for(const variant of family.variants){
  const f=getV2Fixture(family.id,variant.id,preset),r=await renderV2Section(f.input,f.context),dom=nodes(r.html);
  assert.equal(r.reviewOnly,true);assert.equal(r.customerExportReady,false);assert.equal(r.artifact.approvalStatus,'draft');
  assert.equal(r.receipt.compiledHash,r.artifact.artifactHash);hashes.add(r.artifact.artifactHash);
  assert.equal(dom.some(n=>['script','iframe','svg','style','header'].includes(n.tagName)),false);
  assert.equal(dom.some(n=>(n.attrs||[]).some((a:any)=>/^on/i.test(a.name))),false);
  assert.equal(dom.filter(n=>n.tagName==='h1').length,family.role==='hero'||family.role==='contact'?1:0);
  assert.ok(text(parseFragment(r.html)).includes(f.input.content.title));
  assert.ok(r.css.includes('--bnf-heading'));assert.ok(r.css.includes('--bnf-body'));assert.equal(/\.bns-|:root\s*\{|@import|@font-face/.test(r.css),false);
  assert.ok(r.notices.length>0);assert.ok(r.notices.every(n=>n.text.length>500&&/^[a-f0-9]{64}$/.test(n.sha256)));
  assert.deepEqual(r.sourceRefs.map(s=>s.id),family.sourceIds);
 }
 assert.equal(hashes.size,111);
});

test('owned complete images freeze actual natural geometry and stay distinct from cover cropping',async()=>{
 const f=getV2Fixture('hero-stage','split','calm-paper',{example:'industrial'}),r=await renderV2Section(f.input,f.context),img=nodes(r.html).find(n=>n.tagName==='img'),asset=f.context.ownedAssets.find(a=>a.path===attr(img,'src'))!;
 assert.deepEqual([Number(attr(img,'width')),Number(attr(img,'height'))],[asset.width,asset.height]);
 assert.deepEqual([r.frames[0].slot.width,r.frames[0].slot.height],[asset.width,asset.height]);
 assert.equal(r.frames[0].subjectPolicy,'complete');assert.equal(r.frames[0].framePolicy,'adapt');assert.equal(r.frames[0].presentation,'standard');
 assert.ok(r.html.includes('bnx-media-complete'));
 const cover=getV2Fixture('hero-cover','scene','calm-paper');cover.input.media[0].subjectPolicy='complete';
 await assert.rejects(renderV2Section(cover.input,cover.context),/BNX_COVER_REQUIRES_CROP_SAFE/);
});

test('unverified, remote, escaped or impossible media is rejected before any markup is returned',async()=>{
 const f=getV2Fixture('hero-stage','split','calm-paper');
 await assert.rejects(renderV2Section(f.input,{mode:'review',ownedAssets:[]}),/BNX_ASSET_NOT_VERIFIED/);
 for(const path of ['https://example.test/image.png','//example.test/image.png','/a/../private.png','/a" onerror="x']){
  const input=structuredClone(f.input);input.media[0].assetPath=path;
  await assert.rejects(renderV2Section(input,{mode:'review',ownedAssets:[{path,width:100,height:100,source:'uploaded'}]}),/BNX_ASSET_PATH_INVALID/);
 }
 const input=structuredClone(f.input),asset={...f.context.ownedAssets[0],width:0};input.media[0].assetPath=asset.path;
 await assert.rejects(renderV2Section(input,{mode:'review',ownedAssets:[asset]}),/BNX_ASSET_NOT_VERIFIED/);
});

test('partial mosaic degradation preserves media index and every supplied caption without phantom frames',async()=>{
 const f=getV2Fixture('media-mosaic','dominant','calm-paper');f.input.media[0]={...f.input.media[0],kind:'missing'};
 const r=await renderV2Section(f.input,f.context),dom=nodes(r.html),figures=dom.filter(n=>n.tagName==='figure');
 assert.equal(r.frames.length,2);assert.equal(dom.filter(n=>n.tagName==='img').length,2);
 assert.ok(text(figures[0]).includes(f.input.content.items[1].title));assert.equal(text(figures[0]).includes(f.input.content.items[0].title),false);
 assert.ok(text(parseFragment(r.html)).includes(f.input.content.items[0].title));
 assert.ok(r.issues.some(x=>x.code==='BNX_COMPOSITION_DEGRADED'));assert.ok(r.html.includes('role="region"'));
});

test('no-image cases keep content and emit neither empty gallery shells nor image requests',async()=>{
 for(const preset of V2_PRESETS)for(const family of V2_PATTERN_DEFINITIONS)for(const variant of family.variants){
  const f=getV2Fixture(family.id,variant.id,preset,{scenario:'no-images'}),r=await renderV2Section(f.input,f.context),dom=nodes(r.html),readable=text(parseFragment(r.html));
  assert.equal(r.frames.length,0);assert.equal(r.assets.length,0);assert.equal(dom.some(n=>n.tagName==='img'||attr(n,'class')?.split(' ').includes('bnx-media-rail')),false);
  for(const item of f.input.content.items)assert.ok(readable.includes(item.title)&&readable.includes(item.text));
 }
});

test('hero details, common body, values and links survive without fabricating missing facts',async()=>{
 const f=getV2Fixture('hero-stage','centered','deep-studio');
 f.input.content.body='The body remains visible.';
 f.input.content.items=[0,1,2].map(i=>({title:`Detail ${i}`,text:`Exact detail ${i}`,label:`Label ${i}`,value:`Value ${i}`,factRef:`fact-${i}`,href:`#detail-${i}`}));
 await assert.rejects(renderV2Section(f.input,f.context),/BNX_ITEM_FACT_NOT_VERIFIED/);
 const r=await renderV2Section(f.input,{...f.context,verifiedFactRefs:['fact-0','fact-1','fact-2']}),readable=text(parseFragment(r.html));
 for(const item of f.input.content.items){for(const v of [item.title,item.text,item.label,item.value])assert.ok(readable.includes(v!));assert.ok(r.html.includes(`href="${item.href}"`));}
 assert.ok(readable.includes(f.input.content.body));
});

test('footer contacts require server facts; unsafe links and markup never become active code',async()=>{
 const f=getV2Fixture('footer','directory','calm-paper');f.input.content.contact=[{label:'真实联系渠道',href:'mailto:hello@example.test',factRef:'company-email'}];
 await assert.rejects(renderV2Section(f.input,f.context),/BNX_CONTACT_NOT_VERIFIED/);
 f.input.content.title='<script>alert(1)</script>';
 const r=await renderV2Section(f.input,{...f.context,verifiedFactRefs:['company-email']});assert.equal(nodes(r.html).some(n=>n.tagName==='script'),false);assert.ok(r.html.includes('&lt;script&gt;'));
 f.input.content.contact[0].href='javascript:alert(1)';await assert.rejects(renderV2Section(f.input,{...f.context,verifiedFactRefs:['company-email']}));
});

test('FAQ uses actual native disclosure and action groups preserve primary and secondary destinations',async()=>{
 const f=getV2Fixture('faq','split','calm-paper'),r=await renderV2Section(f.input,f.context),dom=nodes(r.html),details=dom.filter(n=>n.tagName==='details');
 assert.equal(details.length,f.input.content.questions.length);assert.ok(details.every(d=>d.childNodes.some((n:any)=>n.tagName==='summary')));
 assert.ok(details.every(d=>!d.attrs.some((a:any)=>a.name==='open')));
 const a=getV2Fixture('action','band','bold-signal'),out=await renderV2Section(a.input,a.context),links=nodes(out.html).filter(n=>n.tagName==='a');
 assert.deepEqual(links.map(n=>attr(n,'href')),a.input.content.actions.map(v=>v.href));assert.ok(links.every(n=>text(n).trim().length>1));
});

test('whole pages deduplicate CSS, assets and notices and never add a second site header',async()=>{
 for(const preset of V2_PRESETS)for(const example of ['industrial','stay'] as const){
  const f=createV2PageFixture({preset,example}),r=await compileV2Page(f.input,f.context),dom=nodes(r.html);
  assert.equal(dom.filter(n=>n.tagName==='h1').length,1);assert.equal(dom.filter(n=>n.tagName==='footer').length,1);assert.equal(dom.filter(n=>n.tagName==='header').length,0);
  assert.equal(new Set(r.assets.map(a=>a.path)).size,r.assets.length);assert.equal(new Set(r.notices.map(n=>n.sourceId+'/'+n.path)).size,r.notices.length);
  assert.equal((r.css.match(/\.bnx-section\{box-sizing/g)||[]).length,1);assert.ok(new TextEncoder().encode(r.css).length<45000);
  assert.equal(r.reviewOnly,true);assert.equal(r.customerExportReady,false);
 }
});

test('review mode cannot be turned into customer export by a client flag',async()=>{
 const f=getV2Fixture('hero-stage','split','calm-paper');
 await assert.rejects(renderV2Section(f.input,{...f.context,mode:'production'} as unknown as V2RenderContext),/BNX_PATTERN_NOT_APPROVED/);
});

test('source CSS variables reject declaration injection and font tokens remain user-owned',()=>{
 const tokens=createWebsiteTokenSnapshot('calm-paper');tokens.colors.accent='red;}body{display:none';
 assert.throws(()=>v2TokenCss(tokens),/V2_UNSAFE_STYLE_TOKEN/);
 const safe=v2TokenCss(createWebsiteTokenSnapshot('deep-studio'));assert.equal(safe.includes('--bnf-heading:'),false);assert.equal(safe.includes('--bnf-body:'),false);
});

test('catalog preserves exact separate identities for all variants and three presets',async()=>{
 const catalog=await getV2Catalog(),artifacts=catalog.patterns.flatMap(p=>p.variants.flatMap(v=>v.artifacts));
 assert.equal(catalog.patterns.length,17);assert.equal(artifacts.length,111);assert.equal(new Set(artifacts.map(a=>a.artifactHash)).size,111);
 assert.ok(artifacts.every(a=>a.reviewOnly&&a.customerExportReady===false&&a.approvalStatus==='draft'));
});
