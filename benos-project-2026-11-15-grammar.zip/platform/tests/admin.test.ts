import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';
import { publishTestPolicies } from './policy-fixture';
import { validateConfiguration } from '../src/modules/integrations';

async function fixture(){
 const db=new TestD1(),env=testEnv(db);
 const request=async(path:string,method='GET',data?:unknown,session?:{cookie:string;csrf:string})=>app.fetch(new Request(env.APP_ORIGIN+path,{method,headers:{origin:env.APP_ORIGIN,...(data?{'content-type':'application/json'}:{}),...(session?{cookie:session.cookie,'x-csrf-token':session.csrf}:{})},body:data?JSON.stringify(data):undefined}),env);
 const res=await request('/api/bootstrap','POST',{token:env.BOOTSTRAP_TOKEN,email:'owner@example.test',password:'long-test-password',name:'Owner'}),user=await res.json() as any;
 const owner={cookie:res.headers.get('set-cookie')!.split(';')[0],csrf:user.data.csrfToken};
 return {db,env,request,owner};
}
test('content drafts stay private; publish snapshot, optimistic conflict, trash and restore preserve history',async()=>{
 const f=await fixture();try{
  const content={kind:'post',slug:'new-post',title:'草稿标题',content:{body:'<script>alert(1)</script> 作为纯文本内容'}};
  const created=await f.request('/api/admin/content','POST',content,f.owner);assert.equal(created.status,201);let row=(await created.json() as any).data;
  assert.equal((await (await f.request('/api/content')).json() as any).data.items.length,0);
  let res=await f.request('/api/admin/content/'+row.id+'/publish','POST',{revision:row.revision},f.owner);assert.equal(res.status,200);row=(await res.json() as any).data;
  res=await f.request('/api/admin/content/'+row.id,'PATCH',{...content,title:'未发布的新标题',revision:row.revision},f.owner);assert.equal(res.status,200);row=(await res.json() as any).data;
  const published=(await (await f.request('/api/content')).json() as any).data.items[0];assert.equal(published.title,'草稿标题');
  const stale=await f.request('/api/admin/content/'+row.id,'PATCH',{...content,revision:1},f.owner);assert.equal(stale.status,409);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) count FROM mutation_guards').get()!.count,0);
  res=await f.request('/api/admin/content/'+row.id,'DELETE',{revision:row.revision},f.owner);assert.equal(res.status,200);row=(await res.json() as any).data;
  assert.equal((await (await f.request('/api/content')).json() as any).data.items.length,0);
  res=await f.request('/api/admin/content/'+row.id+'/restore','POST',{revision:row.revision},f.owner);assert.equal(res.status,200);row=(await res.json() as any).data;
  assert.equal(row.state,'draft');assert.equal(row.published,null);assert.equal(row.title,'未发布的新标题');
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) count FROM content_revisions').get()!.count,5);
 }finally{f.db.close();}
});
test('integration secrets never return or enter audit, no activation before a passed probe, version replacement preserves old config',async()=>{
 const f=await fixture(),originalFetch=globalThis.fetch;try{
  const secretKey='sk_test_PRIVATE123456789',webhookSecret='whsec_PRIVATE123456789';
  const input={kind:'payment',provider:'stripe',name:'收款',publicConfig:{mode:'test',apiVersion:'2026-10-28.endive'},secret:{secretKey,webhookSecret}};
  const created=await f.request('/api/admin/integrations','POST',input,f.owner);assert.equal(created.status,201);const row=(await created.json() as any).data;assert.equal(row.hasSecret,true);assert.equal(row.secret,undefined);
  assert.equal((await f.request('/api/admin/integrations/'+row.id+'/activate','POST',{},f.owner)).status,409);
  globalThis.fetch=async()=>new Response(JSON.stringify({livemode:false}),{headers:{'content-type':'application/json'}});
  assert.equal((await f.request('/api/admin/integrations/'+row.id+'/test','POST',{},f.owner)).status,200);
  assert.equal((await f.request('/api/admin/integrations/'+row.id+'/activate','POST',{},f.owner)).status,200);
  const newRes=await f.request('/api/admin/integrations','POST',input,f.owner);assert.equal(newRes.status,201);const next=(await newRes.json() as any).data;assert.equal(next.version,2);
  assert.equal((await f.request('/api/admin/integrations/'+next.id+'/test','POST',{},f.owner)).status,200);
  assert.equal((await f.request('/api/admin/integrations/'+next.id+'/activate','POST',{},f.owner)).status,200);
  const list=await (await f.request('/api/admin/integrations','GET',undefined,f.owner)).text(),audit=await(await f.request('/api/admin/audit','GET',undefined,f.owner)).text();
  assert.ok(!list.includes(secretKey)&&!audit.includes(secretKey)&&!list.includes(webhookSecret));
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) count FROM integration_configs WHERE status='active'").get()!.count,1);
  assert.equal(f.db.sqlite.prepare('SELECT status FROM integration_configs WHERE id=?').get(row.id)!.status,'disabled');
  assert.ok(!String(f.db.sqlite.prepare('SELECT secret_ciphertext FROM integration_configs WHERE id=?').get(row.id)!.secret_ciphertext).includes(secretKey));
 }finally{globalThis.fetch=originalFetch;f.db.close();}
});
test('member records cannot be generically created or deleted and ordinary users cannot configure services',async()=>{
 const f=await fixture();try{
  assert.equal((await f.request('/api/admin/users','POST',{},f.owner)).status,403);
  publishTestPolicies(f.db);
  const reg=await f.request('/api/auth/register','POST',{email:'member@example.test',name:'Member',password:'long-test-password'}),data=await reg.json() as any;
  const member={cookie:reg.headers.get('set-cookie')!.split(';')[0],csrf:data.data.csrfToken},uid=data.data.user.id;
  assert.equal((await f.request('/api/admin/integrations','GET',undefined,member)).status,403);
  assert.equal((await f.request('/api/admin/users/'+uid,'DELETE',{},f.owner)).status,403);
  const freeze=await f.request('/api/admin/users/'+uid+'/restrictions','POST',{scopes:['login'],reason:'测试异常登录冻结'},f.owner);assert.equal(freeze.status,201);
  assert.equal((await f.request('/api/projects','GET',undefined,member)).status,401);
  const restriction=f.db.sqlite.prepare('SELECT id FROM user_restrictions WHERE user_id=?').get(uid)!.id;
  assert.equal((await f.request('/api/admin/users/'+uid+'/restrictions/'+restriction+'/revoke','POST',{reason:'核验完成解除冻结'},f.owner)).status,200);
  assert.equal((await f.request('/api/projects','GET',undefined,member)).status,200);
 }finally{f.db.close();}
});
test('provider funding is a receipt-backed idempotent budget and rejects wrong public endpoints',async()=>{
 const f=await fixture();try{
  const deposit={amountMicros:100_000_000,referenceId:'receipt-001',reason:'登记已经到账的充值',confirmedProviderDeposit:true};
  assert.equal((await f.request('/api/admin/budgets/openai-main/funding','POST',deposit,f.owner)).status,201);
  assert.equal((await f.request('/api/admin/budgets/openai-main/funding','POST',deposit,f.owner)).status,201);
  assert.equal(f.db.sqlite.prepare('SELECT funded_micros FROM provider_pools').get()!.funded_micros,100_000_000);
  assert.equal((await f.request('/api/admin/budgets/openai-main/funding','POST',{...deposit,amountMicros:101_000_000},f.owner)).status,409);
  for(const endpoint of ['http://private.example.com','https://127.0.0.1','https://localhost','https://service.local','https://user:password@api.example.com','https://api.example.com?token=private'])assert.throws(()=>validateConfiguration('hosting','benos-bridge',{endpoint,keyId:'key'}, {signingSecret:'a'.repeat(32)}));
 }finally{f.db.close();}
});
