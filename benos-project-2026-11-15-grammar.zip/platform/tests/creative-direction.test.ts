import test from 'node:test';
import assert from 'node:assert/strict';
import { createCreativeDirection } from '../src/contracts/creative-direction';

test('creative decisions are local, stable and serializable with room for explicit brand constraints', () => {
  const input = { hasExistingSite: false, stylePreference: '保持原品牌的宁静表达' };
  const first = createCreativeDirection(input)!;
  assert.equal(first.styleSource, 'user');
  assert.deepEqual(JSON.parse(JSON.stringify(first)), createCreativeDirection(input));
  assert.ok(JSON.stringify(first).length < 1600);
  assert.match(first.brandExpression, /可克制也可鲜明/);
  assert.match(first.composition, /不是必选区块或固定页序/);
  assert.ok(!('sections' in first) && !('palette' in first) && !('randomSeed' in first));
  first.brandExpression = 'changed';
  assert.notEqual(createCreativeDirection(input)!.brandExpression, 'changed');
});

test('creative latitude never replans existing sites or scoped edits', () => {
  assert.equal(createCreativeDirection({ hasExistingSite: true, stylePreference: '大胆新风格' }), null);
  for (const scope of ['page', 'node'] as const) assert.equal(createCreativeDirection({ hasExistingSite: false, scope }), null);
  assert.equal(createCreativeDirection({ hasExistingSite: false, stylePreference: ' ' })!.styleSource, 'automatic');
});

test('international expression protects target language, text direction and usable truthful actions', () => {
  const decisions = createCreativeDirection({ hasExistingSite: false })!;
  assert.match(decisions.internationalization, /用户指定或项目语言.*不因“出海”擅改英文/);
  assert.match(decisions.internationalization, /长品牌.*译文增长.*RTL.*dir.*逻辑方向.*不镜像产品图/);
  assert.match(decisions.internationalization, /语言入口只链接真实版本/);
  assert.match(decisions.boundaries, /真实下一步.*不编认证、客户、交付地区、价格或联系方式/);
  assert.match(decisions.boundaries, /移动阅读、键盘、对比度和减少动态效果/);
});

test('references constrain evidence without making every upload a product or every absence a generated photograph', () => {
  const supplied = createCreativeDirection({ hasExistingSite: false, referenceImageCount: 2 })!;
  const absent = createCreativeDirection({ hasExistingSite: false, referenceImageCount: Number.NaN })!;
  assert.match(supplied.imagery, /先辨认上传是品牌、作品、产品还是参考/);
  assert.match(absent.imagery, /没有上传也应判断图像任务/);
  for (const snapshot of [supplied, absent]) {
    assert.match(snapshot.imagery, /原生工作流示例/);
    assert.match(snapshot.imagery, /概念图不得冒充真实界面、产品或客户成果/);
    assert.doesNotMatch(JSON.stringify(snapshot), /https?:\/\/|tel:|mailto:/);
  }
});
