import test from 'node:test';
import assert from 'node:assert/strict';
import { patchDesignInlineText, assertDesignScope } from '../src/modules/design-nodes';
import { inlineTextPartsSchema } from '../src/modules/design-text-parts';

const scope = { kind:'node' as const, templateId:7, nodeKey:'n0' };
const fixture = (inner:string) => ({site:{name:'站',home:'home',pages:[]},assets:[],templates:[{id:7,name:'首页',type:'page',document:{version:1,css:'.keep{}',html:`<h1 class="bnx-title">${inner}</h1><p>原文</p>`}}]});
const phrase = '<span class="bnx-heading-phrase" data-btf-anchor="font1" style="font-family:serif!important">把时间留给<span class="bnx-heading-tail">山与海。</span></span>';
const parts = {slots:['',''],children:[{slots:['把时间留给',''],children:['山与海。']}]};
test('nested heading text changes only original text slots and preserves typography/structure',()=>{
 const base=fixture(phrase),original=JSON.stringify(base);
 assert.deepEqual(patchDesignInlineText(base,scope,parts),base);
 const next=patchDesignInlineText(base,scope,{slots:['',''],children:[{slots:['让日子走进',''],children:['<山林>。']}]}) as any;
 assert.equal(next.templates[0].document.html,base.templates[0].document.html.replace('把时间留给','让日子走进').replace('山与海。','&lt;山林&gt;。'));
 assertDesignScope(base,next,scope);assert.equal(JSON.stringify(base),original);
 assert(inlineTextPartsSchema.safeParse(parts).success);
});
test('nested editing cannot flatten, insert, omit or create markup/control subtrees',()=>{
 assert.throws(()=>patchDesignInlineText(fixture(phrase),scope,{slots:['',''],children:['替换全部']}),/复杂/);
 assert.throws(()=>patchDesignInlineText(fixture(phrase),scope,{slots:['',''],children:[{slots:['',''],children:[]}]}),/不能增减/);
 for(const forbidden of ['<a href="/">山海</a>','<span data-aacms="field">山海</span>','<span aria-hidden="true">+</span>','<span role="img">图标</span>','<span class="icon-menu">+</span>','<span style="font-family:FontAwesome">+</span>','<svg><path></path></svg>','<strong>山海</strong>','<span><span>更深</span></span>']) {
  assert.throws(()=>patchDesignInlineText(fixture(`<span>${forbidden}</span>`),scope,parts),/复杂|CMS/);
 }
 assert.throws(()=>patchDesignInlineText(fixture('<span>{{name}}<span>山海</span></span>'),scope,parts),/CMS/);
 assert(!inlineTextPartsSchema.safeParse({slots:['',''],children:[{slots:['',''],children:[parts]}]}).success,'API schema bounds recursion before materialization');
 assert(!inlineTextPartsSchema.safeParse({...parts,html:'<img>'}).success);
});
test('legacy one-level emphasis and plain nested span font anchors remain compatible',()=>{
 const base=fixture('认识<strong class="accent">材料</strong>'),next=patchDesignInlineText(base,scope,{slots:['了解','。'],children:['工艺']}) as any;
 assert.equal(next.templates[0].document.html,'<h1 class="bnx-title">了解<strong class="accent">工艺</strong>。</h1><p>原文</p>');
 assert.throws(()=>patchDesignInlineText(fixture(phrase),scope,{slots:['',''],children:[{slots:['',''],children:['']}]}),/不能为空/);
 assert.throws(()=>patchDesignInlineText(fixture(phrase),scope,{slots:['',''],children:[{slots:['',''],children:['\u0000']}]}),/无效/);
});
