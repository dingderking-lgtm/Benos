import assert from 'node:assert/strict';
import { beforeEach,afterEach,test } from 'node:test';
import { TestD1,testEnv } from './d1-helper';
import type { Env } from '../src/env';
import { encryptSecret } from '../src/lib/crypto';
import { activeSubscription,canTopup,createOrder } from '../src/modules/commerce';
import { getWallet,grantCredit,fundProvider,reserve,claimReservation,settle } from '../src/modules/ledger';
import { giftMembership,giftPeriods,freezeMembership,unfreezeMembership } from '../src/modules/memberships';
import { STRIPE_API_VERSION,type PaymentRuntime } from '../src/modules/payments';

type Fixture=Record<string,any>;
const NOW=Date.parse('2026-01-31T12:34:56.000Z'),DAY=86400_000,ISO=new Date(NOW).toISOString();
let database:TestD1,env:Env,runtime:PaymentRuntime,provider:Fixture,requests:{path:string;method:string;params:URLSearchParams}[],failPause:boolean,failResume:boolean,openInvoice:boolean;
beforeEach(async()=>{
 database=new TestD1();env=testEnv(database);requests=[];failPause=false;failResume=false;openInvoice=false;
 database.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES('owner','owner@example.test','Owner','unused','owner',?,?),('u','u@example.test','User','unused','user',?,?)").run(ISO,ISO,ISO,ISO);
 const secret=await encryptSecret(JSON.stringify({secretKey:'sk_test_this_is_a_local_test_key',webhookSecret:'whsec_local_test_endpoint_secret'}),env.ENCRYPTION_KEY,'pay');
 database.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('pay','payment','Stripe','stripe',1,'active',?,?,'passed','owner',?)")
  .run(JSON.stringify({mode:'test',apiVersion:STRIPE_API_VERSION}),secret,ISO);
 provider={id:'sub_paid',status:'active',livemode:false,pause_collection:null,trial_end:null,cancel_at_period_end:false};
 runtime={nowMs:NOW,fetch:async(input,init)=>{
  const url=new URL(String(input)),method=init?.method??'GET',params=new URLSearchParams(String(init?.body??''));requests.push({path:url.pathname,method,params});
  assert.equal(url.origin,'https://api.stripe.com');
  if(url.pathname==='/v1/invoices')return Response.json({has_more:false,data:openInvoice&&url.searchParams.get('status')==='open'?[{id:'in_open'}]:[]});
  assert.equal(url.pathname,'/v1/subscriptions/sub_paid');
  if(method==='POST'&&params.has('pause_collection[behavior]')){
   if(failPause)throw new Error('Simulated provider timeout');
   provider.pause_collection={behavior:'void'};
  }else if(method==='POST'){
   if(failResume)throw new Error('Simulated provider timeout');
   assert.equal(params.get('proration_behavior'),'none');provider.pause_collection=null;provider.trial_end=Number(params.get('trial_end'));
  }
  return Response.json(provider);
 }};
});
afterEach(()=>database.close());
const giftInput={tier:'go' as const,months:2,reason:'客户补偿赠送',requestKey:'gift-request-one'};
const freezeInput={reason:'会员申请暂停',requestKey:'freeze-request-one'};
const unfreezeInput={reason:'会员恢复服务',requestKey:'unfreeze-request-one'};
async function paidMembership(){
 database.sqlite.prepare("INSERT INTO orders(id,user_id,kind,plan_tier,amount_cents,credit_micros,state,provider,idempotency_key,payload_hash,created_at,expires_at,config_version_id) VALUES('paid-order','u','subscription','go',2500,16250000,'paid','stripe','paid-order-key','hash',?,?,'pay')")
  .run(ISO,new Date(NOW+28*DAY).toISOString());
 database.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,order_id,starts_at,ends_at,auto_renew,included_sites,credit_micros,topup_allowed,grant_reference_id,created_at) VALUES('paid-sub','u','go','paid','paid-order',?,?,1,1,16250000,1,'paid-period',?)")
  .run(ISO,new Date(NOW+28*DAY).toISOString(),ISO);
 database.sqlite.prepare("INSERT INTO payment_agreements(id,user_id,origin_order_id,config_version_id,provider_subscription_id,tier,state,created_at,updated_at) VALUES('agreement','u','paid-order','pay','sub_paid','go','active',?,?)").run(ISO,ISO);
 await grantCredit(env.DB,{id:'paid-credit',userId:'u',source:'subscription',amountMicros:16_250_000,startsAtMs:NOW,expiresAtMs:NOW+28*DAY,referenceId:'paid-period',nowMs:NOW});
}

test('gift anniversaries clamp month ends without drifting later months',()=>{
 const periods=giftPeriods(NOW,3);
 assert.equal(new Date(periods[0].expiresAtMs).toISOString(),'2026-02-28T12:34:56.000Z');
 assert.equal(new Date(periods[1].expiresAtMs).toISOString(),'2026-03-31T12:34:56.000Z');
 assert.equal(new Date(periods[2].expiresAtMs).toISOString(),'2026-04-30T12:34:56.000Z');
});

test('scheduled gifts start at the explicit future date and replay never shifts their billing periods',async()=>{
 const start=NOW+10*DAY,input={...giftInput,startsAt:new Date(start).toISOString()};
 await giftMembership(env,'owner','u',input,runtime);
 assert.equal((await getWallet(env.DB,'u',NOW)).availableMicros,0);
 assert.equal(await activeSubscription(env.DB,'u',ISO),null);
 assert.equal((await getWallet(env.DB,'u',start)).availableMicros,16_250_000);
 await giftMembership(env,'owner','u',input,{...runtime,nowMs:start+DAY});
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) n FROM membership_gifts').get()!.n,1);
 assert.equal(database.sqlite.prepare('SELECT MIN(starts_at) start FROM subscriptions').get()!.start,input.startsAt);
 await assert.rejects(()=>giftMembership(env,'owner','u',{...input,startsAt:new Date(start+DAY).toISOString()},runtime),/相同请求/);
 await assert.rejects(()=>giftMembership(env,'owner','u',{...input,requestKey:'gift-invalid-past',startsAt:new Date(NOW-DAY).toISOString()},runtime),/开始时间/);
});

test('gifted Go/Pro include full monthly AI but future months and paid topup privileges stay unavailable',async()=>{
 await giftMembership(env,'owner','u',giftInput,runtime);
 const wallet=await getWallet(env.DB,'u',NOW);
 assert.equal(wallet.giftMicros,16_250_000);assert.equal(wallet.grants.length,2);
 assert.equal((await activeSubscription(env.DB,'u',ISO))?.included_sites,1);
 assert.equal(await canTopup(env.DB,'u',ISO),false);
 await giftMembership(env,'owner','u',giftInput,runtime);
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM credit_grants').get()!.count,2);
 await assert.rejects(giftMembership(env,'owner','u',{...giftInput,tier:'pro'},runtime));
 const next=giftPeriods(NOW,2)[1].startsAtMs;
 assert.equal((await getWallet(env.DB,'u',next)).giftMicros,16_250_000);
 assert.equal((await getWallet(env.DB,'u',next)).expiredMicros,16_250_000);
 await giftMembership(env,'owner','u',{tier:'pro',months:1,reason:'赠送高级服务',requestKey:'gift-pro-request'},runtime);
 assert.equal((await getWallet(env.DB,'u',NOW)).giftMicros,81_250_000);
 assert.equal((await activeSubscription(env.DB,'u',ISO))?.included_sites,2);
});

test('freezing gifted membership pauses monthly credit while purchased topup remains spendable',async()=>{
 await giftMembership(env,'owner','u',giftInput,runtime);
 await grantCredit(env.DB,{id:'topup',userId:'u',source:'topup',amountMicros:1000,referenceId:'topup',nowMs:NOW});
 await fundProvider(env.DB,{id:'fund',providerId:'openai',amountMicros:10000,referenceId:'fund',nowMs:NOW});
 const status=await freezeMembership(env,'owner','u',freezeInput,runtime);assert.equal(status.freeze?.state,'frozen');
 assert.equal((await activeSubscription(env.DB,'u',ISO)),null);
 const wallet=await getWallet(env.DB,'u',NOW);assert.equal(wallet.availableMicros,1000);assert.equal(wallet.pausedMicros,32_500_000);
 await reserve(env.DB,{id:'topup-request',userId:'u',providerId:'openai',amountMicros:100,requestKey:'topup-request',nowMs:NOW});
 assert.equal(database.sqlite.prepare('SELECT grant_id FROM reservation_allocations').get()!.grant_id,'topup');
 await assert.rejects(createOrder(env.DB,'u',{kind:'subscription',tier:'go',requestKey:'new-subscription'},'pay',NOW));
 await assert.rejects(giftMembership(env,'owner','u',{...giftInput,requestKey:'another-gift'},runtime));
 assert.equal(requests.length,0);
});

test('unfreeze compensates elapsed time once, shifts future gift months, and never revives expired earlier credits',async()=>{
 await giftMembership(env,'owner','u',giftInput,runtime);
 await grantCredit(env.DB,{id:'old-gift',userId:'u',source:'gift',amountMicros:100,expiresAtMs:NOW,referenceId:'old',nowMs:NOW-1000});
 await freezeMembership(env,'owner','u',freezeInput,runtime);runtime.nowMs=NOW+40*DAY;
 const result=await unfreezeMembership(env,'owner','u',unfreezeInput,runtime);assert.equal(result.freeze?.state,'completed');assert.equal(result.freeze?.compensatedMs,40*DAY);
 const wallet=await getWallet(env.DB,'u',runtime.nowMs);assert.equal(wallet.giftMicros,16_250_000);assert.equal(wallet.pausedMicros,0);assert.equal(wallet.expiredMicros,100);
 const subscriptions=database.sqlite.prepare('SELECT starts_at,ends_at FROM subscriptions ORDER BY starts_at').all();
 assert.equal(subscriptions[0].ends_at,new Date(giftPeriods(NOW,2)[0].expiresAtMs+40*DAY).toISOString());
 assert.equal(subscriptions[1].starts_at,subscriptions[0].ends_at);
 await unfreezeMembership(env,'owner','u',unfreezeInput,{...runtime,nowMs:NOW+41*DAY});
 assert.equal(database.sqlite.prepare('SELECT ends_at FROM subscriptions ORDER BY starts_at LIMIT 1').get()!.ends_at,subscriptions[0].ends_at);
});

test('freeze blocks a not-yet-dispatched monthly reservation but known upstream cost can still settle',async()=>{
 await giftMembership(env,'owner','u',{...giftInput,months:1},runtime);
 await fundProvider(env.DB,{id:'fund',providerId:'openai',amountMicros:10000,referenceId:'fund',nowMs:NOW});
 await reserve(env.DB,{id:'r',userId:'u',providerId:'openai',amountMicros:100,requestKey:'r',nowMs:NOW});
 await freezeMembership(env,'owner','u',freezeInput,runtime);
 assert.equal(await claimReservation(env.DB,'r',NOW),false);
 await settle(env.DB,{reservationId:'r',actualMicros:25,nowMs:NOW});
 assert.equal((await getWallet(env.DB,'u',NOW)).consumedMicros,25);
});

test('paid freeze does not claim success until Stripe collection is paused and old invoices are clear',async()=>{
 await paidMembership();failPause=true;
 const pending=await freezeMembership(env,'owner','u',freezeInput,runtime);assert.equal(pending.freeze?.state,'pending_billing_change');assert.equal(pending.freeze?.frozen,false);
 assert.equal((await activeSubscription(env.DB,'u',ISO))?.source,'paid');assert.equal(await canTopup(env.DB,'u',ISO),true);
 failPause=false;openInvoice=true;
 const invoicePending=await freezeMembership(env,'owner','u',freezeInput,runtime);assert.equal(invoicePending.freeze?.state,'pending_billing_change');assert.equal(invoicePending.freeze?.errorCode,'BILLING_INVOICE_REVIEW');
 openInvoice=false;
 const frozen=await freezeMembership(env,'owner','u',freezeInput,runtime);assert.equal(frozen.freeze?.state,'frozen');
 assert.equal(provider.pause_collection.behavior,'void');assert.equal(await canTopup(env.DB,'u',ISO),false);
});

test('paid unfreeze moves the next charge beyond compensated paid time and failures keep membership frozen',async()=>{
 await paidMembership();await freezeMembership(env,'owner','u',freezeInput,runtime);runtime.nowMs=NOW+10*DAY;failResume=true;
 const pending=await unfreezeMembership(env,'owner','u',unfreezeInput,runtime);assert.equal(pending.freeze?.state,'pending_unfreeze');
 assert.equal((await getWallet(env.DB,'u',runtime.nowMs)).availableMicros,0);
 failResume=false;runtime.nowMs=NOW+12*DAY;
 const done=await unfreezeMembership(env,'owner','u',unfreezeInput,runtime);assert.equal(done.freeze?.state,'completed');assert.equal(done.freeze?.compensatedMs,12*DAY);
 assert.equal(provider.pause_collection,null);assert.equal(provider.trial_end,(NOW+40*DAY)/1000);
 assert.equal((await activeSubscription(env.DB,'u',new Date(runtime.nowMs).toISOString()))?.ends_at,new Date(NOW+40*DAY).toISOString());
 assert.equal((await getWallet(env.DB,'u',runtime.nowMs)).subscriptionMicros,16_250_000);
 assert(requests.some(r=>r.params.get('proration_behavior')==='none'));
});

test('account permission restrictions remain independent of membership time suspension',async()=>{
 await giftMembership(env,'owner','u',{...giftInput,months:1},runtime);
 database.sqlite.prepare("INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,actor_id,created_at) VALUES('login-freeze','u','login','登录限制',?,'owner',?)").run(ISO,ISO);
 const before=(await activeSubscription(env.DB,'u',ISO))!.ends_at;
 runtime.nowMs=NOW+2*DAY;
 assert.equal((await activeSubscription(env.DB,'u',new Date(runtime.nowMs).toISOString()))!.ends_at,before);
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM membership_freezes').get()!.count,0);
});

test('member cannot gift themselves and owner/current account cannot be frozen',async()=>{
 await assert.rejects(giftMembership(env,'u','u',giftInput,runtime));
 await assert.rejects(freezeMembership(env,'owner','owner',freezeInput,runtime));
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM membership_gifts').get()!.count,0);
});

test('concurrent gift deliveries and unfreeze retries do not duplicate credits or compensated time',async()=>{
 await Promise.all([giftMembership(env,'owner','u',giftInput,runtime),giftMembership(env,'owner','u',giftInput,runtime)]);
 assert.equal(database.sqlite.prepare('SELECT COUNT(*) AS count FROM credit_grants').get()!.count,2);
 await freezeMembership(env,'owner','u',freezeInput,runtime);runtime.nowMs=NOW+DAY;
 await Promise.all([unfreezeMembership(env,'owner','u',unfreezeInput,runtime),unfreezeMembership(env,'owner','u',unfreezeInput,runtime)]);
 assert.equal(database.sqlite.prepare('SELECT compensated_ms FROM membership_freezes').get()!.compensated_ms,DAY);
 assert.equal(database.sqlite.prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action='member.unfreeze'").get()!.count,1);
});

test('replaying a previous unfreeze request cannot thaw a later independent freeze',async()=>{
 await giftMembership(env,'owner','u',giftInput,runtime);await freezeMembership(env,'owner','u',freezeInput,runtime);
 runtime.nowMs=NOW+DAY;await unfreezeMembership(env,'owner','u',unfreezeInput,runtime);
 runtime.nowMs=NOW+2*DAY;await freezeMembership(env,'owner','u',{...freezeInput,requestKey:'second-freeze-operation'},runtime);
 const result=await unfreezeMembership(env,'owner','u',unfreezeInput,runtime);
 assert.equal(result.freeze?.state,'frozen');assert.equal((await getWallet(env.DB,'u',runtime.nowMs)).availableMicros,0);
});

test('lost commit acknowledgement during unfreeze returns committed state without a second extension',async()=>{
 await giftMembership(env,'owner','u',giftInput,runtime);await freezeMembership(env,'owner','u',freezeInput,runtime);runtime.nowMs=NOW+DAY;
 const original=database.batch.bind(database);let injected=false;
 (database as unknown as {batch:(statements:any[])=>Promise<any>}).batch=async statements=>{const result=await original(statements);if(!injected){injected=true;throw new Error('Lost commit acknowledgement');}return result;};
 const result=await unfreezeMembership(env,'owner','u',unfreezeInput,runtime);assert.equal(result.freeze?.state,'completed');
 await unfreezeMembership(env,'owner','u',unfreezeInput,{...runtime,nowMs:NOW+2*DAY});
 assert.equal(database.sqlite.prepare('SELECT compensated_ms FROM membership_freezes').get()!.compensated_ms,DAY);
});
