import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash,createHmac } from 'node:crypto';
import { TestD1,testEnv } from './d1-helper';
import { saveVersion } from '../src/modules/ai';
import { starterManifest } from '../src/contracts/starter-library';
import { encryptSecret } from '../src/lib/crypto';
import { ensureCmsBundleTransfer,advanceCmsBundleTransfer,discardCmsBundleTransfer } from '../src/modules/cms-transfers';
import { runPublicationOperation,continuePublicationPreparations } from '../src/modules/publishing';
import type { CmsBundleState } from '../src/lib/cms-bundle';

const MIB=1048576,user='review-user',project='prj_'+'c'.repeat(32),site='site_'+'c'.repeat(32);
const digest=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
class Storage {
 objects=new Map<string,Uint8Array>();afterRange:(()=>void|Promise<void>)|null=null;
 async put(key:string,bytes:Uint8Array){this.objects.set(key,bytes.slice());return {key};}
 async head(key:string){const b=this.objects.get(key);return b?{size:b.length,etag:digest(b)}:null;}
 async get(key:string,options?:any){const b=this.objects.get(key);if(!b)return null;const etag=digest(b);if(options?.onlyIf?.etagMatches!==undefined&&options.onlyIf.etagMatches!==etag)return {size:b.length,etag};const out=options?.range?b.slice(options.range.offset,options.range.offset+options.range.length):b;if(options?.range&&this.afterRange)await this.afterRange();return {size:b.length,etag,body:true,arrayBuffer:async()=>out.slice().buffer};}
}
async function fixture(){
 const db=new TestD1(),env=testEnv(db),storage=new Storage();env.BUCKET=storage as unknown as R2Bucket;const now=new Date().toISOString();
 db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,status,created_at,updated_at) VALUES(?,'review-transfer@example.test','Review','unused','active',?,?)").run(user,now,now);db.sqlite.prepare("INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES(?,?,'Review',?,?)").run(project,user,now,now);
 const manifest=starterManifest('studio')!;manifest.templates[0].document.css+='/*'+'x'.repeat(2*MIB)+'*/';const version=await saveVersion(env,user,project,manifest,'manual',null,'review-version-save');
 db.sqlite.prepare("INSERT INTO sites(id,user_id,project_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,?,?,'Review','review.example.com','cms@example.test','connected',?,?)").run(site,user,project,now,now);
 db.sqlite.prepare("INSERT INTO hosting_entitlements(id,user_id,site_id,source,starts_at,ends_at,state,created_at) VALUES('review-hosting',?,?,'annual',?,?,'active',?)").run(user,site,now,new Date(Date.now()+86400000).toISOString(),now);
 db.sqlite.prepare("INSERT INTO site_connections(id,site_id,origin,key_id,secret_ciphertext,cms_version,last_verified_at,created_at,updated_at) VALUES('review-connection',?,'https://review.example.com','review-key',?,'1.9.21',?,?,?)").run(site,await encryptSecret('review-secret-with-at-least-thirty-two-bytes',env.ENCRYPTION_KEY,site),now,now,now);
 return {db,env,storage,version};
}
function receiver(){
 let state:CmsBundleState|null=null;const operations:string[]=[];let terminal:'expired'|'discarded'|null=null,pinned=false;
 const send=async(_credentials:unknown,input:any,_key:string)=>{
  if(input instanceof Uint8Array){operations.push('chunk');const length=new DataView(input.buffer,input.byteOffset).getUint32(4,false),header=JSON.parse(new TextDecoder().decode(input.subarray(8,8+length))),file=state!.files.find(f=>f.file===header.file)!;assert.equal(header.offset,file.received);file.received+=header.size;}
  else{operations.push(input.operation);if(input.operation==='bundle-status'&&!state)return {status:404,data:{}};if(input.operation==='bundle-begin'){const files=[input.manifest,...input.assets];state={protocol:'benos-bundle-v2',bundleId:input.bundleId,siteId:site,purpose:input.purpose,projectId:input.projectId,versionId:input.versionId,state:'receiving',expiresAt:input.expiresAt,expired:false,pinned:false,chunkBytes:MIB,zipBytes:22+files.reduce((n:number,f:any)=>n+f.size+76+2*f.file.length,0),zipSha256:null,nativeValidated:false,files:files.map(f=>({...f,received:0}))};}if(input.operation==='bundle-seal'){state!.state='sealed';state!.zipSha256='f'.repeat(64);}}
  if(input.operation==='bundle-discard')state!.state='discarded';
  const response=structuredClone(state)!;response.pinned=pinned;if(terminal){response.state=terminal;response.expired=terminal==='expired';}return {status:200,data:response};
 };return {send,operations,end(value:'expired'|'discarded'){terminal=value;},pin(){pinned=true;}};
}

test('permission revoked during the awaited R2 range read stops that outgoing chunk',async()=>{
 const f=await fixture(),remote=receiver();try{
  const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-revoked-in-read','publish');
  f.storage.afterRange=()=>{f.db.sqlite.prepare("UPDATE users SET status='restricted' WHERE id=?").run(user);};
  const result=await advanceCmsBundleTransfer(f.env,user,task.id,{send:remote.send});assert.equal(result.errorCode,'ACCOUNT_RESTRICTED');assert.equal(remote.operations.filter(x=>x==='chunk').length,0,'must recheck authorization after awaited source read and before sending private bytes');
 }finally{f.db.close();}
});

test('expired or replaced lease during a range read cannot send another chunk or clear the replacement lease',async()=>{
 const f=await fixture(),remote=receiver();try{
  let at=Date.now();const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-replaced-lease','publish',at);
  f.storage.afterRange=()=>{at+=151000;f.db.sqlite.prepare('UPDATE cms_bundle_transfers SET lease_token=?,lease_until_ms=? WHERE id=?').run('replacement-owner',at+150000,task.id);};
  await advanceCmsBundleTransfer(f.env,user,task.id,{send:remote.send,now:()=>at});assert.equal(remote.operations.filter(x=>x==='chunk').length,0,'stale holder must not send after lease takeover');assert.equal(f.db.sqlite.prepare('SELECT lease_token FROM cms_bundle_transfers WHERE id=?').get(task.id)!.lease_token,'replacement-owner');
 }finally{f.db.close();}
});

test('signed remote discarded or expired state becomes terminal locally and never sends more private bytes',async()=>{
 for(const terminal of ['discarded','expired'] as const){const f=await fixture(),remote=receiver();try{
  const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-remote-'+terminal,'publish');remote.end(terminal);const result=await advanceCmsBundleTransfer(f.env,user,task.id,{send:remote.send});assert.equal(result.state,terminal,'remote terminal outcome must not remain retrying pending');assert.equal(remote.operations.filter(x=>x==='chunk').length,0);
 }finally{f.db.close();}}
});

test('transport sealing only stages a bundle; it never performs publication prepare, commit or import',async()=>{
 const f=await fixture(),remote=receiver();try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-no-auto-commit','publish');let result;for(let n=0;n<3;n++){result=await advanceCmsBundleTransfer(f.env,user,task.id,{send:remote.send});if(result.sealed)break;}assert.equal(result?.sealed,true);assert.ok(remote.operations.every(x=>['bundle-status','bundle-begin','chunk','bundle-seal'].includes(x)));assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM publication_releases').get()!.n,0);assert.equal(f.db.sqlite.prepare('SELECT published_version_id FROM projects').get()!.published_version_id,null);}finally{f.db.close();}
});

test('connection key rotation during a source read prevents sending that chunk with stale credentials',async()=>{
 const f=await fixture(),remote=receiver();try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-connection-rotate','publish');f.storage.afterRange=()=>{f.db.sqlite.prepare("UPDATE site_connections SET key_id='rotated-key' WHERE site_id=?").run(site);};const result=await advanceCmsBundleTransfer(f.env,user,task.id,{send:remote.send});assert.equal(result.errorCode,'CMS_CONNECTION_CHANGED');assert.equal(remote.operations.filter(x=>x==='chunk').length,0);}finally{f.db.close();}
});

test('discard preserves a remotely pinned bundle, but confirms a receiving bundle as cancelled',async()=>{
 for(const pinned of [false,true]){const f=await fixture(),remote=receiver();try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-discard-'+pinned,'publish');await advanceCmsBundleTransfer(f.env,user,task.id,{send:remote.send});if(pinned)remote.pin();const result=await discardCmsBundleTransfer(f.env,user,task.id,{send:remote.send});assert.equal(result.state,pinned?'transferring':'discarded');assert.equal(result.errorCode,pinned?'CMS_BUNDLE_IN_USE':null);assert.equal(remote.operations.filter(x=>x==='bundle-discard').length,pinned?0:1);}finally{f.db.close();}}
});

function releaseFixture(f:Awaited<ReturnType<typeof fixture>>,transferId:string){const release='rel_'+'c'.repeat(32),now=new Date().toISOString();f.db.sqlite.prepare("INSERT INTO publication_releases(id,site_id,user_id,project_id,version_id,idempotency_key,payload_hash,state,bundle_transfer_id,created_at,updated_at) VALUES(?,?,?,?,?,'review-publication','review-hash','preparing',?,?,?)").run(release,site,user,project,f.version,transferId,now,now);return release;}
async function signedResponse(request:Request,status:number,data:unknown){const text=JSON.stringify(data),at=String(Math.floor(Date.now()/1000)),protocol=request.url.endsWith('/benos-bundle.php')?'BENOS-CMS-BUNDLE-V2-RESPONSE':'BENOS-CMS-V1-RESPONSE',signature=createHmac('sha256','review-secret-with-at-least-thirty-two-bytes').update([protocol,request.headers.get('X-Benos-Nonce'),String(status),at,digest(Buffer.from(text))].join('\n')).digest('base64url');return new Response(text,{status,headers:{'X-Benos-Timestamp':at,'X-Benos-Signature':signature}});}

test('publication lease takeover after status prevents prepare and cannot overwrite the new lease',async()=>{
 const f=await fixture(),receiverMock=receiver(),original=globalThis.fetch;try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-release-takeover','publish');for(let i=0;i<3;i++)if((await advanceCmsBundleTransfer(f.env,user,task.id,{send:receiverMock.send})).sealed)break;const release=releaseFixture(f,task.id),operations:string[]=[];globalThis.fetch=async(input,init)=>{const request=new Request(input,init),body=await request.json() as any;operations.push(body.operation);if(body.operation==='status'){f.db.sqlite.prepare('UPDATE publication_releases SET lease_token=?,lease_until=? WHERE id=?').run('replacement-publication',new Date(Date.now()+240000).toISOString(),release);return signedResponse(request,404,{});}return signedResponse(request,200,{id:release,projectId:project,versionId:f.version,state:'prepared',reviewHash:'a'.repeat(64),summary:{createPages:3,updatePages:0,preserveArticles:0,preserveDrafts:true,replaceGlobalTheme:true,removePages:0}});};await runPublicationOperation(f.env,user,release,'prepare');assert.deepEqual(operations,['status']);assert.equal(f.db.sqlite.prepare('SELECT lease_token FROM publication_releases WHERE id=?').get(release)!.lease_token,'replacement-publication');assert.equal(f.db.sqlite.prepare('SELECT published_version_id FROM projects').get()!.published_version_id,null);}finally{globalThis.fetch=original;f.db.close();}
});

test('cancel during publication transfer survives lost discard acknowledgement and never auto commits',async()=>{
 const f=await fixture(),receiverMock=receiver(),original=globalThis.fetch;try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-publication-cancel','publish');await advanceCmsBundleTransfer(f.env,user,task.id,{send:receiverMock.send});const release=releaseFixture(f,task.id),operations:string[]=[];let loseAck=true;globalThis.fetch=async(input,init)=>{const request=new Request(input,init),body=await request.json() as any;operations.push(body.operation);if(request.url.endsWith('/benos-connect.php'))return signedResponse(request,404,{});const result=await receiverMock.send({},body,'test');if(body.operation==='bundle-discard'&&loseAck){loseAck=false;throw new Error('fixture lost response after remote discard');}return signedResponse(request,result.status,result.data);};await runPublicationOperation(f.env,user,release,'discard');assert.equal(f.db.sqlite.prepare('SELECT state FROM publication_releases WHERE id=?').get(release)!.state,'uncertain');await runPublicationOperation(f.env,user,release,'discard');const result=f.db.sqlite.prepare('SELECT state,error_code FROM publication_releases WHERE id=?').get(release)!;assert.equal(result.state,'failed');assert.equal(result.error_code,'PUBLICATION_DISCARDED');assert.equal(operations.filter(x=>x==='bundle-discard').length,1);assert.ok(!operations.some(x=>['prepare','commit','import'].includes(x)));assert.deepEqual(await continuePublicationPreparations(f.env),{continued:0,failed:0});assert.equal(f.db.sqlite.prepare('SELECT published_version_id FROM projects').get()!.published_version_id,null);}finally{globalThis.fetch=original;f.db.close();}
});

test('a sealed bundle past its immutable expiry cannot remain usable for a new remote preparation',async()=>{
 const f=await fixture(),remote=receiver();try{const task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-sealed-expiry','publish');let current;for(let i=0;i<3;i++){current=await advanceCmsBundleTransfer(f.env,user,task.id,{send:remote.send});if(current.sealed)break;}assert.equal(current?.sealed,true);remote.end('expired');const expired=await advanceCmsBundleTransfer(f.env,user,task.id,{send:remote.send,now:()=>Date.parse(task.expiresAt)+1});assert.equal(expired.state,'expired','an expired staged bundle must not claim it can still prepare a new release');assert.equal(expired.sealed,false);}finally{f.db.close();}
});

test('an existing signed remote preparation pin resumes its original release after bundle TTL without auto commit',async()=>{
 const f=await fixture(),receiverMock=receiver(),original=globalThis.fetch;try{const at=Date.now()-2*86400000,task=await ensureCmsBundleTransfer(f.env,user,site,f.version,'review-existing-expired-pin','publish',at);let view;for(let i=0;i<3;i++){view=await advanceCmsBundleTransfer(f.env,user,task.id,{send:receiverMock.send,now:()=>at});if(view.sealed)break;}assert.equal(view?.sealed,true);const release=releaseFixture(f,task.id),operations:string[]=[];globalThis.fetch=async(input,init)=>{const request=new Request(input,init);assert.ok(request.url.endsWith('/benos-connect.php'),'must reconcile the existing CMS release, not discard its pinned source');const body=await request.json() as any;operations.push(body.operation);const result={id:release,projectId:project,versionId:f.version,state:body.operation==='status'?'preparing':'prepared'};if(body.operation==='prepare'){assert.equal(body.bundleId,task.id);Object.assign(result,{reviewHash:'a'.repeat(64),summary:{createPages:3,updatePages:0,preserveArticles:0,preserveDrafts:true,replaceGlobalTheme:true,removePages:0}});}return signedResponse(request,200,result);};await runPublicationOperation(f.env,user,release,'prepare');assert.deepEqual(operations,['status','prepare']);assert.equal(f.db.sqlite.prepare('SELECT state FROM publication_releases WHERE id=?').get(release)!.state,'prepared');assert.equal(f.db.sqlite.prepare('SELECT published_version_id FROM projects').get()!.published_version_id,null);}finally{globalThis.fetch=original;f.db.close();}
});
