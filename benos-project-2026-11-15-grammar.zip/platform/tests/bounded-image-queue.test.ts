import test from 'node:test';
import assert from 'node:assert/strict';
import { boundedImageQueue } from '../src/lib/bounded-image-queue';

function deferred<T = void>() {
 let resolve!: (value: T | PromiseLike<T>) => void;
 const promise = new Promise<T>(done => { resolve = done; });
 return { promise, resolve };
}
async function until(predicate: () => boolean, label: string) {
 for (let turn = 0; turn < 100 && !predicate(); turn++) await Promise.resolve();
 assert.ok(predicate(), label);
}

for (const concurrency of [3, 4]) test(`image queue caps active work at ${concurrency}, preserves input order and continues past a rejection`, async () => {
 const count = 8, gates = Array.from({ length: count }, () => deferred()), started: number[] = [], finished: number[] = [];
 let active = 0, peak = 0, checks = 0;
 const failure = new Error('one provider image failed');
 const pending = boundedImageQueue(count, concurrency, async () => { checks++; }, async index => {
  started.push(index); active++; peak = Math.max(peak, active);
  try { await gates[index].promise; if (index === 4) throw failure; return `image-${index}`; }
  finally { active--; finished.push(index); }
 });
 await until(() => started.length === concurrency, 'initial bounded batch');
 assert.equal(active, concurrency); assert.equal(checks, concurrency);
 // Keep the early tasks running while later indices finish and replenish slots.
 const released = new Set<number>();
 while (released.size < count) {
  const index = Math.max(...started.filter(value => !released.has(value)));
  assert.ok(Number.isFinite(index)); released.add(index); gates[index].resolve();
  await until(() => finished.includes(index), 'released image settles');
  if (started.length < count) await until(() => started.length > index + 1, 'free slot dispatches another image');
 }
 const results = await pending;
 assert.equal(peak, concurrency); assert.equal(active, 0); assert.equal(checks, count);
 assert.deepEqual(started, [0, 1, 2, 3, 4, 5, 6, 7]);
 assert.notDeepEqual(finished, started, 'fixture really completed out of order');
 assert.equal(results.length, count);
 for (let index = 0; index < count; index++) assert.deepEqual(results[index], index === 4 ? { status: 'rejected', reason: failure } : { status: 'fulfilled', value: `image-${index}` });
});

test('a lost lease stops future dispatch, including an already waiting check, and awaits active image settlement', async () => {
 const first = deferred(), second = deferred(), pendingCheck = deferred(), started: number[] = [];
 let checks = 0, settled = false;
 const lost = new Error('WORKFLOW_LEASE_LOST');
 const running = boundedImageQueue(8, 3, async () => {
  const check = checks++;
  if (check === 2) await pendingCheck.promise;
  if (check >= 3) throw lost;
 }, async index => { started.push(index); await (index === 0 ? first.promise : second.promise); return index; });
 void running.then(() => { settled = true; }, () => { settled = true; });
 await until(() => started.length === 2 && checks === 3, 'two dispatched and one lease check waiting');
 first.resolve(); await until(() => checks === 4, 'new dispatch detects the lost lease');
 pendingCheck.resolve();
 for (let turn = 0; turn < 10; turn++) await Promise.resolve();
 assert.deepEqual(started, [0, 1], 'a late successful lease check cannot revive the stopped queue');
 assert.equal(settled, false, 'already dispatched second image remains awaited');
 second.resolve(); await assert.rejects(running, error => error === lost);
 assert.equal(checks, 4); assert.deepEqual(started, [0, 1]);
});

test('initial lease failure dispatches nothing and an empty queue performs no checks', async () => {
 let calls = 0; const lost = new Error('expired');
 await assert.rejects(boundedImageQueue(8, 4, async () => { throw lost; }, async () => { calls++; }), error => error === lost);
 assert.equal(calls, 0);
 assert.deepEqual(await boundedImageQueue(0, 4, async () => { calls++; }, async () => { calls++; }), []);
 assert.equal(calls, 0);
});

test('invalid queue bounds are rejected before checks or dispatch', async () => {
 for (const [count, concurrency] of [[-1, 3], [1.5, 3], [8, 0], [8, 5], [8, 1.5], [Number.NaN, 3]]) {
  let calls = 0;
  await assert.rejects(boundedImageQueue(count, concurrency, async () => { calls++; }, async () => { calls++; }), RangeError);
  assert.equal(calls, 0);
 }
});
