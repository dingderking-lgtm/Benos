import { sha256 } from '../src/lib/crypto';
/** Explicit local fixture evidence for unrelated generation tests. This helper
 * is never imported by production code and never invokes a real provider. */
export async function seedCapabilityFixture(db:D1Database,configId:string){
 const config=await db.prepare('SELECT id,kind,provider,public_config_json,created_by FROM integration_configs WHERE id=?').bind(configId).first<{id:string;kind:string;provider:string;public_config_json:string;created_by:string}>();if(!config)throw new Error('Missing fixture config');
 const now=new Date().toISOString(),pricing=JSON.parse(config.public_config_json),testId='fixture_test_'+configId;
 await db.prepare(`INSERT INTO integration_function_tests(id,config_id,actor_id,provider_id,request_key,payload_hash,quote_hash,config_fingerprint,state,accounting_state,reserved_micros,actual_micros,request_json,pricing_json,response_json,created_at,updated_at,completed_at)
 VALUES(?,?,?,?,?,?,?,?,'passed','settled',1,0,'{}',?,'{"fixture":true}',?,?,?)`).bind(testId,config.id,config.created_by,pricing.providerPoolId,testId,'fixture','fixture',await sha256(JSON.stringify([config.id,config.kind,config.provider,config.public_config_json])),config.public_config_json,now,now,now).run();
 await db.prepare('UPDATE integration_configs SET capability_test_id=?,capability_tested_at=? WHERE id=?').bind(testId,now,config.id).run();
}
