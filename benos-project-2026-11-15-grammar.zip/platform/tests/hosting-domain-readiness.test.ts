import assert from 'node:assert/strict';
import test from 'node:test';
import { ensureInitialHostingHttps,normalizedHostingIp } from '../src/modules/hosting-domain-readiness';
import { ensureHostedSiteDnsTargets,readHostingDnsTargets } from '../src/modules/hosting-dns-targets';
import { TestD1,testEnv } from './d1-helper';

const config={adapter:'hostinger-hpanel' as const,deploymentMode:'hostinger-tus-bootstrap' as const,hostingOrderId:100,accountUsername:'u12345678'};
const job={id:'job_https',siteId:'site_https',domain:'customer.example.com',leaseToken:'current-lease'};
const token='private-fixture-token';
function fixture(){
 const db=new TestD1(),env=testEnv(db),now=new Date().toISOString();
 db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES('usr','customer@example.com','Customer','x','user','active',?,?)").run(now,now);
 db.sqlite.prepare("INSERT INTO integration_configs(id,kind,provider,version,name,public_config_json,status,test_status,created_by,created_at) VALUES('cfg','hosting','benos-bridge',1,'test','{}','active','passed','usr',?)").run(now);
 db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,'usr','Customer',?,'cms@example.com','pending',?,?)").run(job.siteId,job.domain,now,now);
 db.sqlite.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,state,step,idempotency_key,payload_hash,lease_token,lease_until,created_at,updated_at) VALUES(?,?,'usr','create','running','configure_hosting','https_key','hash',?,?,?,?)").run(job.id,job.siteId,job.leaseToken,new Date(Date.now()+300000).toISOString(),now,now);
 db.sqlite.prepare("INSERT INTO hosting_pools(id,name,account_username,hosting_order_id,config_version_id,max_sites,max_databases,created_at,updated_at) VALUES('pool','Fixture','u12345678',100,'cfg',10,10,?,?)").run(now,now);
 db.sqlite.prepare("INSERT INTO hosting_allocations(job_id,site_id,pool_id,config_version_id,created_at) VALUES(?,?,'pool','cfg',?)").run(job.id,job.siteId,now);
 db.sqlite.prepare("INSERT INTO hosting_provider_intents(job_id,config_version_id,site_id,domain,account_username,hosting_order_id,website_create_attempted,website_ready,database_name,database_user,database_secret_ciphertext,database_create_attempted,database_ready,created_at,updated_at) VALUES(?,'cfg',?,?,'u12345678',100,1,1,'db','db','encrypted',1,1,?,?)").run(job.id,job.siteId,job.domain,now,now);
 db.sqlite.prepare("INSERT INTO hosting_pool_dns_targets(pool_id,records_json,actor_id,reason,confirmed_at) VALUES('pool',?,'usr','Verified hosting IP',?)").run(JSON.stringify([{type:'A',value:'93.184.216.34'}]),now);
 return {db,env};
}
function network(){
 let dnsA=['93.184.216.34'],dnsAAAA:string[]=[],status='not_installed',redirect=false,loseSetup=false,loseRedirect=false,posts=0,patches=0,gets=0;
 const handler:typeof fetch=async(input,init)=>{
  const url=new URL(String(input)),method=init?.method||'GET';
  if(url.origin==='https://cloudflare-dns.com'){
   assert.equal(new Headers(init?.headers).get('Authorization'),null);
   const type=url.searchParams.get('type')==='A'?1:28;return Response.json({Status:0,Answer:(type===1?dnsA:dnsAAAA).map(data=>({type,data}))});
  }
  assert.equal(url.origin,'https://developers.hostinger.com');assert.equal(new Headers(init?.headers).get('Authorization'),'Bearer '+token);
  if(url.pathname.startsWith('/api/dns/v1/zones/'))return new Response('{}',{status:404});
  assert.match(url.pathname,/\/accounts\/u12345678\/websites\/customer\.example\.com\/ssl\//);
  if(url.pathname.endsWith('/status')){assert.equal(method,'GET');gets++;return Response.json({status,is_https_redirect_enabled:redirect});}
  if(url.pathname.endsWith('/setup')){assert.equal(method,'POST');posts++;status='installing';if(loseSetup)throw new Error('lost acknowledgement');return Response.json({});}
  if(url.pathname.endsWith('/https-redirect/toggle')){assert.equal(method,'PATCH');patches++;assert.deepEqual(JSON.parse(String(init?.body)),{is_enabled:true});redirect=true;if(loseRedirect)throw new Error('lost acknowledgement');return Response.json({});}
  throw new Error('Unexpected endpoint');
 };
 return {handler,setDns:(a:string[],aaaa:string[]=[])=>{dnsA=a;dnsAAAA=aaaa;},setStatus:(value:string)=>status=value,loseSetup:()=>loseSetup=true,loseRedirect:()=>loseRedirect=true,counts:()=>({posts,patches,gets})};
}
test('initial SSL waits for exact DNS, persists one issuance, verifies active status and HTTPS redirect before bootstrap',async()=>{
 const f=fixture(),n=network(),original=fetch;globalThis.fetch=n.handler;
 try{
  n.setDns(['93.184.216.35']);assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).step,'verify_dns_records');assert.deepEqual(n.counts(),{posts:0,patches:0,gets:0});
  n.setDns(['93.184.216.34'],['2606:4700::1111']);assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).ready,false,'unexpected IPv6 must not be ignored');assert.equal(n.counts().gets,0);
  n.setDns(['93.184.216.34']);assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).step,'wait_https_certificate');assert.equal(n.counts().posts,1);
  assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).ready,false);assert.equal(n.counts().posts,1);
  n.setStatus('active');assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).step,'verify_https_redirect');assert.equal(n.counts().patches,1);
  assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).ready,true);assert.equal(n.counts().patches,1);assert.ok(f.db.sqlite.prepare('SELECT https_ready_at FROM hosting_provider_intents').get()!.https_ready_at);
 }finally{globalThis.fetch=original;f.db.close();}
});
test('lost SSL acknowledgement reconciles status and never blindly reissues a certificate',async()=>{
 const f=fixture(),n=network(),original=fetch;globalThis.fetch=n.handler;
 try{
  n.loseSetup();await assert.rejects(ensureInitialHostingHttps(f.env,config,token,job),/结果尚未确认/);
  assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).step,'wait_https_certificate');assert.equal(n.counts().posts,1);
  n.setStatus('not_installed');assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).state,'uncertain');assert.equal(n.counts().posts,1);
  n.setStatus('active');n.loseRedirect();await assert.rejects(ensureInitialHostingHttps(f.env,config,token,job),/结果尚未确认/);
  assert.equal((await ensureInitialHostingHttps(f.env,config,token,job)).ready,true);assert.equal(n.counts().patches,1);
 }finally{globalThis.fetch=original;f.db.close();}
});
test('missing DNS targets, immutable scope, revoked certificates and stale leases fail closed',async()=>{
 const f=fixture(),n=network(),original=fetch;globalThis.fetch=n.handler;
 try{
  await assert.rejects(ensureInitialHostingHttps(f.env,{...config,accountUsername:'u9999'},token,job),/身份不符/);assert.equal(n.counts().gets,0);
  await assert.rejects(ensureInitialHostingHttps(f.env,config,token,{...job,leaseToken:'stale'}),/接管/);assert.equal(n.counts().gets,0);
  n.setStatus('revoked');await assert.rejects(ensureInitialHostingHttps(f.env,config,token,job),/签发需要平台/);assert.equal(n.counts().posts,0);
  f.db.sqlite.prepare('DELETE FROM hosting_pool_dns_targets').run();await assert.rejects(ensureInitialHostingHttps(f.env,config,token,job),/平台核对/);assert.equal(n.counts().posts,0);
 }finally{globalThis.fetch=original;f.db.close();}
});
test('an already active certificate is not reinstalled and DNS literals cannot be private',async()=>{
 const f=fixture(),n=network(),original=fetch;globalThis.fetch=n.handler;
 try{n.setStatus('active');await ensureInitialHostingHttps(f.env,config,token,job);assert.equal(n.counts().posts,0);
  for(const ip of ['127.0.0.1','10.0.0.1','192.168.1.1','100.64.0.1','198.18.0.1','::1','2001:db8::1','::ffff:127.0.0.1'])assert.equal(normalizedHostingIp(ip),null,ip);
  assert.equal(normalizedHostingIp('2606:4700:0:0:0:0:0:1111'),'2606:4700::1111');
 }finally{globalThis.fetch=original;f.db.close();}
});
test('newly created websites discover exact official-zone targets without DNS writes or per-site operator input',async()=>{
 const f=fixture(),original=fetch,calls:string[]=[];f.db.sqlite.prepare('DELETE FROM hosting_pool_dns_targets').run();
 globalThis.fetch=async(input,init)=>{const url=new URL(String(input));calls.push(url.href);assert.equal(init?.method??'GET','GET');assert.equal(url.origin,'https://developers.hostinger.com');assert.equal(new Headers(init?.headers).get('Authorization'),'Bearer '+token);
  assert.equal(url.pathname,'/api/dns/v1/zones/'+job.domain);
  return Response.json([{type:'A',name:'@',records:[{content:'93.184.216.34',is_disabled:false},{content:'93.184.216.35',is_disabled:true}]},{type:'AAAA',name:job.domain+'.',records:[{content:'2606:4700:0:0:0:0:0:1111',is_disabled:false}]},{type:'MX',name:'@',records:[{content:'10 mail.example.com'}]},{type:'TXT',name:'@',records:[{content:'v=spf1 -all'}]},{type:'A',name:'other',records:[{content:'93.184.216.40'}]}]);
 };
 try{
  const targets=await ensureHostedSiteDnsTargets(f.env,config,token,job);assert.deepEqual(targets,[{type:'A',value:'93.184.216.34'},{type:'AAAA',value:'2606:4700::1111'}]);
  assert.deepEqual(await readHostingDnsTargets(f.env,job.siteId),{records:targets,source:'provider-zone'});
  assert.deepEqual(await ensureHostedSiteDnsTargets(f.env,config,token,job),targets);assert.equal(calls.length,1,'a durable site target is reused across retries');
  const saved=f.db.sqlite.prepare('SELECT * FROM hosting_site_dns_targets').get()!;assert.equal(saved.job_id,job.id);assert.equal(saved.source_zone,job.domain);assert.ok(!JSON.stringify(saved).includes(token));assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_pool_dns_targets').get()!.n,0,'site DNS never becomes a shared pool target');
 }finally{globalThis.fetch=original;f.db.close();}
});
test('subdomain target discovery uses an SOA-proven parent and exact record name, never wildcard or guessed apex',async()=>{
 const f=fixture(),original=fetch,calls:string[]=[];f.db.sqlite.prepare('DELETE FROM hosting_pool_dns_targets').run();
 globalThis.fetch=async(input,init)=>{const url=new URL(String(input));calls.push(url.href);assert.equal(init?.method??'GET','GET');
  if(url.origin==='https://cloudflare-dns.com'){assert.equal(new Headers(init?.headers).get('Authorization'),null);assert.equal(url.searchParams.get('type'),'SOA');return Response.json({Status:0,Authority:[{type:6,name:'example.com.',data:'nameserver soa values'}]});}
  assert.equal(url.origin,'https://developers.hostinger.com');
  if(url.pathname.endsWith('/'+job.domain))return new Response('{}',{status:404});assert.ok(url.pathname.endsWith('/example.com'));
  return Response.json([{type:'A',name:'@',records:[{content:'93.184.216.35'}]},{type:'A',name:'*',records:[{content:'93.184.216.36'}]},{type:'A',name:'customer',records:[{content:'93.184.216.34'}]}]);
 };
 try{assert.deepEqual(await ensureHostedSiteDnsTargets(f.env,config,token,job),[{type:'A',value:'93.184.216.34'}]);assert.equal(calls.length,3);assert.equal(f.db.sqlite.prepare('SELECT source_zone FROM hosting_site_dns_targets').get()!.source_zone,'example.com');}
 finally{globalThis.fetch=original;f.db.close();}
});
test('conflicting or private provider-zone records stay unresolved and never overwrite DNS',async()=>{
 for(const rows of [
  [{type:'A',name:'@',records:[{content:'127.0.0.1'}]}],
  [{type:'A',name:'@',records:[{content:'93.184.216.34'}]},{type:'CNAME',name:'@',records:[{content:'other.example.com'}]}],
  [{type:'A',name:'@',records:[{content:'93.184.216.34',is_disabled:true}]}],
  [{type:'A',name:'www',records:[{content:'93.184.216.34'}]}],
 ]){
  const f=fixture(),original=fetch;f.db.sqlite.prepare('DELETE FROM hosting_pool_dns_targets').run();
  globalThis.fetch=async(_input,init)=>{assert.equal(init?.method??'GET','GET');return Response.json(rows);};
  try{await assert.rejects(ensureHostedSiteDnsTargets(f.env,config,token,job),/未取得/);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_site_dns_targets').get()!.n,0);}
  finally{globalThis.fetch=original;f.db.close();}
 }
});
test('target discovery rejects wrong scope or lost lease, and explicit pool correction wins over prior automatic targets',async()=>{
 const f=fixture(),original=fetch;f.db.sqlite.prepare('DELETE FROM hosting_pool_dns_targets').run();let calls=0;
 globalThis.fetch=async()=>{calls++;return Response.json([{type:'A',name:'@',records:[{content:'93.184.216.34'}]}]);};
 try{
  await assert.rejects(ensureHostedSiteDnsTargets(f.env,{...config,accountUsername:'u9999'},token,job),/身份不符/);assert.equal(calls,0);
  await ensureHostedSiteDnsTargets(f.env,config,token,job);
  f.db.sqlite.prepare("INSERT INTO hosting_pool_dns_targets(pool_id,records_json,actor_id,reason,confirmed_at) VALUES('pool',?,'usr','Operator corrected host IP',?)").run(JSON.stringify([{type:'A',value:'93.184.216.99'}]),new Date().toISOString());
  assert.deepEqual(await readHostingDnsTargets(f.env,job.siteId),{records:[{type:'A',value:'93.184.216.99'}],source:'operator'});
  f.db.sqlite.prepare('DELETE FROM hosting_site_dns_targets').run();f.db.sqlite.prepare('DELETE FROM hosting_pool_dns_targets').run();
  globalThis.fetch=async()=>{f.db.sqlite.prepare("UPDATE provisioning_jobs SET lease_token='replacement'").run();return Response.json([{type:'A',name:'@',records:[{content:'93.184.216.34'}]}]);};
  await assert.rejects(ensureHostedSiteDnsTargets(f.env,config,token,job),/接管/);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM hosting_site_dns_targets').get()!.n,0);
 }finally{globalThis.fetch=original;f.db.close();}
});
