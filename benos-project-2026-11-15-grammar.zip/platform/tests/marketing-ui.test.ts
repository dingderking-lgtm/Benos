// Public marketing pages (P7.1): catalogue-driven prices, the paused state, account links, CSP-safe markup,
// and the rule that drafts and unpublished entries never render.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync,existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';
import { createCatalogVersion,activateCatalog,BUILTIN_CATALOG_ID,DEFAULT_CATALOG } from '../src/modules/billing-catalog';

async function fixture(){
 const db=new TestD1(),env=testEnv(db),headers:Record<string,string>={origin:env.APP_ORIGIN,'content-type':'application/json'};
 const boot=await app.request('/api/bootstrap',{method:'POST',headers,body:JSON.stringify({token:env.BOOTSTRAP_TOKEN,email:'marketing-owner@example.test',password:'marketing-owner-password',name:'Owner'})},env),auth=await boot.json() as any;
 assert.equal(boot.status,201);headers.cookie=boot.headers.get('set-cookie')!.split(';')[0];headers['x-csrf-token']=auth.data.csrfToken;
 const owner=db.sqlite.prepare('SELECT id FROM users').get()!.id as string;
 const request=(path:string,method='GET',data?:unknown)=>app.request(path,{method,headers,body:data===undefined?undefined:JSON.stringify(data)},env);
 // Anonymous visitor: no cookie, no CSRF token.
 const visit=(path:string)=>app.request(path,{},env);
 const page=async(path:string,status=200)=>{const response=await visit(path);assert.equal(response.status,status,path);return {response,html:await response.text()};};
 const create=async(kind:string,slug:string,title:string,content:Record<string,unknown>={body:'正文'})=>{const response=await request('/api/admin/content','POST',{kind,slug,title,content});assert.equal(response.status,201,await response.clone().text());return (await response.json() as any).data;};
 const act=async(row:any,action:'publish'|'unpublish')=>{const response=await request('/api/admin/content/'+row.id+'/'+action,'POST',{revision:row.revision});assert.equal(response.status,200,await response.clone().text());return (await response.json() as any).data;};
 const publish=async(kind:string,slug:string,title:string,content:Record<string,unknown>={body:'正文'})=>act(await create(kind,slug,title,content),'publish');
 return {db,env,owner,request,visit,page,create,act,publish};
}
const text=(html:string)=>html.replace(/<script[\s\S]*?<\/script>/g,' ').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ');

test('missing policies have an explicit noindex 503 state, while unrelated missing pages stay 404',async()=>{
 const f=await fixture();try{
  f.env.APP_ENV='production';f.env.APP_ORIGIN='https://policy.example.test';f.env.INDEXING_ENABLED='true';
  for(const [slug,title] of [['terms','服务条款'],['privacy','隐私说明']]){
   const {response,html}=await f.page('/pages/'+slug,503);
   assert.match(html,new RegExp('<h1>'+title+'尚未发布</h1>'));assert.ok(html.includes('已有账号，前往登录'));
   assert.equal(response.headers.get('cache-control'),'no-store');assert.equal(response.headers.get('x-robots-tag'),'noindex,nofollow');
   assert.ok(html.includes('<meta name="robots" content="noindex,nofollow">'));assert.ok(!html.includes('mailto:'));assert.ok(!html.includes('联系运营方</a>'));
   assertCspSafe(html,'/pages/'+slug);
  }
  await f.page('/pages/unrelated-missing',404);
 }finally{f.db.close();}
});

test('policy pages show only nonempty published operator content and stop rendering after withdrawal',async()=>{
 const f=await fixture();try{
  let terms=await f.create('page','terms','服务条款',{body:'PRIVATE DRAFT POLICY'});
  assert.ok(!(await f.page('/pages/terms',503)).html.includes('PRIVATE DRAFT POLICY'));
  terms=await f.act(terms,'publish');assert.ok((await f.page('/pages/terms')).html.includes('PRIVATE DRAFT POLICY'));
  const update=await f.request('/api/admin/content/'+terms.id,'PATCH',{kind:'page',slug:'terms-new-draft',title:'新草稿标题',content:{body:'UNPUBLISHED REPLACEMENT'},revision:terms.revision});
  assert.equal(update.status,200);terms=(await update.json() as any).data;
  const published=(await f.page('/pages/terms')).html;assert.ok(published.includes('PRIVATE DRAFT POLICY'));assert.ok(!published.includes('UNPUBLISHED REPLACEMENT'));
  terms=await f.act(terms,'unpublish');assert.ok(!(await f.page('/pages/terms',503)).html.includes('PRIVATE DRAFT POLICY'));
  const privacy=await f.publish('page','privacy','隐私说明',{body:' \n\t　'});assert.ok(!(await f.page('/pages/privacy',503)).html.includes('mk-prose'));
  assert.ok(privacy.id);
 }finally{f.db.close();}
});
// The slice of the plans section that belongs to one card (from its heading to the next card).
const card=(html:string,title:string)=>{const start=html.indexOf(`<h3>${title}</h3>`);assert.ok(start>0,'card '+title);const end=html.indexOf('</article>',start);return html.slice(start,end);};
function assertCspSafe(html:string,path:string){
 assert.ok(!/\sstyle\s*=/.test(html),path+': inline style attribute');
 assert.ok(!/<style[\s>]/i.test(html),path+': <style> block');
 assert.ok(!/\son[a-z]+\s*=\s*["']/i.test(html),path+': inline event handler');
 // The only script element allowed is a non-executable JSON-LD data block.
 for(const match of html.matchAll(/<script\b([^>]*)>/gi))assert.match(match[1],/^ type="application\/ld\+json"$/,path+': executable script');
 assert.ok(!/javascript:/i.test(html),path+': javascript: URL');
 // Nothing is loaded from another host: stylesheets, images, fonts and icons are same-origin paths.
 for(const match of html.matchAll(/<(?:link|img|source)\b[^>]*?\b(?:href|src|srcset)="([^"]+)"/gi)){const target=match[1];if(/rel="canonical"/.test(match[0]))continue;assert.ok(target.startsWith('/')&&!target.startsWith('//'),path+': external resource '+target);}
 assert.equal((html.match(/<link rel="stylesheet"/g)||[]).length,1,path+': exactly one stylesheet');
 assert.ok(html.includes('<link rel="stylesheet" href="/styles/marketing.css">'),path);
}

test('home prices and plan facts come from the active catalogue, never from the page source',async()=>{
 const f=await fixture();try{
  let {html,response}=await f.page('/home');
  // Legacy USD prices must never be silently relabelled as CNY. No CNY prices
  // have been published yet, so only entitlement facts are shown initially.
  const go=card(html,'Go'),pro=card(html,'Pro');
  assert.ok(go.includes('<span class="mk-price-amount">待公布</span><span class="mk-price-period">/ 月</span>'));assert.ok(go.includes('每月 $16.25 AI 额度'));assert.ok(go.includes('包含 1 个网站托管'));
  assert.ok(pro.includes('<span class="mk-price-amount">待公布</span><span class="mk-price-period">/ 月</span>'));assert.ok(pro.includes('每月 $65 AI 额度'));assert.ok(pro.includes('包含 2 个网站托管'));assert.ok(pro.includes('推荐方案'));
  // Without published prices there is no purchase link. (The add-on cards for AI 额度充值 and 网站托管 are no longer on the home page.)
  assert.ok(!html.includes('>从 Go 开始</a>'));assert.ok(!html.includes('mk-addon'));assert.ok(!html.includes('mk-fineprint'));
  const enterprise=card(html,'Enterprise');assert.ok(enterprise.includes(DEFAULT_CATALOG.enterprise.description));assert.ok(enterprise.includes('定制报价'));
  assert.equal(response.headers.get('cache-control'),'no-store','prices are never cached');

  // A new catalogue version changes every figure on the page.
  const catalog=structuredClone(DEFAULT_CATALOG);catalog.go={priceCents:3900,creditMicros:25_350_000,includedSites:3};catalog.pro={priceCents:14900,creditMicros:96_850_000,includedSites:7};catalog.hosting.annualPriceCents=4800;catalog.enterprise.description='P71 企业方案说明';
  catalog.cnyPricing={goPriceCents:19900,proPriceCents:69900,hostingAnnualPriceCents:29900,minimumTopupCents:1000,topupCreditMicrosPerCnyCent:1000};
  const version=await createCatalogVersion(f.env,f.owner,{catalog,reason:'营销页价格来源验证',requestKey:'marketing-ui-catalog-01'});
  await activateCatalog(f.env,f.owner,version.id,{expectedVersionId:BUILTIN_CATALOG_ID,enabled:true,reason:'启用验证版本',confirmedFutureOrdersOnly:true});
  html=(await f.page('/home')).html;
  assert.ok(card(html,'Go').includes('<span class="mk-price-amount">¥199</span>'));assert.ok(card(html,'Go').includes('每月 ¥253.5 AI 额度'));assert.ok(card(html,'Go').includes('包含 3 个网站托管'));
  assert.ok(card(html,'Pro').includes('<span class="mk-price-amount">¥699</span>'));assert.ok(card(html,'Pro').includes('每月 ¥968.5 AI 额度'));assert.ok(card(html,'Pro').includes('包含 7 个网站托管'));
  assert.ok(card(html,'Enterprise').includes('P71 企业方案说明'));
  // The catalogue schema fixes the top-up policy (minimum and credited share), so those figures stay; they are
  // still printed from the catalogue object — see the source check at the end of this test.
  assert.ok(html.includes('到期前可主动续费，不自动扣款'));assert.ok(!html.includes('价格均为美元'));
  // None of the default membership or hosting figures survives anywhere in the document.
  for(const stale of ['$25<','$100<','$16.25','$65 ','$30<','包含 1 个','包含 2 个'])assert.ok(!html.includes(stale),'stale default '+stale);

  // Enterprise can be switched off in the catalogue; the grid then holds two membership cards.
  const closed=structuredClone(catalog);closed.enterprise.contactEnabled=false;
  const second=await createCatalogVersion(f.env,f.owner,{catalog:closed,reason:'关闭企业方案入口',requestKey:'marketing-ui-catalog-02'});
  await activateCatalog(f.env,f.owner,second.id,{expectedVersionId:version.id,enabled:true,reason:'启用无企业入口版本',confirmedFutureOrdersOnly:true});
  html=(await f.page('/home')).html;assert.ok(!html.includes('<h3>Enterprise</h3>'));assert.ok(html.includes('mk-plan-grid mk-plan-grid--two'));

  // The module source carries no price literal: every amount is read from the catalogue object.
  const source=readFileSync(resolve('src/modules/marketing.ts'),'utf8');
  assert.ok(!/\$\s?\d/.test(source.replace(/\$\{/g,'{')),'hard-coded dollar amount in marketing.ts');
  for(const literal of ['16.25','3.25','6500','2500','65%'])assert.ok(!source.includes(literal),'hard-coded catalogue value '+literal);
 }finally{f.db.close();}
});

test('a disabled catalogue shows 暂停新订购 and removes every purchase entry',async()=>{
 const f=await fixture();try{
  const priced=structuredClone(DEFAULT_CATALOG);priced.cnyPricing={goPriceCents:19900,proPriceCents:69900,hostingAnnualPriceCents:29900,minimumTopupCents:1000,topupCreditMicrosPerCnyCent:1000};
  const initial=await createCatalogVersion(f.env,f.owner,{catalog:priced,reason:'发布人民币测试价格',requestKey:'marketing-ui-priced-01'});
  await activateCatalog(f.env,f.owner,initial.id,{expectedVersionId:BUILTIN_CATALOG_ID,enabled:true,reason:'启用人民币测试价格',confirmedFutureOrdersOnly:true});
  const open=(await f.page('/home')).html;
  assert.ok(!open.includes('暂停新订购'));
  for(const label of ['从 Go 开始','选择 Pro'])assert.ok(open.includes('>'+label+'</a>'),label);
  const version=await createCatalogVersion(f.env,f.owner,{catalog:priced,reason:'暂停状态验证版本',requestKey:'marketing-ui-paused-01'});
  await activateCatalog(f.env,f.owner,version.id,{expectedVersionId:initial.id,enabled:false,reason:'暂停新订购入口',confirmedFutureOrdersOnly:true});
  const {html}=await f.page('/home');
  assert.ok(html.includes('<p class="mk-notice" role="status">'));
  for(const title of ['Go','Pro']){const part=card(html,title);assert.ok(part.includes('<span class="mk-button mk-button--disabled" aria-disabled="true">暂停新订购</span>'),title);assert.ok(!/<a class="mk-button/.test(part),title+' keeps a purchase link');}
  for(const label of ['从 Go 开始','选择 Pro'])assert.ok(!html.includes(label),label);
  // Prices stay visible for reference and still come from the catalogue.
  assert.ok(card(html,'Go').includes('<span class="mk-price-amount">¥199</span>'));
  // Re-enabling restores the entries.
  await activateCatalog(f.env,f.owner,version.id,{expectedVersionId:version.id,enabled:true,reason:'恢复新订购入口',confirmedFutureOrdersOnly:true});
  const again=(await f.page('/home')).html;assert.ok(!again.includes('暂停新订购'));assert.ok(again.includes('>从 Go 开始</a>'));
 }finally{f.db.close();}
});

test('account links reach the SPA sign-in and sign-up routes on every page type',async()=>{
 const f=await fixture();try{
  const category=await f.publish('category','news','动态'),tag=await f.publish('tag','notes','笔记');
  await f.publish('post','hello','第一篇文章',{body:'文章正文',categoryId:category.id,tagIds:[tag.id]});
  await f.publish('page','terms','服务条款',{body:'条款正文'});await f.publish('faq','first-question','第一个问题',{body:'回答'});
  for(const [path,status] of [['/home',200],['/blog',200],['/blog/hello',200],['/category/news',200],['/tag/notes',200],['/pages/terms',200],['/faq',200],['/blog/none',404]] as const){
   const {html}=await f.page(path,status);
   assert.ok(html.includes('href="/#/login"'),path+' sign-in');assert.ok(html.includes('href="/#/signup"'),path+' sign-up');
   // The old hash forms and any other hash route are gone.
   assert.ok(!/href="\/#(?!\/(?:login|signup)")/.test(html),path+': unexpected hash route');
   assert.ok(!html.includes('/#login')&&!html.includes('/#register'),path);
   // Every in-page link is a public server path, an anchor, the SPA account entry or a mail link.
   for(const match of html.matchAll(/<a\b[^>]*?\bhref="([^"]*)"/g))assert.match(match[1],/^(?:\/(?:home|blog|faq|pages|category|tag)(?:[\/?#][^"]*)?|#[a-z-]+|\/#\/(?:login|signup)|mailto:[^"]+)$/,path+': '+match[1]);
  }
  const home=(await f.page('/home')).html;
  assert.ok(home.includes('<a class="mk-button mk-button--primary mk-button--large" href="/#/signup">'));assert.ok(home.includes('<a class="mk-button mk-button--ghost mk-button--small" href="/#/login">登录</a>'));
 }finally{f.db.close();}
});

test('rendered HTML is CSP-safe: no inline styles, no executable scripts, no external resources, noindex by default',async()=>{
 const f=await fixture();try{
  const category=await f.publish('category','news','动态',{body:'分类',description:'分类说明'}),tag=await f.publish('tag','notes','笔记');
  await f.publish('post','hello','第一篇文章',{body:'第一段\n\n第二段 <b onclick="x()">不是标签</b>',description:'摘要',categoryId:category.id,tagIds:[tag.id],coverUrl:'/assets/brand/benos-mark.svg',coverAlt:'封面 "引号"'});
  await f.publish('page','terms','服务条款',{body:'条款正文'});await f.publish('faq','first-question','第一个问题',{body:'回答一\n\n回答二',position:1});
  await f.publish('banner','welcome','公告标题',{body:'公告内容',placement:'home',url:'/blog'});
  await f.publish('navigation','nav-terms','条款',{body:'',placement:'footer',url:'/pages/terms'});
  const paths:Array<[string,number]>=[['/home',200],['/blog',200],['/blog?q=%E7%AC%AC%E4%B8%80&sort=title_asc',200],['/blog?q=%22%3E%3Cscript%3Ealert(1)%3C/script%3E',200],['/blog/hello',200],['/category/news',200],['/tag/notes',200],['/pages/terms',200],['/faq',200],['/pages/none',404],['/category/none',404],['/tag/none',404]];
  for(const [path,status] of paths){
   const {response,html}=await f.page(path,status);assertCspSafe(html,path);
   const csp=response.headers.get('content-security-policy')!;
   assert.ok(csp.includes("script-src 'none'")&&csp.includes("style-src 'self'")&&csp.includes("default-src 'none'")&&!csp.includes('unsafe-inline'),path);
   assert.ok(html.includes('<meta name="robots" content="noindex,nofollow">'),path);assert.equal(response.headers.get('x-robots-tag'),'noindex,nofollow',path);
   assert.ok(html.startsWith('<!doctype html><html lang="zh-CN">'),path);assert.equal((html.match(/<h1[\s>]/g)||[]).length,1,path+': one h1');
   assert.ok(html.includes('<link rel="icon" href="/assets/brand/favicon.svg">'),path);
  }
  // User-authored text is escaped, including inside attributes and the search echo.
  const post=(await f.page('/blog/hello')).html;assert.ok(post.includes('&lt;b onclick=&quot;x()&quot;&gt;不是标签&lt;/b&gt;'));assert.ok(post.includes('alt="封面 &quot;引号&quot;"'));
  const echoed=(await f.page('/blog?q=%22%3E%3Cscript%3Ealert(1)%3C/script%3E')).html;assert.ok(echoed.includes('value="&quot;&gt;&lt;script&gt;alert(1)&lt;/script&gt;"'));assert.ok(!echoed.includes('<script>alert'));
  // Indexing opens only for the production origin with the explicit switch.
  f.env.INDEXING_ENABLED='true';assert.ok((await f.page('/home')).html.includes('content="noindex,nofollow"'),'switch alone is not enough outside production');
  f.env.APP_ENV='production';f.env.APP_ORIGIN='https://benos.example.com';
  assert.ok((await f.page('/home')).html.includes('<meta name="robots" content="index,follow">'));assert.ok((await f.page('/blog?q=x')).html.includes('content="noindex,nofollow"'),'search results stay out of the index');
  assert.ok((await f.page('/blog/none',404)).html.includes('content="noindex,nofollow"'));
 }finally{f.db.close();}
});

test('drafts, unpublished and trashed entries never render on any public page',async()=>{
 const f=await fixture();try{
  const category=await f.publish('category','live-category','公开分类'),tag=await f.publish('tag','live-tag','公开标签');
  let post=await f.publish('post','live-post','公开文章',{body:'公开正文 LIVE-BODY',categoryId:category.id,tagIds:[tag.id]});
  // Drafts of every kind, never published.
  await f.create('post','draft-post','草稿文章 DRAFT-POST-TITLE',{body:'DRAFT-POST-BODY',categoryId:category.id,tagIds:[tag.id]});
  await f.create('page','draft-page','草稿页面 DRAFT-PAGE-TITLE',{body:'DRAFT-PAGE-BODY'});
  await f.create('faq','draft-faq','草稿问答 DRAFT-FAQ-TITLE',{body:'DRAFT-FAQ-BODY',position:1});
  await f.create('category','draft-category','草稿分类 DRAFT-CATEGORY-TITLE');await f.create('tag','draft-tag','草稿标签 DRAFT-TAG-TITLE');
  await f.create('banner','draft-banner','草稿横幅 DRAFT-BANNER-TITLE',{body:'DRAFT-BANNER-BODY',placement:'home'});
  await f.create('navigation','draft-nav','草稿导航 DRAFT-NAV-TITLE',{body:'',placement:'header',url:'/pages/draft-page'});
  // Published once, then taken down.
  const retired=await f.act(await f.publish('post','retired-post','下架文章 RETIRED-TITLE',{body:'RETIRED-BODY',categoryId:category.id}),'unpublish');assert.notEqual(retired.state,'published');
  const retiredFaq=await f.act(await f.publish('faq','retired-faq','下架问答 RETIRED-FAQ',{body:'RETIRED-FAQ-BODY'}),'unpublish');assert.notEqual(retiredFaq.state,'published');
  // Published once, then moved to the recycle bin.
  const trashed=await f.publish('post','trashed-post','回收文章 TRASHED-TITLE',{body:'TRASHED-BODY'});assert.equal((await f.request('/api/admin/content/'+trashed.id,'DELETE',{revision:trashed.revision})).status,200);
  // A published post whose newer draft changes title, slug and body: only the published snapshot is public.
  const edited=await f.request('/api/admin/content/'+post.id,'PATCH',{kind:'post',slug:'renamed-post',title:'改名草稿 EDITED-DRAFT-TITLE',revision:post.revision,content:{body:'EDITED-DRAFT-BODY',categoryId:category.id,tagIds:[tag.id]}});assert.equal(edited.status,200);post=(await edited.json() as any).data;

  const secret=/DRAFT-|RETIRED-|TRASHED-|trashed-post|EDITED-DRAFT|draft-post|draft-page|draft-faq|draft-category|draft-tag|draft-banner|draft-nav|retired-post|retired-faq|renamed-post/;
  for(const path of ['/home','/blog','/blog?q=DRAFT','/blog?q=RETIRED','/blog?q=TRASHED','/blog?sort=title_asc','/blog/live-post','/category/live-category','/tag/live-tag','/faq']){const {html}=await f.page(path);assert.ok(!secret.test(path.includes('?q=')?html.replace(/(?:DRAFT|RETIRED|TRASHED)(?!-)/g,''):html),path+' leaks unpublished content');}
  for(const path of ['/blog/draft-post','/blog/retired-post','/blog/trashed-post','/blog/renamed-post','/pages/draft-page','/category/draft-category','/tag/draft-tag']){const {html}=await f.page(path,404);assert.ok(html.includes('页面暂不可用'),path);assert.ok(!secret.test(html.replace(new RegExp(path.split('/').pop()!,'g'),'')),path);}
  // The published snapshot is what visitors read.
  const live=(await f.page('/blog/live-post')).html;assert.ok(live.includes('<h1>公开文章</h1>'));assert.ok(live.includes('公开正文 LIVE-BODY'));assert.ok(live.includes('href="/category/live-category"'));assert.ok(live.includes('href="/tag/live-tag"'));
  assert.ok((await f.page('/blog')).html.includes('href="/blog/live-post"'));assert.ok((await f.page('/home')).html.includes('href="/blog/live-post"'));
  // The staff preview stays behind the session and is never linked from a public page.
  assert.equal((await f.visit('/api/admin/content/'+post.id+'/preview')).status,401);
  for(const path of ['/home','/blog','/faq'])assert.ok(!(await f.page(path)).html.includes('/preview'),path);
  // The sitemap follows the same rule once indexing is on.
  f.env.APP_ENV='production';f.env.APP_ORIGIN='https://benos.example.com';f.env.INDEXING_ENABLED='true';
  const sitemap=await (await f.visit('/sitemap.xml')).text();assert.ok(sitemap.includes('/blog/live-post'));assert.ok(!secret.test(sitemap));
 }finally{f.db.close();}
});

test('empty states: no published content still gives complete pages, and filters explain an empty result',async()=>{
 const f=await fixture();try{
  const home=(await f.page('/home')).html;
  // Without posts or FAQ entries the home page simply omits those sections; prices are still there.
  assert.ok(!home.includes('最近更新'));assert.ok(!home.includes('mk-faq-list'));assert.ok(home.includes('id="plans"'));assert.ok(home.includes('<h1>用一句话<br>设计你的网站</h1>'));
  const blog=(await f.page('/blog')).html;assert.ok(blog.includes('文章正在准备中'));assert.ok(!blog.includes('<form'),'no search form when there is nothing to search');
  const faq=(await f.page('/faq')).html;assert.ok(faq.includes('帮助内容正在准备中'));assert.ok(faq.includes('href="/home#plans"'));assert.ok(!faq.includes('application/ld+json'));
  const category=await f.publish('category','quiet','安静的分类');
  const empty=(await f.page('/category/quiet')).html;assert.ok(empty.includes('这里还没有文章'));assert.ok(empty.includes('<h1>安静的分类</h1>'));assert.ok(empty.includes('href="/blog">查看全部文章</a>'));
  await f.publish('post','only-post','唯一的文章',{body:'正文内容',categoryId:category.id});
  const none=(await f.page('/blog?q=zzzz')).html;assert.ok(none.includes('没有找到匹配的文章'));assert.ok(none.includes('清除搜索'));assert.ok(none.includes('<form class="mk-search" method="get" action="/blog" role="search">'));
  const hit=(await f.page('/blog?q=%E5%94%AF%E4%B8%80')).html;assert.ok(hit.includes('href="/blog/only-post"'));assert.ok(!hit.includes('没有找到匹配的文章'));
  // The search form has visible labels and no inline presentation.
  assert.ok(hit.includes('<span class="mk-field-label">搜索文章</span>'));assert.ok(hit.includes('<span class="mk-field-label">排序</span>'));
  const missing=await f.page('/pages/nothing-here',404);assert.ok(missing.html.includes('页面暂不可用'));assert.ok(missing.html.includes('href="/home">返回首页</a>'));
 }finally{f.db.close();}
});

test('copy rules: AI 额度 wording, no demo or preview copy, no hosting provider name, brand files exist',async()=>{
 const f=await fixture();try{
  await f.publish('faq','first-question','第一个问题',{body:'回答'});await f.publish('post','hello','第一篇文章',{body:'文章正文'});
  for(const path of ['/home','/blog','/faq','/blog/hello']){
   const {html}=await f.page(path),visible=text(html);
   for(const banned of ['积分','演示','预览','交互演示','Hostinger','hPanel','hostinger','OpenAI'])assert.ok(!html.includes(banned),path+' contains '+banned);
   assert.ok(!/\bdemo\b/i.test(visible),path);
  }
  const home=(await f.page('/home')).html;assert.ok(home.includes('AI 额度'));
  // Brand: the static pearl mark (light and dark) and the rounded-square favicon ship with the Worker.
  assert.ok(home.includes('<picture class="mk-mark"><source srcset="/assets/brand/benos-mark-dark.svg" media="(prefers-color-scheme: dark)"><img src="/assets/brand/benos-mark.svg"'));
  assert.ok(home.includes('<link rel="apple-touch-icon" href="/assets/brand/apple-touch-icon.png">'));
  for(const file of ['benos-mark.svg','benos-mark-dark.svg','favicon.svg','apple-touch-icon.png']){const path=resolve('public/assets/brand',file);assert.ok(existsSync(path),file);assert.ok(readFileSync(path).length<64*1024,file+' stays small');}
  for(const file of ['benos-mark.svg','benos-mark-dark.svg','favicon.svg']){const svg=readFileSync(resolve('public/assets/brand',file),'utf8');assert.ok(svg.startsWith('<svg xmlns="http://www.w3.org/2000/svg"'),file);assert.ok(!/<script|<style|\sstyle=|https?:\/\/(?!www\.w3\.org)/.test(svg),file+' is self-contained');}
  assert.ok(readFileSync(resolve('public/assets/brand/favicon.svg'),'utf8').includes('<rect width="512" height="512" rx="116"'),'rounded-square favicon');
  // The stylesheet is self-contained too: no @import, no remote URL, no web font.
  const css=readFileSync(resolve('public/styles/marketing.css'),'utf8');
  // (2026-11-13 redesign: the one url() allowed is the self-hosted Inter file; still no @import and no remote host.)
  assert.ok(!/@import/.test(css));assert.ok(!/https?:\/\//.test(css));
  assert.deepEqual([...css.matchAll(/url\(([^)]*)\)/g)].map(match=>match[1]),['/assets/fonts/inter-latin.woff2']);assert.ok(existsSync(resolve('public/assets/fonts/inter-latin.woff2')));
  assert.ok(css.includes('@media (prefers-color-scheme: dark)'));assert.ok(css.includes('--mk-text: #18181b'));assert.ok(css.includes(':focus-visible'));
 }finally{f.db.close();}
});

// Activates a verified brand version through the owner API, as staff would in the brand settings.
async function setBrand(f:Awaited<ReturnType<typeof fixture>>,configuration:Record<string,unknown>){
 const made=await f.request('/api/admin/settings/branding','POST',{configuration:{brandName:'Benos',tagline:'让每个想法拥有自己的空间。',logoMediaId:null,contactEmail:'',contactPhone:'',contactAddress:'',contactUrl:'',...configuration},reason:'营销页品牌验证'});
 assert.equal(made.status,201,await made.clone().text());const id=(await made.json() as any).data.id;
 assert.equal((await f.request('/api/admin/settings/branding/'+id+'/test','POST',{reason:'校验品牌配置'})).status,200);
 assert.equal((await f.request('/api/admin/settings/branding/'+id+'/activate','POST',{reason:'启用品牌配置'})).status,200);
}
const headerClass=(html:string)=>/<header class="([^"]+)">/.exec(html)![1];

test('header layout adapts to admin-authored navigation entries and long brand names instead of overlapping',async()=>{
 const f=await fixture();try{
  // Default brand and the three built-in links fit in the header row from 768 px.
  let html=(await f.page('/home')).html;assert.equal(headerClass(html),'mk-header');
  assert.ok(html.includes('<a href="/blog"><span>博客</span></a>'));assert.ok(html.includes('<nav class="mk-nav mk-nav--bar" aria-label="主导航">'));
  // Four short custom entries (seven links): the row only fits from 1024 px, below that the links move to the bar.
  for(const [index,title] of ['模板案例','更新日志','关于我们','合作伙伴'].entries())await f.publish('navigation','nav-short-'+index,title,{body:'',placement:'header',url:'/blog',position:10+index});
  html=(await f.page('/home')).html;assert.equal(headerClass(html),'mk-header mk-header--nav-wide');
  assert.ok(html.includes('<a href="/blog"><span>合作伙伴</span></a>'));
  // One very long entry: the links always sit in the bar; the link carries its full title for the ellipsis.
  const long='这是一个非常非常长的页眉导航标题用于检查布局是否会溢出到登录按钮下面';
  await f.publish('navigation','nav-long',long,{body:'',placement:'header',url:'/faq',position:30});
  html=(await f.page('/blog')).html;assert.equal(headerClass(html),'mk-header mk-header--nav-bar');
  assert.ok(html.includes(`<a href="/faq" title="${long}"><span>${long}</span></a>`));
  // A 31-character brand: clipped by CSS, full name in the accessible name and title.
  const brandName='Benos Creative Studio Worldwide';
  await setBrand(f,{brandName});
  html=(await f.page('/faq')).html;assert.ok(html.includes(`<a class="mk-brand" href="/home" aria-label="${brandName} 首页" title="${brandName}">`));assert.equal(headerClass(html),'mk-header mk-header--nav-bar');
  // The stylesheet carries the rules the layouts depend on.
  const css=readFileSync(resolve('public/styles/marketing.css'),'utf8');
  for(const rule of ['.mk-header--nav-bar + .mk-nav--bar { display: flex; }','.mk-header--nav-wide + .mk-nav--bar { display: flex; }','.mk-brand > span { min-width: 0; overflow: hidden; text-overflow: ellipsis;','.mk-header .mk-nav { margin: -4px; padding: 4px; overflow-x: auto;','.mk-nav a > span { min-width: 0; overflow: hidden; text-overflow: ellipsis; }'])assert.ok(css.includes(rule),rule);
  assert.ok(/\.mk-brand \{[^}]*flex: 0 1 auto; min-width: 0; max-width: 260px;/.test(css));
 }finally{f.db.close();}
});

test('stale or mangled listing parameters render a page, never raw JSON',async()=>{
 const f=await fixture();try{
  const category=await f.publish('category','news','动态'),tag=await f.publish('tag','notes','笔记');
  for(let index=0;index<13;index++)await f.publish('post','entry-'+index,'文章 '+String(index).padStart(2,'0'),{body:'正文',categoryId:category.id,tagIds:[tag.id]});
  const first=(await f.page('/blog')).html;assert.ok(first.includes('下一页'));
  const next=/href="\/blog\?([^"]+)">下一页/.exec(first)![1].replace(/&amp;/g,'&');
  const cursor=new URLSearchParams(next).get('cursor')!;
  // The real cursor still works.
  assert.ok((await f.page('/blog?'+next)).html.includes('回到第一页'));
  const longQuery='x'.repeat(400);
  for(const path of ['/blog?sort=bogus','/blog?cursor=garbage','/blog?cursor=%25%25%25','/blog?sort=title_asc&cursor='+encodeURIComponent(cursor),'/blog?q='+longQuery,'/category/news?sort=bogus','/category/news?cursor=garbage','/tag/notes?cursor=garbage&sort=nope']){
   const {response,html}=await f.page(path);
   assert.match(response.headers.get('content-type')!,/^text\/html/,path);assertCspSafe(html,path);
   assert.ok(response.headers.get('content-security-policy')!.includes("script-src 'none'"),path);assert.equal(response.headers.get('x-robots-tag'),'noindex,nofollow',path);
   assert.ok(!html.includes('"ok":false'),path);
  }
  // An unknown sort uses the default order; the select shows the default option.
  const bogus=(await f.page('/blog?sort=bogus')).html;assert.ok(bogus.includes('<option value="published_desc" selected>'));assert.ok(!bogus.includes('bogus'));
  // A cursor that does not decode, or belongs to another filter, shows the first page without a "back" link.
  for(const path of ['/blog?cursor=garbage','/blog?sort=title_asc&cursor='+encodeURIComponent(cursor)]){const {html}=await f.page(path);assert.ok(html.includes('下一页'),path);assert.ok(!html.includes('回到第一页'),path);}
  // An over-long query is cut to the form limit.
  assert.ok((await f.page('/blog?q='+longQuery)).html.includes(`value="${'x'.repeat(160)}"`));
 }finally{f.db.close();}
});

test('the 404 page declares no canonical URL, and Enterprise always offers an action',async()=>{
 const f=await fixture();try{
  for(const path of ['/blog/does-not-exist','/pages/none','/category/none','/tag/none']){const {html}=await f.page(path,404);assert.ok(!html.includes('rel="canonical"'),path);assert.ok(!html.includes('og:url'),path);assert.ok(!html.includes(f.env.APP_ORIGIN+'/home'),path);}
  // Real pages keep their own canonical address.
  assert.ok((await f.page('/blog')).html.includes(`<link rel="canonical" href="${f.env.APP_ORIGIN}/blog">`));
  // No brand contact yet: the Enterprise card links to the FAQ instead of a dead end.
  let enterprise=card((await f.page('/home')).html,'Enterprise');assert.ok(enterprise.includes('<a class="mk-button" href="/faq">查看常见问题</a>'));assert.ok(!enterprise.includes('尚未公布'));
  await setBrand(f,{contactEmail:'sales@example.test'});
  enterprise=card((await f.page('/home')).html,'Enterprise');assert.ok(enterprise.includes('<a class="mk-button" href="mailto:sales@example.test">联系报价</a>'));
  await setBrand(f,{contactEmail:'sales@example.test',contactUrl:'https://example.test/contact'});
  enterprise=card((await f.page('/home')).html,'Enterprise');assert.ok(enterprise.includes('<a class="mk-button" href="https://example.test/contact" rel="noopener">联系报价</a>'));
 }finally{f.db.close();}
});

test('user-authored fields are escaped everywhere: no raw markup and no attribute breakout',async()=>{
 const f=await fixture();try{
  const payload=`X"><script>alert(1)</script><img src=x onerror=alert(2)>' autofocus onfocus='alert(3)`;
  const rich=(extra:Record<string,unknown>={})=>({body:payload+'\n\n'+payload,description:payload,seoTitle:payload,seoDescription:payload,...extra});
  const category=await f.publish('category','evil-category',payload,rich()),tag=await f.publish('tag','evil-tag',payload,rich());
  await f.publish('post','evil-post',payload,rich({categoryId:category.id,tagIds:[tag.id],coverUrl:'/assets/brand/benos-mark.svg',coverAlt:payload}));
  await f.publish('page','evil-page',payload,rich({coverUrl:'/assets/brand/benos-mark.svg',coverAlt:payload}));
  await f.publish('faq','evil-faq',payload,{body:payload,position:1});
  await f.publish('banner','evil-banner',payload,{body:payload,description:payload,placement:'home',url:'/blog',coverUrl:'/assets/brand/benos-mark.svg',coverAlt:payload});
  await f.publish('navigation','evil-nav-header',payload,{body:'',placement:'header',url:'/blog'});
  await f.publish('navigation','evil-nav-footer',payload,{body:'',placement:'footer',url:'/faq'});
  // Brand fields refuse < and >, so they carry quote, apostrophe and ampersand payloads.
  await setBrand(f,{brandName:`B"nos' & Co" onfocus="x`,tagline:`Tag"line' & "q" autofocus onfocus="y`,contactEmail:'hello@example.test',contactPhone:`+1 "555" ' onfocus='z`,contactAddress:`Addr" x='y' &amp;`,contactUrl:'https://example.test/contact?a="b"&c=1'});
  const escapedPayload='X&quot;&gt;&lt;script&gt;alert(1)&lt;/script&gt;&lt;img src=x onerror=alert(2)&gt;&#39; autofocus onfocus=&#39;alert(3)';
  for(const [path,status] of [['/home',200],['/blog',200],['/blog?q='+encodeURIComponent(payload),200],['/blog/evil-post',200],['/pages/evil-page',200],['/category/evil-category',200],['/tag/evil-tag',200],['/faq',200],['/blog/none',404]] as const){
   // The JSON-LD data block holds the payload as JSON text (checked below); the rest of the document is the HTML.
   const {html}=await f.page(path,status),outside=html.replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>/g,'');assertCspSafe(outside,path);
   for(const raw of ['<script>alert','<img src=x',`' autofocus`,`onfocus='alert`,'" onfocus="x','" autofocus onfocus="y',`' onfocus='z`,`x='y'`,'a="b"'])assert.ok(!outside.includes(raw),path+' raw '+raw);
   // Every tag is well formed: attribute values are clean quoted strings, so no stray quote opens a new attribute.
   for(const tagMatch of outside.matchAll(/<[a-z][^>]*>/gi))assert.match(tagMatch[0],/^<[a-z0-9]+(?:\s+[a-z-:]+(?:="[^"<>]*")?)*\s*\/?>$/i,path+': '+tagMatch[0].slice(0,160));
   assert.ok(html.includes('B&quot;nos&#39; &amp; Co&quot; onfocus=&quot;x'),path+' brand escaped');
   if(status===200&&!path.includes('?q='))assert.ok(html.includes(escapedPayload),path+' payload shown as text');
   // JSON-LD stays valid JSON and cannot close its own script element.
   for(const block of html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)){assert.ok(!block[1].includes('<'),path);JSON.parse(block[1]);}
  }
  const post=(await f.page('/blog/evil-post')).html;
  assert.ok(post.includes(`<title>${escapedPayload} · B&quot;nos&#39; &amp; Co&quot; onfocus=&quot;x</title>`));assert.ok(post.includes(`<meta name="description" content="${escapedPayload}">`));assert.ok(post.includes(`alt="${escapedPayload}"`));
  assert.ok(post.includes('Addr&quot; x=&#39;y&#39; &amp;amp;'));assert.ok(post.includes('+1 &quot;555&quot; &#39; onfocus=&#39;z'));
 }finally{f.db.close();}
});
