import test from 'node:test';
import assert from 'node:assert/strict';
import { DESIGN_STYLES } from '../src/contracts/design-style-catalog';
import { createDesignFoundation,compileDesignFoundation,materializeDesignFoundation,inheritDesignFoundation,foundationAuthoringContext,foundationAuthoringExample,foundationAuthoringManifest,foundationFromRequirements,supportsHeroCover,HERO_COVER_MARKER,FOUNDATION_START,FOUNDATION_END } from '../src/contracts/design-foundation';
import { validateSiteManifest } from '../src/modules/template-contract';
import { liveManifest } from '../src/lib/workflow-progress';
import { streamTemplateZip,openTemplateArchive,readTemplateEntry } from '../src/lib/template-archive';
import example from '../src/contracts/site-example.json';

test('all catalog foundations are valid self-contained AACMS output while authoring contains no generated source',async()=>{
 for(const style of DESIGN_STYLES){
  const profile=createDesignFoundation(style),authored=foundationAuthoringExample(profile),final=materializeDesignFoundation(authored,profile),css=final.site.theme.global_css;
  assert.equal(authored.site.theme.global_css,'','the model does not write foundational CSS');
  assert.equal(validateSiteManifest(final).valid,true,JSON.stringify(validateSiteManifest(final).issues));
  assert.equal(css.split(FOUNDATION_START).length-1,1);assert.equal(css.split(FOUNDATION_END).length-1,1);
  assert.doesNotMatch(css,/@import|@font-face|https?:|url\(/i);
  assert.match(css,/:focus-visible\{outline:3px solid var\(--bnf-ink\);outline-offset:5px;box-shadow:0 0 0 3px var\(--bnf-bg\)\}/,'the second ring remains visible where accent equals ink');
  assert.deepEqual(materializeDesignFoundation(final,profile),final,'repeated corrections do not grow CSS');
  const context=JSON.stringify(foundationAuthoringContext(profile));assert.ok(context.length<5400,'one selected style and compact chrome guidance only');assert.ok(!context.includes(FOUNDATION_START));assert.ok(context.includes(style.layout.mobile));assert.ok(css.includes(`8vw,${style.density.sectionGap}px`));
  for(const other of DESIGN_STYLES.filter(item=>item.id!==style.id))assert.ok(!context.includes(other.brief),'only one style brief is supplied');
  assert.deepEqual(foundationAuthoringManifest(final,profile),authored);
 }
});

test('bnf-2 exposes the cover capability while bnf-1 retains its marker and exact frozen bytes', () => {
 const current=createDesignFoundation(DESIGN_STYLES[0]);
 assert.equal(current.version,'bnf-2'); assert.equal(supportsHeroCover(current),true);
 assert.deepEqual(foundationAuthoringContext(current).imagePresentations,['standard','hero-cover']);
 const old={...current,version:'bnf-1' as const,primitives:current.primitives.filter(value=>value!=='hero-cover')};
 const oldCss=compileDesignFoundation(old);
 assert.ok(oldCss.startsWith('/* benos-foundation:bnf-1:start */'));
 assert.ok(oldCss.endsWith('/* benos-foundation:bnf-1:end */'));
 assert.ok(!oldCss.includes('hero-cover'));
 const saved=materializeDesignFoundation(foundationAuthoringExample(old),old);
 saved.site.theme.global_css=saved.site.theme.global_css.replace('.bnf-nav{','.bnf-nav{letter-spacing:.037em;');
 const inherited=inheritDesignFoundation(saved,old)!;
 assert.equal(inherited.version,'bnf-1'); assert.equal(supportsHeroCover(inherited),false);
 assert.equal(compileDesignFoundation(inherited,saved.site.theme),saved.site.theme.global_css);
 assert.equal(foundationFromRequirements({foundation:inherited})?.version,'bnf-1');
 assert.ok(!JSON.stringify(foundationAuthoringContext(inherited)).includes('hero-cover'));
 assert.equal(foundationFromRequirements({foundation:{...inherited,version:'bnf-2'}}),null,'marker cannot upgrade an old snapshot');
 assert.equal(inheritDesignFoundation(saved,current),null,'origin version and frozen CSS must agree');
 const changed=foundationAuthoringManifest(saved,inherited); changed.site.theme.brand_color='#346734';
 const changedCss=materializeDesignFoundation(changed,inherited).site.theme.global_css;
 assert.ok(changedCss.includes('--bnf-accent:#346734')); assert.ok(!changedCss.includes('bnf-2'));
 assert.ok(changedCss.endsWith('/* benos-foundation:bnf-1:end */'));
});

test('all sixteen cover palettes use an opaque readable text face and preserve frozen capability', () => {
 const luminance=(hex:string)=>{const c=hex.slice(1).match(/../g)!.map(v=>parseInt(v,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return c[0]*.2126+c[1]*.7152+c[2]*.0722;};
 const contrast=(a:string,b:string)=>(Math.max(luminance(a),luminance(b))+.05)/(Math.min(luminance(a),luminance(b))+.05);
 for(const style of DESIGN_STYLES)for(const background of [style.tokens.background,'#ffffff','#000000','#ffcc00']){
  const profile=createDesignFoundation(style),css=compileDesignFoundation(profile,{brand_background:background});
  const ink=/--bnf-cover-panel-ink:(#[\da-f]{6})/i.exec(css)![1];
  assert.ok(contrast(background,ink)>=4.5,style.id+'/'+background);
  assert.ok(css.includes(HERO_COVER_MARKER));
  assert.match(css,/\.bnf-hero-cover-panel\{[^}]*background:var\(--bnf-cover-panel-bg\);color:var\(--bnf-cover-panel-ink\)/);
  assert.match(css,/@media\(max-width:640px\)\{\.bnf-hero-cover\{--bnf-hero-cover-height:56vh/);
  assert.ok(css.length<40000,style.id+': snapshot budget');
 }
 const profile=createDesignFoundation(DESIGN_STYLES[0]),saved=materializeDesignFoundation(foundationAuthoringExample(profile),profile),frozen=inheritDesignFoundation(saved,profile)!;
 assert.equal(supportsHeroCover(frozen),true);
 const changed=foundationAuthoringManifest(saved,frozen); changed.site.theme.brand_background='#000000';
 assert.match(materializeDesignFoundation(changed,frozen).site.theme.global_css,/\.bnf-hero-cover\{--bnf-cover-panel-bg:#000000;--bnf-cover-panel-ink:#ffffff\}/);
 const noCover={...frozen,frozenCss:frozen.frozenCss!.replace(HERO_COVER_MARKER,'')};
 assert.equal(supportsHeroCover(noCover),false);
 assert.ok(!JSON.stringify(foundationAuthoringContext(noCover)).includes('hero-cover'));
});

test('untrusted CSS markers cannot choose or suppress the server foundation; custom rules remain editable',()=>{
 const profile=createDesignFoundation(DESIGN_STYLES[1]),authored=foundationAuthoringExample(profile);
 authored.site.theme.global_css=FOUNDATION_START+'body{background:red}'+FOUNDATION_END+'\n.customer-hero{transform:rotate(-1deg)}';
 const final=materializeDesignFoundation(authored,profile);
 assert.ok(final.site.theme.global_css.startsWith(compileDesignFoundation(profile,authored.site.theme)));
 assert.doesNotMatch(final.site.theme.global_css,/body\{background:red/);assert.match(final.site.theme.global_css,/\.customer-hero/);
 assert.equal(foundationFromRequirements({foundation:{...profile,tokens:{...profile.tokens,headingFont:'serif;display:none'}}}),null);
 assert.equal(materializeDesignFoundation(example,null),example,'legacy sites are not rewritten, even by a helper');
});

test('the streamed partial markup, saved manifest and exported ZIP share exactly one foundation',async()=>{
 const profile=createDesignFoundation(DESIGN_STYLES[3]),authored=foundationAuthoringExample(profile);
 authored.site.theme.global_css='.customer-hero{isolation:isolate}';
 const partial=JSON.stringify(authored).replace(/<\/footer>[\s\S]*$/,'');
 const live=liveManifest(example,[{path:'manifest.json',content:partial}],profile);
 const final=materializeDesignFoundation(authored,profile);
 assert.ok(live?.templates.some(template=>template.document.html.includes('bnf-hero')));
 assert.equal(live?.site?.theme?.global_css,final.site.theme.global_css);
 const zip=streamTemplateZip(final,[]),bytes=new Uint8Array(await new Response(zip.stream).arrayBuffer());
 const source={size:bytes.length,read:async(offset:number,length:number)=>bytes.slice(offset,offset+length)},entries=await openTemplateArchive(source);
 assert.deepEqual(entries.map(entry=>entry.name),['manifest.json'],'no runtime CSS dependency is exported');
 const exported=JSON.parse(new TextDecoder().decode(await readTemplateEntry(source,entries[0])));
 assert.equal(exported.site.theme.global_css,live?.site?.theme?.global_css);assert.deepEqual(exported,final);
});

test('adopted foundations freeze actual CSS refinements and allow explicit brand token changes without rebuilding',()=>{
 const profile=createDesignFoundation(DESIGN_STYLES[4]),saved=materializeDesignFoundation(foundationAuthoringExample(profile),profile);
 saved.site.theme.global_css=saved.site.theme.global_css.replace('.bnf-nav{','.bnf-nav{letter-spacing:.02em;')+'\n.client-detail{margin:7px}';
 const inherited=inheritDesignFoundation(saved,profile)!;assert.ok(inherited.frozenCss);
 assert.equal(materializeDesignFoundation(foundationAuthoringManifest(saved,inherited),inherited).site.theme.global_css,saved.site.theme.global_css);
 assert.ok(!JSON.stringify(foundationAuthoringContext(inherited)).includes('letter-spacing'));
 const changed=foundationAuthoringManifest(saved,inherited);changed.site.theme.brand_color='#346734';
 const next=materializeDesignFoundation(changed,inherited);
 assert.match(next.site.theme.global_css,/--bnf-accent:#346734/);assert.match(next.site.theme.global_css,/letter-spacing:\.02em/);
 assert.deepEqual(materializeDesignFoundation(next,inherited),next);
 const green=inheritDesignFoundation(next,inherited)!,omitted:any=foundationAuthoringManifest(next,green);delete omitted.site.theme.brand_color;delete omitted.site.theme.brand_background;delete omitted.site.theme.container_width;
 const retained=materializeDesignFoundation(omitted,green);assert.equal(retained.site.theme.brand_color,'#346734');assert.equal(retained.site.theme.global_css,next.site.theme.global_css);
 const noTheme:any=structuredClone(next);delete noTheme.site.theme;const restored=materializeDesignFoundation(noTheme,green);assert.equal(restored.site.theme.brand_color,'#346734');assert.equal(restored.site.theme.global_css,green.frozenCss);
 assert.equal(inheritDesignFoundation(example,profile),null,'an unrelated legacy design has no block to inherit');
});
