import test from 'node:test';
import assert from 'node:assert/strict';
import {diagnoseDesignCoherence} from '../src/modules/design-coherence';
import {createDesignBrief} from '../src/contracts/design-brief';
import actualTech from './fixtures/design-coherence-tech.json';
const manifest=(html:string)=>({site:{home:'home',pages:[{key:'home',template_id:1}],theme:{}},templates:[{id:1,type:'page',document:{html,css:''}}]});
const pageBlueprint=createDesignBrief({request:'品牌官网',hasExistingSite:false})!.pageBlueprint!;
test('new depth and auxiliary observations are opt-in, bounded and never replan legacy snapshots',()=>{
 const m=manifest('<section><p class="bnf-eyebrow">第一章</p><h1>主题</h1><p class="meta"><span class="meta">重复辅助</span></p><figure><figcaption>图像说明</figcaption></figure></section><section><p class="caption">补充</p><h2>过程</h2></section>');
 assert.deepEqual(diagnoseDesignCoherence(m).diagnostics,[]);
 const checks=diagnoseDesignCoherence(m,{blueprint:pageBlueprint}).diagnostics;assert.ok(checks.some(d=>d.code==='blueprint_depth_gap'));assert.ok(checks.some(d=>d.code==='auxiliary_text_overuse'));assert.match(checks.find(d=>d.code==='auxiliary_text_overuse')!.evidence[0],/4项\/2节/);assert.ok(checks.every(d=>d.severity==='advisory'));
 const simple=createDesignBrief({request:'只做首屏',hasExistingSite:false})!.pageBlueprint!;assert.ok(!diagnoseDesignCoherence(manifest('<section><h1>单屏</h1></section>'),{blueprint:simple}).diagnostics.some(d=>d.code==='blueprint_depth_gap'));
});
test('explicit empty loading skeleton is reported but labelled diagrams and decorative shapes are not guessed',()=>{
 const bad=diagnoseDesignCoherence(manifest('<section><h1>应用</h1><div class="image-placeholder"></div></section>'),{blueprint:pageBlueprint});assert.ok(bad.diagnostics.some(d=>d.code==='unfinished_visual_placeholder'));
 for(const body of ['<div class="diagram"><div>来料</div><div>加工</div><div>结果</div></div>','<div class="decorative-square" aria-hidden="true"></div>','<div class="image-placeholder"><img src="/uploads/a.png" alt="实际图片"></div>'])assert.ok(!diagnoseDesignCoherence(manifest('<section><h1>应用</h1>'+body+'</section>'),{blueprint:pageBlueprint}).diagnostics.some(d=>d.code==='unfinished_visual_placeholder'));
});


test('new placeholder notes cannot displace existing checks from the bounded report',()=>{
 const m=structuredClone(actualTech);
 m.templates[0].document.html+=Array.from({length:8},(_,i)=>`<section><h2>主题${i}</h2><div class="image-placeholder"></div></section>`).join('');
 const legacy=diagnoseDesignCoherence(m),updated=diagnoseDesignCoherence(m,{blueprint:pageBlueprint});
 assert.ok(legacy.diagnostics.length>0);assert.deepEqual(updated.diagnostics.slice(0,legacy.diagnostics.length),legacy.diagnostics);
 assert.equal(updated.diagnostics.length,6);assert.equal(updated.coverage.truncated,true);
});
