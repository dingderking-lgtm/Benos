import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const MiB=1048576;
const hash=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');

/** Fresh inputs for each native test; no fixture archive or prior test run is required. */
export function nativePublicationManifest(){
 const original=JSON.parse(readFileSync(resolve('..','模板制作规范','manifest示例.json'),'utf8').replace(/^\uFEFF/,''));
 original.site.author={slug:'bundle-editorial',name:'Bundle fixture editorial',kind:'organization',title:'Native test editor',brief:'Local publication fixture',bio:'Isolated native CMS article author fixture.',avatar:'/uploads/2026/11/'+'0'.repeat(32)+'.png'};
 original.templates.push({id:7,name:'Seed article',type:'page',document:{version:1,html:'<article><h1>Independent editorial content</h1><p>Customer articles must remain owned and edited by the CMS.</p></article>',css:''},conditions:{all:false,pages:[],exclude_pages:[],types:[],categories:[]}});
 original.site.pages.push({key:'seed_article',title:'Independent editorial content',slug:'insights/editorial-example',type:'article',template_id:7,seo:{title:'Independent editorial content',description:'Native publisher preservation fixture.',schema_type:'Article',language:'en'},excerpt:'Native article fixture',blog:{featured:false}});
 return original;
}

export function nativeFixturePdf(size:number,index:number){
 const stream='%'+String.fromCharCode(65+index).repeat(size-800)+'\n0 0 1 rg 0 0 10 10 re f\n',objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Count 1 /Kids [3 0 R] >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Resources << >> /Contents 4 0 R >>','<< /Length '+Buffer.byteLength(stream)+' >>\nstream\n'+stream+'endstream'];
 let content='%PDF-1.7\n';const offsets:number[]=[];
 for(const [i,object] of objects.entries()){offsets.push(Buffer.byteLength(content));content+=(i+1)+' 0 obj\n'+object+'\nendobj\n';}
 const start=Buffer.byteLength(content);
 content+='xref\n0 5\n0000000000 65535 f \n'+offsets.map(value=>String(value).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n'+start+'\n%%EOF\n';
 const bytes=Buffer.from(content);assert.ok(bytes.length<=size&&bytes.length>size-1024);return bytes;
}

/** Native receiver seals these inputs into a stored ZIP exceeding 73 MiB, below the 74 MiB limit. */
export function largeNativeBundleFixture(original:any,png:Buffer){
 const manifest=structuredClone(original),files:Array<{file:string;bytes:Buffer}>=[];manifest.assets=[];
 manifest.templates[0].document.html='<section><h1>Large bundle publication</h1><p>'+('A'.repeat(7*MiB))+'</p></section>';
 manifest.templates[1].document.html='<section><h1>Large native contact</h1><p>'+('B'.repeat(2*MiB+524288))+'</p></section>';
 for(let index=0;index<6;index++){
  const bytes=nativeFixturePdf((index===5?4:12)*MiB,index),file='assets/'+index+'.pdf',path='/uploads/2026/11/'+hash(bytes)+'.pdf';
  files.push({file,bytes});manifest.assets.push({file,path,size:bytes.length,sha256:hash(bytes),name:'document-'+index+'.pdf',alt:''});
  manifest.templates[0].document.html+='<a href="'+path+'" download>Download verified PDF '+index+'</a>';
 }
 files.push({file:'assets/6.png',bytes:Buffer.from(png)});
 manifest.assets.push({file:'assets/6.png',path:manifest.site.author.avatar,size:png.length,sha256:hash(png),name:'author.png',alt:'Local editorial fixture'});
 const manifestBytes=Buffer.byteLength(JSON.stringify(manifest)),mediaBytes=files.reduce((sum,file)=>sum+file.bytes.length,0);
 assert.ok(manifestBytes>9*MiB&&manifestBytes<=10*MiB,'Exercise the near-limit manifest, not a small substitute');
 assert.ok(mediaBytes>63*MiB&&mediaBytes<=64*MiB,'Exercise the near-limit asset payload');
 return {manifest,files};
}
