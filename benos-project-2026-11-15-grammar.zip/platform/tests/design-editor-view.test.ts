import test from 'node:test';
import assert from 'node:assert/strict';
import { Hono } from 'hono';
import type { App } from '../src/lib/http';
import { AppError } from '../src/lib/errors';
import { mediaFixture,png } from './media-helper';
import { saveVersion } from '../src/modules/ai';
import { saveDesignCandidate,adoptDesignCandidate } from '../src/modules/design-workspace';
import { getDesignEditorView,getDesignEditorNodes,restoreDesignVersion,designEditorRoutes } from '../src/modules/design-editor-view';
import { describeDesignNodePage,annotateDesignHtml,designNodeHtml } from '../src/modules/design-nodes';
import { starterManifest } from '../src/contracts/starter-library';
import { sha256 } from '../src/lib/crypto';
import { saveMedia } from '../src/modules/media';
import { withDesignMemoryBudget } from '../src/lib/design-memory-budget';

const MIB=1048576;
function largeManifest(target=3*MIB){const manifest=starterManifest('studio')!,padding=target-new TextEncoder().encode(JSON.stringify(manifest)).length-12;manifest.templates[0].document.css+='/*'+'x'.repeat(Math.floor(padding/2))+'*/\n';manifest.templates[1].document.css+='/*'+'y'.repeat(padding-Math.floor(padding/2))+'*/\n';return manifest;}
const current=(f:ReturnType<typeof mediaFixture>)=>f.db.sqlite.prepare("SELECT current_version_id FROM projects WHERE id='p'").get()!.current_version_id;
const count=(f:ReturnType<typeof mediaFixture>)=>Number(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_versions').get()!.n);
const code=(value:string)=>(error:any)=>error instanceof AppError&&error.code===value;
async function first(f:ReturnType<typeof mediaFixture>,manifest:unknown=starterManifest('studio')){return saveVersion(f.env,'u','p',manifest,'manual',null,'initial-version');}

test('independent editor projection serves inline sources without HTML/CSS and matches native virtual-page conditions',async()=>{
 const f=mediaFixture();try{const manifest=starterManifest('studio')!,version=await first(f,manifest),view=await getDesignEditorView(f.env,'u','p',{versionId:version});
  assert.equal(view.sourceId,version);assert.equal(view.sourceKind,'version');assert.equal(view.projectionVersion,1);assert.equal(view.currentVersionId,version);assert.equal(view.contentHash,await sha256(JSON.stringify(manifest)));assert.equal(view.byteSize,new TextEncoder().encode(JSON.stringify(manifest)).length);
  assert.equal(view.site.pages.length,3);assert.ok(view.pageOptions.some(p=>p.key==='__blog_archive'));assert.ok(view.pageOptions.some(p=>p.key==='__blog_author'));assert.ok(view.pageOptions.some(p=>p.key==='__blog_article'));assert.ok(JSON.stringify(view).length<20000);assert.doesNotMatch(JSON.stringify(view),/"document"|"html"|"css"|object_key|private\/users/);assert.equal(f.storage.gets,0);
  const row=f.db.sqlite.prepare('SELECT * FROM design_editor_projections').get()!;assert.equal(row.source_hash,view.contentHash);assert.equal(row.projection_hash,await sha256(String(row.projection_json)));
  const article=structuredClone(manifest);article.site.pages[1].type='article';const articleId=await saveVersion(f.env,'u','p',article,'manual',version,'article-version');const next=await getDesignEditorView(f.env,'u','p',{versionId:articleId});assert.ok(next.pageOptions.some(p=>p.key===article.site.pages[1].key&&p.label.includes('文章详情')));assert.ok(!next.pageOptions.some(p=>p.key==='__blog_article'));
 }finally{f.db.close();}
});

test('near-10 MiB R2 sources generate a small cached projection; cache hits do not fetch the manifest or change the 0037 index',async()=>{
 const f=mediaFixture();try{const manifest=largeManifest(10*MIB-256),version=await first(f,manifest),index=f.db.sqlite.prepare('SELECT manifest_json FROM design_versions WHERE id=?').get(version)!.manifest_json,gets=f.storage.gets;
  const view=await getDesignEditorView(f.env,'u','p',{versionId:version});assert.equal(view.byteSize,10*MIB-256);assert.equal(f.storage.gets,gets+1);const cached=await getDesignEditorView(f.env,'u','p',{versionId:version});assert.deepEqual(cached,view);assert.equal(f.storage.gets,gets+1);assert.equal(f.db.sqlite.prepare('SELECT manifest_json FROM design_versions WHERE id=?').get(version)!.manifest_json,index);assert.ok(new TextEncoder().encode(JSON.stringify(cached)).length<20000);
  f.db.sqlite.prepare("UPDATE design_editor_projections SET projection_json='{}'").run();assert.equal((await getDesignEditorView(f.env,'u','p',{versionId:version})).site.name,view.site.name);assert.equal(f.storage.gets,gets+2,'Corrupt derived cache is rebuilt from the verified source');
 }finally{f.db.close();}
});

test('candidate projection does not cache mutable state or current project head',async()=>{
 const f=mediaFixture();try{const manifest=starterManifest('studio')!,candidate=await saveDesignCandidate(f.env,{userId:'u',projectId:'p',requestKey:'candidate-projection-test',baseVersionId:null,scope:{kind:'site'},manifest,source:'manual'});
  const before=await getDesignEditorView(f.env,'u','p',{candidateId:candidate.id});assert.equal(before.candidate?.state,'draft');assert.equal(before.currentVersionId,null);assert.match(before.previewUrl,/\/candidate\//);
  const adopted=await adoptDesignCandidate(f.env,'u','p',candidate.id);const after=await getDesignEditorView(f.env,'u','p',{candidateId:candidate.id});assert.equal(after.candidate?.state,'adopted');assert.equal(after.candidate?.versionId,adopted.versionId);assert.equal(after.currentVersionId,adopted.versionId);assert.equal(before.contentHash,after.contentHash);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_editor_projections').get()!.n,1);
 }finally{f.db.close();}
});

test('node pages and exact selection retain original parser-based keys across excluded nodes, template content and foster parenting',()=>{
 const manifest=starterManifest('studio')!,template=manifest.templates[0];template.document.html='<section><style>.a{color:red}</style><p title=">">Hello <strong>world</strong></p><template><b>inert</b></template><table>outside<tr><td>Cell</td></tr></table><img src="/x.png" alt="logo"></section>';
 const firstPage=describeDesignNodePage(manifest,{templateId:template.id,limit:3});assert.deepEqual(firstPage.items.map(n=>n.nodeKey),['n0','n2','n3']);assert.equal(firstPage.hasMore,true);assert.ok(firstPage.items[0].label.length<=65);
 let after=-1,keys:string[]=[];do{const page=describeDesignNodePage(manifest,{templateId:template.id,after,limit:2});keys.push(...page.items.map(n=>n.nodeKey));if(page.nextAfter===null)break;after=page.nextAfter;}while(true);
 assert.equal(new Set(keys).size,keys.length);assert.ok(!keys.includes('n1'));assert.ok(!keys.includes('n4'));assert.ok(!keys.some(key=>designNodeHtml(manifest,{kind:'node',templateId:template.id,nodeKey:key}).node.tagName==='b'));
 const marked=annotateDesignHtml(template.document.html,template.id);for(const key of keys){const exact=describeDesignNodePage(manifest,{templateId:template.id,nodeKey:key});assert.equal(exact.items.length,1);assert.equal(exact.items[0].nodeKey,key);assert.ok(marked.includes('data-benos-node="'+key+'"'));}
 assert.throws(()=>describeDesignNodePage(manifest,{templateId:template.id,nodeKey:'n1'}),code('DESIGN_SCOPE'));assert.throws(()=>describeDesignNodePage(manifest,{templateId:template.id,limit:201}),code('VALIDATION'));
});

test('large text and many-node shapes produce bounded labels and at most 200 descriptors without an all-site node list',()=>{
 const manifest=starterManifest('studio')!,template=manifest.templates[0];template.document.html='<section><p>'+'界🙂é\r\n'.repeat(240000)+'</p><p>End</p></section>';
 let page=describeDesignNodePage(manifest,{templateId:template.id,limit:2});assert.equal(page.items.length,2);assert.equal(page.hasMore,true);assert.ok(page.items.every(n=>n.label.length<=65));
 template.document.html='<section>'+Array.from({length:20000},(_,n)=>'<p>item '+n+'</p>').join('')+'</section>';page=describeDesignNodePage(manifest,{templateId:template.id,limit:200});assert.equal(page.items.length,200);assert.equal(page.nextAfter,199);assert.equal(page.hasMore,true);assert.ok(JSON.stringify(page).length<45000);assert.equal(describeDesignNodePage(manifest,{templateId:template.id,nodeKey:'n19999'}).items[0].label,'item 19998');
});

test('node cursors are bound to source hash/template; exact lookup needs no preloaded page',async()=>{
 const f=mediaFixture();try{const manifest=starterManifest('studio')!,version=await first(f,manifest),templateId=manifest.templates[0].id,one=await getDesignEditorNodes(f.env,'u','p',{versionId:version,templateId,limit:1});assert.equal(one.items.length,1);assert.ok(one.nextCursor);
  const two=await getDesignEditorNodes(f.env,'u','p',{versionId:version,templateId,limit:1,cursor:one.nextCursor!});assert.notEqual(one.items[0].nodeKey,two.items[0].nodeKey);
  const exact=await getDesignEditorNodes(f.env,'u','p',{versionId:version,templateId,nodeKey:two.items[0].nodeKey});assert.deepEqual(exact.items.map(({aiTarget,...node})=>node),two.items);assert.equal(exact.items[0].aiTarget?.templateId,templateId);assert.equal(exact.items[0].aiTarget?.tag,'section');assert.ok(!('aiTarget' in two.items[0]));
  const next=structuredClone(manifest);next.templates[0].document.css+='\n.x{color:red}';const newer=await saveVersion(f.env,'u','p',next,'manual',version,'newer-for-cursor');await assert.rejects(()=>getDesignEditorNodes(f.env,'u','p',{versionId:newer,templateId,cursor:one.nextCursor!}),code('EDITOR_CURSOR_STALE'));
  await assert.rejects(()=>getDesignEditorNodes(f.env,'u','p',{versionId:version,templateId:2,cursor:one.nextCursor!}),code('EDITOR_CURSOR_STALE'));await assert.rejects(()=>getDesignEditorNodes(f.env,'u','p',{versionId:version,templateId,cursor:'broken'}),code('EDITOR_CURSOR_INVALID'));
  await assert.rejects(()=>getDesignEditorView(f.env,'other','p',{versionId:version}),code('NOT_FOUND'));await assert.rejects(()=>getDesignEditorNodes(f.env,'u','p2',{versionId:version,templateId}),code('NOT_FOUND'));
 }finally{f.db.close();}
});

test('restore creates a new immutable version and replay never moves a newer head backwards',async()=>{
 const f=mediaFixture();try{const manifest=starterManifest('studio')!,v1=await first(f,manifest),changed=structuredClone(manifest);changed.templates[0].document.css+='\n.x{color:blue}';const v2=await saveVersion(f.env,'u','p',changed,'manual',v1,'second-version');const input={requestKey:'restore-idempotent-001',sourceVersionId:v1,expectedCurrentVersionId:v2};const restored=await restoreDesignVersion(f.env,'u','p',input);assert.notEqual(restored.versionId,v1);assert.equal(restored.parentVersionId,v2);assert.equal(restored.contentHash,await sha256(JSON.stringify(manifest)));assert.equal(current(f),restored.versionId);assert.equal(count(f),3);
  const newer=await saveVersion(f.env,'u','p',changed,'manual',restored.versionId,'later-design');const replay=await restoreDesignVersion(f.env,'u','p',input);assert.equal(replay.versionId,restored.versionId);assert.equal(replay.replayed,true);assert.equal(replay.currentVersionId,newer);assert.equal(current(f),newer);assert.equal(count(f),4);
  await assert.rejects(()=>restoreDesignVersion(f.env,'u','p',{...input,sourceVersionId:v2}),code('IDEMPOTENCY_CONFLICT'));await assert.rejects(()=>restoreDesignVersion(f.env,'u','p',{...input,expectedCurrentVersionId:newer}),code('IDEMPOTENCY_CONFLICT'));assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='design.version_restored'").get()!.n,1);
 }finally{f.db.close();}
});

test('large restoration reuses verified immutable R2 pointers and recovers a lost commit acknowledgement',async()=>{
 const f=mediaFixture();try{const manifest=largeManifest(3*MIB),version=await first(f,manifest),row=f.db.sqlite.prepare('SELECT * FROM design_versions WHERE id=?').get(version)!,puts=f.storage.puts,batch=f.db.batch.bind(f.db);let injected=false;
  (f.db as any).batch=async(statements:any[])=>{const result=await batch(statements);if(!injected&&statements.some(s=>String(s.sql).includes('INSERT INTO design_restore_requests'))){injected=true;throw new Error('Lost committed acknowledgement');}return result;};
  const input={requestKey:'restore-large-unknown-001',sourceVersionId:version,expectedCurrentVersionId:version},result=await restoreDesignVersion(f.env,'u','p',input);assert.equal(result.replayed,true);assert.equal(f.storage.puts,puts);const restored=f.db.sqlite.prepare('SELECT * FROM design_versions WHERE id=?').get(result.versionId)!;assert.equal(restored.manifest_object_id,row.manifest_object_id);assert.equal(restored.manifest_json,row.manifest_json);assert.equal(restored.content_hash,row.content_hash);assert.equal(count(f),2);assert.equal((await restoreDesignVersion(f.env,'u','p',input)).versionId,result.versionId);assert.equal(count(f),2);
 }finally{f.db.close();}
});

test('source corruption, stale head, ownership and missing source assets cannot be restored',async()=>{
 const f=mediaFixture();try{const asset=await saveMedia(f.env,'u','p',{bytes:png(),fileName:'keep.png',requestKey:'restore-source-image'}),manifest=largeManifest(1100000);manifest.assets=[{file:'assets/0.png',path:asset.assetPath,sha256:asset.sha256,size:asset.byteSize}];const version=await first(f,manifest),input={requestKey:'restore-invalid-source-001',sourceVersionId:version,expectedCurrentVersionId:version};
  await assert.rejects(()=>restoreDesignVersion(f.env,'other','p',input),code('NOT_FOUND'));await assert.rejects(()=>restoreDesignVersion(f.env,'u','p2',{...input,expectedCurrentVersionId:null}),code('NOT_FOUND'));await assert.rejects(()=>restoreDesignVersion(f.env,'u','p',{...input,expectedCurrentVersionId:null}),code('VERSION_CONFLICT'));
  const object=f.db.sqlite.prepare('SELECT object_key FROM design_manifest_objects').get()!,key=String(object.object_key),original=f.storage.objects.get(key)!;f.storage.objects.set(key,new Uint8Array(original.length));await assert.rejects(()=>restoreDesignVersion(f.env,'u','p',input),code('DESIGN_STORAGE_CORRUPT'));f.storage.objects.set(key,original);
  const media=f.db.sqlite.prepare('SELECT object_key FROM project_media').get()!;f.storage.objects.delete(String(media.object_key));await assert.rejects(()=>restoreDesignVersion(f.env,'u','p',input));assert.equal(count(f),1);assert.equal(current(f),version);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_restore_requests').get()!.n,0);
 }finally{f.db.close();}
});

test('restore commit rechecks archive, login restriction and media state after asynchronous verification',async()=>{
 for(const mutation of ['archive','login','media'] as const){const f=mediaFixture();try{const asset=await saveMedia(f.env,'u','p',{bytes:png(),fileName:'keep.png',requestKey:'race-source-image'}),manifest=starterManifest('studio')!;manifest.assets=[{file:'assets/0.png',path:asset.assetPath,sha256:asset.sha256,size:asset.byteSize}];const version=await first(f,manifest),batch=f.db.batch.bind(f.db);let injected=false;
   (f.db as any).batch=async(statements:any[])=>{if(!injected&&statements.some(s=>String(s.sql).includes('INSERT INTO design_restore_requests'))){injected=true;if(mutation==='archive')f.db.sqlite.prepare("UPDATE projects SET archived_at='2026-01-01' WHERE id='p'").run();else if(mutation==='login')f.db.sqlite.prepare("INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,actor_id,created_at) VALUES('blocked','u','login','test','2020-01-01','u','2020-01-01')").run();else f.db.sqlite.prepare("UPDATE project_media SET state='deleted',deleted_at='2026-01-01' WHERE id=?").run(asset.id);}return batch(statements);};
   await assert.rejects(()=>restoreDesignVersion(f.env,'u','p',{requestKey:'restore-race-'+mutation+'-001',sourceVersionId:version,expectedCurrentVersionId:version}),code('VERSION_CONFLICT'));assert.equal(count(f),1);assert.equal(current(f),version);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM design_restore_requests').get()!.n,0);
  }finally{f.db.close();}}
});

test('heavy admission refuses concurrent work without fetching source; cached view and committed restore replay remain small',async()=>{
 const f=mediaFixture();try{const manifest=largeManifest(1100000),version=await first(f,manifest);await getDesignEditorView(f.env,'u','p',{versionId:version});const request={requestKey:'restore-budget-replay',sourceVersionId:version,expectedCurrentVersionId:version},result=await restoreDesignVersion(f.env,'u','p',request),gets=f.storage.gets;
  await withDesignMemoryBudget(async()=>{assert.equal((await getDesignEditorView(f.env,'u','p',{versionId:version})).sourceId,version);assert.equal((await restoreDesignVersion(f.env,'u','p',request)).versionId,result.versionId);await assert.rejects(()=>getDesignEditorNodes(f.env,'u','p',{versionId:version,templateId:1}),code('DESIGN_MEMORY_BUSY'));await assert.rejects(()=>restoreDesignVersion(f.env,'u','p',{requestKey:'restore-new-budget-busy',sourceVersionId:version,expectedCurrentVersionId:result.versionId}),code('DESIGN_MEMORY_BUSY'));});assert.equal(f.storage.gets,gets);
 }finally{f.db.close();}
});

test('HTTP projection/node/restore boundaries enforce auth, CSRF and bounded queries',async()=>{
 const f=mediaFixture();try{const version=await first(f),now=new Date().toISOString(),token='projection-session'.padEnd(43,'x');f.db.sqlite.prepare('INSERT INTO sessions(id,user_id,token_hash,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('ses','u',await sha256(token),'csrf',now,'2099-01-01T00:00:00.000Z','test');
  const app=new Hono<App>();app.route('/api/design',designEditorRoutes);app.onError((error,c)=>c.json({error:{code:error instanceof AppError?error.code:'INTERNAL'}},(error instanceof AppError?error.status:500) as 400));
  const call=(path:string,method='GET',data?:unknown,auth=true,csrf=true)=>app.request('/api/design/projects/p'+path,{method,headers:{'content-type':'application/json',...(auth?{cookie:'benos_session='+token}:{}),...(csrf?{'X-CSRF-Token':'csrf'}:{})},body:data?JSON.stringify(data):undefined},f.env);
  assert.equal((await call('/editor-view?version='+version,'GET',undefined,false)).status,401);assert.equal((await call('/editor-view?version='+version+'&candidate=x')).status,400);assert.equal((await call('/editor-nodes?version='+version+'&templateId=1&limit=201')).status,400);assert.equal((await call('/editor-nodes?version='+version+'&templateId=1&nodeKey=n0')).status,200);
  const input={requestKey:'restore-http-test-001',sourceVersionId:version,expectedCurrentVersionId:version};assert.equal((await call('/restore','POST',input,true,false)).status,403);const response=await call('/restore','POST',input);assert.equal(response.status,201);assert.ok((await response.json() as any).data.versionId);
 }finally{f.db.close();}
});


test('maximum template/page selectors and a near-8 MiB document remain below the separate 256 KiB projection bound',async()=>{
 const f=mediaFixture();try{const manifest=starterManifest('studio')!;
  while(manifest.templates.length<72){const n=manifest.templates.length+1;manifest.templates.push({...structuredClone(manifest.templates[0]),id:n,name:'模板'.repeat(90),document:{version:1,html:'<section><h1>Page '+n+'</h1></section>',css:''}});}
  for(const template of manifest.templates)template.name='模板'.repeat(90);
  while(manifest.site.pages.length<64){const n=manifest.site.pages.length;manifest.site.pages.push({...structuredClone(manifest.site.pages[1]),key:'page-'+n,slug:'页'.repeat(170)+n,title:'标题'.repeat(120),template_id:8+n});}
  const document=manifest.templates[0].document;document.html='<section><h1>Visible</h1><div hidden>'+('x'.repeat(8*MIB-500))+'</div></section>';document.css='';
  const version=await first(f,manifest),view=await getDesignEditorView(f.env,'u','p',{versionId:version}),bytes=new TextEncoder().encode(JSON.stringify(view)).length;
  assert.equal(view.templates.length,72);assert.equal(view.site.pages.length,64);assert.ok(bytes>128*1024&&bytes<256*1024,'Legitimate long selectors must not be rejected by a narrower old cache bound');
  const node=await getDesignEditorNodes(f.env,'u','p',{versionId:version,templateId:1,nodeKey:'n1'});assert.equal(node.items[0].label,'Visible');assert.ok(JSON.stringify(node).length<1000);
 }finally{f.db.close();}
});

test('restore rechecks a newer head at commit and a lost successful response cannot rewind a later committed version',async()=>{
 const f=mediaFixture();try{const source=await first(f),batch=f.db.batch.bind(f.db);let intercepted=false;
  (f.db as any).batch=async(statements:any[])=>{const result=await batch(statements);if(!intercepted&&statements.some(s=>String(s.sql).includes('INSERT INTO design_restore_requests'))){intercepted=true;const head=String(current(f));f.db.sqlite.prepare("INSERT INTO design_versions(id,project_id,parent_id,version,source,manifest_json,manifest_object_id,content_hash,created_by,created_at) SELECT 'ver_later','p',?,version+1,'manual',manifest_json,manifest_object_id,content_hash,'u',created_at FROM design_versions WHERE id=?").run(head,head);f.db.sqlite.prepare("UPDATE projects SET current_version_id='ver_later' WHERE id='p'").run();throw new Error('Lost acknowledgement after another writer committed');}return result;};
  const input={requestKey:'restore-interleaved-001',sourceVersionId:source,expectedCurrentVersionId:source},result=await restoreDesignVersion(f.env,'u','p',input);assert.equal(result.currentVersionId,'ver_later');assert.notEqual(result.versionId,'ver_later');assert.equal(current(f),'ver_later');assert.equal(count(f),3);assert.equal((await restoreDesignVersion(f.env,'u','p',input)).currentVersionId,'ver_later');assert.equal(count(f),3);
 }finally{f.db.close();}
});
