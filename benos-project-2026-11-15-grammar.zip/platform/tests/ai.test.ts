import test from 'node:test';
import assert from 'node:assert/strict';
import { TestD1,testEnv } from './d1-helper';
import { createGeneration,usageCost,saveVersion } from '../src/modules/ai';
import { encryptSecret } from '../src/lib/crypto';
import { grantCredit,fundProvider,getWallet } from '../src/modules/ledger';
import example from '../src/contracts/site-example.json';
import { seedCapabilityFixture } from './integration-test-helper';

const pricing={baseUrl:'https://api.openai.com/v1',model:'gpt-6.1-sol',protocol:'responses' as const,providerPoolId:'openai-main',inputMicrosPerMillion:2_000_000,cachedInputMicrosPerMillion:100_000,outputMicrosPerMillion:10_000_000,contextTokens:1050000,maxOutputTokens:10000,billingProfile:'openai-gpt6-standard-2026-11-07' as const,cacheTtl:'30m' as const,pricingConfirmedAt:new Date().toISOString()};
async function fixture(balance=16_250_000){const db=new TestD1(),env=testEnv(db),now=new Date().toISOString();
 db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run('u','u@example.test','U','test','user',now,now);
 db.sqlite.prepare('INSERT INTO projects(id,user_id,name,created_at,updated_at) VALUES(?,?,?,?,?)').run('p','u','企业网站',now,now);
 const encrypted=await encryptSecret(JSON.stringify({apiKey:'sk-fixture-only'}),env.ENCRYPTION_KEY,'cfg');
 db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('cfg','text','AI','openai',1,'active',?,?,'passed','u',?)").run(JSON.stringify(pricing),encrypted,now);
 if(balance)await grantCredit(env.DB,{id:'g',userId:'u',source:'topup',amountMicros:balance,referenceId:'receipt'});
 await fundProvider(env.DB,{id:'f',providerId:'openai-main',amountMicros:100_000_000,referenceId:'deposit'});
 await seedCapabilityFixture(env.DB,'cfg');
 return {db,env};
}
const output=(manifest:unknown=example)=>({id:'resp_fixture',model:pricing.model,service_tier:'default',status:'completed',usage:{input_tokens:100,output_tokens:20,input_tokens_details:{cached_tokens:50,cache_write_tokens:0,cache_write_tokens_details:{ttl_30m_tokens:0,ttl_12h_tokens:0}}},output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(manifest)}]}]});
function adapter(generation:(request:RequestInit|undefined)=>Response|Promise<Response>){return async(url:any,init?:RequestInit)=>String(url).endsWith('/input_tokens')?new Response(JSON.stringify({object:'response.input_tokens',input_tokens:100})):generation(init);}
test('generation reserves both pools before paid dispatch, settles cached cost and saves an immutable valid version',async()=>{
 const f=await fixture();try{let calls=0;
 const send=adapter(init=>{calls++;const pool=f.db.sqlite.prepare('SELECT * FROM provider_pools').get()!;assert.equal(pool.reserved_micros,5400000);assert.equal(f.db.sqlite.prepare('SELECT state FROM api_reservations').get()!.state,'dispatching');const payload=JSON.parse(String(init?.body));assert.match(payload.instructions,/本接口没有 foundation/);assert.match(payload.instructions,/新站必须在输出中包含完整、自包含/);assert.equal(payload.store,false);assert.equal(payload.max_output_tokens,10000);assert.equal(payload.service_tier,'default');assert.equal(payload.tools,undefined);return new Response(JSON.stringify(output()));});
 const job=await createGeneration(f.env,'u','p',{prompt:'创建企业网站',requestKey:'request-create-one'}, {fetch:send});assert.equal(job.state,'succeeded');assert.ok(job.result_version_id);assert.equal(calls,1);
 const wallet=await getWallet(f.env.DB,'u');assert.equal(wallet.consumedMicros,305);assert.equal(wallet.heldMicros,0);
 const replay=await createGeneration(f.env,'u','p',{prompt:'创建企业网站',requestKey:'request-create-one'}, {fetch:send});assert.equal(replay.id,job.id);assert.equal(calls,1);
 await assert.rejects(()=>createGeneration(f.env,'u','p',{prompt:'不同内容',requestKey:'request-create-one'},{fetch:send}),/该请求编号/);
 assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) count FROM design_versions').get()!.count,1);
 }finally{f.db.close();}
});
test('insufficient user budget prevents any paid HTTP request and does not reserve provider money',async()=>{
 const f=await fixture(1);try{let calls=0;const job=await createGeneration(f.env,'u','p',{prompt:'创建网站',requestKey:'request-low-funds'},{fetch:adapter(()=>{calls++;return new Response(JSON.stringify(output()));})});assert.equal(job.error_code,'INSUFFICIENT_CREDIT');assert.equal(job.state,'failed');assert.equal(calls,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,0);}finally{f.db.close();}
});
test('concurrent duplicate requests send once and uncertain network results retain both holds',async()=>{
 const f=await fixture();try{let calls=0;const send=adapter(()=>{calls++;throw new Error('Network acknowledgement lost, secret must not be reflected');});const request={prompt:'设计网站',requestKey:'request-concurrent-one'};
 const results=await Promise.all([createGeneration(f.env,'u','p',request,{fetch:send}),createGeneration(f.env,'u','p',request,{fetch:send})]);assert.equal(results[0].id,results[1].id);assert.equal(calls,1);const row=f.db.sqlite.prepare('SELECT * FROM ai_jobs').get()!;assert.equal(row.state,'uncertain');assert.equal(row.error_code,'AI_PROVIDER_UNCERTAIN');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,5400000);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,5400000);
 }finally{f.db.close();}
});
test('invalid templates settle known cost without overwriting the last valid project version',async()=>{
 const f=await fixture();try{const job=await createGeneration(f.env,'u','p',{prompt:'设计网站',requestKey:'request-invalid-one'},{fetch:adapter(()=>new Response(JSON.stringify(output({format:'malicious',html:'<script>bad()</script>'}))))});assert.equal(job.state,'failed');assert.equal(job.error_code,'TEMPLATE_INVALID');assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,305);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare('SELECT current_version_id FROM projects').get()!.current_version_id,null);assert.ok(f.db.sqlite.prepare('SELECT response_json FROM ai_jobs').get()!.response_json);}finally{f.db.close();}
});
test('unknown billing modes or missing usage remain held; integer pricing rejects nonsensical usage',async()=>{
 const f=await fixture();try{const value=output();delete (value as any).usage;const job=await createGeneration(f.env,'u','p',{prompt:'设计网站',requestKey:'request-usage-missing'},{fetch:adapter(()=>new Response(JSON.stringify(value)))});assert.equal(job.state,'uncertain');assert.equal(job.error_code,'AI_USAGE_INVALID');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,5400000);
 assert.throws(()=>usageCost(pricing,{input_tokens:1,output_tokens:1,input_tokens_details:{cached_tokens:2}}));assert.throws(()=>usageCost(pricing,{input_tokens:1,output_tokens:10001}));assert.equal(usageCost(pricing,{input_tokens:1,output_tokens:0,input_tokens_details:{cached_tokens:1,cache_write_tokens:0}}),1);
 }finally{f.db.close();}
});
test('version updates preserve history and prevent stale writers from replacing a newer version',async()=>{
 const f=await fixture();try{const first=await saveVersion(f.env,'u','p',example,'manual',null,'r');await assert.rejects(()=>saveVersion(f.env,'u','p',example,'manual',null,'r2'),/较新版本/);const second=await saveVersion(f.env,'u','p',example,'manual',first,'r3');assert.notEqual(first,second);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) count FROM design_versions').get()!.count,2);assert.equal(f.db.sqlite.prepare('SELECT current_version_id FROM projects').get()!.current_version_id,second);}finally{f.db.close();}
});

