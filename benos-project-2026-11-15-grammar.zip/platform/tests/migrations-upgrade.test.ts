import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync,readdirSync } from 'node:fs';
import { join } from 'node:path';

test('upgrade from the published eight-migration baseline preserves existing users, balances and published snapshots',()=>{
 const db=new DatabaseSync(':memory:'),files=readdirSync('migrations').filter(n=>n.endsWith('.sql')).sort(),now='2026-11-07T00:00:00.000Z';
 try{
  for(const file of files.filter(name=>name<'0009'))db.exec(readFileSync(join('migrations',file),'utf8'));
  db.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run('existing','existing@example.test','Existing','unchanged-password-hash','owner',now,now);
  db.prepare("INSERT INTO credit_grants(id,user_id,source,reference_id,amount_micros,consumed_micros,reserved_micros,starts_at_ms,spend_priority,created_at_ms) VALUES('grant','existing','topup','receipt',6500000,500000,1000000,0,2,0)").run();
  db.prepare("INSERT INTO provider_pools(provider_id,funded_micros,consumed_micros,reserved_micros,updated_at_ms) VALUES('openai',100000000,500000,1000000,0)").run();
  db.prepare("INSERT INTO provider_funding(id,provider_id,reference_id,amount_micros,created_at_ms) VALUES('fund','openai','upstream-receipt',100000000,0)").run();
  const published=JSON.stringify({title:'Live title',slug:'live-slug',body:'Existing body'});
  db.prepare("INSERT INTO content_entries(id,kind,slug,title,draft_json,published_json,state,created_by,created_at,updated_at,published_at) VALUES('content','post','draft-slug','Draft title',?,?,'published','existing',?,?,?)").run(JSON.stringify({title:'Draft title',slug:'draft-slug',body:'Draft'}),published,now,now,now);
  for(const file of files.filter(name=>name>='0009'))db.exec(readFileSync(join('migrations',file),'utf8'));
  const grant=db.prepare('SELECT * FROM credit_grants').get()!;assert.equal(grant.amount_micros,6500000);assert.equal(grant.consumed_micros,500000);assert.equal(grant.reserved_micros,1000000);assert.equal(grant.reversed_micros,0);
  assert.equal(db.prepare('SELECT funded_micros FROM provider_pools').get()!.funded_micros,100000000);assert.equal(db.prepare('SELECT password_hash FROM users').get()!.password_hash,'unchanged-password-hash');
  assert.equal(db.prepare('SELECT published_json FROM content_entries').get()!.published_json,published);
  assert.throws(()=>db.prepare('UPDATE credit_grants SET reversed_micros=5000001').run(),/ledger_grant_reversal_balance/);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM financial_cases').get()!.n,0);
 }finally{db.close();}
});
