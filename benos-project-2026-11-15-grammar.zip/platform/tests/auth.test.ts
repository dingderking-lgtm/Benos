import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';
import { publishTestPolicies } from './policy-fixture';

test('bootstrap is one-time; sessions, CSRF, ownership and roles are server-controlled',async()=>{
 const db=new TestD1(),env=testEnv(db);
 const call=async(path:string,method='GET',data?:unknown,cookie?:string,csrf?:string,origin=env.APP_ORIGIN)=>{
   const headers:Record<string,string>={origin};if(data)headers['content-type']='application/json';if(cookie)headers.cookie=cookie;if(csrf)headers['x-csrf-token']=csrf;
   return app.fetch(new Request(env.APP_ORIGIN+path,{method,headers,body:data?JSON.stringify(data):undefined}),env);
 };
 try {
  assert.equal((await call('/api/projects')).status,401);
  assert.equal((await call('/api/bootstrap','POST',{token:'wrong',email:'owner@example.test',password:'secure-test-password',name:'Owner'})).status,403);
  const ownerRes=await call('/api/bootstrap','POST',{token:env.BOOTSTRAP_TOKEN,email:'owner@example.test',password:'secure-test-password',name:'Owner'});
  assert.equal(ownerRes.status,201);const owner=(await ownerRes.json()) as any, ownerCookie=ownerRes.headers.get('set-cookie')!.split(';')[0];
  assert.equal(owner.data.user.role,'owner');assert.equal(owner.data.user.password_hash,undefined);
  assert.equal((await call('/api/bootstrap','POST',{token:env.BOOTSTRAP_TOKEN,email:'second@example.test',password:'secure-test-password',name:'Other'})).status,409);
   publishTestPolicies(db);
   const reg=await call('/api/auth/register','POST',{email:'user@example.test',password:'secure-test-password',name:'用户',role:'owner'});
  assert.equal(reg.status,201);const user=(await reg.json()) as any,userCookie=reg.headers.get('set-cookie')!.split(';')[0];
  assert.equal(user.data.user.role,'user');
  assert.equal((await call('/api/projects','POST',{name:'未经CSRF的项目'},userCookie)).status,403);
  assert.equal((await call('/api/projects','POST',{name:'跨站项目'},userCookie,user.data.csrfToken,'https://attacker.example')).status,403);
  const created=await call('/api/projects','POST',{name:'我的企业网站',description:'用户需求',status:'published'},userCookie,user.data.csrfToken);
  assert.equal(created.status,201);const project=(await created.json()) as any;assert.equal(project.data.status,'draft');
  assert.equal((await call('/api/projects/'+project.data.id,'GET',undefined,ownerCookie)).status,404);
  const list=(await (await call('/api/projects','GET',undefined,userCookie)).json()) as any;assert.equal(list.data.items.length,1);
  assert.equal((await call('/api/auth/logout','POST',{},userCookie,user.data.csrfToken)).status,200);
  assert.equal((await call('/api/projects','GET',undefined,userCookie)).status,401);
  const login=await call('/api/auth/login','POST',{email:'USER@example.test',password:'secure-test-password'});assert.equal(login.status,200);
  assert.equal((await call('/api/auth/login','POST',{email:'user@example.test',password:'wrong-but-long-password'})).status,401);
  const pass=db.sqlite.prepare('SELECT password_hash FROM users WHERE email=?').get('user@example.test')!.password_hash as string;
  assert.ok(pass.startsWith('pbkdf2-sha256$'));assert.ok(!pass.includes('secure-test-password'));
 }finally{db.close();}
});

test('auth rate limit blocks account brute force and raw sensitive errors never escape',async()=>{
 const db=new TestD1(),env=testEnv(db);
 try {
  let last:Response|undefined;
  for(let i=0;i<12;i++)last=await app.fetch(new Request(env.APP_ORIGIN+'/api/auth/login',{method:'POST',headers:{origin:env.APP_ORIGIN,'content-type':'application/json'},body:JSON.stringify({email:'none@example.test',password:'long-enough-wrong-password'})}),env);
  assert.equal(last!.status,429);
  const response=await app.fetch(new Request(env.APP_ORIGIN+'/api/bootstrap',{method:'POST',headers:{origin:env.APP_ORIGIN,'content-type':'application/json'},body:'not JSON secret-data'}),env);
  assert.equal(response.status,400);assert.ok(!(await response.text()).includes('secret-data'));
 }finally{db.close();}
});

test('portable auth ignores forged Sites headers; trusted server adapter can initialize only its verified owner email',async()=>{
 const db=new TestD1(),env=testEnv(db);delete env.BOOTSTRAP_TOKEN;
 const request=(email:string)=>new Request(env.APP_ORIGIN+'/api/bootstrap',{method:'POST',headers:{origin:env.APP_ORIGIN,'content-type':'application/json','oai-authenticated-user-id':'forged','oai-authenticated-user-email':email},body:JSON.stringify({email,name:'Owner',password:'secure-test-password'})});
 try{
  assert.equal((await app.fetch(request('owner@example.test'),env)).status,403);
  env.VERIFIED_BOOTSTRAP_EMAIL='owner@example.test';
  assert.equal((await app.fetch(request('attacker@example.test'),env)).status,403);
  assert.equal((await app.fetch(request('owner@example.test'),env)).status,201);
  assert.equal((await app.fetch(request('owner@example.test'),env)).status,409);
 }finally{db.close();}
});
