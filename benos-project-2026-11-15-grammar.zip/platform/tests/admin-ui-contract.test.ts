// P6.B backend admin fixes: the contract the new admin console relies on.
// - invalid list filters return 400 VALIDATION (never 500)
// - marketing media uploads accept up to 12 MiB
// - integration views carry a masked secretHint, never the secret
// - revenue series from paid orders only (no invented cost), role-gated
// - member list carries tier + availableMicros from one SQL statement
import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { deflateSync,crc32 } from 'node:zlib';
import { app } from '../src/index';
import { TestD1,testEnv } from './d1-helper';
import { FakeR2,png } from './media-helper';
import { sha256,randomToken } from '../src/lib/crypto';
import { AppError } from '../src/lib/errors';
import { searchMembers,revenueSeries,revenueBucketCount,revenueOrdersSql } from '../src/modules/admin-operations';
import { secretHint } from '../src/modules/integrations';
import { getWallet,grantCredit,fundProvider,reserve,claimReservation } from '../src/modules/ledger';
import { activeSubscription } from '../src/modules/commerce';
import { DEFAULT_CATALOG } from '../src/modules/billing-catalog';

type Session={cookie:string;csrf:string};
const ROLES=[['owner','owner'],['admin','admin'],['support','support'],['editor','editor'],['u','user'],['other','user']] as const;
async function fixture(){
 const db=new TestD1(),env=testEnv(db),storage=new FakeR2(),iso=new Date().toISOString(),expires=new Date(Date.now()+3600_000).toISOString();env.BUCKET=storage as unknown as R2Bucket;
 const sessions:Record<string,Session>={};
 for(const [id,role] of ROLES){db.sqlite.prepare('INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(id,id+'@example.test',id,'fixture',role,iso,iso);
  const token=randomToken(),csrf=randomToken();db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run('ses_'+id,await sha256(token),id,csrf,iso,expires,'fixture');sessions[id]={cookie:'benos_session='+token,csrf};}
 const request=(path:string,init:{method?:string;data?:unknown;as?:string;headers?:Record<string,string>;body?:BodyInit}={})=>{const s=init.as?sessions[init.as]:undefined;
  return app.fetch(new Request(env.APP_ORIGIN+path,{method:init.method??(init.data!==undefined||init.body!==undefined?'POST':'GET'),headers:{origin:env.APP_ORIGIN,...(init.data!==undefined?{'content-type':'application/json'}:{}),...(s?{cookie:s.cookie,'x-csrf-token':s.csrf}:{}),...init.headers},body:init.data!==undefined?JSON.stringify(init.data):init.body,...(init.body instanceof ReadableStream?{duplex:'half'}:{})} as RequestInit),env);};
 return {db,env,storage,sessions,request};
}
async function json(res:Response){return await res.json() as any;}
function bigPng(width:number,height:number){
 const chunk=(type:string,data:Uint8Array)=>{const out=Buffer.alloc(data.length+12);out.writeUInt32BE(data.length,0);out.write(type,4);out.set(data,8);out.writeUInt32BE(crc32(out.subarray(4,-4)),out.length-4);return out;};
 const header=Buffer.alloc(13);header.writeUInt32BE(width,0);header.writeUInt32BE(height,4);header[8]=8;header[9]=6;
 const pixels=randomBytes(height*(width*4+1));for(let row=0;row<height;row++)pixels[row*(width*4+1)]=0;
 return new Uint8Array(Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(pixels,{level:0})),chunk('IEND',Buffer.alloc(0))]));
}

// ---------------------------------------------------------------- item 1
test('invalid admin list filters return 400 VALIDATION with a Chinese message and requestId, valid ones still work',async()=>{
 const f=await fixture();try{
  const bad=['/api/admin/operations/members?limit=500','/api/admin/operations/members?role=god','/api/admin/operations/members?tier=gold','/api/admin/operations/members?page=0',
   '/api/admin/operations/orders?kind=gift','/api/admin/operations/orders?state=done','/api/admin/operations/orders?limit=abc',
   '/api/admin/operations/usage?from=yesterday','/api/admin/operations/usage?state=lost','/api/admin/operations/usage?from=2026-11-08T00:00:00.000Z&to=2026-11-07T00:00:00.000Z',
   '/api/admin/operations/audit?from=2026-13-01','/api/admin/operations/audit?limit=101','/api/admin/operations/audit/export?page=-1',
   '/api/admin/operations/members/u/adjustments?limit=0','/api/admin/operations/members/u/adjustments?page=x',
   '/api/admin/budget-reviews?page=0','/api/admin/budget-reviews?page=abc','/api/admin/budget-reviews?page=10001',
   '/api/ai/admin/workflow-steps?state=bogus','/api/ai/admin/workflow-steps?limit=101',
   '/api/admin/operations/revenue?bucket=week','/api/admin/operations/revenue?from=2026-11-01','/api/admin/operations/revenue?mode=sandbox'];
  for(const path of bad){const res=await f.request(path,{as:'owner'}),body=await json(res);
   assert.equal(res.status,400,path);assert.equal(body.ok,false,path);assert.equal(body.error.code,'VALIDATION',path);assert.match(body.error.message,/[一-鿿]/,path);assert.match(body.error.requestId,/^req_/,path);}
  const good=['/api/admin/operations/members?limit=100&role=user&tier=none&status=active','/api/admin/operations/orders?kind=topup&state=paid&limit=5','/api/admin/operations/usage?from=2026-11-01T00:00:00.000Z&to=2026-11-07T00:00:00.000Z&state=settled',
   '/api/admin/operations/audit?limit=5','/api/admin/operations/members/u/adjustments?page=1&limit=5','/api/admin/budget-reviews?page=1','/api/admin/budget-reviews','/api/ai/admin/workflow-steps?state=uncertain&limit=50','/api/admin/operations/revenue?bucket=month'];
  for(const path of good)assert.equal((await f.request(path,{as:'owner'})).status,200,path);
 }finally{f.db.close();}
});
test('an invalid audit export filter is rejected before it consumes the 10-per-hour export allowance',async()=>{
 const f=await fixture();try{
  const hour=()=>Math.floor(Date.now()/3600_000),window=hour();
  for(let n=0;n<12;n++)assert.equal((await f.request('/api/admin/operations/audit/export?from=bad',{as:'owner'})).status,400);
  // from > to is a filter error too: it must be refused before the allowance is counted.
  for(let n=0;n<12;n++){const res=await f.request('/api/admin/operations/audit/export?from=2026-11-08T00:00:00.000Z&to=2026-11-07T00:00:00.000Z',{as:'owner'}),body=await json(res);assert.equal(res.status,400,'attempt '+n);assert.equal(body.error.code,'VALIDATION');assert.equal(body.error.message,'开始时间不能晚于结束时间');}
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='audit.exported'").get()!.n,0);
  const res=await f.request('/api/admin/operations/audit/export?action=user.login',{as:'owner'});assert.equal(res.status,200);assert.match(res.headers.get('content-type')||'',/text\/csv/);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='audit.exported'").get()!.n,1);
  // The allowance itself still holds: 10 exports per hour, the 11th is refused
  // (skipped only if the clock crossed into a new hourly window during the test).
  for(let n=0;n<9;n++)assert.equal((await f.request('/api/admin/operations/audit/export',{as:'owner'})).status,200);
  const eleventh=await f.request('/api/admin/operations/audit/export',{as:'owner'});if(hour()===window)assert.equal(eleventh.status,429);
 }finally{f.db.close();}
});
test('audit time filters compare instants, so the same moment spelled with or without milliseconds is accepted and matched',async()=>{
 const f=await fixture();try{
  const row=(id:string,at:string)=>f.db.sqlite.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,details_json,request_id,created_at) VALUES(?,'owner','fixture.event','fixture',?,'{}','req_fixture',?)").run(id,id,at);
  row('audit_before','2026-11-06T23:59:59.999Z');row('audit_start','2026-11-07T00:00:00.000Z');row('audit_mid','2026-11-07T12:00:00.500Z');row('audit_end','2026-11-08T00:00:00.000Z');row('audit_after','2026-11-08T00:00:00.001Z');
  const ids=async(query:string)=>{const res=await f.request('/api/admin/operations/audit?action=fixture.event&'+query,{as:'owner'});assert.equal(res.status,200,query);return (await json(res)).data.items.map((i:any)=>i.id).sort();};
  assert.deepEqual(await ids('from=2026-11-07T00:00:00Z&to=2026-11-08T00:00:00Z'),['audit_end','audit_mid','audit_start']);
  assert.deepEqual(await ids('from=2026-11-07T00:00:00.000Z&to=2026-11-08T00:00:00.000Z'),['audit_end','audit_mid','audit_start']);
  assert.deepEqual(await ids('from=2026-11-07T00:00:00Z&to=2026-11-07T00:00:00.000Z'),['audit_start'],'equal instants in two spellings are a valid range');
  const csv=await f.request('/api/admin/operations/audit/export?action=fixture.event&from=2026-11-07T00:00:00Z&to=2026-11-07T00:00:00.000Z',{as:'owner'});assert.equal(csv.status,200);const text=await csv.text();assert.ok(text.includes('audit_start')&&!text.includes('audit_mid'));
 }finally{f.db.close();}
});
test('catalog create/activate enforce reason and requestKey rules as 400 (not 500) and stay idempotent',async()=>{
 const f=await fixture();try{
  const create=(data:unknown,as='owner')=>f.request('/api/admin/operations/catalog',{data,as});
  for(const input of [{catalog:DEFAULT_CATALOG,reason:'ab',requestKey:'catalog-request-key-001'},{catalog:DEFAULT_CATALOG,reason:'   x   ',requestKey:'catalog-request-key-001'},{catalog:DEFAULT_CATALOG,reason:'价格调整原因',requestKey:'short'},{catalog:DEFAULT_CATALOG,reason:'价格调整原因',requestKey:'含中文的请求编号含中文的请求编号'},{catalog:DEFAULT_CATALOG,reason:'x'.repeat(501),requestKey:'catalog-request-key-001'}]){
   const res=await create(input),body=await json(res);assert.equal(res.status,400);assert.equal(body.error.code,'VALIDATION');assert.match(body.error.message,/[一-鿿]/);}
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM billing_catalog_versions').get()!.n,0);
  assert.equal((await create({catalog:DEFAULT_CATALOG,reason:'价格调整原因',requestKey:'catalog-request-key-001'},'admin')).status,403);
  const first=await create({catalog:DEFAULT_CATALOG,reason:'价格调整原因',requestKey:'catalog-request-key-001'});assert.equal(first.status,201);const {id}=(await json(first)).data;
  const retry=await create({catalog:DEFAULT_CATALOG,reason:'价格调整原因',requestKey:'catalog-request-key-001'});assert.equal(retry.status,201);assert.equal((await json(retry)).data.id,id);
  const changed=structuredClone(DEFAULT_CATALOG);changed.go.priceCents=2600;
  const conflict=await create({catalog:changed,reason:'价格调整原因',requestKey:'catalog-request-key-001'});assert.equal(conflict.status,409);assert.equal((await json(conflict)).error.code,'IDEMPOTENCY_CONFLICT');
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM billing_catalog_versions').get()!.n,1);
  const current=(await json(await f.request('/api/admin/operations/catalog',{as:'owner'}))).data.current.id;
  for(const input of [{expectedVersionId:current,enabled:true,reason:'no',confirmedFutureOrdersOnly:true},{expectedVersionId:'',enabled:true,reason:'确认启用新版本',confirmedFutureOrdersOnly:true},{expectedVersionId:current,enabled:true,reason:'确认启用新版本',confirmedFutureOrdersOnly:false}]){
   const res=await f.request('/api/admin/operations/catalog/'+id+'/activate',{data:input,as:'owner'});assert.equal(res.status,400);assert.equal((await json(res)).error.code,'VALIDATION');}
  // Missing, wrong-type and unknown fields get a Chinese message too (never zod's English text).
  const chinese=async(res:Response,expected:string|RegExp,label:string)=>{const body=await json(res);assert.equal(res.status,400,label);assert.equal(body.error.code,'VALIDATION',label);assert.match(body.error.message,/[一-鿿]/,label);assert.doesNotMatch(body.error.message,/invalid|expected|received|unrecognized|too (small|big)/i,label);
   if(typeof expected==='string')assert.equal(body.error.message,expected,label);else assert.match(body.error.message,expected,label);};
  const key='catalog-request-key-002',badPrice=structuredClone(DEFAULT_CATALOG) as any;badPrice.go.priceCents='2500';const lowPrice=structuredClone(DEFAULT_CATALOG);lowPrice.hosting.annualPriceCents=1;
  await chinese(await create({catalog:DEFAULT_CATALOG,requestKey:key}),'请填写变更原因','create without reason');
  await chinese(await create({catalog:DEFAULT_CATALOG,reason:123,requestKey:key}),'请填写变更原因','create with a numeric reason');
  await chinese(await create({catalog:DEFAULT_CATALOG,reason:null,requestKey:key}),'请填写变更原因','create with a null reason');
  await chinese(await create({catalog:DEFAULT_CATALOG,reason:'价格调整原因'}),'缺少请求编号','create without requestKey');
  await chinese(await create({catalog:DEFAULT_CATALOG,reason:'价格调整原因',requestKey:1234567890123456}),'缺少请求编号','create with a numeric requestKey');
  await chinese(await create({reason:'价格调整原因',requestKey:key}),'请检查填写内容：catalog','create without catalog');
  await chinese(await create({catalog:badPrice,reason:'价格调整原因',requestKey:key}),'请检查填写内容：catalog.go.priceCents','create with a text price');
  await chinese(await create({catalog:lowPrice,reason:'价格调整原因',requestKey:key}),'请检查填写内容：catalog.hosting.annualPriceCents','create with an out-of-range price');
  await chinese(await create({catalog:DEFAULT_CATALOG,reason:'价格调整原因',requestKey:key,extra:true}),'提交内容包含不支持的字段','create with an unknown field');
  await chinese(await create([]),/请检查填写内容/,'create with a non-object body');
  const activate=(data:unknown)=>f.request('/api/admin/operations/catalog/'+id+'/activate',{data,as:'owner'});
  await chinese(await activate({expectedVersionId:current,enabled:true,reason:'确认启用新版本',confirmedFutureOrdersOnly:false}),'请确认此变更仅影响之后的新订单','activate unconfirmed');
  await chinese(await activate({expectedVersionId:current,enabled:true,reason:'确认启用新版本'}),'请确认此变更仅影响之后的新订单','activate without the confirmation');
  await chinese(await activate({enabled:true,reason:'确认启用新版本',confirmedFutureOrdersOnly:true}),'缺少当前版本编号','activate without expectedVersionId');
  await chinese(await activate({expectedVersionId:current,enabled:'yes',reason:'确认启用新版本',confirmedFutureOrdersOnly:true}),'请选择启用或停用','activate with a text flag');
  await chinese(await activate({expectedVersionId:current,enabled:true,confirmedFutureOrdersOnly:true}),'请填写变更原因','activate without reason');
  const notJson=await f.request('/api/admin/operations/catalog',{as:'owner',body:'reason=x',headers:{'content-type':'text/plain'}});assert.equal(notJson.status,415);
  const broken=await f.request('/api/admin/operations/catalog',{as:'owner',body:'{',headers:{'content-type':'application/json'}});assert.equal(broken.status,400);assert.equal((await json(broken)).error.code,'INVALID_JSON');
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM billing_catalog_versions').get()!.n,1,'no rejected request created a version');
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='billing.catalog_activated'").get()!.n,0);
  const activated=await f.request('/api/admin/operations/catalog/'+id+'/activate',{data:{expectedVersionId:current,enabled:true,reason:'确认启用新版本',confirmedFutureOrdersOnly:true},as:'owner'});assert.equal(activated.status,200);assert.equal((await json(activated)).data.id,id);
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='billing.catalog_activated'").get()!.n,1);
 }finally{f.db.close();}
});

// ---------------------------------------------------------------- item 2
test('marketing media accepts images over 1 MiB up to 12 MiB, idempotently, while other admin writes keep the 1 MiB cap',async()=>{
 const f=await fixture();try{
  const bytes=bigPng(640,600);assert.ok(bytes.byteLength>1024*1024&&bytes.byteLength<2*1024*1024,'fixture is between 1 and 2 MiB');
  const upload=(body:Uint8Array,key:string,as='editor')=>f.request('/api/admin/content/media',{as,body,headers:{'content-type':'image/png','x-filename':encodeURIComponent('大图.png'),'idempotency-key':key}});
  const res=await upload(bytes,'large_upload_0001'),body=await json(res);assert.equal(res.status,201,JSON.stringify(body));assert.equal(body.data.byteSize,bytes.byteLength);assert.equal(body.data.fileName,'大图.png');assert.equal(f.storage.puts,1);
  const again=await upload(bytes,'large_upload_0001');assert.equal(again.status,201);assert.equal((await json(again)).data.id,body.data.id);assert.equal(f.storage.puts,1,'a retry with the same key stores nothing new');
  const other=await upload(bigPng(640,601),'large_upload_0001');assert.equal(other.status,409);assert.equal((await json(other)).error.code,'IDEMPOTENCY_CONFLICT');
  assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='content.media.upload'").get()!.n,1);
  const tooLarge=await upload(new Uint8Array(12*1024*1024+1),'large_upload_0002');assert.equal(tooLarge.status,413);assert.equal((await json(tooLarge)).error.code,'REQUEST_TOO_LARGE');
  assert.equal((await upload(png(2,2),'support_upload_01','support')).status,403);
  const bigJson={action:'delete',items:[{id:'cmedia_'+'0'.repeat(32),revision:1}],padding:'x'.repeat(1024*1024+10)};
  const bulk=await f.request('/api/admin/content/media/bulk',{data:bigJson,as:'owner'});assert.equal(bulk.status,413,'the exception is the exact upload path only');
  const entry=await f.request('/api/admin/content',{data:{kind:'post',slug:'big',title:'big',content:{body:'x'.repeat(1024*1024+10)}},as:'owner'});assert.equal(entry.status,413);
 }finally{f.db.close();}
});
test('marketing media uploads are authenticated before the body is read, and a streamed body is still capped at 12 MiB',async()=>{
 const f=await fixture();try{
  const MiB=1024*1024;
  const stream=(parts:number)=>{const state={pulled:0,cancelled:false},body=new ReadableStream<Uint8Array>({pull(controller){if(state.pulled>=parts){controller.close();return;}state.pulled++;controller.enqueue(new Uint8Array(MiB));},cancel(){state.cancelled=true;}});return {state,body};};
  const headers={'content-type':'image/png','x-filename':'a.png','idempotency-key':'stream_upload_0001'};
  const anonymous=stream(11),denied=await f.request('/api/admin/content/media',{body:anonymous.body,headers});
  assert.equal(denied.status,401);assert.equal((await json(denied)).error.code,'UNAUTHENTICATED');assert.ok(anonymous.state.pulled<=2,'an anonymous upload is refused without buffering it (read '+anonymous.state.pulled+' of 11 MiB)');
  const support=stream(11),forbidden=await f.request('/api/admin/content/media',{as:'support',body:support.body,headers});
  assert.equal(forbidden.status,403);assert.equal((await json(forbidden)).error.code,'FORBIDDEN');assert.ok(support.state.pulled<=2,'a role without upload rights is refused without buffering it');
  const noCsrf=stream(11),csrf=await f.request('/api/admin/content/media',{body:noCsrf.body,headers:{...headers,cookie:f.sessions.editor.cookie}});
  assert.equal(csrf.status,403);assert.equal((await json(csrf)).error.code,'CSRF');assert.ok(noCsrf.state.pulled<=2);
  const foreign=stream(11),origin=await f.request('/api/admin/content/media',{as:'editor',body:foreign.body,headers:{...headers,origin:'https://evil.example'}});
  assert.equal(origin.status,403);assert.equal((await json(origin)).error.code,'ORIGIN_DENIED');assert.ok(foreign.state.pulled<=2);
  // No Content-Length (chunked): the route's own bounded read stops just past 12 MiB.
  const huge=stream(40),tooLarge=await f.request('/api/admin/content/media',{as:'editor',body:huge.body,headers}),body=await json(tooLarge);
  assert.equal(tooLarge.status,413);assert.equal(body.error.code,'REQUEST_TOO_LARGE');assert.match(body.error.message,/[一-鿿]/);assert.ok(huge.state.pulled<=14,'reading stops at the limit (read '+huge.state.pulled+' of 40 MiB)');
  assert.equal(f.storage.puts,0);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action='content.media.upload'").get()!.n,0);
  // A streamed valid image is still stored.
  const image=bigPng(640,600),chunks=[image.subarray(0,500_000),image.subarray(500_000)];
  const streamed=await f.request('/api/admin/content/media',{as:'editor',body:new ReadableStream<Uint8Array>({pull(controller){const next=chunks.shift();if(next)controller.enqueue(next);else controller.close();}}),headers});
  const saved=await json(streamed);assert.equal(streamed.status,201,JSON.stringify(saved));assert.equal(saved.data.byteSize,image.byteLength);assert.equal(f.storage.puts,1);
  // Other write routes keep the buffered 1 MiB cap for streamed bodies.
  const other=stream(3),bulk=await f.request('/api/admin/content/media/bulk',{as:'owner',body:other.body,headers:{'content-type':'application/json'}});assert.equal(bulk.status,413);assert.equal((await json(bulk)).error.code,'REQUEST_TOO_LARGE');
 }finally{f.db.close();}
});

// ---------------------------------------------------------------- item 3
test('secretHint is computed once from the primary credential and is the only part of a secret ever returned',()=>{
 assert.equal(secretHint({apiKey:'sk-live-abcdefgh1234'}),'1234');
 assert.equal(secretHint({secretKey:'sk_test_PRIVATE123456789',webhookSecret:'whsec_OTHERSECRET999'}),'6789');
 assert.equal(secretHint({hostingerApiToken:'hostinger-token-TOKN',signingSecret:'s'.repeat(28)+'SIGN'}),'TOKN');
 assert.equal(secretHint({signingSecret:'s'.repeat(28)+'SIGN'}),'SIGN');
 assert.equal(secretHint({apiKey:'short-key12'}),null,'under 12 characters reveals too much');
 assert.equal(secretHint({apiKey:'abcdefghijkl密钥结尾'}),null,'non-ASCII tails are not shown');
 assert.equal(secretHint({apiKey:'abcdefghij k12'}),null,'whitespace is not shown');
 assert.equal(secretHint({}),null);
});
test('integration views expose secretHint to owner/admin, never the secret, and legacy rows stay null',async()=>{
 const f=await fixture();try{
  const secretKey='sk_test_PRIVATE123456789',webhookSecret='whsec_PRIVATE123456789';
  const created=await f.request('/api/admin/integrations',{data:{kind:'payment',provider:'stripe',name:'收款',publicConfig:{mode:'test',apiVersion:'2026-10-28.endive'},secret:{secretKey,webhookSecret}},as:'owner'});
  assert.equal(created.status,201);const view=(await json(created)).data;assert.equal(view.hasSecret,true);assert.equal(view.secretHint,'6789');assert.equal(view.secret,undefined);
  const shortEmail=await f.request('/api/admin/integrations',{data:{kind:'email',provider:'resend',name:'通知邮件',publicConfig:{fromEmail:'ops@example.com'},secret:{apiKey:'re_abc12345'}},as:'owner'});
  assert.equal(shortEmail.status,201);assert.equal((await json(shortEmail)).data.secretHint,null);
  const email=await f.request('/api/admin/integrations',{data:{kind:'email',provider:'resend',name:'通知邮件',publicConfig:{fromEmail:'ops@example.com'},secret:{apiKey:'re_abcdefghWXYZ'}},as:'owner'});
  assert.equal((await json(email)).data.secretHint,'WXYZ');
  assert.equal(f.db.sqlite.prepare('SELECT secret_hint FROM integration_configs WHERE id=?').get(view.id)!.secret_hint,'6789');
  f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('cfg_legacy','payment','旧配置','stripe',1,'disabled','{}','legacy-ciphertext','passed','owner',?)").run(new Date().toISOString());
  f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,secret_hint,test_status,created_by,created_at) VALUES('cfg_nosecret','payment','无密钥','stripe',1,'disabled','{}',NULL,'ABCD','passed','owner',?)").run(new Date().toISOString());
  assert.throws(()=>f.db.sqlite.prepare("UPDATE integration_configs SET secret_hint='TOO-LONG' WHERE id='cfg_legacy'").run(),/CHECK/);
  for(const as of ['owner','admin']){const res=await f.request('/api/admin/integrations',{as});assert.equal(res.status,200);const text=await res.text(),items=JSON.parse(text).data.items as any[];
   assert.ok(!text.includes(secretKey)&&!text.includes(webhookSecret)&&!text.includes('re_abcdefghWXYZ'));
   assert.equal(items.find(i=>i.id===view.id).secretHint,'6789');assert.equal(items.find(i=>i.id==='cfg_legacy').secretHint,null);assert.equal(items.find(i=>i.id==='cfg_nosecret').secretHint,null,'no secret, no hint');}
  for(const as of ['support','editor','u'])assert.equal((await f.request('/api/admin/integrations',{as})).status,403);
  const audit=JSON.stringify(f.db.sqlite.prepare("SELECT details_json FROM audit_logs WHERE action='integration.create'").all());assert.ok(!audit.includes(secretKey)&&!audit.includes('6789'));
 }finally{f.db.close();}
});

// ---------------------------------------------------------------- item 4a
function seedRevenue(f:Awaited<ReturnType<typeof fixture>>){
 const iso='2026-10-01T00:00:00.000Z';
 f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,test_status,created_by,created_at) VALUES('cfg_live','payment','正式收款','stripe',1,'active','{\"mode\":\"live\"}','passed','owner',?),('cfg_test','payment','测试收款','stripe',1,'disabled','{\"mode\":\"test\"}','passed','owner',?)").run(iso,iso);
 const order=(id:string,kind:string,cents:number,state:string,paidAt:string|null,fulfilledAt:string|null,config:string|null,user='u')=>f.db.sqlite.prepare("INSERT INTO orders(id,user_id,kind,plan_tier,amount_cents,credit_micros,state,idempotency_key,payload_hash,created_at,expires_at,paid_at,fulfilled_at,config_version_id) VALUES(?,?,?,?,?,0,?,?,'hash',?,?,?,?,?)").run(id,user,kind,kind==='subscription'?'go':null,cents,state,'key-'+id,iso,iso,paidAt,fulfilledAt,config);
 order('o1','subscription',2500,'paid','2026-11-01T10:00:00Z','2026-11-01T10:00:05.000Z','cfg_live');
 order('o2','topup',500,'paid','2026-11-01T23:59:59Z','2026-11-02T00:00:01.000Z','cfg_live');
 order('o3','hosting',3000,'paid','2027-03-01T00:00:00.000Z','2026-11-03T08:00:00.000Z','cfg_test');   // renewal: coverage starts later, money arrived 11-03
 order('o4','topup',1000,'pending',null,null,'cfg_live');
 order('o5','subscription',10000,'refunded','2026-11-02T12:00:00Z','2026-11-02T12:00:00Z',null,'other');
 order('o6','topup',700,'failed',null,null,'cfg_live');
 order('o7','subscription',2500,'paid','2026-10-31T23:00:00Z','2026-10-31T23:00:01.000Z','cfg_live');
 order('o8','topup',600,'review',null,null,'cfg_live');
 // A gift creates a subscription but never an order: it must not appear as revenue.
 f.db.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,included_sites,credit_micros,grant_reference_id,created_at) VALUES('gift_sub','other','pro','gift','2026-11-01T00:00:00.000Z','2026-12-01T00:00:00.000Z',2,65000000,'gift-ref','2026-11-01T00:00:00.000Z')").run();
 const fcase=(id:string,kind:string,state:string,cents:number|null,created:string,config:string|null,order:string|null)=>f.db.sqlite.prepare("INSERT INTO financial_cases(id,kind,provider_object_id,config_version_id,order_id,user_id,provider_state,amount_cents,currency,snapshot_json,snapshot_hash,created_at,updated_at) VALUES(?,?,?,?,?,'u',?,?,'usd','{}','hash',?,?)").run(id,kind,'obj_'+id,config,order,state,cents,created,created);
 fcase('case_r1','refund','succeeded',500,'2026-11-02T09:00:00.000Z','cfg_live','o2');
 fcase('case_r2','refund','succeeded',null,'2026-11-02T10:00:00.000Z','cfg_live','o1');
 fcase('case_r3','refund','pending',100,'2026-11-02T11:00:00.000Z','cfg_live','o1');
 fcase('case_d1','dispute','lost',2500,'2026-11-03T09:00:00.000Z','cfg_test','o3');
 fcase('case_d2','dispute','won',2500,'2026-11-03T10:00:00.000Z','cfg_test','o3');
}
test('CNY revenue and refunds stay separate from historical USD and sandbox is classified as test',async()=>{
 const f=await fixture();try{
  seedRevenue(f);
  f.db.sqlite.prepare(`INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,test_status,created_by,created_at) VALUES('cfg_alipay','payment','支付宝沙箱','alipay',1,'disabled','{"mode":"sandbox"}','passed','owner','2026-10-01T00:00:00.000Z')`).run();
  f.db.sqlite.prepare(`INSERT INTO orders(id,user_id,kind,amount_cents,currency,credit_micros,state,idempotency_key,payload_hash,created_at,expires_at,paid_at,fulfilled_at,config_version_id,provider) VALUES('ali_cny','u','topup',1234,'CNY',1000,'paid','cny-order','hash','2026-11-02T10:00:00.000Z','2026-11-02T11:00:00.000Z','2026-11-02T10:01:00.000Z','2026-11-02T10:01:00.000Z','cfg_alipay','alipay')`).run();
  f.db.sqlite.prepare(`INSERT INTO financial_cases(id,kind,provider,provider_object_id,config_version_id,order_id,user_id,provider_state,amount_cents,currency,snapshot_json,snapshot_hash,created_at,updated_at) VALUES('cny_refund','refund','alipay','ali_refund','cfg_alipay','ali_cny','u','succeeded',234,'CNY','{}','hash','2026-11-02T10:02:00.000Z','2026-11-02T10:02:00.000Z')`).run();
  const range={from:'2026-11-01T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z'};
  const usd=await revenueSeries(f.env.DB,range),cny=await revenueSeries(f.env.DB,{...range,currency:'CNY'});
  assert.equal(usd.totals.totalCents,16000);assert.equal(usd.refunds.amountCents,500);
  assert.equal(cny.currency,'CNY');assert.equal(cny.totals.totalCents,1234);assert.equal(cny.totals.orders,1);assert.equal(cny.refunds.amountCents,234);
  assert.deepEqual(cny.byMode.test,{cents:1234,orders:1});assert.equal((await revenueSeries(f.env.DB,{...range,currency:'CNY',mode:'live'})).totals.totalCents,0);
  assert.equal((await revenueSeries(f.env.DB,{...range,currency:'CNY',mode:'test'})).totals.totalCents,1234);
 }finally{f.db.close();}
});

test('revenue sums only paid orders by kind and confirmation day, with refunds and lost disputes beside it, never netted or costed',async()=>{
 const f=await fixture();try{seedRevenue(f);
  const r=await revenueSeries(f.env.DB,{from:'2026-11-01T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z'});
  assert.deepEqual(r.series,[{period:'2026-11-01',subscriptionCents:2500,topupCents:500,hostingCents:0,totalCents:3000,orders:2},{period:'2026-11-02',subscriptionCents:10000,topupCents:0,hostingCents:0,totalCents:10000,orders:1},{period:'2026-11-03',subscriptionCents:0,topupCents:0,hostingCents:3000,totalCents:3000,orders:1}]);
  assert.deepEqual(r.totals,{subscriptionCents:12500,topupCents:500,hostingCents:3000,totalCents:16000,orders:4});
  assert.deepEqual(r.byMode,{live:{cents:3000,orders:2},test:{cents:3000,orders:1},unknown:{cents:10000,orders:1}});
  assert.deepEqual(r.refunds,{cases:2,amountCents:500,unknownAmountCases:1});assert.deepEqual(r.disputesLost,{cases:1,amountCents:2500,unknownAmountCases:0});
  assert.equal(r.currency,'USD');assert.equal(r.timezone,'UTC');assert.equal(r.bucket,'day');assert.deepEqual(r.basis,{revenue:'paid_orders_gross',time:'payment_confirmed_utc',giftsIncluded:false,costIncluded:false,refundsDeducted:false});
  assert.ok(!/cost|margin|profit/i.test(Object.keys(r.totals).join()),'no invented cost fields');
  const live=await revenueSeries(f.env.DB,{from:'2026-11-01T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z',mode:'live'});assert.equal(live.totals.totalCents,3000);assert.equal(live.disputesLost.cases,0);assert.equal(live.refunds.cases,2);
  const test_=await revenueSeries(f.env.DB,{from:'2026-11-01T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z',mode:'test'});assert.equal(test_.totals.hostingCents,3000);assert.equal(test_.totals.totalCents,3000);
  const months=await revenueSeries(f.env.DB,{from:'2026-10-01T00:00:00.000Z',to:'2026-12-01T00:00:00.000Z',bucket:'month'});
  assert.deepEqual(months.series.map(p=>[p.period,p.totalCents,p.orders]),[['2026-10',2500,1],['2026-11',16000,4]]);
  const inclusive=await revenueSeries(f.env.DB,{from:'2026-11-01T10:00:00.000Z',to:'2026-11-02T00:00:01.000Z'});assert.equal(inclusive.totals.subscriptionCents,2500,'from is inclusive');assert.equal(inclusive.totals.topupCents,500,'o2 counts at its earlier paid_at, not its later fulfilment');
  const exclusive=await revenueSeries(f.env.DB,{from:'2026-11-01T10:00:01.000Z',to:'2026-11-01T23:59:59.000Z'});assert.equal(exclusive.totals.totalCents,0,'to is exclusive');
  const empty=await revenueSeries(f.env.DB,{from:'2025-01-01T00:00:00.000Z',to:'2025-01-03T00:00:00.000Z'});assert.deepEqual(empty.series.map(p=>p.totalCents),[0,0]);assert.equal(empty.totals.totalCents,0);
  const now=Date.parse('2026-11-04T12:00:00.000Z'),days=await revenueSeries(f.env.DB,{},now);assert.equal(days.series.length,30);assert.equal(days.series[0].period,'2026-10-06');assert.equal(days.series.at(-1)!.period,'2026-11-04');assert.equal(days.to,'2026-11-04T12:00:00.000Z');
  const year=await revenueSeries(f.env.DB,{bucket:'month'},now);assert.equal(year.series.length,12);assert.equal(year.series[0].period,'2025-12');assert.equal(year.series.at(-1)!.period,'2026-11');
  for(const raw of [{from:'2026-11-04T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z'},{from:'2026-11-05T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z'},{from:'2025-01-01T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z'},{from:'2023-01-01T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z',bucket:'month'},{bucket:'year'},{from:'2026-11-01'}])
   await assert.rejects(()=>revenueSeries(f.env.DB,raw,now),(e:unknown)=>e instanceof AppError&&e.code==='VALIDATION'&&e.status===400,JSON.stringify(raw));
  const lastAllowed=await revenueSeries(f.env.DB,{from:'2025-11-04T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z'},now);assert.equal(lastAllowed.series.length,365);
 }finally{f.db.close();}
});
test('revenue range limits count buckets (366 days, 36 months) and are checked before any bucket is generated',async()=>{
 const f=await fixture();try{
  const rejects=(raw:Record<string,string>,message:RegExp)=>assert.rejects(()=>revenueSeries(f.env.DB,raw),(e:unknown)=>e instanceof AppError&&e.code==='VALIDATION'&&e.status===400&&message.test(e.message),JSON.stringify(raw));
  // Day: a 366-day span that starts at midday touches 367 calendar days and is refused.
  await rejects({from:'2025-11-03T12:00:00.000Z',to:'2026-11-04T12:00:00.000Z'},/最多 366 天/);
  await rejects({from:'2025-11-03T23:59:59.000Z',to:'2026-11-04T00:00:01.000Z'},/最多 366 天/);
  for(const [from,to,buckets] of [['2025-11-03T12:00:00.000Z','2026-11-04T00:00:00.000Z',366],['2025-11-03T00:00:00.000Z','2026-11-03T12:00:00.000Z',366],['2026-11-03T23:59:59.000Z','2026-11-04T00:00:01.000Z',2],['2026-11-03T10:00:00.000Z','2026-11-03T10:00:01.000Z',1],['2024-02-28T00:00:00.000Z','2024-03-01T00:00:00.000Z',2]] as const){
   const r=await revenueSeries(f.env.DB,{from,to});assert.equal(r.series.length,buckets,from+' '+to);assert.equal(revenueBucketCount(Date.parse(from),Date.parse(to),'day'),buckets);assert.equal(new Set(r.series.map(p=>p.period)).size,buckets);}
  // Month: 36 calendar months, also when the range starts and ends mid-month.
  await rejects({from:'2023-11-30T23:00:00.000Z',to:'2026-11-15T00:00:00.000Z',bucket:'month'},/最多 36 个月/);
  await rejects({from:'2023-12-01T00:00:00.000Z',to:'2026-12-01T00:00:00.001Z',bucket:'month'},/最多 36 个月/);
  for(const [from,to,buckets] of [['2023-12-15T00:00:00.000Z','2026-11-15T00:00:00.000Z',36],['2023-12-01T00:00:00.000Z','2026-12-01T00:00:00.000Z',36],['2026-01-31T23:59:59.000Z','2026-02-01T00:00:01.000Z',2],['2026-12-31T00:00:00.000Z','2027-01-01T00:00:00.000Z',1],['2026-11-10T00:00:00.000Z','2026-11-20T00:00:00.000Z',1]] as const){
   const r=await revenueSeries(f.env.DB,{from,to,bucket:'month'});assert.equal(r.series.length,buckets,from+' '+to);assert.equal(revenueBucketCount(Date.parse(from),Date.parse(to),'month'),buckets);}
  // The arithmetic count equals the generated series for arbitrary ranges inside the limits.
  let seed=20261112;const random=()=>{seed=(seed*1103515245+12345)%2147483648;return seed/2147483648;};
  for(let n=0;n<200;n++){const bucket=n%2?'day':'month',fromMs=Date.parse('2019-01-01T00:00:00.000Z')+Math.floor(random()*2500*86_400_000),toMs=fromMs+1+Math.floor(random()*(bucket==='day'?364:1000)*86_400_000),expected=revenueBucketCount(fromMs,toMs,bucket);
   const r=await revenueSeries(f.env.DB,{from:new Date(fromMs).toISOString(),to:new Date(toMs).toISOString(),bucket});assert.equal(r.series.length,expected,bucket+' '+r.from+' '+r.to);}
  // Absurd ranges (zod accepts years 0000–9999) are refused arithmetically: no query, no key generation.
  assert.equal(revenueBucketCount(Date.parse('0000-01-01T00:00:00.000Z'),Date.parse('9999-12-31T00:00:00.000Z'),'day'),3652424);
  assert.equal(revenueBucketCount(Date.parse('0000-01-01T00:00:00.000Z'),Date.parse('9999-12-31T00:00:00.000Z'),'month'),120000);
  const prepare=f.db.prepare.bind(f.db);let statements=0;f.db.prepare=((sql:string)=>{statements++;return prepare(sql);}) as typeof f.db.prepare;
  const toIso=Date.prototype.toISOString;let keys=0;Date.prototype.toISOString=function(this:Date){keys++;return toIso.call(this);};
  try{
   for(const bucket of ['day','month'])for(const [from,to] of [['0000-01-01T00:00:00.000Z','9999-12-31T00:00:00.000Z'],['1900-01-01T00:00:00.000Z','2100-01-01T00:00:00.000Z'],['0000-01-01T00:00:00.000Z','2026-11-04T00:00:00.000Z']])
    await rejects({from,to,bucket},bucket==='day'?/最多 366 天/:/最多 36 个月/);
  }finally{Date.prototype.toISOString=toIso;f.db.prepare=prepare;}
  assert.equal(statements,0,'a refused range runs no query');assert.equal(keys,0,'a refused range generates no bucket keys');
  const started=performance.now(),res=await f.request('/api/admin/operations/revenue?from=0000-01-01T00:00:00.000Z&to=9999-12-31T00:00:00.000Z',{as:'admin'}),body=await json(res);
  assert.equal(res.status,400);assert.equal(body.error.code,'VALIDATION');assert.match(body.error.message,/最多 366 天/);assert.ok(performance.now()-started<1000,'the extreme range is refused immediately');
 }finally{f.db.close();}
});
test('revenue endpoint is owner/admin only and is read-only',async()=>{
 const f=await fixture();try{seedRevenue(f);const before=f.db.sqlite.prepare('SELECT COUNT(*) n FROM audit_logs').get()!.n;
  for(const as of ['owner','admin']){const res=await f.request('/api/admin/operations/revenue?from=2026-11-01T00:00:00.000Z&to=2026-11-04T00:00:00.000Z',{as});assert.equal(res.status,200);const body=await json(res);assert.equal(body.ok,true);assert.equal(body.data.totals.totalCents,16000);}
  for(const as of ['support','editor','u']){const res=await f.request('/api/admin/operations/revenue',{as});assert.equal(res.status,403);assert.equal((await json(res)).error.code,'FORBIDDEN');}
  assert.equal((await f.request('/api/admin/operations/revenue')).status,401);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM audit_logs').get()!.n,before);
  // EXPLAIN the exact statement revenueSeries runs (join and mode filter included), and
  // prove it is that statement by watching what the function prepares.
  const prepare=f.db.prepare.bind(f.db),seen:string[]=[];f.db.prepare=((sql:string)=>{seen.push(sql);return prepare(sql);}) as typeof f.db.prepare;
  try{for(const mode of ['all','live','test'] as const){seen.length=0;await revenueSeries(f.env.DB,{from:'2026-11-01T00:00:00.000Z',to:'2026-11-04T00:00:00.000Z',mode});assert.ok(seen.includes(revenueOrdersSql(mode)),'revenueSeries runs revenueOrdersSql('+mode+')');}}finally{f.db.prepare=prepare;}
  for(const mode of ['all','live','test'] as const){
   const plan=f.db.sqlite.prepare('EXPLAIN QUERY PLAN '+revenueOrdersSql(mode)).all(...[10,'2026-11-01T00:00:00.000Z','2026-11-04T00:00:00.000Z',...(mode==='all'?[]:[mode])]).map((row:any)=>String(row.detail));
   assert.ok(plan.some(detail=>/^SEARCH o USING INDEX orders_revenue_time \(<expr>>\? AND <expr><\?\)/.test(detail)),'mode='+mode+' searches orders by the revenue-time index on both bounds: '+JSON.stringify(plan));
   assert.ok(!plan.some(detail=>/^SCAN o\b/.test(detail)),'mode='+mode+' never scans the orders table');}
 }finally{f.db.close();}
});

// ---------------------------------------------------------------- item 4b
test('member list carries tier and availableMicros identical to the member detail, computed in one statement',async()=>{
 const f=await fixture();try{
  const NOW=Date.now(),iso=new Date(NOW).toISOString(),day=86_400_000,at=(ms:number)=>new Date(ms).toISOString();
  // u: paid go + gift pro (pro wins); other: only a frozen go subscription (no current tier); admin: expired pro.
  const sub=(id:string,user:string,tier:string,source:string,starts:number,ends:number,frozen:string|null=null)=>f.db.sqlite.prepare("INSERT INTO subscriptions(id,user_id,tier,source,starts_at,ends_at,included_sites,credit_micros,grant_reference_id,created_at,membership_frozen_by) VALUES(?,?,?,?,?,?,1,0,?,?,?)").run(id,user,tier,source,at(starts),at(ends),'ref-'+id,iso,frozen);
  f.db.sqlite.prepare("INSERT INTO membership_freezes(id,user_id,actor_id,request_key,payload_hash,reason,state,requested_at_ms,updated_at) VALUES('freeze_other','other','owner','freeze-key','hash','fixture','frozen',?,?)").run(NOW,iso);
  sub('s_go','u','go','paid',NOW-5*day,NOW+25*day);sub('s_pro','u','pro','gift',NOW-day,NOW+29*day);sub('s_frozen','other','go','paid',NOW-5*day,NOW+25*day,'freeze_other');sub('s_old','admin','pro','paid',NOW-60*day,NOW-30*day);
  // u's grants: available topup, future gift, expired subscription credit, paused credit, revoked credit, and a live hold.
  await grantCredit(f.env.DB,{id:'g_topup',userId:'u',source:'topup',amountMicros:3_250_000,referenceId:'r-topup',nowMs:NOW-1000});
  await grantCredit(f.env.DB,{id:'g_future',userId:'u',source:'gift',amountMicros:1_000_000,startsAtMs:NOW+day,expiresAtMs:NOW+30*day,referenceId:'r-future',nowMs:NOW});
  await grantCredit(f.env.DB,{id:'g_expired',userId:'u',source:'subscription',amountMicros:2_000_000,startsAtMs:NOW-40*day,expiresAtMs:NOW-10*day,referenceId:'r-expired',nowMs:NOW-40*day});
  await grantCredit(f.env.DB,{id:'g_gift',userId:'u',source:'gift',amountMicros:65_000_000,startsAtMs:NOW-day,expiresAtMs:NOW+29*day,referenceId:'r-gift',nowMs:NOW-day});
  await grantCredit(f.env.DB,{id:'g_paused',userId:'other',source:'subscription',amountMicros:16_250_000,startsAtMs:NOW-5*day,expiresAtMs:NOW+25*day,referenceId:'r-paused',nowMs:NOW-5*day});
  f.db.sqlite.prepare("UPDATE credit_grants SET membership_frozen_by='freeze_other' WHERE id='g_paused'").run();
  await grantCredit(f.env.DB,{id:'g_other_topup',userId:'other',source:'topup',amountMicros:500_000,referenceId:'r-other-topup',nowMs:NOW-1000});
  f.db.sqlite.prepare("INSERT INTO orders(id,user_id,kind,amount_cents,credit_micros,state,idempotency_key,payload_hash,created_at,expires_at) VALUES('o_rev','u','topup',500,0,'paid','k-rev','hash',?,?)").run(iso,iso);
  f.db.sqlite.prepare("INSERT INTO financial_cases(id,kind,provider_object_id,order_id,user_id,provider_state,snapshot_json,snapshot_hash,created_at,updated_at) VALUES('case_rev','refund','re_rev','o_rev','u','succeeded','{}','hash',?,?)").run(iso,iso);
  f.db.sqlite.prepare("INSERT INTO financial_entitlement_operations(id,case_id,order_id,user_id,actor_id,direction,target_kind,target_id,original_state,request_key,payload_hash,attempt_nonce,cancel_renewal,renewal_continues_confirmed,state,reason,evidence,created_at) VALUES('op_rev','case_rev','o_rev','u','owner','revoke','annual','x','active','k','hash','nonce',0,0,'completed','fixture','fixture evidence',?)").run(iso);
  await grantCredit(f.env.DB,{id:'g_revoked',userId:'u',source:'topup',amountMicros:700_000,referenceId:'r-revoked',nowMs:NOW-1000});
  f.db.sqlite.prepare("UPDATE credit_grants SET entitlement_revoked_by='op_rev' WHERE id='g_revoked'").run();
  await fundProvider(f.env.DB,{id:'fund',providerId:'pool',amountMicros:10_000_000,referenceId:'deposit',nowMs:NOW});
  await reserve(f.env.DB,{id:'held',userId:'u',providerId:'pool',amountMicros:250_000,requestKey:'held-request',nowMs:NOW});await claimReservation(f.env.DB,'held',NOW);
  // Many more members so a per-row lookup would show up in the statement count.
  for(let n=0;n<40;n++)f.db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,created_at,updated_at) VALUES(?,?,?,'x','user',?,?)").run('bulk'+n,'bulk'+n+'@example.test','bulk'+n,iso,iso);
  const prepare=f.db.prepare.bind(f.db);let statements=0;f.db.prepare=((sql:string)=>{statements++;return prepare(sql);}) as typeof f.db.prepare;
  const result=await searchMembers(f.env.DB,{limit:100},NOW);f.db.prepare=prepare;
  assert.equal(statements,1,'the page, balances and tiers come from a single statement');assert.equal(result.items.length,46);
  for(const item of result.items){const wallet=await getWallet(f.env.DB,item.id,NOW),current=await activeSubscription(f.env.DB,item.id,iso);
   assert.equal(item.availableMicros,wallet.availableMicros,item.id);assert.equal(item.tier,current?.tier??null,item.id);assert.ok(Number.isSafeInteger(item.availableMicros));}
  const byId=Object.fromEntries(result.items.map(i=>[i.id,i]));
  assert.equal(byId.u.tier,'pro');assert.equal(byId.u.availableMicros,3_250_000+65_000_000-250_000);
  assert.equal(byId.other.tier,null,'a frozen membership is not a current tier');assert.equal(byId.other.availableMicros,500_000,'paused credit is not spendable');
  assert.equal(byId.admin.tier,null);assert.equal(byId.bulk0.availableMicros,0);
  for(const key of ['id','email','name','role','status','email_verified_at','created_at','project_count','tier','availableMicros'])assert.ok(key in byId.u,key);
  assert.ok(!JSON.stringify(result).includes('password_hash'));
  const pro=await f.request('/api/admin/operations/members?tier=pro',{as:'support'}),body=await json(pro);assert.equal(pro.status,200);assert.deepEqual(body.data.items.map((i:any)=>[i.id,i.tier]),[['u','pro']]);
  const none=await json(await f.request('/api/admin/operations/members?tier=none&limit=100',{as:'admin'}));assert.ok(none.data.items.every((i:any)=>i.tier===null));assert.ok(none.data.items.some((i:any)=>i.id==='other'));
  // The filter uses the displayed (top) tier: u holds Go and Pro, shows Pro, and is not a "Go" row.
  assert.deepEqual((await json(await f.request('/api/admin/operations/members?tier=go',{as:'support'}))).data.items,[]);
  sub('s_editor_go','editor','go','paid',NOW-day,NOW+29*day);sub('s_support_cancelled','support','go','paid',NOW-day,NOW+29*day);f.db.sqlite.prepare("UPDATE subscriptions SET state='cancelled' WHERE id='s_support_cancelled'").run();
  const go=await searchMembers(f.env.DB,{tier:'go',limit:100},NOW);assert.deepEqual(go.items.map(i=>i.id+':'+i.tier).sort(),['editor:go','support:go']);
  const all=await searchMembers(f.env.DB,{limit:100},NOW);
  for(const tier of ['go','pro','none'] as const){const filtered=await searchMembers(f.env.DB,{tier,limit:100},NOW),expected=tier==='none'?null:tier;
   assert.ok(filtered.items.every(i=>i.tier===expected),'every tier='+tier+' row displays that tier');assert.deepEqual(filtered.items.map(i=>i.id),all.items.filter(i=>i.tier===expected).map(i=>i.id),'tier='+tier+' returns exactly the rows that display it');
   for(const item of filtered.items)assert.equal((await activeSubscription(f.env.DB,item.id,iso))?.tier??null,expected,item.id);}
  assert.deepEqual((await searchMembers(f.env.DB,{tier:'pro',q:'u@example.test',role:'user',status:'active'},NOW)).items.map(i=>i.id),['u'],'the tier filter combines with the other filters');
  const paged1=await searchMembers(f.env.DB,{limit:20,page:3},NOW);assert.equal(paged1.items.length,6);assert.equal(paged1.hasMore,false);
  const paged2=await searchMembers(f.env.DB,{limit:20,page:1},NOW);assert.equal(paged2.items.length,20);assert.equal(paged2.hasMore,true);
 }finally{f.db.close();}
});
