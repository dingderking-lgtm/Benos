import test from 'node:test';
import assert from 'node:assert/strict';
import {createDesignBrief,createLegacyDesignBrief,designBriefAuthoringContext} from '../src/contracts/design-brief';
import {inferWebsiteKind} from '../src/contracts/website-intent';
const brief=(request:string)=>createDesignBrief({request,hasExistingSite:false})!;
test('nine purposes and subtype-specific image responsibilities preserve primary business',()=>{
 const examples=[['咖啡机厂家官网','industrial-b2b'],['工业设备摄影作品集','portfolio-studio'],['给慢巷咖啡店做官网，店里有老式机械','local-hospitality'],['民宿网站','local-hospitality'],['一个无人机官网','software-product'],['软件产品官网','software-product'],['律师事务所网站','professional-service'],['珠宝品牌商品网站','brand-commerce'],['读书会网站','education-community'],['展览活动网站','event-campaign'],['一个未知想法的网站','general'],['机械厂家知识库网站','general'],['咖啡品牌产品目录网站','brand-commerce']] as const;
 for(const [request,kind]of examples){const b=brief(request);assert.equal(b.inference.siteKind,kind,request);assert.equal(b.version,'db-3');assert.equal(b.pageBlueprint?.version,'pb-1');assert.equal(b.pageBlueprint!.roles.length,8);assert.deepEqual(b.pageBlueprint!.targetSections,[7,9]);assert.ok(JSON.stringify(b).length<3000);}
 assert.notDeepEqual(brief('咖啡店网站').imagePlan!.roles,brief('民宿网站').imagePlan!.roles);
 assert.equal(inferWebsiteKind('Build a hotel website').subtype,'stay');
 assert.equal(inferWebsiteKind('A photography portfolio with factory machinery').kind,'portfolio-studio');
 assert.equal(inferWebsiteKind('A coffee machine manufacturer website').kind,'industrial-b2b');
});
test('simple, one hero, no images, explicit image count and existing edits remain distinct',()=>{
 assert.deepEqual(brief('做一个简单读书会介绍首页').pageBlueprint!.targetSections,[4,5]);
 assert.deepEqual(brief('只做首屏').pageBlueprint!.targetSections,[1,1]);assert.deepEqual(brief('只做首屏').imagePlan!.targetRange,[0,1]);
 assert.deepEqual(brief('完整工业官网，不要图片').pageBlueprint!.targetSections,[7,9]);assert.deepEqual(brief('完整工业官网，不要图片').imagePlan!.targetRange,[0,0]);
 assert.deepEqual(brief('咖啡店网站，只用3张图片').imagePlan!.targetRange,[3,3]);
 assert.equal(createDesignBrief({request:'重做所有页面',hasExistingSite:true}),null);
 assert.equal(createDesignBrief({request:'咖啡站',hasExistingSite:false,scope:'node'}),null);
 assert.match(brief('首页、关于、联系三页的完整网站').pageStrategy,/明确页数.*优先/);
});
test('fact-dependent roles retain useful honest fallback and raw request is only excerpted',()=>{
 const photo=brief('摄影作品集');assert.equal(photo.pageBlueprint!.roles.find(r=>r.id==='gallery')!.requires,'owned-assets');
 assert.match(photo.pageBlueprint!.roles.find(r=>r.id==='gallery')!.fallback!,/不编命名项目/);
 for(const q of ['软件产品官网','活动网站','珠宝品牌网站'])assert.ok(brief(q).pageBlueprint!.roles.some(r=>r.requires==='facts'&&r.fallback));
 const b=brief('很长的明确需求。'.repeat(100));assert.equal(b.source.excerptTruncated,true);assert.equal(Array.from(b.source.requestExcerpt).length,160);
 assert.match(b.missingFactsPolicy,/缺资料列任务结果/);
 const old=createLegacyDesignBrief({request:'机械官网',hasExistingSite:false})!;assert.equal(old.version,'db-2');assert.equal(old.pageBlueprint,undefined);
 const before=JSON.stringify(old);assert.ok(designBriefAuthoringContext(old).includes(before));assert.equal(JSON.stringify(old),before);
});
