import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { getV2Fixture } from '../src/design-system/v2/fixtures';
import { renderV2Section } from '../src/design-system/v2/render';
import { V2_PRESETS } from '../src/design-system/v2/contracts';

const localRequire = createRequire(import.meta.url);
let chromium: any = null;
try { chromium = localRequire(process.env.BENOS_TEST_PLAYWRIGHT || 'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright').chromium; } catch { /* Optional browser dependency; pure renderer checks are separate. */ }
const browserPath = process.env.BENOS_TEST_BROWSER || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';

test('ledger descriptions occupy the readable content column at all four widths and presets', {
  skip: !chromium || !existsSync(browserPath) ? 'Requires the local browser dependency' : false, timeout: 60000,
}, async () => {
  const browser = await chromium.launch({ executablePath: browserPath, headless: true });
  try {
    const page = await browser.newPage();
    for (const preset of V2_PRESETS) {
      const fixture = getV2Fixture('features', 'ledger', preset, { scenario: 'long' });
      const result = await renderV2Section(fixture.input, fixture.context);
      for (const width of [320, 390, 768, 1440]) {
        await page.setViewportSize({ width, height: 900 });
        await page.setContent(`<html lang="zh-CN"><head><style>body{margin:0}${result.css}</style></head><body>${result.html}</body></html>`);
        const measurements = await page.evaluate(() => {
          const win = globalThis as any;
          return { overflow: win.document.documentElement.scrollWidth - win.innerWidth,
            rows: Array.from(win.document.querySelectorAll('.bnx-ledger-row')).map((row: any) => {
              const heading = row.children[1].getBoundingClientRect();
              const description = row.children[2].getBoundingClientRect();
              return { headingX: heading.x, headingWidth: heading.width, headingBottom: heading.bottom,
                descriptionX: description.x, descriptionY: description.y, descriptionWidth: description.width };
            }) };
        });
        assert.ok(measurements.overflow <= 1, `${preset}/${width}: page overflow`);
        assert.equal(measurements.rows.length, fixture.input.content.items.length);
        for (const row of measurements.rows) {
          assert.ok(row.descriptionWidth >= 200, `${preset}/${width}: description is only ${row.descriptionWidth}px wide`);
          if (width <= 800) {
            assert.ok(Math.abs(row.descriptionX - row.headingX) <= 1, `${preset}/${width}: description fell into the number column`);
            assert.ok(Math.abs(row.descriptionWidth - row.headingWidth) <= 1);
            assert.ok(row.descriptionY >= row.headingBottom, `${preset}/${width}: description overlaps the heading`);
          } else assert.ok(row.descriptionX >= row.headingX + row.headingWidth, `${preset}/${width}: desktop ledger lost its separate description column`);
        }
      }
    }
  } finally { await browser.close(); }
});
