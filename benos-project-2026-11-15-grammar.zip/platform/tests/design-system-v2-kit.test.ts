import test from 'node:test';
import assert from 'node:assert/strict';
import { parseFragment } from 'parse5';
import { compileV2Page, renderV2Section } from '../src/design-system/v2/render';
import { V2_PATTERN_DEFINITIONS, V2_PRESETS, createWebsiteTokenSnapshot, type V2PageInput } from '../src/design-system/v2/contracts';
import { createV2PageFixture, getV2Fixture } from '../src/design-system/v2/fixtures';
import { prepareV2Generation } from '../src/design-system/v2/generation';
import { KIT_BASE_CSS, KIT_PATTERN_CSS, KIT_PATTERN_IDS, isKitPattern } from '../src/design-system/v2/kit';
import { v2ArtCss, v2Styles, v2TokenCss } from '../src/design-system/v2/styles';
import { parseSiteCompositionV2, siteCompositionV2JsonSchema } from '../src/lib/site-composer-v2';

function nodes(html: string) { const all: any[] = []; const visit = (node: any) => { if (node.tagName) all.push(node); for (const child of node.childNodes || []) visit(child); }; visit(parseFragment(html)); return all; }
const attr = (node: any, name: string) => node.attrs?.find((a: any) => a.name === name)?.value;
const text = (node: any): string => node.nodeName === '#text' ? node.value : (node.childNodes || []).map(text).join('');
const cls = (node: any) => String(attr(node, 'class') || '').split(/\s+/);
const picture = (id: string, caption?: string) => ({ id, kind: 'owned' as const, assetPath: `/kit/${id}.webp`, purpose: 'Line overview', alt: 'Line overview', ...(caption ? { caption } : {}) });
const owned = ['main', 'one', 'two'].map(id => ({ path: `/kit/${id}.webp`, width: 1200, height: 900, source: 'generated' as const }));
const page = (preset = 'calm-paper' as const): V2PageInput => ({ version: 'bnx-compose-1', preset, sections: [
  { id: 'hero', patternId: 'hero-kit', variantId: 'routes', preset, media: [picture('main', 'A material concept.')],
    content: { eyebrow: 'A machinery brand', title: 'Engineering the next life of plastics.', lead: 'Recycling and extrusion lines developed around your material and product.', body: 'A focused brand | All product families',
      actions: [{ label: 'Discover', href: '/about', kind: 'primary' }, { label: 'Explore machines', href: '/products', kind: 'secondary' }],
      items: [{ label: '01 / Recovery', title: 'Recycling machines.', text: 'From prepared scrap to usable pellets.', href: '/recycling' }, { label: '02 / Formation', title: 'Custom extrusion.', text: 'From a product brief to a connected line.', href: '/extrusion' },
        { title: 'One material. Your possibilities.', text: 'The right line begins with the right questions.', href: '/about', linkLabel: 'Our approach' }] } },
  { id: 'purpose', patternId: 'kit-statement', variantId: 'split', preset, media: [],
    content: { eyebrow: 'A clear purpose', title: 'Better-defined projects. More considered machinery.', lead: 'We connect the material question with the equipment decision.', body: 'What enters the line, what leaves it, and what happens in between.', actions: [{ label: 'Meet the company', href: '/about', kind: 'secondary' }] } },
  { id: 'duo', patternId: 'kit-duo', variantId: 'cards', preset, media: [picture('one', 'Recycling concept.'), picture('two', 'Extrusion concept.')],
    content: { eyebrow: 'Two disciplines', title: 'Recover value. Create what comes next.', lead: 'Understand the material, then design the process around it.',
      items: [{ title: 'Plastic recycling machines', text: 'A process built around the incoming material.', href: '/recycling', linkLabel: 'Explore recycling' }, { title: 'Custom extrusion lines', text: 'Every stage supports the product you intend to make.', href: '/extrusion', linkLabel: 'Explore extrusion' }] } },
  { id: 'steps', patternId: 'kit-steps', variantId: 'flow', preset, media: [],
    content: { eyebrow: 'The approach', title: 'A line is only as considered as the brief behind it.', lead: 'Customization is a sequence of engineering decisions.',
      items: [{ title: 'Understand the material', text: 'Start with representative samples.' }, { title: 'Define the system', text: 'Connect feeding, processing and downstream stages.' }, { title: 'Make it specific', text: 'Review layout, controls and utilities.' }, { title: 'Agree the evidence', text: 'Set the checks and acceptance criteria.' }] } },
  { id: 'next', patternId: 'kit-cta', variantId: 'band', preset, media: [],
    content: { title: 'Your next production chapter starts here.', lead: 'Tell us about your material and your product.', actions: [{ label: 'Discuss your project', href: '/contact', kind: 'primary' }] } },
] });
const stone = { direction: 'studio', mode: 'light', accent: '#265bff', neutral: 'stone', accent2: '#e57842' } as const;

test('kit sections compile the template structure: 1360 measure, captioned figures, entry cards, numbered flow and action band', async () => {
  const result = await compileV2Page(page(), { mode: 'review', ownedAssets: owned, verifiedFactRefs: [], art: stone as any });
  assert.deepEqual(result.issues, []);
  const dom = nodes(result.html), sections = dom.filter(n => n.tagName === 'section');
  assert.equal(sections.length, 5);
  for (const section of sections) assert.ok(cls(section).includes('bnk'), 'every kit section carries the kit scope');
  assert.equal(dom.filter(n => n.tagName === 'h1').length, 1);
  assert.equal(dom.filter(n => cls(n).includes('bnk-wrap')).length, 5);
  // Figures keep their caption next to the picture.
  const captions = dom.filter(n => n.tagName === 'figcaption').map(text);
  assert.deepEqual(captions, ['A material concept.', 'Recycling concept.', 'Extrusion concept.']);
  // Two entry cards (links) and one note card with its own link text.
  const routes = dom.filter(n => cls(n).includes('bnk-route'));
  assert.deepEqual(routes.map(n => [n.tagName, attr(n, 'href')]), [['a', '/recycling'], ['a', '/extrusion']]);
  const note = dom.find(n => cls(n).includes('bnk-note'))!;
  assert.match(text(note), /One material\. Your possibilities\..*Our approach/s);
  // The bottom line splits at "|" into two ends.
  assert.deepEqual(dom.find(n => cls(n).includes('bnk-brand-line'))!.childNodes.filter((n: any) => n.tagName === 'span').map(text), ['A focused brand', 'All product families']);
  // Numbered flow: an ordered list whose numerals are decorative.
  const flow = dom.find(n => n.tagName === 'ol' && cls(n).includes('bnk-flow'))!;
  assert.deepEqual(flow.childNodes.filter((n: any) => n.tagName === 'li').map((li: any) => text(li.childNodes[0])), ['01', '02', '03', '04']);
  assert.equal(dom.filter(n => cls(n).includes('bnk-number')).every(n => attr(n, 'aria-hidden') === 'true'), true);
  // No inline styles, scripts or forms anywhere in kit markup.
  assert.equal(dom.some(n => ['script', 'style', 'form', 'iframe', 'svg'].includes(n.tagName)), false);
  assert.equal(dom.filter(n => !['img', 'div'].includes(n.tagName)).some(n => attr(n, 'style')), false);
  assert.match(result.css, /\.bnk-wrap\{width:calc\(100% - 80px\);max-width:1360px/);
});

test('kit headings are set as deliberate lines: a sentence per line, or one long sentence broken near its middle', async () => {
  const dom = nodes((await compileV2Page(page(), { mode: 'review', ownedAssets: owned, verifiedFactRefs: [] })).html);
  const lines = (tag: string, index = 0) => dom.filter(n => n.tagName === tag)[index].childNodes.filter((n: any) => n.tagName === 'span' && cls(n).includes('bnk-line')).map(text);
  assert.deepEqual(lines('h1'), ['Engineering the next', 'life of plastics.']);
  const h2 = dom.filter(n => n.tagName === 'h2').map(n => n.childNodes.filter((c: any) => c.tagName === 'span' && cls(c).includes('bnk-line')).map(text));
  assert.ok(h2.some(l => l.join('|') === 'Better-defined projects.|More considered machinery.'));
  assert.ok(h2.some(l => l.join('|') === 'Recover value.|Create what comes next.'));
  assert.ok(h2.some(l => l.join('|') === 'A line is only as considered|as the brief behind it.'));
  // The lines flow inline on phones so an authored break never stacks on natural wrapping.
  assert.match(KIT_BASE_CSS, /\.bnk-line\{display:block\}/);
  assert.match(KIT_BASE_CSS, /@media\(max-width:760px\)\{\.bnk-line\{display:inline\}/);
  // A short heading is left alone; a CJK heading uses the shared clause rule and looser tracking.
  const short = structuredClone(page()); short.sections[4].content.title = 'Talk to us.';
  assert.equal(nodes((await compileV2Page(short, { mode: 'review', ownedAssets: owned, verifiedFactRefs: [] })).html).filter(n => n.tagName === 'h2').at(-1)!.childNodes.some((n: any) => n.tagName === 'span'), false);
  const zh = structuredClone(page()); zh.sections[1].content.title = '项目定义更清楚，设备才会更合适。';
  const zhDom = nodes((await compileV2Page(zh, { mode: 'review', ownedAssets: owned, verifiedFactRefs: [] })).html), zhSection = zhDom.filter(n => n.tagName === 'section')[1];
  assert.ok(cls(zhSection).includes('bnk-cjk'));
  assert.equal(zhDom.some(n => n.tagName === 'span' && cls(n).includes('bnk-line') && /项目定义/.test(text(n))), false);
  assert.deepEqual(zhDom.filter(n => cls(n).includes('bnx-heading-phrase')).map(text), ['项目定义更清楚，', '设备才会更合适。']);
});

test('kit content is escaped and every optional slot can be left out', async () => {
  const hostile = structuredClone(page());
  hostile.sections[0].content.title = 'Lines <img src=x onerror=alert(1)> built "safely".';
  hostile.sections[0].content.items![0].title = '<b>Bold</b> machines';
  hostile.sections[0].media![0] = { ...hostile.sections[0].media![0], caption: '<script>alert(1)</script>' } as any;
  const html = (await compileV2Page(hostile, { mode: 'review', ownedAssets: owned, verifiedFactRefs: [] })).html;
  assert.equal(/<script|<b>|onerror=alert\(1\)>/.test(html), false);
  assert.match(html, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);
  const bare: V2PageInput = { version: 'bnx-compose-1', preset: 'calm-paper', sections: [
    { id: 'hero', patternId: 'hero-kit', variantId: 'routes', preset: 'calm-paper', media: [], content: { title: 'A short claim', lead: 'One supporting sentence that says what the company does.' } as any },
    { id: 'duo', patternId: 'kit-duo', variantId: 'cards', preset: 'calm-paper', media: [], content: { title: 'Two ways in', items: [{ title: 'First', text: 'What it is for.' }, { title: 'Second', text: 'What it is for.' }] } as any },
  ] };
  const result = await compileV2Page(bare, { mode: 'review', ownedAssets: [], verifiedFactRefs: [] }), dom = nodes(result.html);
  assert.deepEqual(result.issues.filter(i => i.severity === 'error'), []);
  assert.equal(dom.some(n => ['figure', 'img'].includes(n.tagName)), false);
  assert.equal(dom.some(n => cls(n).includes('bnk-home-bottom') || cls(n).includes('bnk-brand-line') || cls(n).includes('bnk-actions')), false);
  assert.ok(dom.some(n => cls(n).includes('bnk-home-one')), 'a hero without a picture uses one column');
  assert.equal(dom.filter(n => cls(n).includes('bnk-duo-text')).length, 2);
});

test('kit pictures never outnumber their cards and unknown kit variants are rejected', async () => {
  const tooMany = structuredClone(page()); tooMany.sections[2].media!.push(picture('main'));
  await assert.rejects(() => compileV2Page(tooMany, { mode: 'review', ownedAssets: owned, verifiedFactRefs: [] }));
  const unknown = structuredClone(page()); (unknown.sections[3] as any).variantId = 'timeline';
  await assert.rejects(() => compileV2Page(unknown, { mode: 'review', ownedAssets: owned, verifiedFactRefs: [] }));
});

test('kit styles pass the stylesheet rules of a page: no !important, no global selectors, every rule scoped to bnk/bnx classes', () => {
  const css = KIT_BASE_CSS + KIT_PATTERN_IDS.map(id => KIT_PATTERN_CSS[id]).join('');
  assert.equal(css.includes('!important'), false);
  assert.equal(/url\(|@import|expression\(|mask|text-wrap/.test(css), false);
  // Split a selector list at top-level commas only (":is(h1,h2,h3)" is one selector).
  const selectors = [...css.replace(/@media[^{]*\{/g, '').matchAll(/([^{}]+)\{[^{}]*\}/g)].flatMap(m => m[1].split(/,(?![^()]*\))/)).map(s => s.trim()).filter(Boolean);
  assert.ok(selectors.length > 120);
  for (const selector of selectors) { assert.match(selector, /^\.(bnx|bnk)-/, selector); assert.equal(/(^|[\s>+~])(\*|html|body|:root)/.test(selector), false, selector); }
});

test('kit colour roles travel only with kit pages, so generic pages keep their exact stylesheet', async () => {
  const tokens = createWebsiteTokenSnapshot('calm-paper');
  assert.equal(v2TokenCss(tokens).includes('--bnx-accent-2'), false);
  assert.equal(v2TokenCss(tokens, true).includes('--bnx-accent-2:'), true);
  assert.equal(v2Styles(tokens, ['features', 'footer']).includes('bnk-'), false);
  assert.equal(v2Styles(tokens, ['features', 'footer']).includes('--bnx-copy'), false);
  const kitCss = v2Styles(tokens, ['hero-kit', 'kit-cta']);
  for (const name of ['--bnx-accent-2:', '--bnx-accent-2-ink:', '--bnx-line-strong:', '--bnx-accent-hover:', '--bnx-accent-deep:', '--bnx-card-strong:', '--bnx-copy:']) assert.ok(kitCss.includes(name), name);
  assert.equal(kitCss.split('.bnk-wrap{width:calc(100% - 80px)').length, 2, 'shared kit rules are included once');
  // The palette override follows the same rule and honours the model's second accent.
  assert.equal(v2ArtCss('calm-paper', stone as any).includes('--bnx-accent-2'), false);
  const art = v2ArtCss('calm-paper', stone as any, true);
  assert.match(art, /--bnx-background:#f7f7f4;/); assert.match(art, /--bnx-accent-2:#e57842;/); assert.match(art, /--bnx-accent-deep:#204cd6;/);
  assert.match(art, /--bnx-accent-2-on:#e57842;/);
  // With a single accent the mark on the solid card falls back to the card's ink instead of vanishing.
  const single = v2ArtCss('calm-paper', { ...stone, accent2: undefined } as any, true);
  assert.match(single, /--bnx-accent-2:#265bff;/); assert.match(single, /--bnx-accent-2-on:#ffffff;/);
  // A generic page with a palette is unchanged by the kit; a kit page carries the roles.
  const generic = createV2PageFixture({ preset: 'calm-paper', example: 'stay', imageBaseUrl: '/fx' });
  assert.equal((await compileV2Page(generic.input, { ...generic.context, art: stone as any })).css.includes('--bnx-accent-2'), false);
  assert.equal((await compileV2Page(generic.input, { ...generic.context, art: stone as any, kit: true })).css.includes('--bnx-accent-2:#e57842'), true);
  assert.equal((await compileV2Page(page(), { mode: 'review', ownedAssets: owned, verifiedFactRefs: [], art: stone as any })).css.includes('--bnx-accent-2:#e57842'), true);
});

test('kit sections have reviewable artifacts in every preset but are not offered to generation until the kit covers a whole site', async () => {
  for (const id of KIT_PATTERN_IDS) {
    const family = V2_PATTERN_DEFINITIONS.find(f => f.id === id)!;
    assert.ok(family, id); assert.ok(isKitPattern(family.id));
    for (const preset of V2_PRESETS) for (const variant of family.variants) {
      const fixture = getV2Fixture(family.id, variant.id, preset), rendered = await renderV2Section(fixture.input, fixture.context);
      assert.match(rendered.artifact.artifactHash, /^[a-f0-9]{64}$/);
      assert.ok(rendered.css.includes('.bnk-wrap{'));
    }
  }
  for (const request of ['做一个工业设备官网，包括首页、产品中心、关于我们和联系我们', '做一个民宿官网', 'Build a website for a plastics machinery company with home, products, about and contact']) for (const preset of V2_PRESETS) {
    const plan = await prepareV2Generation({ request, preset });
    assert.equal(plan.catalog.some(f => isKitPattern(f.id)), false);
    assert.equal(plan.compilerSnapshot.some(entry => isKitPattern(entry.patternId)), false);
    for (const section of plan.pages.flatMap(p => p.sections)) { assert.equal(section.choices.some(c => isKitPattern(c.patternId)), false); assert.equal(isKitPattern(section.recommended.patternId), false); }
  }
});

test('the model-facing tool definition offers nothing kit-only, while the compiler accepts kit inputs', () => {
  const wire = JSON.stringify(siteCompositionV2JsonSchema);
  for (const word of ['linkLabel', 'caption', 'accent2', 'stone', ...KIT_PATTERN_IDS]) assert.equal(wire.includes('"' + word + '"'), false, word);
  assert.ok(wire.includes('"hero-stage"') && wire.includes('"warm"') && wire.includes('"accent"'));
  const parsed = parseSiteCompositionV2({ version: 'site-compose-v2', footer: null, art: { direction: 'studio', mode: 'light', accent: '#265bff', neutral: 'stone', accent2: '#e57842' },
    pages: [{ pageKey: 'home', templateId: 1, composition: { version: 'bnx-compose-1', preset: 'calm-paper', sections: [{ id: 'duo', patternId: 'kit-duo', variantId: 'cards', preset: 'calm-paper',
      media: [{ id: 'a', kind: 'planned', purpose: 'Line overview', alt: 'Line overview', prompt: 'A clean studio photograph of a compact recycling line on a pale background', caption: 'A caption' }],
      content: { title: 'Two ways in', items: [{ title: 'First', text: 'What it is for.', href: '/a', linkLabel: 'Open' }, { title: 'Second', text: 'What it is for.' }] } }] } }] });
  assert.equal(parsed.art?.neutral, 'stone'); assert.equal(parsed.art?.accent2, '#e57842');
  const section = parsed.pages[0]!.composition.sections[0]!;
  assert.equal(section.content.items[0]!.linkLabel, 'Open'); assert.equal(section.media[0]!.caption, 'A caption');
});
