import test from 'node:test';
import assert from 'node:assert/strict';
import { userSpecifiesImageDirection } from '../src/lib/image-visual-direction';

test('explicit image key-value labels preserve a user direction without requiring an imperative verb',()=>{
 for(const text of ["图片风格：水彩","主图：黑白纪实","照片配色=暖色","配图媒介：线稿","主视觉：3D","Image style: watercolor","Hero image: monochrome","Photos - warm documentary","Illustration palette: blue","Product image medium: clay"])assert.equal(userSpecifiesImageDirection(text),true,text);
});

test('negated image labels do not become positive visual requirements',()=>{
 for(const text of ["图片风格：不要水彩","主图：不是蓝色","配图媒介：非水彩","不要图片风格：水彩","Image style: not blue","Images: no cartoons","Avoid image style: watercolor","Do not use photos: warm documentary"])assert.equal(userSpecifiesImageDirection(text),false,text);
});

test('site palette, captions and counts are not misread as image art direction',()=>{
 for(const text of ["网页风格：水彩","图片说明：蓝色设备","照片数量：3D","网站背景：蓝色，图片：展示流程","Image caption: blue equipment","Website palette: blue","Photo count: 3D"])assert.equal(userSpecifiesImageDirection(text),false,text);
});
