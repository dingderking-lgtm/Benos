import test from 'node:test';
import assert from 'node:assert/strict';
import { DESIGN_FONT_CATALOG,DESIGN_FONT_PAIRS,createTypographySnapshot,resolveDesignFont,typographySnapshotSchema,isSafeFontStack } from '../src/contracts/design-typography';
test('33 named fonts include Helvetica and managed Google fonts; legacy snapshots stay readable',()=>{
 assert.equal(DESIGN_FONT_CATALOG.filter(f=>!f.legacy).length,33);assert.equal(new Set(DESIGN_FONT_CATALOG.map(f=>f.id)).size,DESIGN_FONT_CATALOG.length);assert.equal(DESIGN_FONT_PAIRS.length,6);
 for(const f of DESIGN_FONT_CATALOG){assert.ok(['system','google'].includes(f.source));assert.ok(isSafeFontStack(f.stack));assert.ok(f.sampleZh&&f.sampleLatin);assert.doesNotMatch(f.stack,/@|url\(|https?:/);}
 for(const p of DESIGN_FONT_PAIRS){const s=createTypographySnapshot({fontPairId:p.id});assert.equal(s.heading?.id,p.headingId);assert.equal(s.body?.id,p.bodyId);}
});
test('four legacy strings resolve while unknown and CSS payloads are refused',()=>{
 const aliases=['system-ui, sans-serif','Arial, sans-serif','Georgia, serif','ui-monospace, monospace'];assert.deepEqual(aliases.map(x=>resolveDesignFont(x).id),['system-sans','neo-grotesque','transitional-serif','monospace']);
 for(const v of ['url(https://evil/font)','Arial; color:red','Arial/*x*/','@import x','Arial\\3b color:red'])assert.equal(isSafeFontStack(v),false,v);
 assert.throws(()=>resolveDesignFont('network-font'));assert.throws(()=>createTypographySnapshot({fontPairId:'unknown'}));
});
test('empty or one-role changes never implicitly take over the other role',()=>{
 const empty=createTypographySnapshot({});assert.deepEqual(empty,{version:'btf-1',heading:null,body:null,overrides:[]});
 const h=createTypographySnapshot({headingFontId:'zh-song'},empty);assert.equal(h.heading?.id,'zh-song');assert.equal(h.body,null);
 const b=createTypographySnapshot({bodyFontId:'monospace'},h);assert.deepEqual(b.heading,h.heading);assert.equal(b.body?.id,'monospace');
});
test('trusted replay validates frozen family bytes without re-resolving the catalog',()=>{
 const profile=createTypographySnapshot({headingFontId:'zh-song'});profile.heading!.stack='"Previously Frozen Local Family", serif';assert.equal(typographySnapshotSchema.parse(profile).heading?.stack,profile.heading!.stack);
 profile.heading!.stack='Arial; background:url(https://bad)';assert.equal(typographySnapshotSchema.safeParse(profile).success,false);
});
