import test from 'node:test';
import assert from 'node:assert/strict';
import { encryptSecret,sha256,randomToken } from '../src/lib/crypto';
import { grantCredit,fundProvider,getWallet } from '../src/modules/ledger';
import { imageConfigSchema,createImageGeneration,reconcileImageGeneration,imageAvailability,imageGenerationQuote,listImageModels,imageJobView,imageUsageCost,imageReservationCost,type FixtureImageContract,type ImagePricing } from '../src/modules/images';
import { mediaFixture,png } from './media-helper';
import { verifiedImagePricing,meteredImageContract,imageTestReservation,createImageTestRequest,validateImageTestResponse } from '../src/lib/image-billing';
import { app } from '../src/index';

const pricing:ImagePricing={baseUrl:'https://api.openai.com/v1',model:'gpt-image-2.6-sunburst',protocol:'images',providerPoolId:'images-pool',n:1,size:'1024x1024',quality:'low',complexity:'low',outputFormat:'png',textInputMicrosPerMillion:5_000_000,cachedTextInputMicrosPerMillion:1_250_000,imageInputMicrosPerMillion:8_000_000,cachedImageInputMicrosPerMillion:2_000_000,imageOutputMicrosPerMillion:30_000_000,pricingConfirmedAt:new Date().toISOString(),billingContract:{kind:'unverified'}};
const contract:FixtureImageContract={version:'fixture-v1',model:pricing.model,size:pricing.size,quality:pricing.quality,complexity:pricing.complexity,maxPromptBytes:10000,maxInputTextTokens:1000,maxInputImageTokens:0,maxOutputImageTokens:2000,cacheBilling:'uncached'};
const pixels=png(1024,1024),usage={input_tokens:100,input_tokens_details:{text_tokens:100,image_tokens:0},output_tokens:823,total_tokens:923,output_tokens_details:{image_tokens:823,text_tokens:0}};
function response(overrides:Record<string,unknown>={}){return {created:1770000000,model:pricing.model,size:pricing.size,quality:pricing.quality,output_format:'png',data:[{b64_json:Buffer.from(pixels).toString('base64')}],usage,...overrides};}
async function fixture(userFunds=1_000_000,providerFunds=1_000_000){const f=mediaFixture(),secret=await encryptSecret(JSON.stringify({apiKey:'sk-fixture-only'}),f.env.ENCRYPTION_KEY,'image-config');f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES('image-config','image','Images','openai',1,'active',?,?,'passed','u',?)").run(JSON.stringify(pricing),secret,new Date().toISOString());if(userFunds)await grantCredit(f.env.DB,{id:'grant',userId:'u',source:'topup',amountMicros:userFunds,referenceId:'topup-receipt'});await fundProvider(f.env.DB,{id:'deposit',providerId:pricing.providerPoolId,amountMicros:providerFunds,referenceId:'provider-deposit'});return f;}
const request={prompt:'一张自然风景图',requestKey:'image-request-once'};
const runtime=(send:typeof fetch,override:FixtureImageContract=contract)=>({fetch:send,fixtureContract:override});

test('production rejects unverified or self-declared image ceilings before reservation or dispatch',async()=>{
 const f=await fixture();try{let calls=0;assert.deepEqual(await imageAvailability(f.env),{available:false,reason:'IMAGE_BOUND_UNVERIFIED'});await assert.rejects(()=>createImageGeneration(f.env,'u','p',request),/尚未启用/);f.env.APP_ENV='production';await assert.rejects(()=>createImageGeneration(f.env,'u','p',request,runtime(async()=>{calls++;return new Response('{}');})),/尚未启用/);assert.equal(calls,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_jobs').get()!.n,0);assert.equal(imageConfigSchema.safeParse({...pricing,billingContract:{kind:'provider-ceiling',maxCostMicros:1}}).success,false);
 }finally{f.db.close();}
});
test('fixed image request double-reserves, dispatches once, settles real token usage and saves private media',async()=>{
 const f=await fixture();try{let calls=0;const rt=runtime(async(url,init)=>{calls++;assert.equal(String(url),'https://api.openai.com/v1/images/generations');assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,65000);assert.equal(f.db.sqlite.prepare('SELECT state FROM api_reservations').get()!.state,'dispatching');const payload=JSON.parse(String(init!.body));assert.equal(payload.n,1);assert.equal(payload.size,'1024x1024');assert.equal(payload.output_format,'png');assert.equal(payload.stream,false);assert.equal(payload.partial_images,0);return new Response(JSON.stringify(response()),{headers:{'x-request-id':'req-provider-fixture'}});});
 const job=await createImageGeneration(f.env,'u','p',request,rt);assert.equal(job.state,'succeeded');assert.ok(job.result_media_id);const wallet=await getWallet(f.env.DB,'u');assert.equal(wallet.consumedMicros,25190);assert.equal(wallet.heldMicros,0);const again=await createImageGeneration(f.env,'u','p',request,rt);assert.equal(again.id,job.id);assert.equal(calls,1);assert.equal(f.storage.objects.size,2);assert.ok(!job.response_json!.includes('b64_json'));assert.equal(job.provider_request_id,'req-provider-fixture');await assert.rejects(()=>createImageGeneration(f.env,'u','p',{...request,prompt:'另一张图'},rt),/请求编号/);
 }finally{f.db.close();}
});
test('an insufficient wallet prevents every HTTP dispatch; a short platform pool no longer does',async()=>{
 for(const funds of [[1,1_000_000],[1_000_000,1]]){const f=await fixture(...funds as [number,number]);try{let calls=0;const job=await createImageGeneration(f.env,'u','p',request,runtime(async()=>{calls++;return new Response('{}');}));if(funds[0]===1){assert.equal(job.state,'failed');assert.equal(job.error_code,'INSUFFICIENT_CREDIT');assert.equal(calls,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);}else{assert.notEqual(job.error_code,'INSUFFICIENT_PROVIDER_FUNDS');assert.equal(calls,1);assert.equal(f.db.sqlite.prepare("SELECT COUNT(*) n FROM provider_funding WHERE reference_id LIKE 'auto:%'").get()!.n,1);}}finally{f.db.close();}}
});
test('parallel duplicate requests dispatch at most once; transport ambiguity keeps both budgets held',async()=>{
 const f=await fixture();try{let calls=0;const rt=runtime(async()=>{calls++;throw new Error('fixture transport lost');});const jobs=await Promise.all(Array.from({length:12},()=>createImageGeneration(f.env,'u','p',request,rt)));assert.equal(new Set(jobs.map(j=>j.id)).size,1);assert.equal(calls,1);const row=f.db.sqlite.prepare('SELECT state,error_code FROM image_jobs').get()!;assert.equal(row.state,'uncertain');assert.equal(row.error_code,'IMAGE_PROVIDER_UNCERTAIN');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,65000);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,65000);
 }finally{f.db.close();}
});
test('missing/unknown billing evidence freezes funds and disables further provider reservations',async()=>{
 for(const overrides of [{usage:undefined},{svg_usage:{output_tokens:2}},{usage:{...usage,input_tokens_details:{...usage.input_tokens_details,cache_write_tokens:10}}}]){const f=await fixture();try{const job=await createImageGeneration(f.env,'u','p',request,runtime(async()=>new Response(JSON.stringify(response(overrides)))));assert.equal(job.state,'uncertain');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,65000);assert.equal(f.db.sqlite.prepare('SELECT enabled FROM provider_pools').get()!.enabled,0);}finally{f.db.close();}}
});
test('token contract breach never silently overdraws the user and suspends provider budget',async()=>{
 const f=await fixture();try{const job=await createImageGeneration(f.env,'u','p',request,runtime(async()=>new Response(JSON.stringify(response({usage:{...usage,output_tokens:2001,total_tokens:2101,output_tokens_details:{image_tokens:2001,text_tokens:0}}})))));assert.equal(job.error_code,'IMAGE_CONTRACT_BREACH');assert.equal(job.state,'uncertain');assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,65000);assert.equal(f.db.sqlite.prepare('SELECT enabled FROM provider_pools').get()!.enabled,0);
 }finally{f.db.close();}
});
test('unknown R2 acknowledgement is recovered from durable response without paid redispatch',async()=>{
 const f=await fixture();try{let calls=0;f.storage.failAfter=true;const rt=runtime(async()=>{calls++;return new Response(JSON.stringify(response()));});const first=await createImageGeneration(f.env,'u','p',request,rt);assert.equal(first.state,'uncertain');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,65000);const final=await reconcileImageGeneration(f.env,'u',first.id,rt);assert.equal(final.state,'succeeded');assert.equal(calls,1);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,25190);await reconcileImageGeneration(f.env,'u',first.id,rt);assert.equal(calls,1);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media').get()!.n,1);await assert.rejects(()=>reconcileImageGeneration(f.env,'other',first.id,rt),/不存在/);
 }finally{f.db.close();}
});
test('known usage is charged even when malformed image cannot be admitted into media',async()=>{
 const f=await fixture();try{const job=await createImageGeneration(f.env,'u','p',request,runtime(async()=>new Response(JSON.stringify(response({data:[{b64_json:Buffer.from('<svg onload="bad()"></svg>').toString('base64')}]})))));assert.equal(job.state,'failed');assert.equal(job.error_code,'MEDIA_INVALID');assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,25190);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media').get()!.n,0);
 }finally{f.db.close();}
});
test('cache split is explicit and exact; aggregate cache counts or extra output billing are not guessed',()=>{
 const split={...contract,cacheBilling:'reported-split-v1' as const},cached={...usage,input_tokens_details:{text_tokens:100,image_tokens:0,cached_tokens:80,cached_tokens_details:{text_tokens:80,image_tokens:0}}};assert.equal(imageUsageCost(pricing,cached,split),24890);assert.equal(imageReservationCost(pricing,contract),65000);assert.throws(()=>imageUsageCost(pricing,cached,contract));assert.throws(()=>imageUsageCost(pricing,{...usage,input_tokens_details:{text_tokens:100,image_tokens:0,cached_tokens:80}},split));assert.throws(()=>imageUsageCost(pricing,{...usage,output_tokens_details:{image_tokens:820,text_tokens:3}},contract));assert.throws(()=>imageUsageCost(pricing,{...usage,total_tokens:922},contract));assert.throws(()=>imageUsageCost(pricing,{...usage,input_tokens:-1},contract));
});
test('AI restrictions are atomically enforced before any image dispatch',async()=>{
 const f=await fixture();try{const now=new Date().toISOString();f.db.sqlite.prepare("INSERT INTO user_restrictions(id,user_id,scope,reason,starts_at,actor_id,created_at) VALUES('restriction','u','ai','fixture',?,'u',?)").run(now,now);let calls=0;const job=await createImageGeneration(f.env,'u','p',request,runtime(async()=>{calls++;return new Response('{}');}));assert.equal(job.error_code,'ACCOUNT_RESTRICTED');assert.equal(calls,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
 }finally{f.db.close();}
});

const meteredPricing:ImagePricing={...pricing,billingContract:{kind:'metered-reserve-v1'}};
// Synthetic capability evidence exists only in this isolated in-memory database.
async function imageModel(f:Awaited<ReturnType<typeof fixture>>,configId:string,model:string,passed=true){
 const config={...meteredPricing,model},serialized=JSON.stringify(config),now=new Date().toISOString();
 f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled' WHERE kind='image' AND provider='openai' AND status='active' AND id<>?").run(configId);
 const secret=await encryptSecret(JSON.stringify({apiKey:'sk-fixture-only'}),f.env.ENCRYPTION_KEY,configId);
 f.db.sqlite.prepare("INSERT INTO integration_configs(id,kind,name,provider,version,status,public_config_json,secret_ciphertext,test_status,created_by,created_at) VALUES(?,'image',?,'openai',1,'active',?,?,'passed','u',?) ON CONFLICT(id) DO UPDATE SET public_config_json=excluded.public_config_json,secret_ciphertext=excluded.secret_ciphertext").run(configId,model,serialized,secret,now);
 if(passed){
  const fingerprint=await sha256(JSON.stringify([configId,'image','openai',serialized]));
  f.db.sqlite.prepare("INSERT INTO integration_function_tests(id,config_id,actor_id,provider_id,request_key,payload_hash,quote_hash,config_fingerprint,state,accounting_state,reserved_micros,actual_micros,request_json,pricing_json,response_json,created_at,updated_at) VALUES(?,?,'u',?,?,?, ?,?,'passed','settled',1000000,0,'{}',?,'{}',?,?)").run('proof-'+configId,configId,config.providerPoolId,'proof-'+configId,'fixture','fixture',fingerprint,serialized,now,now);
  f.db.sqlite.prepare('UPDATE integration_configs SET capability_test_id=? WHERE id=?').run('proof-'+configId,configId);
 }
 return config;
}
async function productionFixture(){const f=await fixture(5_000_000,5_000_000);await imageModel(f,'image-config',meteredPricing.model);f.env.APP_ENV='production';return f;}

test('audited production presets enforce exact model, official price and bounded request profile',async()=>{
 for(const model of ['gpt-image-2.6-sunburst','gpt-image-2.6-flare']){
  const config={...meteredPricing,model};assert.equal(verifiedImagePricing(config).model,model);assert.equal(imageTestReservation(config),1_000_000);
  const payload=createImageTestRequest(config);assert.equal(payload.n,1);assert.equal(payload.quality,'low');assert.equal(payload.output_format,'png');assert.equal(payload.partial_images,0);assert.equal(payload.stream,false);assert.ok(!('max_output_tokens' in payload));assert.equal(payload.complexity,'low');
  const validated=await validateImageTestResponse(config,response({model}));assert.equal(validated.actualMicros,25190);assert.ok(!JSON.stringify(validated).includes('b64_json'));
 }
 for(const change of [{model:'gpt-image-2'},{baseUrl:'https://untrusted.example/v1'},{quality:'high'},{size:'768x768'},{textInputMicrosPerMillion:1},{billingContract:{kind:'unverified'}},{billingContract:{kind:'metered-reserve-v1',maxCostMicros:1}},{n:2}])assert.throws(()=>verifiedImagePricing({...meteredPricing,...change}));
 await assert.rejects(()=>validateImageTestResponse(meteredPricing,response({data:[{b64_json:Buffer.from(png(1,1)).toString('base64')}]})),/尺寸/);
 for(const unknown of [{...usage,output_tokens_details:{...usage.output_tokens_details,reasoning_tokens:20}},{...usage,input_tokens_details:{...usage.input_tokens_details,cached_tokens_details:{text_tokens:0,image_tokens:0,write_tokens:10}}}])assert.throws(()=>imageUsageCost(meteredPricing,unknown,meteredImageContract(meteredPricing)),/未知计费/);
});

test('production options expose the selected provider model, estimate and exact capability',async()=>{
 const f=await productionFixture();try{
  await imageModel(f,'image-flare','gpt-image-2.6-flare');const options=await listImageModels(f.env,'u');assert.equal(options.items.length,1);assert.equal(options.items[0].model,'gpt-image-2.6-flare');assert.equal((await imageGenerationQuote(f.env,'u','image-config')).reason,'IMAGE_CONFIG_UNAVAILABLE');assert.ok(options.items.every(x=>x.available&&x.canReserve&&x.reservationIsEstimate&&x.requiredReservationMicros===1_000_000));
  const quote=await imageGenerationQuote(f.env,'u','image-flare');assert.ok('model' in quote);assert.equal(quote.model,'gpt-image-2.6-flare');assert.equal(quote.maxPromptBytes,4000);assert.equal(quote.canReserve,true);assert.equal((await imageAvailability(f.env)).available,true);
  f.db.sqlite.prepare("UPDATE provider_pools SET enabled=0").run();assert.equal((await imageGenerationQuote(f.env,'u','image-flare')).reason,'PROVIDER_UNAVAILABLE');
  f.db.sqlite.prepare("UPDATE provider_pools SET enabled=1").run();f.db.sqlite.prepare("UPDATE integration_configs SET capability_test_id=NULL WHERE id='image-flare'").run();assert.equal((await imageGenerationQuote(f.env,'u','image-flare')).available,true);
 }finally{f.db.close();}
});

test('production dispatch binds selected immutable model and snapshot, settles actual usage and never resends',async()=>{
 const f=await productionFixture();try{
  await imageModel(f,'image-flare','gpt-image-2.6-flare');let calls=0;const selected={...request,configId:'image-flare'},rt={fetch:async(url:any,init:any)=>{calls++;assert.equal(String(url),'https://api.openai.com/v1/images/generations');const payload=JSON.parse(init.body);assert.equal(payload.model,'gpt-image-2.6-flare');assert.equal(payload.n,1);assert.equal(init.redirect,'manual');assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,1_000_000);return Response.json(response({model:payload.model}));}};
  const job=await createImageGeneration(f.env,'u','p',selected,rt);assert.equal(job.state,'succeeded');assert.equal(job.config_version_id,'image-flare');assert.equal(imageJobView(job).requestKey,request.requestKey);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,25190);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(JSON.parse(job.request_json).billingContract.reservationIsEstimate,true);
  f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled' WHERE id='image-flare'").run();assert.equal((await createImageGeneration(f.env,'u','p',selected,rt)).id,job.id);assert.equal(calls,1);
  await assert.rejects(()=>createImageGeneration(f.env,'u','p',{...selected,configId:'image-config'},rt),/请求编号/);
  for(const configId of ['missing','image-flare',''])await assert.rejects(()=>createImageGeneration(f.env,'u','p',{...request,requestKey:'another-image-request',configId},rt),/所选图片模型/);assert.equal(calls,1);
 }finally{f.db.close();}
});

test('production validates UTF-8 prompt bytes before holding funds or sending HTTP',async()=>{
 const f=await productionFixture();try{
  let calls=0;const rt={fetch:async()=>{calls++;return Response.json(response());}};
  await assert.rejects(()=>createImageGeneration(f.env,'u','p',{...request,prompt:'图'.repeat(1334)},rt),/长度/);
  assert.equal(calls,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_jobs').get()!.n,0);
 }finally{f.db.close();}
});

test('production excess actual usage retains both holds, suspends pool and never treats reserve as a provider ceiling',async()=>{
 const f=await productionFixture();try{
  let calls=0;const bigUsage={...usage,output_tokens:40000,total_tokens:40100,output_tokens_details:{image_tokens:40000,text_tokens:0}},rt={fetch:async()=>{calls++;return Response.json(response({usage:bigUsage}));}};
  assert.equal(imageUsageCost(meteredPricing,bigUsage,meteredImageContract(meteredPricing)),1_200_500);
  const job=await createImageGeneration(f.env,'u','p',request,rt);assert.equal(job.state,'uncertain');assert.equal(job.error_code,'COST_EXCEEDS_RESERVATION');assert.equal((await getWallet(f.env.DB,'u')).heldMicros,1_000_000);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,0);assert.equal(f.db.sqlite.prepare('SELECT enabled FROM provider_pools').get()!.enabled,0);assert.equal(f.db.sqlite.prepare('SELECT reserved_micros FROM provider_pools').get()!.reserved_micros,1_000_000);
  await createImageGeneration(f.env,'u','p',request,rt);await reconcileImageGeneration(f.env,'u',job.id);assert.equal(calls,1);
 }finally{f.db.close();}
});

test('production ambiguous storage acknowledgement recovers original evidence after model deactivation without redispatch',async()=>{
 const f=await productionFixture();try{
  let calls=0;f.storage.failAfter=true;const job=await createImageGeneration(f.env,'u','p',{...request,configId:'image-config'},{fetch:async()=>{calls++;return Response.json(response());}});assert.equal(job.state,'uncertain');
  f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled',public_config_json='{}' WHERE id='image-config'").run();const recovered=await reconcileImageGeneration(f.env,'u',job.id);assert.equal(recovered.state,'succeeded');assert.equal(calls,1);assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,25190);
 }finally{f.db.close();}
});

test('image request lookup finds an old original request beyond recent history and stays owner/project scoped',async()=>{
 const f=await fixture();try{
  for(let i=0;i<35;i++){
   const time=new Date(Date.now()-100000+i*1000).toISOString(),key='image-history-request-'+i;
   f.db.sqlite.prepare("INSERT INTO image_jobs(id,user_id,project_id,config_version_id,request_key,request_hash,state,request_json,pricing_json,created_at,updated_at) VALUES(?,'u','p','image-config',?,'fixture','failed','{}',?,?,?)").run('history-'+i,key,JSON.stringify(pricing),time,time);
  }
  const token=randomToken(),now=new Date().toISOString();f.db.sqlite.prepare('INSERT INTO sessions(id,token_hash,user_id,csrf_token,created_at,expires_at,ip_hash) VALUES(?,?,?,?,?,?,?)').run(token,await sha256(token),'u',randomToken(),now,'2099-01-01T00:00:00.000Z','fixture');
  const lookup=(path:string)=>app.fetch(new Request(f.env.APP_ORIGIN+'/api/images/projects/'+path,{headers:{cookie:'benos_session='+token}}),f.env);
  const latest=await (await lookup('p/jobs')).json() as any;assert.equal(latest.data.items.length,30);assert.ok(!latest.data.items.some((x:any)=>x.requestKey==='image-history-request-0'));
  const exact=await (await lookup('p/jobs?requestKey=image-history-request-0')).json() as any;assert.equal(exact.data.items.length,1);assert.equal(exact.data.items[0].id,'history-0');assert.equal(exact.data.items[0].requestKey,'image-history-request-0');
  assert.deepEqual((await (await lookup('p2/jobs?requestKey=image-history-request-0')).json() as any).data.items,[]);assert.equal((await lookup('other-project/jobs?requestKey=image-history-request-0')).status,404);assert.equal((await lookup('p/jobs?requestKey=short')).status,400);
 }finally{f.db.close();}
});

test('slot generation dispatches real landscape and portrait sizes with unchanged usage accounting',async()=>{
 for(const [slot,size,width,height] of [
  [{width:1440,height:640,fit:'cover' as const,focalPoint:'right' as const,textSafeArea:'left' as const},'1536x1024',1536,1024],
  [{width:400,height:600,fit:'contain' as const,focalPoint:'center' as const,textSafeArea:'none' as const},'1024x1536',1024,1536],
 ] as const){
  const f=await productionFixture();try{
   let calls=0;const input={...request,slot},rt={fetch:async(_url:any,init:any)=>{
    calls++;const payload=JSON.parse(init.body);assert.equal(payload.size,size);assert.match(payload.prompt,new RegExp('destination frame '+slot.width+'x'+slot.height));assert.equal(payload.quality,'low');
    return Response.json(response({size,data:[{b64_json:Buffer.from(png(width,height)).toString('base64')}]}));
   }};
   const job=await createImageGeneration(f.env,'u','p',input,rt);assert.equal(job.state,'succeeded');
   assert.equal(JSON.parse(job.pricing_json).size,size);assert.equal(JSON.parse(job.request_json).billingContract.size,size);
   const view=imageJobView(job);assert.equal(view.layout.generation.width,width);assert.equal(view.layout.generation.height,height);assert.equal(view.layout.display.objectFit,slot.fit);
   const media=f.db.sqlite.prepare('SELECT width,height FROM project_media WHERE id=?').get(job.result_media_id!);assert.deepEqual({...media},{width,height});
   assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,25190);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
   assert.equal((await createImageGeneration(f.env,'u','p',input,rt)).id,job.id);assert.equal(calls,1);
   await assert.rejects(()=>createImageGeneration(f.env,'u','p',{...input,slot:{...slot,width:800}},rt),/请求编号/);assert.equal(calls,1);
  }finally{f.db.close();}
 }
});

test('slot generation rejects invalid frames and oversized composed prompts before dispatch or reservation',async()=>{
 const f=await productionFixture();try{
  let calls=0;const rt={fetch:async()=>{calls++;return Response.json(response());}};
  await assert.rejects(()=>createImageGeneration(f.env,'u','p',{...request,slot:{width:1,height:400}},rt),/图框/);
  await assert.rejects(()=>createImageGeneration(f.env,'u','p',{...request,prompt:'图'.repeat(1300),slot:{width:1200,height:600}},rt),/长度/);
  assert.equal(calls,0);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM image_jobs').get()!.n,0);
  const quote=await imageGenerationQuote(f.env,'u');assert.ok('supportedSizes' in quote);assert.deepEqual(quote.supportedSizes,['1024x1024','1536x1024','1024x1536']);
 }finally{f.db.close();}
});

test('a provider returning square bytes for a landscape request cannot save a misleading media result',async()=>{
 const f=await productionFixture();try{
  const job=await createImageGeneration(f.env,'u','p',{...request,slot:{width:1440,height:640}},{fetch:async()=>Response.json(response({size:'1536x1024'}))});
  assert.equal(job.state,'failed');assert.equal(job.error_code,'IMAGE_OUTPUT_INVALID');assert.equal(job.result_media_id,null);
  assert.equal((await getWallet(f.env.DB,'u')).consumedMicros,25190);assert.equal((await getWallet(f.env.DB,'u')).heldMicros,0);
  assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) n FROM project_media').get()!.n,0);
 }finally{f.db.close();}
});

test('landscape recovery keeps its immutable geometry after the configured model is disabled',async()=>{
 const f=await productionFixture();try{
  let calls=0;f.storage.failAfter=true;
  const job=await createImageGeneration(f.env,'u','p',{...request,slot:{width:1200,height:600}},{fetch:async()=>{
   calls++;return Response.json(response({size:'1536x1024',data:[{b64_json:Buffer.from(png(1536,1024)).toString('base64')}]}));
  }});assert.equal(job.state,'uncertain');
  f.db.sqlite.prepare("UPDATE integration_configs SET status='disabled',public_config_json='{}' WHERE id='image-config'").run();
  const recovered=await reconcileImageGeneration(f.env,'u',job.id);assert.equal(recovered.state,'succeeded');assert.equal(calls,1);
  assert.equal(imageJobView(recovered).layout.generation.size,'1536x1024');assert.equal(imageJobView(recovered).layout.slot.width,1200);
 }finally{f.db.close();}
});
