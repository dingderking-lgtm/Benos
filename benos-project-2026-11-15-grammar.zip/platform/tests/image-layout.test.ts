import test from 'node:test';
import assert from 'node:assert/strict';
import { IMAGE_SIZES,imageSlotSchema,imageSizeForSlot,imageLayout,imageDisplay,imagePromptForSlot,workflowImagesSchema } from '../src/lib/image-layout';
import { IMAGE_WORKFLOW_TOOL } from '../src/modules/ai-workflow';

test('planned frames choose the closest standard image ratio instead of every image being square',()=>{
 for(const [width,height,size] of [[1440,640,'1536x1024'],[1200,675,'1536x1024'],[600,400,'1536x1024'],[400,600,'1024x1536'],[400,500,'1024x1536'],[400,400,'1024x1024'],[440,400,'1024x1024']] as const){
  assert.equal(imageSizeForSlot({width,height}),size);
 }
 assert.deepEqual(IMAGE_SIZES,['1024x1024','1536x1024','1024x1536']);
});

test('crop instructions describe the actual visible area and reserve space for HTML text',()=>{
 const slot=imageSlotSchema.parse({width:1440,height:640,focalPoint:'right',textSafeArea:'left'});
 const layout=imageLayout(slot),prompt=imagePromptForSlot('An industrial recycling line in a bright factory.',slot);
 assert.equal(layout.generation.size,'1536x1024');
 assert.equal(layout.display.aspectRatio,'1440 / 640');
 assert.equal(layout.display.objectPosition,'100% 50%');
 assert.equal(layout.display.cropFraction,.333);
 assert.deepEqual(layout.display.visibleRegion,{left:0,top:16.7,width:100,height:66.7});
 assert.match(prompt,/output 1536x1024/);assert.match(prompt,/1440x640/);
 assert.match(prompt,/covering 100% of width and 66.7% of height/);
 assert.match(prompt,/left third quiet/);assert.match(prompt,/extra 8% inset/);
});

test('contain preserves complete equipment and reports no crop while cover respects its anchor',()=>{
 const slot=imageSlotSchema.parse({width:400,height:500,fit:'contain',focalPoint:'top'});
 assert.equal(imageLayout(slot).generation.size,'1024x1536');
 assert.equal(imageLayout(slot).display.objectFit,'contain');
 assert.equal(imageLayout(slot).display.cropFraction,0);
 assert.match(imagePromptForSlot('A complete industrial machine.',slot),/complete subject/);
 assert.doesNotMatch(imagePromptForSlot('A complete industrial machine.',slot),/visible crop/);
 const cropped=imageDisplay(imageSlotSchema.parse({width:400,height:800,focalPoint:'left'}),1024,1536);
 assert.deepEqual(cropped.visibleRegion,{left:0,top:0,width:75,height:100});
});

test('invalid dimensions, unsafe enum values and unsolicited geometry fields are rejected',()=>{
 for(const slot of [{width:0,height:400},{width:4097,height:400},{width:400.5,height:400},{width:4096,height:64},{width:'400',height:400},{width:400,height:400,fit:'fill'},{width:400,height:400,focalPoint:'50%;background:url(https://bad)'},{width:400,height:400,size:'9000x9000'}]){
  assert.equal(imageSlotSchema.safeParse(slot).success,false,JSON.stringify(slot));
 }
});

test('new tool calls require full frame geometry but durable legacy calls remain parseable',()=>{
 const parameters=IMAGE_WORKFLOW_TOOL.parameters as any,item=parameters.properties.images.items;
 assert.ok(item.required.includes('slot'));
 assert.deepEqual(item.properties.slot.required,['width','height','fit','focalPoint','textSafeArea']);
 const legacy=workflowImagesSchema.parse({images:[{section:'hero',prompt:'An industrial factory interior.'}]});
 assert.equal(legacy.images[0].slot,undefined);
 const next=workflowImagesSchema.parse({images:[{section:'hero',prompt:'An industrial factory interior.',slot:{width:1440,height:640}}]});
 assert.deepEqual(next.images[0].slot,{width:1440,height:640,fit:'cover',focalPoint:'center',textSafeArea:'none'});
});
