import assert from 'node:assert/strict';
import test from 'node:test';
import { TestD1,testEnv } from './d1-helper';
import { ensureHpanelResources,inspectHpanelInventory,listHpanelWebsites } from '../src/modules/hosting-hostinger';
const cfg={adapter:'hostinger-hpanel' as const,deploymentMode:'registered-php-bridge' as const,hostingOrderId:100,accountUsername:'u12345678'};
const job={id:'job_'+'a'.repeat(32),siteId:'site_'+'a'.repeat(32),domain:'customer.example.com'};
const token='test-hostinger-token-long-enough';
function fixture(){const db=new TestD1(),env=testEnv(db),now=new Date().toISOString();
 db.sqlite.prepare("INSERT INTO users(id,email,name,password_hash,role,status,created_at,updated_at) VALUES('usr_hp','hp@example.com','Owner','x','user','active',?,?)").run(now,now);
 db.sqlite.prepare("INSERT INTO integration_configs(id,kind,provider,version,name,public_config_json,status,test_status,created_by,created_at) VALUES('cfg_hp','hosting','benos-bridge',1,'test','{}','active','passed','usr_hp',?)").run(now);
 db.sqlite.prepare("INSERT INTO sites(id,user_id,name,domain,cms_admin_email,state,created_at,updated_at) VALUES(?,'usr_hp','Customer',?,'cms@example.com','pending',?,?)").run(job.siteId,job.domain,now,now);
 db.sqlite.prepare("INSERT INTO provisioning_jobs(id,site_id,user_id,kind,state,step,idempotency_key,payload_hash,created_at,updated_at) VALUES(?,?,'usr_hp','create','pending','setup','hostinger_job','hash',?,?)").run(job.id,job.siteId,now,now);
 return {db,env,unpause:()=>db.sqlite.prepare('UPDATE hosting_provider_intents SET next_poll_at=NULL').run()};
}
test('hPanel onboarding and database creation reconcile exact durable resources without repeating POST',async()=>{
 const f=fixture(),original=globalThis.fetch;let websitePosts=0,dbPosts=0,ready=false,dbRecord:Record<string,unknown>|null=null;
 globalThis.fetch=async(input,init)=>{const url=new URL(String(input));assert.equal(url.origin,'https://developers.hostinger.com');assert.equal(new Headers(init?.headers).get('Authorization'),'Bearer '+token);
   const json=(value:unknown)=>new Response(JSON.stringify(value),{status:200,headers:{'content-type':'application/json'}});
   if(url.pathname.endsWith('/verify-ownership'))return json({domain:job.domain,is_accessible:true});
   if(url.pathname.endsWith('/websites'))return json(ready?[{domain:job.domain,username:cfg.accountUsername,order_id:100,root_directory:'/home/'+cfg.accountUsername+'/domains/'+job.domain+'/public_html'}]:[]);
   if(url.pathname.endsWith('/orders/100/onboardings')){websitePosts++;return json({status:'running'});}
   if(url.pathname.endsWith('/onboardings'))return json(websitePosts?[{domain:job.domain,username:cfg.accountUsername,status:ready?'completed':'running',created_at:new Date().toISOString()}]:[]);
   if(url.pathname.endsWith('/databases')){
     if(init?.method==='POST'){dbPosts++;const body=JSON.parse(String(init.body));assert.ok(body.name.startsWith(cfg.accountUsername+'_'));assert.ok(body.name.length<=32);assert.equal(body.website_domain,job.domain);dbRecord={name:body.name,user:body.user,domain:job.domain};return json({});}
     return json({data:dbRecord?[dbRecord]:[],meta:{total:dbRecord?1:0,current_page:1,per_page:100}});
   }throw new Error('Unexpected API path '+url.pathname);
 };
 try{
   assert.equal((await ensureHpanelResources(f.env,'cfg_hp',cfg,token,job)).step,'wait_website_setup');assert.equal(websitePosts,1);
   f.unpause();assert.equal((await ensureHpanelResources(f.env,'cfg_hp',cfg,token,job)).ready,false);assert.equal(websitePosts,1);
   ready=true;f.unpause();assert.equal((await ensureHpanelResources(f.env,'cfg_hp',cfg,token,job)).step,'verify_created_database');assert.equal(dbPosts,1);
   f.unpause();const done=await ensureHpanelResources(f.env,'cfg_hp',cfg,token,job);assert.equal(done.ready,true);assert.ok(done.database!.password.length>=32);
   assert.equal((await ensureHpanelResources(f.env,'cfg_hp',cfg,token,job)).ready,true);assert.equal(websitePosts,1);assert.equal(dbPosts,1);
   const stored=f.db.sqlite.prepare('SELECT database_secret_ciphertext FROM hosting_provider_intents').get()!;assert.ok(!String(stored.database_secret_ciphertext).includes(done.database!.password));
 }finally{globalThis.fetch=original;f.db.close();}
});
test('hPanel ownership challenge blocks creation and returns only the verification TXT',async()=>{
 const f=fixture(),original=globalThis.fetch;let calls=0;
 globalThis.fetch=async(input)=>{calls++;assert.ok(String(input).endsWith('/verify-ownership'));return new Response(JSON.stringify({domain:job.domain,is_accessible:false,txt_to_verify:'verification-value'}));};
 try{const result=await ensureHpanelResources(f.env,'cfg_hp',cfg,token,job);assert.equal(result.step,'verify_domain_ownership');assert.equal(result.requiredDnsTxt,'verification-value');assert.equal(calls,1);assert.equal(f.db.sqlite.prepare('SELECT website_create_attempted FROM hosting_provider_intents').get()!.website_create_attempted,0);}
 finally{globalThis.fetch=original;f.db.close();}
});
test('hPanel lost POST response remains uncertain and never issues a duplicate onboarding',async()=>{
 const f=fixture(),original=globalThis.fetch;let posts=0;
 globalThis.fetch=async(input,init)=>{const path=new URL(String(input)).pathname;
   if(path.endsWith('/verify-ownership'))return new Response(JSON.stringify({domain:job.domain,is_accessible:true}));
   if(path.includes('/orders/')){posts++;throw new Error('connection lost');}
   return new Response('[]');
 };
 try{await assert.rejects(ensureHpanelResources(f.env,'cfg_hp',cfg,token,job),/结果尚未确认/);const next=await ensureHpanelResources(f.env,'cfg_hp',cfg,token,job);assert.equal(next.state,'uncertain');assert.equal(posts,1);}
 finally{globalThis.fetch=original;f.db.close();}
});
test('hPanel refuses an existing customer website and immutable account changes',async()=>{
 const f=fixture(),original=globalThis.fetch;
 globalThis.fetch=async(input)=>new Response(JSON.stringify(String(input).endsWith('/verify-ownership')?{domain:job.domain,is_accessible:true}:[{domain:job.domain,username:cfg.accountUsername,order_id:100}]));
 try{await assert.rejects(ensureHpanelResources(f.env,'cfg_hp',cfg,token,job),/不能自动覆盖/);await assert.rejects(ensureHpanelResources(f.env,'cfg_hp',{...cfg,accountUsername:'u9999'},token,job),/原始账号范围已变化/);}
 finally{globalThis.fetch=original;f.db.close();}
});
test('paginated website inventory includes later-page account resources before capacity or scope decisions',async()=>{
 const original=fetch;const pages:number[]=[];
 globalThis.fetch=async(input)=>{
  const url=new URL(String(input));
  if(url.pathname.endsWith('/databases'))return Response.json({data:[{name:'existing_database'}],meta:{total:1,current_page:1,per_page:100}});
  assert.equal(url.pathname,'/api/hosting/v1/websites');const page=Number(url.searchParams.get('page'));pages.push(page);
  return Response.json({data:page===1?[{domain:'other.example.com',username:'u9999',order_id:200}]:[{domain:job.domain,username:cfg.accountUsername,order_id:100}],meta:{total:2,current_page:page,per_page:1}});
 };
 try{const inventory=await inspectHpanelInventory(cfg,token);assert.deepEqual(inventory,{domains:[job.domain],databases:['existing_database']});assert.deepEqual(pages,[1,2]);}
 finally{globalThis.fetch=original;}
});
test('malformed or empty intermediate website pages cannot silently undercount capacity',async()=>{
 const original=fetch;
 try{
  globalThis.fetch=async()=>Response.json({data:[],meta:{total:2,current_page:1,per_page:1}});
  await assert.rejects(listHpanelWebsites(token),/分页信息不完整/);
  globalThis.fetch=async()=>Response.json({data:[{domain:'site.example.com'}],meta:{total:1,current_page:2,per_page:100}});
  await assert.rejects(listHpanelWebsites(token),/分页信息无效/);
  globalThis.fetch=async()=>Response.json({data:[{domain:'site.example.com'}]});
  await assert.rejects(listHpanelWebsites(token),/响应格式无效/);
 }finally{globalThis.fetch=original;}
});
