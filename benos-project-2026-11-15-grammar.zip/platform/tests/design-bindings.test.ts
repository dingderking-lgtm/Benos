import test from 'node:test';
import assert from 'node:assert/strict';
import { assertDesignScope,type DesignScope } from '../src/modules/design-nodes';
import example from '../src/contracts/site-example.json';

const scopes:DesignScope[]=[{kind:'node',templateId:1,nodeKey:'n0'},{kind:'site'}];
function pair(before:string,after:string){const base=structuredClone(example),next=structuredClone(example);base.templates[0].document.html='<section>'+before+'</section>';next.templates[0].document.html='<section>'+after+'</section>';return {base,next};}
function rejected(before:string,after:string){const {base,next}=pair(before,after);for(const scope of scopes)assert.throws(()=>assertDesignScope(base,next,scope),(error:any)=>error.code==='DESIGN_BINDINGS',scope.kind);}
function accepted(before:string,after:string){const {base,next}=pair(before,after);for(const scope of scopes)assert.doesNotThrow(()=>assertDesignScope(base,next,scope),scope.kind);}

test('selected-block links stay fixed while whole-site edits may change plain static destinations',()=>{
 for(const after of ['<a href="/contact">Home</a><a href="/">Contact</a>','<a href="/contact">Contact</a><a href="/">Home</a>']){
  const {base,next}=pair('<a href="/">Home</a><a href="/contact">Contact</a>',after);
  assert.throws(()=>assertDesignScope(base,next,scopes[0]),(error:any)=>error.code==='DESIGN_BINDINGS');
  assert.doesNotThrow(()=>assertDesignScope(base,next,{kind:'site'}));
 }
});

test('whole-site composition can add, remove and reorganize plain anchors while selected blocks remain strict',()=>{
 const changes=[
  ['<a id="cta" href="/contact">Contact</a>','<a id="cta">Contact</a>'],
  ['<a id="cta" href="/contact">Contact</a>','<a id="other" href="/contact">Contact</a>'],
  ['<a href="/contact">Contact</a>','<button>Contact</button>'],
  ['<span>Brand</span>','<a href="/">Brand</a>'],
  ['<a href="/">Brand</a>','<span>Brand</span>'],
  ['<a href="/">Home</a>','<a href="/">Home</a><a href="/contact">Contact</a>'],
  ['<a href="/">Home</a><a href="/contact">Contact</a>','<a href="/contact">Contact</a>'],
 ];
 for(const [before,after] of changes){
  const {base,next}=pair(before,after);
  assert.doesNotThrow(()=>assertDesignScope(base,next,{kind:'site'}));
  assert.throws(()=>assertDesignScope(base,next,scopes[0]),(error:any)=>error.code==='DESIGN_BINDINGS');
 }
});

test('all non-presentation link bindings keep their identity and topology',()=>{
 rejected('<a href="/contact">Contact</a>','<a href="/contact" data-template="new">Contact</a>');
 rejected('<link href="/theme.css">','<link href="/other.css">');
 rejected('<svg><a href="/contact"><text>Contact</text></a></svg>','<svg><a href="/other"><text>Contact</text></a></svg>');
 rejected('<svg><a xlink:href="/contact"><text>Contact</text></a></svg>','<svg><a xlink:href="/other"><text>Contact</text></a></svg>');
 rejected('<a href="/contact" data-media-id="photo">Photo</a>','<a href="/contact">Photo</a>');
 rejected('<a href="/contact" name="target">Contact</a>','<a href="/contact">Contact</a>');
});

test('CMS, form, template and dynamic-placeholder links stay protected during whole-site edits',()=>{
 for(const before of [
  '<div data-aacms="page-content"><a href="/contact">Contact</a></div>',
  '<a data-template="one" href="/contact">Contact</a>',
  '<form><div><a href="/contact">Contact</a></div></form>',
  '<a form="inquiry" href="/contact">Contact</a>',
  '<template><a href="/contact">Contact</a></template>',
  '<div title="{{brand}}"><a href="/contact">Contact</a></div>',
  '<a href="/contact">{{name}}</a>',
  '<a href="/contact/{{id}}">Contact</a>',
 ])rejected(before,before.replace('/contact','/other'));
});

test('ordinary links cannot be added or removed inside managed boundaries or around bound descendants',()=>{
 for(const [open,close] of [
  ['<nav data-aacms="site-navigation" data-aacms-menu="1">','</nav>'],
  ['<div data-aacms="page-content">','</div>'],
  ['<form>','</form>'],
  ['<template>','</template>'],
  ['<div title="{{brand}}">','</div>'],
 ]){
  const original=open+'<a href="/">Home</a>'+close,added=open+'<a href="/">Home</a><a href="/contact">Contact</a>'+close;
  rejected(original,added);rejected(added,original);
 }
 for(const content of ['{{brand}}','<span data-aacms="site-name">Brand</span>','<!-- {{brand}} -->','<label for="email">Email</label>']){
  rejected(content,'<a href="/">'+content+'</a>');
  rejected('<a href="/">'+content+'</a>',content);
 }
 rejected('<div data-aacms="card"><a href="/">Brand</a></div>','<div data-aacms="card"></div><a href="/">Brand</a>');
});
test('each CMS node retains its own attribute pairs, binding order and multiplicity',()=>{
 const before='<div data-aacms="title" data-template="one"></div><div data-aacms="summary" data-template="two"></div>';
 rejected(before,'<div data-aacms="title" data-template="two"></div><div data-aacms="summary" data-template="one"></div>');
 rejected(before,'<div data-aacms="summary" data-template="two"></div><div data-aacms="title" data-template="one"></div>');
 rejected(before,before+'<div data-aacms="title" data-template="one"></div>');
});
test('form field names cannot exchange targets or cross a form boundary',()=>{
 rejected('<form action="/contact"><input name="email"><input name="phone"></form>','<form action="/contact"><input name="phone"><input name="email"></form>');
 rejected('<form><input name="email"></form><form><input name="phone"></form>','<form></form><input name="email"><form><input name="phone"></form>');
 rejected('<form action="/contact" method="post"><input name="email"></form>','<form action="/contact" method="get"><input name="email"></form>');
});
test('label references and explicit form owners remain paired to their controls',()=>{
 rejected('<label for="email">Email</label><input id="email" name="email">','<label for="email">Email</label><input id="phone" name="email">');
 rejected('<input name="email" form="contact"><input name="phone" form="quote">','<input name="email" form="quote"><input name="phone" form="contact">');
});
test('binding ancestry cannot be flattened or moved into another CMS container',()=>{
 rejected('<div data-aacms="card"><a href="/contact">Contact</a></div><div data-aacms="footer"></div>','<div data-aacms="card"></div><a href="/contact">Contact</a><div data-aacms="footer"></div>');
});
test('placeholder order and owning attributes cannot be exchanged or removed',()=>{
 rejected('<p>{{title}} {{summary}}</p>','<p>{{summary}} {{title}}</p>');
 rejected('<img title="{{title}}" alt="{{summary}}">','<img title="{{summary}}" alt="{{title}}">');
 rejected('<div data-aacms="card">{{title}}</div>{{summary}}','<div data-aacms="card"></div>{{title}}{{summary}}');
});
test('inert template content and comment placeholders remain part of the binding projection',()=>{
 rejected('<template><a href="/contact">Contact</a></template>','<template><a href="/other">Contact</a></template>');
 rejected('<template><a href="/contact">Contact</a></template>','<a href="/contact">Contact</a>');
 rejected('<!-- {{title}} --><!-- {{summary}} -->','<!-- {{summary}} --><!-- {{title}} -->');
});
test('decorative wrappers, classes, styles, text and attribute order can still change',()=>{
 accepted('<div class="old"><a data-template="one" href="/contact?a=1&amp;b=2"><span>Contact</span></a></div>',
  '<aside class="new"><div style="padding:12px"><a href="/contact?a=1&#38;b=2" style="color:#333" data-template="one"><strong>Talk to us</strong></a></div></aside>');
 accepted('<div data-aacms="card"><p>{{title}} {{summary}}</p></div>',
  '<div class="styled" data-aacms="card"><section><h2>{{title}}</h2><p>{{summary}}</p></section></div>');
 accepted('<form action="/contact" method="post"><input name="email"><input name="phone"></form>',
  '<form method="post" class="two-columns" action="/contact"><div><input class="field" name="email"></div><section><input style="padding:12px" name="phone"></section></form>');
});
