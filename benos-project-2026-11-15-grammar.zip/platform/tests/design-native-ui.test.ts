import test from 'node:test';
import assert from 'node:assert/strict';
import { starterManifest } from '../src/contracts/starter-library';
import { nativePreviewPageKeys } from '../src/modules/native-previews';
// @ts-ignore Browser ES module exercised directly for its rendered/action contract.
import { nativePageOptions,renderNativeTools,handleNativeAction,nativePreview,changeNativeInput,stopNativePreviewPolling } from '../public/js/design-native.js';
// @ts-ignore Browser session state is shared with the actual native toolbar.
import { visualState } from '../public/js/design-editor.js';

test('native toolbar offers exactly the server keys for samples, real articles, disabled and omitted blog settings',()=>{
 for(const kind of ['studio','industry','actual','disabled','implicit','none']){
  const manifest:any=starterManifest(kind==='industry'?'industry':'studio')!;
  if(kind==='actual')for(const key of ['story-one','story-two'])manifest.site.pages.push({...manifest.site.pages[1],key,slug:key,title:key,type:'article'});
  if(kind==='disabled')manifest.site.blog.enabled=false;
  if(kind==='implicit')delete manifest.site.blog.enabled;
  if(kind==='none')delete manifest.site.blog;
  const data={project:{id:'native-'+kind,current_version_id:'v'},selected:{id:'v',manifest},visual:{proposal:null}},user={id:'test'};
  const options=nativePageOptions(manifest);assert.deepEqual(options.map((option:any)=>option.key),nativePreviewPageKeys(manifest));
  const html=renderNativeTools(data,user);
  if(kind==='actual'){assert.match(html,/story-one（文章详情）/);assert.match(html,/story-two（文章详情）/);assert.doesNotMatch(html,/value="__blog_article"/);}
  else if(kind!=='none')assert.match(html,/文章详情（示例）/);
 }
});
test('native actions preserve actual and synthetic selection and clear a stale page after switching candidate',async()=>{
 const previousFetch=globalThis.fetch,previousLocation=(globalThis as any).location,calls:any[]=[];
 (globalThis as any).location={origin:'https://benos.example'};
 globalThis.fetch=(async(_url:any,init:any)=>{const chosen=JSON.parse(init.body);calls.push(chosen);return Response.json({ok:true,data:jobView('preview-'+calls.length,'native-action-project',chosen,'ready')});}) as typeof fetch;
 try{
  const manifest:any=starterManifest('studio')!,user={id:'native-action-user'},data:any={project:{id:'native-action-project',current_version_id:'v'},selected:{id:'v',manifest},visual:{proposal:null}},context={state:{user,resource:data},render(){}};
  const state=visualState(data,user);state.nativePage='__blog_article';
  await handleNativeAction('design-native-render',{},context);assert.deepEqual(withoutKey(calls.at(-1)),{versionId:'v',pageKey:'__blog_article'});
  const article=structuredClone(manifest);article.site.pages.push({...article.site.pages[1],key:'real-story',slug:'real-story',type:'article'});
  data.visual.proposal={id:'candidate',manifest:article};
  renderNativeTools(data,user);assert.equal(state.nativePage,'home');
  state.nativePage='real-story';await handleNativeAction('design-native-render',{},context);assert.deepEqual(withoutKey(calls.at(-1)),{candidateId:'candidate',pageKey:'real-story'});
  data.visual.proposal=null;
  await handleNativeAction('design-native-render',{},context);assert.deepEqual(withoutKey(calls.at(-1)),{versionId:'v',pageKey:'home'});
  assert.equal(state.nativePage,'home');
 }finally{globalThis.fetch=previousFetch;(globalThis as any).location=previousLocation;}
});

function withoutKey(value:any){const {requestKey,...rest}=value;assert.match(requestKey,/^[A-Za-z0-9:_-]{16,128}$/);return rest;}
function jobView(id:string,projectId:string,chosen:any,state='processing',steps=0){return {id,projectId,versionId:chosen.versionId??null,candidateId:chosen.candidateId??null,pageKey:chosen.pageKey,state,phase:state==='ready'?'complete':'transfer',completedSteps:steps,bytesSent:steps?100:0,totalBytes:100,artifactBytesReceived:0,artifactBytesTotal:0,errorCode:null,retryable:state==='processing',busy:false,expiresAt:new Date(Date.now()+1800000).toISOString(),...(state==='ready'?{previewUrl:'/preview/native/'+projectId+'/'+id,cmsVersion:'1.9.21',usesSampleData:true,sanitizationChanges:[]}: {})};}
function contextFor(suffix:string){const user={id:'native-ui-'+suffix},data={project:{id:'native-project-'+suffix,current_version_id:'v'},selected:{id:'v',manifest:starterManifest('studio')},visual:{proposal:null}},context={state:{user,resource:data},render(){}};return {user,data,context,state:visualState(data,user)};}

test('lost creation acknowledgement reuses the original key and never falls back to legacy preview POST',async()=>{
 const original=globalThis.fetch,location=(globalThis as any).location,f=contextFor('lost-create'),calls:any[]=[];(globalThis as any).location={origin:'https://benos.example'};
 globalThis.fetch=async(url,init)=>{assert.match(String(url),/native-preview-jobs$/);const body=JSON.parse(String(init!.body));calls.push(body);if(calls.length===1)throw new Error('lost acknowledgement');return Response.json({ok:true,data:jobView('preview-lost',f.data.project.id,body,'ready')});};
 try{await handleNativeAction('design-native-render',{},f.context);assert.equal(nativePreview(f.data,f.user),null);await handleNativeAction('design-native-render',{},f.context);assert.equal(calls.length,2);assert.equal(calls[0].requestKey,calls[1].requestKey);assert.equal(nativePreview(f.data,f.user)?.id,'preview-lost');}finally{globalThis.fetch=original;(globalThis as any).location=location;stopNativePreviewPolling();}
});

test('an uncertain step retries the same ordinal and background advancement never skips ahead locally',async()=>{
 const original=globalThis.fetch,location=(globalThis as any).location,f=contextFor('lost-step'),steps:number[]=[],chosen={versionId:'v',pageKey:'home'};let current:any=jobView('preview-step',f.data.project.id,chosen),first=true;(globalThis as any).location={origin:'https://benos.example'};
 globalThis.fetch=async(url,init)=>{if(String(url).endsWith('/continue')){const step=JSON.parse(String(init!.body)).step;steps.push(step);if(first){first=false;current.errorCode='NATIVE_PREVIEW_UNCERTAIN';return Response.json({ok:true,data:current});}assert.equal(step,1);current=jobView('preview-step',f.data.project.id,chosen,'ready',4);}return Response.json({ok:true,data:current});};
 try{await handleNativeAction('design-native-render',{},f.context);assert.deepEqual(steps,[1]);assert.equal(nativePreview(f.data,f.user),null);await handleNativeAction('design-native-render',{},f.context);assert.deepEqual(steps,[1,1]);assert.equal(nativePreview(f.data,f.user)?.id,'preview-step');}finally{globalThis.fetch=original;(globalThis as any).location=location;stopNativePreviewPolling();}
});

test('a completed old page request never replaces the newly selected page or candidate preview',async()=>{
 const original=globalThis.fetch,location=(globalThis as any).location,f=contextFor('source-change');let resolve!:(value:Response)=>void,chosen:any;(globalThis as any).location={origin:'https://benos.example'};
 globalThis.fetch=(_url,init)=>{chosen=JSON.parse(String(init!.body));return new Promise<Response>(done=>{resolve=done;});};
 try{const pending=handleNativeAction('design-native-render',{},f.context);await Promise.resolve();f.state.nativePage='contact';resolve(Response.json({ok:true,data:jobView('preview-old',f.data.project.id,chosen,'ready')}));await pending;assert.equal(nativePreview(f.data,f.user),null);assert.notEqual(f.state.previewMode,'native');assert.equal(f.state.nativePage,'contact');}finally{globalThis.fetch=original;(globalThis as any).location=location;stopNativePreviewPolling();}
});

test('ready preview addresses must match the selected project and job and cancelled previews are cleared',async()=>{
 const original=globalThis.fetch,location=(globalThis as any).location,f=contextFor('url-cancel');let current:any=jobView('preview-url',f.data.project.id,{versionId:'v',pageKey:'home'},'ready');(globalThis as any).location={origin:'https://benos.example'};
 globalThis.fetch=async(url)=>{if(String(url).endsWith('/cancel'))current={...current,state:'cancelled',previewUrl:undefined};return Response.json({ok:true,data:current});};
 try{current.previewUrl='https://other.example/preview/native/'+f.data.project.id+'/preview-url';await handleNativeAction('design-native-render',{},f.context);assert.equal(nativePreview(f.data,f.user),null);current.previewUrl='/preview/native/'+f.data.project.id+'/preview-url';await handleNativeAction('design-native-open',{},f.context);assert.ok(nativePreview(f.data,f.user));await handleNativeAction('design-native-cancel',{},f.context);assert.equal(nativePreview(f.data,f.user),null);assert.equal(f.state.previewMode,'design');}finally{globalThis.fetch=original;(globalThis as any).location=location;stopNativePreviewPolling();}
});

test('a candidate selected while another source is preparing cannot be replaced by the old ready result',async()=>{
 const original=globalThis.fetch,location=(globalThis as any).location,f=contextFor('candidate-race');let resolve!:(value:Response)=>void,chosen:any;(globalThis as any).location={origin:'https://benos.example'};
 globalThis.fetch=(_url,init)=>{chosen=JSON.parse(String(init!.body));return new Promise<Response>(done=>{resolve=done;});};
 try{const pending=handleNativeAction('design-native-render',{},f.context);await Promise.resolve();(f.data.visual as any).proposal={id:'new-candidate',manifest:starterManifest('industry')};f.state.compare='candidate';resolve(Response.json({ok:true,data:jobView('preview-old-candidate',f.data.project.id,chosen,'ready')}));await pending;assert.equal(nativePreview(f.data,f.user),null);assert.notEqual(f.state.previewMode,'native');}finally{globalThis.fetch=original;(globalThis as any).location=location;stopNativePreviewPolling();}
});

test('a late ready acknowledgement after explicit cancellation cannot resurrect the preview',async()=>{
 const original=globalThis.fetch,location=(globalThis as any).location,f=contextFor('cancel-race'),chosen={versionId:'v',pageKey:'home'};let current:any=jobView('preview-cancel-race',f.data.project.id,chosen),resolve!:(value:Response)=>void;(globalThis as any).location={origin:'https://benos.example'};
 globalThis.fetch=(url)=>{if(String(url).endsWith('/continue'))return new Promise<Response>(done=>{resolve=done;});if(String(url).endsWith('/cancel'))current={...current,state:'cancelled'};return Promise.resolve(Response.json({ok:true,data:current}));};
 try{const pending=handleNativeAction('design-native-render',{},f.context);while(!resolve)await new Promise(done=>setTimeout(done,0));await handleNativeAction('design-native-cancel',{},f.context);resolve(Response.json({ok:true,data:jobView('preview-cancel-race',f.data.project.id,chosen,'ready',1)}));await pending;assert.equal(nativePreview(f.data,f.user),null);assert.match(renderNativeTools(f.data,f.user),/已取消此预览/);}finally{globalThis.fetch=original;(globalThis as any).location=location;stopNativePreviewPolling();}
});
