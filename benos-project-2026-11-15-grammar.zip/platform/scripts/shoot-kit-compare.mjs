// Local preview only: puts the starter template's home sections next to the kit sample compiled
// from the same content, section by section, and prints the numbers that decide whether they match.
//   node scripts/shoot-kit-compare.mjs [width] [sample.html]
import { createRequire } from 'node:module';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { signedInContext } from './preview-session.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.BENOS_TEST_PLAYWRIGHT || 'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const [widthArg = '1680', sample = 'kit-arkpm.html'] = process.argv.slice(2), width = Number(widthArg);
const root = resolve(process.cwd(), '../artifacts/design-sample-20261115'), out = resolve(root, 'compare/kit'); mkdirSync(out, { recursive: true });
const names = ['hero', 'statement', 'duo', 'steps', 'cta'];
const step = message => console.error(new Date().toISOString().slice(11, 19), message);
const browser = await chromium.launch({ executablePath: process.env.BENOS_TEST_BROWSER || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });

// What a designer would check on each section: the measure, the type, the pictures and the cards.
const measure = selector => {
  const px = v => Math.round(parseFloat(v) * 10) / 10, sections = [...document.querySelectorAll(selector)];
  const top = sections.filter(el => !sections.some(other => other !== el && other.contains(el)) && el.getBoundingClientRect().height > 120);
  return top.map((el, index) => {
    const cs = getComputedStyle(el), rect = el.getBoundingClientRect(), inner = el.firstElementChild?.getBoundingClientRect();
    const type = node => { if (!node) return null; const s = getComputedStyle(node), r = node.getBoundingClientRect(); return { size: px(s.fontSize), weight: s.fontWeight, tracking: s.letterSpacing === 'normal' ? 0 : px(s.letterSpacing), leading: px(s.lineHeight), lines: Math.round(r.height / parseFloat(s.lineHeight)), color: s.color, family: s.fontFamily.split(',')[0].replace(/"/g, '') }; };
    const box = node => { const s = getComputedStyle(node), r = node.getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height), radius: px(s.borderTopLeftRadius), bg: s.backgroundColor, border: s.borderTopWidth === '0px' ? '' : s.borderTopColor }; };
    const heading = el.querySelector('h1') || el.querySelector('h2');
    const paragraph = [...el.querySelectorAll('p')].find(p => p.textContent.trim().length > 40);
    const kicker = [...el.querySelectorAll('span,p')].find(n => getComputedStyle(n).textTransform === 'uppercase');
    const pictures = [...el.querySelectorAll('figure')].map(box);
    const cards = [...el.querySelectorAll('a,div,li,article')].filter(n => { const s = getComputedStyle(n), r = n.getBoundingClientRect(); return parseFloat(s.borderTopLeftRadius) >= 16 && parseFloat(s.borderTopLeftRadius) <= 30 && r.width > 200 && r.height > 120 && !n.querySelector('figure') && n.tagName !== 'FIGURE'; }).map(box);
    const button = [...el.querySelectorAll('a')].map(n => ({ n, s: getComputedStyle(n) })).find(x => parseFloat(x.s.borderTopLeftRadius) >= 30);
    return { index, height: Math.round(rect.height), bg: cs.backgroundColor, padTop: px(cs.paddingTop), padBottom: px(cs.paddingBottom), measure: inner ? Math.round(inner.width) : 0, left: inner ? Math.round(inner.left) : 0,
      parts: [...el.querySelectorAll('h1,h2,h3,p,a,figure,figcaption,[role=heading],li,article')].map(n => { const r = n.getBoundingClientRect(); return { tag: n.tagName.toLowerCase(), text: (n.textContent || '').split(/[^!-~¡-￿]+/).join(' ').trim().slice(0, 22), top: Math.round(r.top - rect.top), h: Math.round(r.height), w: Math.round(r.width) }; }),
      heading: type(heading), headingText: heading ? heading.innerText.replace(/\n/g, ' / ') : '', paragraph: type(paragraph), kicker: type(kicker), pictures, cards, button: button ? box(button.n) : null };
  });
};

const shoot = async (page, selector, prefix, picks) => {
  const all = await page.evaluate(measure, selector), wanted = picks(all.length); step(`${prefix}: ${all.length} sections measured`);
  const handles = await page.$$(selector), top = [];
  for (const h of handles) { const ok = await h.evaluate((el, sel) => { const list = [...document.querySelectorAll(sel)]; return !list.some(o => o !== el && o.contains(el)) && el.getBoundingClientRect().height > 120; }, selector); if (ok) top.push(h); }
  const rows = [];
  for (let i = 0; i < wanted.length; i++) { await top[wanted[i]].scrollIntoViewIfNeeded(); await page.waitForTimeout(500); await top[wanted[i]].screenshot({ path: resolve(out, `${prefix}-${width}-${names[i]}.png`) }); rows.push(all[wanted[i]]); }
  return rows;
};

// KIT_ONLY=1 re-shoots only the kit side and reuses the template pictures and numbers of the last
// full run (the template does not change between runs).
const reportPath = resolve(out, `report-${width}.json`);
let tpl;
if (process.env.KIT_ONLY === '1' && existsSync(reportPath)) { tpl = JSON.parse(readFileSync(reportPath, 'utf8')).map(row => row.template); step('template reused from the last full run'); }
else {
  const context = await signedInContext(browser, { viewport: { width, height: 1700 } }), template = await context.newPage(); step('signed in');
  await template.goto('http://127.0.0.1:4242/preview/starter/arkpm'); await template.waitForLoadState('networkidle'); step('template loaded');
  // Lazy pictures load as they scroll into view.
  const templateHeight = await template.evaluate(() => document.documentElement.scrollHeight);
  for (let y = 0; y < templateHeight; y += 700) { await template.evaluate(top => scrollTo(0, top), y); await template.waitForTimeout(120); }
  await template.evaluate(() => scrollTo(0, 0));
  step('template scrolled');
  tpl = await shoot(template, 'section', 'tpl', count => [0, 1, 2, 3, count - 1]); step('template shot');
}

const kit = await browser.newPage({ viewport: { width, height: 1700 } });
await kit.goto(pathToFileURL(resolve(root, sample)).href); await kit.waitForLoadState('networkidle');
const mine = await shoot(kit, '.bnx-section', 'kit', () => [0, 1, 2, 3, 4]);

const line = t => t ? `${t.size}px/${t.leading} w${t.weight} ls${t.tracking} ×${t.lines} ${t.family}` : '—';
const report = names.map((name, i) => ({ name, template: tpl[i], kit: mine[i] }));
for (const { name, template: a, kit: b } of report) {
  console.log(`\n[${name}] height ${a.height} → ${b.height} · measure ${a.measure}@${a.left} → ${b.measure}@${b.left} · pad ${a.padTop}/${a.padBottom} → ${b.padTop}/${b.padBottom} · bg ${a.bg} → ${b.bg}`);
  console.log(`  heading   ${line(a.heading)}\n         →  ${line(b.heading)}   "${b.headingText}"`);
  console.log(`  paragraph ${line(a.paragraph)} ${a.paragraph?.color}\n         →  ${line(b.paragraph)} ${b.paragraph?.color}`);
  console.log(`  kicker    ${line(a.kicker)}\n         →  ${line(b.kicker)}`);
  console.log(`  pictures  ${a.pictures.map(p => `${p.w}×${p.h} r${p.radius}`).join(', ') || '—'}\n         →  ${b.pictures.map(p => `${p.w}×${p.h} r${p.radius}`).join(', ') || '—'}`);
  console.log(`  cards     ${a.cards.map(p => `${p.w}×${p.h} r${p.radius} ${p.bg}`).join(', ') || '—'}\n         →  ${b.cards.map(p => `${p.w}×${p.h} r${p.radius} ${p.bg}`).join(', ') || '—'}`);
  if (process.env.DETAIL === name) { const rows = Math.max(a.parts.length, b.parts.length), cell = p => p ? (p.tag + ' ' + p.text).padEnd(30) + String(p.top).padStart(5) + ' ' + String(p.w).padStart(4) + 'x' + String(p.h).padEnd(5) : ''.padEnd(46); for (let k = 0; k < rows; k++) console.log('    ' + cell(a.parts[k]) + ' | ' + cell(b.parts[k])); }
  if (a.button || b.button) console.log(`  button    ${a.button ? `${a.button.w}×${a.button.h} r${a.button.radius} ${a.button.bg}` : '—'}\n         →  ${b.button ? `${b.button.w}×${b.button.h} r${b.button.radius} ${b.button.bg}` : '—'}`);
}
writeFileSync(resolve(out, `report-${width}.json`), JSON.stringify(report, null, 1));

// One sheet per section: template above, kit below, at the same scale.
const sheet = await browser.newPage({ viewport: { width: Math.min(width, 1680), height: 900 } });
for (const name of names) {
  const img = prefix => 'data:image/png;base64,' + readFileSync(resolve(out, `${prefix}-${width}-${name}.png`)).toString('base64');
  await sheet.setContent(`<body style="margin:0;background:#1b1d1f;font:600 15px/1 Arial,sans-serif;color:#fff"><div id="s" style="display:grid;gap:0"><div style="padding:14px 20px;background:#0f1112">模板原版 · Template</div><img src="${img('tpl')}" style="display:block;width:100%"><div style="padding:14px 20px;background:#0b3bd6">AI 设计系统母版区块 · Compiled kit</div><img src="${img('kit')}" style="display:block;width:100%"></div></body>`);
  await sheet.waitForLoadState('load'); await sheet.waitForTimeout(150);
  await (await sheet.$('#s')).screenshot({ path: resolve(out, `pair-${width}-${name}.png`) });
}
await browser.close();
