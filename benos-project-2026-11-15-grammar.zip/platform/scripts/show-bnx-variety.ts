// Model-free check: the same request should not draw the same page skeleton twice.
//   npx tsx scripts/show-bnx-variety.ts "<request>"
import { prepareV2Generation } from '../src/design-system/v2/generation';
const request = process.argv[2] || '一个奔驰汽车官网，要有首页和车型展示页，高端、有质感';
for (let i = 1; i <= 5; i++) {
  const plan = await prepareV2Generation({ request, seed: 'workflow_sample_' + i });
  console.log('#' + i, plan.siteKind);
  for (const page of plan.pages) console.log('  ' + page.key + ': ' + page.sections.map(s => s.responsibility + '[' + s.choices.map(c => c.patternId.replace('media-', '').replace('hero-', 'h-') + '/' + c.variantId).join(',') + ']').join(' → '));
}
