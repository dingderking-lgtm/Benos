// Local preview only: signs in with the preview test account and screenshots a candidate page.
//   node scripts/shoot-candidate.mjs <projectId> <candidateId> <pageKey> [width]
import { createRequire } from 'node:module';
import { mkdirSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.BENOS_TEST_PLAYWRIGHT || 'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const [project, candidate, pageKey, widthArg = '1440'] = process.argv.slice(2), width = Number(widthArg);
const account = readFileSync(resolve(process.cwd(), '../.ui-work/marketing-redesign/preview-account.txt'), 'utf8');
const email = account.match(/邮箱[:：]\s*(\S+)/)[1], secret = account.match(/密码[:：]\s*(\S+)/)[1];
const out = resolve(process.cwd(), '../artifacts/design-sample-20261115/real-run'); mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.BENOS_TEST_BROWSER || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const page = await browser.newPage({ viewport: { width, height: 900 } });
await page.goto('http://127.0.0.1:4242/#/login');
await page.fill('input[type=email]', email); await page.fill('input[type=password]', secret); await page.keyboard.press('Enter');
await page.waitForURL(/\/app\//, { timeout: 20000 });
await page.goto(`http://127.0.0.1:4242/preview/${project}/candidate/${candidate}?page=${pageKey}`);
await page.waitForLoadState('networkidle');
const info = await page.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight, images: document.images.length,
  sections: [...document.querySelectorAll('.bnx-section')].map(s => s.id + ':' + s.className.replace(/bnx-section |bnx-preset-\S+/g, '').trim().replace(/\s+/g, ' ') + ':' + Math.round(s.getBoundingClientRect().height)) }));
console.log(JSON.stringify(info));
const height = Math.min(info.height, 12000), parts = Math.ceil(height / 1800);
await page.setViewportSize({ width, height: 1800 });
for (let i = 0; i < parts; i++) { await page.evaluate(y => scrollTo(0, y), i * 1800); await page.waitForTimeout(500); await page.screenshot({ path: resolve(out, `${pageKey}-${width}-${i + 1}.png`) }); }
await browser.close();
