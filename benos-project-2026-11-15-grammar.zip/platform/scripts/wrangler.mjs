// Cross-shell wrangler launcher (Windows PowerShell, cmd and Git Bash alike): runs the
// project's own wrangler with telemetry off and logs kept out of the system drive.
//   node scripts/wrangler.mjs <wrangler args...>
// Environment already set by the caller wins. When the sibling ../.ui-work folder exists
// (the local development checkout), wrangler logs go to ../.ui-work/wrangler-logs.
import { spawn } from 'node:child_process';
import { existsSync, mkdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkV2SourceIdentity, writeV2SourceIdentity } from './design-system-v2-identity.mjs';

const backend = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const wrangler = join(backend, 'node_modules', 'wrangler', 'bin', 'wrangler.js');
if (!existsSync(wrangler)) { console.error('[wrangler] node_modules/wrangler is missing — run npm install in platform/'); process.exit(1); }

const args = process.argv.slice(2), development = args[0] === 'dev';
try {
  if (development) writeV2SourceIdentity(backend);
  else if (['deploy', 'versions'].includes(args[0])) checkV2SourceIdentity(backend);
} catch (error) { console.error(`[wrangler] ${error.message}`); process.exit(1); }
// The custom-build hook may refresh only in this explicit development launch.
// Deploy/dry-run never inherit a caller's stale development override.
const env = { ...process.env, BENOS_V2_IDENTITY_DEV: development ? '1' : '0', WRANGLER_SEND_METRICS: process.env.WRANGLER_SEND_METRICS ?? 'false' };
const work = resolve(backend, '..', '.ui-work');
if (!env.WRANGLER_LOG_PATH && existsSync(work)) {
  env.WRANGLER_LOG_PATH = join(work, 'wrangler-logs');
  mkdirSync(env.WRANGLER_LOG_PATH, { recursive: true });
}

const child = spawn(process.execPath, [wrangler, ...args], { cwd: backend, env, stdio: 'inherit' });
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => child.kill(signal));
child.once('error', error => { console.error(`[wrangler] ${error.message}`); process.exit(1); });
child.once('exit', (code, signal) => process.exit(code ?? (signal ? 1 : 0)));
