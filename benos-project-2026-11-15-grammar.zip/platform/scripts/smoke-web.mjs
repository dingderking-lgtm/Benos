// End-to-end smoke test of the running Worker (npm run dev) serving the new front end.
//   node scripts/smoke-web.mjs [--base http://127.0.0.1:4180]   (or SMOKE_BASE)
// Uses node:http with a small cookie jar (see send() for why not fetch).
// Registers ONE fresh account per run (register is limited to 5/hour per IP), so do not loop it.
import { createHash, randomBytes } from 'node:crypto';
import http from 'node:http';
import https from 'node:https';

const argBase = process.argv.indexOf('--base');
const base = (argBase > 0 ? process.argv[argBase + 1] : process.env.SMOKE_BASE) || 'http://127.0.0.1:4180';
const origin = new URL(base).origin;
const jar = new Map();
const results = [];
let failed = 0;

function check(name, condition, detail = '') {
  results.push({ name, ok: !!condition });
  if (condition) console.log(`  ok   ${name}`);
  else { failed++; console.log(`  FAIL ${name}${detail ? ` -- ${detail}` : ''}`); }
  return !!condition;
}

function storeCookies(response) {
  for (const line of response.headers.getSetCookie?.() || []) {
    const [pair, ...attributes] = line.split(';');
    const index = pair.indexOf('=');
    const name = pair.slice(0, index).trim(), value = pair.slice(index + 1).trim();
    const expired = attributes.some(attribute => /^\s*max-age\s*=\s*0\s*$/i.test(attribute))
      || attributes.some(attribute => /^\s*expires\s*=/i.test(attribute) && Date.parse(attribute.split('=').slice(1).join('=')) < Date.now());
    if (!value || expired) jar.delete(name); else jar.set(name, value);
  }
}

// Node's fetch (undici) refuses port 4190: it is on the WHATWG "bad ports" list (ManageSieve).
// So requests go through node:http(s) and are wrapped in a minimal Response-like object.
function send(url, { method, headers, body }) {
  return new Promise((resolveResponse, reject) => {
    const client = url.protocol === 'https:' ? https : http;
    const outgoing = client.request(url, { method, headers }, incoming => {
      const chunks = [];
      incoming.on('data', chunk => chunks.push(chunk));
      incoming.on('error', reject);
      incoming.on('end', () => {
        const responseHeaders = new Headers();
        for (let index = 0; index < incoming.rawHeaders.length; index += 2) responseHeaders.append(incoming.rawHeaders[index], incoming.rawHeaders[index + 1]);
        const bytes = Buffer.concat(chunks);
        resolveResponse({
          status: incoming.statusCode, headers: responseHeaders,
          text: async () => bytes.toString('utf8'), json: async () => JSON.parse(bytes.toString('utf8')), arrayBuffer: async () => bytes,
        });
      });
    });
    outgoing.on('error', reject);
    outgoing.setTimeout(30_000, () => outgoing.destroy(new Error(`timeout: ${method} ${url}`)));
    if (body !== undefined) outgoing.write(body);
    outgoing.end();
  });
}

async function request(path, { method = 'GET', body, csrf, headers = {} } = {}) {
  const init = { method, headers: { Accept: 'application/json, text/html;q=0.9, */*;q=0.1', ...headers } };
  if (method !== 'GET' && method !== 'HEAD') init.headers.Origin = origin;
  if (csrf) init.headers['X-CSRF-Token'] = csrf;
  if (body !== undefined) { init.body = Buffer.from(JSON.stringify(body)); init.headers['Content-Type'] = 'application/json'; init.headers['Content-Length'] = String(init.body.length); }
  if (jar.size) init.headers.Cookie = [...jar].map(([name, value]) => `${name}=${value}`).join('; ');
  const response = await send(new URL(path, base), init);
  storeCookies(response);
  return response;
}

async function api(path, options) {
  const response = await request(path, options);
  let json = null;
  try { json = await response.json(); } catch { /* not JSON */ }
  return { status: response.status, json, data: json?.ok ? json.data : undefined, error: json?.ok === false ? json.error : undefined };
}

// Same algorithm as scripts/build-web.mjs: SHA-256 (base64) of each inline script body.
function inlineScriptHashes(html) {
  const hashes = new Set();
  for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)) {
    if (/\bsrc\s*=/i.test(match[1]) || !match[2]) continue;
    hashes.add(createHash('sha256').update(match[2], 'utf8').digest('base64'));
  }
  return [...hashes];
}

const describe = result => result.error ? `${result.status} ${result.error.code}: ${result.error.message}` : `HTTP ${result.status}`;

async function main() {
  console.log(`Smoke test against ${base}`);

  // 1. The Next export is the document at /, with a CSP that admits exactly its inline scripts.
  const page = await request('/', { headers: { Accept: 'text/html' } });
  const html = await page.text();
  check('GET / returns 200 HTML', page.status === 200 && (page.headers.get('content-type') || '').includes('text/html'), `HTTP ${page.status}`);
  check('GET / is the Next.js export', html.includes('/_next/static/') && html.includes('benos-appearance-init'));
  const csp = page.headers.get('content-security-policy') || '';
  const scriptSrc = (csp.split(';').map(part => part.trim()).find(part => part.startsWith('script-src')) || '').split(/\s+/);
  const hashes = inlineScriptHashes(html);
  const missing = hashes.filter(hash => !scriptSrc.includes(`'sha256-${hash}'`));
  check(`CSP script-src admits all ${hashes.length} inline scripts of /`, hashes.length > 0 && missing.length === 0, `missing ${missing.join(', ')}`);
  check('CSP script-src has no unsafe-inline / unsafe-eval', !scriptSrc.includes("'unsafe-inline'") && !scriptSrc.includes("'unsafe-eval'"));
  check('HTML is served with Cache-Control no-cache', /no-cache/.test(page.headers.get('cache-control') || ''), page.headers.get('cache-control') || 'none');

  // 2. Runtime assets: a legacy module and a content-hashed Next chunk.
  const legacy = await request('/core.js');
  check('GET /core.js returns 200 JavaScript', legacy.status === 200 && /javascript/.test(legacy.headers.get('content-type') || ''), `HTTP ${legacy.status} ${legacy.headers.get('content-type')}`);
  check('/core.js revalidates (not immutable)', !/immutable/.test(legacy.headers.get('cache-control') || '') && !!legacy.headers.get('cache-control'), legacy.headers.get('cache-control') || 'none');
  const chunk = html.match(/src="(\/_next\/static\/[^"]+\.js)"/)?.[1];
  if (check('index.html references a /_next/static chunk', !!chunk)) {
    const response = await request(chunk);
    const cache = response.headers.get('cache-control') || '';
    check(`GET ${chunk} returns 200`, response.status === 200, `HTTP ${response.status}`);
    check('/_next/static is cached immutable for a year', /max-age=31536000/.test(cache) && /immutable/.test(cache), cache || 'none');
  }
  // 2b. Independent entry documents and retirement of browser-local business engines.
  const authModule = await (await request('/auth.js')).text();
  check('/auth.js signs in through the platform (no demo-only notice)', authModule.includes('/account/password/forgot') && authModule.includes('BenosAPI') && !authModule.includes('不创建真实账号'));
  for (const [path, title] of [['/app/', '用户工作台'], ['/admin/', '运营后台']]) {
    const entry = await request(path), entryHtml = await entry.text();
    check(path + ' serves its own entry document', entry.status === 200 && entryHtml.includes(title) && entryHtml.includes('/_next/static/'));
    check(path + ' is not indexed', /noindex/.test(entryHtml));
  }
  for (const path of ['/user.js', '/admin.js', '/pricing.js', '/design-engine.js', '/cms-import.js']) {
    const retired = await request(path);
    check(path + ' is absent from the product', retired.status === 404, `HTTP ${retired.status}`);
  }
  const workspaceModule = await (await request('/workspace.js')).text();
  check('/workspace.js composer creates a platform project', workspaceModule.includes('store.create('));
  const spa = await request('/workspace-deep-link', { headers: { Accept: 'text/html' } });
  check('Unknown extensionless path falls back to the app shell', spa.status === 200 && (await spa.text()).includes('benos-appearance-init'), `HTTP ${spa.status}`);

  // 3. API: health, anonymous session, register, project create / list / rename, logout.
  const health = await api('/api/health');
  check('GET /api/health is ready', health.data?.status === 'ready', describe(health));
  let session = await api('/api/session');
  check('GET /api/session -> user null', session.status === 200 && session.data?.user === null, describe(session));

  const bootstrap = await api('/api/bootstrap');
  check('GET /api/bootstrap reports required/configured', typeof bootstrap.data?.required === 'boolean' && typeof bootstrap.data?.configured === 'boolean', describe(bootstrap));
  const anonymousProjects = await api('/api/projects');
  check('Anonymous GET /api/projects -> 401 (client shows the sign-in page)', anonymousProjects.status === 401 && anonymousProjects.error?.code === 'UNAUTHENTICATED', describe(anonymousProjects));
  const wrongLogin = await api('/api/auth/login', { method: 'POST', body: { email: 'nobody@example.test', password: 'not-the-password-1' } });
  check('Wrong credentials -> 401 LOGIN_FAILED', wrongLogin.status === 401 && wrongLogin.error?.code === 'LOGIN_FAILED', describe(wrongLogin));
  const forgot = await api('/api/account/password/forgot', { method: 'POST', body: { email: 'nobody@example.test' } });
  check('POST /api/account/password/forgot answers honestly (202, or an explicit error when mail is not configured)', forgot.status === 202 ? forgot.data?.accepted === true : forgot.status >= 400 && !!forgot.error?.code && !!forgot.error?.message, describe(forgot));

  const stamp = `${Date.now().toString(36)}${randomBytes(3).toString('hex')}`;
  const email = `smoke+${stamp}@example.test`;
  const password = `Smoke-${randomBytes(9).toString('base64url')}`;
  const register = await api('/api/auth/register', { method: 'POST', body: { name: `Smoke ${stamp}`, email, password } });
  if (!check('POST /api/auth/register creates the account', [200, 201].includes(register.status) && register.data?.user?.email === email, describe(register))) return;
  session = await api('/api/session');
  const csrf = session.data?.csrfToken;
  check('GET /api/session shows the new user and a csrfToken', session.data?.user?.email === email && !!csrf, describe(session));

  const fresh = await api('/api/projects');
  check('A new account starts with no projects (no sample data)', fresh.status === 200 && Array.isArray(fresh.data?.items) && fresh.data.items.length === 0, describe(fresh));
  const summary = await api('/api/billing/summary');
  check('GET /api/billing/summary has no membership for a new account (badge hidden)', summary.status === 200 && summary.data?.plan === null, describe(summary));
  const profile = await api('/api/profile', { method: 'PATCH', csrf, body: { name: `Smoke ${stamp} 改名` } });
  const profileAfter = await api('/api/profile');
  check('PATCH /api/profile saves the display name', profile.status === 200 && profileAfter.data?.name === `Smoke ${stamp} 改名` && profileAfter.data?.email === email, describe(profile));
  const staffOnly = await api('/api/admin/overview');
  check('A customer account is refused by /api/admin (403)', staffOnly.status === 403, describe(staffOnly));
  const noCsrf = await api('/api/projects', { method: 'POST', body: { name: 'no csrf' } });
  check('A write without X-CSRF-Token is refused (403 CSRF)', noCsrf.status === 403 && noCsrf.error?.code === 'CSRF', describe(noCsrf));

  const projectName = `冒烟测试项目 ${stamp}`;
  const renamedName = `${projectName} 已改名`;
  const created = await api('/api/projects', { method: 'POST', csrf, body: { name: projectName, description: 'smoke-web.mjs' } });
  const project = created.data?.project || created.data;
  if (!check('POST /api/projects creates a project', [200, 201].includes(created.status) && !!project?.id, describe(created))) return;
  const list = await api('/api/projects');
  const items = list.data?.items || list.data?.projects || (Array.isArray(list.data) ? list.data : []);
  check('GET /api/projects lists the project', items.some(item => item.id === project.id), describe(list));
  const renamed = await api(`/api/projects/${encodeURIComponent(project.id)}`, { method: 'PATCH', csrf, body: { name: renamedName } });
  const after = await api(`/api/projects/${encodeURIComponent(project.id)}`);
  const afterProject = after.data?.project || after.data;
  check('PATCH /api/projects/:id renames it', renamed.status === 200 && afterProject?.name === renamedName, `${describe(renamed)} / ${describe(after)}`);
  check('Renaming keeps the design brief (description)', renamed.data?.description === 'smoke-web.mjs' && afterProject?.description === 'smoke-web.mjs', `${describe(renamed)} / ${describe(after)}`);
  const redescribed = await api(`/api/projects/${encodeURIComponent(project.id)}`, { method: 'PATCH', csrf, body: { description: 'smoke-web.mjs 已改需求' } });
  check('Updating only the brief keeps the name', redescribed.status === 200 && redescribed.data?.name === renamedName && redescribed.data?.description === 'smoke-web.mjs 已改需求', describe(redescribed));

  const logout = await api('/api/auth/logout', { method: 'POST', csrf, body: {} });
  check('POST /api/auth/logout succeeds', logout.status === 200, describe(logout));
  session = await api('/api/session');
  check('GET /api/session -> user null after logout', session.status === 200 && session.data?.user === null, describe(session));
}

main()
  .catch(error => { failed++; console.log(`  FAIL unexpected error -- ${error?.message || error}`); })
  .finally(() => {
    console.log(`${results.filter(result => result.ok).length} passed, ${failed} failed`);
    process.exit(failed ? 1 : 0);
  });
