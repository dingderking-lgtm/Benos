// Per-section screenshots of a rendered sample, for visual review.
//   node scripts/shoot-bnx-samples.mjs <file.html> <width> [sectionId,...]
import { createRequire } from 'node:module';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.BENOS_TEST_PLAYWRIGHT || 'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const [file, widthArg = '1440', only = ''] = process.argv.slice(2);
const width = Number(widthArg), root = resolve(process.cwd(), '../artifacts/design-sample-20261115'), out = resolve(root, 'shots');
mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.BENOS_TEST_BROWSER || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const page = await browser.newPage({ viewport: { width, height: 900 } });
await page.goto(pathToFileURL(resolve(root, file)).href);
await page.waitForLoadState('networkidle');
const info = await page.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight,
  broken: [...document.images].filter(i => !i.naturalWidth).length,
  overflow: [...document.querySelectorAll('.bnx-section *')].filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && (r.right > innerWidth + 1 || r.left < -1) && !e.closest('.bnx-media-rail'); }).slice(0, 5).map(e => e.className),
  sections: [...document.querySelectorAll('.bnx-section')].map(s => ({ id: s.id, h: Math.round(s.getBoundingClientRect().height) })) }));
console.log(JSON.stringify(info));
// "full" as the section list takes one full-page picture instead of one per section.
if (only === 'full') { for (let y = 0; y < info.height; y += 600) { await page.evaluate(top => scrollTo(0, top), y); await page.waitForTimeout(120); } await page.evaluate(() => scrollTo(0, 0)); await page.waitForTimeout(300);
  await page.screenshot({ path: resolve(out, `${file.replace('.html', '')}-${width}-full.png`), fullPage: true }); await browser.close(); process.exit(0); }
const wanted = only ? only.split(',') : info.sections.map(s => s.id);
for (const id of wanted) await page.locator('#' + id).screenshot({ path: resolve(out, `${file.replace('.html', '')}-${width}-${id}.png`) });
await browser.close();
