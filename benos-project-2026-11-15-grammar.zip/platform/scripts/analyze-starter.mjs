// Structural inventory of a starter template package: how its pages are built and how much of
// it is reusable section-by-section. Read-only.
//   node scripts/analyze-starter.mjs [id]
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
const id = process.argv[2] || 'arkpm';
const candidates = [`web-dist/starters/${id}/manifest.json`, `../UI模板/frontend/dist/starters/${id}/manifest.json`, `../UI模板/dist/starters/${id}/manifest.json`, `public/starters/${id}/manifest.json`];
const path = candidates.map(p => resolve(process.cwd(), p)).find(existsSync);
if (!path) { console.log('manifest not found in', candidates); process.exit(1); }
const m = JSON.parse(readFileSync(path, 'utf8'));
const bytes = s => Buffer.byteLength(String(s || ''));
console.log('manifest', path.replace(/\\/g, '/').split('/').slice(-4).join('/'), bytes(JSON.stringify(m)), 'bytes');
console.log('site', JSON.stringify({ name: m.site?.name, home: m.site?.home, pages: m.site?.pages?.length, header: m.site?.header_template_id, footer: m.site?.footer_template_id, forms: m.site?.forms?.length, blog: !!m.site?.blog, themeKeys: Object.keys(m.site?.theme || {}), globalCss: bytes(m.site?.theme?.global_css) }));
console.log('assets', m.assets?.length, 'menus', m.menus?.length, 'forms', (m.forms || []).map(f => f.ref).join(','));
const pageByTemplate = new Map((m.site?.pages || []).map(p => [p.template_id, p]));
const sectionSignatures = new Map();
const classUse = new Map();
let totalCss = 0, totalHtml = 0;
const rows = [];
for (const t of m.templates || []) {
  const html = String(t.document?.html || ''), css = String(t.document?.css || '');
  totalCss += bytes(css); totalHtml += bytes(html);
  // top-level sections of the page body
  const sections = [...html.matchAll(/<section\b([^>]*)>/g)].map(x => (x[1].match(/class="([^"]*)"/) || [, ''])[1]);
  for (const cls of sections) { const key = cls.split(/\s+/).filter(Boolean).sort().join(' '); sectionSignatures.set(key, (sectionSignatures.get(key) || 0) + 1); }
  for (const c of html.matchAll(/class="([^"]*)"/g)) for (const name of c[1].split(/\s+/)) if (name) classUse.set(name, (classUse.get(name) || 0) + 1);
  const page = pageByTemplate.get(t.id);
  rows.push({ id: t.id, type: t.type, name: String(t.name || '').slice(0, 26), page: page?.key || '', html: bytes(html), css: bytes(css), sections: sections.length, imgs: (html.match(/<img\b/g) || []).length, forms: (html.match(/data-form=/g) || []).length, details: (html.match(/<details\b/g) || []).length, inputs: (html.match(/<input\b/g) || []).length });
}
for (const r of rows) console.log(`  t${String(r.id).padStart(2)} ${r.type.padEnd(7)} ${r.page.padEnd(26)} html=${String(r.html).padStart(6)} css=${String(r.css).padStart(6)} sections=${String(r.sections).padStart(2)} imgs=${String(r.imgs).padStart(2)} forms=${r.forms} details=${r.details} inputs=${r.inputs} | ${r.name}`);
console.log('totals html', totalHtml, 'css', totalCss, 'templates', rows.length);
const cssSizes = new Map(); for (const t of m.templates || []) { const c = String(t.document?.css || ''); cssSizes.set(c.length, (cssSizes.get(c.length) || 0) + 1); }
console.log('distinct per-template css sizes', [...cssSizes.entries()].map(([k, v]) => `${k}×${v}`).join(' '));
console.log('section class signatures (' + sectionSignatures.size + ' distinct, ' + [...sectionSignatures.values()].reduce((a, b) => a + b, 0) + ' sections):');
for (const [k, v] of [...sectionSignatures.entries()].sort((a, b) => b[1] - a[1]).slice(0, 60)) console.log(`  ×${String(v).padStart(2)}  ${k}`);
const prefixes = new Map(); for (const [name, n] of classUse) { const p = name.split('-').slice(0, 2).join('-'); prefixes.set(p, (prefixes.get(p) || 0) + n); }
console.log('class families:', [...prefixes.entries()].sort((a, b) => b[1] - a[1]).slice(0, 40).map(([k, v]) => `${k}(${v})`).join(' '));
