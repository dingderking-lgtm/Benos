﻿param([string]$Label = (Get-Date -Format 'yyyy-MM-dd-HHmmss'))
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 has no [System.IO.Path]::GetRelativePath; provide one.
function Get-RelativeReleasePath([string]$Base, [string]$Target) {
  $baseUri = [System.Uri](([System.IO.Path]::GetFullPath($Base).TrimEnd('\')) + '\')
  $targetUri = [System.Uri]([System.IO.Path]::GetFullPath($Target))
  if ($targetUri.AbsolutePath -notlike ($baseUri.AbsolutePath + '*')) { throw ('Path escapes base: ' + $Target) }
  $relative = [System.Uri]::UnescapeDataString($baseUri.MakeRelativeUri($targetUri).ToString())
  return ($relative -replace '/', '\')
}

if ($Label -notmatch '^[A-Za-z0-9._-]+$') { throw 'Invalid release label.' }
$projectRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$workspaceRoot = [System.IO.Path]::GetFullPath((Join-Path $projectRoot '..'))
$frontendRoot = Join-Path $workspaceRoot 'UI模板'
$destination = Join-Path $projectRoot 'deliverables'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
$archivePath = Join-Path $destination ('benos-project-' + $Label + '.zip')
if (Test-Path -LiteralPath $archivePath) { throw 'Release archive already exists; choose a new label.' }
$files = [System.Collections.Generic.List[System.IO.FileInfo]]::new()
# Preserve the sibling platform/UI模板 layout required by build-web.mjs.
function Add-FrontendFiles([string]$Directory) {
  foreach ($entry in Get-ChildItem -LiteralPath $Directory -Force) {
    if (($entry.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Release source cannot contain reparse points.' }
    if ($entry.PSIsContainer) {
      if ($entry.Name -in @('node_modules','.next','out','.wrangler','server','downloads','previews','.openai') -or $entry.Name.StartsWith('.')) { continue }
      Add-FrontendFiles $entry.FullName
    } elseif ($entry.Name -notmatch '\.(tsbuildinfo|log|sqlite|db|zip)$' -and $entry.Name -notmatch '^\.(env|dev\.vars)') {
      $files.Add($entry)
    }
  }
}
foreach ($directory in @('frontend','dist','tests','scripts','worker')) {
  $resolved = [System.IO.Path]::GetFullPath((Join-Path $frontendRoot $directory))
  if (-not $resolved.StartsWith($frontendRoot + [System.IO.Path]::DirectorySeparatorChar)) { throw 'Frontend source escapes project root.' }
  if (Test-Path -LiteralPath $resolved) { Add-FrontendFiles $resolved }
}
foreach ($name in @('package.json','package-lock.json')) { $files.Add((Get-Item -LiteralPath (Join-Path $frontendRoot $name))) }
foreach ($name in @('README.md','.gitignore')) { $files.Add((Get-Item -LiteralPath (Join-Path $workspaceRoot $name))) }
foreach ($directory in @('src','public','migrations','docs','tests','scripts','cms-connector/src','cms-connector/public','cms-connector/product-catalog')) {
  $resolved = [System.IO.Path]::GetFullPath((Join-Path $projectRoot $directory))
  if (-not $resolved.StartsWith($projectRoot + [System.IO.Path]::DirectorySeparatorChar)) { throw 'Source escapes project root.' }
  foreach ($entry in Get-ChildItem -LiteralPath $resolved -Recurse -Force) {
    if (($entry.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Release source cannot contain reparse points.' }
    if (-not $entry.PSIsContainer) { $files.Add($entry) }
  }
}
foreach ($name in @('README.md','IMPLEMENTATION-PLAN.txt','package.json','package-lock.json','tsconfig.json','wrangler.jsonc','.gitignore','.dev.vars.example','cms-connector/bootstrap-runtime.php','cms-connector/build-release.php','cms-connector/restore-managed.php','cms-connector/config.example.php','cms-connector/CONNECTION-PROTOCOL.txt','cms-connector/HOSTINGER-ADAPTER.txt','cms-connector/MANAGED-CMS-POLICY.txt','cms-connector/PRODUCT-CATALOG.txt','cms-connector/BUNDLE-V2-PROTOCOL.txt','cms-connector/PREVIEW-V2-PROTOCOL.txt','cms-connector/site-bundle.php','cms-connector/site-connect.php','cms-connector/site-health.php')) {
  $files.Add((Get-Item -LiteralPath (Join-Path $projectRoot $name)))
}
$entries = @($files | Sort-Object FullName -Unique | ForEach-Object {
  $relative = (Get-RelativeReleasePath $workspaceRoot $_.FullName).Replace('\','/')
  if ($relative.StartsWith('../') -or $relative -match '(^|/)(qa|node_modules|\.wrangler|\.ui-work|\.test-runs|\.secrets)(/|$)' -or $relative -match '\.(sqlite|db|log|zip)$' -or ($relative -match '(^|/)\.dev\.vars' -and $relative -ne 'platform/.dev.vars.example')) { throw ('Forbidden release file: ' + $relative) }
  [pscustomobject]@{ File=$_.FullName; Path=$relative; Sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
})
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$stream = [System.IO.File]::Open($archivePath,[System.IO.FileMode]::CreateNew)
$archive = [System.IO.Compression.ZipArchive]::new($stream,[System.IO.Compression.ZipArchiveMode]::Create,$false)
try {
  foreach ($entry in $entries) {
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$entry.File,$entry.Path,[System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
  }
  $manifest = $archive.CreateEntry('SHA256SUMS.txt')
  $writer = [System.IO.StreamWriter]::new($manifest.Open(),[System.Text.UTF8Encoding]::new($false))
  try { foreach ($entry in $entries) { $writer.WriteLine($entry.Sha256 + '  ' + $entry.Path) } } finally { $writer.Dispose() }
} finally { $archive.Dispose(); $stream.Dispose() }
$verify = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
try {
  foreach ($required in @('README.md','platform/package.json','platform/scripts/build-web.mjs','platform/src/index.ts','UI模板/package.json','UI模板/frontend/app/app/page.tsx','UI模板/frontend/app/admin/page.tsx','UI模板/frontend/components/Studio.tsx')) {
    if (-not $verify.GetEntry($required)) { throw ('Incomplete product archive: ' + $required) }
  }
  if ($verify.Entries.Count -ne $entries.Count + 1) { throw 'Archive entry count mismatch.' }
  foreach ($entry in $entries) {
    $packed = $verify.GetEntry($entry.Path)
    if (-not $packed) { throw 'Archive entry missing.' }
    $content = $packed.Open()
    try {
      $sha = [System.Security.Cryptography.SHA256]::Create()
      try { $digest = $sha.ComputeHash($content) } finally { $sha.Dispose() }
      $hash = (($digest | ForEach-Object { $_.ToString('x2') }) -join '')
    } finally { $content.Dispose() }
    if ($hash -ne $entry.Sha256) { throw ('Archive checksum mismatch: ' + $entry.Path) }
  }
} finally { $verify.Dispose() }
[pscustomobject]@{Path=$archivePath;Files=$entries.Count;Bytes=(Get-Item -LiteralPath $archivePath).Length;Sha256=(Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json
