// Local, model-free preview of the BNX compiler. Writes static HTML so a layout
// can be judged in a browser without login, wallet, provider or approval rows.
//   npx tsx scripts/render-bnx-samples.ts
import { mkdirSync, writeFileSync, copyFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { compileV2Page } from '../src/design-system/v2/render';
import { createV2PageFixture } from '../src/design-system/v2/fixtures';
import { V2_PRESETS, type V2PageInput, type V2Preset } from '../src/design-system/v2/contracts';

const out = resolve(process.cwd(), '../artifacts/design-sample-20261115');
mkdirSync(resolve(out, 'fx'), { recursive: true });
const fixtureDir = resolve(process.cwd(), 'public/assets/design-system-v2');
for (const file of readdirSync(fixtureDir)) copyFileSync(resolve(fixtureDir, file), resolve(out, 'fx', file));
const page = (title: string, lang: string, html: string, css: string) => `<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title><style>html{scroll-behavior:auto}body{margin:0}*,*::before,*::after{box-sizing:border-box}${css}</style></head><body>${html.replaceAll('src="/', 'src="')}</body></html>`;

const index: string[] = [];
for (const preset of V2_PRESETS) for (const example of ['stay', 'industrial'] as const) {
  const fixture = createV2PageFixture({ preset, example, imageBaseUrl: '/fx' });
  const result = await compileV2Page(fixture.input, fixture.context);
  const name = `fixture-${example}-${preset}.html`;
  writeFileSync(resolve(out, name), page(fixture.title, fixture.lang, result.html, result.css));
  index.push(name + ' css=' + new TextEncoder().encode(result.css).length);
}

// A realistic composition, written the way the model fills compose_site_v2.
const car = (n: number, w = 1536, h = 1024) => ({ path: `/img/car-${n}.png`, width: w, height: h, source: 'generated' as const });
const owned = [car(1), car(2), car(3), car(4, 1024, 1536), car(5)];
const media = (id: string, n: number, alt: string, extra: Record<string, unknown> = {}) => ({ id, kind: 'owned' as const, assetPath: `/img/car-${n}.png`, purpose: alt, alt, ...extra });
const auto = (preset: V2Preset): V2PageInput => ({ version: 'bnx-compose-1', preset, sections: [
  { id: 'hero', patternId: 'hero-cover', variantId: 'scene', preset, media: [media('main', 1, '银色豪华轿车停在深色展厅', { textSafeArea: 'left', focalPoint: 'right' })],
    content: { eyebrow: '全新旗舰轿车', title: '安静，是最高级的速度。', lead: '从第一眼的比例，到每一次落座的触感，为真正在意细节的人而造。', actions: [{ label: '预约试驾', href: '#next', kind: 'primary' }, { label: '查看车型', href: '#models', kind: 'secondary' }], items: [{ title: '静谧座舱', text: '多层隔音与主动降噪' }, { title: '从容动力', text: '线性输出，随叫随到' }, { title: '智能辅助', text: '长途与拥堵都更轻松' }] } },
  { id: 'belief', patternId: 'features', variantId: 'statement', preset, media: [],
    content: { eyebrow: '设计理念', title: '好的设计，不需要大声说话。', lead: '我们把注意力放在比例、光影和触感上，让车在安静中显出分量。', items: [{ label: '比例', title: '修长而克制的车身', text: '长轴距与短前悬构成沉稳的姿态。' }, { label: '光影', title: '一条贯穿首尾的腰线', text: '光线在车侧缓慢流动，不靠装饰制造存在感。' }, { label: '触感', title: '每一处接触都经过推敲', text: '皮革、金属与木纹在指尖有各自的温度。' }] } },
  { id: 'models', patternId: 'media-mosaic', variantId: 'cards', preset, media: [media('sedan', 2, '轿车侧面', { subjectPolicy: 'crop-safe' }), media('suv', 3, 'SUV 侧面'), media('sport', 5, '运动轿车前脸')],
    content: { eyebrow: '车型系列', title: '找到与你节奏相合的那一台。', lead: '三个系列，对应三种不同的出行方式。', actions: [{ label: '全部车型', href: '/models', kind: 'secondary' }], items: [{ label: '行政轿车', title: 'S 系旗舰', text: '为后排而生的长轴距与静谧空间。', href: '/models' }, { label: '豪华 SUV', title: 'GL 系全尺寸', text: '七座布局，从城市到远途都从容。', href: '/models' }, { label: '运动轿车', title: 'E 系运动版', text: '更低的姿态与更直接的路感反馈。', href: '/models' }] } },
  { id: 'cabin', patternId: 'media-story', variantId: 'spotlight', preset, media: [media('cabin', 5, '轿车前脸与格栅细节')],
    content: { eyebrow: '工艺细节', title: '细节，经得起近看。', lead: '格栅的每一根饰条、灯组的每一道光带，都按同一套比例绘制。', actions: [{ label: '了解工艺', href: '/craft', kind: 'secondary' }], items: [{ title: '星徽格栅', text: '横向饰条拉宽视觉重心。' }, { title: '数字大灯', text: '光型随路况自动调整。' }, { title: '多辐轮毂', text: '锻造工艺兼顾强度与轻量。' }] } },
  { id: 'journey', patternId: 'process', variantId: 'cards', preset, media: [],
    content: { eyebrow: '购车流程', title: '从了解到交付，四步完成。', lead: '每一步都有专属顾问跟进，不需要你反复确认。', items: [{ title: '在线选配', text: '选择车型、外观与内饰组合。' }, { title: '到店试驾', text: '在熟悉的路线上感受真实表现。' }, { title: '确认方案', text: '顾问给出清晰的金融与置换建议。' }, { title: '专属交付', text: '在约定时间完成验车与讲解。' }] } },
  { id: 'care', patternId: 'features', variantId: 'grid', preset, media: [],
    content: { eyebrow: '用车服务', title: '把车交给我们，把时间留给自己。', lead: '覆盖保养、救援与延保的完整服务。', items: [{ title: '上门取送车', text: '保养当天无需到店，车辆由专人取送。' }, { title: '全天候道路救援', text: '任何时间拨打服务热线即可响应。' }, { title: '原厂延长保修', text: '关键部件享受更长的保障周期。' }, { title: '透明保养报价', text: '每一项工时与配件都提前列明。' }, { title: '代步车服务', text: '维修期间提供同级别代步车辆。' }, { title: '专属服务顾问', text: '一位顾问全程对接，不必重复说明。' }] } },
  { id: 'faq', patternId: 'faq', variantId: 'split', preset, media: [],
    content: { eyebrow: '常见问题', title: '出发之前，你可能想知道。', lead: '没有找到答案？欢迎直接联系顾问。', questions: [{ question: '试驾需要提前多久预约？', answer: '建议提前一至两天预约，顾问会为你确认车型与时间。' }, { question: '可以选择到家试驾吗？', answer: '部分城市支持上门试驾，具体以当地门店安排为准。' }, { question: '置换旧车如何评估？', answer: '到店后由评估师现场检测并给出报价，全程约三十分钟。' }, { question: '交付周期一般多长？', answer: '现车通常一周内交付，定制车型以订单确认时间为准。' }] } },
  { id: 'next', patternId: 'action', variantId: 'centered', preset, media: [],
    content: { eyebrow: '预约试驾', title: '坐进去，才知道有什么不同。', lead: '留下方便的时间，顾问会在一个工作日内与你确认。', actions: [{ label: '预约试驾', href: '/contact', kind: 'primary' }, { label: '查找门店', href: '/stores', kind: 'secondary' }] } },
  { id: 'colophon', patternId: 'footer', variantId: 'directory', preset, media: [],
    content: { title: '星辰汽车', lead: '为真正在意细节的人而造。', navigation: [{ title: '车型', links: [{ label: '轿车', href: '/models' }, { label: 'SUV', href: '/models' }, { label: '运动系列', href: '/models' }] }, { title: '服务', links: [{ label: '保养预约', href: '/service' }, { label: '道路救援', href: '/service' }, { label: '延长保修', href: '/service' }] }, { title: '关于', links: [{ label: '品牌故事', href: '/about' }, { label: '查找门店', href: '/stores' }, { label: '联系我们', href: '/contact' }] }], copyright: '© 2026 星辰汽车', imageAttribution: '图片为概念示意。' } },
] });
for (const preset of V2_PRESETS) {
  const result = await compileV2Page(auto(preset), { mode: 'review', ownedAssets: owned, verifiedFactRefs: [] });
  const name = `auto-${preset}.html`;
  writeFileSync(resolve(out, name), page('星辰汽车', 'zh-CN', result.html, result.css));
  index.push(name + ' css=' + new TextEncoder().encode(result.css).length + ' issues=' + result.issues.map(i => i.code).join(','));
}
console.log(index.join('\n'));

// Design languages with a model-style palette intent.
const arts = [
  ['editorial-dark', 'deep-studio', { direction: 'editorial', mode: 'dark', accent: '#d7d9de', neutral: 'pure' }],
  ['editorial-light', 'calm-paper', { direction: 'editorial', mode: 'light', accent: '#111111', neutral: 'pure' }],
  ['bold-dark', 'bold-signal', { direction: 'bold', mode: 'dark', accent: '#e10600', neutral: 'pure' }],
  ['soft-light', 'calm-paper', { direction: 'soft', mode: 'light', accent: '#c8553d', neutral: 'warm' }],
] as const;
for (const [name, preset, art] of arts) {
  const result = await compileV2Page(auto(preset), { mode: 'review', ownedAssets: owned, verifiedFactRefs: [], art: art as any });
  writeFileSync(resolve(out, `art-${name}.html`), page('星辰汽车', 'zh-CN', result.html, result.css));
  console.log(`art-${name}.html css=` + new TextEncoder().encode(result.css).length);
}

// New structures: full-bleed picture bands and large-type sections.
const flagship = (preset: V2Preset): V2PageInput => { const base = auto(preset).sections; return { version: 'bnx-compose-1', preset, sections: [
  base[0],
  { id: 'creed', patternId: 'manifesto', variantId: 'center', preset, media: [], content: { eyebrow: '品牌信条', title: '不追赶潮流，只把一件事做到极致。', lead: '一百多年来，我们只回答一个问题：一台车，怎样才算造得足够好。', items: [{ title: '工程', text: '每个零件都有存在的理由。' }, { title: '设计', text: '比例先于装饰。' }, { title: '工艺', text: '看不见的地方同样讲究。' }] } },
  { id: 'craft', patternId: 'banner', variantId: 'split', preset, media: [media('craft', 4, '座舱皮革与金属饰板细节')], content: { eyebrow: '座舱', title: '指尖先于眼睛，知道什么是好。', lead: '皮革的缝线、金属的拉丝、木纹的走向，都由同一组工匠完成。', actions: [{ label: '走进座舱', href: '/craft', kind: 'secondary' }], items: [{ title: '手工缝线', text: '每一针间距一致。' }, { title: '实木饰板', text: '同一棵树，纹理连续。' }] } },
  base[2],
  { id: 'scene', patternId: 'banner', variantId: 'fullbleed', preset, media: [media('scene', 3, '银色 SUV 停在深色展厅')], content: { eyebrow: '全尺寸 SUV', title: '去更远的地方，也不必放弃从容。', lead: '七座空间、空气悬架与全时四驱，把长途变成一段安静的时间。', actions: [{ label: '了解 GL 系', href: '/models', kind: 'primary' }] } },
  { id: 'lines', patternId: 'manifesto', variantId: 'index', preset, media: [], content: { eyebrow: '产品家族', title: '四个系列，四种性格。', lead: '从城市到旷野，总有一台与你的生活相合。', items: [{ title: '行政轿车', text: '为后排而生的静谧与舒展。', href: '/models' }, { title: '豪华 SUV', text: '更高的视野，更大的自由。', href: '/models' }, { title: '运动轿跑', text: '低趴姿态与直接的路感。', href: '/models' }, { title: '纯电系列', text: '安静到只剩风声。', href: '/models' }] } },
  base[7], base[8],
] }; };
for (const [name, preset, art] of [arts[0], arts[1], arts[3]]) {
  const result = await compileV2Page(flagship(preset), { mode: 'review', ownedAssets: owned, verifiedFactRefs: [], art: art as any });
  writeFileSync(resolve(out, `flagship-${name}.html`), page('星辰汽车', 'zh-CN', result.html, result.css));
  console.log(`flagship-${name}.html css=` + new TextEncoder().encode(result.css).length + ' issues=' + result.issues.map(i => i.code).join(','));
}

// Closing action section in each layout and design language.
const closing = (preset: V2Preset): V2PageInput => ({ version: 'bnx-compose-1', preset, sections: ['band', 'split', 'centered'].map((variantId, i) => ({ id: 'act-' + variantId, patternId: 'action' as const, variantId, preset, media: [],
  content: { eyebrow: '继续探索', title: ['下一程，由你的选择开启', '从欣赏，到更了解', '坐进去，才知道有什么不同。'][i], lead: '浏览不同车身方向，找到更贴近生活的驾乘表达。', actions: [{ label: '进入车型展示', href: '/models', kind: 'primary' as const }, { label: '品鉴座舱细节', href: '/craft', kind: 'secondary' as const }] } })) });
for (const [name, preset, art] of arts) {
  const result = await compileV2Page(closing(preset), { mode: 'review', ownedAssets: owned, verifiedFactRefs: [], art: art as any });
  writeFileSync(resolve(out, `action-${name}.html`), page('行动区', 'zh-CN', result.html, result.css));
}

// Contact page built from confirmed facts, with the CMS enquiry form mount.
import { parseConfirmedFacts, confirmedContacts } from '../src/lib/confirmed-facts';
const facts = parseConfirmedFacts('做一个汽车官网\n\n【已确认的真实信息】\n公司名称：星辰汽车\n联系电话：+86 21 5555 0100\n联系邮箱：hello@example.test\n公司地址：上海市示例路 100 号\n工作时间：周一至周日 9:00–20:00');
const links = confirmedContacts(facts);
console.log('facts', JSON.stringify(facts), JSON.stringify(links));
for (const [name, preset, art] of [arts[0], arts[3]]) {
  const result = await compileV2Page({ version: 'bnx-compose-1', preset, sections: [{ id: 'contact', patternId: 'contact', variantId: 'form', preset, media: [],
    content: { eyebrow: '联系我们', title: '预约试驾，或直接来店里看看。', lead: '留下你的需求，顾问会在一个工作日内回复。', contact: links.map(l => ({ label: l.label, href: l.href, factRef: l.factRef })), items: [{ title: '地址', text: facts!.address! }, { title: '工作时间', text: facts!.hours! }] } }] },
    { mode: 'review', ownedAssets: owned, verifiedFactRefs: links.map(l => l.factRef), art: art as any });
  writeFileSync(resolve(out, `contact-${name}.html`), page('联系', 'zh-CN', result.html, result.css));
}

// Template-derived kit, filled with the starter template's own home content, pictures and palette,
// so the compiled sections can be compared with the template one by one.
const starterAssets = resolve(process.cwd(), 'web-dist/starters/arkpm/assets');
mkdirSync(resolve(out, 'kit'), { recursive: true });
const kitPictures = [['hero', 37], ['recycling', 49], ['extrusion', 3]] as const;
for (const [name, n] of kitPictures) copyFileSync(resolve(starterAssets, `${n}.webp`), resolve(out, 'kit', `${name}.webp`));
const kitOwned = kitPictures.map(([name]) => ({ path: `/kit/${name}.webp`, width: 1200, height: 900, source: 'generated' as const }));
const kitMedia = (id: string, name: string, alt: string, caption: string) => ({ id, kind: 'owned' as const, assetPath: `/kit/${name}.webp`, purpose: alt, alt, caption });
type KitCopy = { hero: { eyebrow: string; title: string; lead: string; line: string; actions: [string, string]; caption: string; routes: [string, string, string][]; note: [string, string, string] };
  purpose: { eyebrow: string; title: string; lead: string; body: string; link: string };
  duo: { eyebrow: string; title: string; lead: string; cards: [string, string, string, string][] };
  steps: { eyebrow: string; title: string; lead: string; items: [string, string][] };
  cta: { title: string; lead: string; action: string } };
const kitPage = (preset: V2Preset, t: KitCopy): V2PageInput => ({ version: 'bnx-compose-1', preset, sections: [
  { id: 'hero', patternId: 'hero-kit', variantId: 'routes', preset, media: [kitMedia('main', 'hero', 'Blue recycled-polymer sculpture with plastic flakes, white pellets and formed material samples', t.hero.caption)],
    content: { eyebrow: t.hero.eyebrow, title: t.hero.title, lead: t.hero.lead, body: t.hero.line,
      actions: [{ label: t.hero.actions[0], href: '/about', kind: 'primary' }, { label: t.hero.actions[1], href: '/products', kind: 'secondary' }],
      items: [...t.hero.routes.map(([label, title, text], i) => ({ label, title, text, href: i ? '/custom-extrusion-lines' : '/plastic-recycling-machines' })), { title: t.hero.note[0], text: t.hero.note[1], href: '/about', linkLabel: t.hero.note[2] }] } },
  { id: 'purpose', patternId: 'kit-statement', variantId: 'split', preset, media: [],
    content: { eyebrow: t.purpose.eyebrow, title: t.purpose.title, lead: t.purpose.lead, body: t.purpose.body, actions: [{ label: t.purpose.link, href: '/about', kind: 'secondary' }] } },
  { id: 'disciplines', patternId: 'kit-duo', variantId: 'cards', preset,
    media: [kitMedia('recycling', 'recycling', 'Concept of a plastic recycling line with feed conveyor, compactor, extruder and pellet collection', t.duo.cards[0][3]), kitMedia('extrusion', 'extrusion', 'Concept of a custom extrusion line with tooling, cooling, haul-off, guarded cutting and product samples', t.duo.cards[1][3])],
    content: { eyebrow: t.duo.eyebrow, title: t.duo.title, lead: t.duo.lead, items: t.duo.cards.map(([title, text, linkLabel], i) => ({ title, text, linkLabel, href: i ? '/custom-extrusion-lines' : '/plastic-recycling-machines' })) } },
  { id: 'approach', patternId: 'kit-steps', variantId: 'flow', preset, media: [],
    content: { eyebrow: t.steps.eyebrow, title: t.steps.title, lead: t.steps.lead, items: t.steps.items.map(([title, text]) => ({ title, text })) } },
  { id: 'next', patternId: 'kit-cta', variantId: 'band', preset, media: [],
    content: { title: t.cta.title, lead: t.cta.lead, actions: [{ label: t.cta.action, href: '/contact', kind: 'primary' }] } },
] });
const arkpmCopy: KitCopy = {
  hero: { eyebrow: 'ARKPM · A JianTai subsidiary', title: 'Engineering the next life of plastics.', lead: 'ARKPM is the machinery brand of Ark Plastics Machinery Co., Ltd., a JianTai subsidiary. We develop customized recycling and extrusion lines around your material and product.',
    line: 'A focused brand within JianTai plastic machinery company | All product families · Custom configuration', actions: ['Discover ARKPM', 'Explore our machines'], caption: 'New forms. Renewed possibilities. A material concept.',
    routes: [['01 / Recovery', 'Recycling machines.', 'Build a route from prepared scrap to usable pellets.'], ['02 / Formation', 'Custom extrusion.', 'Turn a product brief into a connected production line.']],
    note: ['One material. Your possibilities.', 'From a defined waste stream to a new product profile, the right line begins with the right questions.', 'Our approach to customization'] },
  purpose: { eyebrow: 'A clear purpose', title: 'Better-defined projects. More considered machinery.',
    lead: 'ARKPM is the brand of Ark Plastics Machinery Co., Ltd., a subsidiary of JianTai plastic machinery company. We develop plastic recycling machines and customized extrusion lines around your process.',
    body: 'Our role is to connect the material question with the equipment decision. We help turn a production ambition into a clear brief: what enters the line, what leaves it, and what needs to happen in between.', link: 'Meet the company' },
  duo: { eyebrow: 'Two connected disciplines', title: 'Recover value. Create what comes next.', lead: 'Recycling and extrusion share a practical starting point: understand the material, then design the process around it.',
    cards: [['Plastic recycling machines', 'Film scrap, rigid regrind and defined melt-treatment duties each call for a distinct configuration. Explore a process built around the incoming material and its next use.', 'Explore recycling systems', 'Recycling concept: prepared plastic to pellets.'],
      ['Custom plastic extrusion lines', 'Pipe, profile and tubing lines are developed around geometry, material and downstream handling. Every stage should support the product you intend to make.', 'Explore extrusion systems', 'Extrusion concept: tooling, shaping and downstream handling.']] },
  steps: { eyebrow: 'The ARKPM approach', title: 'A line is only as considered as the brief behind it.', lead: 'Customization is a sequence of engineering decisions. We make the material, process and site requirements part of the same conversation.',
    items: [['Understand the material', 'Start with representative samples, your product requirements and the conditions in which the line will operate.'], ['Define the system', 'Connect feeding, processing and downstream stages in a proposal with clear interfaces and responsibilities.'],
      ['Make it project-specific', 'Review layout, controls, utilities and access so the configuration fits the way your plant needs to work.'], ['Agree the evidence', 'Set the checks, documentation and acceptance criteria that will guide the project from proposal to evaluation.']] },
  cta: { title: 'Your next production chapter starts here.', lead: 'Tell us about your material, your product and the way you want to work. We will help shape a considered project brief.', action: 'Discuss your project' },
};
const zhCopy: KitCopy = {
  hero: { eyebrow: '方舟塑机 · 建泰旗下品牌', title: '为塑料的下一段生命，设计整条产线。', lead: '方舟塑机是建泰塑料机械旗下的设备品牌，围绕你的物料和成品，定制回收造粒与挤出生产线。',
    line: '建泰塑料机械旗下的专注品牌 | 全系列设备 · 按项目定制', actions: ['了解方舟塑机', '查看全部设备'], caption: '新的形态，新的可能：一组材料概念图。',
    routes: [['01 / 回收', '回收造粒设备', '从预处理的废料，到可用的再生颗粒。'], ['02 / 成型', '定制挤出产线', '把一份产品要求，变成一条连贯的产线。']],
    note: ['一种材料，多种可能。', '从明确的废料来源到新的产品截面，合适的产线从问对问题开始。', '了解我们的定制方法'] },
  purpose: { eyebrow: '我们做什么', title: '项目定义更清楚，设备才会更合适。', lead: '方舟塑机是建泰塑料机械的子品牌，围绕你的工艺开发塑料回收设备和定制挤出生产线。',
    body: '我们的工作，是把物料问题和设备决策连起来：进线的是什么、出线的是什么、中间需要发生什么，先写成一份清楚的项目说明。', link: '认识这家公司' },
  duo: { eyebrow: '两条相连的业务', title: '回收价值，再造下一件产品。', lead: '回收与挤出有同一个务实的起点：先弄懂物料，再围绕它设计工艺。',
    cards: [['塑料回收造粒设备', '薄膜边角料、硬质破碎料和需要熔体处理的物料，各自对应不同的配置。按进料和再生用途来规划整套流程。', '查看回收系统', '回收概念图：从预处理塑料到再生颗粒。'],
      ['定制塑料挤出产线', '管材、型材和软管产线围绕截面、材料和下游处理来开发，每一段都要服务于你要做的产品。', '查看挤出系统', '挤出概念图：模具、定型与下游处理。']] },
  steps: { eyebrow: '方舟的做法', title: '一条产线有多周全，取决于它背后的项目说明。', lead: '定制是一连串工程决定。我们把物料、工艺和现场条件放进同一场讨论。',
    items: [['先弄懂物料', '从有代表性的样品、产品要求和产线的运行条件开始。'], ['再定义系统', '把喂料、加工和下游各段连成一份接口清楚、责任明确的方案。'],
      ['按项目细化', '逐项核对布局、控制、公用工程和检修空间，让配置贴合工厂的实际运转。'], ['约定验收依据', '写明检查项目、技术文件和验收标准，从方案一直用到评估。']] },
  cta: { title: '下一段生产，从这里开始。', lead: '告诉我们你的物料、产品和期望的合作方式，我们帮你整理出一份周全的项目说明。', action: '聊聊你的项目' },
};
const kitRuns = [
  ['kit-arkpm', 'en', arkpmCopy, { direction: 'studio', mode: 'light', accent: '#265bff', neutral: 'stone', accent2: '#e57842' }],
  ['kit-zh', 'zh-CN', zhCopy, { direction: 'studio', mode: 'light', accent: '#265bff', neutral: 'stone', accent2: '#e57842' }],
  ['kit-zh-forest', 'zh-CN', zhCopy, { direction: 'studio', mode: 'light', accent: '#1f5c4a', neutral: 'warm', accent2: '#c8862c' }],
  ['kit-zh-dark', 'zh-CN', zhCopy, { direction: 'studio', mode: 'dark', accent: '#7aa2ff', neutral: 'cool', accent2: '#ffb347' }],
] as const;
for (const [name, lang, copy, art] of kitRuns) {
  const result = await compileV2Page(kitPage('calm-paper', copy), { mode: 'review', ownedAssets: kitOwned, verifiedFactRefs: [], art: art as any });
  writeFileSync(resolve(out, `${name}.html`), page(name, lang, result.html, result.css));
  console.log(`${name}.html css=` + new TextEncoder().encode(result.css).length + ' issues=' + result.issues.map(i => i.code + ':' + i.sectionId).join(','));
}
