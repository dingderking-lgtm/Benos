// Local preview only: one signed-in browser context shared by the screenshot scripts. The sign-in
// is saved next to the preview account file and reused, so repeated runs do not trip the sign-in
// rate limit (10 per account per 15 minutes). Never prints the account or the session.
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
const origin = 'http://127.0.0.1:4242';
const dir = resolve(process.cwd(), '../.ui-work/marketing-redesign'), statePath = resolve(dir, 'preview-session.json');
export async function signedInContext(browser, options = {}) {
  if (existsSync(statePath)) {
    const context = await browser.newContext({ ...options, storageState: statePath });
    try { const response = await context.request.get(origin + '/api/session'); if (response.ok() && (await response.json())?.data?.user) return context; } catch { /* fall through to a fresh sign-in */ }
    await context.close();
  }
  const account = readFileSync(resolve(dir, 'preview-account.txt'), 'utf8');
  const email = account.match(/邮箱[:：]\s*(\S+)/)[1], secret = account.match(/密码[:：]\s*(\S+)/)[1];
  const context = await browser.newContext(options), page = await context.newPage();
  const attempt = page.waitForResponse(response => response.url().endsWith('/api/auth/login'), { timeout: 20000 }).catch(() => null);
  await page.goto(origin + '/#/login');
  await page.fill('input[type=email]', email); await page.fill('input[type=password]', secret); await page.keyboard.press('Enter');
  const response = await attempt;
  if (response && response.status() === 429) { await context.close(); throw new Error('PREVIEW_SIGN_IN_RATE_LIMITED: wait up to 15 minutes; the preview allows 10 sign-ins per account per 15 minutes.'); }
  await page.waitForURL(/\/app\//, { timeout: 20000 });
  await context.storageState({ path: statePath }); await page.close();
  return context;
}
