// Stable identity of the grammar engine's bytes. An approval pins this digest: editing the compiler,
// the spec or the exemplar produces a new digest, and the old approval stops matching (which is the
// point — an owner approves the exact thing that will build their sites).
//   node scripts/design-grammar-identity.mjs --write | --check
import { createHash } from 'node:crypto';
import { readFileSync, existsSync, mkdirSync, writeFileSync, renameSync, unlinkSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const GRAMMAR_IDENTITY_VERSION = 'bnl-source-identity-1';
export const GRAMMAR_IDENTITY_FILE = 'src/design-system/grammar/source-identity.json';
/** The compiler, the text the model reads, and the reference page it is measured against. */
export const GRAMMAR_IDENTITY_SOURCES = Object.freeze([
  'src/design-system/grammar/brand.ts',
  'src/design-system/grammar/compile.ts',
  'src/design-system/grammar/site.ts',
  'src/design-system/grammar/spec.ts',
  'src/design-system/grammar/exemplars.ts',
]);
const platformRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');

export function collectGrammarIdentity(root = platformRoot) {
  const files = Object.fromEntries(GRAMMAR_IDENTITY_SOURCES.map(file => [file, sha256(readFileSync(resolve(root, file)))]));
  // The spec and the exemplar are part of the compiler identity, so they are named separately too:
  // an approval says which grammar text and which reference page the owner read.
  const identity = {
    version: GRAMMAR_IDENTITY_VERSION,
    compiler: sha256(JSON.stringify([files[GRAMMAR_IDENTITY_SOURCES[0]], files[GRAMMAR_IDENTITY_SOURCES[1]], files[GRAMMAR_IDENTITY_SOURCES[2]]])),
    spec: files['src/design-system/grammar/spec.ts'],
    exemplar: files['src/design-system/grammar/exemplars.ts'],
    files,
  };
  return { ...identity, digest: sha256(JSON.stringify(identity)) };
}
const encoded = identity => JSON.stringify(identity, null, 2) + '\n';
export function checkGrammarIdentity(root = platformRoot) {
  const identity = collectGrammarIdentity(root), target = resolve(root, GRAMMAR_IDENTITY_FILE);
  if (!existsSync(target) || readFileSync(target, 'utf8') !== encoded(identity)) {
    throw new Error('GRAMMAR_SOURCE_IDENTITY_STALE: grammar sources changed. Run node scripts/design-grammar-identity.mjs --write, review the new identity, then approve it again in the grammar ledger.');
  }
  return identity;
}
export function writeGrammarIdentity(root = platformRoot) {
  const identity = collectGrammarIdentity(root), content = encoded(identity), target = resolve(root, GRAMMAR_IDENTITY_FILE);
  if (existsSync(target) && readFileSync(target, 'utf8') === content) return { identity, changed: false };
  mkdirSync(dirname(target), { recursive: true });
  const temporary = target + '.' + process.pid + '.tmp';
  try { writeFileSync(temporary, content, { encoding: 'utf8', flag: 'wx' }); renameSync(temporary, target); }
  finally { if (existsSync(temporary)) unlinkSync(temporary); }
  return { identity, changed: true };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const args = process.argv.slice(2), modes = args.filter(arg => ['--write', '--check'].includes(arg));
    if (modes.length !== 1 || args.some(arg => !['--write', '--check'].includes(arg) && !arg.startsWith('--root='))) throw new Error('Usage: design-grammar-identity.mjs --write|--check [--root=<fixture directory>]');
    const root = resolve(args.find(arg => arg.startsWith('--root='))?.slice(7) || platformRoot);
    if (modes[0] === '--write') { const result = writeGrammarIdentity(root); console.log(`[bnl-identity] ${result.changed ? 'updated' : 'unchanged'} ${result.identity.digest}`); }
    else { const identity = checkGrammarIdentity(root); console.log(`[bnl-identity] verified ${identity.digest}`); }
  } catch (error) { console.error(`[bnl-identity] ${error instanceof Error ? error.message : String(error)}`); process.exitCode = 1; }
}
