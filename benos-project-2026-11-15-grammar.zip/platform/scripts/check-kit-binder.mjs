// Local check: applies the picture binder's inline geometry (the same declarations
// prepared-site-layout.ts pins on a frame and its pure media wrappers) to a rendered kit sample and
// reports whether the layout moves. Also covers the uncaptioned case, where the figure is a wrapper.
//   node scripts/check-kit-binder.mjs [sample.html] [width,width,...]
import { createRequire } from 'node:module';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.BENOS_TEST_PLAYWRIGHT || 'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const [sample = 'kit-arkpm.html', widths = '1680,1100,900,390'] = process.argv.slice(2);
const root = resolve(process.cwd(), '../artifacts/design-sample-20261115'), out = resolve(root, 'shots'); mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.BENOS_TEST_BROWSER || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const heights = page => page.evaluate(() => [...document.querySelectorAll('.bnx-section')].map(s => Math.round(s.getBoundingClientRect().height)));
const figures = page => page.evaluate(() => [...document.querySelectorAll('.bnx-media')].map(f => { const r = f.getBoundingClientRect(), p = f.parentElement.getBoundingClientRect(), cs = getComputedStyle(f.parentElement); return `${Math.round(r.width)}×${Math.round(r.height)} in ${Math.round(p.width)}×${Math.round(p.height)} border ${cs.borderTopWidth} r${cs.borderTopLeftRadius}`; }));
const pin = (page, dropCaptions) => page.evaluate(drop => {
  if (drop) for (const caption of [...document.querySelectorAll('figcaption')]) caption.remove();
  const meaningful = el => [...el.childNodes].filter(n => n.nodeType === 1 || (n.nodeType === 3 && n.textContent.trim()));
  for (const frame of document.querySelectorAll('.bnx-media')) {
    const section = frame.closest('.bnx-section'), [w, h] = section.classList.contains('bnx-hero-kit') ? [1200, 900] : [800, 600];
    const style = `display:block!important;box-sizing:border-box!important;width:100%!important;max-width:${w}px!important;min-width:0!important;height:auto!important;max-height:none!important;min-height:0!important;aspect-ratio:${w} / ${h}!important;overflow:hidden!important;padding:0!important;border:0!important`;
    const targets = [frame]; let child = frame;
    while (child.parentElement && ['DIV', 'FIGURE'].includes(child.parentElement.tagName) && meaningful(child.parentElement).length === 1) { targets.push(child.parentElement); child = child.parentElement; }
    for (const target of targets) target.setAttribute('style', (target.getAttribute('style') ? target.getAttribute('style') + ';' : '') + style);
    const img = frame.querySelector('img');
    if (img) img.setAttribute('style', `display:block!important;position:static!important;box-sizing:border-box!important;width:100%!important;max-width:100%!important;min-width:0!important;height:auto!important;max-height:none!important;min-height:0!important;aspect-ratio:${w} / ${h}!important;object-fit:cover!important;object-position:50% 50%!important;margin:0!important;padding:0!important;border:0!important`);
    frame.dataset.pinned = String(targets.length);
  }
  return [...document.querySelectorAll('.bnx-media')].map(f => Number(f.dataset.pinned));
}, dropCaptions);
for (const width of widths.split(',').map(Number)) {
  const page = await browser.newPage({ viewport: { width, height: 1000 } });
  const open = async () => { await page.goto(pathToFileURL(resolve(root, sample)).href); await page.waitForLoadState('networkidle'); };
  await open(); const plain = await heights(page), plainFigures = await figures(page);
  const pinned = await pin(page, false), captioned = await heights(page), captionedFigures = await figures(page);
  await open(); await page.evaluate(() => { for (const caption of [...document.querySelectorAll('figcaption')]) caption.remove(); }); const bare = await heights(page);
  await open(); const pinnedBare = await pin(page, true), uncaptioned = await heights(page), uncaptionedFigures = await figures(page);
  await page.screenshot({ path: resolve(out, `${sample.replace('.html', '')}-${width}-binder-nocaption.png`), fullPage: true });
  console.log(`\n== ${width}px`);
  console.log(' sections as compiled         ', plain.join(' / '));
  console.log(' with binder pins (captions)  ', captioned.join(' / '), plain.join() === captioned.join() ? '✓ unchanged' : '✗ MOVED', 'pinned elements per frame', pinned.join(','));
  console.log(' no captions, as compiled     ', bare.join(' / '));
  console.log(' no captions, binder pins     ', uncaptioned.join(' / '), bare.join() === uncaptioned.join() ? '✓ unchanged' : '✗ MOVED', 'pinned elements per frame', pinnedBare.join(','));
  console.log(' figures compiled   ', plainFigures.join(' | '));
  console.log(' figures pinned     ', captionedFigures.join(' | '));
  console.log(' figures no-caption ', uncaptionedFigures.join(' | '));
  await page.close();
}
await browser.close();
