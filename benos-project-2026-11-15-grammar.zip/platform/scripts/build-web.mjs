// Assemble web-dist/: the single static-asset directory the Worker serves (wrangler assets.directory).
//   1. build the Next.js static export of the front end (BENOS_WEB_DIR, default ../UI模板)
//   2. copy the platform/public files that server-rendered backend pages still reference
//   3. copy the front end's runtime assets from its dist/ folder
//   4. merge the Next export (frontend/out) last so its index.html, 404.html and _next/ win
//   5. hash every inline <script> of every HTML file into src/generated/web-csp.ts
// Plain Node, no dependencies. Flags: --skip-next reuses an existing frontend/out without rebuilding.
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { cp, mkdir, readdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { dirname, extname, join, posix, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { syncDesignDirections } from '../../UI模板/scripts/sync-design-directions.mjs';
import { checkV2SourceIdentity } from './design-system-v2-identity.mjs';

const backend = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const webDir = resolve(backend, process.env.BENOS_WEB_DIR || '../UI模板');
const publicDir = join(backend, 'public');
const outDir = join(backend, 'web-dist');
const cspFile = join(backend, 'src', 'generated', 'web-csp.ts');
const skipNext = process.argv.includes('--skip-next');
const started = Date.now();

class BuildError extends Error {}
const fail = message => { throw new BuildError(message); };
const toPosix = path => path.split(sep).join('/');
const requirePath = (path, what) => { if (!existsSync(path)) fail(`${what} is missing: ${path}`); return path; };

async function listFiles(base, dir = '') {
  const files = [];
  for (const entry of await readdir(join(base, dir), { withFileTypes: true })) {
    const path = dir ? `${dir}/${entry.name}` : entry.name;
    if (entry.isDirectory()) files.push(...await listFiles(base, path));
    else if (entry.isFile()) files.push(path);
  }
  return files;
}

async function copyInto(source, target) {
  await mkdir(dirname(target), { recursive: true });
  await cp(source, target, { force: true });
}

// Same algorithm as UI模板/scripts/source-assets.mjs#inlineScriptHashes: hash the exact
// emitted bytes of every inline script (no src attribute, non-empty body).
function inlineScriptHashes(html) {
  const hashes = new Set();
  for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)) {
    if (/\bsrc\s*=/i.test(match[1]) || !match[2]) continue;
    hashes.add(createHash('sha256').update(match[2], 'utf8').digest('base64'));
  }
  return [...hashes];
}

function runNextBuild() {
  const nextBin = requirePath(join(webDir, 'node_modules', 'next', 'dist', 'bin', 'next'), 'Front-end dependency next (run npm install in the front end)');
  requirePath(join(webDir, 'frontend'), 'Front-end Next app');
  return new Promise((resolveBuild, reject) => {
    const child = spawn(process.execPath, [nextBin, 'build', join(webDir, 'frontend'), '--webpack'], {
      cwd: webDir, stdio: 'inherit', env: { ...process.env, NEXT_TELEMETRY_DISABLED: '1' },
    });
    child.once('error', reject);
    child.once('exit', (code, signal) => code === 0 ? resolveBuild() : reject(new BuildError(`Next.js export failed (${signal || code}).`)));
  });
}

// (a) platform/public files referenced by server-rendered pages in src/ (marketing pages,
// content previews, brand defaults), plus CSS url()/@import dependencies and sibling licences.
async function publicReferences() {
  const sources = (await listFiles(join(backend, 'src'))).filter(path => path.endsWith('.ts') && !path.startsWith('generated/'));
  const wanted = new Set();
  // Match root-relative local references, not /styles or /assets occurring
  // inside pinned upstream URLs/source paths in provenance metadata.
  const pattern = /(?<![A-Za-z0-9._/\\-])\/((?:styles|assets|js)\/[A-Za-z0-9._\/-]+\.(?:css|js|mjs|svg|png|jpe?g|webp|gif|ico|woff2?|ttf|txt|json))(?![A-Za-z0-9])/g;
  for (const path of sources) {
    const text = await readFile(join(backend, 'src', path), 'utf8');
    for (const match of text.matchAll(pattern)) wanted.add(match[1]);
  }
  if (!wanted.size) fail('No /styles/, /assets/ or /js/ references found in src/ — the scan is broken.');
  const queue = [...wanted];
  while (queue.length) {
    const path = queue.shift();
    requirePath(join(publicDir, path), `public/${path} (referenced by the Worker)`);
    if (!path.endsWith('.css')) continue;
    const css = await readFile(join(publicDir, path), 'utf8');
    for (const match of css.matchAll(/url\(\s*['"]?([^'")]+)['"]?\s*\)|@import\s+['"]([^'"]+)['"]/g)) {
      const ref = (match[1] || match[2]).split(/[?#]/)[0];
      if (/^(data:|https?:|\/\/)/i.test(ref)) continue;
      const resolved = ref.startsWith('/') ? ref.slice(1) : posix.join(posix.dirname(path), ref);
      if (!wanted.has(resolved)) { wanted.add(resolved); queue.push(resolved); }
    }
  }
  // Ship licence / provenance notes next to the fonts and brand files they cover.
  for (const dir of new Set([...wanted].map(path => posix.dirname(path)))) {
    if (!existsSync(join(publicDir, dir))) continue;
    for (const entry of await readdir(join(publicDir, dir), { withFileTypes: true })) {
      if (entry.isFile() && /^(LICENSE|PROVENANCE)/i.test(entry.name)) wanted.add(`${dir}/${entry.name}`);
    }
  }
  return [...wanted].sort();
}

// (b) front-end runtime assets from UI模板/dist (legacy modules, stylesheets, images).
// Keep the original sources in dist for handoff/history, but do not publish retired local-demo engines.
const excludedDist = new Set(['index.html', 'review.html', 'review.js', 'design-rules.js', 'assets/benos-logo-original.png',
  'design-engine.js', 'design-integration.js', 'designer-chat.js', 'designer-canvas.js', 'designer-tools.js', 'designer.js',
  'cms-import.js', 'cms-import.css', 'hosting-domain-ui.js', 'hosting-domain.css']);
const excludedDistDirs = ['server/', 'downloads/', 'previews/'];
async function frontEndRuntime(distDir) {
  return (await listFiles(distDir)).filter(path => {
    if (path.split('/').some(part => part.startsWith('.'))) return false;
    if (excludedDistDirs.some(dir => path.startsWith(dir))) return false;
    if (excludedDist.has(path) || path.toLowerCase().endsWith('.md')) return false;
    return true;
  }).sort();
}

// Scripts and stylesheets the React shell loads at runtime; every one must be in web-dist.
async function requiredRuntime() {
  const bridge = await readFile(requirePath(join(webDir, 'frontend', 'lib', 'legacy-bridge.ts'), 'Front-end legacy bridge'), 'utf8');
  const scriptBlock = bridge.match(/const scripts\s*=\s*\[([\s\S]*?)\]/);
  const scripts = scriptBlock ? [...scriptBlock[1].matchAll(/'([^']+\.js)'/g)].map(match => match[1]) : [];
  if (!scripts.length) fail('Could not read the legacy script list from frontend/lib/legacy-bridge.ts.');
  return scripts;
}

function htmlReferences(html) {
  const refs = new Set();
  for (const match of html.matchAll(/<(?:script|link)\b[^>]*?\b(?:src|href)\s*=\s*"([^"]+)"/gi)) {
    const ref = match[1].replace(/&amp;/g, '&').split(/[?#]/)[0];
    if (ref.startsWith('/') && !ref.startsWith('//')) refs.add(ref.slice(1));
  }
  return [...refs];
}

async function main() {
  // Refuse stale compiler approval identities before building/copying any assets.
  checkV2SourceIdentity(backend);
  requirePath(webDir, 'Front-end directory (set BENOS_WEB_DIR)');
  await syncDesignDirections({ webDir });
  const distDir = requirePath(join(webDir, 'dist'), 'Front-end runtime assets (dist/)');
  const nextOut = join(webDir, 'frontend', 'out');
  if (skipNext) console.log('[build-web] --skip-next: reusing the existing Next export');
  else await runNextBuild();
  requirePath(join(nextOut, 'index.html'), 'Next export (frontend/out/index.html)');
  requirePath(join(nextOut, '_next', 'static'), 'Next export (frontend/out/_next/static)');
  requirePath(publicDir, 'platform/public');

  const publicFiles = await publicReferences();
  const runtimeFiles = await frontEndRuntime(distDir);
  const nextFiles = (await listFiles(nextOut)).filter(path => !path.split('/').some(part => part.startsWith('.')));

  await rm(outDir, { recursive: true, force: true });
  await mkdir(outDir, { recursive: true });
  const origin = new Map();
  for (const path of publicFiles) { await copyInto(join(publicDir, path), join(outDir, path)); origin.set(path, 'public'); }
  let overrides = 0;
  for (const path of runtimeFiles) { if (origin.has(path)) overrides++; await copyInto(join(distDir, path), join(outDir, path)); origin.set(path, 'dist'); }
  for (const path of nextFiles) { if (origin.has(path)) overrides++; await copyInto(join(nextOut, path), join(outDir, path)); origin.set(path, 'next'); }

  // Verify the shell's runtime dependencies landed in web-dist.
  const missing = [];
  for (const script of await requiredRuntime()) if (!origin.has(script)) missing.push(script);
  const htmlFiles = [...origin.keys()].filter(path => path.endsWith('.html')).sort();
  const hashes = new Set();
  for (const path of htmlFiles) {
    const html = await readFile(join(outDir, path), 'utf8');
    for (const hash of inlineScriptHashes(html)) hashes.add(hash);
    if (path === 'index.html') for (const ref of htmlReferences(html)) if (!origin.has(ref) && !origin.has(ref.replace(/\/$/, '') + '/index.html')) missing.push(`${ref} (referenced by index.html)`);
  }
  if (missing.length) fail(`web-dist is missing runtime files:\n  ${missing.join('\n  ')}`);
  for (const hash of hashes) if (!/^[A-Za-z0-9+/]{43}=$/.test(hash)) fail(`Unexpected inline script hash ${hash}`);

  const sorted = [...hashes].sort();
  const source = `// GENERATED by scripts/build-web.mjs — do not edit by hand.\n// SHA-256 (base64) of every inline <script> in web-dist/*.html (Next.js export).\n// src/index.ts adds them to script-src for HTML responses. The committed default is an empty list.\nexport const webScriptHashes: readonly string[] = ${JSON.stringify(sorted, null, 2)};\n`;
  await mkdir(dirname(cspFile), { recursive: true });
  const previous = existsSync(cspFile) ? await readFile(cspFile, 'utf8') : '';
  if (previous !== source) await writeFile(cspFile, source);

  let bytes = 0;
  for (const path of origin.keys()) bytes += (await stat(join(outDir, path))).size;
  const count = kind => [...origin.values()].filter(value => value === kind).length;
  console.log(`[build-web] web-dist: ${origin.size} files, ${(bytes / 1048576).toFixed(2)} MiB (public ${count('public')}, front-end dist ${count('dist')}, next ${count('next')}; ${overrides} overridden) · ${htmlFiles.length} HTML, ${sorted.length} inline-script hashes → ${toPosix(relative(backend, cspFile))} · ${((Date.now() - started) / 1000).toFixed(1)}s`);
}

main().catch(error => {
  console.error(`[build-web] FAILED: ${error instanceof BuildError ? error.message : error?.stack || error}`);
  process.exit(1);
});
