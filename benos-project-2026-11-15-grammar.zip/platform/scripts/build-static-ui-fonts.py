"""Derive compatibility weights from the existing licensed UI subset.

Requires fonttools and brotli. No download, new font source, or glyph expansion.
Run from the repository root: python scripts/build-static-ui-fonts.py
"""
from pathlib import Path
import hashlib,json
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

root=Path(__file__).resolve().parents[1]
source=root/'public/assets/fonts/studio-sans-sc.woff2'
rows=[]
for weight in [400,500,550,600,650,700]:
 font=TTFont(source,recalcTimestamp=False)
 original=set(font.getBestCmap())
 instantiateVariableFont(font,{'wght':weight},inplace=True)
 assert 'fvar' not in font and set(font.getBestCmap())==original
 assert font['OS/2'].usWeightClass==weight
 font.flavor='woff2'
 output=source.with_name(f'studio-sans-sc-{weight}.woff2')
 font.save(output)
 content=output.read_bytes()
 rows.append({'weight':weight,'file':output.name,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'codepoints':len(original)})
print(json.dumps({'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'weights':rows},indent=2))
