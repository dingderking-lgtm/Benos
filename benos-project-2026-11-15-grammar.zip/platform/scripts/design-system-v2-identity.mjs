// Stable identity of original compiler bytes, independent of tsx/esbuild/minify.
// --write updates only changed bytes; --check never writes. No timestamp or self hash.
import { createHash } from 'node:crypto';
import { readFileSync, existsSync, mkdirSync, writeFileSync, renameSync, unlinkSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const V2_IDENTITY_VERSION = 'bnx-source-identity-1';
export const V2_IDENTITY_FILE = 'src/design-system/v2/source-identity.json';
export const V2_IDENTITY_SOURCES = Object.freeze([
  'src/contracts/section-patterns.ts',
  'src/design-system/v2/adapted-primitives.ts',
  'src/design-system/v2/contracts.ts',
  'src/design-system/v2/provenance.ts',
  'src/design-system/v2/registry.ts',
  'src/design-system/v2/render.ts',
  'src/design-system/v2/styles.ts',
  'src/design-system/v2/kit.ts',
]);
const platformRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');

export function collectV2SourceIdentity(root = platformRoot) {
  const files = Object.fromEntries(V2_IDENTITY_SOURCES.map(file => [file, sha256(readFileSync(resolve(root, file)))]));
  const payload = { version: V2_IDENTITY_VERSION, files };
  return { ...payload, digest: sha256(JSON.stringify(payload)) };
}
const encoded = identity => JSON.stringify(identity, null, 2) + '\n';
export function checkV2SourceIdentity(root = platformRoot) {
  const identity = collectV2SourceIdentity(root), target = resolve(root, V2_IDENTITY_FILE);
  if (!existsSync(target) || readFileSync(target, 'utf8') !== encoded(identity)) {
    throw new Error('BNX_SOURCE_IDENTITY_STALE: original compiler sources changed. Run node scripts/design-system-v2-identity.mjs --write, review the new identity, then rerun checks. Existing exact approvals must be reviewed again.');
  }
  return identity;
}
export function writeV2SourceIdentity(root = platformRoot) {
  const identity = collectV2SourceIdentity(root), content = encoded(identity), target = resolve(root, V2_IDENTITY_FILE);
  if (existsSync(target) && readFileSync(target, 'utf8') === content) return { identity, changed: false };
  mkdirSync(dirname(target), { recursive: true });
  const temporary = target + '.' + process.pid + '.tmp';
  try { writeFileSync(temporary, content, { encoding: 'utf8', flag: 'wx' }); renameSync(temporary, target); }
  finally { if (existsSync(temporary)) unlinkSync(temporary); }
  return { identity, changed: true };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const args = process.argv.slice(2), modes = args.filter(arg => ['--write', '--check', '--build'].includes(arg));
    if (modes.length !== 1 || args.some(arg => !['--write', '--check', '--build'].includes(arg) && !arg.startsWith('--root=')) || args.filter(arg => arg.startsWith('--root=')).length > 1) throw new Error('Usage: design-system-v2-identity.mjs --write|--check|--build [--root=<isolated fixture directory>]');
    const root = resolve(args.find(arg => arg.startsWith('--root='))?.slice(7) || platformRoot);
    const mode = modes[0] === '--build' ? process.env.BENOS_V2_IDENTITY_DEV === '1' ? '--write' : '--check' : modes[0];
    if (mode === '--write') { const result = writeV2SourceIdentity(root); console.log(`[bnx-identity] ${result.changed ? 'updated' : 'unchanged'} ${result.identity.digest}`); }
    else { const identity = checkV2SourceIdentity(root); console.log(`[bnx-identity] verified ${identity.digest}`); }
  } catch (error) { console.error(`[bnx-identity] ${error instanceof Error ? error.message : String(error)}`); process.exitCode = 1; }
}
