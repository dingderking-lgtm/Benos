// Extracts, from a starter template's stylesheet, every rule that styles a given set of classes
// (including the rules inside @media blocks). Read-only; prints the subset.
//   node scripts/extract-starter-css.mjs <id> <class,class,...> [--out file]
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
const [id = 'arkpm', list = '', flag, outFile] = process.argv.slice(2);
const wanted = new Set(list.split(',').map(s => s.trim()).filter(Boolean));
const css = JSON.parse(readFileSync(resolve(process.cwd(), `web-dist/starters/${id}/manifest.json`), 'utf8')).site.theme.global_css.replace(/\/\*[\s\S]*?\*\//g, '');
function blocks(text) { // top-level "prelude{body}" pairs
  const out = []; let depth = 0, start = 0, open = -1;
  for (let i = 0; i < text.length; i++) { const ch = text[i]; if (ch === '{') { if (depth === 0) open = i; depth++; } else if (ch === '}') { depth--; if (depth === 0) { out.push([text.slice(start, open).trim(), text.slice(open + 1, i)]); start = i + 1; } } }
  return out;
}
const uses = selector => [...selector.matchAll(/\.([a-zA-Z][\w-]*)/g)].some(m => wanted.has(m[1]));
const keep = selector => selector.split(',').filter(uses).join(',');
let result = '', count = 0;
for (const [prelude, body] of blocks(css)) {
  if (prelude.startsWith('@media')) { const inner = blocks(body).map(([sel, decl]) => [keep(sel), decl]).filter(([sel]) => sel); if (inner.length) { count += inner.length; result += `${prelude}{\n${inner.map(([sel, decl]) => `  ${sel}{${decl}}`).join('\n')}\n}\n`; } }
  else if (!prelude.startsWith('@')) { const sel = keep(prelude); if (sel) { count++; result += `${sel}{${body}}\n`; } }
}
if (flag === '--out' && outFile) writeFileSync(resolve(process.cwd(), outFile), result);
console.log(`/* ${count} rules, ${result.length} bytes */`);
if (flag !== '--out') console.log(result);
