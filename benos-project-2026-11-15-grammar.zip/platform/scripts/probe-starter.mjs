// Local preview only: prints computed style values of elements on a starter template page, so a
// ported section can be checked against what the template really renders (not what one rule says).
//   node scripts/probe-starter.mjs <path> <width> "<selector>" "<prop,prop,...>" [maxMatches]
import { createRequire } from 'node:module';
import { signedInContext } from './preview-session.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.BENOS_TEST_PLAYWRIGHT || 'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const [target = '/preview/starter/arkpm', widthArg = '1680', selector = 'h1', props = 'font-size,line-height', maxArg = '4'] = process.argv.slice(2);
const browser = await chromium.launch({ executablePath: process.env.BENOS_TEST_BROWSER || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const viewport = { width: Number(widthArg), height: 1200 }, external = /^https?:|^file:/.test(target);
const page = external ? await browser.newPage({ viewport }) : await (await signedInContext(browser, { viewport })).newPage();
await page.goto(external ? target : 'http://127.0.0.1:4242' + target);
await page.waitForLoadState('networkidle');
const rows = await page.evaluate(([sel, list, max]) => [...document.querySelectorAll(sel)].slice(0, max).map(el => {
  const cs = getComputedStyle(el), r = el.getBoundingClientRect();
  return { text: (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 40), cls: String(el.className).slice(0, 60), box: `${Math.round(r.width * 10) / 10}×${Math.round(r.height * 10) / 10}`, ...Object.fromEntries(list.map(p => [p, cs.getPropertyValue(p)])) };
}), [selector, props.split(',').map(s => s.trim()).filter(Boolean), Number(maxArg)]);
for (const row of rows) console.log(JSON.stringify(row));
if (!rows.length) console.log('no match for', selector);
await browser.close();
