#!/usr/bin/env node
// Offline only. No credentials in arguments, no network, no live database writes.
import { DatabaseSync, backup, constants as sqlite } from 'node:sqlite';
import { createHash,createHmac,createDecipheriv,randomUUID,timingSafeEqual } from 'node:crypto';
import { readFileSync,writeFileSync,copyFileSync,mkdirSync,mkdtempSync,readdirSync,lstatSync,statSync,realpathSync,existsSync,rmSync,openSync,readSync,closeSync,constants } from 'node:fs';
import { resolve,join,dirname,relative,sep } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL,fileURLToPath } from 'node:url';
import { validateSiteManifest } from '../src/modules/template-contract.ts';

const FORMAT='benos-platform-recovery',VERSION=1;
export class RecoveryError extends Error {constructor(code){super(code);this.code=code;}}
function check(value,code){if(!value)throw new RecoveryError(code);}
const sha=value=>createHash('sha256').update(value).digest('hex');
const manifestSummary=manifest=>({siteName:String(manifest.site.name??'').slice(0,180),home:manifest.site.home??null,headerTemplateId:manifest.site.header_template_id??null,footerTemplateId:manifest.site.footer_template_id??null,templates:manifest.templates.map(item=>({id:item.id,type:item.type,name:String(item.name??'').slice(0,180)})),pages:manifest.site.pages.map(item=>({key:item.key,slug:item.slug,templateId:item.template_id}))});
const quote=name=>'"'+name.replaceAll('"','""')+'"';
// Only views shipped by this version may be restored. Derive their exact SQL
// from trusted local migrations, never from the database being inspected.
// Whitespace inside quoted SQL values must remain significant.
const normalizedViewSql=sql=>sql.trim().replace(/;$/,'').replace(/'(?:[^']|'')*'|"(?:[^"]|"")*"|\s+/g,part=>/^\s/.test(part)?' ':part);
let trustedViews;
function approvedViews(){
 if(trustedViews)return trustedViews;
 const schema=new DatabaseSync(':memory:',{allowExtension:false});
 try{
  const migrationDir=resolve(dirname(fileURLToPath(import.meta.url)),'../migrations');
  for(const file of readdirSync(migrationDir).filter(name=>/^\d+_[\w-]+\.sql$/.test(name)).sort())schema.exec(readFileSync(join(migrationDir,file),'utf8'));
  trustedViews=new Map(schema.prepare("SELECT name,sql FROM sqlite_schema WHERE type='view'").all().map(view=>[view.name,normalizedViewSql(view.sql)]));
  return trustedViews;
 }finally{schema.close();}
}
const canonical=value=>JSON.stringify(value,(_key,item)=>typeof item==='bigint'?{$integer:String(item)}:item instanceof Uint8Array?{$blob:Buffer.from(item).toString('base64')}:item);
function masterKey(){const value=process.env.ENCRYPTION_KEY;check(typeof value==='string'&&/^[A-Za-z0-9_-]{43}$/.test(value),'ENCRYPTION_KEY_REQUIRED');const key=Buffer.from(value,'base64url');check(key.length===32&&key.toString('base64url')===value,'ENCRYPTION_KEY_INVALID');return key;}
function signature(manifest,key){return createHmac('sha256',key).update('BENOS-RECOVERY-MANIFEST-V1\n').update(canonical(manifest)).digest('hex');}
function regular(path){const item=lstatSync(path);check(item.isFile()&&!item.isSymbolicLink()&&item.nlink===1,'UNSAFE_FILE');return item;}
function hashFile(path){regular(path);const hash=createHash('sha256'),handle=openSync(path,'r'),buffer=Buffer.alloc(1048576);try{let n;while((n=readSync(handle,buffer,0,buffer.length,null))>0)hash.update(buffer.subarray(0,n));}finally{closeSync(handle);}return hash.digest('hex');}
function safeKey(key){check(typeof key==='string'&&key.startsWith('private/')&&key.length<=1024&&!/[\\:\x00-\x1f\x7f]/.test(key),'UNSAFE_OBJECT_KEY');for(const part of key.split('/'))check(part&&part!=='.'&&part!=='..'&&!/[. ]$/.test(part)&&!(/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)),'UNSAFE_OBJECT_KEY');return key;}
function walk(root){check(lstatSync(root).isDirectory()&&!lstatSync(root).isSymbolicLink(),'UNSAFE_DIRECTORY');const result=[],seen=new Set();function visit(directory,prefix=''){for(const item of readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){check(!item.isSymbolicLink(),'SYMLINK_DENIED');const key=prefix+item.name,path=join(directory,item.name);if(item.isDirectory())visit(path,key+'/');else{regular(path);check(!seen.has(key.toLowerCase()),'CASE_COLLISION');seen.add(key.toLowerCase());result.push({key,path});check(result.length<=100000,'OBJECT_LIMIT_EXCEEDED');}}}visit(root);return result;}
function temporary(){const base=realpathSync(tmpdir()),path=mkdtempSync(join(base,'benos-recovery-'));return {path,close(){const actual=realpathSync(path);check(actual.startsWith(base+sep)&&relative(base,actual).startsWith('benos-recovery-'),'UNSAFE_CLEANUP');rmSync(actual,{recursive:true,force:true});}};}
function newTarget(path,sources=[]){const target=resolve(path);check(!existsSync(target),'TARGET_EXISTS');check(existsSync(dirname(target))&&!lstatSync(dirname(target)).isSymbolicLink(),'TARGET_PARENT_REQUIRED');const realParent=realpathSync(dirname(target));for(const source of sources){const real=realpathSync(source);check(realParent!==real&&!realParent.startsWith(real+sep),'TARGET_INSIDE_SOURCE');}return target;}
function readonly(path){const db=new DatabaseSync(path,{readOnly:true,allowExtension:false});check(typeof db.setAuthorizer==='function'&&typeof db.enableDefensive==='function','NODE_24_10_REQUIRED');db.enableDefensive(true);db.exec('PRAGMA trusted_schema=OFF;');return db;}
function rows(db,sql,...values){const statement=db.prepare(sql);statement.setReadBigInts(true);return statement.all(...values);}
function noRows(db,sql,code){check(rows(db,sql).length===0,code);}
function scalar(db,sql){return rows(db,sql)[0];}
async function normalizeDatabase(source,target){
 regular(source);const before=hashFile(source),header=Buffer.alloc(16),handle=openSync(source,'r');try{readSync(handle,header,0,16,0);}finally{closeSync(handle);}
 if(header.toString('binary')==='SQLite format 3\0'){
   for(const suffix of ['-wal','-journal'])check(!existsSync(source+suffix)||statSync(source+suffix).size===0,'DATABASE_NOT_QUIESCENT');
   const db=readonly(source);try{await backup(db,target);}finally{db.close();}
 }else{
   check(statSync(source).size<=256*1048576,'SQL_FILE_TOO_LARGE_USE_SQLITE');
   const db=new DatabaseSync(target,{allowExtension:false});check(typeof db.setAuthorizer==='function','NODE_24_10_REQUIRED');db.enableDefensive(true);db.exec('PRAGMA foreign_keys=OFF;PRAGMA trusted_schema=OFF;');
   db.setAuthorizer((action,a,b)=>{
     if([sqlite.SQLITE_ATTACH,sqlite.SQLITE_DETACH,sqlite.SQLITE_CREATE_VTABLE,sqlite.SQLITE_DROP_VTABLE].includes(action))return sqlite.SQLITE_DENY;
     if(action===sqlite.SQLITE_PRAGMA&&!['foreign_keys','defer_foreign_keys'].includes(String(a).toLowerCase()))return sqlite.SQLITE_DENY;
     if(action===sqlite.SQLITE_FUNCTION&&['load_extension','readfile','writefile','edit','fts3_tokenizer'].includes(String(b).toLowerCase()))return sqlite.SQLITE_DENY;
     return sqlite.SQLITE_OK;
   });
   try{db.exec(readFileSync(source,'utf8').replace(/^\uFEFF/,''));check(!db.isTransaction,'SQL_TRANSACTION_INCOMPLETE');}catch{throw new RecoveryError('SQL_IMPORT_REJECTED');}finally{db.close();}
 }
 check(hashFile(source)===before,'SOURCE_CHANGED');return before;
}
function decrypt(value,key,context){try{const [version,iv,data]=value.split('.'),bytes=Buffer.from(data,'base64url');check(version==='v1'&&Buffer.from(iv,'base64url').length===12&&bytes.length>=16,'CIPHERTEXT_INVALID');const cipher=createDecipheriv('aes-256-gcm',key,Buffer.from(iv,'base64url'));cipher.setAAD(Buffer.from(context));cipher.setAuthTag(bytes.subarray(-16));return Buffer.concat([cipher.update(bytes.subarray(0,-16)),cipher.final()]);}catch{throw new RecoveryError('CIPHERTEXT_OR_KEY_INVALID');}}
function inspectDatabase(path,objects,key,objectPath){
 const db=readonly(path);try{
  const integrity=db.prepare('PRAGMA integrity_check').all();check(integrity.length===1&&Object.values(integrity[0])[0]==='ok','DATABASE_INTEGRITY_FAILED');noRows(db,'PRAGMA foreign_key_check','FOREIGN_KEY_FAILED');
  const schema=rows(db,"SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' AND name<>'_cf_KV' ORDER BY type,name");check(schema.every(item=>! /CREATE\s+VIRTUAL\s+TABLE/i.test(item.sql)&&(item.type!=='view'||approvedViews().get(item.name)===normalizedViewSql(item.sql))),'UNSUPPORTED_SCHEMA');
  const tables=schema.filter(item=>item.type==='table').map(item=>item.name),tableSet=new Set(tables);for(const table of ['users','orders','credit_grants','provider_pools','provider_funding','api_reservations','reservation_allocations','ledger_commands','ledger_events','projects','design_versions','project_media','image_jobs','integration_configs'])check(tableSet.has(table),'PLATFORM_SCHEMA_INCOMPLETE');
  noRows(db,"SELECT 1 FROM ledger_commands WHERE status<>'completed' LIMIT 1",'INCOMPLETE_LEDGER_COMMAND');
  noRows(db,`SELECT 1 FROM api_reservations r WHERE r.amount_micros<>(SELECT COALESCE(SUM(a.reserved_micros),0) FROM reservation_allocations a WHERE a.reservation_id=r.id)
    OR COALESCE(r.actual_micros,0)<>(SELECT COALESCE(SUM(a.consumed_micros),0) FROM reservation_allocations a WHERE a.reservation_id=r.id) LIMIT 1`,'RESERVATION_BALANCE_INVALID');
  noRows(db,'SELECT 1 FROM reservation_allocations a JOIN credit_grants g ON g.id=a.grant_id JOIN api_reservations r ON r.id=a.reservation_id WHERE g.user_id<>r.user_id LIMIT 1','CROSS_USER_ALLOCATION');
  noRows(db,`SELECT 1 FROM credit_grants g WHERE g.reserved_micros<>(SELECT COALESCE(SUM(a.reserved_micros),0) FROM reservation_allocations a JOIN api_reservations r ON r.id=a.reservation_id WHERE a.grant_id=g.id AND r.state IN ('reserved','dispatching','uncertain'))
    OR g.consumed_micros<>(SELECT COALESCE(SUM(a.consumed_micros),0) FROM reservation_allocations a WHERE a.grant_id=g.id) LIMIT 1`,'GRANT_BALANCE_INVALID');
  const opsHeld=tableSet.has('integration_function_tests')?"+(SELECT COALESCE(SUM(t.reserved_micros),0) FROM integration_function_tests t WHERE t.provider_id=p.provider_id AND t.accounting_state='held')":'',opsSpent=tableSet.has('integration_function_tests')?"+(SELECT COALESCE(SUM(t.actual_micros),0) FROM integration_function_tests t WHERE t.provider_id=p.provider_id AND t.accounting_state IN ('settled','released'))":'';
  if(tableSet.has('operations_budgets'))noRows(db,`SELECT 1 FROM operations_budgets p WHERE p.reserved_micros<>(0${opsHeld}) OR p.consumed_micros<>(0${opsSpent}) LIMIT 1`,'OPERATIONS_BALANCE_INVALID');
  if(tableSet.has('operations_budget_events'))noRows(db,`SELECT 1 FROM integration_function_tests t WHERE
    (t.accounting_state<>'none' AND NOT EXISTS(SELECT 1 FROM operations_budget_events e WHERE e.test_id=t.id AND e.provider_id=t.provider_id AND e.kind='reserve' AND e.amount_micros=t.reserved_micros)) OR
    (t.accounting_state IN ('settled','released') AND NOT EXISTS(SELECT 1 FROM operations_budget_events e WHERE e.test_id=t.id AND e.provider_id=t.provider_id AND e.kind=CASE t.accounting_state WHEN 'released' THEN 'release' ELSE 'settle' END AND e.amount_micros=t.actual_micros)) LIMIT 1`,'OPERATIONS_EVENT_INVALID');
  noRows(db,`SELECT 1 FROM provider_pools p WHERE p.reserved_micros<>((SELECT COALESCE(SUM(r.amount_micros),0) FROM api_reservations r WHERE r.provider_id=p.provider_id AND r.state IN ('reserved','dispatching','uncertain'))${opsHeld})
    OR p.consumed_micros<>((SELECT COALESCE(SUM(r.actual_micros),0) FROM api_reservations r WHERE r.provider_id=p.provider_id)${opsSpent})
    OR p.funded_micros<>(SELECT COALESCE(SUM(f.amount_micros),0) FROM provider_funding f WHERE f.provider_id=p.provider_id)${tableSet.has('provider_debits')?'-(SELECT COALESCE(SUM(d.amount_micros),0) FROM provider_debits d WHERE d.provider_id=p.provider_id)':''} LIMIT 1`,'PROVIDER_BALANCE_INVALID');
  if(tableSet.has('financial_credit_adjustments'))noRows(db,`SELECT 1 FROM credit_grants g WHERE g.reversed_micros<>(SELECT COALESCE(SUM(CASE WHEN a.direction='reverse' THEN a.amount_micros ELSE -a.amount_micros END),0) FROM financial_credit_adjustments a WHERE a.grant_id=g.id) LIMIT 1`,'CREDIT_ADJUSTMENT_INVALID');
  noRows(db,`SELECT 1 FROM projects p WHERE (p.current_version_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM design_versions v WHERE v.id=p.current_version_id AND v.project_id=p.id)) OR (p.published_version_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM design_versions v WHERE v.id=p.published_version_id AND v.project_id=p.id)) LIMIT 1`,'PROJECT_VERSION_REFERENCE_INVALID');
  noRows(db,'SELECT 1 FROM design_versions v JOIN design_versions parent ON parent.id=v.parent_id WHERE parent.project_id<>v.project_id LIMIT 1','VERSION_PARENT_INVALID');
  const objectMap=new Map(objects.map(item=>[item.key,item]));
  const requireObject=(objectKey,hash,size)=>{safeKey(objectKey);const item=objectMap.get(objectKey);check(item,'OBJECT_MISSING');if(hash)check(item.sha256===hash,'OBJECT_DIGEST_MISMATCH');if(size!==undefined&&size!==null)check(BigInt(item.size)===BigInt(size),'OBJECT_SIZE_MISMATCH');};
  const media=[...rows(db,'SELECT * FROM project_media'),...(tableSet.has('project_media_extended')?rows(db,'SELECT * FROM project_media_extended'):[])];for(const item of media){safeKey(item.object_key);if(item.state!=='staging'||objectMap.has(item.object_key))requireObject(item.object_key,item.sha256,item.byte_size);}
  if(tableSet.has('content_media')){
   for(const item of rows(db,'SELECT * FROM content_media')){safeKey(item.object_key);if(item.state!=='staging'||objectMap.has(item.object_key))requireObject(item.object_key,item.sha256,item.byte_size);}
   if(tableSet.has('platform_brand_versions'))noRows(db,"SELECT 1 FROM platform_brand_versions b WHERE json_extract(b.configuration_json,'$.logoMediaId') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM content_media m WHERE m.id=json_extract(b.configuration_json,'$.logoMediaId') AND m.state='ready') LIMIT 1",'BRAND_MEDIA_REFERENCE_INVALID');
   if(tableSet.has('content_entries'))for(const column of ['draft_json','published_json'])noRows(db,`SELECT 1 FROM content_entries e WHERE json_extract(e.${column},'$.coverMediaId') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM content_media m WHERE m.id=json_extract(e.${column},'$.coverMediaId') AND m.state<>'staging') LIMIT 1`,'CONTENT_MEDIA_REFERENCE_INVALID');
  }
  const projects=new Map(rows(db,'SELECT id,user_id FROM projects').map(item=>[item.id,item]));
  if(tableSet.has('package_uploads')){
   check(tableSet.has('package_upload_chunks')&&tableSet.has('package_upload_entries'),'PACKAGE_UPLOAD_SCHEMA_INCOMPLETE');
   for(const upload of rows(db,'SELECT * FROM package_uploads')){
    check(projects.get(upload.project_id)?.user_id===upload.user_id&&/^upload_[a-f0-9]{32}$/.test(upload.id),'PACKAGE_UPLOAD_IDENTITY_INVALID');
    const prefix='private/template-uploads/'+encodeURIComponent(upload.user_id)+'/'+encodeURIComponent(upload.project_id)+'/'+upload.id,active=upload.cleanup_state==='pending'&&['uploading','processing'].includes(upload.state),chunks=rows(db,'SELECT * FROM package_upload_chunks WHERE upload_id=? ORDER BY chunk_index',upload.id);let received=0n;
    for(const item of chunks){
     check(/^[a-f0-9]{64}$/.test(item.sha256)&&safeKey(item.object_key)===prefix+'/chunks/'+item.chunk_index+'-'+item.sha256,'PACKAGE_CHUNK_IDENTITY_INVALID');
     check(item.byte_offset===item.chunk_index*1048576n&&item.byte_size===(upload.total_bytes-item.byte_offset<1048576n?upload.total_bytes-item.byte_offset:1048576n),'PACKAGE_CHUNK_SIZE_INVALID');
     if(item.state==='ready'){check(item.byte_offset===received&&typeof item.etag==='string'&&item.etag.length>0,'PACKAGE_CHUNK_SEQUENCE_INVALID');received+=item.byte_size;}
     else check(item.byte_offset===received,'PACKAGE_CHUNK_SEQUENCE_INVALID');
     if(active&&item.state==='ready'||objectMap.has(item.object_key))requireObject(item.object_key,item.sha256,item.byte_size);
    }
    check(received===upload.received_bytes&&received<=upload.total_bytes,'PACKAGE_UPLOAD_PROGRESS_INVALID');
    if(upload.state==='processing'||upload.state==='ready')check(received===upload.total_bytes,'PACKAGE_UPLOAD_PROGRESS_INVALID');
    for(const item of rows(db,'SELECT * FROM package_upload_entries WHERE upload_id=?',upload.id)){
     let expectedKey=prefix+'/manifest.json';
     if(item.media_id){check(/^media_[a-f0-9]{32}$/.test(item.media_id)&&/^assets\/\d{1,2}\.(jpg|jpeg|png|webp|gif|svg|pdf)$/.test(item.file_name),'PACKAGE_ENTRY_IDENTITY_INVALID');expectedKey='private/users/'+encodeURIComponent(upload.user_id)+'/projects/'+encodeURIComponent(upload.project_id)+'/'+item.media_id+'/original.'+item.file_name.split('.').at(-1).replace('jpeg','jpg');}
     else check(item.file_name==='manifest.json','PACKAGE_ENTRY_IDENTITY_INVALID');
     check(safeKey(item.object_key)===expectedKey,'PACKAGE_ENTRY_IDENTITY_INVALID');
     if(item.state==='verified')check(/^[a-f0-9]{64}$/.test(item.sha256)&&typeof item.etag==='string'&&item.etag.length>0,'PACKAGE_ENTRY_DIGEST_INVALID');
     if(active&&item.state==='verified'||objectMap.has(item.object_key))requireObject(item.object_key,item.sha256,item.byte_size);
     if(upload.state==='ready'&&item.media_id)check(media.some(m=>m.id===item.media_id&&m.user_id===upload.user_id&&m.project_id===upload.project_id&&m.object_key===item.object_key&&m.sha256===item.sha256&&m.byte_size===item.byte_size),'PACKAGE_PROMOTION_REFERENCE_INVALID');
    }
    if(upload.state==='ready')check(rows(db,'SELECT id FROM design_candidates WHERE id=? AND user_id=? AND project_id=?',upload.candidate_id,upload.user_id,upload.project_id).length===1,'PACKAGE_CANDIDATE_REFERENCE_INVALID');
   }
  }
  const inspectDesign=(text,projectId,expectedHash,requireMedia=true)=>{
   if(expectedHash!==undefined)check(sha(text)===expectedHash,'DESIGN_DIGEST_MISMATCH');let manifest;try{manifest=JSON.parse(text);}catch{throw new RecoveryError('DESIGN_MANIFEST_INVALID');}check(validateSiteManifest(manifest).valid,'DESIGN_MANIFEST_INVALID');
   const project=projects.get(projectId);check(project,'DESIGN_PROJECT_REFERENCE_INVALID');
   if(requireMedia)for(const asset of manifest.assets){const match=media.find(m=>m.project_id===projectId&&m.user_id===project.user_id&&m.state!=='staging'&&m.sha256===asset.sha256&&m.byte_size===BigInt(asset.size)&&(asset.file.toLowerCase().endsWith('.'+m.extension)||m.extension==='jpg'&&asset.file.toLowerCase().endsWith('.jpeg')));check(match,'DESIGN_MEDIA_REFERENCE_INVALID');requireObject(match.object_key,asset.sha256,asset.size);}
   return manifest;
  };
  const storedManifests=new Map();
  if(tableSet.has('design_manifest_objects')){
   for(const table of ['design_versions','design_candidates'])check(tableSet.has(table)&&rows(db,'PRAGMA table_info('+quote(table)+')').some(column=>column.name==='manifest_object_id'),'MANIFEST_SCHEMA_INCOMPLETE');
   const referenced=new Set(rows(db,'SELECT manifest_object_id FROM design_versions WHERE manifest_object_id IS NOT NULL UNION SELECT manifest_object_id FROM design_candidates WHERE manifest_object_id IS NOT NULL').map(item=>item.manifest_object_id));
   for(const item of rows(db,'SELECT * FROM design_manifest_objects')){
    const project=projects.get(item.project_id);check(project&&project.user_id===item.user_id,'MANIFEST_OWNERSHIP_INVALID');
    check(typeof item.sha256==='string'&&/^[a-f0-9]{64}$/.test(item.sha256)&&item.byte_size>1000000n&&item.byte_size<=10485760n,'MANIFEST_METADATA_INVALID');
    check(typeof item.id==='string'&&/^manifest_[a-f0-9]{32}$/.test(item.id),'MANIFEST_IDENTITY_INVALID');
    const expectedKey='private/users/'+encodeURIComponent(item.user_id)+'/projects/'+encodeURIComponent(item.project_id)+'/manifests/'+item.id+'/'+item.sha256+'.json';check(safeKey(item.object_key)===expectedKey,'MANIFEST_OBJECT_PATH_INVALID');
    check(['staging','ready','purging','purged'].includes(item.state),'MANIFEST_METADATA_INVALID');let index;try{index=JSON.parse(item.index_json);}catch{throw new RecoveryError('MANIFEST_INDEX_INVALID');}
    check(index?.format==='benos-manifest-ref'&&index.version===1&&index.objectId===item.id&&index.sha256===item.sha256&&index.byteSize===Number(item.byte_size)&&Array.isArray(index.assets)&&index.assets.length<=64,'MANIFEST_INDEX_INVALID');
    storedManifests.set(item.id,item);
    if(item.state==='ready'||objectMap.has(item.object_key)){
     requireObject(item.object_key,item.sha256,item.byte_size);const bytes=readFileSync(objectPath(objectMap.get(item.object_key)));check(bytes.length===Number(item.byte_size),'OBJECT_SIZE_MISMATCH');check(sha(bytes)===item.sha256,'OBJECT_DIGEST_MISMATCH');let text;try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{throw new RecoveryError('DESIGN_MANIFEST_INVALID');}
     const manifest=inspectDesign(text,item.project_id,item.sha256,referenced.has(item.id)),expected={format:'benos-manifest-ref',version:1,objectId:item.id,sha256:item.sha256,byteSize:Number(item.byte_size),assets:manifest.assets,summary:manifestSummary(manifest)};
     check(JSON.stringify(expected)===item.index_json,'MANIFEST_INDEX_MISMATCH');
    }
   }
  }
  const designDigest=item=>{
   if(item.manifest_object_id!==undefined&&item.manifest_object_id!==null){
    const stored=storedManifests.get(item.manifest_object_id);check(stored,'MANIFEST_REFERENCE_INVALID');check(stored.state==='ready','MANIFEST_NOT_READY');check(stored.project_id===item.project_id&&stored.user_id===projects.get(item.project_id)?.user_id&&(!item.user_id||item.user_id===stored.user_id)&&(!item.created_by||item.created_by===stored.user_id),'MANIFEST_OWNERSHIP_INVALID');check(item.manifest_json===stored.index_json,'MANIFEST_INDEX_MISMATCH');if(item.content_hash!==undefined)check(item.content_hash===stored.sha256,'DESIGN_DIGEST_MISMATCH');return stored.sha256;
   }
   inspectDesign(item.manifest_json,item.project_id,item.content_hash);return sha(item.manifest_json);
  };
  for(const item of rows(db,'SELECT * FROM design_versions'))designDigest(item);
  if(tableSet.has('design_candidates')){
   noRows(db,`SELECT 1 FROM design_candidates c JOIN projects p ON p.id=c.project_id WHERE c.user_id<>p.user_id
     OR (c.base_version_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM design_versions v WHERE v.id=c.base_version_id AND v.project_id=c.project_id))
     OR (c.adopted_version_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM design_versions v WHERE v.id=c.adopted_version_id AND v.project_id=c.project_id))
     OR (c.state='adopted')<>(c.adopted_version_id IS NOT NULL) LIMIT 1`,'CANDIDATE_REFERENCE_INVALID');
   for(const item of rows(db,'SELECT * FROM design_candidates')){
    const digest=designDigest(item);
    if(item.adopted_version_id){const version=rows(db,'SELECT content_hash,parent_id FROM design_versions WHERE id=?',item.adopted_version_id)[0];check(version.content_hash===digest&&version.parent_id===item.base_version_id,'CANDIDATE_ADOPTION_MISMATCH');}
   }
  }

  // Derived editor caches and durable restore receipts do not introduce R2 keys.
  const versions=new Map(rows(db,'SELECT * FROM design_versions').map(item=>[item.id,item]));
  const sourceVersion=(id,project)=>{const item=versions.get(id);check(item&&item.project_id===project,'EDIT_SOURCE_REFERENCE_INVALID');return item;};
  const sourceText=item=>item.manifest_object_id?readFileSync(objectPath(objectMap.get(storedManifests.get(item.manifest_object_id).object_key)),'utf8'):item.manifest_json;
  const objectText=item=>{requireObject(item.object_key,item.sha256,item.byte_size);try{return new TextDecoder('utf-8',{fatal:true}).decode(readFileSync(objectPath(objectMap.get(item.object_key))));}catch{throw new RecoveryError('EDIT_OBJECT_ENCODING_INVALID');}};
  const jsonValue=(text,code)=>{try{return JSON.parse(text);}catch{throw new RecoveryError(code);}};
  if(tableSet.has('design_editor_projections'))for(const item of rows(db,'SELECT * FROM design_editor_projections')){
   check(projects.get(item.project_id)?.user_id===item.user_id&&item.projection_version===1n,'EDITOR_PROJECTION_IDENTITY_INVALID');
   const source=item.source_kind==='version'?versions.get(item.version_id):rows(db,'SELECT * FROM design_candidates WHERE id=?',item.candidate_id)[0];
   check(source&&source.project_id===item.project_id&&source.id===item.source_id&&designDigest(source)===item.source_hash,'EDITOR_PROJECTION_SOURCE_INVALID');
   const text=sourceText(source);check(BigInt(Buffer.byteLength(text))===item.source_bytes&&sha(item.projection_json)===item.projection_hash,'EDITOR_PROJECTION_DIGEST_INVALID');
   const projection=jsonValue(item.projection_json,'EDITOR_PROJECTION_JSON_INVALID');check(projection.site&&Array.isArray(projection.templates)&&Array.isArray(projection.assets)&&Array.isArray(projection.pageOptions),'EDITOR_PROJECTION_JSON_INVALID');
  }
  if(tableSet.has('design_restore_requests'))for(const item of rows(db,'SELECT * FROM design_restore_requests')){
   const source=sourceVersion(item.source_version_id,item.project_id),result=sourceVersion(item.result_version_id,item.project_id);
   if(item.expected_current_version_id)sourceVersion(item.expected_current_version_id,item.project_id);
   check(projects.get(item.project_id)?.user_id===item.user_id&&source.content_hash===item.source_hash&&result.content_hash===item.source_hash&&result.created_by===item.user_id&&result.parent_id===item.expected_current_version_id&&item.request_hash===sha(JSON.stringify([item.project_id,item.source_version_id,item.expected_current_version_id])),'EDITOR_RESTORE_REFERENCE_INVALID');
  }
  if(tableSet.has('design_edit_workspaces')){
   for(const required of ['design_edit_objects','design_edit_files','design_edit_operations','design_edit_media_refs'])check(tableSet.has(required),'EDIT_WORKSPACE_SCHEMA_INCOMPLETE');
   const workspaces=new Map(rows(db,'SELECT * FROM design_edit_workspaces').map(item=>[item.id,item])),editObjects=new Map(rows(db,'SELECT * FROM design_edit_objects').map(item=>[item.id,item]));
   for(const item of editObjects.values()){
    const w=workspaces.get(item.workspace_id);check(w&&/^editobj_[a-f0-9]{32}$/.test(item.id),'EDIT_OBJECT_IDENTITY_INVALID');
    check(safeKey(item.object_key)==='private/users/'+encodeURIComponent(w.user_id)+'/projects/'+encodeURIComponent(w.project_id)+'/edit-workspaces/'+w.id+'/objects/'+item.id+'/'+item.sha256,'EDIT_OBJECT_IDENTITY_INVALID');
    const required=item.state==='ready'&&(['preparing','ready'].includes(w.state)||['response','tool'].includes(item.kind));
    if(required||objectMap.has(item.object_key))objectText(item);
    if(['response','tool'].includes(item.kind))check(!['purging','purged'].includes(item.state),'EDIT_RECEIPT_PURGED');
   }
   const member=(id,w,kind,required=false)=>{const item=editObjects.get(id);check(item&&item.workspace_id===w.id&&item.kind===kind,'EDIT_OBJECT_REFERENCE_INVALID');if(required){check(item.state==='ready','EDIT_OBJECT_NOT_READY');requireObject(item.object_key,item.sha256,item.byte_size);}return item;};
   for(const w of workspaces.values()){
    check(/^edit_[a-f0-9]{32}$/.test(w.id)&&projects.get(w.project_id)?.user_id===w.user_id,'EDIT_WORKSPACE_IDENTITY_INVALID');const source=sourceVersion(w.base_version_id,w.project_id);check(source.content_hash===w.source_hash,'EDIT_SOURCE_DIGEST_INVALID');
    const active=['preparing','ready'].includes(w.state),complete=w.state==='ready'||w.state==='completed',base=jsonValue(sourceText(source),'EDIT_BLUEPRINT_INVALID'),scope=jsonValue(w.scope_json,'EDIT_SCOPE_INVALID'),expectedFiles=new Map();
    check(scope?.kind==='site'||scope?.kind==='node'&&Number.isSafeInteger(scope.templateId)&&/^n\d{1,9}$/.test(scope.nodeKey),'EDIT_SCOPE_INVALID');
    for(const template of base.templates)for(const field of ['html','css','customCss'])if(typeof template.document[field]==='string'){
     const path='templates/'+template.id+'.'+(field==='customCss'?'custom.css':field);expectedFiles.set(path,{templateId:BigInt(template.id),field,sha:sha(template.document[field]),size:BigInt(Buffer.byteLength(template.document[field]))});template.document[field]='';
    }
    if(typeof base.site.theme?.global_css==='string'){expectedFiles.set('site/global.css',{templateId:null,field:'global_css',sha:sha(base.site.theme.global_css),size:BigInt(Buffer.byteLength(base.site.theme.global_css))});base.site.theme.global_css='';}
    const files=rows(db,'SELECT * FROM design_edit_files WHERE workspace_id=?',w.id),selection=w.selection_json?jsonValue(w.selection_json,'EDIT_SCOPE_INVALID'):null;
    if(complete)check(files.length===expectedFiles.size&&w.blueprint_object_id,'EDIT_WORKSPACE_INCOMPLETE');
    if(scope.kind==='node'&&complete)check(selection&&selection.path==='templates/'+scope.templateId+'.html'&&Number.isSafeInteger(selection.start)&&Number.isSafeInteger(selection.end)&&selection.start>=0&&selection.end>=selection.start,'EDIT_SCOPE_INVALID');
    if(w.blueprint_object_id){const blueprint=member(w.blueprint_object_id,w,'blueprint',active);check(blueprint.logical_key==='blueprint'&&blueprint.sha256===sha(JSON.stringify(base)),'EDIT_BLUEPRINT_MISMATCH');}
    for(const file of files){const expected=expectedFiles.get(file.path);check(expected&&file.template_id===expected.templateId&&file.field===expected.field,'EDIT_FILE_IDENTITY_INVALID');const original=member(file.base_object_id,w,'file',active),current=member(file.current_object_id,w,'file',active);
     check(original.logical_key==='base:'+file.path&&original.sha256===expected.sha&&original.byte_size===expected.size&&current.sha256===file.sha256&&current.byte_size===file.byte_size,'EDIT_FILE_DIGEST_INVALID');
     const writable=scope.kind==='node'?file.path===selection?.path:file.field!=='customCss';check(file.writable===(writable?1n:0n)&&(!writable?current.sha256===original.sha256:true),'EDIT_FILE_SCOPE_INVALID');
     if(selection?.path===file.path)check(BigInt(selection.end)<=file.byte_size,'EDIT_SCOPE_INVALID');
    }
    const refs=rows(db,'SELECT * FROM design_edit_media_refs WHERE workspace_id=?',w.id),assets=jsonValue(w.assets_json,'EDIT_ASSETS_INVALID');check(Array.isArray(assets)&&assets.length<=64,'EDIT_ASSETS_INVALID');
    for(const ref of refs)check(media.some(m=>m.id===ref.media_id&&m.user_id===w.user_id&&m.project_id===w.project_id&&m.sha256===ref.sha256&&m.byte_size===ref.byte_size&&(!active||m.state==='ready')),'EDIT_MEDIA_REFERENCE_INVALID');
    if(w.state==='ready')for(const asset of assets)check(refs.some(ref=>ref.sha256===asset.sha256&&ref.byte_size===BigInt(asset.size)),'EDIT_MEDIA_REFERENCE_INVALID');
    if(w.candidate_id){const candidate=rows(db,'SELECT * FROM design_candidates WHERE id=?',w.candidate_id)[0];check(candidate&&candidate.user_id===w.user_id&&candidate.project_id===w.project_id&&candidate.base_version_id===w.base_version_id,'EDIT_CANDIDATE_REFERENCE_INVALID');}
    if(w.validated_revision!==null)check(w.validated_revision<=w.revision,'EDIT_REVISION_INVALID');
    for(const op of rows(db,'SELECT * FROM design_edit_operations WHERE workspace_id=?',w.id)){const result=jsonValue(op.result_json,'EDIT_OPERATION_INVALID');check(op.result_revision===op.expected_revision+1n&&op.result_revision<=w.revision&&result.revision===Number(op.result_revision),'EDIT_OPERATION_INVALID');}
   }
   if(tableSet.has('ai_workflows'))for(const workflow of rows(db,'SELECT * FROM ai_workflows WHERE workspace_id IS NOT NULL')){
    const w=workspaces.get(workflow.workspace_id);check(w&&w.user_id===workflow.user_id&&w.project_id===workflow.project_id&&w.base_version_id===workflow.base_version_id,'EDIT_WORKFLOW_REFERENCE_INVALID');
    for(const step of rows(db,'SELECT * FROM ai_workflow_steps WHERE workflow_id=?',workflow.id)){
     const reservation=rows(db,'SELECT * FROM api_reservations WHERE id=?',step.reservation_id)[0];if(reservation)check(reservation.user_id===w.user_id&&reservation.provider_id===workflow.provider_id&&reservation.amount_micros===workflow.per_step_micros,'EDIT_WORKFLOW_RESERVATION_INVALID');
     if(step.state==='completed')check(step.response_object_id&&step.tool_object_id&&reservation?.state==='settled','EDIT_WORKFLOW_RECEIPT_MISSING');let response=null,tool=null;
     for(const [field,kind] of [['response_object_id','response'],['tool_object_id','tool']])if(step[field]){const item=member(step[field],w,kind,true);check(item.logical_key===kind+':'+step.id,'EDIT_WORKFLOW_RECEIPT_IDENTITY');const value=jsonValue(objectText(item),'EDIT_WORKFLOW_RECEIPT_JSON');if(kind==='response')response=value;else tool=value;}
     if(response&&step.response_json){const summary=jsonValue(step.response_json,'EDIT_WORKFLOW_RECEIPT_JSON');for(const key of ['id','model','status','usage'])if(Object.hasOwn(summary,key))check(canonical(summary[key])===canonical(response[key]),'EDIT_WORKFLOW_RECEIPT_MISMATCH');}
     if(step.state==='completed'){const calls=response?.output?.filter(o=>o.type==='function_call');check(Array.isArray(calls)&&calls.length===1&&Array.isArray(tool)&&tool.length===1&&tool[0].callId===calls[0].call_id&&tool[0].name===calls[0].name,'EDIT_WORKFLOW_CALL_MISMATCH');}
    }
   }
  }
  if(tableSet.has('manifest_edits')){
   for(const required of ['manifest_edit_objects','manifest_edit_chunks','manifest_edit_segments','manifest_edit_operations'])check(tableSet.has(required),'MANIFEST_EDIT_SCHEMA_INCOMPLETE');
   for(const edit of rows(db,'SELECT * FROM manifest_edits')){
    check(/^medit_[a-f0-9]{32}$/.test(edit.id)&&projects.get(edit.project_id)?.user_id===edit.user_id,'MANIFEST_EDIT_IDENTITY_INVALID');
    if(edit.base_version_id)sourceVersion(edit.base_version_id,edit.project_id);
    if(edit.source_version_id){const source=sourceVersion(edit.source_version_id,edit.project_id);check(source.content_hash===edit.source_hash&&BigInt(Buffer.byteLength(sourceText(source)))===edit.input_bytes&&edit.mode==='source','MANIFEST_EDIT_SOURCE_INVALID');}
    const active=edit.cleanup_state==='pending'&&['uploading','preparing','editing','committing'].includes(edit.state),objects=new Map(rows(db,'SELECT * FROM manifest_edit_objects WHERE edit_id=?',edit.id).map(o=>[o.id,o]));
    for(const item of objects.values()){
     check(/^editobj_[a-f0-9]{32}$/.test(item.id)&&safeKey(item.object_key)==='private/users/'+encodeURIComponent(edit.user_id)+'/projects/'+encodeURIComponent(edit.project_id)+'/manifest-edits/'+edit.id+'/objects/'+item.id+'/'+item.sha256,'MANIFEST_EDIT_OBJECT_IDENTITY_INVALID');
     if(item.state==='ready')check(typeof item.etag==='string'&&item.etag.length>0,'MANIFEST_EDIT_ETAG_MISSING');
     if(active&&item.state==='ready'||objectMap.has(item.object_key))requireObject(item.object_key,item.sha256,item.byte_size);
    }
    const linked=id=>{const item=objects.get(id);check(item,'MANIFEST_EDIT_OBJECT_REFERENCE_INVALID');return item;};
    const chunks=rows(db,'SELECT * FROM manifest_edit_chunks WHERE edit_id=? ORDER BY chunk_index',edit.id);let confirmed=0n;
    if(edit.mode==='source')check(chunks.length===0&&edit.received_bytes===edit.input_bytes,'MANIFEST_EDIT_UPLOAD_PROGRESS_INVALID');
    for(let n=0;n<chunks.length;n++){const chunk=chunks[n],item=linked(chunk.object_id),offset=BigInt(n)*1048576n,size=edit.input_bytes-offset<1048576n?edit.input_bytes-offset:1048576n;check(edit.mode==='upload'&&chunk.chunk_index===BigInt(n)&&chunk.byte_offset===offset&&size>0n&&item.byte_size===size,'MANIFEST_EDIT_CHUNK_INVALID');if(offset<edit.received_bytes){check(item.state==='ready'&&offset+size<=edit.received_bytes,'MANIFEST_EDIT_UPLOAD_PROGRESS_INVALID');confirmed+=size;}else check(offset===edit.received_bytes&&n===chunks.length-1,'MANIFEST_EDIT_UPLOAD_PROGRESS_INVALID');}
    if(edit.mode==='upload')check(confirmed===edit.received_bytes,'MANIFEST_EDIT_UPLOAD_PROGRESS_INVALID');
    const segments=rows(db,'SELECT * FROM manifest_edit_segments WHERE edit_id=? ORDER BY segment_index',edit.id);let segmentBytes=0n;
    for(let n=0;n<segments.length;n++){const segment=segments[n],item=linked(segment.object_id);check(segment.segment_index===BigInt(n)&&item.byte_size<=131072n,'MANIFEST_EDIT_SEGMENT_INVALID');if(BigInt(n)<edit.segment_count){check(item.state==='ready','MANIFEST_EDIT_SEGMENT_INVALID');segmentBytes+=item.byte_size;}else check(segments.length<=Number(edit.segment_count)+4&&edit.state!=='editing'&&edit.state!=='committing'&&edit.state!=='saved','MANIFEST_EDIT_SEGMENT_INVALID');}
    check(segments.length>=Number(edit.segment_count),'MANIFEST_EDIT_SEGMENT_INVALID');
    if(['editing','committing','saved'].includes(edit.state))check(segments.length===Number(edit.segment_count)&&segmentBytes===edit.total_bytes&&edit.split_offset===edit.input_bytes&&edit.received_bytes===edit.input_bytes,'MANIFEST_EDIT_PROGRESS_INVALID');
    else if(edit.revision===0n)check(segmentBytes===edit.split_offset,'MANIFEST_EDIT_PROGRESS_INVALID');
    if(edit.result_version_id){const result=sourceVersion(edit.result_version_id,edit.project_id);check(result.created_by===edit.user_id&&result.parent_id===edit.base_version_id&&edit.state==='saved','MANIFEST_EDIT_RESULT_INVALID');}
    for(const op of rows(db,'SELECT * FROM manifest_edit_operations WHERE edit_id=?',edit.id)){
     check(op.expected_revision<=edit.revision,'MANIFEST_EDIT_OPERATION_INVALID');if(op.object_id){const item=linked(op.object_id);check(op.kind==='patch'&&op.segment_index>=0n&&op.segment_index<edit.segment_count,'MANIFEST_EDIT_OPERATION_INVALID');if(op.state==='succeeded')check(item.state==='ready'&&op.result_revision===op.expected_revision+1n&&op.result_revision<=edit.revision,'MANIFEST_EDIT_OPERATION_INVALID');}
     if(op.kind==='commit'&&op.state==='succeeded')check(op.result_version_id===edit.result_version_id&&op.result_revision===op.expected_revision,'MANIFEST_EDIT_RESULT_INVALID');
    }
   }
  }

  if(tableSet.has('native_preview_jobs')){
   check(tableSet.has('native_preview_artifacts')&&tableSet.has('native_preview_chunks'),'NATIVE_PREVIEW_SCHEMA_INCOMPLETE');
   for(const job of rows(db,'SELECT * FROM native_preview_jobs')){
    check(/^preview_[a-f0-9]{32}$/.test(job.id)&&projects.get(job.project_id)?.user_id===job.user_id,'NATIVE_PREVIEW_IDENTITY_INVALID');
    check(rows(db,'SELECT 1 FROM sites WHERE id=? AND user_id=? AND project_id=?',job.site_id,job.user_id,job.project_id).length===1,'NATIVE_PREVIEW_SITE_INVALID');
    const source=rows(db,job.version_id?'SELECT * FROM design_versions WHERE id=? AND project_id=?':'SELECT * FROM design_candidates WHERE id=? AND project_id=? AND user_id=?',...(job.version_id?[job.version_id,job.project_id]:[job.candidate_id,job.project_id,job.user_id]))[0];
    check(source,'NATIVE_PREVIEW_SOURCE_INVALID');
    let snapshot,sources,metadata,render;try{snapshot=JSON.parse(job.source_json);sources=JSON.parse(job.sources_json);metadata=JSON.parse(job.bundle_metadata_json);render=job.render_json?JSON.parse(job.render_json):null;}catch{throw new RecoveryError('NATIVE_PREVIEW_METADATA_INVALID');}
    check(snapshot.manifest_object_id===(source.manifest_object_id??null)&&snapshot.content_hash===designDigest(source)&&Array.isArray(sources)&&sources.length>=1&&sources.length<=65,'NATIVE_PREVIEW_SOURCE_INVALID');
    check(metadata.bundleId===job.bundle_id&&metadata.purpose==='preview'&&metadata.projectId===job.project_id&&metadata.versionId===(job.version_id??job.candidate_id)&&BigInt(metadata.expiresAt)*1000n===job.deadline_ms,'NATIVE_PREVIEW_METADATA_INVALID');
    const expected=[metadata.manifest,...metadata.assets],seen=new Set();check(expected.length===sources.length,'NATIVE_PREVIEW_SOURCE_INVALID');
    for(let i=0;i<sources.length;i++){
     const item=sources[i];check(item&&item.file===expected[i].file&&item.size===expected[i].size&&item.sha256===expected[i].sha256&&/^[a-f0-9]{64}$/.test(item.sha256)&&Number.isSafeInteger(item.size)&&item.size>0&&!seen.has(item.file),'NATIVE_PREVIEW_SOURCE_INVALID');seen.add(item.file);
     if(i===0)check(item.file==='manifest.json'&&item.sha256===snapshot.content_hash,'NATIVE_PREVIEW_SOURCE_INVALID');
     else check(media.some(m=>m.id===item.mediaId&&m.user_id===job.user_id&&m.project_id===job.project_id&&m.sha256===item.sha256&&m.byte_size===BigInt(item.size)&&m.mime_type===item.mime),'NATIVE_PREVIEW_SOURCE_INVALID');
    }
    if(render)check(render.previewId===job.id&&render.bundleId===job.bundle_id&&render.projectId===job.project_id&&render.siteId===job.site_id&&render.versionId===(job.version_id??job.candidate_id)&&render.pageKey===job.page_key&&render.manifestSha256===snapshot.content_hash&&Array.isArray(render.assets)&&render.assets.length===sources.length-1,'NATIVE_PREVIEW_RENDER_INVALID');
    const prefix='private/native-preview-jobs/'+encodeURIComponent(job.user_id)+'/'+encodeURIComponent(job.project_id)+'/'+job.id,active=job.cleanup_state==='pending'&&['processing','ready'].includes(job.state),artifacts=rows(db,'SELECT * FROM native_preview_artifacts WHERE job_id=?',job.id);
    if(job.state==='ready')check(artifacts.some(a=>a.file==='preview.html')&&artifacts.every(a=>a.state==='ready'),'NATIVE_PREVIEW_READY_INVALID');
    for(const artifact of artifacts){
     const expected=artifact.file==='preview.html'?render?.html:render?.assets?.find(a=>a.file===artifact.file&&a.mode==='sanitized');
     check(expected&&expected.sha256===artifact.sha256&&BigInt(expected.size)===artifact.byte_size&&(artifact.file==='preview.html'?artifact.mime_type==='text/html':expected.mime===artifact.mime_type)&&safeKey(artifact.object_key)===prefix+'/ready/'+artifact.file,'NATIVE_PREVIEW_ARTIFACT_INVALID');
     const chunks=rows(db,'SELECT * FROM native_preview_chunks WHERE job_id=? AND file=? ORDER BY chunk_index',job.id,artifact.file);let received=0n;
     for(let i=0;i<chunks.length;i++){
      const chunk=chunks[i],offset=BigInt(i)*1048576n,remaining=artifact.byte_size-offset;check(chunk.chunk_index===BigInt(i)&&remaining>0n&&chunk.byte_size===(remaining<1048576n?remaining:1048576n)&&/^[a-f0-9]{64}$/.test(chunk.sha256)&&safeKey(chunk.object_key)===prefix+'/chunks/'+artifact.file+'/'+i,'NATIVE_PREVIEW_CHUNK_INVALID');
      if(chunk.state==='ready'){check(typeof chunk.etag==='string'&&chunk.etag.length>0&&received===offset,'NATIVE_PREVIEW_PROGRESS_INVALID');received+=chunk.byte_size;}else check(i===chunks.length-1&&received===offset,'NATIVE_PREVIEW_PROGRESS_INVALID');
      if(active&&chunk.state==='ready'&&chunk.purged_at===null||objectMap.has(chunk.object_key))requireObject(chunk.object_key,chunk.sha256,chunk.byte_size);
      if(chunk.purged_at!==null)check(artifact.state==='ready','NATIVE_PREVIEW_PROGRESS_INVALID');
     }
     check(received===artifact.received_bytes&&(artifact.state!=='ready'||received===artifact.byte_size&&typeof artifact.etag==='string'&&artifact.etag.length>0),'NATIVE_PREVIEW_PROGRESS_INVALID');
     if(active&&artifact.state==='ready'||objectMap.has(artifact.object_key))requireObject(artifact.object_key,artifact.sha256,artifact.byte_size);
    }
   }
  }
  for(const item of rows(db,'SELECT * FROM image_jobs')){if(item.response_object_key)requireObject(item.response_object_key,item.response_sha256);else if(item.response_sha256)requireObject('private/image-jobs/'+encodeURIComponent(item.user_id)+'/'+item.id+'/response.json',item.response_sha256);}
  const contexts={integration_configs:['secret_ciphertext','id',''],site_connections:['secret_ciphertext','site_id',''],provisioning_jobs:['secret_ciphertext','id',''],hosting_provider_intents:['database_secret_ciphertext','job_id','hosting-database:'],hosting_bootstrap_intents:['secret_ciphertext','job_id','bootstrap:'],email_outbox:['payload_ciphertext','id',''],service_notification_outbox:['payload_ciphertext','id','']};let encryptedValues=0;
  for(const table of tables){const cipherColumns=rows(db,'PRAGMA table_info('+quote(table)+')').map(item=>item.name).filter(name=>name.endsWith('_ciphertext'));for(const column of cipherColumns){const context=contexts[table];check(context&&context[0]===column,'UNKNOWN_CIPHERTEXT_CONTEXT');for(const item of rows(db,'SELECT '+quote(column)+' AS ciphertext,'+quote(context[1])+' AS identity FROM '+quote(table)+' WHERE '+quote(column)+' IS NOT NULL')){decrypt(item.ciphertext,key,context[2]+item.identity);encryptedValues++;}}}
  for(const item of rows(db,"SELECT public_config_json FROM integration_configs WHERE kind='hosting'")){let config;try{config=JSON.parse(item.public_config_json);}catch{throw new RecoveryError('CONFIG_JSON_INVALID');}if(config.cmsReleaseObjectKey)requireObject(config.cmsReleaseObjectKey,config.cmsReleaseSha256,config.cmsReleaseSize);}
  const inventory=[];for(const table of tables){const columns=rows(db,'PRAGMA table_info('+quote(table)+')');const primary=columns.filter(c=>c.pk>0n).sort((a,b)=>Number(a.pk-b.pk));const order=(primary.length?primary:columns).map(c=>quote(c.name)).join(',');const statement=db.prepare('SELECT * FROM '+quote(table)+(order?' ORDER BY '+order:''));statement.setReadBigInts(true);const digest=createHash('sha256');let count=0;for(const row of statement.iterate()){digest.update(canonical(row)+'\n');count++;}inventory.push({name:table,rows:count,sha256:digest.digest('hex')});}
  return {schemaSha256:sha(canonical(schema)),tables:inventory,encryptedValues,unresolvedReservations:Number(scalar(db,"SELECT COUNT(*) count FROM api_reservations WHERE state IN ('reserved','dispatching','uncertain')").count),unresolvedOperations:tableSet.has('integration_function_tests')?Number(scalar(db,"SELECT COUNT(*) count FROM integration_function_tests WHERE accounting_state='held'").count):0,readyMedia:media.filter(m=>m.state==='ready').length,designVersions:Number(scalar(db,'SELECT COUNT(*) count FROM design_versions').count)};
 }finally{db.close();}
}
function metadataFor(key,hash){return {httpMetadata:{contentType:key.endsWith('.zip')?'application/zip':key.endsWith('.json')?'application/json':key.endsWith('.png')?'image/png':key.endsWith('.webp')?'image/webp':key.endsWith('.jpg')?'image/jpeg':key.endsWith('.gif')?'image/gif':key.endsWith('.svg')?'image/svg+xml':key.endsWith('.pdf')?'application/pdf':'application/octet-stream',cacheControl:'private, no-store'},customMetadata:{sha256:hash}};}
function writeNew(path,bytes){writeFileSync(path,bytes,{flag:'wx',mode:0o600});}
function copyTreeExclusive(source,target){mkdirSync(target,{mode:0o700});for(const {key,path} of walk(source)){const destination=join(target,...key.split('/'));mkdirSync(dirname(destination),{recursive:true,mode:0o700});copyFileSync(path,destination,constants.COPYFILE_EXCL);}}
export async function createBackup({database,objects,output,metadata,quiesced=false}){
 check(quiesced===true,'QUIESCENCE_CONFIRMATION_REQUIRED');regular(database);check(!lstatSync(objects).isSymbolicLink(),'SYMLINK_DENIED');const key=masterKey(),source=realpathSync(database),objectRoot=realpathSync(objects),target=newTarget(output,[objectRoot]);let suppliedMetadata=null;
 if(metadata){regular(metadata);check(statSync(metadata).size<=32*1048576,'METADATA_TOO_LARGE');try{suppliedMetadata=JSON.parse(readFileSync(metadata,'utf8'));check(suppliedMetadata&&typeof suppliedMetadata==='object'&&!Array.isArray(suppliedMetadata),'METADATA_INVALID');}catch{throw new RecoveryError('METADATA_INVALID');}}
 const stage=temporary();try{
  const databasePath=join(stage.path,'database.sqlite'),sourceSha256=await normalizeDatabase(source,databasePath);mkdirSync(join(stage.path,'objects'));const inventory=[];
  const sourceFiles=walk(objectRoot);if(suppliedMetadata)check(Object.keys(suppliedMetadata).length===sourceFiles.length,'METADATA_INCOMPLETE');for(const item of sourceFiles){safeKey(item.key);const hash=hashFile(item.path),size=statSync(item.path).size,file='objects/'+hash+'.bin',destination=join(stage.path,...file.split('/'));if(!existsSync(destination))copyFileSync(item.path,destination,constants.COPYFILE_EXCL);check(hashFile(destination)===hash&&hashFile(item.path)===hash,'SOURCE_OBJECT_CHANGED');const meta=suppliedMetadata?suppliedMetadata[item.key]:metadataFor(item.key,hash);check(meta&&meta.httpMetadata&&meta.customMetadata&&typeof meta.httpMetadata==='object'&&typeof meta.customMetadata==='object'&&!Array.isArray(meta.httpMetadata)&&!Array.isArray(meta.customMetadata),'METADATA_INVALID');check(Object.values(meta.httpMetadata).every(v=>typeof v==='string')&&Object.values(meta.customMetadata).every(v=>typeof v==='string'),'METADATA_INVALID');check(!meta.customMetadata.sha256||meta.customMetadata.sha256===hash,'METADATA_DIGEST_MISMATCH');inventory.push({key:item.key,file,size,sha256:hash,httpMetadata:meta.httpMetadata,customMetadata:meta.customMetadata});}
  const audit=inspectDatabase(databasePath,inventory,key,item=>join(stage.path,...item.file.split('/')));check(hashFile(source)===sourceSha256,'SOURCE_CHANGED');const again=walk(objectRoot);check(again.length===sourceFiles.length&&again.every((item,index)=>item.key===sourceFiles[index].key&&hashFile(item.path)===inventory[index].sha256),'SOURCE_OBJECT_CHANGED');
  const payload={format:FORMAT,version:VERSION,id:randomUUID(),createdAt:new Date().toISOString(),recoveryModeRequired:true,metadataPolicy:suppliedMetadata?'preserved':'reconstructed-private-defaults',sourceSha256,database:{file:'database.sqlite',size:statSync(databasePath).size,sha256:hashFile(databasePath)},objects:inventory,audit};
  const manifest={...payload,signature:signature(payload,key)};writeNew(join(stage.path,'manifest.json'),JSON.stringify(manifest,null,2));copyTreeExclusive(stage.path,target);return {format:FORMAT,output:target,tables:audit.tables.length,objects:inventory.length,unresolvedReservations:audit.unresolvedReservations,unresolvedOperations:audit.unresolvedOperations};
 }finally{stage.close();}
}
export function verifyBackup({bundle}){
 check(!lstatSync(bundle).isSymbolicLink(),'SYMLINK_DENIED');const root=realpathSync(bundle),key=masterKey();regular(join(root,'manifest.json'));check(statSync(join(root,'manifest.json')).size<=32*1048576,'MANIFEST_TOO_LARGE');let manifest;try{manifest=JSON.parse(readFileSync(join(root,'manifest.json'),'utf8'));}catch{throw new RecoveryError('MANIFEST_INVALID');}
 const {signature:signed,...payload}=manifest;check(payload.format===FORMAT&&payload.version===VERSION&&payload.recoveryModeRequired===true&&Array.isArray(payload.objects)&&payload.objects.length<=100000,'MANIFEST_INVALID');const expected=signature(payload,key);check(typeof signed==='string'&&/^[a-f0-9]{64}$/.test(signed)&&timingSafeEqual(Buffer.from(signed,'hex'),Buffer.from(expected,'hex')),'MANIFEST_SIGNATURE_OR_KEY_INVALID');
 check(payload.database?.file==='database.sqlite','MANIFEST_INVALID');const files=new Set(['manifest.json','database.sqlite']),keys=new Set();for(const item of payload.objects){safeKey(item.key);check(!keys.has(item.key.toLowerCase())&&/^[a-f0-9]{64}$/.test(item.sha256)&&item.file==='objects/'+item.sha256+'.bin'&&Number.isSafeInteger(item.size)&&item.size>=0,'MANIFEST_INVALID');keys.add(item.key.toLowerCase());files.add(item.file);const path=join(root,...item.file.split('/'));check(existsSync(path),'OBJECT_MISSING');check(statSync(path).size===item.size&&hashFile(path)===item.sha256,'OBJECT_DIGEST_MISMATCH');}
 const actual=walk(root).map(item=>item.key);check(actual.length===files.size&&actual.every(file=>files.has(file)),'UNLISTED_BACKUP_FILE');const dbPath=join(root,'database.sqlite');check(statSync(dbPath).size===payload.database.size&&hashFile(dbPath)===payload.database.sha256,'DATABASE_DIGEST_MISMATCH');const audit=inspectDatabase(dbPath,payload.objects,key,item=>join(root,...item.file.split('/')));check(canonical(audit)===canonical(payload.audit),'AUDIT_MISMATCH');return {root,manifest:payload,audit};
}
function sqlValue(value){if(value===null)return 'NULL';if(typeof value==='bigint')return String(value);if(typeof value==='number'){check(Number.isFinite(value),'INVALID_NUMBER');return String(value);}if(value instanceof Uint8Array)return "X'"+Buffer.from(value).toString('hex')+"'";check(typeof value==='string','UNSUPPORTED_SQL_VALUE');return value.includes('\0')?"CAST(X'"+Buffer.from(value).toString('hex')+"' AS TEXT)":"'"+value.replaceAll("'","''")+"'";}
function exportSql(path,target){const db=readonly(path),fd=openSync(target,'wx',0o600);try{const write=value=>{const buffer=Buffer.from(value);let offset=0;while(offset<buffer.length)offset+=writeSync(fd,buffer,offset,buffer.length-offset);};write('PRAGMA defer_foreign_keys=ON;\n');const schema=rows(db,"SELECT type,name,sql FROM sqlite_schema WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' AND name<>'_cf_KV' ORDER BY CASE type WHEN 'table' THEN 0 ELSE 1 END,name");for(const item of schema.filter(s=>s.type==='table'))write(item.sql+';\n');for(const item of schema.filter(s=>s.type==='table')){const columns=rows(db,'PRAGMA table_info('+quote(item.name)+')').map(c=>c.name),stmt=db.prepare('SELECT * FROM '+quote(item.name));stmt.setReadBigInts(true);for(const row of stmt.iterate())write('INSERT INTO '+quote(item.name)+'('+columns.map(quote).join(',')+') VALUES('+columns.map(name=>sqlValue(row[name])).join(',')+');\n');}for(const item of schema.filter(s=>s.type!=='table'))write(item.sql+';\n');}finally{closeSync(fd);db.close();}}
export async function restoreBackup({bundle,output}){
 const verified=verifyBackup({bundle}),target=newTarget(output,[verified.root]),stage=temporary();try{
  copyFileSync(join(verified.root,'database.sqlite'),join(stage.path,'database.sqlite'),constants.COPYFILE_EXCL);mkdirSync(join(stage.path,'r2'));const metadata={};
  for(const item of verified.manifest.objects){const destination=join(stage.path,'r2',...item.key.split('/'));mkdirSync(dirname(destination),{recursive:true,mode:0o700});copyFileSync(join(verified.root,...item.file.split('/')),destination,constants.COPYFILE_EXCL);check(hashFile(destination)===item.sha256,'OBJECT_DIGEST_MISMATCH');metadata[item.key]={httpMetadata:item.httpMetadata,customMetadata:item.customMetadata};}
  const audit=inspectDatabase(join(stage.path,'database.sqlite'),verified.manifest.objects,masterKey(),item=>join(stage.path,'r2',...item.key.split('/')));check(canonical(audit)===canonical(verified.audit),'RESTORE_AUDIT_MISMATCH');exportSql(join(stage.path,'database.sqlite'),join(stage.path,'database.sql'));
  writeNew(join(stage.path,'r2-metadata.json'),JSON.stringify(metadata,null,2));writeNew(join(stage.path,'RECOVERY-MODE-REQUIRED.txt'),'RECOVERY_MODE=true\nKeep traffic, callbacks and scheduled tasks disabled. Reconcile external payments, provider charges, CMS operations and queued messages before any controlled cutover. This tool never changes live bindings.\n');
  writeNew(join(stage.path,'restore-report.json'),JSON.stringify({format:FORMAT,backupId:verified.manifest.id,restoredAt:new Date().toISOString(),verified:true,recoveryModeRequired:true,audit},null,2));copyTreeExclusive(stage.path,target);return {output:target,verified:true,recoveryModeRequired:true,tables:audit.tables.length,objects:verified.manifest.objects.length,unresolvedReservations:audit.unresolvedReservations,unresolvedOperations:audit.unresolvedOperations};
 }finally{stage.close();}
}

/** Rebind provider ETags only in a fresh offline copy after objects were uploaded
 * to a new private store. Content SHA256 is verified independently; ETag is not
 * derived from bytes and this command never queries a provider or live database. */
export async function rebindRestoredEtags({restored,etags,output}){
 check(!lstatSync(restored).isSymbolicLink(),'SYMLINK_DENIED');
 const root=realpathSync(restored),source=join(root,'database.sqlite'),objectRoot=join(root,'r2'),key=masterKey();regular(source);regular(etags);regular(join(root,'RECOVERY-MODE-REQUIRED.txt'));
 check(readFileSync(join(root,'RECOVERY-MODE-REQUIRED.txt'),'utf8').startsWith('RECOVERY_MODE=true'),'RECOVERY_MODE_REQUIRED');
 check(statSync(etags).size<=32*1048576,'ETAG_INVENTORY_TOO_LARGE');let inventory;try{inventory=JSON.parse(readFileSync(etags,'utf8'));}catch{throw new RecoveryError('ETAG_INVENTORY_INVALID');}
 check(inventory?.format==='benos-restored-etags'&&inventory.version===1&&Array.isArray(inventory.objects)&&inventory.objects.length<=100000,'ETAG_INVENTORY_INVALID');
 const targetEtags=new Map();for(const item of inventory.objects){safeKey(item.key);check(!targetEtags.has(item.key)&&/^[a-f0-9]{64}$/.test(item.sha256)&&Number.isSafeInteger(item.size)&&item.size>=0&&typeof item.etag==='string'&&item.etag.length>0&&item.etag.length<=200&&!/[\r\n\x00-\x1f\x7f]/.test(item.etag),'ETAG_INVENTORY_INVALID');targetEtags.set(item.key,item);}
 const objects=walk(objectRoot).map(item=>{safeKey(item.key);const digest=hashFile(item.path),size=statSync(item.path).size,entry=targetEtags.get(item.key);check(entry&&entry.sha256===digest&&entry.size===size,'ETAG_OBJECT_MISMATCH');return {key:item.key,sha256:digest,size,file:item.path};});check(objects.length===targetEtags.size,'ETAG_INVENTORY_INVALID');
 const before=inspectDatabase(source,objects,key,item=>item.file),target=newTarget(output,[root]),stage=temporary();
 const specs={manifest_edit_objects:'manifest_edit_object_identity',package_upload_chunks:'package_chunk_identity',package_upload_entries:'package_entry_identity',native_preview_artifacts:'native_preview_artifact_identity',native_preview_chunks:'native_preview_chunk_identity'};
 try{
  const copied=join(stage.path,'database.sqlite'),sourceDigest=await normalizeDatabase(source,copied),db=new DatabaseSync(copied,{allowExtension:false});db.enableDefensive(true);db.exec('PRAGMA foreign_keys=ON;PRAGMA trusted_schema=OFF;');let changed=0;
  const withoutEtags=()=>{const values=[];for(const table of before.tables){const columns=rows(db,'PRAGMA table_info('+quote(table.name)+')'),pk=columns.filter(c=>c.pk>0n).sort((a,b)=>Number(a.pk-b.pk)),order=(pk.length?pk:columns).map(c=>quote(c.name)).join(','),digest=createHash('sha256');for(const row of rows(db,'SELECT * FROM '+quote(table.name)+' ORDER BY '+order)){if(Object.hasOwn(specs,table.name))delete row.etag;digest.update(canonical(row)+'\n');}values.push([table.name,digest.digest('hex')]);}return canonical(values);};
  try{const protectedBefore=withoutEtags();db.exec('BEGIN IMMEDIATE');
   for(const [table,trigger] of Object.entries(specs)){
    if(!before.tables.some(t=>t.name===table))continue;const found=rows(db,"SELECT sql FROM sqlite_schema WHERE type='trigger' AND name=? AND tbl_name=?",trigger,table)[0];check(found?.sql,'ETAG_TRIGGER_MISSING');
    db.exec('DROP TRIGGER '+quote(trigger));
    for(const row of rows(db,'SELECT object_key,sha256,byte_size,etag FROM '+quote(table)+' WHERE etag IS NOT NULL')){const next=targetEtags.get(row.object_key);if(!next)continue;check(next.sha256===row.sha256&&BigInt(next.size)===row.byte_size,'ETAG_OBJECT_MISMATCH');if(next.etag===row.etag)continue;changed+=Number(db.prepare('UPDATE '+quote(table)+' SET etag=? WHERE object_key=? AND etag=?').run(next.etag,row.object_key,row.etag).changes);}
    db.exec(found.sql);
   }
   check(withoutEtags()===protectedBefore,'ETAG_UNEXPECTED_DATABASE_MUTATION');db.exec('COMMIT');
  }catch(error){if(db.isTransaction)db.exec('ROLLBACK');throw error;}finally{db.close();}
  const after=inspectDatabase(copied,objects,key,item=>item.file);check(after.schemaSha256===before.schemaSha256,'ETAG_SCHEMA_CHANGED');check(hashFile(source)===sourceDigest,'SOURCE_CHANGED');
  copyTreeExclusive(objectRoot,join(stage.path,'r2'));for(const item of objects){const path=join(stage.path,'r2',...item.key.split('/'));check(statSync(path).size===item.size&&hashFile(path)===item.sha256,'OBJECT_DIGEST_MISMATCH');}regular(join(root,'r2-metadata.json'));copyFileSync(join(root,'r2-metadata.json'),join(stage.path,'r2-metadata.json'),constants.COPYFILE_EXCL);exportSql(copied,join(stage.path,'database.sql'));
  writeNew(join(stage.path,'RECOVERY-MODE-REQUIRED.txt'),readFileSync(join(root,'RECOVERY-MODE-REQUIRED.txt')));writeNew(join(stage.path,'target-etags.json'),JSON.stringify(inventory,null,2));
  writeNew(join(stage.path,'restore-report.json'),JSON.stringify({format:FORMAT,reboundAt:new Date().toISOString(),verified:true,recoveryModeRequired:true,updatedEtagRows:changed,sourceDatabaseSha256:sourceDigest,etagInventorySha256:hashFile(etags),remoteProviderVerified:false,audit:after},null,2));copyTreeExclusive(stage.path,target);
  return {output:target,verified:true,recoveryModeRequired:true,updatedEtagRows:changed,remoteProviderVerified:false};
 }finally{stage.close();}
}

// Loaded late only as a built-in: no shell, dynamic SQL endpoint, or networking.
import { writeSync } from 'node:fs';
async function main(){
 const [command,...args]=process.argv.slice(2),options={};
 for(let i=0;i<args.length;i++){const key=args[i];check(['--database','--objects','--output','--bundle','--metadata','--quiesced','--restored','--etags'].includes(key)&&!Object.hasOwn(options,key.slice(2)),'ARGUMENT_INVALID');if(key==='--quiesced')options.quiesced=true;else{check(args[i+1]&&!args[i+1].startsWith('--'),'ARGUMENT_INVALID');options[key.slice(2)]=args[++i];}}
 let result;
 if(command==='backup'){check(options.database&&options.objects&&options.output,'ARGUMENT_INVALID');result=await createBackup(options);}
 else if(command==='verify'){check(options.bundle,'ARGUMENT_INVALID');const found=verifyBackup(options);result={verified:true,tables:found.audit.tables.length,objects:found.manifest.objects.length,unresolvedReservations:found.audit.unresolvedReservations,unresolvedOperations:found.audit.unresolvedOperations};}
 else if(command==='restore'){check(options.bundle&&options.output,'ARGUMENT_INVALID');result=await restoreBackup(options);}
 else if(command==='rebind-etags'){check(options.restored&&options.etags&&options.output,'ARGUMENT_INVALID');result=await rebindRestoredEtags(options);}
 else throw new RecoveryError('USAGE: backup --database PATH --objects DIRECTORY [--metadata JSON] --output NEW_DIRECTORY --quiesced | verify --bundle DIRECTORY | restore --bundle DIRECTORY --output NEW_DIRECTORY | rebind-etags --restored DIRECTORY --etags JSON --output NEW_DIRECTORY');
 console.log(JSON.stringify({ok:true,...result}));
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)main().catch(error=>{console.error(JSON.stringify({ok:false,error:error instanceof RecoveryError?error.code:'RECOVERY_FAILED'}));process.exitCode=1;});
