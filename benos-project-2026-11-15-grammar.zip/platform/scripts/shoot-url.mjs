// Local preview only: signs in with the preview test account, screenshots any same-origin page
// in viewport-sized parts and prints a structural outline of it.
//   node scripts/shoot-url.mjs <path-or-"templates"> <name> [width] [maxParts]
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { signedInContext } from './preview-session.mjs';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.BENOS_TEST_PLAYWRIGHT || 'C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const [target, name, widthArg = '1680', partsArg = '8'] = process.argv.slice(2), width = Number(widthArg), maxParts = Number(partsArg);
const out = resolve(process.cwd(), '../artifacts/design-sample-20261115/compare'); mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.BENOS_TEST_BROWSER || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
const page = await (await signedInContext(browser, { viewport: { width, height: 900 } })).newPage();
await page.goto('http://127.0.0.1:4242/app/'); await page.waitForLoadState('domcontentloaded');
if (target === 'templates') {
  const data = await page.evaluate(async () => (await fetch('/api/design/templates', { credentials: 'include' })).json());
  console.log(JSON.stringify(data).slice(0, 1500)); await browser.close(); process.exit(0);
}
await page.goto('http://127.0.0.1:4242' + target);
await page.waitForLoadState('networkidle');
const info = await page.evaluate(() => {
  const text = el => (el.textContent || '').replace(/\s+/g, ' ').trim();
  // The page body is everything between the header and footer; a "section" is a direct block of real height.
  const candidates = [...document.querySelectorAll('main > *, body > section, body > div > section, .aacms-page > *, body > main > section, section')].filter(el => el.getBoundingClientRect().height > 120);
  const top = candidates.filter(el => !candidates.some(other => other !== el && other.contains(el)));
  const styles = [...document.querySelectorAll('style')].map(s => s.textContent || '').join('');
  const fonts = new Set(), sizes = new Set(), radii = new Set();
  for (const el of document.querySelectorAll('h1,h2,h3,p,a,li,span,button')) { const cs = getComputedStyle(el); if (!text(el)) continue; fonts.add(cs.fontFamily.split(',')[0].replace(/"/g, '').trim()); sizes.add(Math.round(parseFloat(cs.fontSize))); }
  for (const el of document.querySelectorAll('div,article,a,img,figure,section')) { const r = parseFloat(getComputedStyle(el).borderTopLeftRadius); if (r > 0) radii.add(Math.round(r)); }
  return { scrollWidth: document.documentElement.scrollWidth, height: document.documentElement.scrollHeight, cssBytes: styles.length, domNodes: document.querySelectorAll('*').length,
    images: document.images.length, links: document.querySelectorAll('a[href]').length, words: text(document.body).length,
    fonts: [...fonts].slice(0, 6), sizes: [...sizes].sort((a, b) => a - b), radii: [...radii].sort((a, b) => a - b).slice(0, 12),
    sections: top.map(el => { const r = el.getBoundingClientRect(), cs = getComputedStyle(el); return { tag: el.tagName.toLowerCase(), cls: (el.className || '').toString().slice(0, 70), h: Math.round(r.height), w: Math.round(r.width), bg: cs.backgroundColor,
      imgs: el.querySelectorAll('img').length, heads: [...el.querySelectorAll('h1,h2')].map(h => text(h).slice(0, 60)).slice(0, 2), h3: el.querySelectorAll('h3').length, links: el.querySelectorAll('a[href]').length, chars: text(el).length,
      grids: [...el.querySelectorAll('*')].filter(n => /grid|flex/.test(getComputedStyle(n).display) && n.children.length >= 2).length }; }) };
});
writeFileSync(resolve(out, `${name}-${width}.json`), JSON.stringify(info, null, 1));
console.log(JSON.stringify({ ...info, sections: info.sections.length }));
for (const s of info.sections) console.log(`  ${String(s.h).padStart(5)}px imgs=${s.imgs} h3=${s.h3} links=${s.links} chars=${String(s.chars).padStart(4)} boxes=${String(s.grids).padStart(2)} | ${s.heads[0] || ''} | .${s.cls.split(' ')[0]}`);
const parts = Math.min(maxParts, Math.ceil(info.height / 1500));
await page.setViewportSize({ width, height: 1500 });
for (let i = 0; i < parts; i++) { await page.evaluate(y => scrollTo(0, y), i * 1500); await page.waitForTimeout(600); await page.screenshot({ path: resolve(out, `${name}-${width}-${i + 1}.png`) }); }
await browser.close();
