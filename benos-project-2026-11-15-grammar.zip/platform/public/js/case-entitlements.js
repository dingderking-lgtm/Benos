import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
const kinds = { subscription: '会员账期', annual: '年付托管' };
const states = { active: '有效', cancelled: '已停止续费，保留原账期', expired: '已到期', revoked: '已撤销', pending: '等待确认' };
const renewalStates = { active: '自动续费中', cancel_scheduled: '已安排到期停止续费', cancelled: '已取消续费', past_due: '续费逾期', unknown: '续费状态尚未确认', not_applicable: '不涉及自动续费' };
const operationStates = { pending_billing_change: '等待渠道确认取消续费，权益尚未撤销', pending_local_change: '等待完成权益调整，请查询原操作', completed: '已完成' };
const allowed = item => (item.kind === 'refund' && item.providerState === 'succeeded') || (item.kind === 'dispute' && item.providerState === 'lost');
const pending = operation => ['pending_billing_change', 'pending_local_change'].includes(operation.state);
const action = (label, name, attrs = '') => `<button type="button" class="ui-button ui-button--secondary" data-action="case-entitlement-${name}" ${attrs}>${label}</button>`;
const original = (data, item) => data.entitlements.operations.find(operation => operation.id === item.revocationId && operation.direction === 'revoke' && operation.state === 'completed' && operation.targetId === item.id && operation.targetKind === item.kind);
const inProgress = (data, item) => data.entitlements.operations.some(operation => operation.targetId === item.id && operation.targetKind === item.kind && pending(operation));
const resultMessage = result => result.state === 'completed' ? result.direction === 'restore' ? '已恢复原订单权益，原有效期保留；未重新开启自动续费' : '已撤销选定订单权益；渠道退款与额度冲销记录分别保留' : operationStates[result.state] || '权益操作已受理，请刷新核对结果';

export function renderCaseEntitlements(data, user) {
  if (!data.entitlements) return '';
  const entitlements = data.entitlements, owner = user.role === 'owner';
  return `<section class="b-section"><div class="b-section-heading"><div><h2>原订单的会员与托管权益</h2><p>权益调整、AI 额度冲销和支付渠道退款分别记录。</p></div></div><div class="b-notice">${icon('shield-check')}<div><strong>仅调整这笔订单对应的权益</strong><p>撤销会员账期会停止该账期的会员、附送托管及尚未冲销的月度额度；其他账期与独立年费托管保留。恢复保留原有效期，不重新开启自动续费，也不恢复已单独冲销的额度。</p></div></div><p class="b-muted b-section">后续续费：${e(renewalStates[entitlements.renewal.state] || entitlements.renewal.state)}${entitlements.renewal.cancelRequested && !['cancel_scheduled', 'cancelled'].includes(entitlements.renewal.state) ? ' · 已请求取消，仍需渠道确认' : ''}</p>${entitlements.items.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>权益</th><th>原有效期</th><th>当前状态</th><th>操作</th></tr></thead><tbody>${entitlements.items.map(item => {
    const prior = original(data, item), busy = inProgress(data, item), canRestore = item.state === 'revoked' && prior;
    return `<tr><td>${e(kinds[item.kind] || item.kind)}${item.tier ? ` · ${item.tier === 'pro' ? 'Pro' : 'Go'}` : ''}<small>${e(item.id)}</small>${item.siteId ? `<small>网站：${e(item.siteId)}</small>` : ''}</td><td>${date(item.startsAt)}<small>至 ${date(item.endsAt)}</small></td><td>${e(states[item.state] || item.state)}${item.membershipFrozen ? '<small>会员计时暂停中，请先处理会员冻结</small>' : ''}${busy ? '<small>有未完成的权益操作，请从下方查询原操作</small>' : ''}</td><td>${canRestore ? action('恢复原订单权益', 'restore', `data-target-id="${e(item.id)}" data-target-kind="${e(item.kind)}" ${owner && !busy && !item.membershipFrozen ? '' : 'disabled'}`) : action('撤销此项权益', 'revoke', `data-target-id="${e(item.id)}" data-target-kind="${e(item.kind)}" ${owner && allowed(data.case) && item.state !== 'revoked' && !busy && !item.membershipFrozen ? '' : 'disabled title="需平台所有者、符合渠道状态，且没有会员冻结或待处理操作"'}`)}</td></tr>`;
  }).join('')}</tbody></table></div>` : '<div class="b-inline-empty">此订单没有可关联的会员或年付托管权益。</div>'}${entitlements.operations.length ? `<div class="b-section-heading b-section"><h3>权益调整记录</h3></div><div class="b-table-wrap"><table class="b-table"><thead><tr><th>操作</th><th>处理状态</th><th>原因 / 依据</th><th>时间</th><th>操作</th></tr></thead><tbody>${entitlements.operations.map(operation => `<tr><td>${operation.direction === 'revoke' ? '撤销' : '恢复'}${e(kinds[operation.targetKind] || operation.targetKind)}<small>${e(operation.targetId)}</small>${operation.direction === 'revoke' && operation.targetKind === 'subscription' ? `<small>${operation.cancelRenewal ? '同时请求取消后续续费' : '已确认保留后续续费'}</small>` : ''}</td><td class="b-table-prose">${e(operationStates[operation.state] || operation.state)}${operation.errorCode ? `<small>${e(operation.errorCode)}</small>` : ''}</td><td class="b-table-prose">${e(operation.reason || '—')}<small>${e(operation.evidence || '')}</small></td><td>${date(operation.createdAt)}</td><td>${pending(operation) ? action('查询并重试原操作', 'retry', `data-operation-id="${e(operation.id)}" ${owner ? '' : 'disabled'}`) : '—'}</td></tr>`).join('')}</tbody></table></div>` : ''}</section>`;
}

export async function handleCaseEntitlementAction(name, trigger, context) {
  if (!['case-entitlement-revoke', 'case-entitlement-restore', 'case-entitlement-retry'].includes(name)) return false;
  if (context.state.user.role !== 'owner') throw new Error('只有平台所有者可以调整订单权益。');
  const data = context.state.resource;
  const base = `/admin/payment-cases/${encodeURIComponent(data.case.id)}/entitlements`;
  if (name === 'case-entitlement-retry') {
    const operation = data.entitlements.operations.find(item => item.id === trigger.dataset.operationId && pending(item));
    if (!operation) throw new Error('操作状态已变化，请刷新记录。');
    trigger.disabled = true;
    try {
      const result = await api(`${base}/${encodeURIComponent(operation.id)}/retry`, { method: 'POST', body: {} });
      await context.reload(); context.notify(resultMessage(result));
    } finally { if (trigger.isConnected) trigger.disabled = false; }
    return true;
  }
  const item = data.entitlements.items.find(row => row.id === trigger.dataset.targetId && row.kind === trigger.dataset.targetKind);
  const direction = name.endsWith('restore') ? 'restore' : 'revoke';
  if (!item || inProgress(data, item)) throw new Error('权益状态已变化或已有待处理操作，请刷新核对。');
  if (item.membershipFrozen) throw new Error('此会员账期仍暂停计时，请先处理原会员冻结。');
  const parent = direction === 'restore' ? original(data, item) : null;
  if (direction === 'restore' ? item.state !== 'revoked' || !parent : item.state === 'revoked' || !allowed(data.case)) throw new Error('当前权益或渠道状态不满足此操作条件，请刷新核对。');
  const title = direction === 'restore' ? '恢复原订单权益' : '撤销此项权益';
  context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${direction === 'restore' ? '恢复原有效期，不续期、不重新开启自动续费、不恢复已单独冲销的 AI 额度。' : item.kind === 'subscription' ? '仅停止这笔订单的会员账期、附送托管与月度额度；其他账期及独立年费托管保留。' : '仅停止这笔订单的年付托管权益；其他独立托管权益保留。'}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="case-entitlement" data-case-id="${e(data.case.id)}" data-revision="${e(data.case.revision)}" data-direction="${direction}" data-target-id="${e(item.id)}" data-target-kind="${e(item.kind)}" data-parent-id="${e(parent?.id || '')}" data-request-key="${crypto.randomUUID()}"><p class="b-confirm-title">${e(kinds[item.kind])} · ${e(item.id)}</p><p class="b-muted">原有效期：${date(item.startsAt)} 至 ${date(item.endsAt)}。${direction === 'restore' && item.endsAt && new Date(item.endsAt).valueOf() <= Date.now() ? '原权益已到期，恢复后仍不能使用。' : ''}</p>${direction === 'revoke' && item.kind === 'subscription' ? '<label class="b-field"><span>后续自动续费处理</span><select name="renewalChoice" required><option value="">请选择续费处理方式</option><option value="cancel">取消后续自动续费</option><option value="retain">保留后续自动续费</option></select><small class="b-field-hint">选择取消时，必须等待支付渠道确认后才撤销这笔订单权益。</small></label><label class="b-confirm-checkbox"><input type="checkbox" name="confirmRenewalContinues"><span>如选择保留续费，我确认后续账期仍可能自动扣款。</span></label>' : ''}<label class="b-field"><span>操作原因</span><textarea name="reason" rows="3" minlength="3" maxlength="500" required></textarea></label><label class="b-field"><span>核对依据</span><textarea name="evidence" rows="3" minlength="10" maxlength="2000" required></textarea></label><label class="b-confirm-checkbox"><input type="checkbox" name="confirmImpact" required><span>已核对原订单、权益范围、有效期及续费影响，确认本次${direction === 'restore' ? '恢复' : '撤销'}。</span></label><p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">确认${title}</button></div></form>`);
  return true;
}

export async function submitCaseEntitlementForm(form, values, context) {
  if (context.state.user.role !== 'owner' || !values.confirmImpact) throw new Error('需要平台所有者核对并确认操作影响。');
  const monthlyRevoke = form.dataset.direction === 'revoke' && form.dataset.targetKind === 'subscription';
  if (monthlyRevoke && !['cancel', 'retain'].includes(values.renewalChoice)) throw new Error('请明确选择后续自动续费的处理方式。');
  if (monthlyRevoke && values.renewalChoice === 'retain' && !values.confirmRenewalContinues) throw new Error('保留自动续费前，请确认后续账期仍可能自动扣款。');
  const result = await api(`/admin/payment-cases/${encodeURIComponent(form.dataset.caseId)}/entitlements`, { method: 'POST', body: { direction: form.dataset.direction, targetKind: form.dataset.targetKind, targetId: form.dataset.targetId, ...(form.dataset.direction === 'restore' ? { parentId: form.dataset.parentId } : {}), cancelRenewal: monthlyRevoke && values.renewalChoice === 'cancel', confirmRenewalContinues: monthlyRevoke && values.renewalChoice === 'retain' && !!values.confirmRenewalContinues, reason: values.reason.trim(), evidence: values.evidence.trim(), requestKey: form.dataset.requestKey, expectedRevision: Number(form.dataset.revision), confirmImpact: true } });
  context.closeModal(); await context.reload(); context.notify(resultMessage(result));
}
