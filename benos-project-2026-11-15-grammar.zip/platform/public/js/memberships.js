import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
const usd = value => new Intl.NumberFormat('en-US', { style:'currency', currency:'USD', maximumFractionDigits:6 }).format(Number(value) / 1e6);
const states = { pending_billing_change: '正在暂停扣费，尚未冻结', frozen: '会员计时已冻结', pending_unfreeze: '正在恢复扣费日期，仍然冻结', completed: '已恢复并补足时间' };
const action = (title, name, attrs = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="membership-${name}" ${attrs}>${title}</button>`;
const reasonField = value => `<label class="b-field"><span>操作原因</span><textarea name="reason" minlength="3" maxlength="500" rows="3" required>${e(value || '')}</textarea></label>`;
const footer = title => `<p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">${title}</button></div>`;
const modal = (title, description, operation, content, attributes) => `<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${description}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="membership-${operation}" ${attributes}>${content}</form>`;

export function renderMembershipPanel(data, actor) {
  const membership = data.membership;
  if (!membership) return '';
  const user = data.user;
  const freeze = membership.freeze;
  const canManage = actor.role === 'owner' || (actor.role === 'admin' && user.role === 'user');
  const canFreeze = canManage && actor.id !== user.id && user.role !== 'owner';
  const busy = freeze && freeze.state !== 'completed';
  const attrs = `data-user-id="${e(user.id)}"`;
  const items = membership.items || [];
  const hasTerm = items.some(item => ['active', 'cancelled'].includes(item.state) && new Date(item.ends_at) > new Date());
  return `<section class="b-section"><div class="b-section-heading"><div><h2>会员权益与计时</h2><p>赠送包含完整月度 AI 额度，冻结期间暂停会员计时。</p></div><div class="b-table-actions">${canManage ? action('赠送会员', 'gift', `${attrs} ${busy ? 'disabled title="请先完成解冻"' : ''}`, true) : ''}${canFreeze ? freeze?.frozen ? action(freeze.state === 'pending_unfreeze' ? '继续恢复' : '解冻并顺延', 'unfreeze', attrs) : freeze?.state === 'pending_billing_change' ? action('继续冻结操作', 'freeze', attrs) : action('冻结会员计时', 'freeze', `${attrs} ${hasTerm ? '' : 'disabled title="没有可暂停的会员期"'}`) : ''}</div></div>${freeze ? `<div class="b-notice b-member-freeze">${icon('clock')}<div><strong>${states[freeze.state] || e(freeze.state)}</strong><p>${freeze.frozenAtMs ? `开始冻结：${date(freeze.frozenAtMs)}。` : ''}${freeze.state === 'completed' ? ` 已补足 ${Math.round((freeze.compensatedMs || 0) / 60000)} 分钟会员时间。` : freeze.state === 'pending_billing_change' ? '只有扣费暂停确认后，会员才会进入冻结。' : freeze.state === 'pending_unfreeze' ? '待扣费日期核对完成后，再恢复权益并补足冻结时间。' : '会员时间与对应额度有效期将在解冻时一起顺延。'}${freeze.errorCode ? ` 操作尚待确认：${e(freeze.errorCode)}。请继续原操作。` : ''}</p></div></div>` : ''}${items.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>套餐</th><th>来源</th><th>有效期</th><th>会员计时</th><th>每期 AI 额度</th></tr></thead><tbody>${items.map(item => `<tr><td>${item.tier === 'pro' ? 'Pro' : 'Go'}</td><td>${item.source === 'gift' ? '平台赠送' : '付费订阅'}</td><td>${date(item.starts_at)}<small>至 ${date(item.ends_at)}</small></td><td><span class="b-badge">${item.membership_frozen_by ? '已暂停' : new Date(item.ends_at) <= new Date() ? '已到期' : new Date(item.starts_at) > new Date() ? '未开始' : '计时中'}</span></td><td>${usd(item.credit_micros)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="b-inline-empty">该账户尚无会员权益记录。</div>'}<div class="b-membership-gifts">${(membership.gifts || []).filter(gift => gift.state === 'pending').map(gift => `<div class="b-notice"><div><strong>${gift.tier === 'pro' ? 'Pro' : 'Go'} 赠送正在入账</strong><p>此赠送尚未全部确认，请继续原请求，避免再次赠送。</p>${canManage ? action('继续赠送入账', 'gift-retry', `data-user-id="${e(user.id)}" data-gift-id="${e(gift.id)}"`) : '<p>此记录仅供查看，请由有权限的管理员继续处理原赠送。</p>'}</div></div>`).join('')}</div><p class="b-muted">赠送会员包含对应套餐的完整月度额度与托管名额；额外充值仍需有效的付费会员。</p></section>`;
}

export async function handleMembershipAction(name, trigger, context) {
  const membership = context.state.resource.membership;
  const userId = trigger.dataset.userId;
  if (name === 'membership-gift' || name === 'membership-gift-retry') {
    const existing = name.endsWith('-retry') ? membership.gifts.find(item => item.id === trigger.dataset.giftId) : null;
    if (name.endsWith('-retry') && !existing) throw new Error('赠送状态已变化，请刷新后重试。');
    let savedPlan; try { savedPlan = existing?.plan_snapshot_json ? JSON.parse(existing.plan_snapshot_json) : null; } catch { throw new Error('原赠送套餐记录无法读取，请刷新后核对。'); }
    const plans = existing ? [{ tier: existing.tier, name: existing.tier === 'pro' ? 'Pro' : 'Go', ...savedPlan }] : membership.giftPlans || [];
    if (!plans.length || !existing && !membership.catalogVersionId) throw new Error('赠送套餐版本尚未读取，请刷新后重试。');
    const catalogVersionId = existing ? existing.catalog_version_id || savedPlan?.catalogVersionId || '' : membership.catalogVersionId;
    const scheduledStart = existing && Number(existing.starts_at_ms) > Date.parse(existing.created_at) ? new Date(existing.starts_at_ms).toISOString() : '';
    const attributes = `data-catalog-version="${e(catalogVersionId)}" data-user-id="${e(userId)}" data-request-key="${e(existing?.request_key || crypto.randomUUID())}" data-starts-at="${e(scheduledStart)}"`;
    context.showModal(modal(existing ? '继续赠送入账' : '赠送会员', '按月发放完整 AI 额度与对应托管名额，不附赠充值权限。', 'gift', `<label class="b-field"><span>赠送套餐</span><select name="tier" ${existing ? 'disabled' : ''}>${plans.map(plan => `<option value="${e(plan.tier)}" ${existing?.tier === plan.tier ? 'selected' : ''}>${e(plan.name)} · ${Number.isSafeInteger(plan.creditMicros) ? `每月 ${usd(plan.creditMicros)} AI 额度 · ${e(plan.includedSites)} 个网站` : '沿用原历史赠送权益'}</option>`).join('')}</select>${existing ? `<input type="hidden" name="tier" value="${e(existing.tier)}">` : ''}</label><label class="b-field"><span>赠送月数</span><input type="number" name="months" min="1" max="12" value="${existing?.months || 1}" required ${existing ? 'readonly' : ''}></label>${existing ? scheduledStart ? `<p class="b-notice-text">预约开始：${date(scheduledStart)}，沿用原请求的开始时间。</p>` : '' : '<label class="b-field"><span>预约开始时间（可选）</span><input type="datetime-local" name="startsAt"><small class="b-field-hint">留空立即开始；可预约未来一年内开始。预约前不会提前增加可用 AI 额度。</small></label>'}${existing ? reasonField(existing.reason).replace('<textarea ', '<textarea readonly ') : reasonField('')}${footer(existing ? '继续原请求' : '确认赠送')}`, attributes));
    return true;
  }
  if (name === 'membership-freeze' || name === 'membership-unfreeze') {
    const operation = name.endsWith('-unfreeze') ? 'unfreeze' : 'freeze';
    const freeze = membership.freeze;
    const pending = operation === 'freeze' ? freeze?.state === 'pending_billing_change' : freeze?.state === 'pending_unfreeze';
    const requestKey = pending ? operation === 'freeze' ? freeze.requestKey : freeze.unfreezeRequestKey : crypto.randomUUID();
    const reason = pending ? operation === 'freeze' ? freeze.reason : freeze.unfreezeReason : '';
    context.showModal(modal(operation === 'freeze' ? '冻结会员计时' : '解冻并顺延会员', operation === 'freeze' ? '先确认自动扣费暂停，再冻结会员时间。历史充值余额单独保留。' : '恢复扣费日期后，顺延会员及对应额度的有效期，补足冻结期间的时间。', operation, `${pending ? '<p class="b-notice-text">继续此前未完成的操作，沿用原请求编号与原因。</p>' : ''}${pending ? reasonField(reason).replace('<textarea ', '<textarea readonly ') : reasonField('')}${footer(pending ? '继续原操作' : '确认操作')}`, `data-user-id="${e(userId)}" data-request-key="${e(requestKey)}"`));
    return true;
  }
  return false;
}

export async function submitMembershipForm(name, form, values, context) {
  const operation = name.replace('membership-', '');
  if (!['gift', 'freeze', 'unfreeze'].includes(operation)) return false;
  const body = { reason: values.reason.trim(), requestKey: form.dataset.requestKey, ...(operation === 'gift' ? { tier: values.tier, months: Number(values.months) } : {}) };
  if (operation === 'gift' && form.dataset.catalogVersion) body.catalogVersionId = form.dataset.catalogVersion;
  if (operation === 'gift' && (form.dataset.startsAt || values.startsAt)) body.startsAt = form.dataset.startsAt || new Date(values.startsAt).toISOString();
  const result = await api(`/admin/memberships/${encodeURIComponent(form.dataset.userId)}/${operation === 'gift' ? 'gifts' : operation}`, { method: 'POST', body });
  let message;
  if (operation === 'gift') message = result.gifts?.some(gift => gift.request_key === body.requestKey && gift.state === 'completed') ? body.startsAt && new Date(body.startsAt) > new Date() ? '会员赠送已安排，将按预约时间开始' : '会员赠送已入账' : '赠送正在入账，请查看原操作状态';
  else if (operation === 'freeze') message = result.freeze?.state === 'frozen' ? '会员计时已冻结' : '冻结尚未确认，请继续查看原操作';
  else message = result.freeze?.state === 'completed' ? '会员已恢复，冻结时间已顺延补足' : '恢复尚未确认，会员仍保持冻结';
  context.closeModal();
  await context.reload();
  context.notify(message);
  return true;
}
