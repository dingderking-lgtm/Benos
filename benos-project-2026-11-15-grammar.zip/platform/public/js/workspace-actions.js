import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';
import { normalizeDirection, styleDirection, renderDirectionPanel, renderStyleGallery, directionProject } from './workspace-direction.js';
import { renderDashboardInspirations } from './dashboard-home.js';
import { previewDocument } from './workspace-preview.js';

let accountTrigger=null, pointerTrigger=null, directionDraft=null, directionResize=null;
const account=()=>document.getElementById('account-menu');
function positionAccount(){
 const menu=account();if(!accountTrigger?.isConnected||!menu?.matches(':popover-open'))return;
 const scale=Number.parseFloat(getComputedStyle(document.documentElement).zoom)||1;
 const width=(visualViewport?.width||innerWidth)/scale,height=(visualViewport?.height||innerHeight)/scale;
 const anchor=accountTrigger.getBoundingClientRect(),rail=accountTrigger.closest('.app-sidebar,#mobile-nav')?.getBoundingClientRect();
 menu.style.width=Math.min(280,rail?.width>=240?rail.width/scale-24:280,width-24)+'px';
 const box=menu.getBoundingClientRect();
 menu.style.left=Math.max(12,Math.min((rail?.width>=240?rail.left+(rail.width-box.width)/2:anchor.left)/scale,width-box.width/scale-12))+'px';
 menu.style.top=Math.max(12,Math.min((anchor.top-box.height)/scale-8,height-box.height/scale-12))+'px';
}
export function closeWorkspaceAccount(restore=false){const trigger=accountTrigger,menu=account();if(menu?.matches(':popover-open'))menu.hidePopover();trigger?.setAttribute('aria-expanded','false');if(menu&&menu.parentNode!==document.body)document.body.append(menu);accountTrigger=null;if(restore&&trigger?.isConnected)trigger.focus();}
export function openWorkspaceAccount(trigger,context){
 if(pointerTrigger===trigger||(account()?.matches(':popover-open')&&accountTrigger===trigger)){pointerTrigger=null;closeWorkspaceAccount(true);return;}
 pointerTrigger=null;closeWorkspaceAccount();accountTrigger=trigger;
 const menu=account();menu.innerHTML=context.renderAccount({user:context.state.user,billing:context.state.workspaceBilling,canOperate:context.canOperate});
 (trigger.closest('#mobile-nav')||document.body).append(menu);trigger.setAttribute('aria-expanded','true');menu.showPopover();positionAccount();menu.querySelector('a,button')?.focus({preventScroll:true});
}
document.addEventListener('pointerdown',event=>{pointerTrigger=account()?.matches(':popover-open')&&event.target.closest('[data-action="workspace-account"]')===accountTrigger?accountTrigger:null;});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&account()?.matches(':popover-open')){event.preventDefault();event.stopPropagation();closeWorkspaceAccount(true);}},true);
window.addEventListener('resize',positionAccount,{passive:true});
window.visualViewport?.addEventListener('resize',positionAccount,{passive:true});
account()?.addEventListener('toggle',event=>{if(event.newState==='closed')accountTrigger?.setAttribute('aria-expanded','false');});

export function renderWorkspaceInspiration(direction){return `<section class="s-page inspiration-page"><div class="page-intro"><div><h1>灵感案例</h1><p>从喜欢的画面出发，创造属于你的品牌网站。</p></div><button type="button" class="ui-button ui-button--primary" data-action="choose-style">${icon('palette')}视觉设定</button></div>${renderDashboardInspirations()}${renderStyleGallery(normalizeDirection(direction).style)}</section>`;}
async function home(context){if(context.state.route!=='home'){history.replaceState(null,'','#home');await context.reload();}}
function directionPreview(value){
 directionResize?.disconnect();
 const frame=document.getElementById('direction-preview');if(!frame)return;
 frame.srcdoc=previewDocument(directionProject(value));
 const fit=()=>{const parent=frame.parentElement,w=parent.clientWidth;if(!w)return;frame.style.width='1000px';frame.style.height='720px';frame.style.transform=`scale(${w/1000})`;parent.style.height=Math.round(720*w/1000)+'px';};directionResize=new ResizeObserver(fit);directionResize.observe(frame.parentElement);requestAnimationFrame(fit);
}
document.getElementById('modal')?.addEventListener('close',()=>{directionResize?.disconnect();directionResize=null;});
function paintDirection(context,opener){
 const content=`<div class="b-modal-header"><div><h2 id="modal-title">视觉设定</h2></div><button type="button" class="ui-icon-button ui-button--ghost" data-action="close-modal" aria-label="关闭视觉设定">${icon('x')}</button></div><div class="b-modal-body workspace-direction-body">${renderDirectionPanel(directionDraft)}</div>`;
 const modal=document.getElementById('modal');
 if(modal.open&&modal.classList.contains('direction-modal')){modal.innerHTML=content;if(opener){const same=[...modal.querySelectorAll('[data-action]')].find(n=>n.dataset.action===opener.action&&n.dataset.style===opener.style&&n.dataset.option===opener.option&&n.dataset.value===opener.value);same?.focus({preventScroll:true});}}
 else context.showModal(content);
 modal.classList.add('direction-modal');directionPreview(directionDraft);
}
export async function handleWorkspaceAction(action,trigger,context){
 if(action==='workspace-project-preview'){
  const path=`/preview/${encodeURIComponent(trigger.dataset.projectId)}/${encodeURIComponent(trigger.dataset.versionId)}`;
  context.showModal(`<div class="b-modal-header"><h2 id="modal-title">${e(trigger.dataset.name)} · 设计预览</h2><button type="button" class="ui-icon-button" data-action="close-modal" aria-label="关闭预览">${icon('x')}</button></div><div class="b-modal-body"><iframe class="full-preview" src="${e(path)}" sandbox="allow-same-origin" referrerpolicy="no-referrer" title="${e(trigger.dataset.name)}设计预览"></iframe></div>`);
  document.getElementById('modal').classList.add('workspace-preview-modal');return;
 }
 if(action==='workspace-account')return openWorkspaceAccount(trigger,context);
 if(action==='workspace-account-close')return closeWorkspaceAccount(true);
 if(action==='workspace-menu'){context.showModal(`<div class="b-modal-header"><h2 id="modal-title">开始新的创作</h2><button type="button" class="ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></div><div class="b-modal-body creation-menu-options"><button type="button" data-action="workspace-new-design">${icon('sparkles')}<span><strong>描述你的想法</strong><small>从一句需求开始设计网站</small></span>${icon('arrow-right')}</button><button type="button" data-action="start-library">${icon('layout-template')}<span><strong>从模板开始</strong><small>选择一个完整的网站模板</small></span>${icon('arrow-right')}</button><a href="#projects">${icon('folder')}<span><strong>继续已有项目</strong><small>回到你的创作空间</small></span>${icon('arrow-right')}</a></div>`);return;}
 if(action==='workspace-new-design'){context.closeModal();await home(context);document.getElementById('project-idea')?.focus();return;}
 if(action==='workspace-search'){closeWorkspaceAccount();context.closeModal();history.replaceState(null,'','#projects');await context.reload();document.querySelector('[name="project-search"]')?.focus();return;}
 if(action==='workspace-media'){
  const result=await api('/projects'),items=result.items||result.projects||[];
  context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">项目素材库</h2><p>选择项目，管理它的图片与文件。</p></div><button type="button" class="ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></div><div class="b-modal-body creation-menu-options">${items.length?items.map(p=>`<a href="#media/${encodeURIComponent(p.id)}">${icon('folder')}<span><strong>${e(p.name)}</strong><small>打开项目私有素材库</small></span>${icon('arrow-right')}</a>`).join(''):'<p>先创建一个网站项目，素材会保存在对应项目中。</p><button type="button" data-action="workspace-new-design">开始第一个项目</button>'}${result.nextCursor?'<a href="#projects">查看全部项目</a>':''}</div>`);return;
 }
 if(action==='workspace-reference'){await home(context);document.getElementById('workspace-reference-input')?.click();return;}
 if(action==='workspace-dismiss-tip'){context.state.workspaceTipDismissed=true;document.querySelector('.composer-guide')?.remove();return;}
 if(action==='workspace-style'||action==='choose-style'||action==='explore-direction'){await home(context);directionDraft=action==='explore-direction'?styleDirection(trigger.dataset.style):context.getDirection();paintDirection(context);return;}
 if(action==='set-style'){directionDraft=styleDirection(trigger.dataset.style);paintDirection(context,{...trigger.dataset});return;}
 if(action==='set-direction-option'){if(!['accent','typography','layout'].includes(trigger.dataset.option))return;directionDraft=normalizeDirection({...directionDraft,[trigger.dataset.option]:trigger.dataset.value});paintDirection(context,{...trigger.dataset});return;}
 if(action==='reset-direction'){directionDraft=normalizeDirection();paintDirection(context);return;}
 if(action==='apply-direction'){context.setDirection(directionDraft);context.closeModal();context.render();document.getElementById('project-idea')?.focus();return;}
 if(action==='workspace-inspiration'){
  const example=context.examples.find(item=>item.id===trigger.dataset.id);if(!example)return;
  if(trigger.dataset.intent==='use'){
   await home(context);context.state.workspacePrompt=example.prompt;context.setDirection(example);context.closeModal();context.render();document.getElementById('project-idea')?.focus();return;
  }
  context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">${e(example.name)} · 设计参考</h2><p>${e(example.description)}</p></div><button type="button" class="ui-icon-button" data-action="close-modal" aria-label="关闭参考">${icon('x')}</button></div><div class="b-modal-body"><iframe id="workspace-example-preview" class="full-preview" sandbox="allow-same-origin" title="${e(example.name)}示例网站预览"></iframe><p class="workspace-inspiration-copy">${e(example.prompt)}</p><div class="b-form-actions"><button type="button" class="ui-button ui-button--primary" data-action="workspace-inspiration" data-id="${example.id}" data-intent="use">以此为灵感开始 ${icon('arrow-right')}</button></div></div>`);document.getElementById('modal').classList.add('workspace-preview-modal');document.getElementById('workspace-example-preview').srcdoc=previewDocument(example);return;
 }
}
