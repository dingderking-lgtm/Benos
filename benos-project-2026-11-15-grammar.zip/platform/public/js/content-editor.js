import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const kinds = { page: '营销页面', post: '博客文章', faq: '常见问题', navigation: '导航链接', banner: '展示横幅', category: '内容分类', tag: '文章标签' };
const fields = (label, name, value = '', options = {}) => `<label class="b-field"><span>${label}</span>${options.textarea ? `<textarea name="${name}" rows="${options.rows || 3}" maxlength="${options.max || 1000}" ${options.required ? 'required' : ''}>${e(value)}</textarea>` : `<input type="${options.type || 'text'}" name="${name}" value="${e(value)}" maxlength="${options.max || 200}" ${options.required ? 'required' : ''} ${options.type === 'number' ? 'min="0" max="100000" step="1"' : ''}>`}${options.hint ? `<small class="b-field-hint">${options.hint}</small>` : ''}</label>`;
const select = (label, name, values, value = '') => `<label class="b-field"><span>${label}</span><select name="${name}">${values.map(item => `<option value="${e(item.id)}" ${item.id === value ? 'selected' : ''}>${e(item.label)}</option>`).join('')}</select></label>`;

export async function loadContentResource(options) {
  const params = new URLSearchParams(location.hash.split('?')[1] || '');
  const filters = {kind:params.get('kind')||'',state:params.get('state')||'any',q:params.get('q')||'',sort:params.get('sort')||'updated_desc',categoryId:params.get('categoryId')||'',tagId:params.get('tagId')||''};
  const filter = new URLSearchParams(Object.entries(filters).filter(([,value])=>value));
  const reads = await Promise.allSettled([api('/admin/content?' + filter, options), api('/admin/content/options', options)]);
  const failure = reads.find(item => item.status === 'rejected'); if (failure) throw failure.reason;
  return { ...reads[0].value, references: reads[1].value, filters };
}

export function publicContentUrl(item) {
  const slug = item.published?.slug || item.slug;
  if (!slug) return null;
  const path = slug.split('/').map(encodeURIComponent).join('/');
  return item.kind === 'post' ? '/blog/' + path : item.kind === 'page' ? '/pages/' + path : item.kind === 'category' ? '/category/' + path : item.kind === 'tag' ? '/tag/' + path : item.kind === 'faq' ? '/faq' : '/home';
}

export function contentFilters(data) {
  const f=data.filters||{},refs=data.references||{};
  return `<form class="b-content-toolbar" data-form="admin-content-filter"><div>${fields('搜索内容','contentQuery',f.q||'',{max:160,hint:'按标题、地址标识和正文搜索全部内容。'})}${select('内容类型','contentKindFilter',[{id:'',label:'全部类型'},...Object.entries(kinds).map(([id,label])=>({id,label}))],f.kind||'')}${select('内容状态','contentStateFilter',[{id:'any',label:'全部状态'},{id:'draft',label:'草稿'},{id:'published',label:'已发布'},{id:'unpublished',label:'已取消发布'},{id:'trashed',label:'回收站'}],f.state||'any')}${select('排序','contentSort',[{id:'updated_desc',label:'最近更新'},{id:'created_desc',label:'最近创建'},{id:'published_desc',label:'最近发布'},{id:'title_asc',label:'标题升序'},{id:'position_asc',label:'展示顺序'}],f.sort||'updated_desc')}${select('分类','contentCategory',[{id:'',label:'全部分类'},...(refs.categories||[]).map(i=>({id:i.id,label:i.title}))],f.categoryId||'')}${select('标签','contentTag',[{id:'',label:'全部标签'},...(refs.tags||[]).map(i=>({id:i.id,label:i.title}))],f.tagId||'')}</div><div class="b-table-actions"><button class="ui-button ui-button--primary" type="submit">搜索与筛选</button><button class="ui-button ui-button--secondary" type="button" data-action="admin-marketing-media-open">营销素材库</button><a class="ui-button ui-button--secondary" href="/home" target="_blank" rel="noopener">查看平台前台 ${icon('arrow-up-right')}</a></div></form>`;
}

export function contentBulkToolbar(){return `<div class="b-table-actions b-section"><button type="button" class="ui-button ui-button--secondary" data-action="admin-content-select-all">全选 / 取消当前已加载项</button><label class="b-field"><span>批量操作</span><select data-content-bulk-action><option value="publish">发布</option><option value="unpublish">取消发布</option><option value="trash">移入回收站</option><option value="restore">恢复草稿</option></select></label><button type="button" class="ui-button ui-button--secondary" data-action="admin-content-bulk-review">处理选中项</button></div>`;}

export async function handleContentListAction(name,trigger,context){
 if(name==='admin-content-references'){const result=await api('/admin/content/'+encodeURIComponent(trigger.dataset.itemId)+'/references'),target=trigger.closest('form').querySelector('[data-content-references]');target.innerHTML=result.items.length?`<p>当前引用（${result.items.length} 处）：</p><ul>${result.items.map(item=>`<li><a href="${e(item.href)}">${e(item.title)}</a> · ${e(item.snapshots.map(s=>s==='draft'?'草稿':'已发布').join('、'))}</li>`).join('')}</ul>`:'<p>当前没有引用。删除或下架时仍会重新核对。</p>';return true;}

 if(name==='admin-content-select-all'){const boxes=[...document.querySelectorAll('[data-content-select]')],checked=boxes.some(box=>!box.checked);boxes.forEach(box=>{box.checked=checked;});return true;}
 if(name!=='admin-content-bulk-review')return false;
 const selected=[...document.querySelectorAll('[data-content-select]:checked')].map(box=>({id:box.value,revision:Number(box.dataset.revision)}));
 if(!selected.length)throw new Error('请先选择需要处理的内容。');if(selected.length>100)throw new Error('一次最多处理100条，请缩小选择范围。');
 const operation=document.querySelector('[data-content-bulk-action]').value,labels={publish:'发布',unpublish:'取消发布',trash:'移入回收站',restore:'恢复草稿'};
 context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">批量${labels[operation]}</h2><p>逐条核对权限、版本与引用。部分失败时会显示具体记录，不影响其他已完成结果。</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></div><form class="b-modal-body" data-form="admin-content-bulk" data-operation="${operation}" data-items="${e(JSON.stringify(selected))}"><p>已选择 ${selected.length} 条内容。</p><label class="b-confirm-checkbox"><input type="checkbox" name="confirmed" required><span>确认按上述范围逐条处理。</span></label><p data-form-error class="b-form-error" hidden></p><div class="b-form-actions"><button class="ui-button ui-button--primary" type="submit">确认批量${labels[operation]}</button></div></form>`);return true;
}
export async function submitContentListForm(name,form,values,context){
 if(name==='admin-content-filter'){navigateContentFilter(context);return true;}
 if(name!=='admin-content-bulk')return false;if(!values.confirmed)throw new Error('请确认批量处理范围。');
 const result=await api('/admin/content/bulk',{method:'POST',body:{action:form.dataset.operation,items:JSON.parse(form.dataset.items)}}),passed=result.items.filter(i=>i.ok).length;
 await context.reload();context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">批量处理结果</h2><p>已完成 ${passed} 条；未完成 ${result.items.length-passed} 条。</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></div><div class="b-modal-body">${result.items.map(item=>`<p><code>${e(item.id)}</code><br>${item.ok?'已完成':e(item.error?.message||'未完成，请刷新核对')}</p>`).join('')}</div>`);return true;
}

function specificFields(kind, content, refs, itemId) {
  let html = '';
  if (['post', 'page', 'category', 'tag', 'banner'].includes(kind)) {
    html += `<details class="b-content-field-group" open><summary>搜索展示与封面</summary>${fields('SEO 标题', 'seoTitle', content.seoTitle || '', { max: 200, hint: '留空使用内容标题。' })}${fields('SEO 描述', 'seoDescription', content.seoDescription || '', { textarea: true, max: 320, hint: '简要说明页面内容，不承诺收录或排名。' })}<input type="hidden" name="coverMediaId" value="${e(content.coverMediaId||'')}">${content.coverMediaId?`<p class="b-field-hint">已关联营销素材 <code>${e(content.coverMediaId)}</code></p>`:''}<div class="b-table-actions"><button type="button" class="ui-button ui-button--secondary" data-action="admin-marketing-media-picker">从营销素材库选择封面</button><button type="button" class="ui-button ui-button--secondary" data-action="admin-marketing-media-clear">移除素材关联</button></div><div data-content-media-picker hidden></div>${fields('封面图片地址', 'coverUrl', content.coverUrl || '', { max: 2000, hint: '使用 HTTPS 图片地址或以 / 开头的公开图片路径。' })}${fields('封面描述', 'coverAlt', content.coverAlt || '', { max: 200, hint: '描述图片内容，供读屏与图片无法加载时使用。' })}</details>`;
  }
  if (['post','page'].includes(kind)) { const date=content.publicationDate?new Date(content.publicationDate):null; const value=date&&!Number.isNaN(date.valueOf())?new Date(date.getTime()-date.getTimezoneOffset()*60000).toISOString().slice(0,16):''; html += fields('发布时间（本地时间）','publicationDate',value,{type:'datetime-local',hint:'留空保留原发布时间；首次发布使用当前时间。修改只在再次发布后生效，不支持定时发布。'}); }
  if (kind === 'post') html += select('文章分类', 'categoryId', [{ id: '', label: '不指定分类' }, ...(refs.categories || []).map(item => ({ id: item.id, label: item.title + (item.state === 'published' ? '' : '（尚未发布）') }))], content.categoryId || '');
  if (kind === 'post') html += `<fieldset class="b-scope-options"><legend>文章标签（最多30个）</legend>${(refs.tags||[]).map(tag=>`<label><input type="checkbox" name="tagIds" value="${e(tag.id)}" ${(content.tagIds||[]).includes(tag.id)?'checked':''}><span>${e(tag.title)}${tag.state==='published'?'':'（尚未发布）'}</span></label>`).join('')||'<p class="b-field-hint">请先创建文章标签。</p>'}</fieldset>`;
  if (['navigation', 'banner'].includes(kind)) {
    html += select('引用站内内容', 'targetId', [{ id: '', label: '使用下方自定义链接' }, ...(refs.targets || []).filter(item => item.id !== itemId).map(item => ({ id: item.id, label: `${kinds[item.kind] || item.kind} · ${item.title}${item.state === 'published' ? '' : '（尚未发布）'}` }))], content.targetId || '');
    html += fields('自定义链接', 'url', content.url || '', { max: 2000, hint: '选择引用内容时自动跟随公开路径；未选择引用时，填写 HTTPS 或 / 开头的站内地址。' });
    html += select('展示位置', 'placement', kind === 'navigation' ? [{ id: 'header', label: '页首导航' }, { id: 'footer', label: '页脚导航' }] : [{ id: 'home', label: '首页' }], content.placement || (kind === 'navigation' ? 'header' : 'home'));
  }
  html += fields('展示顺序', 'position', content.position ?? 0, { type: 'number', max: 7, hint: '数字越小越靠前；相同顺序由服务器稳定排列。' });
  return html;
}

export function contentFormMarkup(item = {}, refs = {}) {
  const content = item.content || {};
  return `<div class="b-modal-header"><div><h2 id="modal-title">${item.id ? '编辑内容' : '新增内容'}</h2><p>${item.id ? '修改保存为新草稿，公开版本在再次发布后更新。' : '先保存草稿，核对内容与关联项后再发布。'}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="admin-content" ${item.id ? `data-item-id="${e(item.id)}" data-revision="${e(item.revision)}"` : ''}>${item.id ? `<input type="hidden" name="kind" value="${e(item.kind)}"><p class="b-muted">内容类型：${e(kinds[item.kind])}</p>` : select('内容类型', 'kind', Object.entries(kinds).map(([id, label]) => ({ id, label })), 'post')}${fields('标题', 'title', item.title || '', { required: true, max: 200 })}${fields('地址标识', 'slug', item.slug || '', { required: true, max: 180, hint: '使用英文字母、数字与短横线，例如 getting-started。' })}${fields('内容摘要', 'description', content.description || '', { textarea: true, max: 1000 })}${fields('正文 / 回答', 'body', content.body || '', { textarea: true, rows: 7, max: 100000, hint: '正文按纯文本安全展示，段落与换行会保留。' })}<div data-content-specific>${specificFields(item.kind || 'post', content, refs, item.id)}</div>${item.id?`<div class="b-section"><button class="ui-button ui-button--secondary" type="button" data-action="admin-content-references" data-item-id="${e(item.id)}">查看引用此内容的条目</button><div data-content-references role="status"></div></div>`:''}<p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions">${item.id?`<a class="ui-button ui-button--secondary" href="/api/admin/content/${encodeURIComponent(item.id)}/preview" target="_blank" rel="noopener">预览已保存草稿</a>`:'<span class="b-field-hint">保存草稿后可以预览。</span>'}<button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button class="ui-button ui-button--primary" type="submit">${item.id ? '保存更改' : '保存草稿'}</button></div></form>`;
}

export function updateContentFields(form, refs) {
  const previous = {...Object.fromEntries(new FormData(form)),tagIds:new FormData(form).getAll('tagIds')};
  form.querySelector('[data-content-specific]').innerHTML = specificFields(form.elements.kind.value, previous, refs || {}, form.dataset.itemId);
}

export function contentPayload(values, form) {
  return { kind: values.kind, slug: values.slug.trim(), title: values.title.trim(), content: { ...(values.publicationDate?{publicationDate:new Date(values.publicationDate).toISOString()}:{}), body: values.body || '', description: (values.description || '').trim(), seoTitle: (values.seoTitle || '').trim(), seoDescription: (values.seoDescription || '').trim(), coverUrl: (values.coverUrl || '').trim(), coverAlt: (values.coverAlt || '').trim(), categoryId: values.categoryId || null, tagIds: values.kind==='post' && form ? new FormData(form).getAll('tagIds') : [], coverMediaId: values.coverMediaId || null, targetId: values.targetId || null, position: Number(values.position || 0), placement: values.placement || 'home', url: values.targetId ? '' : (values.url || '').trim() } };
}

export function navigateContentFilter(context) {
  const toolbar = document.querySelector('.b-content-toolbar');
  const params = new URLSearchParams({state:toolbar.querySelector('[name=contentStateFilter]').value,sort:toolbar.querySelector('[name=contentSort]').value});
  for(const [name,param] of [['contentKindFilter','kind'],['contentQuery','q'],['contentCategory','categoryId'],['contentTag','tagId']]){const value=toolbar.querySelector(`[name=${name}]`).value.trim();if(value)params.set(param,value);}
  context.navigate('admin/content?' + params);
}

export async function loadMoreContent(trigger, context) {
  const current = context.state.resource;
  if (!current.nextCursor) return;
  trigger.disabled = true;
  try {
    const params = new URLSearchParams({...current.filters,cursor:current.nextCursor});
    const next = await api('/admin/content?' + params);
    if (context.state.resource !== current) return;
    const ids = new Set(current.items.map(item => item.id));
    current.items.push(...next.items.filter(item => !ids.has(item.id))); current.nextCursor = next.nextCursor || null;
    context.render();
  } finally { if (trigger.isConnected) trigger.disabled = false; }
}
