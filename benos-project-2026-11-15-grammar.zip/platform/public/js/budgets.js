import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const money = value => Number.isSafeInteger(value) ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 6 }).format(value / 1e6) : '—';
const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
const states = { reserved: '额度已预留', dispatching: '请求处理中', uncertain: '费用待核对', preparing: '准备中', running: '生成中', succeeded: '已完成', failed: '未完成' };
const action = (text, name, attrs = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="budget-${name}" ${attrs}>${text}</button>`;
const field = (label, name, value = '', options = {}) => `<label class="b-field"><span>${label}</span>${options.textarea ? `<textarea name="${name}" required minlength="${options.min || 3}" maxlength="${options.max || 2000}" rows="4">${e(value)}</textarea>` : `<input type="${options.number ? 'number' : 'text'}" name="${name}" value="${e(value)}" required ${options.number ? 'min="0" step="0.000001"' : `maxlength="${options.max || 200}"`} ${options.readonly ? 'readonly' : ''}>`}${options.hint ? `<small class="b-field-hint">${options.hint}</small>` : ''}</label>`;
const confirm = text => `<label class="b-confirm-checkbox"><input type="checkbox" name="confirmed" required><span>${text}</span></label>`;
const footer = text => `<p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">${text}</button></div>`;
const modal = (title, description, name, body, attrs = '') => `<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${description}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="budget-${name}" ${attrs}>${body}</form>`;

function toMicros(value, zero = false) {
  if (!/^\d+(?:\.\d{1,6})?$/.test(String(value))) throw new Error('请输入美元金额，最多 6 位小数。');
  const [whole, decimal = ''] = String(value).split('.');
  const amount = Number(BigInt(whole) * 1000000n + BigInt(decimal.padEnd(6, '0')));
  if (!Number.isSafeInteger(amount) || amount > 100000000000 || amount < (zero ? 0 : 1)) throw new Error('金额超出允许范围。');
  return amount;
}

export async function loadBudgetResource(options) {
  const workflowPage = Math.max(1, Math.min(10000, Number(new URLSearchParams(location.hash.split('?')[1] || '').get('workflowPage')) || 1));
  const reads = await Promise.allSettled([api('/admin/budgets', options), api('/admin/ai-jobs', options), api('/admin/image-jobs', options), api(`/ai/admin/workflow-steps?state=uncertain&page=${workflowPage}&limit=50`, options)]);
  const failure = reads.find(item => item.status === 'rejected');
  if (failure) throw failure.reason;
  return { ...reads[0].value, jobs: (reads[1].value.items || []).map(job => ({ ...job, jobKind: 'text' })), imageJobs: (reads[2].value.items || []).map(job => ({ ...job, jobKind: 'image' })), workflowJobs: (reads[3].value.items || []).map(job => ({ ...job, created_at: job.createdAt, error_code: job.errorCode, jobKind: 'workflow' })), workflowPage, workflowHasMore: reads[3].value.hasMore };
}

export function renderBudgetPage(data, user) {
  const owner = user.role === 'owner';
  const unresolved = [...data.jobs, ...data.imageJobs, ...(data.workflowJobs || [])].filter(job => job.state === 'uncertain');
  return `<section class="s-page"><div class="page-intro"><div><h1>API 预算与用量</h1><p>供应商预算与会员额度分别核验，任何一侧不足时停止新请求。</p></div>${action(icon('plus') + '登记供应商实充', 'fund', owner ? '' : 'disabled title="仅平台所有者可登记"', true)}</div><div class="b-notice">${icon('shield-check')}<div><strong>按真实充值记录登记预算</strong><p>这里记录平台已经购买的 API 额度，不会代为给供应商充值，也不等于供应商实时余额。同一账户的文本与图片服务必须共用预算池。</p></div></div><div class="b-section b-plan-grid">${data.pools.length ? data.pools.map(pool => `<article class="b-card"><div class="b-section-heading"><h2>${e(pool.provider_id)}</h2><span class="b-badge">${pool.enabled ? '允许新请求' : '已暂停新请求'}</span></div><span class="b-eyebrow">剩余可分配预算</span><strong class="b-balance">${money(pool.funded_micros - pool.consumed_micros - pool.reserved_micros - pool.safety_micros)}</strong><dl class="b-config-facts"><div><dt>登记预算净额</dt><dd>${money(pool.funded_micros)}</dd></div><div><dt>已结算用量</dt><dd>${money(pool.consumed_micros)}</dd></div><div><dt>请求预留</dt><dd>${money(pool.reserved_micros)}</dd></div><div><dt>安全保留</dt><dd>${money(pool.safety_micros)}</dd></div></dl><p class="b-muted">更新于 ${date(pool.updated_at_ms)}</p><div class="b-table-actions">${action('追加实充记录', 'fund', `data-provider="${e(pool.provider_id)}" ${owner ? '' : 'disabled'}`)}${action('登记预算减额', 'debit', `data-provider="${e(pool.provider_id)}" ${owner ? '' : 'disabled'}`)}${action('查看减额记录', 'debits', `data-provider="${e(pool.provider_id)}"`)}${action(pool.enabled ? '暂停新请求' : '恢复新请求', 'toggle', `data-provider="${e(pool.provider_id)}" ${owner ? '' : 'disabled'}`)}</div></article>`).join('') : '<div class="b-empty">'+icon('credit-card')+'<h2>尚未登记供应商预算</h2><p>核对真实充值凭据后，登记相应预算池。未配置预算时不会发送付费请求。</p></div>'}</div><section class="b-section"><div class="b-section-heading"><div><h2>待核对的 AI 费用</h2><p>只有供应商账单或请求记录能够确认实际费用后，才能结算或释放预留额度。</p></div>${action('刷新记录', 'refresh')}</div>${unresolved.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>任务</th><th>状态</th><th>供应商请求</th><th>操作</th></tr></thead><tbody>${unresolved.map(job => `<tr><td><code>${e(job.id)}</code><small>${job.jobKind === 'image' ? '图片生成' : job.jobKind === 'workflow' ? '设计工作流 · 第 ' + job.ordinal + ' 轮' : '文本设计'} · ${date(job.created_at)}</small></td><td>${e(states[job.state])}<small>${e(job.error_code || '')}</small></td><td><code>${e(job.provider_response_id || job.workflowId || '尚无响应编号')}</code></td><td>${action('录入核对结论', 'reconcile', `data-job-id="${e(job.id)}" data-job-kind="${e(job.jobKind)}" ${owner ? '' : 'disabled'}`)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="b-inline-empty">没有需要人工核对的 AI 费用。</div>'}</section>${(data.workflowPage > 1 || data.workflowHasMore) ? `<div class="b-pagination"><p>工作流待核对记录 · 第 ${data.workflowPage} 页</p>${data.workflowPage > 1 ? action('上一页', 'workflow-page', `data-page="${data.workflowPage - 1}"`) : ''}${data.workflowHasMore ? action('下一页', 'workflow-page', `data-page="${data.workflowPage + 1}"`) : ''}</div>` : ''}<section class="b-section"><div class="b-section-heading"><div><h2>未结算请求</h2><p>最近 100 条预留、处理中及结果未知的请求。</p></div></div>${data.reservations.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>请求</th><th>预算池</th><th>预留额度</th><th>状态</th><th>时间</th></tr></thead><tbody>${data.reservations.map(item => `<tr><td><code>${e(item.id)}</code><small>${e(item.user_id)}</small></td><td>${e(item.provider_id)}</td><td>${money(item.amount_micros)}</td><td>${e(states[item.state] || item.state)}</td><td>${date(item.created_at_ms)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="b-inline-empty">当前没有未结算请求。</div>'}</section></section>`;
}

export async function handleBudgetAction(name, trigger, context) {
  if (name === 'budget-refresh') { await context.reload(); return true; }
  if (name === 'budget-workflow-page') { context.navigate('admin/budgets?workflowPage=' + encodeURIComponent(trigger.dataset.page)); return true; }
  if (name === 'budget-debits') {
    const provider = trigger.dataset.provider;
    trigger.disabled = true;
    try {
      const data = await api(`/admin/budgets/${encodeURIComponent(provider)}/debits`);
      context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">预算减额记录</h2><p>${e(provider)}</p></div><button class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><div class="b-modal-body">${data.items.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>金额与凭据</th><th>原因</th><th>时间</th></tr></thead><tbody>${data.items.map(item => `<tr><td>${money(item.amount_micros)}<small>${e(item.reference_id)}</small></td><td class="b-table-prose">${e(item.reason)}</td><td>${date(item.created_at_ms)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="b-inline-empty">暂无预算减额记录。</p>'}</div>`);
    } finally { if (trigger.isConnected) trigger.disabled = false; }
    return true;
  }
  if (context.state.user.role !== 'owner') throw new Error('只有平台所有者可以修改预算与核对费用。');
  const pool = context.state.resource.pools.find(item => item.provider_id === trigger.dataset.provider);
  if (name === 'budget-fund') {
    context.showModal(modal('登记供应商实充', '请先在供应商完成充值并核对到账凭据，再登记实际金额。同一收据重复提交不会重复加款。', 'fund', `${field('预算池 ID', 'provider', pool?.provider_id || 'openai-main', { readonly: !!pool, max: 100, hint: '与 AI 服务配置中的供应商预算池 ID 完全一致。' })}${field('实际到账金额（美元）', 'amount', '', { number: true })}${field('供应商充值收据编号', 'referenceId', '', { hint: '使用供应商真实且唯一的收据或交易编号，重试时保留同一编号。' })}${field('登记原因', 'reason', '', { textarea: true, max: 500 })}${confirm('我已核对供应商实际到账金额与收据，此操作只登记已经购买的预算。')}${footer('确认登记实充')}`));
  } else if (name === 'budget-debit') {
    if (!pool) throw new Error('预算池已变化，请刷新。');
    const available = pool.funded_micros - pool.consumed_micros - pool.reserved_micros - pool.safety_micros;
    context.showModal(modal('登记预算减额', '依据供应商真实退款、提现或其他已核实的余额减少记录调整平台预算。不能动用已预留额度，也不修改会员余额。', 'debit', `<p class="b-confirm-title">${e(pool.provider_id)} · 当前最多可减少 ${money(available)}</p>${field('实际减少金额（美元）', 'amount', '', { number: true })}${field('供应商唯一凭据编号', 'referenceId')}${field('减少原因', 'reason', '', { textarea: true, max: 500 })}${confirm('已核对供应商真实余额减少凭据。确认从可用预算中扣减，保留所有预留额度。')}${footer('确认登记预算减额')}`, `data-provider="${e(pool.provider_id)}" data-available-micros="${available}"`));
  } else if (name === 'budget-toggle') {
    if (!pool) throw new Error('预算池已变化，请先刷新。');
    context.showModal(modal(pool.enabled ? '暂停新请求' : '恢复新请求', pool.enabled ? '停止从此预算池发起新的付费请求。已发出的请求继续核对结算。' : '恢复后仍会检查用户余额、预算余额和模型计费配置。', 'toggle', `${field('操作原因', 'reason', '', { textarea: true, max: 500 })}${footer('确认变更')}`, `data-provider="${e(pool.provider_id)}" data-enabled="${pool.enabled ? 'false' : 'true'}"`));
  } else if (name === 'budget-reconcile') {
    const job = [...context.state.resource.jobs, ...context.state.resource.imageJobs, ...(context.state.resource.workflowJobs || [])].find(item => item.id === trigger.dataset.jobId && item.jobKind === trigger.dataset.jobKind && item.state === 'uncertain');
    if (!job) throw new Error('任务状态已变化，请先刷新。');
    context.showModal(modal('录入费用核对结论', '核对结论会改变会员与平台额度，请以供应商实际账单为依据。不能仅因请求超时就判定免费。', 'reconcile', `<p class="b-muted">任务 ${e(job.id)}</p><label class="b-field"><span>核对结论</span><select name="outcome" required><option value="">请选择有证据支持的结论</option><option value="confirmed_cost">已确认实际费用</option><option value="confirmed_unused">已确认未产生任何费用</option></select></label>${field('实际费用（美元）', 'amount', '', { number: true, hint: '确认无费用时填写 0；确认有费用时填写账单实际金额。' })}${field('核对依据', 'evidence', '', { textarea: true, min: 10, max: 2000, hint: '记录账单编号、供应商请求编号、核对时间与结论。不要粘贴 API 密钥。' })}${confirm('我已核对供应商记录，以上结论和金额准确，可以据此结算或释放原请求额度。')}${footer('提交核对结论')}`, `data-job-id="${e(job.id)}" data-job-kind="${e(job.jobKind)}"`));
  } else return false;
  return true;
}

export async function submitBudgetForm(name, form, values, context) {
  if (context.state.user.role !== 'owner') throw new Error('只有平台所有者可以修改预算与核对费用。');
  if (name === 'budget-fund') {
    if (!values.confirmed) throw new Error('请确认已核对实际到账凭据。');
    if (!/^[A-Za-z0-9_-]{1,100}$/.test(values.provider.trim())) throw new Error('预算池 ID 只支持字母、数字、短横线和下划线。');
    await api(`/admin/budgets/${encodeURIComponent(values.provider.trim())}/funding`, { method: 'POST', body: { amountMicros: toMicros(values.amount), referenceId: values.referenceId.trim(), reason: values.reason.trim(), confirmedProviderDeposit: true } });
  } else if (name === 'budget-debit') {
    if (!values.confirmed) throw new Error('请确认已核对供应商真实凭据。');
    const amountMicros = toMicros(values.amount);
    if (amountMicros > Number(form.dataset.availableMicros)) throw new Error('减额超过当前可用预算，不能占用已预留额度。');
    await api(`/admin/budgets/${encodeURIComponent(form.dataset.provider)}/debit`, { method: 'POST', body: { amountMicros, referenceId: values.referenceId.trim(), reason: values.reason.trim(), confirmedProviderWithdrawal: true } });
  } else if (name === 'budget-toggle') {
    await api(`/admin/budgets/${encodeURIComponent(form.dataset.provider)}`, { method: 'PATCH', body: { enabled: form.dataset.enabled === 'true', reason: values.reason.trim() } });
  } else if (name === 'budget-reconcile') {
    if (!values.confirmed) throw new Error('请先核对供应商证据并确认结论。');
    const amount = toMicros(values.amount, true);
    if (values.outcome === 'confirmed_unused' && amount !== 0) throw new Error('确认未产生费用时，实际费用应为 0。');
    if (!['confirmed_unused', 'confirmed_cost'].includes(values.outcome)) throw new Error('请选择核对结论。');
    const endpoint = form.dataset.jobKind === 'workflow' ? '/ai/admin/workflow-steps' : `/admin/${form.dataset.jobKind === 'image' ? 'image-jobs' : 'ai-jobs'}`;
    await api(`${endpoint}/${encodeURIComponent(form.dataset.jobId)}/reconcile`, { method: 'POST', body: { outcome: values.outcome, evidence: values.evidence.trim(), ...(values.outcome === 'confirmed_cost' ? { actualMicros: amount } : {}) } });
  } else return false;
  context.closeModal(); await context.reload(); context.notify(name === 'budget-fund' ? '实充记录已登记，预算已更新' : name === 'budget-debit' ? '已登记预算减额，原请求预留额度保持不变' : name === 'budget-toggle' ? '预算池状态已更新' : '已按核对结论处理原请求额度'); return true;
}
