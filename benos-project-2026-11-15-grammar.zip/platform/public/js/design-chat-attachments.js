import { uploadProjectMedia } from './media.js';

const uploads = new WeakMap();
const accepted = new Set(['image/png', 'image/jpeg', 'image/webp']);
const maxBytes = 6 * 1024 * 1024;

export function isChatUploadPending(form) {
  const upload = uploads.get(form);
  return Boolean(upload?.pending || upload?.error);
}

function checkLimits(assets, selected, files) {
  if (files.some(file => !accepted.has(file.type) || !file.size)) throw new Error('请选择有内容的 PNG、JPEG 或 WebP 图片。');
  if (selected.length + files.length > 3) throw new Error('每条消息最多使用 3 张参考图，请减少图片后重选。');
  const currentBytes = selected.reduce((sum, id) => sum + (assets.find(asset => asset.id === id)?.byteSize || 0), 0);
  if (files.reduce((sum, file) => sum + file.size, currentBytes) > maxBytes) throw new Error('参考图合计最多 6 MiB，请压缩或减少图片后重选。');
}

// The same file can be selected again after navigation or a lost acknowledgement.
// Keep only its idempotency key in session storage, never the image bytes.
async function requestFor(entry, owner, project) {
  if (entry.key) return;
  const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', await entry.file.arrayBuffer()));
  const digest = Array.from(hash, byte => byte.toString(16).padStart(2, '0')).join('');
  entry.slot = JSON.stringify(['benos-reference-upload', owner, project, digest, entry.name]);
  let original;
  try { original = sessionStorage.getItem(entry.slot); } catch { /* In-memory retry remains available. */ }
  entry.key = original || crypto.randomUUID();
  try { sessionStorage.setItem(entry.slot, entry.key); } catch { /* Storage may be disabled. */ }
}
function forgetRequest(entry) {
  try { sessionStorage.removeItem(entry.slot); } catch { /* Storage may be disabled. */ }
}

export function mountChatAttachments(form, context, handlers) {
  if (uploads.has(form)) return;
  const owner = context.state.user.id, project = context.state.resource.project.id;
  const state = {pending:false, error:'', queue:[], progressText:''};
  uploads.set(form, state);
  const current = () => form.isConnected && context.state.user?.id === owner &&
    context.state.resource?.project?.id === project && context.state.route === 'design/' + project;
  const report = () => {
    if (current()) handlers.onStatus({
      pending:state.pending, error:state.error, progressText:state.progressText,
      canRetry:!state.pending && state.queue.length > 0, blocked:isChatUploadPending(form),
    });
  };

  async function upload(files) {
    if (!current()) return;
    const additions = (files || []).map(file => ({file, name:file.name || '参考图.' + file.type.split('/')[1]}));
    if (state.pending) {
      if (!additions.length) return;
      try {
        checkLimits(context.state.resource.visual.assets, handlers.getSelected(), [...state.queue, ...additions].map(entry => entry.file));
        state.queue.push(...additions);
        state.error = '';
      } catch (error) {
        state.error = error.message;
      }
      report();
      return;
    }
    state.pending = true;
    state.error = '';
    try {
      if (files) state.queue = [];
      checkLimits(context.state.resource.visual.assets, handlers.getSelected(), files || state.queue.map(entry => entry.file));
      if (files) state.queue = additions;
      while (state.queue.length && current()) {
        const entry = state.queue[0];
        state.progressText = '正在上传 ' + entry.name;
        report();
        await requestFor(entry, owner, project);
        if (!current()) return;
        const asset = await uploadProjectMedia(project, entry.file, entry.key, entry.name);
        if (!current()) return;
        if (asset.state === 'deleted' || asset.deletedAt) {
          forgetRequest(entry);
          entry.key = null;
          throw new Error('原素材已移入回收站，可重新上传这张图片。');
        }
        if (!asset.id || asset.projectId !== project || asset.state !== 'ready' || !accepted.has(asset.mimeType) ||
            asset.byteSize !== entry.file.size) throw new Error('暂未收到有效的图片回执，请重试。');
        const assets = context.state.resource.visual.assets;
        if (!assets.some(item => item.id === asset.id)) assets.unshift(asset);
        const selected = handlers.getSelected();
        if (!selected.includes(asset.id)) {
          // Library selections may have changed while the file was uploading.
          checkLimits(assets, selected, [entry.file]);
          handlers.onSelected([...selected, asset.id]);
        }
        forgetRequest(entry);
        state.queue.shift();
      }
    } catch (error) {
      state.error = error.message || '图片上传未完成，请重试。';
    } finally {
      state.pending = false;
      state.progressText = '';
      report();
    }
  }

  form.addEventListener('change', event => {
    if (!event.target.matches('[data-chat-upload-input]')) return;
    const files = Array.from(event.target.files);
    event.target.value = '';
    if (files.length) void upload(files);
  });
  form.addEventListener('paste', event => {
    const data = event.clipboardData;
    if (!data || event.target !== form.elements.prompt) return;
    const files = Array.from(data.items).filter(item => item.kind === 'file').map(item => item.getAsFile()).filter(Boolean);
    if (files.length) {
      if (!data.getData('text/plain')) event.preventDefault();
      void upload(files);
    }
  });
  form.addEventListener('dragover', event => {
    if (Array.from(event.dataTransfer?.types || []).includes('Files')) event.preventDefault();
  });
  form.addEventListener('drop', event => {
    const files = Array.from(event.dataTransfer?.files || []);
    if (files.length) { event.preventDefault(); void upload(files); }
  });
  form.addEventListener('click', event => {
    if (event.target.closest('[data-chat-upload-retry]') && state.queue.length) void upload();
    if (event.target.closest('[data-chat-upload-dismiss]') && !state.pending) {
      state.queue = [];
      state.error = '';
      report();
    }
  });
}
