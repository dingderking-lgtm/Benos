import { icon, escapeHtml as esc } from './icons.js';
import { normalizeDirection, designPalettes, renderDirectionSummary } from './workspace-direction.js';

// Design references from the approved interactive preview. These are examples,
// never customer projects, saved designs, or evidence of a completed AI request.
export const dashboardInspirations = Object.freeze([
  { id: 'atelier', name: 'ATELIER', description: '建筑、空间与独立创意', type: 'studio', style: '大胆创意', accent: 'charcoal', typography: 'editorial', layout: 'centered', prompt: '为建筑与创意工作室 ATELIER 设计一个英文品牌网站，以真实建筑摄影、大幅留白和编辑式衬线标题呈现空间作品、设计理念与服务，采用居中首屏构图。' },
  { id: 'forma', name: 'FORMA', description: '自然材质与生活美学', type: 'home', style: '温暖自然', accent: 'sand', typography: 'editorial', layout: 'split', prompt: '为生活方式品牌 FORMA 设计一个温暖的英文网站，使用自然家居摄影、暖沙色与优雅的衬线排版，展示家居系列、品牌故事和日常生活灵感。' },
  { id: 'axiom', name: 'AXIOM', description: '精密制造与现代品牌', type: 'manufacturing', style: '专业商务', accent: 'sage', typography: 'sans', layout: 'split', prompt: '为精密制造品牌 AXIOM 设计专业的英文企业网站，用真实工业摄影、清晰的无衬线排版和克制的森林绿，展示制造能力、工程方案与企业实力。' },
]);

const visuals = {
  atelier: { image: '/assets/studio.webp', brand: 'ATELIER', nav: 'Projects · Studio · Contact', kicker: 'ARCHITECTURE & CREATIVE DIRECTION', headline: 'Spaces,<br>with a soul.', caption: 'A different way of seeing.', index: '01 / SELECTED WORK' },
  forma: { image: '/assets/interior.webp', brand: 'forma', nav: 'Collection · Our story · Journal', kicker: 'OBJECTS FOR EVERYDAY LIVING', headline: 'Life, beautifully<br>considered.', caption: 'Room for a quieter life.', index: 'THE LIVING COLLECTION' },
  axiom: { image: '/assets/manufacturing.webp', brand: 'AXIOM', nav: 'Capabilities · About · Contact', kicker: 'PRECISION IN EVERY POSSIBILITY', headline: 'Made for<br>what’s next.', caption: 'Engineered with intention.', index: 'DISCOVER OUR CRAFT' },
};

function websiteExcerpt(example) {
  const visual = visuals[example.id];
  return `<span class="px-site px-site--${example.id}" aria-hidden="true"><span class="px-site-header"><span class="px-site-brand">${visual.brand}</span><span class="px-site-nav">${visual.nav}</span><span class="px-site-menu"><i></i><i></i></span></span><span class="px-site-photograph"><img src="${visual.image}" alt="" width="1200" height="${example.type === 'home' ? '1200' : '675'}" loading="lazy" draggable="false"><span class="px-photo-shade"></span><span class="px-site-story"><span class="px-site-kicker">${visual.kicker}</span><span class="px-site-headline">${visual.headline}</span><span class="px-site-cta">${visual.caption}<span>↗</span></span></span><span class="px-site-index">${visual.index}</span></span></span>`;
}

function renderHeroStack() {
  return `<div class="creation-showcase px-hero-stack" role="group" aria-label="探索三个网站设计参考">${dashboardInspirations.map(example => `<button type="button" class="px-hero-card px-hero-card--${example.id}" data-action="workspace-inspiration" data-id="${example.id}" aria-label="查看 ${example.name} 设计参考，${example.description}" title="查看 ${example.name} 设计参考">${websiteExcerpt(example)}</button>`).join('')}</div>`;
}

export function renderDashboardInspirations() {
  return `<section class="px-gallery" aria-labelledby="px-gallery-title"><header class="px-gallery-heading"><div><span class="px-gallery-kicker">MADE WITH IMAGINATION</span><h2 id="px-gallery-title">从灵感，开始你的下一个网站</h2></div><a class="px-gallery-more" href="#inspiration">探索更多 ${icon('arrow-up-right')}</a></header><div class="px-gallery-grid">${dashboardInspirations.map(example => `<article class="px-example-card"><button type="button" class="px-example-main" data-action="workspace-inspiration" data-id="${example.id}" aria-label="查看 ${example.name} 设计参考，${example.description}">${websiteExcerpt(example)}<span class="px-example-copy"><span class="px-example-title"><strong>${example.name}</strong><span class="px-example-label">设计参考</span></span><span>${example.description}</span></span><span class="px-example-preview-hint" aria-hidden="true">查看参考 ${icon('arrow-up-right')}</span></button><button type="button" class="px-example-use" data-action="workspace-inspiration" data-id="${example.id}" data-intent="use" aria-label="以 ${example.name} 为灵感开始设计" title="以此为灵感开始设计"><span>使用</span>${icon('arrow-up-right')}</button></article>`).join('')}</div></section>`;
}

export function renderDashboardStudioFeature(direction) {
  const current = normalizeDirection(direction || {});
  const palette = designPalettes.find(item => item.id === current.accent);
  return `<section class="px-studio-feature" aria-label="品牌视觉设定"><span class="px-feature-art" aria-hidden="true"><span class="px-feature-palette">${palette.colors.map(color => `<i style="background:${color}"></i>`).join('')}</span><span class="px-feature-type px-feature-type--${current.typography}">Aa</span></span><div class="px-feature-copy"><h2>让每个页面，都有你的品牌气质</h2><div class="px-feature-current">${renderDirectionSummary(current)}</div></div><button type="button" class="px-feature-action" data-action="workspace-style" aria-label="调整品牌视觉设定"><span>视觉设定</span>${icon('sliders')}</button></section>`;
}

export function renderDashboardRecentProjects({ projects = [], query = '', projectCard }) {
  const search = query.trim().toLocaleLowerCase();
  const matches = projects.filter(project => {
    const text = `${project.name || ''} ${project.description || ''}`;
    return text.toLocaleLowerCase().includes(search);
  });
  matches.sort((a, b) => Date.parse(b.updated_at) - Date.parse(a.updated_at));
  if (matches.length) return matches.slice(0, 2).map(project => projectCard(project)).join('');

  const title = search ? '没有找到匹配的项目' : '你的第一个作品，从这里开始';
  const message = search ? '试试其他名称，或前往全部项目查看。' : '在上方写下想法，创建后便可以继续设计。';
  return `<div class="dashboard-project-empty">
    <span class="dashboard-empty-symbol" aria-hidden="true">${icon(search ? 'search' : 'layout-template')}</span>
    <div><h3>${title}</h3><p>${message}</p></div>
  </div>`;
}

/** composerOptions is trusted markup; projectCard is a trusted renderer from app.js. */
export function renderDashboardHome({ user, projects = [], brand, composerOptions = '', projectCard, direction, prompt = '', query = '', showTip = true }) {
  const projectMarkup = renderDashboardRecentProjects({ projects, query, projectCard });
  return `<div class="home-content dashboard-home" aria-label="${esc(brand?.brandName || 'Benos')} 设计工作台"><section class="creation-section" aria-labelledby="home-title">${renderHeroStack()}<h1 id="home-title">欢迎回来，${esc(user?.name || '创作者')}<span class="greeting-dot">.</span></h1><p class="home-subtitle">今天，让灵感成为一个好网站。</p><form id="prompt-form" class="prompt-composer" data-form="quick-project">${showTip ? `<div class="composer-guide"><span>${icon('sparkles')}从一个想法开始，配色、字体和构图都由你定义。</span><button type="button" data-action="workspace-dismiss-tip" aria-label="关闭创作提示">${icon('close')}</button></div>` : ''}<div class="composer-body"><label class="ui-sr-only" for="project-idea">描述你想创建的网站</label><textarea id="project-idea" name="description" placeholder="说说你想设计的网站，或添加一张参考图…" rows="2" maxlength="4000">${esc(prompt)}</textarea>${composerOptions}<div class="composer-toolbar"><div><button type="button" class="composer-tool attach-tool" data-action="workspace-reference" aria-label="添加参考图" title="添加参考图片">${icon('image')}<span>参考图</span></button><button type="button" class="composer-tool style-tool" data-action="workspace-style">${icon('sliders')}<span>视觉设定</span>${icon('chevron-down')}</button></div><div class="composer-submit"><span class="composer-shortcut">Ctrl ↵</span><button class="ui-button ui-button--primary start-design" type="submit" aria-label="开始设计" title="开始设计"><span>开始设计</span>${icon('arrow-up')}</button></div></div><p class="b-form-error" data-form-error role="alert" hidden></p></div></form><div class="composer-caption"><span>你的想法，值得一个好设计。</span><button type="button" data-action="start-library">从模板开始 ${icon('arrow-up-right')}</button></div></section>${renderDashboardInspirations()}${renderDashboardStudioFeature(direction)}<section class="recent-section" aria-labelledby="recent-title"><div class="section-title-row"><div class="recent-title-group"><h2 id="recent-title">继续创作</h2><span>最近的设计项目</span></div><div class="section-tools"><label class="search-field">${icon('search')}<input id="project-search" name="workspace-project-search" type="search" aria-label="搜索已加载项目" placeholder="搜索项目" maxlength="160" value="${esc(query)}"></label><a href="#projects" class="text-button">全部项目 ${icon('arrow-right')}</a></div></div><div id="project-grid" class="project-grid">${projectMarkup}</div></section></div>`;
}
