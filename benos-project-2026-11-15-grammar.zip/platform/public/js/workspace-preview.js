// Full static website compositions from the approved interactive preview.
import { escapeHtml as escape } from './icons.js';

const showcases = {
  atelier: { brand: 'ATELIER', headline: 'Spaces,\nwith a soul.' },
  forma: { brand: 'FORMA', headline: 'Life, beautifully\nconsidered.' },
  axiom: { brand: 'AXIOM', headline: 'Made for\nwhat’s next.' },
};

const palette = {
  sage: { accent: '#354E43', soft: '#F4F6F2', ink: '#222B25' },
  sand: { accent: '#6A5140', soft: '#F7F4EF', ink: '#302A25' },
  charcoal: { accent: '#24262B', soft: '#F3F3F3', ink: '#24262B' }
};

const siteContent = {
  manufacturing: {
    brand: 'axiom.', eyebrow: 'BUILT ON PRECISION',
    headline: 'Precision,\nwithout compromise.',
    intro: 'From the first sketch to the final component. Thoughtful engineering, made for the real world.',
    image: '/assets/manufacturing.webp', imageAlt: 'Precision metal cutting equipment at work', imageHeight: 675,
    imageCaption: 'Every detail. Every dimension.', imageIndex: '01 — OUR CRAFT',
    nav: ['Capabilities', 'Our approach', 'About us'],
    section: 'Complex challenges.\nConsidered solutions.',
    sectionIntro: 'We connect design, materials and manufacturing to help ambitious ideas take their next shape.',
    action: 'Explore capabilities', secondAction: 'Start a conversation',
    cards: [
      ['01', 'Precision components', 'Carefully engineered parts, from early prototypes to repeatable production.'],
      ['02', 'Integrated assembly', 'A considered approach to the details that bring every component together.'],
      ['03', 'Made for your project', 'A collaborative process built around your materials, requirements and ambition.']
    ],
    storyLabel: 'A BETTER WAY TO MAKE', storyTitle: 'Good engineering\nstarts with understanding.',
    storyText: 'The right questions make all the difference. We work closely with your team to turn complex requirements into clear, practical solutions.',
    endTitle: 'Let’s make\nwhat comes next.', endText: 'Your next idea deserves the right manufacturing partner.',
    footerNote: 'Engineered with intention.'
  },
  home: {
    brand: 'form & living', eyebrow: 'MADE FOR THE WAY YOU LIVE',
    headline: 'Thoughtful objects.\nBetter everyday.',
    intro: 'Quiet shapes, honest materials and little details that make a space feel like your own.',
    image: '/assets/interior.webp', imageAlt: 'A warm, naturally lit contemporary living space', imageHeight: 1200,
    imageCaption: 'A little room for everyday life.', imageIndex: 'THE LIVING COLLECTION',
    nav: ['Collections', 'Our philosophy', 'Journal'],
    section: 'For the spaces\nyou make your own.',
    sectionIntro: 'Objects to live with, not just look at. Discover considered pieces for the moments that make a home.',
    action: 'Explore the collection', secondAction: 'Our point of view',
    cards: [
      ['01', 'Slow mornings', 'Natural textures and easy proportions for a softer start to the day.'],
      ['02', 'Gathering places', 'Thoughtful pieces that make a little more room for coming together.'],
      ['03', 'Everyday rituals', 'Small, lasting details that bring a sense of calm to the everyday.']
    ],
    storyLabel: 'LESS, BUT MORE CONSIDERED', storyTitle: 'Made to belong.\nDesigned to stay.',
    storyText: 'We believe the best spaces grow with the people who live in them. Our approach is simple: useful objects, considered materials and a feeling that lasts.',
    endTitle: 'A home that\nfeels like you.', endText: 'Start with one piece. Make room for your own story.',
    footerNote: 'Objects for everyday living.'
  },
  studio: {
    brand: 'North®', eyebrow: 'INDEPENDENT DESIGN STUDIO',
    headline: 'Distinct by design.\nBuilt to matter.',
    intro: 'We shape brands and digital experiences with clear thinking, a curious spirit and a point of view.',
    image: '/assets/studio.webp', imageAlt: 'Minimal concrete architecture with expressive geometry', imageHeight: 675,
    imageCaption: 'Finding a different perspective.', imageIndex: 'PERSPECTIVES — 001',
    nav: ['Selected work', 'What we do', 'The studio'],
    section: 'Clear thinking.\nUnexpected outcomes.',
    sectionIntro: 'From the first conversation to the final detail, we help ambitious teams find their own way forward.',
    action: 'Discover our approach', secondAction: 'Meet the studio',
    cards: [
      ['01', 'Brand & strategy', 'Finding what matters, then making it clear through an identity with its own voice.'],
      ['02', 'Digital experiences', 'Thoughtful websites and products that bring people and brands closer together.'],
      ['03', 'Creative direction', 'A consistent point of view, expressed across every meaningful brand moment.']
    ],
    storyLabel: 'SMALL TEAM. OPEN MINDS.', storyTitle: 'Better work\nstarts with a conversation.',
    storyText: 'We work as an extension of your team: asking questions, exploring possibilities and bringing clarity to the things that make your brand different.',
    endTitle: 'Something good\nstarts here.', endText: 'Tell us what you have in mind. We’ll bring a fresh perspective.',
    footerNote: 'Independent minds. Shared ambition.'
  }
};

/** A script-free srcdoc. Explicit fragment URLs keep navigation inside the preview. */
export function previewDocument(project = {}) {
  const type = Object.hasOwn(siteContent, project.type) ? project.type : 'manufacturing';
  const typography = project.typography === 'editorial' ? 'editorial' : 'sans';
  const layout = project.layout === 'centered' ? 'centered' : 'split';
  const caseId = project.showcase || project.id;
  const showcase = Object.hasOwn(showcases, caseId) ? caseId : '';
  const reference = showcases[showcase];
  const content = siteContent[type];
  const colors = Object.hasOwn(palette, project.accent) ? palette[project.accent] : palette.sage;
  const title = escape(project.name || '网站设计');
  const multiline = value => escape(value).replace(/\r?\n/g, '<br>');
  const headline = multiline(project.headline || reference?.headline || content.headline);
  const brand = escape(typeof project.brand === 'string' && project.brand.trim() ? project.brand.trim().slice(0, 60) : reference?.brand || content.brand);
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title} · 网站设计预览</title>
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'self' 'unsafe-inline'; img-src 'self'; font-src 'self'; object-src 'none'; connect-src 'none'; form-action 'none'; base-uri 'none'">
<link rel="stylesheet" href="/styles/fonts.css">
<style>
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#fff;color:${colors.ink};font:14px/1.65 Inter,'Studio Sans SC',system-ui,sans-serif;-webkit-font-smoothing:antialiased;--accent:${colors.accent};--soft:${colors.soft};--muted:#717171}a{color:inherit;text-decoration:none}button,input,textarea{font:inherit}a:focus-visible{outline:2px solid var(--accent);outline-offset:5px}img{display:block;max-width:100%;height:auto}h1,h2,h3,p,figure{margin:0}.wrap{width:min(1240px,calc(100% - 112px));margin-inline:auto}.site-header{min-height:94px;display:flex;align-items:center;justify-content:space-between;gap:28px}.brand{display:inline-flex;align-items:center;gap:11px;flex-shrink:0}.brand-mark{display:grid;grid-template-columns:repeat(2,5px);gap:3px;transform:rotate(-8deg)}.brand-mark i{width:5px;height:5px;background:var(--accent);border-radius:1px}.brand-mark i:last-child{opacity:.35}.brand-name{font-size:27px;letter-spacing:-1.5px;font-weight:650;line-height:1}.nav{display:flex;align-items:center;gap:28px;font-size:12px;font-weight:450}.nav a{transition:opacity 150ms}.nav a:hover{opacity:.6}.nav-contact{display:inline-flex;align-items:center;gap:20px;margin-left:8px}.nav-contact .arrow{font-size:17px}.hero{padding:66px 0 74px}.hero-grid{display:grid;grid-template-columns:1fr 1.04fr;gap:7%;align-items:center}.eyebrow{display:flex;align-items:center;gap:9px;color:var(--accent);font-size:10px;font-weight:600;letter-spacing:1.55px;line-height:1.7}.hero .eyebrow:before{content:'';width:5px;height:5px;background:var(--accent);border-radius:50%;flex-shrink:0}.hero h1{font-size:clamp(43px,5.2vw,76px);font-weight:500;letter-spacing:-3.5px;line-height:1.04;margin:24px 0;overflow-wrap:break-word}.intro{max-width:350px;color:#6C706C;font-size:14px;line-height:1.85}.hero-actions{display:flex;align-items:center;flex-wrap:wrap;gap:20px;margin-top:30px}.button{display:inline-flex;align-items:center;justify-content:center;gap:24px;min-height:44px;padding:12px 18px;background:var(--accent);color:#fff;border-radius:4px;font-size:12px;font-weight:500;line-height:1.5}.button .arrow{font-size:17px;line-height:1}.text-link{display:inline-flex;align-items:center;gap:14px;font-size:12px;font-weight:500}.hero-art{min-width:0}.hero-image{position:relative;width:100%;background:var(--soft);border-radius:2px;overflow:hidden}.hero-image img{width:100%;height:auto;object-fit:contain}.image-note{display:flex;align-items:center;justify-content:space-between;gap:16px;padding-top:14px;color:var(--muted);font-size:10px;line-height:1.6}.image-note span:last-child{font-size:9px;letter-spacing:1px;white-space:nowrap}.hero-caption{display:flex;justify-content:space-between;gap:20px;margin-top:72px;padding-top:19px;border-top:1px solid #ECECE8;font-size:11px;color:var(--muted)}.hero-caption strong{font-weight:500;color:var(--accent)}.section{padding:72px 0 82px}.section-head{display:grid;grid-template-columns:1fr .75fr;gap:72px;align-items:end}.section h2{margin-top:18px;font-size:clamp(30px,3.4vw,46px);font-weight:500;letter-spacing:-1.8px;line-height:1.13}.section-intro{max-width:340px;justify-self:end;color:var(--muted);font-size:14px;line-height:1.85}.capabilities{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:40px;margin-top:52px}.capability{padding-top:20px;border-top:1px solid #E6E7E2}.number{font-size:11px;color:var(--muted)}.capability h3{margin:31px 0 12px;font-size:18px;font-weight:500;letter-spacing:-.5px}.capability p{color:var(--muted);font-size:13px;line-height:1.85;max-width:270px}.story{background:var(--soft)}.story-grid{display:grid;grid-template-columns:.55fr 1fr;gap:12%;padding-block:76px}.story-index{display:flex;align-items:flex-start;justify-content:space-between;padding-top:8px}.story-index .large-index{font-size:56px;font-weight:400;letter-spacing:-4px;line-height:1;color:var(--accent);opacity:.35}.story-copy h2{font-size:clamp(31px,3.8vw,49px);font-weight:500;letter-spacing:-1.8px;line-height:1.12}.story-copy p{max-width:445px;color:var(--muted);font-size:14px;line-height:1.9;margin:23px 0 26px}.contact{display:flex;align-items:flex-end;justify-content:space-between;gap:48px;padding-block:86px}.contact h2{font-size:clamp(38px,4.8vw,64px);font-weight:500;letter-spacing:-2.5px;line-height:1.08;margin-top:20px}.contact p{margin-top:22px;color:var(--muted);font-size:13px}.contact>.button{flex-shrink:0;margin-bottom:6px}.footer{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-block:30px;border-top:1px solid #ECECE8;color:var(--muted);font-size:11px}.footer-brand{font-size:17px;font-weight:600;letter-spacing:-.7px;color:var(--accent)}.footer-right{display:flex;gap:22px;align-items:center}.home{background:#FBFAF7}.home .brand-mark{display:none}.home .brand-name{font-size:23px;font-weight:500;letter-spacing:-1.1px}.home .hero{padding-top:42px}.home .hero-grid{grid-template-columns:1fr 1.02fr;gap:9%}.home .hero h1{font-size:clamp(43px,5vw,70px);letter-spacing:-3.2px;font-weight:450}.home .hero-image{background:#F2EEE8}.home .hero-caption{margin-top:58px}.home .story{background:#F2EFE8}.studio .brand-mark{display:none}.studio .brand-name{font-size:30px;font-weight:600;letter-spacing:-2px}.studio .hero h1{font-size:clamp(45px,5.4vw,78px);letter-spacing:-4px}.studio .hero-image{background:#E9E9E8}.studio .eyebrow{letter-spacing:1.3px}.studio .hero-grid{grid-template-columns:1.05fr 1fr;gap:6%}.studio .story{background:#F3F3F1}
.hero-copy{min-width:0}.hero h1{overflow-wrap:anywhere}
@media(min-width:1500px){.hero{padding-top:84px;padding-bottom:80px}}
@media(max-width:1050px){.wrap{width:calc(100% - 72px)}.site-header{min-height:82px}.nav{gap:22px;font-size:11px}.nav-contact{gap:12px;margin-left:0}.hero{padding-top:46px;padding-bottom:52px}.hero-grid,.home .hero-grid,.studio .hero-grid{gap:6%}.hero h1{letter-spacing:-2.5px}.home .hero h1,.studio .hero h1{letter-spacing:-2.5px}.hero .eyebrow{font-size:9px;letter-spacing:1.2px}.hero-actions{gap:16px}.intro{font-size:13px}.button{font-size:11px;gap:18px;padding-inline:15px}.text-link{font-size:11px;gap:9px}.hero-caption{margin-top:52px}.image-note{font-size:9px;gap:8px}.image-note span:last-child{font-size:8px}.section{padding-block:54px}.section-head{gap:36px;grid-template-columns:1fr .8fr}.section-intro{font-size:13px}.capabilities{gap:26px;margin-top:40px}.capability h3{font-size:16px}.capability p{font-size:12px}.story-grid{padding-block:60px;gap:9%}.contact{padding-block:64px}}
@media(max-width:760px){.wrap{width:calc(100% - 48px)}.site-header{min-height:76px;gap:18px}.nav a:not(.nav-contact){display:none}.nav-contact{font-size:12px}.hero,.home .hero{padding-top:34px;padding-bottom:38px}.hero-grid,.home .hero-grid,.studio .hero-grid{grid-template-columns:1fr;gap:34px}.hero h1,.home .hero h1,.studio .hero h1{max-width:590px;font-size:clamp(47px,8.7vw,68px);letter-spacing:-3px;margin-block:23px}.intro{max-width:420px;font-size:14px;line-height:1.8}.hero-actions{margin-top:26px}.button{font-size:12px}.text-link{font-size:12px}.hero-art{width:100%}.home .hero-art{width:82%;justify-self:end}.hero-image{border-radius:2px}.image-note{font-size:11px}.image-note span:last-child{font-size:9px}.hero-caption,.home .hero-caption{margin-top:32px;font-size:10px}.section{padding-block:44px 52px}.section-head{grid-template-columns:1fr;gap:24px}.section h2{font-size:36px}.section-intro{justify-self:start;max-width:420px;font-size:14px}.capabilities{gap:24px;margin-top:36px}.capability h3{font-size:16px;line-height:1.4;margin-top:22px}.capability p{font-size:12px}.story-grid{grid-template-columns:.35fr 1fr;gap:10%;padding-block:50px}.story-index{flex-direction:column;gap:28px}.story-index .eyebrow{font-size:8px;letter-spacing:.8px}.story-index .large-index{font-size:45px}.story-copy h2{font-size:35px}.story-copy p{font-size:13px}.contact{padding-block:54px;gap:24px}.contact h2{font-size:43px}.contact p{font-size:12px}.footer{font-size:10px}.footer-right{gap:16px}.footer-right span{display:none}}
@media(max-width:460px){.wrap{width:calc(100% - 40px)}.site-header{min-height:72px}.brand-name{font-size:25px}.home .brand-name{font-size:22px}.studio .brand-name{font-size:28px}.nav-contact{font-size:11px;gap:12px}.hero,.home .hero{padding-top:28px}.hero h1,.home .hero h1,.studio .hero h1{font-size:48px;letter-spacing:-2.6px;line-height:1.06}.hero .eyebrow{font-size:8px;letter-spacing:1.2px}.intro{font-size:13px}.hero-actions{gap:18px}.hero-grid,.home .hero-grid,.studio .hero-grid{gap:32px}.home .hero-art{width:100%}.image-note{font-size:10px}.image-note span:last-child{font-size:8px}.hero-caption>span:last-child{display:none}.section h2{font-size:33px}.capabilities{grid-template-columns:1fr;gap:28px}.capability{padding-top:16px}.capability h3{margin-top:14px;font-size:18px}.capability p{max-width:none;font-size:13px}.story-grid{grid-template-columns:1fr;gap:24px;padding-block:40px}.story-index{flex-direction:row;align-items:center;padding:0}.story-index .eyebrow{font-size:9px}.story-index .large-index{font-size:28px;letter-spacing:-1px}.story-copy h2{font-size:34px}.story-copy p{font-size:13px}.contact{flex-direction:column;align-items:flex-start;padding-block:46px;gap:28px}.contact h2{font-size:43px}.footer{flex-wrap:wrap;gap:12px;padding-block:25px}.footer-brand{font-size:16px}}
.editorial :is(h1,h2,h3,.brand-name,.footer-brand){font-family:Georgia,'Studio Sans SC',serif}
.editorial .hero h1{font-weight:400;letter-spacing:-.045em;line-height:1.08}
.editorial .section h2,.editorial .story-copy h2,.editorial .contact h2{font-weight:400;letter-spacing:-.035em;line-height:1.16}
.editorial .capability h3,.editorial .brand-name,.editorial .footer-brand{font-weight:400;letter-spacing:-.025em}
.centered .hero-grid{grid-template-columns:minmax(0,1fr);gap:48px}
.centered .hero-copy{width:min(100%,960px);margin-inline:auto;text-align:center}
.centered .hero .eyebrow{justify-content:center}
.centered .hero h1{max-width:960px;margin-inline:auto}
.centered .intro{max-width:490px;margin-inline:auto}
.centered .hero-actions{justify-content:center}
.centered .hero-art{width:100%;max-width:1080px;justify-self:center}
.centered .hero-caption{margin-top:40px}
@media(max-width:760px){.centered .hero-grid{gap:32px}.centered .hero-caption{margin-top:28px}}
/* The three inspiration cases keep their photographic opening in the editor. */
.showcase .hero{width:100%;padding:0}.showcase .hero-grid{position:relative;isolation:isolate;display:grid;grid-template-columns:minmax(0,1fr);align-items:center;gap:0;min-height:clamp(540px,70svh,760px)}.showcase .hero-art{position:absolute;inset:0;z-index:-1;width:100%;max-width:none;height:100%}.showcase .hero-image,.showcase .hero-image img{width:100%;height:100%;border-radius:0}.showcase .hero-image img{object-fit:cover;object-position:center}.showcase .hero-art:after{content:'';position:absolute;inset:0;--showcase-shade:color-mix(in srgb,var(--accent) 65%,#101417);background:linear-gradient(90deg,color-mix(in srgb,var(--showcase-shade) 84%,transparent),color-mix(in srgb,var(--showcase-shade) 74%,transparent));pointer-events:none}.showcase .image-note{display:none}.showcase .hero-copy{width:min(1240px,calc(100% - 112px));max-width:none;margin-inline:auto;padding-block:76px;color:#fff;text-align:left}.showcase .hero h1{max-width:850px;font-size:clamp(50px,7vw,100px);letter-spacing:-.05em;margin:24px 0}.showcase .hero .eyebrow,.showcase .hero .intro{color:#fff}.showcase .hero .eyebrow:before{background:currentColor}.showcase .hero .intro{max-width:420px}.showcase .hero .button{background:#fff;color:var(--accent)}.showcase .hero .text-link{color:#fff}.showcase .hero a:focus-visible{outline-color:#fff}.showcase .hero-caption{width:min(1240px,calc(100% - 112px));margin:26px auto 0}.showcase.centered .hero-copy{text-align:center}.showcase.centered .hero h1,.showcase.centered .hero .intro{margin-inline:auto}.showcase-forma .hero-art:after{background:linear-gradient(90deg,rgb(247 243 235 / 94%),rgb(247 243 235 / 64%))}.showcase-forma .hero-image img{object-position:center 60%}.showcase-forma .hero-copy,.showcase-forma .hero .eyebrow,.showcase-forma .hero .intro,.showcase-forma .hero .text-link{color:#302a25}.showcase-forma .hero .button{background:var(--accent);color:#fff}.showcase-forma .hero a:focus-visible{outline-color:#302a25}
@media(max-width:760px){.showcase .hero-grid{min-height:560px}.showcase .hero-copy{width:calc(100% - 48px);padding-block:48px}.showcase .hero h1{font-size:clamp(43px,8.5vw,68px);letter-spacing:-.045em}.showcase .hero-caption{width:calc(100% - 48px);margin-top:24px}}
@media(max-width:460px){.showcase .hero-copy,.showcase .hero-caption{width:calc(100% - 40px)}.showcase .hero-grid{min-height:540px}.showcase .hero h1{font-size:43px}.showcase .hero .intro{font-size:13px}.showcase .hero-actions{gap:16px}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}a{transition:none}}
</style></head><body class="${type} ${typography} ${layout}${showcase ? ' showcase showcase-' + showcase : ''}">
<header class="wrap site-header"><a class="brand" href="about:srcdoc#top" aria-label="${brand} home"><span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i><i></i></span><span class="brand-name">${brand}</span></a><nav class="nav" aria-label="Main navigation"><a href="about:srcdoc#services">${content.nav[0]}</a><a href="about:srcdoc#approach">${content.nav[1]}</a><a href="about:srcdoc#about">${content.nav[2]}</a><a class="nav-contact" href="about:srcdoc#contact">Let’s talk <span class="arrow" aria-hidden="true">↗</span></a></nav></header>
<main id="top"><section class="wrap hero"><div class="hero-grid"><div class="hero-copy"><p class="eyebrow">${content.eyebrow}</p><h1>${headline}</h1><p class="intro">${content.intro}</p><div class="hero-actions"><a class="button" href="about:srcdoc#services">${content.action}<span class="arrow" aria-hidden="true">↗</span></a><a class="text-link" href="about:srcdoc#about">${content.secondAction}<span aria-hidden="true">→</span></a></div></div><figure class="hero-art"><div class="hero-image"><img src="${content.image}" alt="${content.imageAlt}" width="1200" height="${content.imageHeight}" fetchpriority="high"></div><figcaption class="image-note"><span>${content.imageCaption}</span><span>${content.imageIndex}</span></figcaption></figure></div><div class="hero-caption"><span><strong>${content.footerNote}</strong></span><span>Considered from start to finish.</span></div></section>
<section class="wrap section" id="services"><div class="section-head"><div><p class="eyebrow">01 / WHAT WE DO</p><h2>${multiline(content.section)}</h2></div><p class="section-intro">${content.sectionIntro}</p></div><div class="capabilities" id="approach">${content.cards.map(card => `<article class="capability"><span class="number">${card[0]} /</span><h3>${card[1]}</h3><p>${card[2]}</p></article>`).join('')}</div></section>
<section class="story" id="about"><div class="wrap story-grid"><div class="story-index"><p class="eyebrow">${content.storyLabel}</p><span class="large-index" aria-hidden="true">02</span></div><div class="story-copy"><h2>${multiline(content.storyTitle)}</h2><p>${content.storyText}</p><a class="text-link" href="about:srcdoc#contact">A conversation starts here <span aria-hidden="true">↗</span></a></div></div></section>
<section class="wrap contact" id="contact"><div><p class="eyebrow">LET’S BEGIN</p><h2>${multiline(content.endTitle)}</h2><p>${content.endText}</p></div><a class="button" href="about:srcdoc#top">Explore the possibilities <span class="arrow" aria-hidden="true">↗</span></a></section></main>
<footer class="wrap footer"><span class="footer-brand">${brand}</span><div class="footer-right"><span>${content.footerNote}</span><a href="about:srcdoc#top">Back to top ↑</a></div></footer>
</body></html>`;
}
