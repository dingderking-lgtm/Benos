import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

export function uploadProjectMedia(projectId, file, requestKey, fileName = file.name) {
  return api(`/media/projects/${encodeURIComponent(projectId)}/assets`, {
    method: 'POST', raw: true, body: file,
    headers: { 'Content-Type': file.type, 'X-Filename': encodeURIComponent(fileName), 'Idempotency-Key': requestKey },
  });
}

const dates = value => new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium' }).format(new Date(value));
const size = bytes => bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)} MiB` : `${Math.max(1, Math.round(bytes / 1024))} KiB`;
const states = { preparing: '正在检查图片需求', reserved: '已预留生成额度', running: '图片生成中', uncertain: '结果与费用待核对', output_pending: '图片保存待恢复', succeeded: '已保存到素材库', failed: '生成未完成' };
const unfinished = new Set(['preparing', 'reserved', 'running', 'uncertain', 'output_pending']);
const action = (label, name, attrs = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="media-${name}" ${attrs}>${label}</button>`;
const error = '<p class="b-form-error" role="alert" data-form-error hidden></p>';
const acceptedTypes = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/svg+xml', 'application/pdf'];
const describe = asset => asset.mimeType === 'application/pdf' ? `PDF 文档 · ${size(asset.byteSize)}` : `${asset.width} × ${asset.height} · ${size(asset.byteSize)}`;
const pending = new Map();
function storageKey(userId, projectId, kind) { return `benos-media:${userId}:${projectId}:${kind}`; }
function readPending(key) { if (pending.has(key)) return pending.get(key); try { return JSON.parse(sessionStorage.getItem(key) || 'null'); } catch { return null; } }
function writePending(key, value) { if (value) pending.set(key, value); else pending.delete(key); try { if (value) sessionStorage.setItem(key, JSON.stringify(value)); else sessionStorage.removeItem(key); } catch { /* Current-page retries still share a key. */ } }

export async function loadMediaResource(projectId, user, options) {
  const project = encodeURIComponent(projectId);
  const results = await Promise.allSettled([api(`/projects/${project}`, options), api(`/media/projects/${project}/assets?deleted=1`, options), api(`/images/projects/${project}/jobs`, options), api('/images/availability', options)]);
  const failed = results.find(result => result.status === 'rejected');
  if (failed) throw failed.reason;
  const [details, assets, jobs, availability] = results.map(result => result.value);
  const key = storageKey(user.id, projectId, 'image'), request = readPending(key);
  if (request?.jobId && jobs.items.some(job => job.id === request.jobId && !unfinished.has(job.state))) writePending(key, null);
  return { project: details, assets: assets.items || [], jobs: jobs.items || [], availability };
}

export function renderMediaPage(data, user) {
  const { project, assets, jobs, availability } = data;
  const active = assets.filter(asset => asset.state === 'ready'), deleted = assets.filter(asset => asset.state === 'deleted');
  const storageReady = availability.reason !== 'MEDIA_NOT_CONFIGURED';
  const request = readPending(storageKey(user.id, project.id, 'image'));
  const inProgress = jobs.some(job => unfinished.has(job.state));
  const card = asset => `<article class="b-project-card b-card">${asset.mimeType === 'application/pdf' ? `<a class="b-media-document" href="${e(asset.contentUrl)}" download aria-label="下载 ${e(asset.fileName)}">${icon('file-text')}<span>PDF 文档</span><span>下载文件 ${icon('download')}</span></a>` : `<button type="button" data-action="media-preview" data-media-id="${e(asset.id)}" aria-label="预览 ${e(asset.fileName)}" style="display:block;width:100%;padding:0;border:0;background:transparent;cursor:pointer"><img src="${e(asset.contentUrl)}" alt="${e(asset.fileName)}" loading="lazy" width="${asset.width}" height="${asset.height}" style="display:block;width:100%;height:200px;object-fit:contain;border-radius:8px"></button>`}<div class="b-project-info"><div><h3 style="overflow-wrap:anywhere">${e(asset.fileName)}</h3></div><p>${describe(asset)} · ${asset.source === 'generation' ? 'AI 生成' : '已上传'}</p><div class="b-project-meta"><span>${dates(asset.createdAt)}</span>${action('移入回收站', 'delete', `data-media-id="${e(asset.id)}"`)}</div></div></article>`;
  return `<section class="s-page"><header class="page-intro"><div><p class="b-eyebrow">${e(project.name)}</p><h1>项目素材</h1><p>上传品牌图片、SVG 标志或 PDF 文档，管理网站需要的素材。素材仅对你的账号开放。</p></div><a class="ui-button ui-button--secondary" href="#projects/${encodeURIComponent(project.id)}">${icon('arrow-left')}返回项目</a></header><div class="b-project-grid"><section class="b-card"><div class="b-card-heading"><h2>上传素材</h2><p>上传图片、标志或普通静态 PDF。每个文件最多 12 MiB，SVG 最多 1 MiB。</p><details class="b-media-format"><summary>格式与容量说明</summary><p>正式模板发布所引用的素材合计最多 64 MiB；AI 参考图片最多 3 张，合计不超过 6 MiB。图片边长最多 8192，位图最多 1600 万像素；GIF 最多 500 帧，累计解码最多 3200 万像素。</p><p>PDF 作为下载文档保存，不用于图片替换或 AI 参考图。支持传统交叉引用表的静态 PDF；加密、增量更新及对象流文件请先重新导出。</p></details></div>${storageReady ? `<form data-form="media-upload" data-project-id="${e(project.id)}"><label class="b-field"><span>选择素材</span><input type="file" name="imageFile" accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,application/pdf" required></label>${error}<div class="b-form-actions"><button type="submit" class="ui-button ui-button--primary">${icon('upload')}上传素材</button></div></form>` : '<p class="b-notice-text">素材存储尚未启用，请稍后再试。</p>'}</section><section class="b-card"><div class="b-card-heading"><h2>AI 图片生成</h2><p>描述你需要的图片，通过检查后会保存到当前项目。</p></div>${availability.available ? `<form data-form="media-generate" data-project-id="${e(project.id)}"><label class="b-field"><span>图片需求</span><textarea name="prompt" rows="3" minlength="3" maxlength="32000" required ${request || inProgress ? 'readonly' : ''} placeholder="例如：柔和自然光下的品牌产品静物图">${e(request?.prompt || '')}</textarea></label><p class="b-muted">提交前预留本次额度，完成后按实际用量结算。</p>${error}<div class="b-form-actions"><button type="submit" class="ui-button ui-button--primary" ${inProgress ? 'disabled' : ''}>${inProgress ? '请查询原任务' : request ? '查询原请求' : '生成图片'}</button></div></form>` : `<p class="b-notice-text">图片生成尚未启用。</p>${['owner', 'admin'].includes(user.role) && availability.reason === 'IMAGE_BOUND_UNVERIFIED' ? '<p class="b-muted">管理员提示：尚无通过审核的供应商费用硬上限合同，系统不会发送付费图片请求。价格估算不能作为额度上限。</p>' : ''}`}</section></div><section class="b-recent"><div class="b-section-heading"><div><h2>可用素材 <span class="b-muted">${active.length}</span></h2><p>已被设计版本引用的素材会保留，用于历史预览与回滚。</p></div>${action('刷新', 'refresh')}</div>${active.length ? `<div class="b-project-grid">${active.map(card).join('')}</div>` : '<div class="b-empty">'+icon('image')+'<h2>准备网站的第一张图片</h2><p>上传标志、产品图或品牌照片，即可在此预览和管理。</p></div>'}</section>${deleted.length ? `<section class="b-recent b-card"><div class="b-card-heading"><h2>回收站 <span class="b-muted">${deleted.length}</span></h2><p>恢复后可以继续使用原始素材。</p></div><div class="b-table-wrap"><table class="b-table"><thead><tr><th>素材</th><th>大小</th><th>移除时间</th><th>操作</th></tr></thead><tbody>${deleted.map(asset => `<tr><td>${e(asset.fileName)}</td><td>${size(asset.byteSize)}</td><td>${dates(asset.deletedAt)}</td><td>${action('恢复素材', 'restore', `data-media-id="${e(asset.id)}"`)}</td></tr>`).join('')}</tbody></table></div></section>` : ''}${jobs.length ? `<section class="b-recent b-card"><div class="b-section-heading"><div><h2>图片生成记录</h2><p>结果待确认时，请查询原任务，避免重复提交。</p></div>${action('刷新任务', 'refresh')}</div><div class="b-table-wrap"><table class="b-table"><thead><tr><th>提交时间</th><th>状态</th><th>操作</th></tr></thead><tbody>${jobs.map(job => `<tr><td>${dates(job.createdAt)}</td><td>${e(states[job.state] || '等待处理')}${job.errorCode ? `<p class="b-muted">${job.state === 'uncertain' ? '相关额度继续预留，等待费用核对。' : job.state === 'output_pending' ? '费用已结算，原始结果正在等待恢复。' : '任务未完成，请检查额度或联系平台支持。'}</p>` : ''}</td><td>${job.mediaId ? action('查看图片', 'preview', `data-media-id="${e(job.mediaId)}"`) : availability.available && ['uncertain', 'output_pending'].includes(job.state) ? action('核对原任务', 'reconcile', `data-job-id="${e(job.id)}"`) : action('刷新状态', 'refresh')}</td></tr>`).join('')}</tbody></table></div></section>` : ''}</section>`;
}

export async function handleMediaAction(name, trigger, context) {
  if (name === 'media-refresh') { await context.reload(); return true; }
  if (name === 'media-preview') {
    const asset = context.state.resource.assets.find(item => item.id === trigger.dataset.mediaId && item.state === 'ready');
    if (!asset) throw new Error('此素材已移除，请先从回收站恢复。');
    if (asset.mimeType === 'application/pdf') throw new Error('PDF 请使用素材卡片的下载入口。');
    context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">${e(asset.fileName)}</h2><p>${asset.width} × ${asset.height} · ${size(asset.byteSize)}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭预览">${icon('x')}</button></div><div class="b-modal-body"><img src="${e(asset.contentUrl)}" alt="${e(asset.fileName)}" width="${asset.width}" height="${asset.height}" style="display:block;width:100%;height:auto;max-height:65vh;object-fit:contain"></div>`);return true;
  }
  if (name === 'media-delete' || name === 'media-restore') {
    await api(`/media/assets/${encodeURIComponent(trigger.dataset.mediaId)}/${name === 'media-delete' ? 'delete' : 'restore'}`, { method: 'POST', body: {} });
    await context.reload();context.notify(name === 'media-delete' ? '素材已移入回收站' : '素材已恢复');return true;
  }
  if (name === 'media-reconcile') {
    const job = await api(`/images/jobs/${encodeURIComponent(trigger.dataset.jobId)}/reconcile`, { method: 'POST', body: {} });
    await context.reload();context.notify(states[job.state] || '已刷新任务状态');return true;
  }
  return false;
}

export async function submitMediaForm(name, form, values, context) {
  const projectId = form.dataset.projectId || context.state.resource.project.id, userId = context.state.user.id;
  if (name === 'media-upload') {
    const file = form.elements.imageFile.files?.[0];
    if (!file || !file.size || file.size > 12 * 1048576 || !acceptedTypes.includes(file.type)) throw new Error('请选择 12 MiB 以内的 PNG、JPEG、WebP、GIF、安全 SVG 或普通 PDF。');
    if (file.type === 'image/svg+xml' && file.size > 1048576) throw new Error('SVG 最多 1 MiB，请简化图形后上传。');
    const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await file.arrayBuffer())), b => b.toString(16).padStart(2, '0')).join('');
    const key = storageKey(userId, projectId, 'upload');
    let request = readPending(key);
    if (!request || request.sha256 !== digest || request.fileName !== file.name) request = { requestKey: crypto.randomUUID(), sha256: digest, fileName: file.name };
    writePending(key, request);
    await uploadProjectMedia(projectId, file, request.requestKey);
    writePending(key, null);form.reset();await context.reload();context.notify('素材已保存到项目素材库');return true;
  }
  if (name === 'media-generate') {
    if (!context.state.resource.availability.available) throw new Error('图片生成尚未启用。');
    const key = storageKey(userId, projectId, 'image');
    const request = readPending(key) || { prompt: values.prompt.trim(), requestKey: crypto.randomUUID() };
    writePending(key, request);
    const job = await api(`/images/projects/${encodeURIComponent(projectId)}/generate`, { method: 'POST', body: { prompt: request.prompt, requestKey: request.requestKey } });
    if (unfinished.has(job.state)) writePending(key, { ...request, jobId: job.id }); else writePending(key, null);
    await context.reload();context.notify(states[job.state] || '图片任务已提交');return true;
  }
  return false;
}


