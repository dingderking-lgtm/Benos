let csrfToken = '';

export class ApiError extends Error {
  constructor(message, code = 'REQUEST_FAILED', status = 0) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
  }
}

export function setCsrfToken(value) {
  csrfToken = typeof value === 'string' ? value : '';
}

export async function api(path, { method = 'GET', body, signal, headers: extraHeaders = {}, raw = false } = {}) {
  const headers = { Accept: 'application/json', ...extraHeaders };
  if (body !== undefined && !raw) headers['Content-Type'] = 'application/json';
  if (!['GET', 'HEAD'].includes(method) && csrfToken) headers['X-CSRF-Token'] = csrfToken;
  let response;
  try {
    response = await fetch(`/api${path}`, {
      method,
      credentials: 'same-origin',
      cache: 'no-store',
      headers,
      body: body === undefined ? undefined : raw ? body : JSON.stringify(body),
      signal,
    });
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new ApiError('暂时无法连接服务，请检查网络后重试。', 'NETWORK_ERROR');
  }
  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new ApiError('服务未返回有效数据，请稍后重试。', 'INVALID_RESPONSE', response.status);
  }
  if (!response.ok || payload?.ok !== true) {
    const code = payload?.error?.code || 'REQUEST_FAILED';
    const message = payload?.error?.message || '请求未完成，请稍后重试。';
    const error = new ApiError(message, code, response.status);
    if (response.status === 401 && !path.startsWith('/auth/') && path !== '/session') {
      window.dispatchEvent(new CustomEvent('benos:session-expired'));
    }
    throw error;
  }
  return payload.data;
}
