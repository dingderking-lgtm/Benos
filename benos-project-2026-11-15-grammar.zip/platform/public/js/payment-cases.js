import { api } from './api.js';
import { renderCaseEntitlements, handleCaseEntitlementAction, submitCaseEntitlementForm } from './case-entitlements.js';
import { renderCaseCredits, handleCaseCreditAction, submitCaseCreditForm } from './case-credits.js';
import { icon, escapeHtml as e } from './icons.js';

const kinds = { refund: '退款记录', dispute: '拒付 / 争议', payment_review: '支付复核' };
const reviews = { open: '需要跟进', acknowledged: '已记录审核结论' };
const scopes = { ai: '使用 AI', topup: '追加充值', publish: '发布网站', login: '登录账户' };
const actions = { acknowledged: '确认已审核', needs_follow_up: '仍需跟进', restriction: '限制账户权限', restriction_added: '限制账户权限', restrict: '限制账户权限', revoke: '恢复账户权限', restriction_revoked: '恢复账户权限' };
const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
function money(cents, currency) { if (!Number.isSafeInteger(cents)) return '—'; try { return new Intl.NumberFormat('en-US', { style: 'currency', currency: String(currency || 'usd').toUpperCase() }).format(cents / 100); } catch { return `${cents / 100} ${e(currency)}`; } }
const microMoney = value => Number.isSafeInteger(value) ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 6 }).format(value / 1e6) : '—';
const action = (label, name, attrs = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="case-${name}" ${attrs}>${label}</button>`;
const field = (label, name, min = 3, max = 500) => `<label class="b-field"><span>${label}</span><textarea name="${name}" minlength="${min}" maxlength="${max}" rows="3" required></textarea></label>`;
const footer = text => `<p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">${text}</button></div>`;
const modal = (title, description, form, body, attrs = '') => `<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${description}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="case-${form}" data-request-key="${crypto.randomUUID()}" ${attrs}>${body}</form>`;
const notice = `<div class="b-notice">${icon('shield-check')}<div><strong>审核记录与资金结果分别核对</strong><p>记录审核结论不会向支付渠道发起退款，也不会自动冲销会员额度。争议默认只记录；需要限制账户权限时须单独确认，不暂停会员计时。</p></div></div>`;

export async function loadPaymentCases(options) {
  const selected = new URLSearchParams(location.hash.split('?')[1] || '').get('state') || 'open';
  const result = await api('/admin/payment-cases?state=' + encodeURIComponent(selected), options);
  return { ...result, selected };
}

export async function loadPaymentCase(id, options) {
  const base = '/admin/payment-cases/' + encodeURIComponent(id);
  const reads = await Promise.allSettled([api(base, options), api(base + '/credits', options), api(base + '/entitlements', options)]);
  const failure = reads.find(item => item.status === 'rejected'); if (failure) throw failure.reason;
  return { ...reads[0].value, credits: reads[1].value, entitlements: reads[2].value };
}

function renderLegacyCases(data, user) {
  if (!data.legacyItems?.length) return '';
  return `<section class="b-section"><div class="b-section-heading"><div><h2>待迁入的历史审核记录</h2><p>原始记录与处理时间保留；迁入不代表渠道已退款，也不自动调整权益。</p></div>${action('迁入历史记录', 'import-legacy', user?.role === 'owner' ? '' : 'disabled title="仅平台所有者可迁入"')}</div><div class="b-table-wrap"><table class="b-table"><thead><tr><th>原记录</th><th>原因</th><th>原审核状态</th><th>时间</th></tr></thead><tbody>${data.legacyItems.map(item => `<tr><td><code>${e(item.id)}</code><small>${e(item.eventId || '—')}</small></td><td class="b-table-prose">${e(item.reason || '—')}</td><td>${item.state === 'resolved' ? '原记录已结案' : '需要跟进'}</td><td>${date(item.createdAt)}</td></tr>`).join('')}</tbody></table></div></section>`;
}

export function renderPaymentCases(data, user) {
  return `<section class="s-page"><div class="page-intro"><div><h1>退款与支付争议</h1><p>核对支付渠道记录，保存处理依据与人工决策。</p></div>${action('刷新记录', 'refresh')}</div>${notice}${renderLegacyCases(data, user)}<div class="b-content-toolbar"><label class="b-field"><span>审核状态</span><select name="caseStateFilter"><option value="open" ${data.selected === 'open' ? 'selected' : ''}>需要跟进</option><option value="acknowledged" ${data.selected === 'acknowledged' ? 'selected' : ''}>已记录结论</option><option value="all" ${data.selected === 'all' ? 'selected' : ''}>全部记录</option></select></label></div><section class="b-section">${data.items.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>记录</th><th>金额</th><th>渠道状态</th><th>审核状态</th><th>更新</th><th>操作</th></tr></thead><tbody>${data.items.map(item => `<tr><td><strong>${e(kinds[item.kind] || item.kind)}</strong><small>${e(item.providerObjectId)}</small></td><td>${money(item.amountCents, item.currency)}</td><td>${e(item.providerState || '等待渠道核验')}</td><td>${e(reviews[item.reviewState] || item.reviewState)}</td><td>${date(item.updatedAt)}</td><td><a class="ui-button ui-button--secondary" href="#admin/payment-cases/${encodeURIComponent(item.id)}">查看详情</a></td></tr>`).join('')}</tbody></table></div>` : '<div class="b-empty">'+icon('credit-card')+'<h2>当前没有匹配的支付记录</h2><p>支付渠道的退款、争议与待核对事件会显示在这里。</p></div>'}</section></section>`;
}

export function renderPaymentCase(data, user) {
  const item = data.case;
  const canManage = ['owner', 'admin'].includes(user.role);
  const current = restriction => !restriction.revokedAt && (!restriction.endsAt || new Date(restriction.endsAt) > new Date());
  return `<section class="s-page"><a class="b-back" href="#admin/payment-cases">${icon('arrow-left')}返回支付记录</a><div class="page-intro"><div><h1>${e(kinds[item.kind] || '支付复核')}</h1><p>${e(item.providerObjectId)}</p></div><span class="b-badge">${e(reviews[item.reviewState] || item.reviewState)}</span></div>${notice}<div class="b-section b-project-detail-grid"><section class="b-card"><div class="b-card-heading"><h2>渠道记录</h2><p>渠道状态通过事件通知或主动查询更新。</p></div><dl class="b-config-facts"><div><dt>记录金额</dt><dd>${money(item.amountCents, item.currency)}</dd></div><div><dt>渠道状态</dt><dd>${e(item.providerState || '待核验')}</dd></div><div><dt>最近更新</dt><dd>${date(item.updatedAt)}</dd></div><div><dt>AI 额度调整</dt><dd>${item.financialEffectState === 'credit_adjusted' ? `已人工冲销净额 ${microMoney(item.creditAdjustedMicros || 0)}` : '未自动执行'}</dd></div></dl><div class="b-table-actions">${action('刷新支付渠道记录', 'reconcile', canManage ? '' : 'disabled title="仅所有者或管理员可刷新支付渠道"')}${action('记录审核结论', 'decision', '', true)}</div></section><aside class="b-card b-project-facts"><h2>关联信息</h2><dl><div><dt>记录 ID</dt><dd><code>${e(item.id)}</code></dd></div><div><dt>订单 ID</dt><dd><code>${e(item.orderId || '未关联')}</code></dd></div><div><dt>会员 ID</dt><dd>${item.userId ? `<a href="#admin/users/${encodeURIComponent(item.userId)}">${e(item.userId)}</a>` : '未关联'}</dd></div><div><dt>记录版本</dt><dd>${e(item.revision)}</dd></div></dl></aside></div>${renderCaseCredits(data, user)}${renderCaseEntitlements(data, user)}<section class="b-section"><div class="b-section-heading"><div><h2>此记录关联的账户限制</h2><p>功能权限限制与会员计时分开；解除操作仅影响此记录创建的限制。</p></div>${action('限制账户权限', 'restrict', canManage && item.userId ? '' : 'disabled')}</div>${data.restrictions.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>范围</th><th>原因</th><th>有效期</th><th>状态</th><th>操作</th></tr></thead><tbody>${data.restrictions.map(record => `<tr><td>${e(scopes[record.scope] || record.scope)}</td><td class="b-table-prose">${e(record.reason)}</td><td>${date(record.startsAt)}<small>至 ${record.endsAt ? date(record.endsAt) : '人工解除'}</small></td><td>${record.revokedAt ? '已恢复' : current(record) ? '限制中' : '已到期'}</td><td>${current(record) && canManage ? action('恢复此项权限', 'revoke', `data-restriction-id="${e(record.id)}"`) : '—'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="b-inline-empty">没有因这条支付记录创建的账户限制。</div>'}</section><section class="b-section"><div class="b-section-heading"><h2>人工处理记录</h2></div>${data.decisions.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>操作</th><th>依据与原因</th><th>操作人</th><th>时间</th></tr></thead><tbody>${data.decisions.map(record => `<tr><td>${e(actions[record.action] || record.action)}${record.scopes?.length ? `<small>${record.scopes.map(scope => e(scopes[scope] || scope)).join('、')}</small>` : ''}</td><td class="b-table-prose">${e(record.evidence)}${record.reason ? `<small>${e(record.reason)}</small>` : ''}</td><td><code>${e(record.actorId)}</code></td><td>${date(record.createdAt)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="b-inline-empty">尚无人工处理记录。</div>'}</section><section class="b-section"><div class="b-section-heading"><h2>渠道事件记录</h2></div>${data.events.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>事件</th><th>渠道状态</th><th>接收时间</th></tr></thead><tbody>${data.events.map(record => `<tr><td>${e(record.eventType)}<small>${e(record.eventId)}</small></td><td>${e(record.providerState || '—')}</td><td>${date(record.createdAt)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="b-inline-empty">尚无关联事件记录。</div>'}</section></section>`;
}

export async function handleCaseAction(name, trigger, context) {
  if (name.startsWith('case-entitlement-')) return handleCaseEntitlementAction(name, trigger, context);
  if (name.startsWith('case-credit-')) return handleCaseCreditAction(name, trigger, context);
  if (name === 'case-import-legacy') {
    if (context.state.user.role !== 'owner') throw new Error('只有平台所有者可以迁入历史审核记录。');
    trigger.disabled = true;
    try { const result = await api('/admin/payment-cases/import-legacy', { method: 'POST', body: {} }); await context.reload(); context.notify(`已迁入 ${result.importedCount} 条历史审核记录${result.remainingCount ? `，仍有 ${result.remainingCount} 条可继续迁入` : ''}；未执行退款或权益调整`); }
    finally { if (trigger.isConnected) trigger.disabled = false; }
    return true;
  }
  if (name === 'case-refresh') { await context.reload(); return true; }
  const item = context.state.resource.case;
  if (!item) throw new Error('请先打开具体支付记录。');
  if (name === 'case-reconcile') {
    trigger.disabled = true;
    try { await api(`/admin/payment-cases/${encodeURIComponent(item.id)}/reconcile`, { method: 'POST', body: {} }); await context.reload(); context.notify('已刷新渠道记录，请核对当前状态'); }
    finally { if (trigger.isConnected) trigger.disabled = false; }
  } else if (name === 'case-decision') {
    context.showModal(modal('记录审核结论', '此操作只保存处理记录，不会发起退款，也不更改会员额度。', 'decision', `<label class="b-field"><span>处理结论</span><select name="decision" required><option value="">请选择</option><option value="acknowledged">已核对并记录</option><option value="needs_follow_up">仍需继续跟进</option></select></label>${field('核对依据', 'evidence', 10, 2000)}${footer('保存审核记录')}`, `data-case-id="${e(item.id)}" data-revision="${e(item.revision)}"`));
  } else if (name === 'case-restrict') {
    context.showModal(modal('限制账户权限', '只限制所选功能权限，不暂停会员计时；争议记录本身不会自动冻结账户。', 'restrict', `<fieldset class="b-scope-options"><legend>限制范围</legend>${Object.entries(scopes).map(([scope, label]) => `<label><input type="checkbox" name="scopes" value="${scope}"><span>${label}</span></label>`).join('')}</fieldset>${field('限制原因', 'reason')}${field('核对依据', 'evidence', 10, 2000)}<label class="b-field"><span>自动解除时间（可选）</span><input type="datetime-local" name="endsAt"></label><label class="b-confirm-checkbox"><input type="checkbox" name="confirmImpact" required><span>已核对目标会员与所选范围，确认限制相关功能；会员计时继续。</span></label>${footer('确认限制所选权限')}`, `data-case-id="${e(item.id)}" data-revision="${e(item.revision)}"`));
  } else if (name === 'case-revoke') {
    const record = context.state.resource.restrictions.find(row => row.id === trigger.dataset.restrictionId && !row.revokedAt);
    if (!record) throw new Error('限制状态已变化，请刷新后重试。');
    context.showModal(modal('恢复此项权限', `仅解除此支付记录创建的“${e(scopes[record.scope] || record.scope)}”限制，其他限制保留。`, 'revoke', `${field('恢复原因', 'reason')}${field('核对依据', 'evidence', 10, 2000)}<label class="b-confirm-checkbox"><input type="checkbox" name="confirmImpact" required><span>确认恢复此项权限，保留完整处理记录。</span></label>${footer('确认恢复此项权限')}`, `data-case-id="${e(item.id)}" data-restriction-id="${e(record.id)}"`));
  } else return false;
  return true;
}

export async function submitCaseForm(name, form, values, context) {
  if (name === 'case-entitlement') { await submitCaseEntitlementForm(form, values, context); return true; }
  if (name === 'case-credit') { await submitCaseCreditForm(form, values, context); return true; }
  const base = `/admin/payment-cases/${encodeURIComponent(form.dataset.caseId)}`;
  const common = { requestKey: form.dataset.requestKey, evidence: values.evidence.trim() };
  if (name === 'case-decision') await api(base + '/decision', { method: 'POST', body: { ...common, decision: values.decision, expectedRevision: Number(form.dataset.revision) } });
  else if (name === 'case-restrict') {
    const selected = new FormData(form).getAll('scopes');
    if (!selected.length) throw new Error('请选择需要限制的功能。');
    if (!values.confirmImpact) throw new Error('请确认已核对限制影响。');
    await api(base + '/restrictions', { method: 'POST', body: { ...common, scopes: selected, reason: values.reason.trim(), expectedRevision: Number(form.dataset.revision), confirmImpact: true, ...(values.endsAt ? { endsAt: new Date(values.endsAt).toISOString() } : {}) } });
  } else if (name === 'case-revoke') {
    if (!values.confirmImpact) throw new Error('请确认恢复此项权限。');
    await api(base + `/restrictions/${encodeURIComponent(form.dataset.restrictionId)}/revoke`, { method: 'POST', body: { ...common, reason: values.reason.trim(), confirmImpact: true } });
  } else return false;
  context.closeModal(); await context.reload(); context.notify(name === 'case-decision' ? '审核记录已保存，未执行退款或权益冲销' : name === 'case-restrict' ? '账户功能限制已记录，会员计时未暂停' : '此记录关联的权限限制已解除'); return true;
}
