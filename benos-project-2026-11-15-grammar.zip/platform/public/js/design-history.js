import { api } from './api.js';

const histories = new Map();
const storageKey = (userId, projectId) => `benos-design-history:${userId}:${projectId}`;
const validId = value => typeof value === 'string' && value.length > 0 && value.length <= 160;
const validItem = item => validId(item?.beforeVersionId) && validId(item?.afterVersionId);
function save(key, history) { try { localStorage.setItem(key, JSON.stringify(history)); } catch { /* The current session still retains the same request identity. */ } }
export function designHistory(userId, projectId, currentVersionId) {
  const key = storageKey(userId, projectId);
  if (!histories.has(key)) {
    let stored;
    try { stored = JSON.parse(localStorage.getItem(key) || 'null'); } catch { /* Empty or inaccessible local storage. */ }
    const pending = stored?.pending;
    histories.set(key, { currentVersionId: stored?.currentVersionId || currentVersionId, undo: Array.isArray(stored?.undo) ? stored.undo.filter(validItem).slice(-30) : [], redo: Array.isArray(stored?.redo) ? stored.redo.filter(validItem).slice(-30) : [], pending: pending && ['undo', 'redo', 'restore'].includes(pending.action) && validId(pending.requestKey) && validId(pending.sourceVersionId) && (pending.expectedCurrentVersionId === null || validId(pending.expectedCurrentVersionId)) ? { action: pending.action, requestKey: pending.requestKey, sourceVersionId: pending.sourceVersionId, expectedCurrentVersionId: pending.expectedCurrentVersionId } : null });
  }
  const history = histories.get(key);
  if (history.currentVersionId !== currentVersionId && !history.pending) { history.undo = []; history.redo = []; history.currentVersionId = currentVersionId; save(key, history); }
  return history;
}
export function recordDesignAdoption(userId, projectId, beforeVersionId, afterVersionId) {
  const history = designHistory(userId, projectId, beforeVersionId);
  if (beforeVersionId) history.undo.push({ beforeVersionId, afterVersionId });
  history.undo = history.undo.slice(-30); history.redo = []; history.pending = null; history.currentVersionId = afterVersionId;
  save(storageKey(userId, projectId), history); return history;
}
export async function restoreDesignVersion(userId, projectId, currentVersionId, action, sourceVersionId) {
  const key = storageKey(userId, projectId), history = designHistory(userId, projectId, currentVersionId);
  if (history.pending && history.pending.action !== action) throw new Error('请先核对上一次恢复操作，原请求编号仍已保留。');
  if (!history.pending) {
    const item = (action === 'undo' ? history.undo : history.redo).at(-1);
    const source = action === 'restore' ? sourceVersionId : action === 'undo' ? item?.beforeVersionId : item?.afterVersionId;
    if (!validId(source)) throw new Error('没有可恢复的历史版本。');
    history.pending = { action, requestKey: crypto.randomUUID(), sourceVersionId: source, expectedCurrentVersionId: currentVersionId || null }; save(key, history);
  }
  const { action: pendingAction, ...body } = history.pending;
  let result;
  try { result = await api(`/design/projects/${encodeURIComponent(projectId)}/restore`, { method: 'POST', body }); }
  catch (error) {
    if (error.status >= 400 && error.status < 500 && ![408, 429].includes(error.status)) { history.pending = null; save(key, history); }
    throw error;
  }
  if (!validId(result.versionId) || result.currentVersionId !== null && !validId(result.currentVersionId)) throw new Error('恢复结果不完整，请继续核对原请求。');
  // A replay may refer to a completed restore followed by a newer independent edit.
  // Never describe the old result as the current project head.
  const superseded = result.currentVersionId !== result.versionId;
  if (superseded || pendingAction === 'restore') { history.undo = []; history.redo = []; }
  else { const source = pendingAction === 'undo' ? history.undo : history.redo, item = source.pop(); if (item) (pendingAction === 'undo' ? history.redo : history.undo).push(item); }
  history.currentVersionId = result.currentVersionId; history.pending = null; save(key, history);
  return { ...result, superseded };
}
