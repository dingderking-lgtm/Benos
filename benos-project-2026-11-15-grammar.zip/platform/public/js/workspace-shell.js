import { escapeHtml, icon } from './icons.js';

const usd = new Intl.NumberFormat('en-US', {
  style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 6,
});

function accountName(user) {
  return user?.name?.trim() || user?.email?.trim() || '我的账户';
}

function avatar(name) {
  return `<span class="avatar" aria-hidden="true">${escapeHtml(Array.from(name)[0].toUpperCase())}</span>`;
}

function planName(billing) {
  if (!billing || !Object.hasOwn(billing, 'plan')) return '套餐未读取';
  if (!billing.plan) return '暂无生效套餐';
  const plan = billing.plan;
  const name = { go: 'Go', pro: 'Pro' }[plan.tier] || plan.tier || '会员';
  if (Date.parse(plan.endsAt) <= Date.now()) return `${name} 已到期`;
  return plan.source === 'gift' ? `${name} 赠送` : name;
}

function balanceLabel(billing) {
  const amount = billing?.wallet?.availableMicros;
  if (billing?.walletState !== 'ready' || !Number.isSafeInteger(amount) || amount < 0) return '余额未读取';
  return usd.format(amount / 1_000_000);
}

function navLink(path, title, glyph, selected, count = '') {
  return `<a href="#${path}" class="nav-link" title="${title}" aria-label="${title}"${selected ? ' aria-current="page"' : ''}>
    ${icon(glyph)}<span>${title}</span>${count}</a>`;
}

function navButton(action, title, glyph, selected = false) {
  return `<button type="button" class="nav-link" data-action="${action}" title="${title}" aria-label="${title}"${selected ? ' aria-current="page"' : ''}>
    ${icon(glyph)}<span>${title}</span></button>`;
}

function canOpenAdmin(user, allowed) {
  return allowed === true && ['owner', 'admin', 'editor', 'support'].includes(user?.role);
}

function recentProjects(items, received) {
  const ordered = [...items].filter(project => typeof project?.id === 'string' && project.id);
  ordered.sort((a, b) => (Date.parse(b.updated_at) || 0) - (Date.parse(a.updated_at) || 0));
  const colors = ['color-manufacturing', 'color-home', 'color-studio'];
  return `<div class="sidebar-recents"><span class="nav-caption">最近项目</span>${ordered.length
    ? ordered.slice(0, 3).map((project, index) => {
      const name = escapeHtml(project.name || '未命名项目');
      return `<a class="recent-nav-link" href="#design/${encodeURIComponent(project.id)}" title="${name}">
        <i class="project-color ${colors[index]}" aria-hidden="true"></i><span>${name}</span></a>`;
    }).join('')
    : `<p class="workspace-recents-empty">${received ? '暂无最近项目' : '最近项目未读取'}</p>`}</div>`;
}

export function renderWorkspaceSidebar({ user, brandHtml = '', collapsed = false, mobile = false, route = 'home', projects }) {
  const name = accountName(user);
  const received = Array.isArray(projects) || Array.isArray(projects?.items);
  const items = Array.isArray(projects) ? projects : projects?.items || [];
  const count = received ? `<small title="已加载 ${items.length} 个项目">${items.length}${projects?.nextCursor ? '+' : ''}</small>` : '';
  const toggleLabel = mobile ? '关闭导航' : collapsed ? '展开侧栏' : '收起侧栏';
  return `<div class="sidebar-brand">${brandHtml}<div class="sidebar-brand-actions">
      <button type="button" class="sidebar-brand-search" data-action="workspace-search" aria-label="搜索工作空间" title="搜索工作空间">${icon('search')}</button>
      <button type="button" class="ui-icon-button ui-button--ghost ui-icon-button--compact ${mobile ? '' : 'desktop-collapse'}" data-action="${mobile ? 'close-nav' : 'toggle-sidebar'}" aria-label="${toggleLabel}" title="${toggleLabel}">${icon(mobile ? 'x' : 'panel-left')}</button>
    </div></div>
    ${mobile ? '' : `<button type="button" class="sidebar-search workspace-rail-search" data-action="workspace-search" title="搜索工作空间" aria-label="搜索工作空间">${icon('search')}</button>`}
    <button type="button" class="ui-button new-site" data-action="new-project" aria-label="新建项目" title="新建项目">${icon('pen-tool')}<span>新建项目</span></button>
    <div class="nav-group"><nav aria-label="工作空间">
      ${navLink('home', '工作台', 'house', route === 'home')}
      ${navLink('projects', '我的项目', 'folder', /^(projects|design)(\/|$)/.test(route), count)}
      ${navLink('inspiration', '灵感案例', 'sparkles', route === 'inspiration')}
      ${navButton('start-library', '模板库', 'layout-grid')}
      ${navButton('workspace-media', '素材库', 'image', route.startsWith('media/'))}
      ${navLink('hosting', '网站托管', 'globe', /^(hosting)(\/|$)/.test(route))}
    </nav></div>
    ${recentProjects(items, received)}
    <div class="sidebar-bottom">
      <a class="workspace-upgrade" href="#billing"><span class="upgrade-symbol">${icon('layers')}</span>
        <span><strong>拓展你的创作空间</strong><small>查看套餐与增购服务</small></span>${icon('chevron-right')}</a>
      <div class="sidebar-account-bar"><button type="button" class="account-trigger" data-action="workspace-account" aria-label="打开账户菜单" aria-controls="account-menu" aria-expanded="false" aria-haspopup="dialog">
        ${avatar(name)}<span class="account-trigger-name" title="${escapeHtml(name)}">${escapeHtml(name)}</span>${icon('chevron-down')}</button>
        <a class="account-notifications" href="#notifications" aria-label="服务通知" title="服务通知"${route === 'notifications' ? ' aria-current="page"' : ''}>${icon('bell')}</a>
      </div>
    </div>`;
}

export function renderWorkspaceHeader({ route = 'home', title = '工作台', billing }) {
  const plan = escapeHtml(planName(billing));
  const balance = escapeHtml(balanceLabel(billing));
  return `<header class="app-header${route === 'home' ? ' is-home-header' : ''}">
    <div class="breadcrumbs">
      <button type="button" class="ui-icon-button ui-button--ghost mobile-menu" data-action="open-nav" aria-label="打开导航" aria-controls="mobile-nav" aria-haspopup="dialog">${icon('menu')}</button>
      <button type="button" class="ui-icon-button ui-button--ghost expand-sidebar" data-action="toggle-sidebar" aria-label="展开侧栏">${icon('panel-left')}</button>
      <button type="button" class="header-workspace" data-action="workspace-menu" aria-haspopup="dialog"><span class="workspace-symbol">${icon('sparkles')}</span><span>设计工作台</span><small>BENOS</small>${icon('chevron-down')}</button>
      <span class="workspace-crumb">工作空间</span><span class="crumb-slash">/</span><strong>${escapeHtml(title)}</strong>
    </div>
    <div class="header-actions"><div class="header-account">
      <a class="header-usage" href="#billing" aria-label="查看套餐和 AI 可用额度，${plan}，${balance}" title="AI 可用额度：${balance}">${icon('sparkles')}<span class="workspace-balance">${balance}</span><span class="header-plan">${plan}</span></a>
      <a class="ui-icon-button ui-button--ghost" href="#notifications" aria-label="服务通知" title="服务通知">${icon('bell')}</a>
    </div></div>
  </header>`;
}

function accountLink(path, title, glyph, detail = '') {
  return `<a class="account-menu-item" href="#${path}">${icon(glyph)}<span>${title}</span>${detail ? `<small>${escapeHtml(detail)}</small>` : ''}${icon('chevron-right')}</a>`;
}

export function renderWorkspaceAccount({ user, billing, canOperate = false }) {
  const name = accountName(user);
  const email = escapeHtml(user?.email || '');
  const adminRoute = user?.role === 'editor' ? 'admin/content' : 'admin';
  return `<div class="account-menu-identity">${avatar(name)}<div><strong title="${escapeHtml(name)}">${escapeHtml(name)}</strong><span title="${email}">${email}</span></div>
      <button type="button" class="account-menu-close" data-action="workspace-account-close" aria-label="关闭账户菜单">${icon('x')}</button></div>
    <section class="account-menu-plan" aria-label="当前套餐"><div><strong>${escapeHtml(planName(billing))}</strong><a href="#billing">管理套餐</a></div>
      ${accountLink('billing', 'AI 可用额度', 'sparkles', balanceLabel(billing))}
    </section>
    <nav aria-label="账户服务">
      ${accountLink('projects', '我的项目', 'folder')}${accountLink('hosting', '网站托管', 'globe')}<hr>
      ${accountLink('settings', '账户与设置', 'settings')}${accountLink('billing', '套餐与账单', 'credit-card')}${accountLink('notifications', '服务通知', 'bell')}
      ${canOpenAdmin(user, canOperate) ? accountLink(adminRoute, '平台管理', 'shield-check') : ''}<hr>
      <button type="button" class="account-menu-item" data-action="logout">${icon('arrow-left')}<span>退出登录</span></button>
    </nav>`;
}
