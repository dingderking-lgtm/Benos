import { escapeHtml as escape, icon } from './icons.js';

const suggestions = [
  { label: '试试暖砂配色', prompt: '把网站配色改为暖砂色' },
  { label: '换成深炭配色', prompt: '把网站配色改为深炭色' },
  { label: '让标题更有品牌感', prompt: '调整首页主标题的字体、字号和留白，让品牌表达更清晰。' },
];

function assistantMark(size) {
  return `<img class="d-assistant-logo" src="/assets/brand/benos-logo.svg" alt="" width="${size}" height="${size}">`;
}

function suggestionList(items) {
  if (!items.length) return '';
  return `<div class="d-suggestions" aria-label="继续探索">
    ${items.map(item => `<button type="button" class="d-suggestion"
      data-action="design-conversation-suggest" data-prompt="${escape(item.prompt)}">
      <span>${escape(item.label)}</span>${icon('arrow-right')}</button>`).join('')}
  </div>`;
}

function previewToggle(open) {
  const label = open ? '收起预览' : '打开预览';
  return `<button type="button" class="text-button d-preview-toggle"
    data-action="design-conversation-toggle-preview" aria-controls="designer-site-preview"
    aria-expanded="${open}" title="${label}">${icon('panel-left')}<span data-preview-toggle-label>${label}</span></button>`;
}

function messageList(messages) {
  return messages.filter(message => message.text).map(message => {
    const isUser = message.role === 'user';
    const author = message.author || (isUser ? '你' : '设计助手');
    return `<article class="d-message d-message--${isUser ? 'user' : 'assistant'}">
      <span class="d-message-avatar" aria-hidden="true">${isUser ? '你' : assistantMark(20)}</span>
      <div class="d-message-content"><span class="d-message-author">${escape(author)}</span>
        <p>${escape(message.text)}</p></div>
    </article>`;
  }).join('');
}

function deviceSwitch(device) {
  const choices = [['desktop', '桌面预览', 'monitor'], ['mobile', '手机预览', 'smartphone']];
  return `<div class="d-device-switch" role="group" aria-label="预览设备">
    ${choices.map(([value, label, glyph]) => `<button type="button" class="d-device-button"
      data-action="design-device" data-device="${value}" aria-label="${label}" title="${label}"
      aria-pressed="${device === value}">${icon(glyph)}</button>`).join('')}
  </div>`;
}

function mobileTabs(mobileTab) {
  return `<nav class="d-mobile-tabs" aria-label="设计器视图">
    <button type="button" class="d-tab" data-action="design-visual-tab" data-mobile-tab="preview"
      aria-pressed="${mobileTab === 'preview'}">${icon('monitor')} 网站预览</button>
    <button type="button" class="d-tab" data-action="design-visual-tab" data-mobile-tab="ai"
      aria-pressed="${mobileTab === 'ai'}">${icon('sparkle')} AI 对话</button>
  </nav>`;
}

/**
 * Read-only composition of the design workspace. HTML slots are produced by
 * application renderers. User names, briefs, suggestions and messages are text.
 * canvasHtml owns the authenticated iframe and its selection overlay.
 */
export function renderDesignConversation({
  project, brief = project.description || '', saveLabel = '', statusLabel = '',
  messages = [], historyHtml = '', activitiesHtml = '', composerHtml = '',
  suggestions: promptSuggestions = suggestions, panelHtml = '', canvasHtml = '',
  previewControlsHtml = '', previewLabel = '', toolsHtml = '', footerHtml = '',
  device = 'desktop', tab = 'ai', mobileTab = 'preview', canUndo = false,
  hasPreview = false, candidate = false, reviewHref = '', previewOpen = true,
  conversationStarted = false,
}) {
  const selectedDevice = device === 'mobile' ? 'mobile' : 'desktop';
  const selectedPanel = tab === 'visual' ? 'visual' : 'ai';
  const selectedMobile = ['preview', 'ai', 'visual'].includes(mobileTab) ? mobileTab : 'preview';
  const status = statusLabel || (candidate ? '待采用方案' : '');
  const briefStatus = ({ '待采用方案': '待采用', '已采用方案': '已采用', '已放弃方案': '已放弃' })[status] || status;
  const heading = project.name || '未命名项目';
  const history = historyHtml || (messages.length
    ? `<div class="d-messages" aria-live="polite" aria-relevant="additions text">${messageList(messages)}</div>`
    : '');
  const review = reviewHref.startsWith('#design/')
    ? `<a class="text-button d-conversation-review" href="${escape(reviewHref)}">审阅方案 ${icon('arrow-right')}</a>`
    : candidate ? `<button type="button" class="text-button d-conversation-review"
        data-action="design-visual-tab" data-mobile-tab="visual" aria-pressed="${selectedMobile === 'visual'}">
        审阅方案 ${icon('arrow-right')}</button>` : '';

  return `<section class="d-shell b-design-shell d-conversation"
      data-device="${selectedDevice}" data-design-tab="${selectedPanel}" data-mobile-tab="${selectedMobile}" data-preview-open="${previewOpen}"
      aria-label="网站设计工作台">
    <header class="d-header">
      <div class="d-project-heading">
        <a class="ui-icon-button ui-button--ghost d-back" href="#home" aria-label="返回工作台" title="返回工作台">${icon('arrow-left')}</a>
        <div class="d-project-details"><h1 class="d-project-name" title="${escape(heading)}">${escape(heading)}</h1>
          ${saveLabel ? `<span class="d-save-state">${icon(hasPreview ? 'check' : 'folder')} ${escape(saveLabel)}</span>` : ''}
        </div>${status ? `<span class="d-local-badge">${escape(status)}</span>` : ''}
      </div>
      <div class="d-header-actions">
        <button type="button" class="ui-icon-button ui-button--ghost d-undo"
          data-action="design-visual-undo" aria-label="撤销最近采用的设计" title="撤销最近采用的设计"
          ${canUndo ? '' : 'disabled'}>${icon('undo')}</button>
        ${deviceSwitch(selectedDevice)}
        ${toolsHtml || `<button type="button" class="ui-icon-button ui-button--ghost d-conversation-tools"
          data-action="design-conversation-tools" aria-label="设计工具" title="设计工具">${icon('ellipsis')}</button>`}
        <button type="button" class="ui-button ui-button--primary d-publish"
          data-action="design-conversation-publish" aria-label="发布网站" title="发布网站">
          ${icon('arrow-up')}<span><span class="d-publish-prefix">一键</span>发布</span></button>
      </div>
    </header>
    ${mobileTabs(selectedMobile)}
    <div class="d-body">
      <aside class="d-chat-panel" aria-label="设计助手与编辑工具">
        <div class="d-conversation-chat" data-design-ai>
          <div class="d-chat-heading"><span class="d-assistant-mark" aria-hidden="true">${assistantMark(26)}</span>
            <h2>设计助手</h2><span data-chat-heading-tools>${previewToggle(previewOpen)}</span>
          </div>
          <div class="d-chat-scroll" id="designer-messages">
            ${brief ? `<details class="d-chat-project-brief" data-chat-project-brief${!conversationStarted && !messages.length ? ' open data-initial-brief' : ''}>
              <summary>${icon('file-text')}<span>项目需求</span>${icon('chevron-down')}</summary><p>${escape(brief)}</p></details>` : ''}
            ${!conversationStarted && !messages.length ? `<div class="d-chat-intro" data-conversation-intro>
              ${suggestionList(promptSuggestions)}
            </div>` : ''}
            ${history}
            ${activitiesHtml}
          </div>
          ${composerHtml}
        </div>
        <div class="d-conversation-inspector">
          <div class="d-inspector-heading"><button type="button" class="text-button d-conversation-return" data-action="design-visual-tab"
            data-design-tab="ai">${icon('arrow-left')} 返回 AI 对话</button>${previewToggle(previewOpen)}</div>
          <div data-visual-panel>${panelHtml}</div>
        </div>
      </aside>
      <section id="designer-site-preview" class="d-preview-panel b-design-preview" aria-label="设计效果预览"${previewOpen ? '' : ' inert aria-hidden="true"'}>
        <div class="d-preview-toolbar">
          <span class="d-preview-caption">${icon('globe')} 网站预览</span>
          ${review}
          <span class="d-preview-status"${review ? ' data-review-state' : ''}><span class="d-status-dot" aria-hidden="true"></span>
            <span data-conversation-device-label>${selectedDevice === 'mobile' ? '手机视图' : '桌面视图'}</span>
            ${status ? `<span class="d-preview-draft"> · ${escape(status)}</span>` : ''}
            ${review && status ? `<span class="d-review-state-compact">${escape(briefStatus)}</span>` : ''}
          </span>
        </div>
        ${previewControlsHtml}
        <div class="d-preview-stage"><div class="d-preview-frame">${canvasHtml}</div></div>
        ${footerHtml || (previewLabel ? `<div class="d-preview-bottom"><span>${icon(hasPreview ? 'check' : 'monitor')} ${escape(previewLabel)}</span></div>` : '')}
      </section>
    </div>
  </section>`;
}
