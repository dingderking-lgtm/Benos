import { api } from './api.js';
import { escapeHtml as e } from './icons.js';
import { composerHtml, imageOnlyPrompt, recordHtml, turnHtml, turnKey, pickedReferences, projectReferenceLibrary } from './design-conversation-workflow.js';
import { isChatUploadPending, mountChatAttachments } from './design-chat-attachments.js';
import { visualState } from './design-editor.js';

const drafts = new Map();
const requests = new Map();
const notices = new Map();
const sending = new Set();
const running = new Set();
const paused = new Set();
const composing = new WeakSet();
const mountedForms = new WeakSet();
const startedProjects = new Set();
const activeStates = new Set(['ready', 'processing', 'uncertain']);
const referenceTypes = new Set(['image/png', 'image/jpeg', 'image/webp']);
let pollTimer, epoch = 0;
let openedTool;

const keyFor = (user, project) => `${user.id}:${project.id}`;
const path = data => `/ai/projects/${encodeURIComponent(data.project.id)}`;
const referenceReady = asset => asset.state === 'ready' && !asset.deletedAt && referenceTypes.has(asset.mimeType);
const activeWorkflow = data => data.workflow.items.some(item => activeStates.has(item.state)) ||
  data.workflow.conversation?.items.some(item => item.state === 'received');

function readSession(map, prefix, id) {
  if (map.has(id)) return map.get(id);
  try {
    const value = JSON.parse(sessionStorage.getItem(prefix + id) || 'null');
    if (value) map.set(id, value);
    return value;
  } catch { return null; }
}
function saveSession(map, prefix, id, value) {
  if (value) map.set(id, value);
  else map.delete(id);
  try {
    if (value) sessionStorage.setItem(prefix + id, JSON.stringify(value));
    else sessionStorage.removeItem(prefix + id);
  } catch { /* Private browsing can still use the in-memory copy. */ }
}
const readDraft = id => readSession(drafts, 'benos-chat-draft:', id) || {};
const saveDraft = (id, value) => saveSession(drafts, 'benos-chat-draft:', id, value);
function readPending(id) {
  const saved = readSession(requests, 'benos-workflow:', id);
  if (!saved) return null;
  if (saved.body?.requestKey && ['account','quoted'].includes(saved.origin)) return saved;
  // Previous releases saved the original quoted POST body directly under this key.
  if (saved.requestKey && typeof saved.prompt === 'string') return {origin:'quoted', body:saved, originalPrompt:saved.prompt};
  return null;
}
const savePending = (id, value) => saveSession(requests, 'benos-workflow:', id, value);

function markConversationStarted(id) {
  if (startedProjects.has(id)) return;
  startedProjects.add(id);
  try { localStorage.setItem('benos-chat-started:' + id,'1'); } catch { /* Available for this visit. */ }
}
export function isConversationStarted(data,user) {
  const id = keyFor(user,data.project);
  if (startedProjects.has(id)) return true;
  try {
    if (localStorage.getItem('benos-chat-started:' + id) === '1') {
      startedProjects.add(id); return true;
    }
  } catch { /* Storage may be unavailable. */ }
  const draft = readDraft(id);
  if (data.workflow.items.length || data.workflow.conversation?.items.length || data.jobs?.length || readPending(id) || localTurnList(id).length || draft.prompt?.trim() || draft.referenceMediaIds?.length) {
    markConversationStarted(id); return true;
  }
  return false;
}
export function conversationBrief(data,user) {
  const brief = (data.project.description || '').trim();
  if (!brief) return '';
  const id = keyFor(user,data.project);
  const pending = readPending(id);
  const prompts = [...timeline(data,user).map(item => item.requestPrompt), pending?.originalPrompt];
  const repeated = prompts.some(text => typeof text === 'string' && (text.trim() === brief || text.startsWith(brief + '\n视觉风格：')));
  return repeated ? '' : brief;
}
function removeIntro(form) {
  const chat = form?.closest?.('[data-design-ai]');
  chat?.querySelector('[data-conversation-intro]')?.remove();
  const brief = chat?.querySelector('[data-chat-project-brief][data-initial-brief]');
  if (brief) { brief.open = false; brief.removeAttribute('data-initial-brief'); }
}

function scopeFor(data, user) {
  const state = visualState(data, user);
  if (!data.visual.proposal && data.selected && data.selected.id === data.project.current_version_id && state.selectedKey) {
    const node = data.visual.nodes.find(item => `${item.templateId}:${item.nodeKey}` === state.selectedKey);
    if (!node) return {blocked:'请重新选择要调整的区块。'};
    return {scope:{kind:'node',templateId:node.templateId,nodeKey:node.nodeKey},label:`当前区块 · ${node.label || node.nodeKey}`};
  }
  return {scope:{kind:'site'},label:data.project.current_version_id ? '当前网站' : '完整网站'};
}
function readOnlyView(data) {
  if (data.visual.proposal) return '当前正在审阅设计方案。采用方案或返回当前设计后即可发送修改。';
  if (data.selected && data.selected.id !== data.project.current_version_id) return '当前正在查看历史版本。返回当前设计或恢复此版本后即可发送修改。';
  return '';
}
export function primeWorkflowDraft(userId, projectId, value) {
  const id = `${userId}:${projectId}`;
  if (value.prompt?.trim() || value.referenceMediaIds?.length) markConversationStarted(id);
  saveDraft(id, {...value,starterStyle:value.style || ''});
}
const pageSize = 20;
const localTurns = new Map();
const foldPreferences = new Map();
const loadingHistory = new Set();
const localTurnList = id => readSession(localTurns,'benos-chat-unconfirmed-turns:',id) || [];
function rememberTurn(id,turn) {
  const previous = localTurnList(id);
  const next = [turn,...previous.filter(item => turnKey(item) !== turnKey(turn))];
  saveSession(localTurns,'benos-chat-unconfirmed-turns:',id,next);
}
function foldSettings(id) { return readSession(foldPreferences,'benos-chat-folds:',id) || {}; }
function mergeTurns(...lists) {
  const all = new Map();
  for (const rows of lists) for (const item of rows || []) {
    const key = turnKey(item);
    if (!all.has(key)) all.set(key,item);
  }
  return [...all.values()].sort((a,b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
}
export function mergeConversationPages(previous,updated) {
  const old = previous?.conversation, fresh = updated?.conversation;
  if (!old || !fresh) return;
  const overlap = new Set(fresh.items.map(turnKey));
  const connected = old.items.some(turn => overlap.has(turnKey(turn)));
  if (fresh.nextCursor && old.loadedEarlier && connected) fresh.nextCursor = old.nextCursor;
  fresh.items = mergeTurns(fresh.items,old.items);
  fresh.loadedEarlier = !!(old.loadedEarlier && connected);
}
function legacyTurns(projectId,items,jobs=[]) {
  return mergeTurns(items.map(item => ({...item,projectId,recordKind:'workflow'})),jobs.map(item => ({...item,projectId,recordKind:'legacy_job',transcriptId:'legacy-'+item.id})));
}
export async function loadWorkflowResource(projectId, options) {
  const id = encodeURIComponent(projectId);
  const [quote, list, history] = await Promise.all([
    api(`/ai/projects/${id}/workflow-quote`, options).catch(error => {
      if (error.name === 'AbortError' || [401,403].includes(error.status)) throw error;
      return {available:false,reason:'QUOTE_UNAVAILABLE'};
    }),
    api(`/ai/projects/${id}/workflows`, options),
    api(`/ai/projects/${id}/conversation?limit=${pageSize}`, options),
  ]);
  return {quote,items:list.items || [],conversation:{items:history.items || [],nextCursor:history.nextCursor || null,loadedEarlier:false}};
}
function timeline(data,user) {
  const sessionId = keyFor(user,data.project);
  const durable = data.workflow.conversation?.items || legacyTurns(data.project.id,data.workflow.items,data.jobs);
  const durableKeys = new Set(durable.map(turnKey));
  const remembered = localTurnList(sessionId);
  const unconfirmed = remembered.filter(turn => !durableKeys.has(turnKey(turn)));
  if (unconfirmed.length !== remembered.length) saveSession(localTurns,'benos-chat-unconfirmed-turns:',sessionId,unconfirmed.length ? unconfirmed : null);
  const pending = readPending(sessionId), provisional = [];
  if (pending) {
    const old = pending.body;
    provisional.push({recordKind:'message',projectId:data.project.id,requestKey:old.requestKey,requestOrigin:pending.origin,
      requestPrompt:pending.editorText ?? pending.originalPrompt ?? old.prompt,referenceMediaIds:old.referenceMediaIds,
      state:sending.has(sessionId) ? 'pending' : 'checking',checkedMissing:pending.checkedMissing,createdAt:pending.createdAt || new Date().toISOString()});
  }
  return mergeTurns(durable,unconfirmed,provisional).filter(turn => !turn.projectId || turn.projectId === data.project.id);
}
function transcript(data, user) {
  const id = keyFor(user,data.project), history = data.workflow.conversation;
  const older = history?.nextCursor ? `<div class="d-chat-older" data-chat-key="older"><button type="button" class="text-button" data-action="design-conversation-earlier" ${loadingHistory.has(id) ? 'disabled' : ''}>${loadingHistory.has(id) ? '正在加载…' : '加载更早的对话'}</button></div>` : '';
  const turns = timeline(data,user), folds = foldSettings(id);
  return older + turns.reverse().map(turn => turnHtml(turn,data.visual.assets || [],folds)).join('');
}
export function renderConversationHistory(data, user) {
  return `<div class="d-messages" data-conversation-log role="log" aria-label="项目对话" aria-live="polite" aria-relevant="additions">${transcript(data,user)}</div>`;
}

function composerState(data, user) {
  const id = keyFor(user, data.project), draft = readDraft(id), pending = readPending(id);
  const selection = scopeFor(data,user);
  const hasStarter = !data.project.current_version_id && data.visual.candidates?.some(candidate => candidate.state === 'draft' && candidate.baseVersionId === null);
  return {prompt:draft.prompt ?? pending?.originalPrompt ?? '', style:draft.style || '', starterStyle:draft.starterStyle || '',
    pending:!!pending, active:activeWorkflow(data), sending:sending.has(id), quote:data.workflow.quote,
    blocked:readOnlyView(data) || selection.blocked, scopeLabel:selection.label,
    projectId:data.project.id, hasStarter,feedback:notices.get(id)?.text || '',
    references:(data.visual.assets || []).filter(referenceReady), referenceIds:draft.referenceMediaIds || []};
}
export function renderConversationComposer(data, user) {
  return composerHtml(composerState(data,user));
}
export function syncConversationTranscript(context, followSend = false) {
  const target = document.querySelector('[data-conversation-log]');
  if (!target || !context.state.user || !context.state.resource?.workflow) return;
  const scroll = target.closest('.d-chat-scroll');
  const follow = scroll && (followSend || scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 48);
  const anchor = !follow && scroll && [...target.children].find(child => child.matches('article') && child.getBoundingClientRect().bottom > scroll.getBoundingClientRect().top);
  const top = anchor?.getBoundingClientRect().top;
  const template = document.createElement('template');
  template.innerHTML = transcript(context.state.resource,context.state.user);
  const old = new Map([...target.children].map(node => [node.dataset.chatKey,node]));
  let cursor = target.firstElementChild;
  for (const wanted of [...template.content.children]) {
    const key = wanted.dataset.chatKey;
    let node = old.get(key);
    if (!node) { target.insertBefore(wanted,cursor); node = wanted; }
    else {
      old.delete(key);
      if (node !== cursor) target.insertBefore(node,cursor);
      if (!node.isEqualNode(wanted)) {
        if (node.matches('article')) {
          const before = node.querySelector('.d-message-content'), after = wanted.querySelector('.d-message-content');
          for (const part of ['.d-chat-fold','[data-message-body]','[data-fold-excerpt]','[data-message-result]']) {
            const a = before.querySelector(part), b = after.querySelector(part);
            if (!b) a?.remove();
            else if (!a) before.append(b);
            else if (!a.isEqualNode(b)) {
              const focus = a.contains(document.activeElement);
              a.replaceWith(b);
              if (focus) (b.matches('button,a') ? b : b.querySelector('button,a'))?.focus({preventScroll:true});
            }
          }
        } else if (!node.contains(document.activeElement)) { node.replaceWith(wanted); node = wanted; }
      }
    }
    cursor = node.nextElementSibling;
  }
  for (const stale of old.values()) {
    const focused = stale.contains(document.activeElement);
    stale.remove();
    if (focused) target.querySelector('.d-chat-fold')?.focus({preventScroll:true});
  }
  if (scroll && follow) scroll.scrollTop = scroll.scrollHeight;
  else if (anchor?.isConnected) scroll.scrollTop += anchor.getBoundingClientRect().top - top;
}
const refreshHistory = syncConversationTranscript;

export function syncConversationComposer(context, updateText = false) {
  const form = document.querySelector('[data-form="design-conversation-message"]');
  if (!form || !context.state.user || !context.state.resource?.workflow) return;
  if (isConversationStarted(context.state.resource,context.state.user)) removeIntro(form);
  if (!conversationBrief(context.state.resource,context.state.user)) form.closest('[data-design-ai]')?.querySelector('[data-chat-project-brief]')?.remove();
  const state = composerState(context.state.resource,context.state.user);
  const template = document.createElement('template');
  // Only controls whose state has changed are updated; leave focus, selection and open details intact.
  template.innerHTML = composerHtml({...state,references:[]});
  const next = template.content.querySelector('form'), prompt = form.elements.prompt;
  if (updateText && !composing.has(prompt) && prompt.value !== next.elements.prompt.value) prompt.value = next.elements.prompt.value;
  const button = form.querySelector('button[type="submit"]'), newButton = next.querySelector('button[type="submit"]');
  button.disabled = newButton.disabled || isChatUploadPending(form);
  button.innerHTML = newButton.innerHTML;
  button.setAttribute('aria-label',newButton.getAttribute('aria-label'));
  const note = form.parentElement.querySelector('.d-compose-note');
  if (note) note.innerHTML = template.content.querySelector('.d-compose-note').innerHTML;
}
export function rememberWorkflowInput(input, context) {
  const form = input.closest('[data-form="design-conversation-message"]');
  if (!form) return;
  const id = keyFor(context.state.user, context.state.resource.project), draft = readDraft(id);
  if (input.name === 'prompt') {
    if (input.value.length) { markConversationStarted(id); removeIntro(form); }
    saveDraft(id, {...draft,prompt:input.value,restoreOnFailure:null});
  }
  if (input.name === 'style') {
    saveDraft(id, {...draft,style:input.value});
    const trigger = form.querySelector('[data-chat-tool="style"]');
    trigger.dataset.selected = String(!!input.value);
    trigger.title = input.value ? `视觉风格 · ${input.value}` : '选择视觉风格';
  }
  if (input.name === 'referenceMediaIds') {
    const referenceMediaIds = [...form.querySelectorAll('[name="referenceMediaIds"]:checked')].map(el => el.value);
    setChatReferences(form,context,id,referenceMediaIds,false);
  }
}
function setChatReferences(form,context,id,ids,refreshCatalog) {
  if (ids.length) { markConversationStarted(id); removeIntro(form); }
  saveDraft(id,{...readDraft(id),referenceMediaIds:ids,restoreOnFailure:null});
  renderChatReferences(form,context,id,ids,refreshCatalog);
}
function renderChatReferences(form,context,id,ids,refreshCatalog) {
  if (!form.isConnected) return;
  const {resource:data,user} = context.state;
  if (!data?.project || !user || keyFor(user,data.project) !== id) return;
  const assets = (data.visual.assets || []).filter(referenceReady);
  const strip = form.querySelector('[data-chat-selected-references]');
  strip.innerHTML = pickedReferences(assets,ids);
  strip.hidden = ids.length === 0;
  form.elements.prompt.required = !ids.length;
  form.elements.prompt.placeholder = ids.length ? imageOnlyPrompt : '描述想调整的地方…';
  const library = form.querySelector('[data-chat-tool-panel="references"] .d-chat-tool-content');
  if (refreshCatalog) library.innerHTML = projectReferenceLibrary(assets,ids,data.project.id);
  for (const input of library.querySelectorAll('[name="referenceMediaIds"]')) input.checked = ids.includes(input.value);
  form.querySelector('[data-chat-tool="references"]').dataset.selected = String(ids.length > 0);
}
function showUploadStatus(form,context,{pending,error,canRetry,progressText,blocked}) {
  const status = form.querySelector('[data-chat-upload-status]');
  status.hidden = !(pending || error || blocked);
  status.dataset.error = String(!!error);
  status.querySelector('[data-chat-upload-message]').textContent = error || progressText || (pending ? '正在上传参考图…' : '');
  status.querySelector('[data-chat-upload-retry]').hidden = !error || !canRetry;
  status.querySelector('[data-chat-upload-dismiss]').hidden = !error;
  const id = keyFor(context.state.user,context.state.resource.project), draft = readDraft(id);
  if (pending) { markConversationStarted(id); removeIntro(form); }
  if (pending && draft.restoreOnFailure) saveDraft(id,{...draft,restoreOnFailure:null});
  if (form.isConnected) syncConversationComposer(context);
}
function updateList(context, item) {
  const data = context.state.resource;
  if (!item.recordKind || item.recordKind === 'workflow') {
    const index = data.workflow.items.findIndex(old => old.id === item.id);
    if (index < 0) data.workflow.items.unshift(item);
    else data.workflow.items[index] = item;
  }
  if (data.workflow.conversation) {
    const prior = data.workflow.conversation.items.find(old => turnKey(old) === turnKey(item) || (old.recordKind === 'workflow' && old.id === item.id));
    const turn = {...prior,...item};
    data.workflow.conversation.items = mergeTurns([turn],data.workflow.conversation.items.filter(old => old !== prior));
  }
  refreshHistory(context);
  syncConversationComposer(context);
}
function sameContext(context, projectId, userId) {
  return context.state.user?.id === userId && context.state.route === `design/${projectId}` && context.state.resource?.project?.id === projectId;
}
const refreshConversation = context => (context.refreshConversation || context.reload)();
async function continueLoop(context, item) {
  if (running.has(item.id)) return;
  const projectId = context.state.resource.project.id, userId = context.state.user.id;
  running.add(item.id); paused.delete(item.id); updateList(context,item);
  try {
    while (item.state === 'ready' && !paused.has(item.id) && sameContext(context,projectId,userId)) {
      item = await api(`/ai/workflows/${encodeURIComponent(item.id)}/continue`, {method:'POST',body:{step:item.stepsUsed+1}});
      if (sameContext(context,projectId,userId)) updateList(context,item);
    }
  } catch (error) {
    notices.set(`${userId}:${projectId}`, {text:`本轮状态待更新。${error.message} 请在原任务中查询进度。`});
  } finally {
    running.delete(item.id);
    if (sameContext(context,projectId,userId)) await refreshConversation(context);
  }
}
export function stopWorkflowPolling() { clearTimeout(pollTimer); epoch++; }
function closeChatTool(returnFocus = false) {
  if (!openedTool) return;
  const {button,panel,listeners} = openedTool;
  openedTool = null;
  listeners.abort();
  button.setAttribute('aria-expanded','false');
  panel.hidden = true;
  if (returnFocus && button.isConnected) button.focus({preventScroll:true});
}
function placeChatTool(button, panel) {
  const form = button.form;
  const box = form.getBoundingClientRect(), opener = button.getBoundingClientRect();
  const shell = form.closest('.d-shell');
  const tabs = shell.querySelector('.d-mobile-tabs');
  const header = shell.querySelector('.d-header');
  const visibleTop = Math.max(window.visualViewport?.offsetTop || 0,
    shell.getBoundingClientRect().top, header?.getBoundingClientRect().bottom || 0,
    tabs?.getClientRects().length ? tabs.getBoundingClientRect().bottom : 0,
    form.closest('.d-chat-panel').getBoundingClientRect().top);
  const scale = box.width / (form.offsetWidth || box.width) || 1;
  // Normally clear the entire composer. In a short workspace use the space above
  // the trigger, including the textarea, rather than sliding underneath the tabs.
  const anchor = (box.top - visibleTop) / scale >= 242 ? box.top : opener.top;
  panel.style.setProperty('--chat-panel-bottom',Math.ceil((box.bottom - anchor) / scale + 5) + 'px');
  panel.style.setProperty('--chat-panel-space',Math.max(0,Math.floor((anchor - visibleTop) / scale - 10)) + 'px');
}
function toggleChatTool(button, fromKeyboard) {
  const wasOpen = openedTool?.button === button;
  closeChatTool();
  if (wasOpen) return;
  const panel = button.form.querySelector(`[data-chat-tool-panel="${button.dataset.chatTool}"]`);
  if (!panel) return;
  const listeners = new AbortController(), signal = listeners.signal;
  openedTool = {button,panel,listeners};
  button.setAttribute('aria-expanded','true');
  const place = () => placeChatTool(button,panel);
  place();
  panel.hidden = false;
  const outside = event => {
    if (!panel.contains(event.target) && !button.contains(event.target)) closeChatTool();
  };
  document.addEventListener('pointerdown',outside,{capture:true,signal});
  document.addEventListener('focusin',outside,{capture:true,signal});
  window.addEventListener('resize',place,{signal});
  window.visualViewport?.addEventListener('resize',place,{signal});
  const sizing = new ResizeObserver(place);
  sizing.observe(button.form); sizing.observe(button.closest('.d-shell'));
  signal.addEventListener('abort',() => sizing.disconnect(),{once:true});
  document.addEventListener('keydown',event => {
    if (event.key === 'Escape' && !event.isComposing) {
      event.preventDefault(); closeChatTool(true);
    }
  },{signal});
  window.addEventListener('hashchange',() => closeChatTool(),{signal});
  window.addEventListener('blur',() => {
    requestAnimationFrame(() => {
      if (openedTool?.button === button && document.activeElement?.tagName === 'IFRAME') closeChatTool();
    });
  },{signal});
  if (fromKeyboard) (panel.querySelector('input:checked') || panel.querySelector('input,a,button[data-action]') || panel.querySelector('button'))?.focus({preventScroll:true});
}
export function mountWorkflow(context) {
  stopWorkflowPolling();
  const currentEpoch = epoch, projectId = context.state.resource.project.id, userId = context.state.user.id;
  const form = document.querySelector('[data-form="design-conversation-message"]');
  if (form && !mountedForms.has(form)) {
    mountedForms.add(form);
    const draftId = keyFor(context.state.user,context.state.resource.project);
    mountChatAttachments(form,context,{
      getSelected:() => readDraft(draftId).referenceMediaIds || [],
      onSelected:ids => setChatReferences(form,context,draftId,ids,true),
      onStatus:status => showUploadStatus(form,context,status),
    });
    const chooseStyle = input => {
      input.checked = true;
      rememberWorkflowInput(input,context);
      closeChatTool();
      form.elements.prompt.focus({preventScroll:true});
    };
    form.addEventListener('click',event => {
      const button = event.target.closest('[data-chat-tool]');
      if (button) toggleChatTool(button,event.detail === 0);
      else if (event.target.closest('[data-chat-tool-close]')) closeChatTool(true);
      else if (event.target.closest('[data-chat-upload-button]')) {
        closeChatTool();
        form.querySelector('[data-chat-upload-input]').click();
      } else if (event.target.closest('[data-chat-remove-reference]')) {
        const id = event.target.closest('[data-chat-remove-reference]').dataset.chatRemoveReference;
        setChatReferences(form,context,draftId,(readDraft(draftId).referenceMediaIds || []).filter(value => value !== id),false);
        (form.querySelector('[data-chat-remove-reference]') || form.querySelector('[data-chat-upload-button]')).focus({preventScroll:true});
      }
      else if (event.detail > 0 && event.target.matches('input[name="style"]')) chooseStyle(event.target);
    });
    form.elements.prompt.addEventListener('compositionstart', () => composing.add(form.elements.prompt));
    form.elements.prompt.addEventListener('compositionend', () => composing.delete(form.elements.prompt));
    form.addEventListener('benos:selection-changed', () => syncConversationComposer(context));
    form.addEventListener('keydown', event => {
      if (event.target.matches('input[name="style"]') && ['Enter',' '].includes(event.key)) {
        event.preventDefault(); chooseStyle(event.target); return;
      }
      if (event.target !== form.elements.prompt || event.key !== 'Enter' || !(event.ctrlKey || event.metaKey) || event.isComposing || event.keyCode === 229) return;
      event.preventDefault();
      if (!form.querySelector('button[type="submit"]').disabled) form.requestSubmit();
    });
  }
  const poll = async () => {
    if (currentEpoch !== epoch || !sameContext(context,projectId,userId)) return;
    try {
      const list = await api(`/ai/projects/${encodeURIComponent(projectId)}/workflows`);
      if (currentEpoch !== epoch) return;
      const old = context.state.resource.workflow.items;
      context.state.resource.workflow.items = list.items || [];
      const completed = list.items?.some(item => item.state !== 'processing' && old.some(previous => previous.id === item.id && previous.state === 'processing'));
      if (completed) { await refreshConversation(context); return; }
      refreshHistory(context); syncConversationComposer(context);
    } catch (error) {
      if (currentEpoch !== epoch) return;
      notices.set(`${userId}:${projectId}`,{text:`无法更新任务进度。${error.message}`});
      refreshHistory(context);
    }
    if (currentEpoch === epoch && context.state.resource.workflow.items.some(item => item.state === 'processing')) pollTimer = setTimeout(poll,5000);
  };
  if (context.state.resource.workflow.items.some(item => item.state === 'processing')) pollTimer = setTimeout(poll,4000);
}
function referenceIds(data, draft) {
  const ids = draft.referenceMediaIds || [];
  if (ids.length > 3) throw new Error('最多选择 3 张参考图。');
  const selected = ids.map(id => data.visual.assets.find(item => item.id === id));
  if (selected.some(asset => !asset || !referenceReady(asset))) throw new Error('参考图仅支持当前项目中可用的 PNG、JPEG 或 WebP 图片。');
  if (selected.reduce((sum,asset) => sum + asset.byteSize,0) > 6 * 1024 * 1024) throw new Error('参考图合计超过 6 MiB，请减少图片或先压缩。');
  return ids;
}
function makeMessage(data, user, draft, prompt) {
  if ((!prompt.trim() && !draft.referenceMediaIds?.length) || prompt.length > 18000) throw new Error('请输入设计需求或添加参考图。正文最多 18000 个字符。');
  const blocked = readOnlyView(data);
  if (blocked) throw new Error(blocked);
  if (activeWorkflow(data)) throw new Error('此项目仍有进行中的设计任务，请先查看任务记录。');
  const selection = scopeFor(data,user);
  if (selection.blocked) throw new Error(selection.blocked);
  return {requestKey:crypto.randomUUID(),prompt,...(draft.style ? {style:draft.style} : {}),
    baseVersionId:data.project.current_version_id || null, scope:selection.scope, referenceMediaIds:referenceIds(data,draft)};
}
function definitiveRejection(error) {
  return (error.status >= 400 && error.status < 500 && error.status !== 408 && error.code !== 'INVALID_RESPONSE') ||
    ['AI_NOT_CONFIGURED','AI_BILLING_UNVERIFIED','CAPABILITY_TEST_REQUIRED','VISION_BILLING_UNVERIFIED','INSUFFICIENT_PROVIDER_FUNDS'].includes(error.code);
}
async function lookup(data, pending) {
  try {
    return await api(`${path(data)}/messages/${encodeURIComponent(pending.body.requestKey)}`);
  } catch (error) {
    if (error.status === 404 && error.code === 'NOT_FOUND') return null;
    throw error;
  }
}
function errorText(error) {
  const messages = {
    AI_NOT_CONFIGURED:'AI 设计服务尚未启用。',
    AI_BILLING_UNVERIFIED:'设计服务的计费尚待核验。',
    INSUFFICIENT_PROVIDER_FUNDS:'平台当前可用设计额度不足，请稍后重试。',
  };
  return messages[error.code] || error.message || '发送未完成，请稍后重试。';
}
async function acceptReceipt(context, id, pending, item, advance) {
  if (!item?.id || !item.state || (item.projectId && item.projectId !== context.projectId) || (item.requestOrigin && item.requestOrigin !== pending.origin)) {
    throw new Error('原请求的回执与当前项目不匹配，请查询原任务。');
  }
  item = {requestKey:pending.body.requestKey,requestPrompt:pending.editorText ?? pending.originalPrompt,referenceMediaIds:pending.body.referenceMediaIds,
    requestOrigin:pending.origin,createdAt:pending.createdAt,projectId:context.projectId,...item};
  if (item.state === 'received') savePending(id,pending);
  else savePending(id,null);
  notices.delete(id);
  const draft = readDraft(id);
  if (item.state !== 'received' && draft.restoreOnFailure === pending.body.requestKey) saveDraft(id,{...draft,restoreOnFailure:null});
  rememberTurn(id,item);
  if (!sameContext(context,context.projectId,context.userId)) return;
  updateList(context,item);
  if (advance && item.state === 'ready') await continueLoop(context,item);
  else await refreshConversation(context);
}
async function sendOrRecover(context, pending, mode) {
  const {resource:data,user} = context.state, id = keyFor(user,data.project);
  if (sending.has(id)) return;
  context = {...context,projectId:data.project.id,userId:user.id};
  sending.add(id); notices.delete(id);
  const live = () => sameContext(context,data.project.id,user.id);
  if (live()) { refreshHistory(context,true); syncConversationComposer(context,mode === 'send'); }
  let item;
  try {
    if (mode !== 'send') {
      item = await lookup(data,pending);
      if (item?.state === 'received' && mode === 'retry') item = null;
      if (!item && mode === 'check') {
        savePending(id,{...pending,checkedMissing:true});
        return;
      }
    }
    if (!item) {
      if (mode === 'retry' && (readOnlyView(data) || data.workflow.items.some(row => activeStates.has(row.state)))) {
        notices.set(id,{text:'请先返回当前设计并完成已有任务。仍可查询原请求的回执。'});
        return;
      }
      const endpoint = pending.origin === 'quoted' ? 'workflows' : 'messages';
      try {
        item = await api(`${path(data)}/${endpoint}`,{method:'POST',body:pending.body});
      } catch (error) {
        if (definitiveRejection(error)) {
          // Some preflight refusals are persisted without a billable workflow.
          // Preserve each attempted message independently until the server history includes it.
          let receipt = null;
          try { receipt = await lookup(data,pending); } catch { /* A future history refresh can confirm the receipt. */ }
          const refused = receipt || {id:pending.body.requestKey,projectId:data.project.id,recordKind:'message',requestOrigin:pending.origin,
            requestKey:pending.body.requestKey,requestPrompt:pending.editorText ?? pending.originalPrompt,referenceMediaIds:pending.body.referenceMediaIds,
            state:'failed',errorCode:error.code,createdAt:pending.createdAt || new Date().toISOString()};
          if (receipt && receipt.state !== 'failed') { await acceptReceipt(context,id,pending,receipt,false); return; }
          rememberTurn(id,refused); savePending(id,null);
          const draft = readDraft(id);
          if (draft.restoreOnFailure === pending.body.requestKey || draft.prompt === undefined) {
            const refs = pending.body.referenceMediaIds || [];
            saveDraft(id,{...draft,prompt:pending.editorText ?? pending.originalPrompt,referenceMediaIds:refs,restoreOnFailure:null});
            if (live()) {
              const form = document.querySelector('[data-form="design-conversation-message"]');
              if (form) renderChatReferences(form,context,id,refs,false);
              syncConversationComposer(context,true);
            }
          }
          if (live() && receipt) updateList(context,refused);
          return;
        }
        // A lost response can follow a successful reservation. Look up the same key before any replay.
        try { item = await lookup(data,pending); } catch { /* Keep the original request for read-only reconciliation. */ }
        if (!item) {
          notices.set(id,{text:'发送回执待核对，请查询原请求。'});
          return;
        }
      }
    }
    await acceptReceipt(context,id,pending,item,mode !== 'check');
  } catch (error) {
    notices.set(id,{text:errorText(error)});
  } finally {
    sending.delete(id);
    if (live()) { refreshHistory(context); syncConversationComposer(context); }
  }
}
export async function handleWorkflowAction(name, trigger, context) {
  if (name === 'design-conversation-suggest') {
    const field = document.querySelector('[data-form="design-conversation-message"] textarea');
    if (field && trigger.dataset.prompt) { field.value = trigger.dataset.prompt; rememberWorkflowInput(field,context); field.focus(); }
    return true;
  }
  const {resource:data,user} = context.state;
  if (name === 'design-message-check' || name === 'design-message-retry') {
    const pending = readPending(keyFor(user,data.project));
    if (pending) await sendOrRecover(context,pending,name === 'design-message-check' ? 'check' : 'retry');
    return true;
  }
  if (name === 'design-workflow-pause') { paused.add(trigger.dataset.id); context.notify('本轮结束后停止自动继续。'); return true; }
  if (name !== 'design-workflow-continue' && name !== 'design-workflow-refresh') return false;
  const projectId = data.project.id, userId = user.id;
  try {
    let item = await api(`/ai/workflows/${encodeURIComponent(trigger.dataset.id)}`);
    if (!sameContext(context,projectId,userId)) return true;
    if (name === 'design-workflow-continue' && item.recoverable) {
      item = await api(`/ai/workflows/${encodeURIComponent(item.id)}/continue`,{method:'POST',body:{step:item.steps.at(-1)?.ordinal || 1}});
      if (!sameContext(context,projectId,userId)) return true;
      updateList(context,item);
    }
    if (name === 'design-workflow-continue' && item.state === 'ready') await continueLoop(context,item);
    else await refreshConversation(context);
  } catch (error) {
    if (sameContext(context,projectId,userId)) {
      notices.set(keyFor(user,data.project),{text:errorText(error)}); refreshHistory(context);
    }
  }
  return true;
}
export async function submitWorkflowForm(name, form, values, context) {
  if (name !== 'design-conversation-message') return false;
  const {resource:data,user} = context.state, id = keyFor(user,data.project);
  if (readPending(id) || sending.has(id) || composing.has(form.elements?.prompt) || isChatUploadPending(form)) return true;
  const draft = readDraft(id), editorText = String(values.prompt ?? '');
  const prompt = editorText;
  saveDraft(id,{...draft,prompt:String(values.prompt || '')});
  const body = makeMessage(data,user,draft,prompt);
  markConversationStarted(id);
  removeIntro(form);
  const pending = {origin:'account',body,originalPrompt:prompt,editorText,createdAt:new Date().toISOString()};
  savePending(id,pending);
  saveDraft(id,{...draft,prompt:'',referenceMediaIds:[],restoreOnFailure:body.requestKey});
  renderChatReferences(form,context,id,[],false);
  if (form.isConnected) form.elements.prompt.focus({preventScroll:true});
  await sendOrRecover(context,pending,'send');
  return true;
}
