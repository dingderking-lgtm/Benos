import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const taskNames = { hosting_retention: '暂停网站保留期登记与复核', service_notifications: '套餐与托管到期提醒', hosting_inventory: '托管连接资源核对', email_delivery: '邮件发送队列', provisioning_secrets: '安装凭据清理', provisioning_jobs: '网站配置任务', hosting_entitlements: '托管有效期同步' };
const statuses = { succeeded: '已完成', failed: '需要处理', partial: '部分任务待处理' };
const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '尚无记录';

export function renderMaintenance(data, user) {
  if (!data) return '';
  return `<section class="b-section b-card"><div class="b-section-heading"><div><h2>后台定时任务</h2><p>检查邮件队列、网站配置与托管到期同步是否持续运行。</p></div><span class="b-badge">${data.running ? '正在执行' : data.needsAttention || data.lastResult?.state === 'partial' ? '需要检查' : '最近运行正常'}</span></div>${data.needsAttention ? `<div class="b-notice">${icon('clock')}<div><strong>${data.lastFinishedAt ? '超过 5 分钟没有完成记录' : '尚未观察到定时任务运行'}</strong><p>请检查部署环境的定时触发器。手动执行完成一次，不代表定时调度已经启用。</p></div></div>` : ''}<dl class="b-config-facts"><div><dt>最近开始</dt><dd>${date(data.lastStartedAt)}</dd></div><div><dt>最近完成</dt><dd>${date(data.lastFinishedAt)}</dd></div></dl>${data.lastResult?.tasks?.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>维护任务</th><th>上次结果</th></tr></thead><tbody>${data.lastResult.tasks.map(task => `<tr><td>${e(taskNames[task.task] || task.task)}</td><td>${e(statuses[task.state] || '待核对')}</td></tr>`).join('')}</tbody></table></div>` : ''}<div class="b-table-actions b-section"><button type="button" class="ui-button ui-button--secondary" data-action="retry">刷新运行记录</button><button type="button" class="ui-button ui-button--primary" data-action="maintenance-run" ${user.role !== 'owner' || data.running ? 'disabled' : ''}>${data.running ? '正在处理维护任务' : '立即执行一次'}</button></div></section>`;
}

export async function runMaintenance(trigger, context) {
  trigger.disabled = true;
  try {
    const result = await api('/admin/maintenance/run', { method: 'POST', body: {} });
    if (result.state !== 'queued') throw new Error('维护任务尚未确认受理，请刷新运行记录。');
    await context.reload(); context.notify('维护请求已受理，请刷新运行记录确认结果');
  } finally { if (trigger.isConnected) trigger.disabled = false; }
}
