import { handleMarketingMediaAction } from './content-media-ui.js';
import { contentFilters, contentFormMarkup, contentPayload, publicContentUrl, loadMoreContent, contentBulkToolbar, handleContentListAction, submitContentListForm } from './content-editor.js';
import { api } from './api.js';
import { renderMembershipPanel } from './memberships.js';
import { icon, escapeHtml as e } from './icons.js';

const roles = { owner: '平台所有者', admin: '管理员', support: '客服', editor: '内容编辑', user: '用户' };
const scopes = { login: '登录账户', ai: '使用 AI', topup: '追加充值', publish: '发布网站' };
const kinds = { text: '文本 AI', image: '图像 AI', payment: '支付', hosting: 'CMS 连接', email: '邮件', dns: '域名' };
const contentKinds = { page: '营销页面', post: '博客文章', faq: '常见问题', navigation: '导航链接', banner: '展示横幅', category: '内容分类', tag: '文章标签' };
const states = { active: '已启用', inactive: '未启用', draft: '草稿', tested: '已验证', disabled: '已停用', passed: '验证通过', failed: '验证失败', untested: '未验证', not_tested: '未验证', pending: '待验证', published: '已发布', unpublished: '已取消发布', deleted: '回收站', trashed: '回收站', archived: '已归档' };
const list = data => Array.isArray(data) ? data : data?.items || [];
const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
const badge = value => `<span class="b-badge">${e(states[value] || value || '—')}</span>`;
const action = (label, name, attrs = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="admin-${name}" ${attrs}>${label}</button>`;
const field = (label, name, value = '', { type = 'text', required = true, textarea = false, hint = '', max = 500 } = {}) => `<label class="b-field"><span>${label}</span>${textarea ? `<textarea name="${name}" rows="5" maxlength="${max}" ${required ? 'required' : ''}>${e(value)}</textarea>` : `<input name="${name}" type="${type}" value="${e(value)}" maxlength="${max}" ${required ? 'required' : ''} autocomplete="off">`}${hint ? `<small class="b-field-hint">${hint}</small>` : ''}</label>`;
const select = (label, name, options, current) => `<label class="b-field"><span>${label}</span><select name="${name}">${Object.entries(options).map(([key, text]) => `<option value="${key}" ${key === current ? 'selected' : ''}>${text}</option>`).join('')}</select></label>`;
const formFooter = label => `<p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">${label}</button></div>`;
const modal = (title, description, form, body, attrs = '') => `<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${description}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="admin-${form}" ${attrs}>${body}</form>`;
const header = (title, subtitle, button = '') => `<div class="page-intro"><div><h1>${title}</h1><p>${subtitle}</p></div>${button}</div>`;
const contentOf = item => typeof item.content === 'object' && item.content ? item.content : (() => { try { return JSON.parse(item.content_json || '{}'); } catch { return {}; } })();
const activeRestriction = item => !item.revoked_at && (!item.ends_at || new Date(item.ends_at) > new Date());

export function renderUserDetail(data, actor) {
  const user = data.user;
  const editable = ['owner', 'admin'].includes(actor.role) && actor.id !== user.id && user.role !== 'owner' && (actor.role === 'owner' || user.role === 'user');
  const restrictions = data.restrictions || [];
  const current = restrictions.filter(activeRestriction);
  return `<section class="s-page"><a class="b-back" href="#admin/users">${icon('arrow-left')}返回会员列表</a>${header(e(user.name || user.email), e(user.email), editable ? action(icon('shield-check') + '限制账户权限', 'restrict', `data-user-id="${e(user.id)}"`) : '')}<div class="b-metrics b-member-metrics"><div class="b-card"><span class="b-eyebrow">账户身份</span><h2>${e(roles[user.role] || user.role)}</h2></div><div class="b-card"><span class="b-eyebrow">当前权限限制</span><h2>${current.length ? current.map(item => scopes[item.scope] || item.scope).map(e).join('、') : '无有效限制'}</h2></div><div class="b-card"><span class="b-eyebrow">注册时间</span><h2>${date(user.created_at)}</h2></div></div><div class="b-section b-notice">${icon('shield-check')}<div><strong>会员重要记录受到保护</strong><p>账户权限限制单独记录，不改变会员有效期。当前账户与平台所有者不可限制。暂停会员计时与会员赠送使用独立的权益操作。</p></div></div>${renderMembershipPanel(data, actor)}<section class="b-section"><div class="b-section-heading"><h2>账户权限限制记录</h2></div>${restrictions.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>限制范围</th><th>原因</th><th>有效期</th><th>状态</th><th>操作</th></tr></thead><tbody>${restrictions.map(item => `<tr><td>${e(scopes[item.scope] || item.scope)}</td><td class="b-table-prose">${e(item.reason)}</td><td>${date(item.starts_at)}<small>至 ${item.ends_at ? date(item.ends_at) : '手动解除'}</small></td><td>${badge(item.revoked_at ? '已恢复' : activeRestriction(item) ? '限制中' : '已到期')}</td><td>${editable && activeRestriction(item) ? action('解除限制', 'revoke', `data-user-id="${e(user.id)}" data-restriction-id="${e(item.id)}"`) : '—'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="b-inline-empty">该会员没有权限限制记录。</div>'}</section></section>`;
}

export function renderAdminContent(data) {
  const items = list(data);
  return `<section class="s-page">${header('内容管理', '维护营销页面、博客与网站公共内容。', action(icon('plus') + '新增内容', 'new-content', '', true))}<div class="b-notice">${icon('file-text')}<div><strong>先保存草稿，再发布</strong><p>内容保留版本号以避免覆盖他人的修改。删除会移入回收站，可在这里恢复。</p></div></div>${contentFilters(data)}${items.length?contentBulkToolbar():''}<div class="b-section">${items.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>选择</th><th>内容</th><th>类型</th><th>状态</th><th>版本</th><th>操作</th></tr></thead><tbody>${items.map(item => `<tr><td><input type="checkbox" data-content-select value="${e(item.id)}" data-revision="${item.revision}" aria-label="选择 ${e(item.title)}"></td><td><strong>${e(item.title)}</strong><small>/${e(item.slug)}</small></td><td>${e(contentKinds[item.kind] || item.kind)}</td><td>${badge(item.state || item.status)}</td><td>v${e(item.revision)}</td><td><div class="b-table-actions">${(item.state || item.status) === 'trashed' ? action('恢复', 'content-restore', `data-item-id="${e(item.id)}"`) : `${action('编辑', 'edit-content', `data-item-id="${e(item.id)}"`)}<a class="ui-button ui-button--secondary" href="/api/admin/content/${encodeURIComponent(item.id)}/preview" target="_blank" rel="noopener">预览草稿</a>${item.state === 'published' ? `<a class="ui-button ui-button--secondary" href="${e(publicContentUrl(item))}" target="_blank" rel="noopener">查看公开内容</a>` : ''}${(item.state || item.status) === 'published' ? action('发布更新', 'content-publish', `data-item-id="${e(item.id)}"`) : ''}${action((item.state || item.status) === 'published' ? '取消发布' : '发布', (item.state || item.status) === 'published' ? 'content-unpublish' : 'content-publish', `data-item-id="${e(item.id)}"`)}${action('移入回收站', 'content-delete', `data-item-id="${e(item.id)}"`)}`}</div></td></tr>`).join('')}</tbody></table></div>` : '<div class="b-empty">' + icon('file-text') + '<h2>开始整理你的品牌内容</h2><p>创建第一篇文章或营销页面，保存草稿后再发布。</p></div>'}</div>${data.nextCursor ? `<div class="b-pagination">${action('加载更多内容', 'more-content')}</div>` : ''}</section>`;
}

export function renderAdminIntegrations(data, actor = { role: 'user' }) {
  const items = list(data);
  const integrationAction = (label, name, attrs = '', primary = false) => action(label, name, attrs + (actor.role === 'owner' ? '' : ' disabled title="仅平台所有者可修改服务配置"'), primary);
  const activationReady = item => (item.testStatus || item.test_status) === 'passed' && item.kind !== 'image' && (item.kind !== 'text' || (item.capabilityTestedAt && Date.now() - Date.parse(item.capabilityTestedAt) < 86400000));
  return `<section class="s-page">${header('服务配置', '管理连接版本，验证成功后再切换在线服务。', integrationAction(icon('plus') + '新增配置', 'new-integration', '', true))}<div class="b-notice">${icon('shield-check')}<div><strong>密钥加密保存，只写不回显</strong><p>替换服务时创建新版本，测试通过后启用。启用新版本前，现有配置继续生效。</p></div></div><section class="b-section b-integration-cards">${items.length ? items.map(item => `<article class="b-card"><div class="b-integration-card-heading"><div><span class="b-eyebrow">${e(kinds[item.kind] || item.kind)} · 版本 ${e(item.version)}</span><h2>${e(item.name)}</h2><p>${e(item.provider)}</p></div>${badge(item.status)}</div><dl class="b-config-facts"><div><dt>连接验证</dt><dd>${badge(item.testStatus || item.test_status)}</dd></div><div><dt>最近验证</dt><dd>${date(item.testedAt || item.tested_at)}</dd></div><div><dt>密钥</dt><dd>${item.hasSecret ? '已加密保存' : '未配置'}</dd></div>${['text','image'].includes(item.kind)?`<div><dt>能力与计费验证</dt><dd>${item.capabilityTestedAt?(Date.now()-Date.parse(item.capabilityTestedAt)<86400000?'已通过 · ':'验证已过期 · ')+date(item.capabilityTestedAt):'尚未通过'}</dd></div>`:''}</dl><details class="b-config-details"><summary>查看非敏感配置</summary><pre>${e(JSON.stringify(item.publicConfig || {}, null, 2))}</pre></details><div class="b-table-actions">${['text','image'].includes(item.kind)?`<button type="button" class="ui-button ui-button--secondary" data-action="functional-open" data-config-id="${e(item.id)}">能力与计费测试</button>`:''}${integrationAction('新建替换版本', 'clone-integration', `data-item-id="${e(item.id)}"`)}${integrationAction('验证连接', 'integration-test', `data-item-id="${e(item.id)}" ${item.status === 'active' ? 'disabled title="当前版本已启用，请新建版本验证"' : ''}`)}${item.status === 'active' ? integrationAction('停用', 'integration-disable', `data-item-id="${e(item.id)}"`) : integrationAction('启用此版本', 'integration-activate', `data-item-id="${e(item.id)}" ${!activationReady(item) ? 'disabled title="请完成连接与所需的能力计费验证；图片功能尚未开放"' : ''}`)}</div></article>`).join('') : '<div class="b-empty">' + icon('server') + '<h2>还没有连接外部服务</h2><p>从 AI、支付或 CMS 连接服务开始配置。</p></div>'}</section></section>`;
}

function numberField(label, name, value = '', hint = '') {
  return field(label, name, value, { type: 'number', hint, max: 30 }).replace('type="number"', 'type="number" min="0" step="any"');
}

function integrationFields(kind, item = {}) {
  const config = item.publicConfig || {};
  if (kind === 'text' || kind === 'image') {
    const priceValue = name => config[name] == null ? '' : config[name] / 1e6;
    const imageFields = `<p class="b-notice-text">图片配置仅保存价格和模型参数。生产生图需通过服务端费用上限审核，目前不会发送付费图片请求。</p><div class="b-config-input-grid">${select('图片尺寸', 'size', { '1024x1024': '正方形 1024 × 1024', '1536x1024': '横图 1536 × 1024', '1024x1536': '竖图 1024 × 1536' }, config.size || '1024x1024')}${select('生成质量', 'quality', { low: '低', medium: '中', high: '高', xhigh: '更高', max: '最高' }, config.quality || 'medium')}${select('生成复杂度', 'complexity', { low: '低', medium: '中', high: '高' }, config.complexity || 'medium')}${numberField('文本输入（美元 / 百万 tokens）', 'textInputPrice', priceValue('textInputMicrosPerMillion'))}${numberField('缓存文本输入（美元 / 百万 tokens）', 'cachedTextInputPrice', priceValue('cachedTextInputMicrosPerMillion'))}${numberField('图片输入（美元 / 百万 tokens）', 'imageInputPrice', priceValue('imageInputMicrosPerMillion'))}${numberField('缓存图片输入（美元 / 百万 tokens）', 'cachedImageInputPrice', priceValue('cachedImageInputMicrosPerMillion'))}${numberField('图片输出（美元 / 百万 tokens）', 'imageOutputPrice', priceValue('imageOutputMicrosPerMillion'))}</div><p class="b-field-hint">每次生成 1 张 PNG。缓存价格不得高于对应输入价格。</p>`;
    return `${select('API 服务', 'provider', kind === 'image' ? { openai: 'OpenAI 官方 API' } : { openai: 'OpenAI 官方 API', 'openai-compatible': '兼容 OpenAI 的 API' }, item.provider || 'openai')}${field('API 地址', 'baseUrl', config.baseUrl || 'https://api.openai.com/v1', { type: 'url', max: 500 })}${field('模型 ID', 'model', config.model || '', { max: 200, hint: '填写服务商提供的模型标识，平台不会自行替换模型。' })}${field('API 密钥', 'apiKey', '', { type: 'password', max: 8192 })}${field('供应商预算池 ID', 'providerPoolId', config.providerPoolId || 'openai-main', { max: 100, hint: '同一供应商账户使用同一预算池，防止更换模型后重复分配余额。' })}${kind === 'text' ? `${select('文本计费规则', 'billingProfile', { unverified: '未审核 · 禁止付费请求', 'openai-gpt6-standard-2026-11-07': '已审核 OpenAI GPT-6 标准计费（2026-11-07）' }, config.billingProfile || 'unverified')}${select('缓存有效期', 'cacheTtl', { '30m': '30 分钟', '12h': '12 小时' }, config.cacheTtl || '30m')}<p class="b-field-hint">已审核规则会由服务端精确核对模型、官方接口、价格及上下文上限。配置不匹配时仍会阻止请求。</p><div class="b-config-input-grid">${numberField('输入价格（美元 / 百万 tokens）', 'inputPrice', priceValue('inputMicrosPerMillion'))}${numberField('缓存输入价格（美元 / 百万 tokens）', 'cachedInputPrice', priceValue('cachedInputMicrosPerMillion'))}${numberField('输出价格（美元 / 百万 tokens）', 'outputPrice', priceValue('outputMicrosPerMillion'))}${numberField('上下文上限（tokens）', 'contextTokens', config.contextTokens || '')}${numberField('单次最大输出（tokens）', 'maxOutputTokens', config.maxOutputTokens || '')}</div>` : imageFields}<label class="b-confirm-checkbox"><input type="checkbox" name="pricingConfirmed" required><span>我已核对服务商当前价格与模型限制，并确认以上配置。</span></label>`;
  }
  if (kind === 'payment') return `${select('支付环境', 'mode', { test: '测试环境', live: '正式环境' }, config.mode || 'test')}<p class="b-field-hint">支付服务：Stripe · API 版本 2026-10-28.endive</p>${field('支付密钥', 'secretKey', '', { type: 'password', max: 8192 })}${field('Webhook 签名密钥', 'webhookSecret', '', { type: 'password', max: 8192, hint: '支付权益只在验证签名的支付通知到达后发放。' })}`;
  if (kind === 'hosting') {
    const legacy = config.deploymentMode === 'registered-php-bridge';
    return `<input type="hidden" name="deploymentMode" value="${legacy ? 'registered-php-bridge' : 'hostinger-tus-bootstrap'}"><p class="b-notice-text">${legacy ? '为已注册的 PHP 连接服务创建替换版本。' : '自动安装模式：用户提交网站信息后，平台在主机账户中上传已核验发行包，创建数据库并安装 CMS。服务验证通过后才能启用。'}</p>${numberField('主机订单 ID', 'hostingOrderId', config.hostingOrderId || '', '填写 hPanel 对应主机套餐的订单编号。')}${field('主机账户用户名', 'accountUsername', config.accountUsername || '', { max: 21, hint: '使用以 u 开头、后接数字的主机账户用户名。' })}${field('主机 API Token', 'hostingerApiToken', '', { type: 'password', max: 8192 })}${legacy ? `${field('CMS 连接服务地址', 'endpoint', config.endpoint || '', { type: 'url', max: 500 })}${field('签名密钥 ID', 'keyId', config.keyId || '', { max: 80 })}${field('请求签名密钥', 'signingSecret', '', { type: 'password', max: 512, hint: '至少 32 个字符，与连接服务中保存的签名密钥一致。' })}` : `<label class="b-field"><span>上传受管 CMS 发行包</span><input type="file" name="cmsReleaseFile" accept=".zip,application/zip"><small class="b-field-hint">选择不超过 48 MiB 的受管 CMS ZIP。上传并通过服务端核验后填入下方配置，不会自动启用服务。</small></label>${action('上传并校验发行包', 'upload-cms-release')}<p class="b-field-hint" role="status" data-cms-upload-status></p>${field('私有 CMS 发行包对象键', 'cmsReleaseObjectKey', config.cmsReleaseObjectKey || '', { max: 300, hint: '使用平台私有存储中的发行包路径，例如 private/cms-releases/benos-cms.zip。' })}${field('发行包 SHA256', 'cmsReleaseSha256', config.cmsReleaseSha256 || '', { max: 64, hint: '填写发布包构建清单中的 64 位 SHA256，不可使用未经核验的文件。' })}${numberField('发行包大小（字节）', 'cmsReleaseSize', config.cmsReleaseSize || '', '填写构建清单中的精确字节数，最大 48 MiB。')}`}`;
  }
  if (kind === 'email') return `<p class="b-notice-text">邮件服务：Resend。用于邮箱验证、找回密码与账户通知。发信域名应先完成供应商验证。</p>${field('发件邮箱', 'fromEmail', config.fromEmail || '', { type: 'email', max: 254 })}${field('发件人名称', 'fromName', config.fromName || 'Benos', { max: 80 })}${field('回复邮箱', 'replyTo', config.replyTo || '', { type: 'email', max: 254, required: false })}${field('邮件 API 密钥', 'apiKey', '', { type: 'password', max: 8192 })}`;
  return '';
}

function integrationForm(item = {}) {
  const supported = { text: '文本 AI', image: '图像 AI', payment: '支付', hosting: 'CMS 连接', email: '账户邮件' };
  return modal(item.id ? '新建替换版本' : '新增服务配置', '旧版本保持不变。新版本通过验证后才可启用。', 'integration', `<fieldset class="b-form-section"><legend>配置身份</legend><div class="b-config-input-grid">${select('服务类型', 'kind', supported, item.kind || 'text')}${field('配置名称', 'name', item.name || '', { max: 80 })}</div></fieldset><fieldset class="b-form-section"><legend>连接与计费参数</legend><div data-integration-fields>${integrationFields(item.kind || 'text', item)}</div></fieldset>${formFooter('保存新版本')}`);
}

export function updateIntegrationFields(form) {
  const target = form.querySelector('[data-integration-fields]');
  if (target) target.innerHTML = integrationFields(form.elements.kind.value);
}

function toMicros(value, allowZero = false) {
  if (!/^\d+(?:\.\d{1,6})?$/.test(String(value))) throw new Error('美元金额最多支持 6 位小数，请填写有效价格。');
  const [whole, fraction = ''] = String(value).split('.');
  const result = Number(BigInt(whole) * 1000000n + BigInt(fraction.padEnd(6, '0')));
  if (!Number.isSafeInteger(result) || (allowZero ? result < 0 : result <= 0)) throw new Error('请输入大于 0 的有效价格。');
  return result;
}



async function uploadCmsRelease(trigger, context) {
  if (context.state.user.role !== 'owner') throw new Error('只有平台所有者可以上传受管 CMS 发行包。');
  const form = trigger.closest('form[data-form="admin-integration"]');
  if (!form || form.dataset.cmsUploading === 'true' || form.elements.deploymentMode?.value !== 'hostinger-tus-bootstrap') return;
  const input = form.elements.cmsReleaseFile, file = input?.files?.[0];
  if (!file || !file.size || file.size > 48 * 1048576 || !/\.zip$/i.test(file.name)) throw new Error('请选择不超过 48 MiB 的非空 ZIP 发行包。');
  const status = form.querySelector('[data-cms-upload-status]');
  const fields = ['cmsReleaseObjectKey', 'cmsReleaseSha256', 'cmsReleaseSize'].map(name => form.elements[name]);
  const controls = [trigger, input, form.elements.kind, form.querySelector('[type="submit"]')].filter(Boolean);
  const disabled = controls.map(control => control.disabled), readOnly = fields.map(field => field.readOnly);
  form.dataset.cmsUploading = 'true'; controls.forEach(control => { control.disabled = true; }); fields.forEach(field => { field.readOnly = true; });
  try {
    status.textContent = '正在计算发行包校验值…';
    const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await file.arrayBuffer())), byte => byte.toString(16).padStart(2, '0')).join('');
    if (!form.isConnected) return;
    status.textContent = '正在上传并核验发行包…';
    const result = await api('/admin/cms-releases/upload', { method: 'POST', raw: true, body: file, headers: { 'Content-Type': 'application/zip', 'X-Content-Sha256': digest } });
    if (!form.isConnected) return;
    if (result.verified !== true || result.cmsReleaseSha256 !== digest || result.cmsReleaseSize !== file.size || typeof result.cmsReleaseObjectKey !== 'string' || !result.cmsReleaseObjectKey || result.cmsReleaseObjectKey.length > 300) throw new Error('发行包核验结果与本地文件不一致，原配置保持不变。');
    fields[0].value = result.cmsReleaseObjectKey; fields[1].value = result.cmsReleaseSha256; fields[2].value = String(result.cmsReleaseSize);
    status.textContent = `发行包已上传并核验（${file.size.toLocaleString('zh-CN')} 字节）。请保存新版本，再验证连接并启用。`;
    input.value = '';
    context.notify('发行包已核验并填入配置，尚未保存或启用服务');
  } catch (error) {
    if (form.isConnected) status.textContent = '上传或核验未完成，下方原配置保持不变。';
    throw error;
  } finally {
    delete form.dataset.cmsUploading;
    controls.forEach((control, index) => { control.disabled = disabled[index]; });
    fields.forEach((field, index) => { field.readOnly = readOnly[index]; });
  }
}

export async function handleAdminAction(name, trigger, context) {
  if(name.startsWith('admin-marketing-media-')) return handleMarketingMediaAction(name,trigger,context);
  if(['admin-content-select-all','admin-content-bulk-review','admin-content-references'].includes(name)) return handleContentListAction(name,trigger,context);
  const { state, showModal, reload, notify } = context;
  const item = list(state.resource).find(row => row.id === trigger.dataset.itemId);
  if (name === 'admin-upload-cms-release') { await uploadCmsRelease(trigger, context); return true; }
  if (name === 'admin-more-content') { await loadMoreContent(trigger, context); return true; }
  if (name === 'admin-restrict') {
    showModal(modal('限制账户权限', '仅限制所选能力，不改变会员到期时间。请记录具体原因。', 'restrict', `<fieldset class="b-scope-options"><legend>限制范围</legend>${Object.entries(scopes).map(([key, label]) => `<label><input type="checkbox" name="scopes" value="${key}"><span>${label}</span></label>`).join('')}</fieldset>${field('限制原因', 'reason', '', { textarea: true, max: 500 })}${field('自动解除时间', 'endsAt', '', { type: 'datetime-local', required: false, hint: '留空表示由管理员手动解除。' })}${formFooter('确认限制')}`, `data-user-id="${e(trigger.dataset.userId)}"`));
  } else if (name === 'admin-revoke') {
    showModal(modal('解除会员限制', '保留原限制记录，并新增恢复操作审计。', 'revoke', `${field('恢复原因', 'reason', '', { textarea: true, max: 500 })}${formFooter('确认恢复')}`, `data-user-id="${e(trigger.dataset.userId)}" data-restriction-id="${e(trigger.dataset.restrictionId)}"`));
  } else if (name === 'admin-new-content' || name === 'admin-edit-content') {
    if (name === 'admin-edit-content' && !item) throw new Error('内容记录已变化，请刷新后重试。');
    showModal(contentFormMarkup(item, state.resource.references || {}));
  } else if (name === 'admin-new-integration' || name === 'admin-clone-integration') {
    if (name === 'admin-clone-integration' && !item) throw new Error('配置记录已变化，请刷新后重试。');
    showModal(integrationForm(item));
  } else if (name.startsWith('admin-content-')) {
    if (!item) throw new Error('内容记录已变化，请刷新后重试。');
    const operation = name.replace('admin-content-', '');
    const titles = { publish: '发布内容', unpublish: '取消发布', delete: '移入回收站', restore: '恢复内容' };
    const descriptions = { publish: '发布后，此内容可通过公开页面访问。', unpublish: '内容会恢复为草稿，停止公开展示。', delete: '内容会停止公开展示，并保留在回收站中。', restore: '恢复后请检查内容，再决定是否发布。' };
    showModal(modal(titles[operation], descriptions[operation], 'content-state', `<p class="b-confirm-title">${e(item.title)}</p>${formFooter(`确认${titles[operation]}`)}`, `data-item-id="${e(item.id)}" data-revision="${e(item.revision)}" data-operation="${operation}"`));
  } else if (name === 'admin-integration-disable') {
    if (!item) throw new Error('配置记录已变化，请刷新后重试。');
    showModal(modal('停用服务配置', `停用后，依赖“${e(item.name)}”的服务可能暂时不可用。`, 'integration-disable', `${field('停用原因', 'reason', '', { textarea: true, max: 500 })}${formFooter('确认停用')}`, `data-item-id="${e(item.id)}"`));
  } else if (name === 'admin-integration-test' || name === 'admin-integration-activate') {
    if (!item) throw new Error('配置记录已变化，请刷新后重试。');
    const operation = name.endsWith('-test') ? 'test' : 'activate';
    showModal(modal(operation === 'test' ? '验证服务连接' : '启用服务版本', operation === 'test' ? '验证将向此服务发送真实请求，以检查凭据和连接状态。' : '启用后，后续请求将使用此配置版本。', 'integration-operation', `<p class="b-confirm-title">${e(item.name)} · v${e(item.version)}</p>${formFooter(operation === 'test' ? '开始验证' : '确认启用')}`, `data-item-id="${e(item.id)}" data-operation="${operation}"`));
  } else return false;
  return true;
}

export async function submitAdminForm(actionName, form, values, context) {
  if(['admin-content-filter','admin-content-bulk'].includes(actionName)) return submitContentListForm(actionName,form,values,context);
  let message = '操作已完成';
  if (actionName === 'admin-restrict') {
    const selected = new FormData(form).getAll('scopes');
    if (!selected.length) throw new Error('请至少选择一项限制范围。');
    if (values.reason.trim().length < 3) throw new Error('请填写至少 3 个字符的具体原因。');
    await api(`/admin/users/${encodeURIComponent(form.dataset.userId)}/restrictions`, { method: 'POST', body: { scopes: selected, reason: values.reason.trim(), endsAt: values.endsAt ? new Date(values.endsAt).toISOString() : null } });
    message = '会员限制已保存';
  } else if (actionName === 'admin-revoke') {
    if (values.reason.trim().length < 3) throw new Error('请填写至少 3 个字符的恢复原因。');
    await api(`/admin/users/${encodeURIComponent(form.dataset.userId)}/restrictions/${encodeURIComponent(form.dataset.restrictionId)}/revoke`, { method: 'POST', body: { reason: values.reason.trim() } });
    message = '会员限制已解除';
  } else if (actionName === 'admin-content') {
    const body = contentPayload(values, form);
    if (form.dataset.itemId) body.revision = Number(form.dataset.revision);
    await api(`/admin/content${form.dataset.itemId ? '/' + encodeURIComponent(form.dataset.itemId) : ''}`, { method: form.dataset.itemId ? 'PATCH' : 'POST', body });
    message = '内容已保存';
  } else if (actionName === 'admin-content-state') {
    const operation = form.dataset.operation;
    await api(`/admin/content/${encodeURIComponent(form.dataset.itemId)}${operation === 'delete' ? '' : '/' + operation}`, { method: operation === 'delete' ? 'DELETE' : 'POST', body: { revision: Number(form.dataset.revision) } });
    message = operation === 'delete' ? '内容已移入回收站' : '内容状态已更新';
  } else if (actionName === 'admin-integration') {
    if (form.dataset.cmsUploading === 'true') throw new Error('请等待发行包上传和核验完成后再保存配置。');
    let publicConfig, secret, provider;
    if (values.kind === 'text' || values.kind === 'image') {
      if (!values.pricingConfirmed) throw new Error('请核对并确认服务价格与限制。');
      provider = values.provider;
      publicConfig = { baseUrl: values.baseUrl.trim(), model: values.model.trim(), protocol: values.kind === 'text' ? 'responses' : 'images', providerPoolId: values.providerPoolId.trim(), pricingConfirmedAt: new Date().toISOString(), ...(values.kind === 'text' ? { billingProfile: values.billingProfile, cacheTtl: values.cacheTtl, inputMicrosPerMillion: toMicros(values.inputPrice), cachedInputMicrosPerMillion: toMicros(values.cachedInputPrice, true), outputMicrosPerMillion: toMicros(values.outputPrice), contextTokens: Number(values.contextTokens), maxOutputTokens: Number(values.maxOutputTokens) } : { size: values.size, quality: values.quality, complexity: values.complexity, n: 1, outputFormat: 'png', textInputMicrosPerMillion: toMicros(values.textInputPrice), cachedTextInputMicrosPerMillion: toMicros(values.cachedTextInputPrice, true), imageInputMicrosPerMillion: toMicros(values.imageInputPrice, true), cachedImageInputMicrosPerMillion: toMicros(values.cachedImageInputPrice, true), imageOutputMicrosPerMillion: toMicros(values.imageOutputPrice), billingContract: { kind: 'unverified' } }) };
      secret = { apiKey: values.apiKey };
    } else if (values.kind === 'payment') {
      provider = 'stripe'; publicConfig = { mode: values.mode, apiVersion: '2026-10-28.endive' }; secret = { secretKey: values.secretKey, webhookSecret: values.webhookSecret };
    } else if (values.kind === 'hosting') {
      provider = 'benos-bridge';
      const legacy = values.deploymentMode === 'registered-php-bridge';
      publicConfig = { adapter: 'hostinger-hpanel', deploymentMode: values.deploymentMode, hostingOrderId: Number(values.hostingOrderId), accountUsername: values.accountUsername.trim(), ...(legacy ? { endpoint: values.endpoint.trim(), keyId: values.keyId.trim() } : { cmsReleaseObjectKey: values.cmsReleaseObjectKey.trim(), cmsReleaseSha256: values.cmsReleaseSha256.trim(), cmsReleaseSize: Number(values.cmsReleaseSize) }) };
      secret = { hostingerApiToken: values.hostingerApiToken, ...(legacy ? { signingSecret: values.signingSecret } : {}) };
    } else if (values.kind === 'email') {
      provider = 'resend'; publicConfig = { fromEmail: values.fromEmail.trim(), fromName: values.fromName.trim(), ...(values.replyTo.trim() ? { replyTo: values.replyTo.trim() } : {}) }; secret = { apiKey: values.apiKey };
    } else throw new Error('该服务类型尚未开放配置。');
    await api('/admin/integrations', { method: 'POST', body: { kind: values.kind, name: values.name.trim(), provider, publicConfig, secret } });
    message = '新配置版本已保存，请先验证连接';
  } else if (actionName === 'admin-integration-operation') {
    const result = await api(`/admin/integrations/${encodeURIComponent(form.dataset.itemId)}/${form.dataset.operation}`, { method: 'POST', body: {} });
    message = result.message || (form.dataset.operation === 'test' ? '连接验证已完成，请查看验证状态' : '服务版本已启用');
  } else if (actionName === 'admin-integration-disable') {
    await api(`/admin/integrations/${encodeURIComponent(form.dataset.itemId)}/disable`, { method: 'POST', body: { reason: values.reason.trim() } });
    message = '服务配置已停用';
  } else return false;
  context.closeModal();
  await context.reload();
  context.notify(message);
  return true;
}
