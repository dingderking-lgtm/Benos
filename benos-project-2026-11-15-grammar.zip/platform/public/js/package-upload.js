import { api } from './api.js';
import { escapeHtml as e } from './icons.js';

const MIB = 1048576;
const records = new Map();
const terminal = new Set(['ready', 'failed', 'cancelled', 'expired']);
const keyFor = (user, project) => `benos-package-upload:${user}:${project}`;
const phases = { directory: '检查 ZIP 目录', manifest: '校验模板清单', assets: '校验素材内容', commit: '保存候选方案', complete: '候选方案已准备' };
const counts = value => new Intl.NumberFormat('zh-CN').format(value);
const path = id => `/design/package-uploads/${encodeURIComponent(id)}`;

function recordFor(data, user) {
  const key = keyFor(user.id, data.project.id);
  if (!records.has(key)) {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(key) || 'null'); } catch { /* Private browsing can disable storage. */ }
    if (!saved || typeof saved.requestKey !== 'string' || typeof saved.fileName !== 'string' || !Number.isSafeInteger(saved.totalBytes)) saved = null;
    records.set(key, { key, projectId: data.project.id, userId: user.id, saved, view: null, file: null, checked: new Map(), running: false, epoch: 0, mounted: null, message: '', error: '' });
  }
  return records.get(key);
}
function persist(record) {
  try { if (record.saved) localStorage.setItem(record.key, JSON.stringify(record.saved)); else localStorage.removeItem(record.key); } catch { /* Same-page recovery still uses memory. */ }
}
function accept(record, view) {
  if (!view || typeof view.id !== 'string' || view.projectId !== record.projectId || view.totalBytes !== record.saved.totalBytes || view.chunkSize !== MIB || !Number.isSafeInteger(view.receivedBytes) || view.receivedBytes < 0 || view.receivedBytes > view.totalBytes || view.nextOffset !== view.receivedBytes || !Array.isArray(view.chunks) || view.chunks.length > 74 || !Number.isSafeInteger(view.completedSteps) || view.completedSteps < 0 || !['uploading', 'processing', 'ready', 'failed', 'cancelled', 'expired'].includes(view.state)) throw new Error('上传进度身份或格式不一致，请保留原任务并重试。');
  let confirmed = 0;
  view.chunks.forEach((chunk, index) => {
    if (chunk.index !== index || chunk.offset !== confirmed || chunk.size !== Math.min(MIB, view.totalBytes - confirmed) || !/^[a-f0-9]{64}$/.test(chunk.sha256)) throw new Error('已确认分块记录不完整，请保留原任务并重试。');
    confirmed += chunk.size;
  });
  if (confirmed !== view.receivedBytes || record.saved.uploadId && record.saved.uploadId !== view.id) throw new Error('服务器确认的分块与上传任务不匹配。');
  record.view = view; record.saved.uploadId = view.id;
  if (record.saved.pendingStep && view.completedSteps >= record.saved.pendingStep) delete record.saved.pendingStep;
  persist(record); update(record); return view;
}
function current(record, epoch) {
  return record.epoch === epoch && record.mounted?.dialog.open && record.mounted.context.state.user?.id === record.userId && record.mounted.context.state.resource?.project?.id === record.projectId;
}
function status(record) {
  const view = record.view;
  if (!record.saved) return '选择完整 ZIP 站点包开始导入。';
  if (!view) return '原请求已保留。继续时会核对同一个上传任务。';
  if (view.state === 'ready') return '候选方案已生成，尚未采用或发布。';
  if (view.state === 'failed') return '文件未通过检查。原项目未被覆盖，可查看错误后重新上传。';
  if (view.state === 'cancelled') return '服务器已确认取消上传。';
  if (view.state === 'expired') return '上传任务已到期，请重新创建上传。';
  if (view.busy) return '原步骤仍在处理，请稍后更新状态。';
  return view.state === 'processing' ? phases[view.phase] || '正在校验站点包' : '上传 ZIP 文件';
}
function update(record) {
  const form = record.mounted?.dialog.querySelector('[data-form="design-package-upload"]');
  if (!form || !record.mounted.dialog.open) return;
  const view = record.view, active = !!record.saved && !terminal.has(view?.state), blocked = !!record.mounted.context.state.resource.project.current_version_id;
  form.querySelector('[data-package-status]').textContent = status(record);
  const meta = form.querySelector('[data-package-meta]'); meta.textContent = record.saved ? `${record.saved.fileName} · ${counts(record.saved.totalBytes)} 字节` : '';
  const progress = form.querySelector('progress'); progress.hidden = !view; progress.max = view?.totalBytes || 1; progress.value = view?.receivedBytes || 0;
  form.querySelector('[data-package-confirmed]').textContent = view ? `服务器已确认 ${counts(view.receivedBytes)} / ${counts(view.totalBytes)} 字节${view.state === 'processing' || view.state === 'ready' ? `；条目已校验 ${counts(view.entriesVerified)} / ${counts(view.entriesTotal)}` : ''}` : '';
  form.querySelector('[data-package-expiry]').textContent = view?.expiresAt ? `任务保留至 ${new Date(view.expiresAt).toLocaleString('zh-CN')}。已确认的分块可在期限内继续。` : '';
  form.querySelector('[data-package-message]').textContent = record.message;
  const error = form.querySelector('[data-package-error]'); error.textContent = record.error || (view?.errorCode ? `状态代码：${view.errorCode}` : ''); error.hidden = !error.textContent;
  const file = form.elements.package; file.disabled = blocked || record.running || !!view && view.state !== 'uploading'; file.required = !view || view.state === 'uploading';
  const submit = form.querySelector('[type="submit"]'); submit.disabled = blocked || record.running || terminal.has(view?.state); submit.hidden = terminal.has(view?.state); submit.textContent = record.running ? '正在处理…' : view?.state === 'processing' ? '继续校验' : record.saved ? '核对并继续' : '开始分块上传';
  form.querySelector('[data-action="design-package-refresh"]').hidden = !record.saved?.uploadId;
  form.querySelector('[data-action="design-package-refresh"]').disabled = record.running;
  form.querySelector('[data-action="design-package-pause"]').hidden = !record.running;
  form.querySelector('[data-action="design-package-cancel"]').hidden = !active;
  form.querySelector('[data-action="design-package-cancel"]').disabled = record.running;
  form.querySelector('[data-action="design-package-new"]').hidden = !terminal.has(view?.state);
  form.querySelector('[data-action="design-package-preview"]').hidden = view?.state !== 'ready' || !view.candidateId;
  form.querySelector('[data-package-reselect]').hidden = !(active && (!view || view.state === 'uploading'));
}
export function renderPackageUploadForm(data, user) {
  const blocked = !!data.project.current_version_id;
  const record = recordFor(data, user);
  return `<form class="b-modal-body" data-form="design-package-upload"><p class="b-notice-text">完整 ZIP 包包含 manifest.json 与素材。最大 74 MiB（含 ZIP 目录），清单最多 10 MiB，素材合计最多 64 MiB。上传按 1 MiB 分块确认；通过检查后生成待采用方案。</p>${blocked ? '<p class="b-notice-text">此项目已有设计，请在空项目中导入，避免覆盖已有版本。</p>' : ''}<label class="b-field"><span>选择 ZIP 站点包</span><input type="file" name="package" accept="application/zip,.zip" ${blocked ? 'disabled' : ''} required><small class="b-field-hint">支持规范内的 PNG、JPEG、WebP、GIF、安全 SVG 和普通 PDF 素材；单张素材仍受格式与大小限制。</small></label><div class="b-notice"><div><strong data-package-status>${e(status(record))}</strong><p data-package-meta style="overflow-wrap:anywhere"></p><progress aria-label="服务器已确认的 ZIP 上传进度" value="0" max="1" style="width:100%" hidden></progress><p data-package-confirmed aria-live="polite"></p><p data-package-expiry></p></div></div><p class="b-muted" data-package-reselect hidden>恢复上传需重新选择原 ZIP；会逐块核对服务器已接收内容，不会仅凭文件名判断一致，也不表示整个 ZIP 摘要已核验。</p><p class="b-muted">关闭弹窗会暂停文件发送；已上传完整的文件可由后台继续校验。再次点击“导入模板”可查看或继续原任务。文件内容只在当前页面内存中，不写入浏览器持久存储。</p><p class="b-muted" data-package-message aria-live="polite"></p><p class="b-form-error" role="alert" data-package-error hidden></p><p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">关闭并保留任务</button><button type="button" class="ui-button ui-button--secondary" data-action="design-package-refresh" hidden>更新原任务</button><button type="button" class="ui-button ui-button--secondary" data-action="design-package-pause" hidden>暂停并保留进度</button><button type="button" class="ui-button ui-button--secondary" data-action="design-package-cancel" hidden>取消上传任务</button><button type="button" class="ui-button ui-button--secondary" data-action="design-package-new" hidden>新建上传</button><button type="button" class="ui-button ui-button--primary" data-action="design-package-preview" hidden>预览候选方案</button><button type="submit" class="ui-button ui-button--primary" ${blocked ? 'disabled' : ''}>开始分块上传</button></div></form>`;
}
export function mountPackageUpload(context) {
  const record = recordFor(context.state.resource, context.state.user), dialog = document.querySelector('#modal');
  if (!dialog?.querySelector('[data-form="design-package-upload"]')) return;
  record.mounted = { context, dialog }; record.error = ''; update(record);
  if (context.state.resource.project.current_version_id) { dialog.querySelectorAll('[data-form="design-package-upload"] input, [data-form="design-package-upload"] [type="submit"]').forEach(node => { node.disabled = true; }); }
  dialog.addEventListener('close', () => { record.epoch++; record.mounted = null; }, { once: true });
  if (record.saved?.uploadId && !record.running) void refresh(record).catch(error => { record.error = error.message; update(record); });
}
export function stopPackageUploadLoops() { for (const record of records.values()) { record.epoch++; record.mounted = null; } }
async function refresh(record) { return accept(record, await api(path(record.saved.uploadId))); }
async function hash(bytes) { return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(byte => byte.toString(16).padStart(2, '0')).join(''); }
async function checkFile(record, epoch) {
  if (!record.file || record.file.name !== record.saved.fileName || record.file.size !== record.saved.totalBytes) throw new Error('请重新选择原 ZIP 文件，文件名和大小必须匹配；随后还会核对已上传的每个分块。');
  for (const chunk of record.view?.chunks || []) {
    if (!current(record, epoch)) return false;
    if (record.checked.get(chunk.index) === chunk.sha256) continue;
    record.message = `正在核对已确认分块 ${chunk.index + 1} / ${record.view.chunks.length}…`; update(record);
    const actual = await hash(await record.file.slice(chunk.offset, chunk.offset + chunk.size).arrayBuffer());
    if (actual !== chunk.sha256) throw new Error(`第 ${chunk.index + 1} 个已上传分块与所选文件不一致。已停止，原任务和已确认内容均保留，请选择正确文件。`);
    record.checked.set(chunk.index, actual);
  }
  record.message = ''; return current(record, epoch);
}
async function run(record) {
  if (record.running) return;
  const epoch = ++record.epoch; record.running = true; record.error = ''; update(record);
  try {
    if (!record.saved.uploadId) accept(record, await api(`/design/projects/${encodeURIComponent(record.projectId)}/package-uploads`, { method: 'POST', body: { requestKey: record.saved.requestKey, fileName: record.saved.fileName, totalBytes: record.saved.totalBytes } }));
    else await refresh(record);
    if (!current(record, epoch)) return;
    if (record.view.busy) { record.message = '原步骤仍在处理，稍后更新原任务即可。'; return; }
    if (record.view.state === 'uploading' && !await checkFile(record, epoch)) return;
    while (current(record, epoch) && !terminal.has(record.view.state)) {
      if (record.view.busy) { record.message = '原步骤仍在处理，请稍后继续。'; break; }
      if (record.view.state === 'uploading') {
        const offset = record.view.nextOffset, index = offset / MIB, bytes = await record.file.slice(offset, Math.min(offset + MIB, record.file.size)).arrayBuffer();
        const sha256 = await hash(bytes);
        if (!current(record, epoch)) break;
        accept(record, await api(`${path(record.saved.uploadId)}/chunks/${index}`, { method: 'PUT', raw: true, body: bytes, headers: { 'Content-Type': 'application/octet-stream', 'X-Chunk-SHA256': sha256, 'X-Chunk-Offset': String(offset) } })); record.checked.set(index, sha256);
      } else if (record.view.state === 'processing') {
        const step = record.saved.pendingStep || record.view.completedSteps + 1;
        record.saved.pendingStep = step; persist(record);
        accept(record, await api(`${path(record.saved.uploadId)}/continue`, { method: 'POST', body: { step } }));
      } else break;
    }
    if (record.view?.state === 'ready') record.message = '内容已通过导入检查。请预览候选并手动采用，网站尚未发布。';
  } catch (error) {
    record.error = error.message;
    if (record.saved?.uploadId) { try { await refresh(record); } catch { /* Preserve the original step and error for retry. */ } }
    record.message = '已暂停当前页面自动处理。已确认进度与原请求编号已保留，继续时会先核对原任务。';
  } finally { record.running = false; update(record); }
}
export async function submitPackageUploadForm(name, form, _values, context) {
  if (name !== 'design-package-upload') return false;
  if (context.state.resource.project.current_version_id) throw new Error('请新建空项目导入完整 ZIP 包。');
  const record = recordFor(context.state.resource, context.state.user), file = form.elements.package.files[0];
  if (file) {
    if (!/\.zip$/i.test(file.name) || file.size < 22 || file.size > 74 * MIB || file.name.length > 180) throw new Error('请选择 22 字节至 74 MiB 的 ZIP 站点包，文件名不超过 180 字符。');
    if (record.file !== file) { record.file = file; record.checked.clear(); }
  }
  if (!record.saved) {
    if (!record.file) throw new Error('请选择 ZIP 站点包。');
    record.saved = { requestKey: crypto.randomUUID(), fileName: record.file.name, totalBytes: record.file.size, lastModified: record.file.lastModified }; persist(record);
  }
  if ((!record.view || record.view.state === 'uploading') && (!record.file || record.file.name !== record.saved.fileName || record.file.size !== record.saved.totalBytes)) throw new Error('请重新选择与原任务文件名、大小相同的 ZIP，再逐块核对已上传内容。');
  void run(record); setTimeout(() => update(record), 0); return true;
}
export async function handlePackageUploadAction(name, _trigger, context) {
  if (!name.startsWith('design-package-')) return false;
  const record = recordFor(context.state.resource, context.state.user);
  if (name === 'design-package-pause') { record.epoch++; record.message = '已请求暂停，当前请求结束后保留原任务，不再发送下一块。'; update(record); return true; }
  if (record.running) throw new Error('当前请求正在处理，可关闭弹窗后稍后继续原任务。');
  record.error = '';
  if (name === 'design-package-refresh' && record.saved?.uploadId) await refresh(record);
  else if (name === 'design-package-cancel' && record.saved) {
    record.epoch++;
    if (!record.saved.uploadId) accept(record, await api(`/design/projects/${encodeURIComponent(record.projectId)}/package-uploads`, { method: 'POST', body: { requestKey: record.saved.requestKey, fileName: record.saved.fileName, totalBytes: record.saved.totalBytes } }));
    accept(record, await api(`${path(record.saved.uploadId)}/cancel`, { method: 'POST', body: {} }));
    record.message = record.view.state === 'cancelled' ? '服务器已确认取消，可新建上传。' : '原任务状态已更新，请查看结果。';
  } else if (name === 'design-package-new') {
    if (!terminal.has(record.view?.state)) throw new Error('请先核对或取消原上传任务。');
    record.saved = null; record.view = null; record.file = null; record.checked.clear(); record.message = ''; persist(record);
    const input = record.mounted?.dialog.querySelector('[name="package"]'); if (input) input.value = '';
  } else if (name === 'design-package-preview') {
    await refresh(record);
    if (record.view.state !== 'ready' || !record.view.candidateId) throw new Error('候选方案尚未准备好，请先更新状态。');
    context.closeModal(); context.navigate(`design/${encodeURIComponent(record.projectId)}?candidate=${encodeURIComponent(record.view.candidateId)}`); context.notify('完整包已准备，请预览后采用');
  } else return false;
  update(record); return true;
}
