import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
const error = '<p class="b-form-error" role="alert" data-form-error hidden></p>';
const action = (label, name, attributes = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="security-${name}" ${attributes}>${label}</button>`;
const field = (label, name, options = {}) => `<label class="b-field"><span>${label}</span><input name="${name}" type="${options.type || 'password'}" value="${e(options.value || '')}" required ${options.type === 'email' ? 'maxlength="254"' : 'minlength="12" maxlength="128"'} autocomplete="${options.autocomplete || 'new-password'}">${options.hint ? `<small class="b-field-hint">${e(options.hint)}</small>` : ''}</label>`;
const footer = title => `${error}<div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">${title}</button></div>`;
const modal = (title, description, name, content, attributes = '') => `<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${description}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="security-${name}" ${attributes}>${content}</form>`;

/** data = {user, sessions:{items:[{id,createdAt,expiresAt,current}]}}. */
export function renderSecuritySettings(data = {}) {
  const user = data.user || data.profile || data;
  const sessions = data.sessions?.items || data.items || [];
  return `<section class="b-card b-settings-row"><div class="b-card-heading"><h2>邮箱验证</h2><p>验证邮箱，方便恢复账号并接收账户邮件。</p></div><div><p>${e(user.email || '')}</p><p><span class="b-badge">${user.email_verified_at ? '已验证' : '尚未验证'}</span></p>${user.email_verified_at ? '' : action('申请验证邮件', 'verify-request')}</div></section><section class="b-card b-settings-row"><div class="b-card-heading"><h2>登录密码</h2><p>修改密码后，所有登录会话都会退出。</p></div><div>${action('修改密码', 'change-password')}</div></section><section class="b-card"><div class="b-section-heading"><div><h2>登录会话</h2><p>管理仍有效的登录状态。</p></div>${sessions.some(item => !item.current) ? action('退出其他会话', 'revoke-others') : ''}</div>${sessions.length ? `<div class="b-table-wrap"><table class="b-table"><thead><tr><th>会话</th><th>登录时间</th><th>到期时间</th><th>操作</th></tr></thead><tbody>${sessions.map(item => `<tr><td>${item.current ? '<span class="b-badge">当前会话</span>' : '其他会话'}</td><td>${date(item.createdAt)}</td><td>${date(item.expiresAt)}</td><td>${item.current ? '正在使用' : action('退出此会话', 'revoke-session', `data-session-id="${e(item.id)}"`)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="b-muted">暂无可展示的会话，请刷新后再试。</p>'}</section>`;
}

/** The caller captures the fragment once and removes it with history.replaceState.
 * Rendering never verifies a token or performs a network request. */
export function renderAccountTokenPage(kind, token) {
  const reset = kind === 'reset' || kind === 'reset-password';
  const title = reset ? '设置新的登录密码' : '验证你的邮箱';
  if (!/^[A-Za-z0-9_-]{43}$/.test(token || '')) return `<section class="s-page"><section class="b-card"><div class="b-card-heading"><h1>链接无效或已失效</h1><p>请从邮件中打开完整链接，或重新申请。</p></div>${reset ? action('重新申请重置邮件', 'forgot-password', '', true) : '<a class="ui-button ui-button--primary" href="/">返回 Benos</a>'}</section></section>`;
  return `<section class="s-page"><section class="b-card"><div class="b-card-heading"><h1>${title}</h1><p>${reset ? '密码至少 12 位。保存后，请使用新密码重新登录。' : '点击确认完成邮箱验证。链接只能使用一次。'}</p></div><form data-form="security-${reset ? 'reset-password' : 'verify-email'}"><input type="hidden" name="token" value="${e(token)}">${reset ? field('新密码', 'password', { hint: '使用不易猜测、且未在其他网站使用的密码。' }) + field('确认新密码', 'confirmPassword') : ''}${error}<div class="b-form-actions"><button type="submit" class="ui-button ui-button--primary">${reset ? '保存新密码' : '确认验证邮箱'}</button><a class="ui-button ui-button--secondary" href="/">返回 Benos</a></div></form></section></section>`;
}

export async function handleSecurityAction(name, trigger, context) {
  if (name === 'security-forgot-password') {
    context.showModal(modal('找回登录密码', '填写注册邮箱。邮件服务可用时，系统会尝试发送一次性重置链接。', 'forgot-password', `${field('注册邮箱', 'email', { type: 'email', autocomplete: 'email', value: context.state.user?.email || '' })}${footer('申请重置链接')}`));
    return true;
  }
  if (name === 'security-change-password') {
    context.showModal(modal('修改登录密码', '保存后，所有设备上的旧会话都会退出，请重新登录。', 'change-password', `${field('当前密码', 'currentPassword', { autocomplete: 'current-password' })}${field('新密码', 'newPassword')}${field('确认新密码', 'confirmPassword')}${footer('保存新密码')}`));
    return true;
  }
  if (name === 'security-verify-request') {
    const result = await api('/account/email/verify/request', { method: 'POST', body: {} });
    if (result.verified && context.state.user) context.state.user.email_verified_at ||= new Date().toISOString();
    context.notify(result.verified ? '邮箱已完成验证' : '验证请求已加入发送队列，请稍后检查邮箱');
    return true;
  }
  if (name === 'security-revoke-others' || name === 'security-revoke-session') {
    const target = name === 'security-revoke-others' ? 'others' : trigger.dataset.sessionId;
    if (!target) throw new Error('会话状态已变化，请刷新后重试。');
    const path = target === 'others' ? '/account/sessions/revoke-others' : `/account/sessions/${encodeURIComponent(target)}/revoke`;
    const result = await api(path, { method: 'POST', body: {} });
    if (result.signInRequired) await context.signOutLocal?.();
    else await context.reload();
    context.notify(target === 'others' ? '其他会话已退出' : '所选会话已退出');
    return true;
  }
  return false;
}

export async function submitSecurityForm(name, form, values, context) {
  if (name === 'security-forgot-password') {
    const result = await api('/account/password/forgot', { method: 'POST', body: { email: values.email.trim().toLowerCase() } });
    context.closeModal();context.notify(result.message);return true;
  }
  if (name === 'security-change-password' || name === 'security-reset-password') {
    const reset = name === 'security-reset-password';
    const password = reset ? values.password : values.newPassword;
    if (password !== values.confirmPassword) throw new Error('两次填写的新密码不一致。');
    await api(`/account/password/${reset ? 'reset' : 'change'}`, { method: 'POST', body: reset ? { token: values.token, password } : { currentPassword: values.currentPassword, newPassword: password } });
    form.reset();context.closeModal();await context.signOutLocal?.();
    context.notify('密码已更新，请使用新密码重新登录');return true;
  }
  if (name === 'security-verify-email') {
    await api('/account/email/verify', { method: 'POST', body: { token: values.token } });
    if (context.state.user) context.state.user.email_verified_at = new Date().toISOString();
    form.innerHTML = '<div class="b-notice"><div><strong>邮箱已验证</strong><p>现在可以返回 Benos，继续使用你的账户。</p></div></div><div class="b-form-actions"><a class="ui-button ui-button--primary" href="/">返回 Benos</a></div>';
    context.notify('邮箱验证成功');return true;
  }
  return false;
}
