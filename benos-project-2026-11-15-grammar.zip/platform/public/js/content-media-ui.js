import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const resources=new WeakMap();
const action=(label,name,attrs='')=>`<button type="button" class="ui-button ui-button--secondary" data-action="admin-marketing-media-${name}" ${attrs}>${label}</button>`;
const bytes=value=>`${(value/1048576).toFixed(2)} MiB`;

function render(container,data){
 const {filters,picker}=data;
 container.innerHTML=`<p class="b-notice-text">素材只对管理人员可见。被已发布内容或当前品牌引用后才公开读取；停用后收回对应公开权限。草稿、发布内容或保留的品牌版本引用中的素材不能移入回收站。</p><div class="b-config-input-grid"><label class="b-field"><span>搜索文件名</span><input data-media-filter="q" value="${e(filters.q)}" maxlength="160"></label><label class="b-field"><span>状态</span><select data-media-filter="state"><option value="ready" ${filters.state==='ready'?'selected':''}>可用素材</option><option value="deleted" ${filters.state==='deleted'?'selected':''}>回收站</option><option value="any" ${filters.state==='any'?'selected':''}>全部</option></select></label><label class="b-field"><span>排序</span><select data-media-filter="sort"><option value="newest" ${filters.sort==='newest'?'selected':''}>最近上传</option><option value="name" ${filters.sort==='name'?'selected':''}>文件名升序</option></select></label></div><div class="b-table-actions">${action('搜索与筛选','filter')}${action('全选 / 取消已加载项','select-all')}</div><label class="b-field b-section"><span>上传营销图片</span><input type="file" data-marketing-file accept="image/png,image/jpeg,image/webp"><small class="b-field-hint">PNG、JPEG、WebP，单张不超过12 MiB。</small></label>${action('上传图片','upload')}<div class="b-table-actions b-section">${action('选中项移入回收站','bulk', 'data-operation="delete"')}${action('恢复选中项','bulk','data-operation="restore"')}</div><div data-media-result role="status"></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(210px,100%),1fr));gap:14px;margin-top:18px">${data.items.length?data.items.map(item=>`<article class="b-card" style="padding:16px;min-width:0"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-marketing-select value="${e(item.id)}"><span style="overflow-wrap:anywhere">${e(item.fileName)}</span></label>${item.state==='ready'?`<img src="${e(item.previewUrl)}" alt="${e(item.fileName)}" width="${item.width}" height="${item.height}" style="display:block;width:100%;height:145px;object-fit:contain;margin:10px 0">`:'<p class="b-muted">已移入回收站</p>'}<p class="b-field-hint">${item.width} × ${item.height} · ${bytes(item.byteSize)}</p><div class="b-table-actions">${picker&&item.state==='ready'?action(container.closest('[data-form="settings-brand"]')?'选为 Logo':'选为封面','choose',`data-media-id="${e(item.id)}"`):''}${action('查看引用','references',`data-media-id="${e(item.id)}"`)}${action(item.state==='ready'?'移入回收站':'恢复','state',`data-media-id="${e(item.id)}" data-operation="${item.state==='ready'?'delete':'restore'}"`)}</div></article>`).join(''):'<p class="b-inline-empty">没有匹配的素材。</p>'}</div>${data.nextCursor?`<div class="b-section">${action('加载更多素材','more')}</div>`:''}`;
}
async function load(container,picker=false,filters={q:'',state:'ready',sort:'newest'},append=false){
 const previous=resources.get(container),params=new URLSearchParams(filters);if(append&&previous?.nextCursor)params.set('cursor',previous.nextCursor);
 const data=await api('/admin/content/media?'+params);if(!container.isConnected)return;
 const items=append?[...previous.items,...data.items.filter(item=>!previous.items.some(old=>old.id===item.id))]:data.items;
 const result={...data,items,filters,picker};resources.set(container,result);render(container,result);
}
export async function handleMarketingMediaAction(name,trigger,context){
 if(name==='admin-marketing-media-clear'){
  const form=trigger.closest('form');form.elements.coverMediaId.value='';form.elements.coverUrl.value='';context.notify('已移除素材关联，保存后生效');return true;
 }
 if(name==='admin-marketing-media-open'){
  context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">营销素材库</h2><p>管理营销页面与博客的公共展示图片。</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></div><div class="b-modal-body" data-marketing-media><p>正在读取素材…</p></div>`);
  const container=document.querySelector('#modal [data-marketing-media]');try{await load(container);}catch(error){container.innerHTML=`<p class="b-form-error">${e(error.message)}</p>${action('重试读取','reload')}`;throw error;}return true;
 }
 if(name==='admin-marketing-media-picker'){
  const container=trigger.closest('form').querySelector('[data-content-media-picker]');container.hidden=false;container.setAttribute('data-marketing-media','');container.innerHTML='<p>正在读取素材…</p>';
  try{await load(container,true);}catch(error){container.innerHTML=`<p class="b-form-error">${e(error.message)}</p>${action('重试读取','reload')}`;throw error;}return true;
 }
 const container=trigger.closest('[data-marketing-media]');if(!container)return false;
 const data=resources.get(container)||{items:[],filters:{q:'',state:'ready',sort:'newest'},picker:container.hasAttribute('data-content-media-picker')};
 if(name==='admin-marketing-media-choose'){
  const item=data.items.find(row=>row.id===trigger.dataset.mediaId&&row.state==='ready');if(!item)throw new Error('素材状态已变化，请刷新。');const form=container.closest('form');form.elements.coverMediaId.value=item.id;form.elements.coverUrl.value=item.publicUrl;container.hidden=true;context.notify('素材已选择，保存并启用对应内容后生效');return true;
 }
 if(name==='admin-marketing-media-select-all'){const boxes=[...container.querySelectorAll('[data-marketing-select]')],checked=boxes.some(box=>!box.checked);boxes.forEach(box=>{box.checked=checked;});return true;}
 trigger.disabled=true;
 try{
  if(name==='admin-marketing-media-references'){
   const result=await api('/admin/content/media/'+encodeURIComponent(trigger.dataset.mediaId)+'/references');container.querySelector('[data-media-result]').innerHTML=result.items.length?`<p>当前引用（${result.items.length} 处）：</p><ul>${result.items.map(item=>`<li><a href="${e(item.href)}">${e(item.title)}</a> · ${e(item.kind==='brand_version'?'保留品牌版本':item.snapshots.map(s=>s==='draft'?'草稿':'已发布').join('、'))}</li>`).join('')}</ul>`:'<p>当前没有引用，可以移入回收站；最终以提交时校验为准。</p>';
  }else if(name==='admin-marketing-media-filter'||name==='admin-marketing-media-reload'){
   const filters=Object.fromEntries(['q','state','sort'].map(key=>[key,container.querySelector(`[data-media-filter=${key}]`)?.value||data.filters[key]]));await load(container,data.picker,filters);
  }else if(name==='admin-marketing-media-more')await load(container,data.picker,data.filters,true);
  else if(name==='admin-marketing-media-upload'){
   const input=container.querySelector('[data-marketing-file]'),file=input.files?.[0];if(!file||!file.size||file.size>12*1048576||!['image/png','image/jpeg','image/webp'].includes(file.type))throw new Error('请选择12 MiB以内的PNG、JPEG或WebP。');
   const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer())),byte=>byte.toString(16).padStart(2,'0')).join('');
   if(input.dataset.hash!==hash||input.dataset.filename!==file.name){input.dataset.hash=hash;input.dataset.filename=file.name;input.dataset.requestKey=crypto.randomUUID();}
   await api('/admin/content/media',{method:'POST',raw:true,body:file,headers:{'Content-Type':file.type,'X-Filename':encodeURIComponent(file.name),'Idempotency-Key':input.dataset.requestKey}});await load(container,data.picker,{q:'',state:'ready',sort:'newest'});context.notify('素材已保存，被已发布内容或当前品牌引用后才公开');
  }else if(name==='admin-marketing-media-state'||name==='admin-marketing-media-bulk'){
   const selected=name.endsWith('-state')?[trigger.dataset.mediaId]:[...container.querySelectorAll('[data-marketing-select]:checked')].map(box=>box.value);
   if(!selected.length)throw new Error('请先选择素材。');if(selected.length>100)throw new Error('一次最多处理100个素材。');
   const items=selected.map(id=>data.items.find(item=>item.id===id)).filter(Boolean).map(({id,revision})=>({id,revision}));
   const result=await api('/admin/content/media/bulk',{method:'POST',body:{action:trigger.dataset.operation,items}});await load(container,data.picker,data.filters);const passed=result.items.filter(item=>item.ok).length;
   container.querySelector('[data-media-result]').innerHTML=`<p>已完成 ${passed} 项；未完成 ${result.items.length-passed} 项。</p>${result.items.filter(item=>!item.ok).map(item=>`<p class="b-notice-text">${e(item.id)}：${e(item.error?.message||'未完成，请刷新核对')}</p>`).join('')}`;
  }else return false;
 }finally{if(trigger.isConnected)trigger.disabled=false;}
 return true;
}
