import { escapeHtml as e } from './icons.js';
export function designThumbnail(projectId,versionId,label='网站设计'){
 if(!projectId||!versionId)return '';
 const path='/preview/'+encodeURIComponent(projectId)+'/'+encodeURIComponent(versionId);
 return `<span class="b-design-thumbnail" aria-hidden="true"><iframe src="${e(path)}" title="${e(label)}预览" sandbox="allow-same-origin" loading="lazy" tabindex="-1" referrerpolicy="no-referrer"></iframe></span>`;
}
