import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const usd = value => Number.isSafeInteger(value) ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 6 }).format(value / 1e6) : '—';
const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '无到期时间';
const sources = { subscription: '会员月度额度', topup: '充值额度', gift: '赠送额度' };
const allowed = item => (item.kind === 'refund' && item.providerState === 'succeeded') || (item.kind === 'dispute' && item.providerState === 'lost');
const action = (title, direction, attrs = '') => `<button type="button" class="ui-button ui-button--secondary" data-action="case-credit-${direction}" ${attrs}>${title}</button>`;

export function renderCaseCredits(data, user) {
  const credits = data.credits;
  if (!credits) return '';
  const owner = user.role === 'owner', canReverse = owner && allowed(data.case);
  return `<section class="b-section"><div class="b-section-heading"><div><h2>原订单来源的 AI 额度</h2><p>原始额度、实际消耗、请求预留与人工冲销分别记录。</p></div></div><div class="b-notice">${icon('shield-check')}<div><strong>仅处理此订单来源的未使用额度</strong><p>只有渠道退款成功或拒付败诉后，平台所有者才能按明确金额冲销。不会按退款比例自动计算，不动其他来源余额，也不会向支付渠道发起退款。</p></div></div>${credits.grants.length ? `<div class="b-table-wrap b-section"><table class="b-table"><thead><tr><th>额度来源</th><th>原始额度</th><th>已消耗 / 已预留</th><th>已冲销</th><th>可冲销</th><th>有效期</th><th>操作</th></tr></thead><tbody>${credits.grants.map(grant => `<tr><td>${e(sources[grant.source] || grant.source)}<small>${e(grant.id)}</small></td><td>${usd(grant.amountMicros)}</td><td>${usd(grant.consumedMicros)} / ${usd(grant.heldMicros)}</td><td>${usd(grant.reversedMicros)}</td><td>${usd(grant.adjustableMicros)}</td><td>${date(grant.startsAtMs)}<small>至 ${date(grant.expiresAtMs)}${grant.membershipFrozen ? ' · 会员计时已暂停' : ''}</small></td><td>${action('冲销未使用额度', 'reverse', `data-grant-id="${e(grant.id)}" ${canReverse && grant.adjustableMicros > 0 ? '' : 'disabled title="需平台所有者、符合渠道状态且有可冲销额度"'}`)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="b-inline-empty">此订单没有可关联的 AI 额度来源。</div>'}${credits.adjustments.length ? `<div class="b-section-heading b-section"><h3>额度冲销与恢复记录</h3></div><div class="b-table-wrap"><table class="b-table"><thead><tr><th>操作与金额</th><th>原因 / 依据</th><th>操作人 / 时间</th><th>操作</th></tr></thead><tbody>${credits.adjustments.map(item => `<tr><td>${item.direction === 'reverse' ? '冲销' : '恢复'} ${usd(item.amountMicros)}<small>${e(item.grantId)}</small></td><td class="b-table-prose">${e(item.reason)}<small>${e(item.evidence)}</small></td><td><code>${e(item.actorId)}</code><small>${date(item.createdAt)}</small></td><td>${item.direction === 'reverse' && item.restorableMicros > 0 ? action('恢复原冲销额度', 'restore', `data-adjustment-id="${e(item.id)}" ${owner ? '' : 'disabled'}`) : '—'}</td></tr>`).join('')}</tbody></table></div>` : ''}</section>`;
}

export async function handleCaseCreditAction(name, trigger, context) {
  if (!['case-credit-reverse', 'case-credit-restore'].includes(name)) return false;
  if (context.state.user.role !== 'owner') throw new Error('只有平台所有者可以冲销或恢复来源额度。');
  const data = context.state.resource, direction = name.endsWith('restore') ? 'restore' : 'reverse';
  const parent = direction === 'restore' ? data.credits.adjustments.find(item => item.id === trigger.dataset.adjustmentId && item.direction === 'reverse') : null;
  const grant = data.credits.grants.find(item => item.id === (parent?.grantId || trigger.dataset.grantId));
  if (!grant || (direction === 'reverse' && !allowed(data.case))) throw new Error('记录状态已变化，请刷新并核对渠道状态。');
  const maximum = direction === 'restore' ? parent?.restorableMicros || 0 : grant.adjustableMicros;
  if (maximum <= 0) throw new Error('此来源当前没有可操作额度。');
  const title = direction === 'restore' ? '恢复原冲销额度' : '冲销未使用额度';
  context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${direction === 'restore' ? '恢复到原额度来源，保留原有效期，不续期，也不改动渠道退款状态。' : '仅减少选定来源尚未消耗、尚未预留的额度；不执行渠道退款。'}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="case-credit" data-direction="${direction}" data-case-id="${e(data.case.id)}" data-revision="${e(data.case.revision)}" data-grant-id="${e(grant.id)}" data-parent-id="${e(parent?.id || '')}" data-maximum-micros="${maximum}" data-request-key="${crypto.randomUUID()}"><p class="b-confirm-title">${e(sources[grant.source] || grant.source)} · 最多 ${usd(maximum)}</p><p class="b-muted">原有效期至 ${date(grant.expiresAtMs)}。${direction === 'restore' && grant.expiresAtMs && grant.expiresAtMs <= Date.now() ? '此额度已到期，恢复后仍不能使用。' : ''}${grant.membershipFrozen ? '原会员仍暂停计时，恢复额度不会自动解冻。' : ''}</p><label class="b-field"><span>${title}金额（美元）</span><input type="number" name="amount" min="0.000001" step="0.000001" required><small class="b-field-hint">明确输入金额，不会根据退款比例自动填充。</small></label><label class="b-field"><span>操作原因</span><textarea name="reason" rows="3" minlength="3" maxlength="500" required></textarea></label><label class="b-field"><span>核对依据</span><textarea name="evidence" rows="3" minlength="10" maxlength="2000" required></textarea></label><label class="b-confirm-checkbox"><input type="checkbox" name="confirmImpact" required><span>已核对来源、金额、原有效期和支付渠道记录，确认本次额度${direction === 'restore' ? '恢复' : '冲销'}。</span></label><p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">确认${title}</button></div></form>`);
  return true;
}

export async function submitCaseCreditForm(form, values, context) {
  if (context.state.user.role !== 'owner' || !values.confirmImpact) throw new Error('需要平台所有者核对并确认操作影响。');
  if (!/^\d+(?:\.\d{1,6})?$/.test(values.amount)) throw new Error('请输入最多 6 位小数的美元金额。');
  const [whole, fraction = ''] = values.amount.split('.');
  const amountMicros = Number(BigInt(whole) * 1000000n + BigInt(fraction.padEnd(6, '0')));
  if (!Number.isSafeInteger(amountMicros) || amountMicros <= 0 || amountMicros > Number(form.dataset.maximumMicros)) throw new Error('金额超过当前来源可操作额度，不能占用已消耗或已预留部分。');
  await api(`/admin/payment-cases/${encodeURIComponent(form.dataset.caseId)}/credits`, { method: 'POST', body: { direction: form.dataset.direction, grantId: form.dataset.grantId, amountMicros, ...(form.dataset.direction === 'restore' ? { parentId: form.dataset.parentId } : {}), reason: values.reason.trim(), evidence: values.evidence.trim(), requestKey: form.dataset.requestKey, expectedRevision: Number(form.dataset.revision), confirmImpact: true } });
  context.closeModal(); await context.reload(); context.notify(form.dataset.direction === 'restore' ? '原冲销额度已恢复到原来源，原有效期保留' : '已冲销指定来源额度，未执行渠道退款');
}
