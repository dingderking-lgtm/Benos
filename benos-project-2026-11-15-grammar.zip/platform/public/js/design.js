import { renderProjectConversation, handleConversationTool, syncPreviewLayout } from './design-conversation.js';
import { renderManifestEditor, mountManifestEditor, stopManifestEditor, rememberManifestInput, changeManifestInput, handleManifestAction, submitManifestForm } from './design-manifest-editor.js';
import { renderPackageUploadForm, mountPackageUpload, stopPackageUploadLoops, handlePackageUploadAction, submitPackageUploadForm } from './package-upload.js';
import { api } from './api.js';
import { restoreDesignVersion } from './design-history.js';
import { nativePreview, handleNativeAction, changeNativeInput, mountNativePreview, stopNativePreviewPolling } from './design-native.js';
import { loadWorkflowResource, mountWorkflow, stopWorkflowPolling, rememberWorkflowInput, handleWorkflowAction, submitWorkflowForm, syncConversationComposer, mergeConversationPages, syncConversationTranscript } from './design-workflow.js';
import { icon, escapeHtml as e } from './icons.js';
import { loadEditorView, loadVisualResource, visualState, mountVisualEditor, stopVisualEditor, rememberVisualInput, changeVisualInput, handleVisualAction, submitVisualForm } from './design-editor.js';

const drafts = new Map();
const pending = new Map();
let pollTimer;
let layoutObserver=null,tabObserver=null,layoutAnimation=0;
const boundPreviewShells=new WeakSet();
let pollEpoch = 0;
const liveStates = new Set(['preparing', 'reserved', 'running', 'uncertain']);
const jobNames = { preparing: '检查需求与用量', reserved: '额度已预留', running: '正在生成网站', succeeded: '设计版本已保存', failed: '生成未完成', uncertain: '结果与费用待核对' };
const errors = { AI_NOT_CONFIGURED: 'AI 设计服务尚未配置。', AI_BILLING_UNVERIFIED: '当前模型的计费规则尚未通过核验，请稍后再试。', INSUFFICIENT_CREDIT: '可用 AI 额度不足，请先补充额度。', INSUFFICIENT_PROVIDER_FUNDS: '平台当前可用 AI 容量不足，请稍后再试。', TOKEN_COUNT_UNAVAILABLE: '本次用量尚无法预估，未发起付费生成。', CONTEXT_LIMIT: '项目内容超过当前模型容量，请缩减需求后重试。', AI_PROVIDER_UNCERTAIN: '生成结果与费用尚未确认。请查询原任务，不要重复提交。', AI_USAGE_INVALID: '本次费用待核对，相关额度仍保留在原请求中。', TEMPLATE_INVALID: '生成内容未通过模板检查，本次已按实际用量结算。', AI_OUTPUT_INCOMPLETE: '模型输出未完成，本次已按实际用量结算。', VERSION_CONFLICT: '项目已有较新版本，请先刷新确认。' };
const money = value => Number.isSafeInteger(value) ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 6 }).format(value / 1e6) : '—';
const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
const keyFor = (user, project) => `benos-ai-request:${user}:${project}`;
const action = (label, name, extra = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="design-${name}" ${extra}>${label}</button>`;

function readPending(user, project) {
  const key = keyFor(user, project);
  if (pending.has(key)) return pending.get(key);
  try { const value = JSON.parse(sessionStorage.getItem(key) || 'null'); if (value?.requestKey && typeof value.prompt === 'string') { pending.set(key, value); return value; } } catch { /* Storage may be disabled. */ }
  return null;
}

function savePending(user, project, value) {
  const key = keyFor(user, project);
  if (value) pending.set(key, value); else pending.delete(key);
  try { if (value) sessionStorage.setItem(key, JSON.stringify(value)); else sessionStorage.removeItem(key); } catch { /* In-memory idempotency remains available. */ }
}

export async function loadDesignResource(projectId, user, options) {
  const id = encodeURIComponent(projectId);
  const results = await Promise.allSettled([api(`/projects/${id}`, options), api(`/ai/projects/${id}/versions`, options), api(`/ai/projects/${id}/jobs`, options), api('/ai/quote', options)]);
  const failed = results.find(result => result.status === 'rejected');
  if (failed) throw failed.reason;
  const [project, versions, jobs, quote] = results.map(result => result.value);
  const query=new URLSearchParams(location.hash.split('?')[1]||''),candidateId=query.get('candidate');
  const candidateView=candidateId?await loadEditorView(projectId,'candidate',candidateId,options):null;
  const proposal=candidateView?{...candidateView.candidate,editorView:candidateView}:null;
  const selectedId=proposal?proposal.baseVersionId:query.get('version')||project.current_version_id;
  const selectedView=selectedId?await loadEditorView(projectId,'version',selectedId,options):null;
  const selected=selectedView?{id:selectedView.sourceId,version:selectedView.version,contentHash:selectedView.contentHash,editorView:selectedView}:null;
  const request = readPending(user.id, projectId);
  if (request?.jobId) { const job=jobs.items.find(item=>item.id===request.jobId);if(job&&!liveStates.has(job.state))savePending(user.id,projectId,null); }
  const [visual,workflow]=await Promise.all([loadVisualResource(project,selected,options,proposal),loadWorkflowResource(project.id,options)]);
  return { project, versions: versions.items || [], jobs: jobs.items || [], selected, quote, visual, workflow, reviewRequested: query.get('review') === '1' };
}

function jobsMarkup(jobs) {
  if (!jobs.length) return '<p class="b-design-no-jobs">设计请求会保留在这里，随时可以查看处理状态。</p>';
  return jobs.slice(0, 8).map(job => `<article class="b-design-job"><div>${icon(job.state === 'succeeded' ? 'circle-check' : job.state === 'uncertain' || job.state === 'failed' ? 'circle-question-mark' : 'clock')}<strong>${e(jobNames[job.state] || job.state)}</strong></div><small>${date(job.createdAt)}</small>${Number.isSafeInteger(job.requiredReservationMicros) ? `<p>此请求最高预留 ${money(job.requiredReservationMicros)}</p>` : ''}${job.errorCode ? `<p>${e(errors[job.errorCode] || '此任务未完成，请查看账户额度或联系平台支持。')}</p><code>${e(job.errorCode)}</code>` : ''}${job.versionId ? `<a href="#design/${encodeURIComponent(job.projectId)}?version=${encodeURIComponent(job.versionId)}">查看保存的版本 ${icon('arrow-right')}</a>` : ''}</article>`).join('');
}

export function renderDesigner(data, user) {
  return renderProjectConversation(data, user);
}

let chatRefreshSequence = 0;
export async function refreshDesignerConversation(context, signal) {
  const { resource, user } = context.state;
  if (!resource?.workflow || !user) return;
  const sequence = ++chatRefreshSequence;
  const mediaAtStart = new Set(resource.visual.assets.map(asset => asset.id));
  const current = () => !signal?.aborted && context.state.resource === resource &&
    context.state.user?.id === user.id && sequence === chatRefreshSequence;
  let updated;
  try {
    updated = await loadDesignResource(resource.project.id, user, { signal });
  } catch (error) {
    if (current()) context.notify(`设计记录已收到，预览暂时无法更新。${error.message}`);
    return;
  }
  const shell = document.querySelector('.d-conversation');
  if (!current() || !shell) return;
  // A user can attach a photo to the next message while this prior receipt is refreshing.
  const refreshedIds = new Set(updated.visual.assets.map(asset => asset.id));
  const newlyUploaded = resource.visual.assets.filter(asset => !mediaAtStart.has(asset.id) && !refreshedIds.has(asset.id));
  updated.visual.assets.unshift(...newlyUploaded);
  const sameVersion = resource.selected?.id === updated.selected?.id;
  if (sameVersion) {
    // The current inspector may have loaded extra pages or a node outside the initial page.
    for (const key of ['nodes', 'nodePages', 'nodeTemplateId']) updated.visual[key] = resource.visual[key];
  }
  mergeConversationPages(resource.workflow, updated.workflow);
  Object.assign(resource, updated);
  const next = document.createElement('template');
  next.innerHTML = renderDesigner(resource, user);
  for (const selector of ['.d-project-heading', '.d-header-actions', '.d-preview-toolbar', '.d-preview-bottom', '[data-visual-panel]']) {
    const before = shell.querySelector(selector), after = next.content.querySelector(selector);
    if (before && after && !before.isEqualNode(after) && !before.contains(document.activeElement)) before.replaceWith(after);
  }
  syncConversationTranscript(context);
  const canvas = shell.querySelector('.b-design-canvas');
  const nextCanvas = next.content.querySelector('.b-design-canvas');
  const frame = canvas?.querySelector('iframe'), nextFrame = nextCanvas?.querySelector('iframe');
  if (canvas && nextCanvas && (frame?.getAttribute('src') !== nextFrame?.getAttribute('src') || frame?.getAttribute('sandbox') !== nextFrame?.getAttribute('sandbox'))) {
    canvas.replaceWith(nextCanvas);
    stopVisualEditor();
    if (!nativePreview(resource, user)) mountVisualEditor(context);
  }
  syncConversationComposer(context);
  syncPreviewLayout(context,shell);
  mountWorkflow(context);
}

export function stopDesignPolling() { layoutObserver?.disconnect(); layoutObserver=null; tabObserver?.disconnect(); tabObserver=null; cancelAnimationFrame(layoutAnimation); layoutAnimation=0; clearTimeout(pollTimer); pollEpoch += 1; stopVisualEditor(); stopWorkflowPolling(); stopPackageUploadLoops(); stopNativePreviewPolling(); stopManifestEditor(); }

export function mountDesigner(context) {
  stopDesignPolling();
  const shell=document.querySelector('.b-design-shell');
  if(shell){
    const sync=()=>syncPreviewLayout(context,shell);
    if(!boundPreviewShells.has(shell)){
      boundPreviewShells.add(shell);
      shell.addEventListener('pointerdown',event=>{
        if(event.pointerType==='mouse' && event.target.closest?.('.d-preview-toggle') &&
            document.activeElement?.matches('[data-form="design-conversation-message"] textarea'))event.preventDefault();
      });
    }
    const reflow=()=>{const compact=String(shell.clientWidth<=650);if(shell.dataset.designCompact!==compact)shell.dataset.designCompact=compact;sync();};
    reflow();
    layoutObserver=new ResizeObserver(()=>{if(!layoutAnimation)layoutAnimation=requestAnimationFrame(()=>{layoutAnimation=0;reflow();});});
    layoutObserver.observe(shell);
    tabObserver=new MutationObserver(sync);
    tabObserver.observe(shell,{attributes:true,attributeFilter:['data-mobile-tab']});
  }
  if (!nativePreview(context.state.resource, context.state.user)) mountVisualEditor(context);
  mountWorkflow(context);
  mountNativePreview(context);
  const legacyNode = document.querySelector('.b-design-jobs'); if (legacyNode) legacyNode.innerHTML = jobsMarkup(context.state.resource.jobs);
  const epoch = pollEpoch;
  const projectId = context.state.resource.project.id;
  const userId = context.state.user.id;
  async function poll() {
    if (epoch !== pollEpoch || context.state.route !== `design/${projectId}` || context.state.user?.id !== userId) return;
    try {
      const { items } = await api(`/ai/projects/${encodeURIComponent(projectId)}/jobs`);
      if (epoch !== pollEpoch) return;
      const old = context.state.resource.jobs || [];
      context.state.resource.jobs = items;
      const node = document.querySelector('.b-design-jobs');
      if (node) node.innerHTML = jobsMarkup(items);
      const completed = items.find(job => !liveStates.has(job.state) && old.some(previous => previous.id === job.id && liveStates.has(previous.state)));
      if (completed) { if (completed.state !== 'uncertain') savePending(userId, projectId, null); await context.refreshConversation(); }
    } catch (error) {
      if (epoch !== pollEpoch) return;
      const node = document.querySelector('.b-design-jobs');
      if (node) node.innerHTML = `<p class="b-form-error">暂时无法刷新任务状态。${e(error.message)}</p>${action('重新查询', 'refresh')}`;
    }
    if (epoch === pollEpoch && (context.state.resource.jobs.some(job => liveStates.has(job.state)) || readPending(userId, projectId))) pollTimer = setTimeout(poll, 5000);
  }
  if (context.state.resource.jobs.some(job => liveStates.has(job.state)) || readPending(userId, projectId)) pollTimer = setTimeout(poll, 4000);
}

export function rememberDesignDraft(input, context) {
  rememberManifestInput(input, context);
  rememberVisualInput(input, context);
  rememberWorkflowInput(input, context);
  if (input.name === 'prompt' && input.closest('[data-form="design-generate"]') && context.state.resource?.project) drafts.set(keyFor(context.state.user.id, context.state.resource.project.id), input.value);
}

export function handleDesignChange(target, context) {
  if(changeManifestInput(target,context))return;
  if (changeNativeInput(target,context)) return;
  rememberWorkflowInput(target, context);
  if (changeVisualInput(target, context)) return;
  const { project, selected } = context.state.resource || {};
  if (target.matches('[data-design-version]') && project) context.navigate(`design/${encodeURIComponent(project.id)}?version=${encodeURIComponent(target.value)}`);
  else if (target.matches('[data-design-page]') && project) { context.closeModal(); const editor=visualState(context.state.resource,context.state.user); editor.previewMode='design'; context.render(); }
}

function templateModal(data, mode, user) {
  const editing=mode==='edit';
  return `<div class="b-modal-header"><div><h2 id="modal-title">${editing?'编辑模板数据':'导入站点包'}</h2><p>通过模板结构、素材与安全检查后保存。</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div>${editing?renderManifestEditor(data,user,{editing:true}):renderPackageUploadForm(data,user)+'<details class="b-template-json"><summary>高级：JSON 导入与分段编辑</summary>'+renderManifestEditor(data,user)+'</details>'}`;
}

export async function handleDesignAction(name, trigger, context) {
  if (await handleConversationTool(name, trigger, context)) return true;
  if (name === 'design-legacy-records') {
    context.showModal(`<header class="b-modal-header"><h2 id="modal-title">早期生成记录</h2><button type="button" class="ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></header><div class="b-modal-body b-design-jobs">${jobsMarkup(context.state.resource.jobs)}</div>`);
    return true;
  }
  if (trigger.closest?.('.conversation-toolbox') && ['design-visual-mode', 'design-visual-undo', 'design-visual-redo', 'design-native-return'].includes(name)) context.closeModal();
  if(await handleManifestAction(name,trigger,context))return true;
  if (await handlePackageUploadAction(name, trigger, context)) return true;
  if (await handleNativeAction(name, trigger, context)) return true;
  if (await handleVisualAction(name, trigger, context)) return true;
  if (await handleWorkflowAction(name, trigger, context)) return true;
  const data = context.state.resource;
  if (name === 'design-refresh') { await context.reload(); return true; }
  if (name === 'design-device') {
    const device = trigger.dataset.device === 'mobile' ? 'mobile' : 'desktop';
    visualState(data, context.state.user).device = device;
    const shell = document.querySelector('.d-conversation');
    shell.dataset.device = device;
    shell.querySelector('.b-design-canvas').dataset.device = device;
    shell.querySelector('[data-conversation-device-label]').textContent = device === 'mobile' ? '手机视图' : '桌面视图';
    document.querySelectorAll('[data-action="design-device"]').forEach(button => button.setAttribute('aria-pressed', String(button === trigger)));
    return true;
  }
  if (name === 'design-import' || name === 'design-edit') { context.showModal(templateModal(data, name === 'design-edit' ? 'edit' : 'import', context.state.user)); if (name === 'design-import') mountPackageUpload(context); mountManifestEditor(context); return true; }
  if (name === 'design-export') {
    const response = await fetch(`/api/design/projects/${encodeURIComponent(data.project.id)}/versions/${encodeURIComponent(data.selected.id)}/package`, { credentials: 'same-origin', cache: 'no-store' });
    if (!response.ok) { let payload; try { payload = await response.json(); } catch {} throw new Error(payload?.error?.message || '站点包导出失败，请重试。'); }
    const url = URL.createObjectURL(await response.blob());
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `benos-${data.project.id}-v${data.selected.version}.zip`; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); return true;
  }
  if (name === 'design-restore') {
    context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">恢复历史设计</h2><p>复制此版本为一个新的当前版本，所有历史记录仍然保留。</p></div></div><form class="b-modal-body" data-form="design-restore"><p class="b-confirm-title">版本 ${e(data.selected.version)}</p><p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">恢复为新版本</button></div></form>`); return true;
  }
  return false;
}

export async function submitDesignForm(name, form, values, context) {
  if(await submitManifestForm(name,form,values,context))return true;
  if (await submitPackageUploadForm(name, form, values, context)) return true;
  if (await submitVisualForm(name, form, values, context)) return true;
  if (await submitWorkflowForm(name, form, values, context)) return true;
  const { project, selected } = context.state.resource;
  const userId = context.state.user.id;
  if (name === 'design-generate') {
    let request = readPending(userId, project.id);
    if (!request && (!context.state.resource.quote?.available || !context.state.resource.quote.canReserve)) throw new Error('当前服务或可用额度无法支持本次请求，请刷新状态后重试。');
    if (!request) request = { prompt: values.prompt.trim(), requestKey: crypto.randomUUID(), baseVersionId: project.current_version_id || null };
    savePending(userId, project.id, request);
    form.querySelector('textarea').readOnly = true;
    form.querySelector('button[type="submit"]').textContent = '正在处理原请求…';
    mountDesigner(context);
    try {
      const { jobId, ...body } = request;
      const result = await api(`/ai/projects/${encodeURIComponent(project.id)}/generate`, { method: 'POST', body });
      if (liveStates.has(result.state)) savePending(userId, project.id, { ...request, jobId: result.id }); else savePending(userId, project.id, null);
      if (context.state.user?.id === userId && context.state.route === `design/${project.id}`) await context.reload();
      context.notify(result.state === 'succeeded' ? '设计版本已保存' : result.state === 'uncertain' ? '结果与费用待核对，请查询原任务' : result.state === 'failed' ? errors[result.errorCode] || '本次设计未完成，请查看任务状态' : '任务已受理，请查看处理状态');
    } catch (error) {
      if (error.status >= 400 && error.status < 500 && error.status !== 408 || ['AI_NOT_CONFIGURED', 'AI_BILLING_UNVERIFIED'].includes(error.code)) {
        savePending(userId, project.id, null);
        if (form.isConnected) form.querySelector('textarea').readOnly = false;
      }
      form.dataset.pendingRequest = String(!!readPending(userId, project.id));
      throw error;
    }
    return true;
  }
  if (name === 'design-restore') {
    const result=await restoreDesignVersion(userId,project.id,project.current_version_id,'restore',selected.id);context.closeModal();context.navigate(`design/${encodeURIComponent(project.id)}${result.currentVersionId?`?version=${encodeURIComponent(result.currentVersionId)}`:''}`);context.notify(result.superseded?'原恢复已完成，当前已有更新版本，未回退当前设计':'历史设计已恢复为新版本');return true;
  }

  return false;
}
