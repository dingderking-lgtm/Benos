import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const labels = { preparing: '正在准备', prepared: '等待确认发布影响', committing: '发布处理中', published: '已发布', rolling_back: '正在回滚', rolled_back: '已回滚', failed: '未完成', uncertain: '发布结果待核对' };
const openStates = new Set(['preparing', 'prepared', 'committing', 'rolling_back', 'uncertain']);
const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
const action = (text, name, attrs = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="publishing-${name}" ${attrs}>${text}</button>`;
const footer = text => `<p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">${text}</button></div>`;
const modal = (title, description, form, body, attrs = '') => `<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${description}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="publishing-${form}" ${attrs}>${body}</form>`;

export async function loadPublishingData(detail, options) {
  const site = detail.site;
  const tasks = [api(`/publishing/sites/${encodeURIComponent(site.id)}/releases`, options), site.projectId ? api(`/ai/projects/${encodeURIComponent(site.projectId)}/versions`, options) : api('/projects', options)];
  const results = await Promise.allSettled(tasks);
  const failed = results.find(result => result.status === 'rejected');
  if (failed) throw failed.reason;
  return { releases: results[0].value.items || [], versions: site.projectId ? results[1].value.items || [] : [], projects: site.projectId ? [] : results[1].value.items || [], nextCursor: site.projectId ? null : results[1].value.nextCursor || null };
}

function summaryMarkup(summary) {
  return `<div class="b-release-summary"><div><strong>${e(summary.createPages)}</strong><span>新增页面</span></div><div><strong>${e(summary.updatePages)}</strong><span>更新页面</span></div><div><strong>${e(summary.preserveArticles)}</strong><span>保留文章</span></div></div><ul class="b-release-effects"><li>${icon('check')}${summary.preserveDrafts ? '保留已有草稿' : '草稿处理待确认'}</li><li>${icon('check')}删除页面：${e(summary.removePages)}</li><li>${icon('palette')}${summary.replaceGlobalTheme ? '将替换网站全局样式' : '保留网站全局样式'}</li></ul>`;
}

function transferMarkup(release) {
  if (release.state !== 'preparing') return '';
  const transfer = release.result?.transfer;
  const total = Number.isSafeInteger(transfer?.totalBytes) && transfer.totalBytes > 0 ? transfer.totalBytes : null;
  const sent = Number.isSafeInteger(transfer?.bytesSent) && transfer.bytesSent >= 0 && total !== null && transfer.bytesSent <= total ? transfer.bytesSent : null;
  const bytes = value => new Intl.NumberFormat('zh-CN').format(value);
  return `<div class="b-notice"><div><strong>${sent === null ? '正在准备发布影响清单' : '正在传输网站资源'}</strong>${sent !== null ? `<p>CMS 已确认 ${bytes(sent)} / ${bytes(total)} 字节</p><progress aria-label="CMS 已确认接收的资源" value="${sent}" max="${total}" style="width:100%">${bytes(sent)} / ${bytes(total)}</progress>` : ''}<p>后台会继续准备；准备完成后，仍需核对影响清单并确认发布。可点击“继续准备 / 更新进度”核对原任务。</p></div></div>`;
}

export function renderPublishingPanel(detail) {
  const { site, publishing } = detail;
  if (!publishing) return '';
  const ready = site.state === 'connected' && detail.canPublish;
  const open = publishing.releases.some(release => openStates.has(release.state));
  const hasVersions = publishing.versions.length > 0;
  return `<section class="b-section"><div class="b-section-heading"><div><h2>发布网站设计</h2><p>先核对本次变更，再将设计版本发布到已连接的网站。</p></div>${site.projectId ? action('准备发布', 'prepare', ready && !open && hasVersions ? '' : 'disabled', true) : action('关联设计项目', 'bind', '', true)}</div>${site.projectId ? `<div class="b-publication-project"><span>${icon('folder')}已关联设计项目</span><a class="text-button" href="#design/${encodeURIComponent(site.projectId)}">打开设计台 ${icon('arrow-right')}</a></div>` : '<div class="b-notice"><div><strong>先关联一个设计项目</strong><p>关联后，可以将该项目中保存的版本发布到此网站。已有发布记录的站点不能随意改绑项目。</p></div></div>'}${!ready ? `<p class="b-notice-text">${site.state !== 'connected' ? '完成 CMS、域名与 HTTPS 验证后，才能发布网站设计。' : !detail.canManageHosting ? '托管权益已到期，请续费后继续发布。' : '网站发布权限暂时受限，请联系平台支持。'}</p>` : !hasVersions ? '<p class="b-notice-text">关联项目还没有已保存的设计版本，请先完成网站设计。</p>' : ''}<div class="b-release-list">${publishing.releases.length ? publishing.releases.map(release => `<article class="b-card"><div class="b-section-heading"><div><h3>发布记录</h3><p>${date(release.createdAt)}</p></div><span class="b-badge" data-status="${e(release.state)}">${release.errorCode === 'PUBLICATION_DISCARDED' && release.state === 'failed' ? '已取消准备' : e(labels[release.state] || release.state)}</span></div>${transferMarkup(release)}${release.state === 'prepared' && release.result?.summary ? summaryMarkup(release.result.summary) : ''}${release.state === 'uncertain' ? '<p class="b-notice-text">发布结果尚未确认。请核对这条原始记录，避免重复发布。</p>' : ''}${release.errorCode ? `<p class="b-muted">状态代码：${e(release.errorCode)}</p>` : ''}${release.result?.backup ? '<p class="b-muted">已保存发布前备份，可用于回滚。</p>' : ''}<div class="b-table-actions">${release.state === 'prepared' && release.reviewHash ? action('核对影响并发布', 'review', `data-release-id="${e(release.id)}" ${ready ? '' : 'disabled'}`, true) : ''}${['preparing', 'prepared', 'uncertain'].includes(release.state) ? action('取消准备', 'discard', `data-release-id="${e(release.id)}"`) : ''}${release.state === 'published' ? action('回滚到发布前', 'rollback', `data-release-id="${e(release.id)}" ${ready ? '' : 'disabled'}`) : ''}${openStates.has(release.state) || release.state === 'failed' ? action(release.state === 'preparing' ? '继续准备 / 更新进度' : '核对原发布状态', 'reconcile', `data-release-id="${e(release.id)}"`) : ''}</div></article>`).join('') : '<div class="b-inline-empty">还没有发布记录。准备操作不会立即替换公开网站。</div>'}</div></section>`;
}

export async function handlePublishingAction(name, trigger, context) {
  const detail = context.state.resource;
  const { site, publishing } = detail;
  const release = publishing.releases.find(item => item.id === trigger.dataset.releaseId);
  if (name === 'publishing-more-projects') {
    if (!publishing.nextCursor) return true;
    trigger.disabled = true;
    try {
      const more = await api(`/projects?cursor=${encodeURIComponent(publishing.nextCursor)}`);
      if (!trigger.isConnected || context.state.resource !== detail) return true;
      const existing = new Set(publishing.projects.map(project => project.id));
      const added = (more.items || []).filter(project => !existing.has(project.id));
      publishing.projects.push(...added); publishing.nextCursor = more.nextCursor || null;
      trigger.closest('form').querySelector('select[name=projectId]').insertAdjacentHTML('beforeend', added.map(project => `<option value="${e(project.id)}">${e(project.name)}</option>`).join(''));
      if (!publishing.nextCursor) trigger.remove();
    } finally { if (trigger.isConnected) trigger.disabled = false; }
  } else if (name === 'publishing-bind') {
    if (!publishing.projects.length) throw new Error('请先创建一个网站设计项目，再关联到此网站。');
    context.showModal(modal('关联设计项目', '此网站将接收所选项目的设计版本。首次绑定后不可随意改绑。', 'bind', `<label class="b-field"><span>设计项目</span><select name="projectId" required>${publishing.projects.map(project => `<option value="${e(project.id)}">${e(project.name)}</option>`).join('')}</select></label>${publishing.nextCursor ? action('加载更多项目', 'more-projects') : ''}${footer('确认关联项目')}`, `data-site-id="${e(site.id)}"`));
  } else if (name === 'publishing-prepare') {
    context.showModal(modal('准备发布', '先读取 CMS 当前内容并生成发布影响清单，不会直接覆盖公开页面。', 'prepare', `<label class="b-field"><span>选择设计版本</span><select name="versionId" required>${publishing.versions.map(version => `<option value="${e(version.id)}">版本 ${e(version.version)} · ${version.source === 'ai' ? 'AI 设计' : '手动保存'} · ${date(version.created_at)}</option>`).join('')}</select></label>${footer('准备发布影响清单')}`, `data-site-id="${e(site.id)}" data-request-key="${crypto.randomUUID()}"`));
  } else if (name === 'publishing-review') {
    if (!release || release.state !== 'prepared' || !release.result?.summary || !release.reviewHash) throw new Error('发布记录已变化，请先刷新并核对。');
    context.showModal(modal('确认本次发布影响', '以下清单由目标 CMS 根据当前站点内容生成。', 'commit', `${summaryMarkup(release.result.summary)}<label class="b-confirm-checkbox"><input type="checkbox" required><span>我已核对以上变更，确认将此版本发布到 ${e(site.domain)}。</span></label>${footer('确认发布到网站')}`, `data-release-id="${e(release.id)}" data-review-hash="${e(release.reviewHash)}"`));
  } else if (name === 'publishing-discard') {
    if (!release || !['preparing', 'prepared', 'uncertain'].includes(release.state)) throw new Error('请先核对原发布状态。');
    context.showModal(modal('取消发布准备', '服务器会先核对 CMS 的真实状态。传输中的资源以及尚未开始处理的准备记录，只有确认可安全停止时才会取消。', 'discard', `<p class="b-confirm-title">${e(site.domain)} · ${date(release.createdAt)}</p><p class="b-muted">已开始导入、已发布或已回滚的记录不会被丢弃。结果仍未知时，请继续查询这条原记录。</p><label class="b-confirm-checkbox"><input type="checkbox" required><span>确认请求取消尚未开始导入的准备记录。</span></label>${footer('请求取消准备')}`, `data-release-id="${e(release.id)}"`));
  } else if (name === 'publishing-rollback') {
    if (!release || release.state !== 'published') throw new Error('请先核对原发布状态。');
    context.showModal(modal('回滚到发布前', '使用本次发布前的备份恢复站点，服务器会校验备份与站点状态。', 'rollback', `<p class="b-confirm-title">${e(site.domain)} · ${date(release.createdAt)}</p><label class="b-confirm-checkbox"><input type="checkbox" required><span>确认恢复此发布前的站点备份。</span></label>${footer('确认回滚')}`, `data-release-id="${e(release.id)}"`));
  } else if (name === 'publishing-reconcile') {
    if (!release) throw new Error('发布记录已变化，请刷新后重试。');
    trigger.disabled = true;
    try { const result = await api(`/publishing/releases/${encodeURIComponent(release.id)}/reconcile`, { method: 'POST', body: {} }); await context.reload(); context.notify(statusMessage(result.release)); }
    finally { if (trigger.isConnected) trigger.disabled = false; }
  } else return false;
  return true;
}

function statusMessage(release) {
  if (release.state === 'failed' && release.errorCode === 'PUBLICATION_DISCARDED') return 'CMS 已确认取消准备，可以重新准备发布';
  if (release.state === 'published') return 'CMS 已确认发布成功';
  if (release.state === 'rolled_back') return 'CMS 已确认回滚完成';
  if (release.state === 'prepared') return '发布影响清单已准备，请核对后确认';
  if (release.state === 'uncertain') return '发布结果待核对，请继续查询原记录';
  if (release.state === 'preparing') return '仍在准备，请更新原任务进度；完成后需确认发布影响';
  return '发布状态已更新，请查看原记录';
}

export async function submitPublishingForm(name, form, values, context) {
  let result;
  if (name === 'publishing-bind') {
    await api(`/hosting/sites/${encodeURIComponent(form.dataset.siteId)}`, { method: 'PATCH', body: { projectId: values.projectId } });
    context.closeModal(); await context.reload(); context.notify('设计项目已关联'); return true;
  }
  if (name === 'publishing-prepare') result = await api(`/publishing/sites/${encodeURIComponent(form.dataset.siteId)}/prepare`, { method: 'POST', headers: { 'Idempotency-Key': form.dataset.requestKey }, body: { versionId: values.versionId } });
  else if (name === 'publishing-commit') result = await api(`/publishing/releases/${encodeURIComponent(form.dataset.releaseId)}/commit`, { method: 'POST', body: { reviewHash: form.dataset.reviewHash } });
  else if (name === 'publishing-discard') result = await api(`/publishing/releases/${encodeURIComponent(form.dataset.releaseId)}/discard`, { method: 'POST', body: {} });
  else if (name === 'publishing-rollback') result = await api(`/publishing/releases/${encodeURIComponent(form.dataset.releaseId)}/rollback`, { method: 'POST', body: {} });
  else return false;
  context.closeModal(); await context.reload(); context.notify(statusMessage(result.release)); return true;
}
