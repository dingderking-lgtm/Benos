import { api } from './api.js';
import { escapeHtml as e } from './icons.js';
const usd=value=>'$'+(Number(value||0)/1e6).toFixed(6).replace(/0+$/,'').replace(/\.$/,'');
const stateNames={created:'已建立',reserved:'已预占',running:'正在测试',passed:'能力与计费通过',failed:'测试未通过',uncertain:'费用待核对'};
const accountingNames={none:'未预占',held:'保留预占',settled:'已结算',released:'已释放'};
const error='<p class="b-form-error" data-form-error role="alert" hidden></p>';
const footer=label=>`${error}<div class="b-form-actions"><button type="button" class="ui-button" data-action="close-modal">关闭</button><button type="submit" class="ui-button ui-button--primary">${label}</button></div>`;
function money(value){if(!/^\d+(?:\.\d{1,6})?$/.test(value))throw Error('美元金额最多支持 6 位小数');const [a,b='']=value.split('.'),n=Number(BigInt(a)*1000000n+BigInt(b.padEnd(6,'0')));if(!Number.isSafeInteger(n))throw Error('金额超出范围');return n;}
export async function openFunctionalTests(configId,context){
 const config=context.state.resource.items.find(item=>item.id===configId);if(!config)throw Error('请刷新配置列表');
 const [quote,history,budgets]=await Promise.all([api(`/admin/integrations/${encodeURIComponent(configId)}/functional-test-quote`),api(`/admin/integrations/${encodeURIComponent(configId)}/functional-tests`),api('/admin/integrations/operations-budgets')]);
 const owner=context.state.user.role==='owner',provider=config.publicConfig.providerPoolId,budget=budgets.items.find(b=>b.providerId===provider);
 const quoteView=quote.available?`<dl class="b-config-facts"><div><dt>本次最多预占</dt><dd>${usd(quote.requiredReservationMicros)}</dd></div><div><dt>运营预算可用</dt><dd>${usd(quote.operationsAvailableMicros)}</dd></div><div><dt>供应商资金可用</dt><dd>${usd(quote.providerAvailableMicros)}</dd></div></dl><p>固定短文本测试，最多输出 ${quote.maxOutputTokens} tokens。成功后按真实用量结算，释放剩余预占；不扣用户余额。</p>${!quote.canReserve?'<p class="b-notice-text">可用运营预算或供应商资金不足，请先核对预算和真实入资。</p>':''}<form class="b-modal-body" data-form="functional-run" data-config-id="${e(configId)}" data-quote-hash="${e(quote.quoteHash)}" data-max-cost="${quote.requiredReservationMicros}" data-request-key="${crypto.randomUUID()}"><label class="b-field"><span><input type="checkbox" name="confirmedCharge" required> 我确认发送真实收费测试，最高预占 ${usd(quote.requiredReservationMicros)}</span></label>${error}<button type="submit" class="ui-button ui-button--primary" ${!owner||!quote.canReserve?'disabled':''}>确认执行小额测试</button></form>`:`<div class="b-notice"><div><strong>暂不能执行收费测试</strong><p>${config.kind==='image'?'图片 API 的单次最高费用合同尚未验证，生产测试和启用均保持关闭。':'请先通过连接验证，并使用已审核的模型、价格和协议配置。'}</p><small>${e(quote.reason||'')}</small></div></div>`;
 context.showModal(`<div class="b-modal-header"><div><h2>${e(config.name)} · 能力与计费验证</h2><p>只读连接测试不等于收费能力通过；费用未知时先核对原测试。</p></div><button type="button" class="ui-button" data-action="close-modal" aria-label="关闭">×</button></div><div class="b-modal-body">${quoteView}<details class="b-section"><summary>运营测试预算</summary><p>此上限只分配运营测试额度，不代表向供应商充值。已有消耗和预占不会因修改上限被清零。</p><form data-form="functional-budget" data-config-id="${e(configId)}" data-provider="${e(provider)}"><label class="b-field"><span>累计运营预算上限（美元）</span><input name="limit" inputmode="decimal" value="${Number(budget?.limitMicros||0)/1e6}" required></label><p>已消耗 ${usd(budget?.consumedMicros)}，已预占 ${usd(budget?.reservedMicros)}</p><label class="b-field"><span>修改原因</span><textarea name="reason" minlength="3" maxlength="500" required></textarea></label>${error}<button type="submit" class="ui-button ui-button--secondary" ${!owner?'disabled':''}>保存预算上限</button></form></details><section class="b-section"><h3>本版本测试记录</h3>${history.items.length?`<div class="b-table-wrap"><table class="b-table"><thead><tr><th>状态</th><th>费用</th><th>操作</th></tr></thead><tbody>${history.items.map(item=>`<tr><td>${e(stateNames[item.state]||item.state)}<small>${e(accountingNames[item.accountingState]||item.accountingState)}</small></td><td>预占 ${usd(item.reservedMicros)}<small>实际 ${item.actualMicros==null?'待核对':usd(item.actualMicros)}</small></td><td>${owner&&item.accountingState==='held'?`<button type="button" class="ui-button ui-button--secondary" data-action="functional-reconcile" data-config-id="${e(configId)}" data-test-id="${e(item.id)}">人工费用核对</button>`:'—'}</td></tr>`).join('')}</tbody></table></div>`:'<p>尚未执行功能测试。</p>'}<button type="button" class="ui-button ui-button--secondary" data-action="functional-open" data-config-id="${e(configId)}">刷新测试记录</button></section></div>`);
}
export async function handleFunctionalAction(action,trigger,context){
 if(action==='functional-open'){await openFunctionalTests(trigger.dataset.configId,context);return true;}
 if(action==='functional-reconcile'){
  context.showModal(`<div class="b-modal-header"><div><h2>核对运营测试费用</h2><p>先查供应商原始记录；核对费用不会把失败测试改为能力通过。运行中的测试至少等待 3 分钟。</p></div></div><form class="b-modal-body" data-form="functional-reconcile" data-config-id="${e(trigger.dataset.configId)}" data-test-id="${e(trigger.dataset.testId)}"><label class="b-field"><span>确认结果</span><select name="outcome"><option value="confirmed_cost">已核实实际费用</option><option value="confirmed_unused">已核实未产生费用</option></select></label><label class="b-field"><span>实际费用（美元，未消费填 0）</span><input name="actual" inputmode="decimal" required></label><label class="b-field"><span>核对依据（至少 10 个字符）</span><textarea name="evidence" minlength="10" maxlength="2000" required></textarea></label>${footer('确认费用核对')}</form>`);return true;
 }return false;
}
export async function submitFunctionalForm(action,form,values,context){
 const configId=form.dataset.configId;
 if(action==='functional-budget'){
  await api(`/admin/integrations/operations-budgets/${encodeURIComponent(form.dataset.provider)}`,{method:'PUT',body:{limitMicros:money(values.limit.trim()),reason:values.reason.trim()}});context.notify('运营预算上限已保存');
 }else if(action==='functional-run'){
  if(!form.elements.confirmedCharge.checked)throw Error('请确认本次收费测试');
  const result=await api(`/admin/integrations/${encodeURIComponent(configId)}/functional-tests`,{method:'POST',body:{requestKey:form.dataset.requestKey,quoteHash:form.dataset.quoteHash,maxCostMicros:Number(form.dataset.maxCost),confirmedCharge:true}});
  context.notify(result.state==='passed'?'能力和计费测试通过，请再启用配置':result.accountingState==='held'?'测试费用尚未确认，预占保持，请核对原记录':'测试未通过，请查看测试记录');
 }else{
  const actual=money(values.actual.trim());if(values.outcome==='confirmed_unused'&&actual!==0)throw Error('未消费确认的实际费用应为 0');
  await api(`/admin/integrations/${encodeURIComponent(configId)}/functional-tests/${encodeURIComponent(form.dataset.testId)}/reconcile`,{method:'POST',body:{outcome:values.outcome,...(values.outcome==='confirmed_cost'?{actualMicros:actual}:{}),evidence:values.evidence.trim()}});context.notify('费用已核对；能力仍需重新测试通过');
 }
 await context.reload();await openFunctionalTests(configId,context);
}
