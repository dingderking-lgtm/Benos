import { designThumbnail } from './thumbnails.js';
import { api } from './api.js';
import { renderPublishingPanel } from './publishing.js';
import { renderHostingManagement,handleHostingManagementAction,submitHostingManagementForm } from './hosting-management.js';
import { icon, escapeHtml as e } from './icons.js';

const statuses = { requested: '已申请', pending: '等待处理', queued: '排队中', provisioning: '配置中', running: '配置中', awaiting_input: '等待处理', needs_attention: '需要处理', connected: '已连接', active: '正常运行', completed: '已完成', ready: '已就绪', succeeded: '已完成', failed: '配置失败', suspended: '已暂停', expired: '已到期' };
const steps = { requested: '已收到申请', validating: '检查网站信息', checking: '检查网站信息', database: '配置数据库', database_created: '数据库已配置', installing: '安装 CMS', cms_installed: 'CMS 已安装', domain: '验证域名', domain_verified: '域名已验证', ssl: '验证 HTTPS', verifying: '验证网站连接', ready: '完成连接', connected: '完成连接', completed: '完成连接' };
const errors = { HOSTING_NOT_CONFIGURED: '网站连接服务尚未就绪，请稍后重试。', HOSTING_UNAVAILABLE: '网站连接服务暂时不可用，请稍后重试。', CREDENTIALS_EXPIRED: '管理密码已过期，请重新输入后继续。', HOSTING_ENTITLEMENT_REQUIRED: '当前账户没有可用的网站托管名额，请先选择会员套餐。' };
const badge = value => `<span class="b-badge" data-status="${e(value || '')}">${e(statuses[value] || value || '—')}</span>`;
const date = value => value && !Number.isNaN(new Date(value).valueOf()) ? new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
const action = (label, name, extra = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="hosting-${name}" ${extra}>${label}</button>`;
const field = (label, name, { type = 'text', value = '', max = 160, hint = '', min } = {}) => `<label class="b-field"><span>${label}</span><input name="${name}" type="${type}" value="${e(value)}" maxlength="${max}" ${min ? `minlength="${min}"` : ''} required autocomplete="${type === 'password' ? 'new-password' : 'off'}">${hint ? `<small class="b-field-hint">${hint}</small>` : ''}</label>`;
const footer = label => `<p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">${label}</button></div>`;
const modal = (title, description, form, body, attrs = '') => `<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${description}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="hosting-${form}" ${attrs}>${body}</form>`;

export function renderHostingList(data) {
  const items = data.items || [];
  const entitlement = data.entitlement || {};
  const projectId = new URLSearchParams(location.hash.split('?')[1] || '').get('project') || '';
  return `<section class="s-page"><div class="page-intro"><div><h1>网站托管</h1><p>连接你的网站，将内容管理留在一个熟悉的工作空间。</p></div>${action(icon('plus') + '连接 CMS', 'new', `data-project-id="${e(projectId)}" ${entitlement.canCreate ? '' : 'disabled title="需要可用的会员托管名额"'}`, true)}</div><div class="b-hosting-entitlement b-card"><div><span class="b-eyebrow">会员包含托管名额</span><strong>${typeof entitlement.includedSites === 'number' ? entitlement.includedSites : '—'}</strong></div><div><span class="b-eyebrow">会员到期</span><strong>${date(entitlement.subscriptionEndsAt)}</strong></div><a class="ui-button ui-button--secondary" href="#billing">管理套餐</a></div>${!entitlement.canCreate ? `<div class="b-notice b-section">${icon('circle-question-mark')}<div><strong>当前没有可用的新建名额</strong><p>需要有效会员与可用名额才能连接新网站。已有网站可通过独立年付托管继续运行。</p></div></div>` : ''}${!data.bridgeReady ? `<div class="b-notice b-section">${icon('clock')}<div><strong>网站连接服务尚未就绪</strong><p>你可以先提交网站信息，平台会保存待处理任务。服务就绪后可继续配置。</p></div></div>` : ''}<section class="b-section">${items.length ? `<div class="b-project-grid">${items.map(site => `<article class="b-card b-hosted-site">${site.previewVersionId?`<a class="b-project-visual" href="#hosting/${encodeURIComponent(site.id)}" aria-label="${e(site.name)}">${designThumbnail(site.projectId,site.previewVersionId,site.name)}</a>`:''}<div class="b-section-heading"><h2>${e(site.name)}</h2>${badge(site.state)}</div><p>${e(site.domain)}</p><div class="b-project-meta"><span>更新于 ${date(site.updatedAt)}</span><a class="text-button" href="#hosting/${encodeURIComponent(site.id)}">查看连接 ${icon('arrow-right')}</a></div></article>`).join('')}</div>` : `<div class="b-empty">${icon('globe')}<h2>连接你的第一个 CMS</h2><p>填写网站名称、绑定域名与管理账户，平台自动完成网站配置。</p>${entitlement.canCreate ? action('连接 CMS', 'new', `data-project-id="${e(projectId)}"`, true) : '<a class="ui-button ui-button--primary" href="#billing">查看会员套餐</a>'}</div>`}</section></section>`;
}

export function renderHostingDetail(data) {
  const { site, job } = data;
  const retention = data.retention;
  const retentionNotice = retention ? `<section class="b-notice b-section">${icon('shield-check')}<div><strong>暂停后至少保留 ${e(retention.minimumDays)} 天</strong><p>暂停时间：${date(retention.suspendedAt)}<br>最低保留至：${date(retention.retainAtLeastUntil)}</p><p>${retention.reviewDue ? '最低保留期已满，平台可人工复核继续保留。' : '当前仍处于最低保留期内。'}网站不会自动删除。续费后请刷新网站状态，确认恢复结果。</p><a class="ui-button ui-button--secondary" href="#billing">查看托管续费</a></div></section>` : '';
  const completed = job?.result?.cmsInstalled && job?.result?.domainVerified && job?.result?.httpsVerified;
  const retryable = job && ['awaiting_input', 'failed', 'needs_attention'].includes(job.state);
  const progress = [['CMS 安装', job?.result?.cmsInstalled], ['域名验证', job?.result?.domainVerified], ['HTTPS 验证', job?.result?.httpsVerified]];
  return `<section class="s-page"><a class="b-back" href="#hosting">${icon('arrow-left')}返回网站托管</a><div class="page-intro"><div><h1>${e(site.name)}</h1><p>${e(site.domain)}</p></div>${badge(site.state)}</div><div class="b-project-detail-grid"><section class="b-card"><div class="b-card-heading"><h2>网站连接状态</h2><p>${completed ? '网站已通过安装、域名与 HTTPS 验证。' : '完成全部验证后，网站才会显示为已连接。'}</p></div><ol class="b-hosting-progress">${progress.map(([title, done]) => `<li>${icon(done ? 'circle-check' : 'clock')}<div><strong>${title}</strong><span>${done ? '已验证' : '等待验证'}</span></div></li>`).join('')}</ol>${job ? `<p class="b-hosting-step">当前步骤：${e(steps[job.step] || '等待服务处理')}</p>${job.errorCode ? `<div class="b-notice"><div><strong>${e(errors[job.errorCode] || '连接需要进一步处理，请重试或联系平台支持。')}</strong><p>状态代码：${e(job.errorCode)}</p></div></div>` : ''}` : '<p class="b-muted">尚无配置任务记录。</p>'}<div class="b-form-actions b-section">${action(icon('rotate-ccw') + '刷新状态', 'refresh')}${retryable ? action('继续配置', 'retry', `data-job-id="${e(job.id)}"`, true) : ''}</div></section><aside class="b-card b-project-facts"><h2>网站信息</h2><dl><div><dt>绑定域名</dt><dd>${e(site.domain)}</dd></div><div><dt>管理账户</dt><dd>${e(site.cmsAdminEmail)}</dd></div><div><dt>创建时间</dt><dd>${date(site.createdAt)}</dd></div><div><dt>托管权益</dt><dd>${data.canManageHosting ? '可以管理' : '需要续费'}</dd></div></dl><a class="ui-button ui-button--secondary" href="#billing">管理托管续费</a></aside></div>${retentionNotice}${renderHostingManagement(data)}${renderPublishingPanel(data)}</section>`;
}

export async function handleHostingAction(name, trigger, context) {
  if(await handleHostingManagementAction(name,trigger,context))return true;
  if (name === 'hosting-refresh') { await context.reload(); return true; }
  if (name === 'hosting-new') {
    const key = crypto.randomUUID();
    context.showModal(modal('连接 CMS', '填写四项信息，平台自动完成后续配置。', 'create', `${field('网站名称', 'name', { max: 120 })}${field('绑定域名', 'domain', { max: 253, hint: '填写你拥有的域名，例如 example.com，不需要 https://。' })}${field('后台登录账户', 'cmsAdminEmail', { type: 'email', max: 190, hint: '使用邮箱地址作为 CMS 管理账户。' })}${field('后台登录密码', 'cmsAdminPassword', { type: 'password', min: 12, max: 256, hint: '至少 12 个字符。密码加密保存用于配置，不会在页面中回显。' })}${footer('提交并开始配置')}`, `data-request-key="${key}" data-project-id="${e(trigger.dataset.projectId || '')}"`));
    return true;
  }
  if (name === 'hosting-retry') {
    const job = context.state.resource.job;
    const needsPassword = job.requiresPassword || (job.secretExpiresAt && new Date(job.secretExpiresAt) <= new Date());
    context.showModal(modal('继续网站配置', needsPassword ? '原管理密码已过期，请重新输入后继续。' : '平台会继续处理当前连接任务。', 'retry', `${needsPassword ? field('后台登录密码', 'cmsAdminPassword', { type: 'password', min: 12, max: 256 }) : '<p class="b-confirm-title">已完成的步骤不会重复创建。</p>'}${footer('继续配置')}`, `data-job-id="${e(job.id)}"`));
    return true;
  }
  return false;
}

export async function submitHostingForm(name, form, values, context) {
  if(await submitHostingManagementForm(name,form,values,context))return true;
  let result;
  if (name === 'hosting-create') {
    result = await api('/hosting/sites', { method: 'POST', headers: { 'Idempotency-Key': form.dataset.requestKey }, body: { name: values.name.trim(), domain: values.domain.trim(), cmsAdminEmail: values.cmsAdminEmail.trim(), cmsAdminPassword: values.cmsAdminPassword, ...(form.dataset.projectId ? { projectId: form.dataset.projectId } : {}) } });
  } else if (name === 'hosting-retry') {
    result = await api(`/hosting/jobs/${encodeURIComponent(form.dataset.jobId)}/retry`, { method: 'POST', body: values.cmsAdminPassword ? { cmsAdminPassword: values.cmsAdminPassword } : {} });
  } else return false;
  const password = form.querySelector('input[type="password"]');
  if (password) password.value = '';
  context.closeModal();
  context.navigate(`hosting/${encodeURIComponent(result.site.id)}`);
  context.notify(result.site.state === 'connected' ? '网站已连接' : '连接任务已保存，请查看处理状态');
  return true;
}
