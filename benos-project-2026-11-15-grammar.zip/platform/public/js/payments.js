import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';

const price = cents => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(cents / 100);
const credit = (cents, bps = 6500) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 4 }).format(cents * bps / 1000000);
const usd = micros => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 6 }).format(micros / 1e6);
const footer = title => `<p class="b-form-error" role="alert" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button ui-button--secondary" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">${title}</button></div>`;
const modal = (title, description, form, body, attrs = '') => `<div class="b-modal-header"><div><h2 id="modal-title">${title}</h2><p>${description}</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="payment-${form}" ${attrs}>${body}</form>`;

export function renderOrderActions(item) {
  return `<div class="b-table-actions">${item.canResumeCheckout ? `<button type="button" class="ui-button ui-button--secondary" data-action="payment-resume" data-order-id="${e(item.id)}">继续原订单付款</button>` : ''}<button type="button" class="ui-button ui-button--secondary" data-action="payment-reconcile" data-order-id="${e(item.id)}">核验订单</button></div>`;
}

function checkoutTarget(value) {
  let target;
  try { target = new URL(value); } catch { throw new Error('结账地址无效。请通过账单记录查询原订单。'); }
  if (target.origin !== 'https://checkout.stripe.com' || target.username || target.password) throw new Error('结账地址未通过安全检查，请联系平台支持。');
  return target.href;
}

export function renderAgreements(items = []) {
  if (!items.length) return '';
  return `<section class="b-section"><div class="b-section-heading"><div><h2>自动续费</h2><p>取消下次续费后，本期已获得的权益仍然有效。</p></div></div><div class="b-agreements">${items.map(item => `<div class="b-card b-topup"><div><h2>${item.tier === 'pro' ? 'Pro' : 'Go'} 订阅</h2><p>${item.state === 'cancelled' ? '续费已停止' : item.state === 'cancel_scheduled' ? '已确认取消下次续费' : item.cancel_requested ? '取消申请待确认，请继续原操作' : '按月自动续费'}</p></div>${['cancelled', 'cancel_scheduled'].includes(item.state) ? '<span class="b-badge">已取消续费</span>' : `<button type="button" class="ui-button ui-button--secondary" data-action="payment-cancel" data-agreement-id="${e(item.id)}">${item.cancel_requested ? '继续确认取消' : '取消下次续费'}</button>`}</div>`).join('')}</div></section>`;
}

export function updateTopupPreview(input) {
  if (input.name !== 'amount' || !input.closest('[data-form="payment-checkout"]')) return;
  const amount = Number(input.value);
  const minimum = Number(input.form.dataset.minimumCents || 500), bps = Number(input.form.dataset.creditBps || 6500);
  const target = input.form.querySelector('[data-topup-credit]');
  if (target) target.textContent = Number.isFinite(amount) && amount * 100 >= minimum ? credit(Math.round(amount * 100), bps) : `最低充值 ${price(minimum)}`;
  const capacity = input.form.querySelector('[data-topup-capacity]');
  if (!capacity || input.form.dataset.quoteStatus !== 'ready') return;
  const required = Number(input.form.dataset.quoteRequiredMicros), available = Number(input.form.dataset.quoteAvailableMicros);
  if (!Number.isFinite(amount) || amount * 100 < minimum) { capacity.textContent = `当前设计所需临时预留 ${usd(required)}。最低充值 $5 不变。`; return; }
  const after = available + Math.round(amount * 100) * bps;
  capacity.textContent = after < required ? `充值后可用余额约 ${usd(after)}，仍低于当前设计所需临时预留 ${usd(required)}。预留按实际用量结算后返还差额；最低充值仍为 $5。` : `充值后可用余额约 ${usd(after)}；当前设计需要临时预留 ${usd(required)}，完成后按实际用量结算并返还差额。`;
}

export async function handlePaymentAction(name, trigger, context) {
  const catalog=context.state.resource;
  const catalogAttrs=`data-catalog-version="${e(catalog.catalogVersionId || '')}"`;
  if (['payment-subscribe','payment-topup','payment-hosting'].includes(name) && catalog.catalogEnabled === false) throw new Error('当前套餐暂停新购，请稍后再试。');
  if (name === 'payment-subscribe') {
    const plan = context.state.resource.plans.find(item => item.tier === trigger.dataset.tier);
    if (!plan) throw new Error('套餐状态已变化，请刷新后重试。');
    context.showModal(modal(`订阅 ${e(plan.name)}`, '完成付款并收到确认后，会员权益才会生效。', 'checkout', `<div class="b-payment-review"><strong>${price(plan.priceCents)}<small> / 月</small></strong><p>每月 ${usd(plan.creditMicros)} AI 额度，包含 ${e(plan.includedSites)} 个网站托管。</p><p>按月自动续费，可随时取消下次续费。</p></div>${footer('前往安全结账')}`, `${catalogAttrs} data-kind="subscription" data-tier="${e(plan.tier)}" data-request-key="${crypto.randomUUID()}"`));
  } else if (name === 'payment-topup') {
    context.showModal(modal('追加 AI 用量', '充值余额单独保留，会员到期后仍可用于 AI 设计。', 'checkout', `<label class="b-field"><span>充值金额（美元）</span><input type="number" name="amount" min="5" max="10000" step="0.01" value="10" required></label><div class="b-payment-review"><span>可获得的 AI 额度</span><strong data-topup-credit>$6.50</strong><p>充值金额的 65% 转换为可用 AI 额度。最低充值 $5。</p></div><p class="b-notice-text" data-topup-capacity role="status">正在核对当前设计所需的临时预留额度…</p>${footer('前往安全结账')}`, `${catalogAttrs} data-minimum-cents="${catalog.topupPolicy?.minimumCents || 500}" data-credit-bps="${catalog.topupPolicy?.creditBps || 6500}" data-kind="topup" data-request-key="${crypto.randomUUID()}"`));
    const form = document.querySelector('form[data-form="payment-checkout"][data-kind="topup"]');
    try {
      const quote = await api('/ai/quote');
      if (!form?.isConnected) return true;
      if (quote.available) {
        form.dataset.quoteStatus = 'ready'; form.dataset.quoteRequiredMicros = quote.requiredReservationMicros; form.dataset.quoteAvailableMicros = quote.availableMicros;
        updateTopupPreview(form.elements.amount);
      } else form.querySelector('[data-topup-capacity]').textContent = 'AI 设计服务当前尚未启用。充值会增加余额，但不会自动启用设计服务。';
    } catch {
      if (form?.isConnected) form.querySelector('[data-topup-capacity]').textContent = '暂时无法核对当前设计所需预留额度。充值入口仍可使用，实际设计可用性需在设计台再次确认。';
    }
  } else if (name === 'payment-hosting') {
    const site = context.state.resource.hosting.find(item => item.id === trigger.dataset.siteId);
    if (!site) throw new Error('网站记录已变化，请刷新后重试。');
    context.showModal(modal('续费 CMS 托管', '网站托管与 AI 会员独立计算。', 'checkout', `<div class="b-payment-review"><span>${e(site.name || site.domain)}</span><strong>${price(catalog.hostingAnnualPriceCents)}<small> / 网站 / 年</small></strong><p>不包含 AI 额度与追加充值权限。</p></div>${footer('前往安全结账')}`, `${catalogAttrs} data-kind="hosting" data-site-id="${e(site.id)}" data-request-key="${crypto.randomUUID()}"`));
  } else if (name === 'payment-resume') {
    trigger.disabled = true;
    try {
      const result = await api(`/billing/orders/${encodeURIComponent(trigger.dataset.orderId)}/checkout`, { method: 'POST', body: {} });
      if (result.checkoutState === 'open' && result.checkoutUrl) { window.location.assign(checkoutTarget(result.checkoutUrl)); return true; }
      await context.reload();
      context.notify(result.checkoutState === 'paid' ? '原订单已确认入账，请查看最新权益' : result.checkoutState === 'expired' ? '原支付会话已到期，原订单已结束，可重新发起购买' : result.checkoutState === 'complete' ? '原支付会话已完成，正在核对到账；请查看订单状态' : '原订单付款状态尚未确认，请核验原订单后再试');
    } finally { if (trigger.isConnected) trigger.disabled = false; }
  } else if (name === 'payment-reconcile') {
    trigger.disabled = true;
    try { await api(`/billing/orders/${encodeURIComponent(trigger.dataset.orderId)}/reconcile`, { method: 'POST', body: {} }); await context.reload(); context.notify('订单已核验，请查看最新状态与权益'); }
    finally { if (trigger.isConnected) trigger.disabled = false; }
  } else if (name === 'payment-cancel') {
    context.showModal(modal('取消下次续费', '当前付费周期内的权益继续保留，下期不再自动扣费。', 'cancel', `<p class="b-confirm-title">本期到期后，历史充值余额仍可使用；继续托管网站需要有效托管权益。</p>${footer('确认取消下次续费')}`, `data-agreement-id="${e(trigger.dataset.agreementId)}"`));
  } else return false;
  return true;
}

export async function submitPaymentForm(name, form, values, context) {
  if (name === 'payment-cancel') {
    const result = await api(`/billing/agreements/${encodeURIComponent(form.dataset.agreementId)}/cancel`, { method: 'POST', body: {} });
    context.closeModal(); await context.reload(); context.notify(['cancelled', 'cancel_scheduled'].includes(result.state) ? '已确认取消下次续费，本期权益保留' : '取消状态待确认，请查看订阅记录'); return true;
  }
  if (name !== 'payment-checkout') return false;
  const kind = form.dataset.kind;
  const body = { kind, requestKey: form.dataset.requestKey };
  if (!form.dataset.catalogVersion) throw new Error('套餐版本尚未读取，请关闭窗口并刷新账单后重试。');
  body.catalogVersionId = form.dataset.catalogVersion;
  if (kind === 'subscription') body.tier = form.dataset.tier;
  else if (kind === 'hosting') body.siteId = form.dataset.siteId;
  else {
    if (!/^\d+(?:\.\d{1,2})?$/.test(values.amount)) throw new Error('请输入最多两位小数的美元金额。');
    const [whole, fraction = ''] = values.amount.split('.');
    body.amountCents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
    if (!Number.isSafeInteger(body.amountCents) || body.amountCents < Number(form.dataset.minimumCents || 500)) throw new Error('最低充值金额为 5 美元。');
  }
  const result = await api('/billing/checkout', { method: 'POST', body });
  if (!result.checkoutUrl) { context.closeModal(); await context.reload(); context.notify('订单已记录，请查看订单状态并核验支付'); return true; }
  window.location.assign(checkoutTarget(result.checkoutUrl));
  return true;
}
