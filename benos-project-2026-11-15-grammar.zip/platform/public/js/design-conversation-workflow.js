import { escapeHtml as e, icon } from './icons.js';

const formatter = new Intl.NumberFormat('en-US', {
  style: 'currency', currency: 'USD', maximumFractionDigits: 6,
});
const money = value => Number.isSafeInteger(value) ? formatter.format(value / 1_000_000) : '—';
export const imageOnlyPrompt = '参考所附图片优化网站设计。';

const labels = {
  ready: '等待下一轮设计', processing: '正在处理本轮设计', succeeded: '设计方案已生成',
  failed: '本次设计未完成', uncertain: '结果与费用待核对',
  budget_exhausted: '本次任务已用完可预留额度', steps_exhausted: '本次任务已达到处理轮数上限',
};

const tools = {
  read_project: '读取项目摘要', list_files: '查看文件索引', read_file: '读取文件',
  read_fragment: '读取文件片段', find_text: '查找文本', propose_edits: '修改文件片段',
  propose_files: '准备文件修改', check_preview: '检查结构与修改范围', finish: '保存待采用方案',
};
const errors = {
  INSUFFICIENT_CREDIT:'账户可用额度不足以预留下一轮费用。',
  INSUFFICIENT_PROVIDER_FUNDS:'平台的设计额度暂时不足，请稍后重试。',
  AI_NOT_CONFIGURED:'AI 设计服务尚未启用。',
  AI_BILLING_UNVERIFIED:'设计服务的计费尚待核验。',
  VERSION_CONFLICT:'当前设计已有更新，请返回当前版本后继续。',
};

function sentReferences(ids, assets) {
  if (!Array.isArray(ids) || !ids.length) return '';
  const items = [...new Set(ids)].map(id => assets.find(asset => asset.id === id && asset.state === 'ready' && !asset.deletedAt &&
    ['image/png','image/jpeg','image/webp'].includes(asset.mimeType) && asset.contentUrl)).filter(Boolean);
  if (!items.length) return '';
  return `<div class="d-sent-references" aria-label="本条消息的参考图">${items.map(item => `<img loading="lazy" src="${e(item.contentUrl)}" alt="参考图：${e(item.fileName)}" width="64" height="52">`).join('')}</div>`;
}

export function recordHtml(item, running, proposal) {
  const activity = (item.steps || []).flatMap(step => (step.tools || []).map(tool =>
    `<li>第 ${e(step.ordinal)} 轮 · ${e(tools[tool.name] || tool.name)} · ${tool.ok ? '已完成' : '未完成'}${tool.code ? `（${e(tool.code)}）` : ''}</li>`));
  const candidate = item.candidateId
    ? `#design/${encodeURIComponent(item.projectId)}?${item.baseVersionId ? 'version=' + encodeURIComponent(item.baseVersionId) + '&amp;' : ''}candidate=${encodeURIComponent(item.candidateId)}` : '';
  const candidateState = {adopted:'方案已采用',discarded:'方案已放弃',draft:'方案已准备，等待采用'}[proposal?.state];
  const status = item.state === 'succeeded' && candidateState ? candidateState : labels[item.state] || item.state;
  return `<div class="b-design-job" data-workflow-id="${e(item.id)}"><div>${icon(item.state === 'succeeded' ? 'circle-check' : item.state === 'uncertain' ? 'circle-question-mark' : 'clock')}<strong>${e(status)}</strong></div>
    <p>已处理 ${e(item.stepsUsed)} 轮 · 已用 ${money(item.consumedMicros)} · 预留 ${money(item.heldMicros)}</p>
    <details><summary>额度明细</summary><p>${item.requestOrigin === 'account' ? '本次任务上限' : '原请求预算'} ${money(item.maxCostMicros)} · 最多 ${e(item.maxSteps)} 轮</p></details>
    ${item.workspaceId ? `<small>文件工作区 · 修订 ${e(item.workspaceRevision ?? 0)} · 修改结果仍需预览采用</small>` : ''}
    ${activity.length ? `<details><summary>本地工具处理记录</summary><ul>${activity.join('')}</ul></details>` : ''}
    ${item.referenceMode === 'model-input-image' ? '<small>参考图输入方式：图像输入</small>' : ''}
    ${item.errorCode ? `<p>${item.state === 'uncertain' ? '费用未确认，保留原任务与预留额度，请稍后查询。' : errors[item.errorCode] || '本次流程已停止，请查看处理记录。'}</p><code>${e(item.errorCode)}</code>${item.errorCode === 'INSUFFICIENT_CREDIT' ? '<a href="#billing">查看账户额度</a>' : ''}` : ''}
    ${candidate ? `<a href="${candidate}">${proposal?.state === 'draft' ? '对比并采用方案' : '查看设计方案'} ${icon('arrow-right')}</a>` : ''}
    ${(item.state === 'ready' || item.recoverable) && !running ? `<button type="button" class="ui-button ui-button--secondary" data-action="design-workflow-continue" data-id="${e(item.id)}">${item.recoverable ? '恢复本地处理' : '继续原任务'}</button>` : ''}
    ${item.state === 'uncertain' || item.state === 'processing' ? `<button type="button" class="text-button" data-action="design-workflow-refresh" data-id="${e(item.id)}">查询原任务</button>` : ''}
    ${running ? `<button type="button" class="ui-button ui-button--secondary" data-action="design-workflow-pause" data-id="${e(item.id)}">停止自动继续</button>` : ''}
    ${item.state === 'processing' && !item.recoverable ? '<small>当前轮次已发送，正在等待结果。</small>' : ''}</div>`;
}

export function turnKey(turn) {
  return turn.requestKey ? `request-${turn.requestOrigin || 'account'}-${turn.requestKey}` : String(turn.transcriptId || turn.id);
}

function candidateLink(turn) {
  return turn.candidateId ? `#design/${encodeURIComponent(turn.projectId)}?${turn.baseVersionId ? 'version=' + encodeURIComponent(turn.baseVersionId) + '&amp;' : ''}candidate=${encodeURIComponent(turn.candidateId)}` : '';
}
function conversationStatus(turn) {
  if (turn.state === 'pending') return '正在发送…';
  if (turn.state === 'checking') return '发送结果待确认。';
  if (turn.state === 'received') return '消息已保存，等待继续处理。';
  if (turn.state === 'ready' || turn.state === 'processing') return '正在处理你的需求…';
  if (turn.state === 'uncertain') return '设计结果待核对。';
  if (turn.state === 'failed') {
    if (turn.errorCode === 'AI_NOT_CONFIGURED') return 'AI 设计服务尚未启用。';
    if (turn.errorCode === 'INSUFFICIENT_CREDIT') return '可用 AI 额度不足，暂时无法继续。';
    return '这次设计未完成。';
  }
  if (turn.state === 'budget_exhausted' || turn.state === 'steps_exhausted') return '本次设计已停止。';
  if (turn.candidateState === 'adopted') return '设计方案已采用。';
  if (turn.candidateState === 'discarded') return '设计方案已放弃。';
  if (turn.candidateId) return '设计方案已准备好。';
  if (turn.versionId) return '已保存设计版本。';
  return '';
}
function publicReply(value) {
  if (typeof value !== 'string') return '';
  // The transcript API exposes only the public reply. Older responses may lack it.
  // Never substitute tool arguments, provider output, errors or document source.
  return value.trim();
}
function defaultExpanded(text) {
  return text.length <= 320 && text.split('\n').length <= 5 && !/\x60\x60\x60|~~~|<\s*(?:!doctype|html|style|script|div|section)\b|(?:^|\n)\s*(?:import |export |function |const |def |class )/i.test(text);
}
function chatMessage(role, turn, text, images, footer, folds) {
  const id = role + '-' + turnKey(turn), bodyId = 'chat-body-' + encodeURIComponent(id);
  const open = folds[id] ?? defaultExpanded(text);
  const label = role === 'user' ? '你' : '设计助手';
  const avatar = role === 'user' ? '你' : '<img class="d-assistant-logo" src="/assets/brand/benos-logo.svg" alt="" width="20" height="20">';
  const excerpt = text.replace(/\s+/g,' ').trim().slice(0,56) || (images ? '图片消息' : '消息');
  return `<article class="d-message d-message--${role}" data-chat-key="${e(id)}" data-message-id="${e(id)}" data-message-role="${role}">
    <span class="d-message-avatar" aria-hidden="true">${avatar}</span><div class="d-message-content">
    <button type="button" class="d-chat-fold" data-action="design-conversation-fold" data-id="${e(id)}" aria-controls="${e(bodyId)}" aria-expanded="${open}" aria-label="${open?'收起':'展开'}${label}的消息"><span>${label}</span>${icon('chevron-down')}</button>
    <div id="${e(bodyId)}" data-message-body${open?'':' hidden'}>${text ? `<p>${e(text)}</p>` : ''}${images}</div>
    <span class="d-fold-excerpt" data-fold-excerpt${open?' hidden':''}>${e(excerpt)}</span>
    ${footer ? `<div class="d-chat-result" data-message-result>${footer}</div>` : ''}</div></article>`;
}

export function turnHtml(turn, assets, folds) {
  const reply = publicReply(turn.assistantReply);
  const text = typeof turn.requestPrompt === 'string' ? turn.requestPrompt : '';
  const images = sentReferences(turn.referenceMediaIds,assets);
  let status = reply ? '' : conversationStatus(turn);
  if (!text && !images && !reply && !turn.candidateId && !turn.versionId) return '';
  const link = candidateLink(turn);
  if (link) status += ` <a href="${link}">查看方案</a>`;
  if (!link && turn.versionId) status += ` <a href="#design/${encodeURIComponent(turn.projectId)}?version=${encodeURIComponent(turn.versionId)}">查看版本</a>`;
  if (turn.checkedMissing || turn.state === 'checking') {
    status += ' <button type="button" class="text-button" data-action="design-message-check">查询原请求</button>';
    if (turn.checkedMissing) status += ' <button type="button" class="text-button" data-action="design-message-retry">按原请求重试</button>';
  }
  if (turn.state === 'received') status += ` <button type="button" class="text-button" data-action="design-conversation-resume" data-id="${e(turnKey(turn))}">继续原消息</button>`;
  if (turn.state === 'uncertain') status += ' <button type="button" class="text-button" data-action="design-conversation-task-records">查看任务</button>';
  if (turn.errorCode === 'INSUFFICIENT_CREDIT') status += ' <a href="#billing">查看账户额度</a>';
  const userMessage = text || images || turn.referenceMediaIds?.length ? chatMessage('user',turn,text,images,reply ? '' : status,folds) : '';
  return userMessage + (reply ? chatMessage('assistant',turn,reply,'',status,folds) : '');
}

export function unavailableMessage(quote) {
  if (!quote.reason || quote.reason === 'AI_NOT_CONFIGURED') return 'AI 设计服务尚未启用。';
  if (['CAPABILITY_TEST_REQUIRED', 'AI_BILLING_UNVERIFIED'].includes(quote.reason)) return '当前设计服务的能力与计费尚待核验。';
  return '暂时无法读取 AI 设计报价，请稍后刷新。';
}

const presetStyles = ['简洁留白','现代科技','温暖自然','精致商务','大胆创意'];
function chatTool({key, label, caption, glyph, detail, content, selected}) {
  const id = `design-chat-${key}`;
  return `<button type="button" class="d-chat-tool" data-chat-tool="${key}" aria-label="${e(label)}" title="${e(detail)}" aria-expanded="false" aria-controls="${id}" data-selected="${selected}">
    ${icon(glyph)}${caption ? `<span>${e(caption)}</span>` : ''}
  </button><div class="d-chat-tool-panel" data-chat-tool-panel="${key}" id="${id}" role="group" aria-labelledby="${id}-title" hidden>
    <div class="d-chat-tool-heading"><h3 id="${id}-title">${e(label)}</h3><button class="d-chat-tool-close" type="button" data-chat-tool-close aria-label="收起${e(label)}" title="收起">${icon('x')}</button></div>
    <div class="d-chat-tool-content">${content}</div>
  </div>`;
}
export function pickedReferences(references, referenceIds) {
  return referenceIds.map(id => {
    const asset = references.find(item => item.id === id), name = asset?.fileName || '不可用的参考图';
    return `<button type="button" class="d-picked-reference" data-chat-remove-reference="${e(id)}" aria-label="移除${e(name)}" title="移除${e(name)}">
      ${asset ? `<img src="${e(asset.contentUrl)}" alt="">` : icon('image')}<span class="d-picked-remove">${icon('x')}</span></button>`;
  }).join('');
}
export function projectReferenceLibrary(references,referenceIds,projectId) {
  const choices = references.length ? `<fieldset data-conversation-references><legend>最多 3 张，共 6 MiB</legend>${references.map(asset => `<label class="d-reference-choice"><input type="checkbox" name="referenceMediaIds" value="${e(asset.id)}" ${referenceIds.includes(asset.id) ? 'checked' : ''}><img loading="lazy" src="${e(asset.contentUrl)}" alt="" width="32" height="32"><span>${e(asset.fileName)}</span></label>`).join('')}</fieldset>` : '<p class="d-chat-tool-empty">项目中还没有可选图片。</p>';
  return choices + `<a class="d-chat-project-media" href="#media/${encodeURIComponent(projectId)}">项目素材 ${icon('arrow-up-right')}</a>`;
}
function designTools({style, starterStyle, references, referenceIds, projectId}) {
  const styles = [...new Set([starterStyle,style,...presetStyles].filter(Boolean))];
  const styleField = `<fieldset class="d-chat-style-list"><legend class="ui-sr-only">视觉风格</legend>${['',...styles].map(value =>
    `<label class="d-chat-style-option"><input type="radio" name="style" value="${e(value)}"${style === value ? ' checked' : ''}><span>${e(value || '由需求决定')}</span>${icon('check')}</label>`).join('')}</fieldset>`;
  const styleTool = chatTool({key:'style',label:'视觉风格',caption:'风格',glyph:'palette',detail:style ? `视觉风格 · ${style}` : '选择视觉风格',content:styleField,selected:!!style});
  const upload = `<button type="button" class="d-chat-tool d-chat-upload-button" data-chat-upload-button aria-label="上传参考图" title="从设备上传参考图">${icon('image')}<span>上传参考图</span></button>
    <input type="file" hidden data-chat-upload-input accept="image/png,image/jpeg,image/webp" multiple aria-label="选择参考图片">`;
  const refsTool = chatTool({key:'references',label:'项目参考图',caption:'',glyph:'chevron-down',detail:'从项目素材选择参考图',content:projectReferenceLibrary(references,referenceIds,projectId),selected:referenceIds.length > 0});
  return `<div class="d-chat-tools" aria-label="设计选项" role="group">${styleTool}<div class="d-chat-attachment-tools">${upload}${refsTool}</div></div>`;
}

export function composerHtml(state) {
  const {prompt, pending, active, quote, blocked, scopeLabel, hasStarter, sending, projectId} = state;
  const disabled = !!(pending || active || blocked || sending);
  let hint = '按实际用量结算';
  if (hasStarter) hint = '预览草稿待采用';
  if (quote?.available === false) hint = unavailableMessage(quote).replace(/。$/,'');
  else if (quote?.available && quote.canReserve === false) hint = `单轮需预留 ${money(quote.perStepReservationMicros)}`;
  let note = `<span data-conversation-scope>${e(scopeLabel || '')}</span> · ${e(hint)}`;
  if (blocked) note = e(blocked) + ` <a href="#design/${encodeURIComponent(projectId)}">返回当前设计</a>`;
  else if (pending || active) note = '可先写下一条消息。';
  return `<div class="d-compose-area"><form class="d-compose" data-form="design-conversation-message">
    <label class="ui-sr-only" for="designer-prompt">描述想调整的设计</label>
    <div class="d-picked-references" data-chat-selected-references${state.referenceIds.length ? '' : ' hidden'}>${pickedReferences(state.references,state.referenceIds)}</div>
    <textarea id="designer-prompt" name="prompt" rows="2" minlength="1" maxlength="18000" ${state.referenceIds.length ? '' : 'required'} placeholder="${state.referenceIds.length ? imageOnlyPrompt : '描述想调整的地方…'}">${e(prompt)}</textarea>
    <div class="d-compose-footer">${designTools(state)}<button class="ui-icon-button ui-button--primary d-send" type="submit" ${disabled ? 'disabled' : ''} aria-label="发送设计调整" title="发送（Ctrl / ⌘ + Enter）" aria-keyshortcuts="Control+Enter Meta+Enter">${icon('arrow-up')}</button></div>
    <div class="d-chat-upload-status" data-chat-upload-status hidden><span data-chat-upload-message role="status"></span>
      <button type="button" class="text-button" data-chat-upload-retry hidden>重试</button><button type="button" class="text-button" data-chat-upload-dismiss hidden>取消本次附件</button></div>
    <p class="b-form-error" role="alert" data-form-error hidden></p></form>
    <p class="d-compose-note">${note}</p></div>`;
}
