import { api } from './api.js';
import { icon, escapeHtml as e } from './icons.js';
import { primeWorkflowDraft } from './design-workflow.js';
import { uploadProjectMedia } from './media.js';
import { normalizeDirection, designPalettes } from './workspace-direction.js';
const starts=new Map();
const get=user=>{if(!starts.has(user.id))starts.set(user.id,{files:[],style:'',template:null,uploads:{}});return starts.get(user.id);};
export function getDesignDirection(user){return normalizeDirection(get(user).direction || {});}
export function setDesignDirection(user,value){const state=get(user);state.direction=normalizeDirection(value);const d=state.direction,p=designPalettes.find(p=>p.id===d.accent);state.style=`${d.style}；配色：${p.name}（${p.colors.join('、')}）；字体：${d.typography==='editorial'?'编辑衬线':'现代无衬线'}；首屏：${d.layout==='centered'?'居中叙事':'左右分栏'}`;return state.direction;}
export function renderDesignStart(user,compact=false){const state=get(user);if(compact){if(!state.direction)setDesignDirection(user,{});return `<input type="hidden" name="startStyle" value="${e(state.style)}"><input type="file" hidden id="workspace-reference-input" name="startReferences" accept="image/png,image/jpeg,image/webp" multiple aria-label="选择最多 3 张参考图片"><div data-start-selection>${selection(state)}</div><p class="b-form-error" data-start-error role="alert" hidden></p>`;}return `<div class="b-start-options"><label class="b-start-style"><span>风格方向</span><select name="startStyle"><option value="">由需求决定</option>${['简洁留白','现代科技','温暖自然','精致商务','大胆创意'].map(style=>`<option ${state.style===style?'selected':''}>${e(style)}</option>`).join('')}</select></label><label class="ui-button ui-button--secondary b-start-file">${icon('image')}参考图片<input type="file" name="startReferences" accept="image/png,image/jpeg,image/webp" multiple aria-label="选择最多 3 张参考图片"></label><button type="button" class="ui-button ui-button--secondary" data-action="start-library">${icon('layout-template')}从模板开始</button></div><div data-start-selection>${selection(state)}</div><p class="b-start-hint">图片保存在你的私有项目中。发送设计消息时使用账户中的 AI 额度。</p><p class="b-form-error" data-start-error role="alert" hidden></p>`;}
function selection(state){return `${state.template?`<div class="b-start-template">${icon('layout-template')}已选模板：${e(state.template.name)}<button type="button" class="text-button" data-action="start-clear-template">取消选择</button></div>`:''}${state.files.length?`<div class="b-start-references">${state.files.map((item,index)=>`<div><img src="${e(item.url)}" alt="${e(item.file.name)}"><span>${e(item.file.name)}</span><button type="button" class="ui-button ui-icon-button" data-action="start-remove-reference" data-index="${index}" aria-label="移除 ${e(item.file.name)}">${icon('x')}</button></div>`).join('')}</div>`:''}`;}
function redraw(user){const node=document.querySelector('[data-start-selection]');if(node)node.innerHTML=selection(get(user));}
export function changeDesignStart(target,context){
  const state=get(context.state.user);if(target.name==='startStyle'){state.style=target.value;return;}
  if(target.name!=='startReferences')return;
  const files=Array.from(target.files||[]),error=document.querySelector('[data-start-error]');
  if(files.length>3||files.reduce((total,file)=>total+file.size,0)>6*1024*1024||files.some(file=>!['image/png','image/jpeg','image/webp'].includes(file.type))){if(error){error.hidden=false;error.textContent='请选择 PNG、JPEG 或 WebP 图片，最多 3 张，合计不超过 6 MiB。';}target.value='';return;}
  state.files.forEach(item=>URL.revokeObjectURL(item.url));state.files=files.map(file=>({file,url:URL.createObjectURL(file),requestKey:crypto.randomUUID()}));if(error)error.hidden=true;redraw(context.state.user);
}
export function captureDesignStart(form,user){const state=get(user);state.style=form.elements.startStyle?.value||'';return{...state,files:[...state.files],uploads:{},prompt:form.elements.description?.value.trim()||''};}
export async function finishDesignStart(project,user,start){
  const referenceMediaIds=[];
  for(const item of start.files){let asset=start.uploads[item.requestKey];if(!asset){asset=await uploadProjectMedia(project.id,item.file,item.requestKey);start.uploads[item.requestKey]=asset;}referenceMediaIds.push(asset.id);}
  primeWorkflowDraft(user.id,project.id,{prompt:project.description||start.prompt,style:start.style,referenceMediaIds});
  let path=`design/${encodeURIComponent(project.id)}`;
  if(start.template){start.templateRequestKey||=crypto.randomUUID();const proposal=await api(`/design/projects/${encodeURIComponent(project.id)}/templates/${encodeURIComponent(start.template.id)}`,{method:'POST',body:{requestKey:start.templateRequestKey,baseVersionId:null}});path+=`?candidate=${encodeURIComponent(proposal.id)}`;}
  get(user).files.forEach(item=>URL.revokeObjectURL(item.url));starts.delete(user.id);return path;
}
export async function handleDesignStartAction(name,trigger,context){
  const state=get(context.state.user);
  if(name==='start-library'){const{items}=await api('/design/templates');state.options=items;context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">从一个完整模板开始</h2><p>选好模板后创建项目，再预览并确认采用。</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></div><div class="b-modal-body b-template-library">${items.map(item=>`<article class="b-template-choice"><div class="b-template-snapshot"><iframe src="${e(item.previewUrl)}" title="${e(item.name)}模板预览" sandbox="allow-same-origin" loading="lazy" tabindex="-1" inert></iframe></div><h3>${e(item.name)}</h3><p>${e(item.description)}</p><button type="button" class="ui-button ui-button--primary" data-action="start-choose-template" data-id="${e(item.id)}">选择此模板</button></article>`).join('')||'<p>暂时没有可用模板。</p>'}</div>`);return true;}
  if(name==='start-choose-template'){state.template=state.options?.find(item=>item.id===trigger.dataset.id)||null;context.closeModal();redraw(context.state.user);return true;}
  if(name==='start-clear-template'){state.template=null;redraw(context.state.user);return true;}
  if(name==='start-remove-reference'){const[item]=state.files.splice(Number(trigger.dataset.index),1);if(item)URL.revokeObjectURL(item.url);redraw(context.state.user);return true;}
  return false;
}
