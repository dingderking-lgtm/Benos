import { api } from './api.js';
import { escapeHtml as e } from './icons.js';
export function renderNotifications(data){
 return `<section class="s-page"><div class="page-intro"><div><h1>服务通知</h1><p>套餐和网站托管在到期前 7 天、前 1 天及到期后提醒。未读 ${data.unreadCount} 条。</p></div></div>${data.items.length?data.items.map(n=>`<article class="b-card b-section"><div class="b-section-heading"><h2>${e(n.title)}</h2><span class="b-badge">${n.readAt?'已读':'未读'}</span></div><p>${e(n.body)}</p><p class="b-muted">${e(new Date(n.createdAt).toLocaleString('zh-CN'))}</p><div class="b-table-actions"><a class="ui-button ui-button--secondary" href="${n.siteId?'#hosting/'+encodeURIComponent(n.siteId):'#billing'}">查看当前权益</a>${!n.readAt?`<button type="button" class="ui-button ui-button--secondary" data-action="notification-read" data-notification-id="${e(n.id)}">标记已读</button>`:''}</div></article>`).join(''):'<div class="b-empty"><h2>暂无服务通知</h2><p>到期提醒会显示在这里；续费后请以当前权益状态为准。</p></div>'}</section>`;
}
export async function readNotification(trigger,context){
 trigger.disabled=true;try{await api('/notifications/'+encodeURIComponent(trigger.dataset.notificationId)+'/read',{method:'POST',body:{}});await context.reload();}finally{if(trigger.isConnected)trigger.disabled=false;}
}
