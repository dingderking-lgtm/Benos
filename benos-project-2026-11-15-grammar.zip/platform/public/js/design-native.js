import { api } from './api.js';
import { escapeHtml as e, icon } from './icons.js';
import { visualState, visualManifest } from './design-editor.js';

const records = new Map();
const phases = { transfer: '向 CMS 传输资源', render: 'CMS 正在渲染', artifacts: '接收并校验预览内容', finalize: '完成预览检查', complete: '原生预览已准备' };
const terminal = new Set(['ready', 'cancelled', 'expired', 'failed']);
const errors = { NATIVE_PREVIEW_REMOTE_CAPACITY: 'CMS 正在处理其他任务，请稍后继续此预览。原任务和已确认进度会保留。' };
let mounted = null, pollTimer, mountEpoch = 0;
const path = id => `/design/native-preview-jobs/${encodeURIComponent(id)}`;
const signature = (data, user) => data.visual.proposal && visualState(data, user).compare !== 'original' ? 'candidate:' + data.visual.proposal.id : 'version:' + (data.selected?.id || '');
const number = value => new Intl.NumberFormat('zh-CN').format(value);
const button = (label, action, disabled = false) => `<button type="button" class="ui-button ui-button--secondary" data-action="design-native-${action}" ${disabled ? 'disabled' : ''}>${label}</button>`;

export function nativePageOptions(manifest) {
  if(Array.isArray(manifest?.pageOptions))return manifest.pageOptions.map(option=>({key:option.key,label:option.label}));
  const pages = manifest?.site?.pages || [], blog = manifest?.site?.blog, hasBlog = !!blog && typeof blog === 'object' && !Array.isArray(blog);
  const options = pages.map(page => ({ key: page.key, label: (page.title || page.key) + (page.type === 'article' ? '（文章详情）' : '') }));
  if (hasBlog && blog.enabled !== false) options.push({ key: '__blog_archive', label: '博客归档' }, { key: '__blog_author', label: '博客作者页' });
  if (hasBlog && !pages.some(page => page.type === 'article')) options.push({ key: '__blog_article', label: '文章详情（示例）' });
  return options;
}
function selectedNativePage(manifest, state) {
  const options = nativePageOptions(manifest);
  return options.some(option => option.key === state.nativePage) ? state.nativePage : options.some(option => option.key === manifest?.site?.home) ? manifest.site.home : options[0]?.key;
}
function selection(data, user) {
  const state = visualState(data, user), pageKey = selectedNativePage(visualManifest(data, user), state);
  state.nativePage = pageKey;
  const source = data.visual.proposal && state.compare !== 'original' ? { candidateId: data.visual.proposal.id } : { versionId: data.selected?.id };
  return { ...source, pageKey };
}
function storageKey(data, user) {
  const chosen = selection(data, user);
  return `benos-native-job:${user.id}:${data.project.id}:${signature(data, user)}:${chosen.pageKey || ''}`;
}
function recordFor(data, user) {
  const key = storageKey(data, user), chosen = selection(data, user);
  if (!records.has(key)) {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(key) || 'null'); } catch { /* Memory-only recovery remains available. */ }
    if (!saved || typeof saved.requestKey !== 'string' || saved.pageKey !== chosen.pageKey || (saved.versionId || null) !== (chosen.versionId || null) || (saved.candidateId || null) !== (chosen.candidateId || null)) saved = null;
    records.set(key, { key, projectId: data.project.id, userId: user.id, signature: signature(data, user), chosen, saved, view: null, error: '', message: '', running: false, runEpoch: 0 });
  }
  return records.get(key);
}
function persist(record) {
  try { if (record.saved) localStorage.setItem(record.key, JSON.stringify(record.saved)); else localStorage.removeItem(record.key); } catch { /* Do not store preview HTML or capability URLs. */ }
}
function sameSelection(context, record) {
  return context.state.user?.id === record.userId && context.state.resource?.project?.id === record.projectId && (!context.state.route || context.state.route.startsWith(`design/${record.projectId}`)) && storageKey(context.state.resource, context.state.user) === record.key;
}
export function nativePreview(data, user) {
  const state = visualState(data, user), preview = state.nativePreview;
  return state.previewMode === 'native' && preview?.signature === signature(data, user) && preview.pageKey === selectedNativePage(visualManifest(data, user), state) && Date.parse(preview.expiresAt) > Date.now() ? preview : null;
}
function jobLabel(record) {
  const view = record.view;
  if (!view) return record.saved ? '原预览请求已保留' : '';
  if (view.state === 'ready') return '原生预览已准备';
  if (view.state === 'cancelled') return '已取消此预览';
  if (view.state === 'expired') return '原生预览已过期';
  if (view.state === 'failed') return '原生预览未完成';
  if (view.errorCode === 'NATIVE_PREVIEW_REMOTE_CAPACITY') return '等待 CMS 处理资源';
  return view.errorCode ? '原任务需要核对' : phases[view.phase] || '正在准备原生预览';
}
function jobMarkup(record) {
  if (!record.saved) return '';
  const view = record.view, processing = !view || view.state === 'processing';
  const description = processing ? '暂停浏览器或关闭页面后，后台仍可能继续准备。预览不会采用设计或发布网站，也不发起付费 AI 请求。' : view.state === 'ready' ? '预览已经准备好，可在有效期内查看。任务详情中的字节数来自服务器确认。' : view.state === 'cancelled' ? '此任务已停止，原生预览与临时资源已失效。' : view.state === 'expired' ? '此任务已到期，可重新准备原生预览。' : '本次未生成可用的原生预览，请查看错误后再决定下一步。';
  const content = `<strong>${e(jobLabel(record))}</strong>`;
  const body = `${view ? `<span>已完成 ${number(view.completedSteps)} 个处理步骤${view.busy ? ' · 当前步骤正在处理' : ''}</span><span>CMS 已确认资源 ${number(view.bytesSent)} / ${number(view.totalBytes)} 字节</span><progress aria-label="CMS 已确认原生预览资源" max="${view.totalBytes || 1}" value="${view.bytesSent}" style="width:100%"></progress>${view.artifactBytesTotal ? `<span>预览内容已接收 ${number(view.artifactBytesReceived)} / ${number(view.artifactBytesTotal)} 字节</span><progress aria-label="预览内容接收进度" max="${view.artifactBytesTotal}" value="${view.artifactBytesReceived}" style="width:100%"></progress>` : ''}<small>${view.state === 'ready' ? '预览有效至' : '任务有效至'} ${e(new Date(view.expiresAt).toLocaleString('zh-CN'))}</small>` : ''}<span>${description}</span>${record.message ? `<span role="status">${e(record.message)}</span>` : ''}${record.error || view?.errorCode ? `<p class="b-form-error" role="alert">${e(errors[view?.errorCode] || record.error || '此步骤尚未确认，请更新或继续原任务。')}${view?.errorCode ? `<br><code>${e(view.errorCode)}</code>` : ''}</p>` : ''}<div class="b-table-actions">${record.running ? button('暂停浏览器继续', 'pause') : processing ? button('继续原任务', 'render') : ''}${record.saved.jobId ? button('更新任务状态', 'refresh', record.running) : ''}${record.saved.jobId && ['processing', 'ready'].includes(view?.state) ? button('取消此预览', 'cancel') : ''}${view?.state === 'ready' ? button('打开原生预览', 'open', record.running) : ''}</div>${record.saved.jobId && ['processing', 'ready'].includes(view?.state) ? '<small>取消后，此预览及临时资源将失效；设计版本和网站内容会保留。</small>' : ''}`;
  return view?.state === 'ready' ? `<details class="b-native-notice" data-native-details ${record.detailsOpen ? 'open' : ''}><summary>原生预览已准备 · 任务详情与取消</summary><div style="display:grid;gap:6px">${body}</div></details>` : `<section class="b-native-notice" aria-label="原生预览任务">${content}${body}</section>`;
}
function renderLabel(record, shown) {
  if (record.running) return '正在准备…';
  if (record.view?.state === 'ready') return shown ? '更新预览状态' : '打开原生预览';
  if (record.saved && !terminal.has(record.view?.state)) return '继续原任务';
  return record.saved ? '重新准备预览' : 'CMS 原生预览';
}
export function renderNativeTools(data, user) {
  const native = nativePreview(data, user), state = visualState(data, user), manifest = visualManifest(data, user), options = nativePageOptions(manifest), record = recordFor(data, user);
  return `<div data-native-container="${e(record.key)}"><div class="b-native-tools"><span>${native ? 'CMS 原生预览' : '设计预览'}</span><label class="b-field" style="margin:0"><span class="b-sr-only">原生预览页面，点击预览后加载</span><select data-native-page ${!manifest ? 'disabled' : ''}>${options.map(option => `<option value="${e(option.key)}" ${option.key === state.nativePage ? 'selected' : ''}>${e(option.label)}</option>`).join('')}</select></label><button type="button" class="ui-button ui-button--secondary" data-action="design-native-render" ${!manifest || record.running ? 'disabled' : ''}>${icon('monitor')}<span data-native-render-label>${renderLabel(record, !!native)}</span></button>${native ? button('返回设计编辑', 'return') : ''}</div><div data-native-task>${jobMarkup(record)}</div></div>`;
}
export function renderNativeNotice(data, user) {
  const native = nativePreview(data, user); if (!native) return '';
  const changes = native.sanitizationChanges;
  return `<div class="b-native-notice" role="status"><strong>CMS ${e(native.cmsVersion || '当前版本')} 实际渲染</strong><span>${native.usesSampleData ? '预览含演示数据，用于检查列表与详情结构。' : '使用该站点提供的预览数据。'} 预览不会发布到网站。</span>${Array.isArray(changes) && changes.length ? `<details><summary>隔离预览清理了 ${changes.length} 项内容</summary><ul>${changes.map(change => `<li>${e(typeof change === 'string' ? change : `模板 ${change.templateId} 的 ${change.field === 'css' ? '样式' : '内容'}经过安全清理，可能与设计预览略有不同`)}</li>`).join('')}</ul></details>` : typeof changes === 'number' && changes > 0 ? `<span>隔离预览清理了 ${changes} 项内容。</span>` : ''}<small>在独立隔离环境中查看原生效果；区块选择与样式修改请返回设计编辑。</small></div>`;
}
function update(record, context) {
  if (!sameSelection(context, record) || typeof document === 'undefined') return;
  const container = document.querySelector('[data-native-container]'); if (!container || container.dataset.nativeContainer !== record.key) return;
  const focus = document.activeElement?.closest('[data-action]'), focusAction = container.contains(focus) ? focus.dataset.action : null;
  const detail = container.querySelector('[data-native-details]'); if (detail) record.detailsOpen = detail.open;
  container.querySelector('[data-native-task]').innerHTML = jobMarkup(record);
  const primary = container.querySelector('.b-native-tools [data-action="design-native-render"]'); primary.disabled = record.running || !visualManifest(context.state.resource, context.state.user); primary.querySelector('[data-native-render-label]').textContent = renderLabel(record, !!nativePreview(context.state.resource, context.state.user));
  if (focusAction && (!focus?.isConnected || focus.disabled)) container.querySelector(`[data-action="${focusAction}"]:not(:disabled)`)?.focus({ preventScroll: true });
}
function accept(record, view) {
  const validInteger = value => Number.isSafeInteger(value) && value >= 0;
  if (!view || typeof view.id !== 'string' || view.projectId !== record.projectId || view.pageKey !== record.chosen.pageKey || (view.versionId || null) !== (record.chosen.versionId || null) || (view.candidateId || null) !== (record.chosen.candidateId || null) || !['processing', 'ready', 'cancelled', 'expired', 'failed'].includes(view.state) || ![view.completedSteps, view.bytesSent, view.totalBytes, view.artifactBytesReceived, view.artifactBytesTotal].every(validInteger) || view.bytesSent > view.totalBytes || view.artifactBytesReceived > view.artifactBytesTotal || !Number.isFinite(Date.parse(view.expiresAt)) || record.saved.jobId && record.saved.jobId !== view.id) throw new Error('原生预览的身份或进度不一致，请保留原任务并重试。');
  if (record.view?.state === 'cancelled' && view.state !== 'cancelled') return record.view;
  record.view = view; record.saved.jobId = view.id;
  if (view.state === 'ready') { record.error = ''; record.message = ''; }
  if (view.state === 'cancelled') { record.error = ''; record.message = '服务器已确认取消此预览。'; }
  if (record.saved.pendingStep && view.completedSteps >= record.saved.pendingStep) delete record.saved.pendingStep;
  persist(record); return view;
}
async function refresh(record) { return accept(record, await api(path(record.saved.jobId))); }
function restoreControlFocus(action) {
  if (typeof document === 'undefined') return;
  const restore = () => {
    const active = document.activeElement;
    if (!active || ['BODY', 'HTML', 'MAIN', 'IFRAME'].includes(active.tagName) || active.closest('[data-native-container]')) document.querySelector(`.b-native-tools [data-action="${action}"]`)?.focus({ preventScroll: true });
  };
  restore(); requestAnimationFrame(restore);
}
function showReady(record, context) {
  if (!sameSelection(context, record) || record.view?.state !== 'ready') return;
  const view = record.view, url = new URL(view.previewUrl, location.origin), expected = `/preview/native/${encodeURIComponent(record.projectId)}/${encodeURIComponent(view.id)}`;
  if (url.origin !== location.origin || !['http:', 'https:'].includes(url.protocol) || url.pathname !== expected || url.search || url.hash || Date.parse(view.expiresAt) <= Date.now()) throw new Error('原生预览地址无效或已过期，请核对原任务。');
  const state = visualState(context.state.resource, context.state.user);
  const focus = typeof document !== 'undefined' && (!document.activeElement || ['BODY', 'HTML', 'MAIN', 'IFRAME'].includes(document.activeElement.tagName) || !!document.activeElement.closest('[data-native-container]'));
  if (typeof document !== 'undefined' && document.querySelector('dialog[open] .conversation-toolbox [data-native-container]')) context.closeModal?.();
  state.nativePreview = { ...view, previewUrl: url.pathname, signature: record.signature }; state.previewMode = 'native'; state.mobileTab = 'preview'; context.render();
  if (focus) restoreControlFocus('design-native-return');
}
function clearClosedPreview(record, context) {
  if (!sameSelection(context, record) || !record.view || record.view.state === 'ready') return;
  const state = visualState(context.state.resource, context.state.user);
  if (state.nativePreview?.id === record.view.id && state.previewMode === 'native') { state.previewMode = 'design'; state.nativePreview = null; context.render(); restoreControlFocus('design-native-render'); }
}
export function stopNativePreviewPolling() { clearTimeout(pollTimer); mountEpoch++; mounted = null; }
export function mountNativePreview(context) {
  clearTimeout(pollTimer);
  const record = recordFor(context.state.resource, context.state.user), epoch = mountEpoch;
  mounted = { context, record, epoch };
  const poll = async () => {
    if (epoch !== mountEpoch || !sameSelection(context, record) || !record.saved?.jobId) return;
    try { await refresh(record); if (epoch !== mountEpoch) return; clearClosedPreview(record, context); update(record, context); }
    catch (error) { if (epoch === mountEpoch) { record.error = error.message; update(record, context); } }
    if (epoch === mountEpoch && (record.view?.state === 'processing' || nativePreview(context.state.resource, context.state.user))) pollTimer = setTimeout(poll, 5000);
  };
  if (record.saved?.jobId) pollTimer = setTimeout(poll, 0);
}
export function changeNativeInput(target, context) {
  if (!target.matches('[data-native-page], [data-design-page]')) return false;
  const state = visualState(context.state.resource, context.state.user); state.nativePage = target.value; state.previewMode = 'design';
  if (target.matches('[data-design-page]')) state.page = target.value;
  context.render();
  if (typeof document !== 'undefined') document.querySelector(target.matches('[data-native-page]') ? '[data-native-page]' : '[data-design-page]')?.focus({ preventScroll: true });
  return true;
}
async function run(record, context) {
  if (record.running) return;
  const runEpoch = ++record.runEpoch, startedMount = mountEpoch; record.running = true; record.error = ''; record.message = ''; update(record, context);
  const active = () => record.runEpoch === runEpoch && mountEpoch === startedMount && sameSelection(context, record);
  try {
    if (record.saved.jobId) await refresh(record);
    else accept(record, await api(`/design/projects/${encodeURIComponent(record.projectId)}/native-preview-jobs`, { method: 'POST', body: { requestKey: record.saved.requestKey, ...record.chosen } }));
    if (!active()) return;
    if (record.view.busy) { record.message = '原步骤正在处理，请稍后更新任务状态。'; return; }
    while (active() && record.view.state === 'processing') {
      const step = record.saved.pendingStep || record.view.completedSteps + 1;
      record.saved.pendingStep = step; persist(record);
      const previous = record.view.completedSteps;
      const next = await api(`${path(record.saved.jobId)}/continue`, { method: 'POST', body: { step } });
      accept(record, next); update(record, context);
      if (record.view.errorCode || record.view.busy || record.view.completedSteps <= previous) { record.message = '本次自动继续已停止，请更新或继续这条原任务。后台仍可能继续准备。'; break; }
    }
    if (active() && record.view.state === 'ready') showReady(record, context);
  } catch (error) {
    record.error = error.message; record.message = '请求结果未完整确认，原请求编号和步骤已保留，请核对原任务。';
    if (record.saved.jobId) { try { await refresh(record); } catch { /* Unknown results never allocate another job. */ } }
  } finally { record.running = false; update(record, context); if (mounted?.record === record && sameSelection(context, record) && record.view?.state === 'processing') mountNativePreview(context); }
}
export async function handleNativeAction(name, _trigger, context) {
  if (!name.startsWith('design-native-')) return false;
  const data = context.state.resource, state = visualState(data, context.state.user), record = recordFor(data, context.state.user);
  if (name === 'design-native-return') { record.runEpoch++; state.previewMode = 'design'; context.render(); restoreControlFocus('design-native-render'); return true; }
  if (name === 'design-native-pause') { record.runEpoch++; record.message = '已暂停浏览器继续。当前请求仍会核对结果，后台可以继续准备；这不是取消任务。'; update(record, context); return true; }
  if (name === 'design-native-cancel') {
    if (!record.saved?.jobId) throw new Error('请先核对原预览请求。');
    record.runEpoch++; accept(record, await api(`${path(record.saved.jobId)}/cancel`, { method: 'POST', body: {} })); record.message = record.view.state === 'cancelled' ? '服务器已确认取消，此预览及临时资源已失效。' : '任务状态已更新，请查看真实结果。'; clearClosedPreview(record, context); update(record, context); return true;
  }
  if (name === 'design-native-refresh' || name === 'design-native-open') {
    if (!record.saved?.jobId) throw new Error('请先准备原生预览。');
    record.error = ''; record.message = ''; await refresh(record); clearClosedPreview(record, context); update(record, context); if (name === 'design-native-open') showReady(record, context); return true;
  }
  if (name !== 'design-native-render') return false;
  if (!record.chosen.pageKey || !record.chosen.versionId && !record.chosen.candidateId) throw new Error('请先选择一个设计版本或候选方案。');
  if (record.running) return true;
  if (record.view?.state === 'ready') { await refresh(record); if (record.view.state === 'ready') showReady(record, context); else { clearClosedPreview(record, context); update(record, context); } return true; }
  if (!record.saved || terminal.has(record.view?.state)) { record.saved = { requestKey: crypto.randomUUID(), ...record.chosen }; record.view = null; persist(record); }
  await run(record, context); return true;
}
