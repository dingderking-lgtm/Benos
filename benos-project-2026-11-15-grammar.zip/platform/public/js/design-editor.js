import { api } from './api.js';
import { designHistory, recordDesignAdoption, restoreDesignVersion } from './design-history.js';
import { icon, escapeHtml as e } from './icons.js';
const sessions = new Map();
let selectionCleanup = () => {};
let selectionSequence = 0;
const numbers = [['fontSize','字号',8,160],['lineHeight','行高',.8,3],['paddingTop','上内边距',0,160],['paddingRight','右内边距',0,160],['paddingBottom','下内边距',0,160],['paddingLeft','左内边距',0,160],['marginTop','上外边距',0,160],['marginRight','右外边距',0,160],['marginBottom','下外边距',0,160],['marginLeft','左外边距',0,160],['gap','元素间距',0,160],['borderRadius','圆角',0,160]];
const baseFields = new Set(['fontFamily','color','backgroundColor','fontSize','lineHeight']);
const btn = (label, action, extra = '', primary = false) => `<button type="button" class="ui-button ui-button--${primary ? 'primary' : 'secondary'}" data-action="design-visual-${action}" ${extra}>${label}</button>`;
const route = data => `design/${encodeURIComponent(data.project.id)}`;
const endpoint = data => `/design/projects/${encodeURIComponent(data.project.id)}`;
const nodeKey = node => `${node.templateId}:${node.nodeKey}`;
const scopeLabel = scope => scope?.kind === 'node' ? `仅所选区块（模板 ${scope.templateId} / ${scope.nodeKey}）` : '全站设计';
function session(data, user) {
  const key = `${user.id}:${data.project.id}`;
  if (!sessions.has(key)) sessions.set(key, { mode:'browse',tab:'ai',mobileTab:'preview',compare:'candidate',scope:'node',selectedKey:'',values:{},current:data.project.current_version_id,device:'desktop',page:'' });
  const state = sessions.get(key), history = designHistory(user.id, data.project.id, data.project.current_version_id);
  if (state.current !== data.project.current_version_id) { state.selectedKey=''; state.values={}; state.current=data.project.current_version_id; }
  state.undo=history.undo; state.redo=history.redo; state.history=history;
  return state;
}
export async function loadEditorView(projectId, kind, sourceId, options) {
  if (!['version','candidate'].includes(kind) || !sourceId) throw new Error('请选择有效的设计来源。');
  const view=await api(`/design/projects/${encodeURIComponent(projectId)}/editor-view?${kind}=${encodeURIComponent(sourceId)}`,options);
  if(view.sourceKind!==kind||view.sourceId!==sourceId||view.projectionVersion!==1||!Array.isArray(view.templates)||!Array.isArray(view.site?.pages))throw new Error('设计摘要不完整，请重新读取原版本。');
  return view;
}
export async function loadVisualResource(project, selected, options, proposal=null) {
  const id=encodeURIComponent(project.id),view=selected?.editorView;
  const templateId=view?.site.pages.find(page=>page.key===view.site.home)?.template_id||view?.templates.find(template=>template.type==='page')?.id;
  const [page,media,candidates]=await Promise.all([
    selected&&templateId ? api(`/design/projects/${id}/editor-nodes?version=${encodeURIComponent(selected.id)}&templateId=${templateId}&limit=100`,options) : Promise.resolve({items:[],nextCursor:null}),
    api(`/media/projects/${id}/assets`,options),api(`/design/projects/${id}/candidates`,options),
  ]);
  if(view&&page.contentHash&&page.contentHash!==view.contentHash)throw new Error('节点来源与当前设计不一致，请刷新。');
  return {nodes:page.items||[],fonts:view?.styleOptions?.fonts||[],assets:media.items||[],candidates:candidates.items||[],proposal,nodeTemplateId:templateId,nodePages:templateId?{[templateId]:{nextCursor:page.nextCursor,loaded:true}}:{}};
}
export function visualState(data,user) { return session(data,user); }
// Both inputs are small editor projections. Legacy inline fixtures remain readable.
export function visualManifest(data,user) { const source=data.visual?.proposal&&session(data,user).compare!=='original'?data.visual.proposal:data.selected;return source?.editorView||source?.manifest; }
export async function queryVisualNodes(context,templateId,{nodeKey:exactKey,cursor}={}) {
  const data=context.state.resource,selected=data.selected,view=selected?.editorView;
  if(!view||!view.templates.some(template=>template.id===Number(templateId)))throw new Error('此模板不属于当前设计版本。');
  const params=new URLSearchParams({version:selected.id,templateId:String(templateId),limit:'100'});if(exactKey)params.set('nodeKey',exactKey);else if(cursor)params.set('cursor',cursor);
  const page=await api(`${endpoint(data)}/editor-nodes?${params}`);
  if(context.state.resource!==data||data.selected?.id!==selected.id)return null;
  if(page.sourceId!==selected.id||page.contentHash!==view.contentHash||page.templateId!==Number(templateId))throw new Error('节点来源已变化，请刷新当前版本。');
  const incoming=page.items||[],existing=new Map(data.visual.nodes.map(node=>[nodeKey(node),node]));for(const node of incoming)existing.set(nodeKey(node),node);data.visual.nodes=[...existing.values()];
  if(!exactKey)data.visual.nodePages[templateId]={loaded:true,nextCursor:page.nextCursor};
  return page;
}
export function visualPreviewUrl(data,user,page) {
  const state=session(data,user),proposal=data.visual?.proposal;
  const path=proposal && state.compare!=='original' ? `/preview/${encodeURIComponent(data.project.id)}/candidate/${encodeURIComponent(proposal.id)}` : data.selected ? `/preview/${encodeURIComponent(data.project.id)}/${encodeURIComponent(data.selected.id)}` : '';
  return path ? `${path}?page=${encodeURIComponent(page||'')}&editor=1` : '';
}
export function renderVisualToolbar(data,user) {
  const state=session(data,user),enabled=!!data.selected&&data.selected.id===data.project.current_version_id&&!data.visual.proposal;
  return `<div class="b-visual-toolbar" role="group" aria-label="设计编辑方式">${btn(icon('monitor')+'浏览','mode',`data-mode="browse" aria-pressed="${state.mode!=='select'}"`)}${btn(icon('pen-tool')+'选择区块','mode',`data-mode="select" aria-pressed="${state.mode==='select'}" ${enabled?'':'disabled'}`)}${btn(icon('undo-2')+'撤销采用','undo',enabled&&(state.history.pending?.action==='undo'||state.undo.length&&!state.history.pending)?'':'disabled')}${btn(icon('arrow-right')+'重做采用','redo',enabled&&(state.history.pending?.action==='redo'||state.redo.length&&!state.history.pending)?'':'disabled')}</div>`;
}
export function renderVisualPanel(data,user) {
  const state=session(data,user),visual=data.visual,proposal=visual.proposal;
  if (proposal) {
    const draft=proposal.state==='draft',changed=proposal.baseVersionId!==data.project.current_version_id;
    return `<section class="b-visual-panel"><h2>预览修改方案</h2><p class="b-muted">${e(scopeLabel(proposal.scope))} · ${draft?'尚未采用':proposal.state==='adopted'?'已经采用':'已经放弃'}</p><p class="b-muted">采用后保存为新版本；线上网站需另行发布才会更新。</p><div class="b-visual-compare" role="group" aria-label="对比修改">${btn('修改前','compare',`data-view="original" aria-pressed="${state.compare==='original'}" ${data.selected?'':'disabled'}`)}${btn('修改方案','compare',`data-view="candidate" aria-pressed="${state.compare!=='original'}"`)}</div>${changed&&draft?'<p class="b-notice-text">当前设计已更新，此方案仍可对照，但不能覆盖较新的版本。</p>':''}<p class="b-form-error" data-visual-error role="alert" hidden></p><div class="b-table-actions">${draft?btn('放弃修改','discard')+btn('采用此方案','adopt',changed?'disabled':'',true):btn('返回当前设计','return')}</div></section>`;
  }
  const selection=visual.nodes.find(node=>nodeKey(node)===state.selectedKey),templates=data.selected?.editorView?.templates||[],activeTemplate=visual.nodeTemplateId,visibleNodes=visual.nodes.filter(node=>!activeTemplate||node.templateId===activeTemplate),editable=data.selected&&data.selected.id===data.project.current_version_id;
  if (!editable) return `<section class="b-visual-panel"><h2>调整设计</h2><p class="b-muted">${data.selected?'历史版本只供预览；先恢复为当前版本再进行修改。':'可以从模板库起步，或通过 AI 创建首个设计方案。'}</p>${btn('浏览模板库','library',data.selected?'disabled':'')}${candidateList(data)}</section>`;
  return `<section class="b-visual-panel"><h2>调整设计</h2>${state.history.pending?'<p class="b-notice-text">上次恢复结果待核对，继续原操作会使用原请求编号。</p>':''}${templates.length?`<label class="b-field"><span>选择模板区域</span><select data-visual-template>${templates.map(template=>`<option value="${template.id}" ${template.id===activeTemplate?'selected':''}>${e(template.name)} · ${e(template.type)}</option>`).join('')}</select></label>`:''}<label class="b-field"><span>当前区块</span><select data-visual-node><option value="">请选择区块</option>${visibleNodes.map(node=>`<option value="${e(nodeKey(node))}" ${selection===node?'selected':''}>${e(node.tag)} · ${e(node.label)}${node.protected?'（动态绑定）':''}</option>`).join('')}</select></label>${visual.nodePages?.[activeTemplate]?.nextCursor?btn('加载更多区块','nodes-more',state.loadingNodes?'disabled':''):''}${state.loadingNode?'<p class="b-field-hint" role="status">正在读取所选区块…</p>':''}<p class="b-field-hint">在选择模式中点击预览，或用列表选择。只提交填写的样式字段，其他属性保持原样。</p>${selection?renderFields(data,state,selection):'<div class="b-inline-empty">选择一个区块后，可调整文字、颜色、间距或图片。</div>'}${candidateList(data)}</section>`;
}
function candidateList(data) {
  const items=data.visual.candidates;
  return items.length?`<details class="b-visual-drafts"><summary>待采用方案（${items.length}）</summary>${items.map(item=>`<a href="#${route(data)}?${item.baseVersionId?`version=${encodeURIComponent(item.baseVersionId)}&`:''}candidate=${encodeURIComponent(item.id)}">${e(scopeLabel(item.scope))} · ${e(new Date(item.createdAt).toLocaleString('zh-CN'))}</a>`).join('')}</details>`:'';
}
function renderFields(data,state,node) {
  const val=name=>e(state.values[name]||''),whole=state.scope==='site';
  return `<form data-form="design-visual-patch"><label class="b-field"><span>修改范围</span><select name="scope" data-visual-scope><option value="node" ${whole?'':'selected'}>仅当前区块</option><option value="site" ${whole?'selected':''}>全站基础排版</option></select><small class="b-field-hint">${whole?'作用于全站基础字体、字号、行高和配色；区块单独设置的样式可能优先。':'只修改所选节点，保留其他区域与 CMS 动态绑定。'}</small></label><label class="b-field"><span>字体</span><select name="fontFamily"><option value="">保持原字体</option>${data.visual.fonts.map(font=>`<option value="${e(font.value)}" ${state.values.fontFamily===font.value?'selected':''}>${e(font.label)}</option>`).join('')}</select></label><div class="b-visual-fields">${[['color','文字颜色'],['backgroundColor','背景颜色']].map(([key,label])=>`<label class="b-field"><span>${label}</span><span class="b-visual-color"><input type="color" data-visual-picker="${key}" value="${/^#[0-9a-f]{6}$/i.test(state.values[key]||'')?val(key):'#262626'}" aria-label="${label}选择器"><input name="${key}" value="${val(key)}" placeholder="保持原样" pattern="#[0-9a-fA-F]{6}" maxlength="7" aria-label="${label}色值"></span></label>`).join('')}${numbers.filter(([name])=>!whole||baseFields.has(name)).map(([name,label,min,max])=>`<label class="b-field"><span>${label}${name==='lineHeight'?'（倍）':'（px）'}</span><input type="number" name="${name}" value="${val(name)}" min="${min}" max="${max}" step="${name==='lineHeight'?'.05':'1'}" placeholder="${e(state.computed?.[name]||'保持原样')}"></label>`).join('')}</div>${whole?'<label class="b-checkbox"><input type="checkbox" name="confirmSite" required>确认将这些基础样式用于全站</label>':''}<p class="b-form-error" data-form-error role="alert" hidden></p><div class="b-form-actions"><button type="submit" class="ui-button ui-button--primary">预览样式修改</button></div></form>${node.canReplaceImage&&!whole?renderImageForm(data):''}<p class="b-field-hint">${node.protected?'此区块带有 CMS 动态绑定，数据字段和链接由服务端保护。':'样式修改不改写文章、表单数据或导航链接。'}</p>`;
}
function renderImageForm(data) {
  const assets=data.visual.assets.filter(asset=>asset.state==='ready'&&!asset.deletedAt&&['image/png','image/jpeg','image/webp','image/gif','image/svg+xml'].includes(asset.mimeType));
  return `<details class="b-visual-image"><summary>替换当前图片</summary><form data-form="design-visual-image"><div class="b-visual-asset-grid">${assets.map(asset=>`<label class="b-visual-asset"><input type="radio" name="assetPath" value="${e(asset.assetPath)}" required><img src="${e(asset.contentUrl)}" alt="" loading="lazy"><span>${e(asset.fileName)}</span></label>`).join('')||`<p class="b-muted">请先到<a href="#media/${encodeURIComponent(data.project.id)}">项目素材</a>上传图片。</p>`}</div><label class="b-field"><span>图片说明</span><input name="alt" maxlength="300" placeholder="描述图片内容，便于无障碍阅读"></label><p class="b-field-hint">仅可选择 PNG、JPEG、WebP、GIF 或 SVG 图片，PDF 不作为图片替换。保持原布局和图片比例规则；模板发布素材合计上限 64 MiB。</p><p class="b-form-error" data-form-error role="alert" hidden></p><button class="ui-button ui-button--primary" type="submit" ${assets.length?'':'disabled'}>预览图片替换</button></form></details>`;
}
function refreshPanel(context) {
  const data=context.state.resource,state=session(data,context.state.user);
  const panel=document.querySelector('[data-visual-panel]');if(panel)panel.innerHTML=renderVisualPanel(data,context.state.user);
  const toolbar=document.querySelector('[data-visual-toolbar]');if(toolbar)toolbar.innerHTML=renderVisualToolbar(data,context.state.user);
  const shell=document.querySelector('.b-design-shell');if(shell){shell.dataset.designTab=state.tab;shell.dataset.mobileTab=state.mobileTab;}
  document.querySelectorAll('button[data-design-tab]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.designTab===state.tab)));
  document.querySelectorAll('button[data-mobile-tab]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.mobileTab===state.mobileTab)));
  document.querySelector('.b-design-canvas iframe')?.dispatchEvent(new Event('benos:selection-mode'));
  document.querySelector('[data-form="design-conversation-message"]')?.dispatchEvent(new CustomEvent('benos:selection-changed'));
}
export function stopVisualEditor(){selectionSequence++;selectionCleanup();selectionCleanup=()=>{};}
export function mountVisualEditor(context){
  stopVisualEditor();const data=context.state.resource,state=session(data,context.state.user),frame=document.querySelector('.b-design-canvas iframe');if(!frame)return;
  selectionCleanup=bindVisualSelection(frame,{isCurrent:()=>context.state.resource===data&&!data.visual.proposal&&data.selected?.id===data.project.current_version_id,mode:()=>state.mode,allowed:(key,tid)=>/^n\d+$/.test(key)&&!!data.selected?.editorView?.templates.some(template=>String(template.id)===tid),onSelect:(key,tid,element)=>{
    const sequence=++selectionSequence;state.loadingNode=true;refreshPanel(context);
    (async()=>{try{const page=await queryVisualNodes(context,Number(tid),{nodeKey:key});if(sequence!==selectionSequence||context.state.resource!==data||!page)return;const node=page.items.find(item=>item.nodeKey===key);if(!node)throw new Error('所选节点已不存在，请重新选择。');data.visual.nodeTemplateId=node.templateId;state.selectedKey=nodeKey(node);state.values={};state.computed=readComputed(element);state.tab='visual';state.mobileTab='visual';}catch(error){if(sequence===selectionSequence)context.notify(error.message);}finally{if(sequence===selectionSequence&&context.state.resource===data){state.loadingNode=false;refreshPanel(context);}}})();
  }});
}
function readComputed(element){const style=element?.ownerDocument.defaultView.getComputedStyle(element),result={};if(!style)return result;for(const[name]of numbers){const n=parseFloat(style[name]);if(Number.isFinite(n))result[name]=name==='lineHeight'?String(Math.round(n/parseFloat(style.fontSize)*100)/100):String(Math.round(n*100)/100);}return result;}
export function rememberVisualInput(input,context){
  if(!input.closest('[data-form="design-visual-patch"]'))return;const state=session(context.state.resource,context.state.user);
  if(input.dataset.visualPicker){input.form.elements.namedItem(input.dataset.visualPicker).value=input.value;state.values[input.dataset.visualPicker]=input.value;}
  else if(input.name&&input.name!=='scope'){state.values[input.name]=input.value;if(['color','backgroundColor'].includes(input.name)&&/^#[0-9a-f]{6}$/i.test(input.value))input.form.querySelector(`[data-visual-picker="${input.name}"]`).value=input.value;}
}
export function changeVisualInput(target,context){const state=session(context.state.resource,context.state.user);if(target.matches('[data-visual-template]')){const data=context.state.resource,templateId=Number(target.value);data.visual.nodeTemplateId=templateId;state.selectedKey='';state.values={};state.loadingNodes=true;refreshPanel(context);queryVisualNodes(context,templateId).then(()=>{if(context.state.resource===data)refreshPanel(context);}).catch(error=>context.notify(error.message)).finally(()=>{state.loadingNodes=false;if(context.state.resource===data)refreshPanel(context);});return true;}if(target.matches('[data-visual-node]')){state.selectedKey=target.value;state.values={};state.computed={};refreshPanel(context);return true;}if(target.matches('[data-visual-scope]')){state.scope=target.value;refreshPanel(context);return true;}if(target.matches('[data-design-page]'))state.page=target.value;rememberVisualInput(target,context);return false;}
export async function handleVisualAction(name,trigger,context){
  if(!name.startsWith('design-visual-'))return false;const data=context.state.resource,state=session(data,context.state.user),action=name.slice('design-visual-'.length);
  if(action==='nodes-more'){const templateId=data.visual.nodeTemplateId,cursor=data.visual.nodePages[templateId]?.nextCursor;if(cursor){state.loadingNodes=true;try{await queryVisualNodes(context,templateId,{cursor});}finally{state.loadingNodes=false;if(context.state.resource===data)refreshPanel(context);}}return true;}
  if(action==='tab'){if(trigger.dataset.mobileTab){state.mobileTab=trigger.dataset.mobileTab;if(state.mobileTab!=='preview')state.tab=state.mobileTab;}else{state.tab=trigger.dataset.designTab;state.mobileTab=state.tab;}refreshPanel(context);return true;}
  if(action==='mode'){state.previewMode='design';state.mode=trigger.dataset.mode;if(state.mode==='select')state.tab='visual';refreshPanel(context);return true;}
  if(action==='compare'){state.previewMode='design';state.compare=trigger.dataset.view;context.render();return true;}
  if(action==='return'){context.navigate(route(data));return true;}
  if(action==='library'){
    const{items}=await api('/design/templates');context.showModal(`<div class="b-modal-header"><div><h2 id="modal-title">选择起步模板</h2><p>先查看方案，再确认采用。起步模板仅用于尚无设计版本的项目。</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></div><div class="b-modal-body b-template-library">${items.length?items.map(template=>`<article class="b-template-choice"><div class="b-template-snapshot"><iframe src="${e(template.previewUrl)}" title="${e(template.name)}模板预览" sandbox="allow-same-origin" loading="lazy" tabindex="-1" inert></iframe></div><h3>${e(template.name)}</h3><p>${e(template.description)}</p><small>${e(template.style)} · ${Array.isArray(template.pages)?template.pages.length:e(template.pages)} 个页面</small>${btn('预览此方案','template',`data-template-id="${e(template.id)}" ${data.project.current_version_id?'disabled':''}`,true)}</article>`).join(''):'<p class="b-muted">模板库暂时没有可用模板。</p>'}</div>`);return true;
  }
  if(action==='template'){const requestKey=trigger.dataset.requestKey||=crypto.randomUUID();const proposal=await api(`${endpoint(data)}/templates/${encodeURIComponent(trigger.dataset.templateId)}`,{method:'POST',body:{requestKey,baseVersionId:data.project.current_version_id||null}});state.compare='candidate';state.tab='visual';state.mobileTab='preview';context.closeModal();context.navigate(`${route(data)}?candidate=${encodeURIComponent(proposal.id)}`);return true;}
  if(action==='adopt'){const proposal=data.visual.proposal,result=await api(`${endpoint(data)}/candidates/${encodeURIComponent(proposal.id)}/adopt`,{method:'POST',body:{}});recordDesignAdoption(context.state.user.id,data.project.id,data.selected?.id||null,result.versionId);state.current=result.versionId;state.selectedKey='';state.values={};state.compare='candidate';context.navigate(`${route(data)}?version=${encodeURIComponent(result.versionId)}`);context.notify('方案已采用并保存为新版本；发布后才会更新线上网站');return true;}
  if(action==='discard'){await api(`${endpoint(data)}/candidates/${encodeURIComponent(data.visual.proposal.id)}/discard`,{method:'POST',body:{}});context.navigate(route(data));context.notify('本次方案已放弃，当前版本保持不变');return true;}
  if(action==='undo'||action==='redo'){const result=await restoreDesignVersion(context.state.user.id,data.project.id,data.project.current_version_id,action);state.current=result.currentVersionId;state.selectedKey='';state.values={};context.navigate(`${route(data)}${result.currentVersionId?`?version=${encodeURIComponent(result.currentVersionId)}`:''}`);context.notify(result.superseded?'原恢复操作已完成，项目已有更新的版本，当前设计未被回退':action==='undo'?'已恢复采用前的设计，历史版本保留':'已恢复刚才的方案，历史版本保留');return true;}
  return false;
}
export async function submitVisualForm(name,form,values,context){
  if(!['design-visual-patch','design-visual-image'].includes(name))return false;
  const data=context.state.resource,state=session(data,context.state.user),node=data.visual.nodes.find(item=>nodeKey(item)===state.selectedKey);
  if(!node||data.selected?.id!==data.project.current_version_id)throw new Error('请选择当前版本中的区块。');
  const scope=name==='design-visual-patch'&&values.scope==='site'?{kind:'site'}:{kind:'node',templateId:node.templateId,nodeKey:node.nodeKey};let operation;
  if(name==='design-visual-image'){const asset=data.visual.assets.find(asset=>asset.assetPath===values.assetPath&&asset.state==='ready'&&!asset.deletedAt&&['image/png','image/jpeg','image/webp','image/gif','image/svg+xml'].includes(asset.mimeType));if(!asset)throw new Error('请选择当前项目中可用的图片素材，PDF 不能替换图片。');operation={kind:'image',assetPath:asset.assetPath,alt:values.alt.trim()};}
  else{if(scope.kind==='site'&&values.confirmSite!=='on')throw new Error('请确认全站基础样式的影响范围。');const properties={};for(const key of ['fontFamily','color','backgroundColor',...numbers.map(([key])=>key)])if(values[key]?.trim()&&(scope.kind!=='site'||baseFields.has(key)))properties[key]=numbers.some(([name])=>name===key)?Number(values[key]):values[key].trim();if(!Object.keys(properties).length)throw new Error('请填写至少一项要修改的样式。');operation={kind:'style',properties};}
  const payload={baseVersionId:data.selected.id,scope,operation},fingerprint=JSON.stringify(payload);if(form.dataset.fingerprint!==fingerprint){form.dataset.fingerprint=fingerprint;form.dataset.requestKey=crypto.randomUUID();}
  const proposal=await api(`${endpoint(data)}/candidates`,{method:'POST',body:{...payload,requestKey:form.dataset.requestKey}});state.compare='candidate';state.mobileTab='preview';
  context.navigate(`${route(data)}?version=${encodeURIComponent(data.selected.id)}&candidate=${encodeURIComponent(proposal.id)}`);context.notify('修改方案已准备，请对比后采用');return true;
}
// Pointer events stay in the trusted parent. Safari blocks callbacks attached to a
// script-disabled iframe document, so selection never relies on child script rights.
export function visualFramePoint(rect,viewport,clientX,clientY){
  if(!rect.width||!rect.height||clientX<rect.left||clientY<rect.top||clientX>rect.left+rect.width||clientY>rect.top+rect.height)return null;
  return {x:(clientX-rect.left)*viewport.width/rect.width,y:(clientY-rect.top)*viewport.height/rect.height};
}
export function bindVisualSelection(frame,options){
  const parent=frame.parentElement,layer=frame.ownerDocument.createElement('div');layer.className='b-design-selection-layer';layer.setAttribute('aria-hidden','true');
  let outlined,previousOutline,previousOffset,drag=null,suppressClick=false,attached=false,layoutFrame=0;
  const clear=()=>{if(outlined){outlined.style.outline=previousOutline;outlined.style.outlineOffset=previousOffset;outlined=null;}};
  const update=()=>{if(!options.isCurrent()||options.mode()!=='select'){detach();return;}if(!attached){parent.append(layer);for(const[type,handler,config]of events)layer.addEventListener(type,handler,config);attached=true;}for(const[key,value]of Object.entries({left:frame.offsetLeft+'px',top:frame.offsetTop+'px',width:frame.offsetWidth+'px',height:frame.offsetHeight+'px'}))if(layer.style[key]!==value)layer.style[key]=value;};const schedule=()=>{if(!layoutFrame)layoutFrame=requestAnimationFrame(()=>{layoutFrame=0;update();});};
  const select=event=>{if(suppressClick){suppressClick=false;return;}if(options.mode()!=='select'||!options.isCurrent())return;event.preventDefault();event.stopPropagation();let doc,win;try{doc=frame.contentDocument;win=frame.contentWindow;}catch{return;}if(!doc||!win)return;const point=visualFramePoint(frame.getBoundingClientRect(),{width:win.innerWidth,height:win.innerHeight},event.clientX,event.clientY);if(!point)return;const target=doc.elementFromPoint(point.x,point.y)?.closest?.('[data-benos-node][data-benos-template]');if(!target||!doc.documentElement.contains(target))return;const key=target.getAttribute('data-benos-node'),tid=target.getAttribute('data-benos-template');if(!options.allowed(key,tid))return;clear();outlined=target;previousOutline=target.style.outline;previousOffset=target.style.outlineOffset;target.style.outline='2px solid #727272';target.style.outlineOffset='-2px';options.onSelect(key,tid,target);};
  const scroll=(dx,dy)=>{try{const rect=frame.getBoundingClientRect(),win=frame.contentWindow;if(win&&rect.width&&rect.height)win.scrollBy(dx*win.innerWidth/rect.width,dy*win.innerHeight/rect.height);}catch{}};
  const wheel=event=>{event.preventDefault();const scale=event.deltaMode===1?16:event.deltaMode===2?frame.clientHeight:1;scroll(event.deltaX*scale,event.deltaY*scale);};
  const down=event=>{suppressClick=false;if(event.pointerType==='mouse')return;drag={x:event.clientX,y:event.clientY,startX:event.clientX,startY:event.clientY,moved:false};layer.setPointerCapture(event.pointerId);};
  const move=event=>{if(!drag)return;if(Math.abs(event.clientX-drag.startX)+Math.abs(event.clientY-drag.startY)>6)drag.moved=true;if(drag.moved){scroll(drag.x-event.clientX,drag.y-event.clientY);suppressClick=true;}drag.x=event.clientX;drag.y=event.clientY;};
  const up=()=>{drag=null;},cancel=()=>{drag=null;suppressClick=true;};
  const events=[['click',select],['wheel',wheel,{passive:false}],['pointerdown',down],['pointermove',move],['pointerup',up],['pointercancel',cancel]];
  const detach=()=>{if(attached){for(const[type,handler,config]of events)layer.removeEventListener(type,handler,config);layer.remove();attached=false;}drag=null;clear();};
  frame.addEventListener('load',schedule);frame.addEventListener('benos:selection-mode',update);const observer=new ResizeObserver(schedule);observer.observe(frame);update();
  return()=>{observer.disconnect();cancelAnimationFrame(layoutFrame);frame.removeEventListener('load',schedule);frame.removeEventListener('benos:selection-mode',update);detach();};
}
