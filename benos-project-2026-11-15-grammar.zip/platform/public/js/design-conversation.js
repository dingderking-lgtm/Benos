import { api } from './api.js';
import { escapeHtml as esc, icon } from './icons.js';
import { renderVisualPanel, renderVisualToolbar, visualManifest, visualPreviewUrl, visualState } from './design-editor.js';
import { nativePreview, renderNativeNotice, renderNativeTools } from './design-native.js';
import { renderDesignConversation } from './design-conversation-view.js';
import { renderConversationHistory, renderConversationComposer, isConversationStarted, conversationBrief } from './design-workflow.js';

const previewChoices = new Map();
const choiceKey = (data,user) => 'benos-design-preview-open:' + user.id + ':' + data.project.id;
function previewChoice(data,user) {
  const key=choiceKey(data,user);
  if(previewChoices.has(key))return previewChoices.get(key);
  let open=true;
  try { open=localStorage.getItem(key)!=='false'; } catch { /* A session can use in-memory preferences. */ }
  previewChoices.set(key,open);
  return open;
}
function singlePane(shell) {
  const tabs=shell.querySelector('.d-mobile-tabs');
  return tabs && getComputedStyle(tabs).display!=='none';
}

export function syncPreviewLayout(context,shell=document.querySelector('.d-conversation')) {
  if(!shell)return;
  const {resource:data,user}=context.state;
  const open=previewChoice(data,user),tabbed=singlePane(shell);
  shell.dataset.previewOpen=String(open);
  const visible=open && (!tabbed || shell.dataset.mobileTab==='preview');
  const panel=shell.querySelector('#designer-site-preview');
  if(panel){panel.inert=!visible;panel.setAttribute('aria-hidden',String(!visible));}
  for(const button of shell.querySelectorAll('[data-action="design-conversation-toggle-preview"]')){
    const label=visible?'收起预览':'打开预览';
    button.setAttribute('aria-expanded',String(visible));
    button.setAttribute('aria-label',label);
    button.title=label;
    const text=button.querySelector('[data-preview-toggle-label]');
    if(text && text.textContent!==label)text.textContent=label;
  }
}

// Layout changes rewrap chat text. Preserve the visible message rather than a
// stale pixel offset, unless the reader scrolls during the short transition.
function retainReadingPosition(shell) {
  const log=shell.querySelector('.d-chat-scroll');
  if(!log?.clientHeight || !log.scrollTop)return;
  const top=log.getBoundingClientRect().top,atEnd=log.scrollHeight-log.clientHeight-log.scrollTop<4;
  const anchor=[...log.querySelectorAll('.d-message,[data-project-design-status],.d-brief,.d-suggestion')]
    .find(node=>node.getBoundingClientRect().bottom>top);
  const offset=anchor?.getBoundingClientRect().top-top;
  const controller=new AbortController();
  const cancel=()=>controller.abort();
  for(const event of ['wheel','touchstart','pointerdown','keydown'])log.addEventListener(event,cancel,{signal:controller.signal,passive:true});
  setTimeout(()=>{
    if(controller.signal.aborted || !log.isConnected)return;
    controller.abort();
    if(!log.clientHeight)return;
    if(atEnd)log.scrollTop=log.scrollHeight;
    else if(anchor?.isConnected)log.scrollTop+=anchor.getBoundingClientRect().top-log.getBoundingClientRect().top-offset;
  },200);
}
function choosePreview(context,trigger,open) {
  const shell=trigger.closest('.d-conversation');
  if(!shell)return;
  const {resource:data,user}=context.state,editor=visualState(data,user),key=choiceKey(data,user);
  retainReadingPosition(shell);
  const tabbed=singlePane(shell);
  previewChoices.set(key,open);
  try { localStorage.setItem(key,String(open)); } catch { /* The in-memory choice remains effective. */ }
  if(tabbed){
    editor.mobileTab=open?'preview':(trigger.dataset.mobileTab==='ai'?'ai':editor.tab);
    if(!open && editor.mobileTab==='ai')editor.tab='ai';
  }else if(!open && editor.mobileTab==='preview')editor.mobileTab=editor.tab;
  shell.dataset.mobileTab=editor.mobileTab;
  shell.dataset.designTab=editor.tab;
  for(const button of shell.querySelectorAll('[data-mobile-tab]'))button.setAttribute('aria-pressed',String(button.dataset.mobileTab===editor.mobileTab));
  syncPreviewLayout(context,shell);
  if(tabbed && open && trigger.matches('[data-action="design-conversation-toggle-preview"]')){
    shell.querySelector('.d-mobile-tabs [data-mobile-tab="preview"]')?.focus({preventScroll:true});
  }else if(!open && shell.querySelector('#designer-site-preview')?.contains(document.activeElement)){
    trigger.focus({preventScroll:true});
  }
}

function renderCanvas(project, device, url, native) {
  let contents;
  if (url) {
    contents = `<iframe title="${esc(project.name)}网站预览" src="${esc(url)}" sandbox="${native ? 'allow-scripts' : 'allow-same-origin'}" referrerpolicy="no-referrer"></iframe>`;
  } else {
    contents = `<div class="b-design-placeholder"><img src="/assets/brand/benos-logo.svg" alt="" width="44" height="44"><h2>还没有网站预览</h2><p>生成首个设计方案，或选择一个起步模板。</p><div class="conversation-tool-items">${tool('开始 AI 对话', 'design-conversation-chat')}${tool('浏览模板', 'design-visual-library')}</div></div>`;
  }
  return `<div class="b-design-canvas" data-device="${device}">${contents}</div>`;
}

export function renderProjectConversation(data, user) {
  const { selected, project } = data;
  const editor = visualState(data, user);
  const proposal = data.visual.proposal;
  if (proposal?.id !== editor.openCandidateId) {
    editor.openCandidateId = proposal?.id;
    editor.tab = proposal ? 'visual' : 'ai';
    editor.mobileTab = proposal && data.reviewRequested ? 'visual' : 'preview';
  }
  const previewOpen=previewChoice(data,user);
  if(!previewOpen && editor.mobileTab==='preview')editor.mobileTab=editor.tab;
  const manifest = visualManifest(data, user);
  const pages = manifest?.site?.pages || [];
  const pageKey = pages.some(page => page.key === editor.page) ? editor.page : manifest?.site?.home || pages[0]?.key;
  const native = nativePreview(data, user);
  const draft = initialDraft(data);
  const reviewHref = draft ? `#design/${encodeURIComponent(project.id)}?candidate=${encodeURIComponent(draft.id)}&review=1` : '';
  const draftUrl = draft ? `/preview/${encodeURIComponent(project.id)}/candidate/${encodeURIComponent(draft.id)}` : '';
  const url = native?.previewUrl || visualPreviewUrl(data, user, pageKey) || draftUrl;
  const current = !!selected && selected.id === project.current_version_id;
  let statusLabel = '草稿';
  if (draft) statusLabel = '待采用方案';
  else if (proposal) statusLabel = ({ draft: '待采用方案', adopted: '已采用方案', discarded: '已放弃方案' })[proposal.state] || '历史方案';
  else if (selected && !current) statusLabel = '历史版本';
  else if (current && project.published_version_id === selected.id) statusLabel = '已发布版本';
  const saveLabel = selected ? `已保存 · 版本 ${selected.version}` : '项目已创建';
  const footerLabel = native ? 'CMS 原生预览' : proposal ? (editor.compare === 'original' ? '正在对照原版本' : '正在预览设计方案') : url ? '预览与所选版本同步' : '等待首个设计方案';
  const canUndo = current && !proposal && (editor.history.pending?.action === 'undo' || (!editor.history.pending && editor.undo.length > 0));
  return renderDesignConversation({
    project, brief:conversationBrief(data,user), saveLabel, statusLabel, previewOpen, conversationStarted:isConversationStarted(data,user),
    historyHtml: renderConversationHistory(data, user),
    composerHtml: renderConversationComposer(data, user),
    canvasHtml: renderCanvas(project, editor.device, url, native),
    panelHtml: renderVisualPanel(data, user),
    previewControlsHtml: native ? renderNativeNotice(data, user) : '',
    previewLabel: draft ? '最近的待采用方案 · 采用后可继续修改此版本' : footerLabel,
    reviewHref,
    device: editor.device, tab: editor.tab, mobileTab: editor.mobileTab,
    canUndo, hasPreview: !!url, candidate: !!proposal,
  });
}

function initialDraft(data) {
  if (data.project.current_version_id || data.selected || data.visual.proposal) return null;
  // The authenticated project endpoint returns drafts newest first.
  return data.visual.candidates.find(candidate => candidate.state === 'draft' && candidate.baseVersionId === null);
}

function tool(label, action, disabled = false) {
  return `<button type="button" class="ui-button ui-button--secondary" data-action="${action}"${disabled ? ' disabled' : ''}>${label}</button>`;
}

function toolGroup(title, items) {
  return `<section class="conversation-tool-group"><h3>${title}</h3><div class="conversation-tool-items">${items}</div></section>`;
}

function dialog(title, content) {
  return `<header class="b-modal-header"><h2 id="modal-title">${title}</h2><button type="button" class="ui-icon-button" data-action="close-modal" aria-label="关闭">${icon('x')}</button></header><div class="b-modal-body conversation-toolbox">${content}</div>`;
}

function versionOptions(data) {
  return data.versions.map(version => {
    const label = `版本 ${esc(version.version)}${version.id === data.project.current_version_id ? ' · 当前' : ''}`;
    return `<option value="${esc(version.id)}"${data.selected?.id === version.id ? ' selected' : ''}>${label}</option>`;
  }).join('');
}

function showTools(context) {
  const { resource: data, user } = context.state;
  const { project, selected } = data;
  const state = visualState(data, user);
  const manifest = visualManifest(data, user);
  const pages = manifest?.site?.pages || [];
  const pageKey = state.page || manifest?.site?.home || pages[0]?.key;
  const pageOptions = pages.map(page => `<option value="${esc(page.key)}"${page.key === pageKey ? ' selected' : ''}>${esc(page.title || page.name || page.key)}</option>`).join('');
  const versions = data.versions.length ? `<label class="b-field"><span>设计版本</span><select data-design-version>${versionOptions(data)}</select></label>` : '';
  const pageSelect = pages.length ? `<label class="b-field"><span>预览页面</span><select data-design-page>${pageOptions}</select></label>` : '';
  const media = `<a href="#media/${encodeURIComponent(project.id)}" class="ui-button ui-button--secondary">项目素材</a>`;
  const inputs = [media, tool('模板库', 'design-visual-library'), tool('导入模板', 'design-import')];
  if (selected) inputs.push(tool('导出模板', 'design-export'), tool('编辑模板数据', 'design-edit'));
  const hasHistoricalVersion = selected && selected.id !== project.current_version_id;
  const versionTools = hasHistoricalVersion ? tool('恢复此历史版本', 'design-restore') : '';
  const groups = [toolGroup('项目', inputs.join(''))];
  const records = [tool('设计任务记录', 'design-conversation-task-records')];
  if (data.jobs?.length) records.push(tool('早期生成记录', 'design-legacy-records'));
  groups.push(toolGroup('记录', records.join('')));
  if (versions || pageSelect) groups.push(toolGroup('版本与页面', versions + pageSelect + versionTools));
  groups.push(toolGroup('调整设计', tool(data.visual.proposal ? '审阅当前方案' : '打开样式面板', 'design-conversation-visual') + `<div data-visual-toolbar>${renderVisualToolbar(data, user)}</div>`));
  if (manifest) groups.push(toolGroup('CMS 原生预览', renderNativeTools(data, user)));
  context.showModal(dialog('设计工具', groups.join('')));
}

export async function handleConversationTool(name, trigger, context) {
  const { resource: data, user } = context.state;
  if(name==='design-conversation-toggle-preview'){
    const shell=trigger.closest('.d-conversation');
    choosePreview(context,trigger,!previewChoice(data,user) || (singlePane(shell) && shell.dataset.mobileTab!=='preview'));
    return true;
  }
  if(name==='design-visual-tab' && trigger.closest?.('.d-mobile-tabs') && ['ai','preview'].includes(trigger.dataset.mobileTab)){
    choosePreview(context,trigger,trigger.dataset.mobileTab==='preview');
    return true;
  }
  if (name === 'design-conversation-tools') {
    showTools(context);
    return true;
  }
  if (name === 'design-conversation-visual' || name === 'design-conversation-chat') {
    const state = visualState(data, user);
    state.tab = name === 'design-conversation-visual' ? 'visual' : 'ai';
    state.mobileTab = state.tab;
    context.closeModal();
    context.render();
    if (state.tab === 'ai') document.querySelector('.d-compose textarea')?.focus();
    return true;
  }
  if (name === 'design-conversation-publish') {
    if (data.visual.proposal || !data.project.current_version_id || data.selected?.id !== data.project.current_version_id) {
      let action = tool('选择起步模板', 'design-visual-library');
      let explanation = '先生成并采用第一个网站方案，即可选择托管站点发布。';
      const draft = initialDraft(data);
      if (draft) {
        explanation = '采用当前预览中的方案后，即可选择托管站点发布。';
        action = `<a class="ui-button ui-button--primary" href="#design/${encodeURIComponent(data.project.id)}?candidate=${encodeURIComponent(draft.id)}&amp;review=1">审阅方案</a>`;
      } else if (data.visual.proposal) {
        explanation = '先审阅并采用当前方案，再发布保存后的版本。';
        action = tool('审阅方案', 'design-conversation-visual');
      } else if (data.project.current_version_id) {
        explanation = '目前正在预览历史版本。你可以返回当前版本，或先将此版本恢复为当前设计。';
        action = `<a class="ui-button ui-button--secondary" href="#design/${encodeURIComponent(data.project.id)}">返回当前版本</a>${tool('恢复此历史版本', 'design-restore')}`;
      }
      context.showModal(dialog('发布网站', `<p>${explanation}</p><div class="conversation-tool-items">${action}</div>`));
      return true;
    }
    const { items } = await api('/hosting/sites');
    if (context.state.resource !== data || context.state.user?.id !== user.id) return true;
    const sites = items.filter(site => site.projectId === data.project.id);
    if (sites.length === 1) context.navigate(`hosting/${encodeURIComponent(sites[0].id)}`);
    else if (sites.length) {
      const links = sites.map(site => `<a class="ui-button ui-button--secondary" href="#hosting/${encodeURIComponent(site.id)}">${esc(site.name)} · ${esc(site.domain)}</a>`).join('');
      context.showModal(dialog('选择发布网站', `<div class="conversation-tool-items">${links}</div>`));
    } else context.navigate(`hosting?project=${encodeURIComponent(data.project.id)}`);
    return true;
  }
  return false;
}
