import { escapeHtml as e } from './icons.js';

const date=value=>value&&!Number.isNaN(new Date(value).valueOf())?new Intl.DateTimeFormat('zh-CN',{dateStyle:'medium',timeStyle:'short'}).format(new Date(value)):'—';
const sources={annual:'独立年付托管',gift:'赠送托管',membership:'会员附送托管'};
const stateNames={pending:'待处理',provisioning:'配置中',awaiting_dns:'等待域名验证',connected:'已连接',publishing:'发布中',active:'正常运行',suspended:'已暂停',error:'需要处理'};
function coverageMarkup(coverage){
 if(!coverage)return '<p>托管权益暂时无法读取，请刷新核对。</p>';
 const current=coverage.current,upcoming=coverage.upcoming||[];
 let output=current?`<strong>当前权益有效至 ${date(current.endsAt)}</strong><small>${e(current.sources.map(source=>sources[source]||source).join('、'))}</small><small>连续覆盖自 ${date(current.startsAt)}</small>`:
  `<strong>${coverage.membershipFrozen?'会员计时已冻结，当前无有效托管权益':coverage.lastEndedAt?'当前托管权益已到期':'当前无有效托管权益'}</strong>${coverage.lastEndedAt?`<small>上一有效区间结束于 ${date(coverage.lastEndedAt)}</small>`:''}`;
 if(upcoming.length)output+=`<details><summary>已安排的后续区间 · ${upcoming.length} 段</summary><p class="b-table-prose">以下区间尚未开始；区间之间的空档不包含托管服务。</p>${upcoming.map(range=>`<p class="b-table-prose">${date(range.startsAt)} 至 ${date(range.endsAt)}<small>${e(range.sources.map(source=>sources[source]||source).join('、'))}</small></p>`).join('')}</details>`;
 return output;
}
export function renderBillingHosting(items,paymentReady){
 if(!items.length)return '<div class="b-inline-empty">还没有网站托管记录。</div>';
 return `<p class="b-muted">每个网站单独计算已入账的托管权益；已确认的相邻区间合并展示，未到账的自动续费不计入。网站实际运行状态另行显示。</p><p class="b-operations-scroll-hint">左右滑动查看完整权益与续费操作。</p><div class="b-table-wrap"><table class="b-table"><thead><tr><th>网站</th><th>网站状态</th><th>已确认的托管权益</th><th>续费</th></tr></thead><tbody>${items.map(item=>`<tr data-billing-site-id="${e(item.id)}"><td><strong>${e(item.name||item.domain||'网站')}</strong><small>${e(item.domain||'')}</small><a class="text-button" href="#hosting/${encodeURIComponent(item.id)}">查看网站</a></td><td><span class="b-badge" data-status="${e(item.state)}">${e(stateNames[item.state]||item.state||'—')}</span></td><td>${coverageMarkup(item.coverage)}</td><td><button type="button" class="ui-button ui-button--secondary" data-action="payment-hosting" data-site-id="${e(item.id)}" ${paymentReady?'':'disabled'}>续费一年</button></td></tr>`).join('')}</tbody></table></div>`;
}
