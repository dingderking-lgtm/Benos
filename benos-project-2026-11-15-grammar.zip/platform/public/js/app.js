import { renderDashboardHome, renderDashboardRecentProjects, dashboardInspirations } from './dashboard-home.js';
import { renderWorkspaceSidebar, renderWorkspaceHeader, renderWorkspaceAccount } from './workspace-shell.js';
import { renderWorkspaceInspiration, handleWorkspaceAction, closeWorkspaceAccount } from './workspace-actions.js';
import { renderDesignStart, changeDesignStart, captureDesignStart, finishDesignStart, handleDesignStartAction, getDesignDirection, setDesignDirection } from './design-start.js';
import { designThumbnail } from './thumbnails.js';
import { loadPaymentCases, loadPaymentCase, renderPaymentCases, renderPaymentCase, handleCaseAction, submitCaseForm } from './payment-cases.js';
import { loadContentResource, updateContentFields, navigateContentFilter } from './content-editor.js';
import { handleFunctionalAction, submitFunctionalForm } from './integration-tests.js';
import { loadHostingPools, renderHostingPools, handlePoolAction, submitPoolForm } from './hosting-pools.js';
import { renderHostingOperations } from './hosting-management.js';
import { loadOperationsResource, renderOperationsPage, handleOperationsAction, submitOperationsForm } from './admin-operations.js';
import { loadBudgetReviews, renderBudgetReviews, renderBudgetAlertSummary, openBudgetReview, submitBudgetReview } from './budget-reviews.js';
import { loadSettingsResource, renderSettings as renderPlatformSettings, handleSettingsAction, submitSettingsForm } from './admin-settings.js';
import { renderNotifications, readNotification } from './notifications.js';
import { api, setCsrfToken, ApiError } from './api.js';
import { loadMediaResource, renderMediaPage, handleMediaAction, submitMediaForm } from './media.js';
import { loadBudgetResource, renderBudgetPage, handleBudgetAction, submitBudgetForm } from './budgets.js';
import { renderMaintenance, runMaintenance } from './maintenance.js';
import { loadPublishingData, handlePublishingAction, submitPublishingForm } from './publishing.js';
import { renderAgreements, renderOrderActions, updateTopupPreview, handlePaymentAction, submitPaymentForm } from './payments.js';
import { renderSecuritySettings, renderAccountTokenPage, handleSecurityAction, submitSecurityForm } from './account-security.js';
import { loadDesignResource, renderDesigner, mountDesigner, refreshDesignerConversation, stopDesignPolling, rememberDesignDraft, handleDesignChange, handleDesignAction, submitDesignForm } from './design.js';
import { syncConversationComposer } from './design-workflow.js';
import { handleMembershipAction, submitMembershipForm } from './memberships.js';
import { icon, escapeHtml as esc } from './icons.js';
import { renderUserDetail, renderAdminContent, renderAdminIntegrations, handleAdminAction, submitAdminForm, updateIntegrationFields } from './admin.js';
import { renderHostingList, renderHostingDetail, handleHostingAction, submitHostingForm } from './hosting.js';
import { renderBillingHosting } from './billing-hosting.js';

const app = document.querySelector('#app');
const modal = document.querySelector('#modal');
const mobileNav = document.querySelector('#mobile-nav');
const toastNode = document.querySelector('#toast');
let accountTokenPage = null;
if (['/account/reset-password', '/account/verify-email'].includes(location.pathname.replace(/\/$/, ''))) {
  accountTokenPage = { kind: location.pathname.split('/').filter(Boolean).at(-1), token: new URLSearchParams(location.hash.slice(1)).get('token') || '' };
  history.replaceState(null, '', `${location.pathname}${location.search}`);
}
if (!location.hash && ['/app/billing', '/app/settings'].includes(location.pathname.replace(/\/$/, ''))) {
  history.replaceState(null, '', `${location.pathname}${location.search}#${location.pathname.split('/').filter(Boolean).at(-1)}`);
}
const state = { user: null, bootstrapRequired: false, bootstrapConfigured: true, trustedOwnerEmail: '', route: 'home', resource: null, loading: false, error: null, authMode: 'login', collapsed: false, query: '', projectFilter: 'all', workspaceProjects: null, workspaceBilling: null, workspacePrompt: '', workspaceQuery: '' };
let routeEpoch = 0;
let routeController;
let toastTimer;
let lastModalFocus;
let projectStart = null;
let platformBrand = { brandName: 'Benos', tagline: '让每个想法拥有自己的空间', logoUrl: '/assets/brand/benos-logo.svg' };
let viewportZoom = 1;
function updateUiViewport() {
  const root = document.documentElement, viewport = window.visualViewport;
  viewportZoom = Number.parseFloat(getComputedStyle(root).zoom) || 1;
  const values = { width: (viewport?.width || innerWidth) / viewportZoom, height: (viewport?.height || innerHeight) / viewportZoom, left: (viewport?.offsetLeft || 0) / viewportZoom, top: (viewport?.offsetTop || 0) / viewportZoom };
  for (const [name, value] of Object.entries(values)) {
    const key = '--ui-viewport-' + name, next = value.toFixed(3) + 'px';
    if (root.style.getPropertyValue(key) !== next) root.style.setProperty(key, next);
  }
}
updateUiViewport();
window.addEventListener('resize', updateUiViewport, { passive: true });
window.visualViewport?.addEventListener('resize', updateUiViewport, { passive: true });
window.visualViewport?.addEventListener('scroll', updateUiViewport, { passive: true });
new MutationObserver(() => { if ((Number.parseFloat(getComputedStyle(document.documentElement).zoom) || 1) !== viewportZoom) updateUiViewport(); }).observe(document.documentElement, { attributes: true, attributeFilter: ['style'] });
const pendingTableMeasurements = new Set();
let tableMeasureFrame = 0;
const tableResizeObserver = new ResizeObserver(entries => {
  for (const { target } of entries) pendingTableMeasurements.add(target);
  if (tableMeasureFrame) return;
  tableMeasureFrame = requestAnimationFrame(() => {
    tableMeasureFrame = 0;
    const measured = [...pendingTableMeasurements].filter(target => target.isConnected).map(target => ({ target, scrolls: target.scrollWidth > target.clientWidth + 1 }));
    pendingTableMeasurements.clear();
    for (const { target, scrolls } of measured) {
      if (target.dataset.overflow !== String(scrolls)) target.dataset.overflow = String(scrolls);
      if (scrolls && target.getAttribute('tabindex') !== '0') target.setAttribute('tabindex', '0');
      else if (!scrolls && target.hasAttribute('tabindex')) target.removeAttribute('tabindex');
    }
  });
});
function enhanceTables(root) {
  for (const wrapper of root.querySelectorAll('.b-table-wrap')) {
    wrapper.setAttribute('role', 'region');
    wrapper.setAttribute('aria-label', '数据表，内容超出时可横向滚动');
    wrapper.querySelectorAll('thead th').forEach(cell => cell.setAttribute('scope', 'col'));
    tableResizeObserver.observe(wrapper);
  }
}

try { state.collapsed = JSON.parse(localStorage.getItem('benos-ui-preferences-v1') || '{}').collapsed === true; } catch { /* Preferences are optional. */ }

const names = { home: '工作台', inspiration: '灵感案例', projects: '我的网站', hosting: '网站托管', billing: '套餐与账单', settings: '账户设置', notifications: '服务通知', admin: '运营概览', 'admin/users': '会员管理', 'admin/catalog': '套餐与商业规则', 'admin/orders': '订单查询', 'admin/usage': 'AI 用量明细', 'admin/audit': '操作审计', 'admin/liabilities': '未使用 AI 额度', 'admin/settings': '品牌与联系设置', 'admin/integrations': '服务配置', 'admin/hosting': '站点管理', 'admin/hosting-pools': '托管连接', 'admin/budget-reviews': '预算预警与核对', 'admin/budgets': 'API 预算与用量', 'admin/payment-cases': '退款与支付争议', 'admin/content': '内容管理' };
const statusNames = { draft: '草稿', active: '进行中', published: '已发布', archived: '已归档', provisioning: '配置中', pending: '待处理', paid: '已支付', failed: '失败', canceled: '已取消', cancelled: '已取消', expired: '已到期', suspended: '已暂停', restricted: '受限', refunded: '已退款', fulfilled: '已入账', review: '待人工核对', checkout_created: '待支付', modified: '有未发布修改' };
const roleNames = { owner: '平台所有者', admin: '管理员', support: '客服', editor: '内容编辑', user: '用户' };
const isAdmin = () => ['owner', 'admin'].includes(state.user?.role);
const canOperate = () => ['owner', 'admin', 'support', 'editor'].includes(state.user?.role);
const rows = (value) => Array.isArray(value) ? value : (value?.items || value?.projects || []);
const money = (micros) => typeof micros === 'number' && Number.isFinite(micros) ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 4 }).format(micros / 1e6) : '—';
const price = (cents) => typeof cents === 'number' ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: cents % 100 ? 2 : 0 }).format(cents / 100) : '—';
const date = (value, includeTime = false) => {
  if (!value) return '—';
  const parsed = new Date(value);
  return Number.isNaN(parsed.valueOf()) ? '—' : new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium', ...(includeTime ? { timeStyle: 'short' } : {}) }).format(parsed);
};
const badge = (value) => `<span class="b-badge" data-status="${esc(value || '')}">${esc(statusNames[value] || value || '—')}</span>`;
const button = (label, action, appearance = 'secondary', extra = '') => `<button type="button" class="ui-button ui-button--${appearance}" data-action="${action}" ${extra}>${label}</button>`;
const linkButton = (label, href, appearance = 'secondary') => `<a class="ui-button ui-button--${appearance}" href="${href}">${label}</a>`;
const field = (label, name, { value = '', type = 'text', required = false, autocomplete = '', hint = '', maxlength = 160, minlength, placeholder = '', textarea = false, readonly = false } = {}) => `<label class="b-field"><span>${label}${required ? '<small aria-hidden="true"> *</small>' : ''}</span>${textarea ? `<textarea name="${name}" rows="4" maxlength="${maxlength}" ${required ? 'required' : ''} placeholder="${esc(placeholder)}">${esc(value)}</textarea>` : `<input name="${name}" type="${type}" value="${esc(value)}" maxlength="${maxlength}" ${minlength ? `minlength="${minlength}"` : ''} ${required ? 'required' : ''} ${readonly ? 'readonly' : ''} ${autocomplete ? `autocomplete="${autocomplete}"` : ''} placeholder="${esc(placeholder)}">`}${hint ? `<small class="b-field-hint">${hint}</small>` : ''}</label>`;
const formError = '<p class="b-form-error" role="alert" data-form-error hidden></p>';
const heading = (title, description = '', action = '') => `<div class="page-intro"><div><h1>${title}</h1>${description ? `<p>${description}</p>` : ''}</div>${action}</div>`;
const empty = (title, text, action = '', name = 'folder') => `<div class="b-empty">${icon(name)}<h2>${title}</h2><p>${text}</p>${action}</div>`;
const notice = (title, description, name = 'circle-question-mark') => `<div class="b-notice">${icon(name)}<div><strong>${title}</strong><p>${description}</p></div></div>`;

function toast(message) {
  clearTimeout(toastTimer);
  toastNode.textContent = message;
  toastNode.hidden = false;
  toastTimer = setTimeout(() => { toastNode.hidden = true; }, 4500);
}

function routeFromHash() {
  const raw = location.hash.replace(/^#\/?/, '') || 'home';
  if (state.user && ['login', 'register'].includes(raw)) return 'home';
  return raw.split('?')[0].replace(/\/$/, '');
}

function navigate(path) {
  if (location.hash.replace(/^#\/?/, '') === path) loadRoute();
  else location.hash = path;
}

function brand() {
  return `<a class="brand" href="#home" aria-label="${esc(platformBrand.brandName)} 工作台"><span class="brand-mark b-brand-mark" aria-hidden="true"><img src="${esc(platformBrand.logoUrl)}" alt="" width="34" height="34"></span><span class="brand-name">${esc(platformBrand.brandName)}<span class="brand-period">.</span></span></a>`;
}

function navigationLink(path, title, glyph) {
  const selected = state.route === path || (path === 'projects' && /^(design|media)\//.test(state.route)) || (['projects', 'hosting', 'admin/users', 'admin/payment-cases'].includes(path) && state.route.startsWith(path + '/'));
  return `<a class="nav-link" href="#${path}" title="${title}" ${selected ? 'aria-current="page"' : ''}>${icon(glyph)}<span>${title}</span></a>`;
}

function sidebar(mobile = false) {
  const user = state.user;
  if (!state.route.startsWith('admin')) return renderWorkspaceSidebar({user,brandHtml:brand(),collapsed:state.collapsed,mobile,route:state.route,projects:state.workspaceProjects,billing:state.workspaceBilling,canOperate:canOperate()});
  return `<div class="sidebar-brand">${brand()}${button(icon(mobile ? 'x' : 'panel-left'), mobile ? 'close-nav' : 'toggle-sidebar', 'ghost', `aria-label="${mobile ? '关闭导航' : '收起导航'}" title="${mobile ? '关闭导航' : '收起导航'}"`)}</div>
    <button type="button" class="ui-button new-site" data-action="new-project" title="新建项目">${icon('plus')}<span>新建项目</span></button>
    <div class="nav-group"><span class="nav-caption">工作空间</span><nav aria-label="工作空间">${navigationLink('home', '工作台', 'house')}${navigationLink('projects', '我的项目', 'folder')}${navigationLink('hosting', '网站托管', 'globe')}${navigationLink('billing', '套餐与账单', 'credit-card')}</nav></div>
    ${canOperate() ? `<div class="nav-group b-admin-nav"><span class="nav-caption">平台管理</span><nav aria-label="平台管理">${state.user.role !== 'editor' ? navigationLink('admin', '运营概览', 'layout-grid') + navigationLink('admin/users', '会员管理', 'shield-check') + navigationLink('admin/orders', '订单查询', 'credit-card') + navigationLink('admin/usage', 'AI 用量明细', 'file-text') + navigationLink('admin/payment-cases', '退款与支付争议', 'credit-card') : ''}${isAdmin() ? navigationLink('admin/catalog', '套餐与商业规则', 'credit-card') + navigationLink('admin/liabilities', '未使用 AI 额度', 'shield-check') + navigationLink('admin/audit', '操作审计', 'file-text') + navigationLink('admin/settings', '品牌与联系设置', 'settings') + navigationLink('admin/integrations', '服务配置', 'sliders-horizontal') + navigationLink('admin/hosting-pools', '托管连接', 'globe') + navigationLink('admin/budgets', 'API 预算与用量', 'shield-check') + navigationLink('admin/budget-reviews', '预算预警与核对', 'bell') : ''}${state.user.role === 'owner' ? navigationLink('admin/hosting', '站点管理', 'globe') : ''}${state.user.role !== 'support' ? navigationLink('admin/content', '内容管理', 'file-text') : ''}</nav></div>` : ''}
    <div class="sidebar-bottom"><nav aria-label="账户">${navigationLink('notifications', '服务通知', 'bell')}${navigationLink('settings', '账户设置', 'settings')}</nav><a class="profile" href="#settings" title="${esc(user.name || user.email)}"><span class="avatar">${esc((user.name || user.email || 'B').slice(0, 1).toUpperCase())}</span><span class="profile-copy"><strong>${esc(user.name || '我的账户')}</strong><small>${esc(user.email)}</small></span>${icon('chevron-right')}</a><button type="button" class="b-signout" data-action="logout" title="退出登录">${icon('arrow-left')}<span>退出登录</span></button></div>`;
}

function routeTitle() {
  return names[state.route] || (state.route.startsWith('admin/payment-cases/') ? '支付记录详情' : state.route.startsWith('media/') ? '项目素材' : state.route.startsWith('design/') ? '网站设计' : state.route.startsWith('projects/') ? '项目详情' : state.route.startsWith('admin/users/') ? '会员详情' : state.route.startsWith('hosting/') ? '网站连接' : '页面');
}

function renderShell(content) {
  closeWorkspaceAccount();
  const userWorkspace = !state.route.startsWith('admin');
  mobileNav.classList.toggle('b-workspace-user',userWorkspace);
  tableResizeObserver.disconnect();
  pendingTableMeasurements.clear();
  document.title = `${routeTitle()} · ${platformBrand.brandName}`;
  app.innerHTML = `<div class="app-shell${userWorkspace ? ' b-workspace-user' : ''}${state.collapsed ? ' sidebar-collapsed' : ''}"><aside class="app-sidebar" aria-label="主导航">${sidebar()}</aside><main id="main-content" class="app-main" tabindex="-1">${userWorkspace ? renderWorkspaceHeader({user:state.user,route:state.route,title:routeTitle(),billing:state.workspaceBilling}) : `<header class="app-header"><div class="breadcrumbs"><button class="ui-button ui-icon-button mobile-menu" data-action="open-nav" aria-label="打开导航">${icon('menu')}</button>${state.collapsed ? `<button class="ui-button ui-icon-button b-expand" data-action="toggle-sidebar" aria-label="展开导航">${icon('panel-left')}</button>` : ''}<span class="workspace-crumb">我的工作空间</span><span class="crumb-slash">/</span><strong>${routeTitle()}</strong></div><div class="header-actions"><a class="b-header-account" href="#settings" aria-label="账户设置"><span class="avatar">${esc((state.user.name || state.user.email).slice(0, 1).toUpperCase())}</span></a></div></header>`}<div id="route-content"${state.route.startsWith('design/') ? ' class="view designer-view"' : ''}>${content}</div><footer class="b-footer">${esc(platformBrand.brandName)} · ${esc(platformBrand.tagline)}</footer></main></div>`;
  enhanceTables(app);
}

function renderLoading() {
  renderShell('<section class="s-page"><div class="b-loading" role="status" aria-live="polite">' + icon('loader-circle') + '<p>正在加载…</p></div></section>');
}

function renderError(error, fullPage = false) {
  const content = `<div class="b-error" role="alert">${icon('circle-question-mark')}<h1>暂时无法加载</h1><p>${esc(error.message || '服务连接失败，请重试。')}</p>${error.code ? `<small>错误代码：${esc(error.code)}</small>` : ''}${button('重新加载', fullPage ? 'restart' : 'retry', 'primary')}</div>`;
  if (fullPage) app.innerHTML = `<main id="main-content" class="b-startup">${brand()}${content}</main>`;
  else renderShell(`<section class="s-page">${content}</section>`);
}

function renderAuth(message = '') {
  const setup = state.bootstrapRequired;
  const register = !setup && state.authMode === 'register';
  const title = setup ? `创建你的 ${esc(platformBrand.brandName)} 平台` : register ? '开始你的创作' : '欢迎回来';
  document.title = `${setup ? '初始化平台' : register ? '注册' : '登录'} · ${platformBrand.brandName}`;
  app.innerHTML = `<main id="main-content" class="b-auth"><section class="b-auth-story"><div>${brand()}</div><div class="b-auth-intro"><span class="b-eyebrow">你的想法，自此发生</span><h1>从一个想法，<br>到一个属于<br>你的网站。</h1><p>设计、内容与网站管理，在同一个工作空间中完成。</p><div class="b-auth-art" aria-hidden="true"><div class="b-art-window"><span></span><span></span><span></span><div class="b-art-title"></div><div class="b-art-line"></div><div class="b-art-cards"><i></i><i></i><i></i></div></div><span class="b-art-label">Made with ${esc(platformBrand.brandName)} ${icon('sparkles')}</span></div></div><small>${esc(platformBrand.brandName)} · 网站设计与内容管理</small></section><section class="b-auth-main"><div class="b-auth-mobile-brand">${brand()}</div><div class="b-auth-card"><h2>${title}</h2><p class="b-auth-description">${setup ? state.trustedOwnerEmail ? '以当前 Sites 所有者身份初始化平台。请设置你的称呼与登录密码。' : '首次使用需要初始化平台所有者账户。' : register ? '创建账户，开启你的第一个网站项目。' : '登录后继续管理你的项目。'}</p>${message ? `<p class="b-notice-text" role="status">${esc(message)}</p>` : ''}${setup && !state.bootstrapConfigured ? notice('初始化配置未完成', '请先在平台部署环境中配置安全密钥与初始化密钥，再重新加载。', 'shield-check') + button('重新检查', 'restart') : ''}<form data-form="${setup ? 'bootstrap' : register ? 'register' : 'login'}" ${setup && !state.bootstrapConfigured ? 'hidden' : ''}>${setup && !state.trustedOwnerEmail ? field('初始化密钥', 'token', { type: 'password', required: true, autocomplete: 'off', maxlength: 512, hint: '使用部署时设置的初始化密钥，仅用于首次创建平台所有者。' }) : ''}${setup || register ? field('你的称呼', 'name', { required: true, autocomplete: 'name', maxlength: 80, placeholder: '怎么称呼你' }) : ''}${field('邮箱地址', 'email', { type: 'email', value: setup ? state.trustedOwnerEmail : '', readonly: setup && !!state.trustedOwnerEmail, required: true, autocomplete: 'email', maxlength: 254, placeholder: 'you@example.com' })}${field('密码', 'password', { type: 'password', required: true, autocomplete: setup || register ? 'new-password' : 'current-password', minlength: setup || register ? 12 : undefined, maxlength: 128, hint: setup || register ? '至少 12 个字符，建议结合字母、数字与符号。' : '' })}${formError}<button class="ui-button ui-button--primary b-auth-submit" type="submit">${setup ? '创建平台所有者' : register ? '创建账户' : '登录'}${icon('arrow-right')}</button></form>${!setup && !register ? '<button type="button" class="text-button b-forgot-password" data-action="security-forgot-password">忘记密码？</button>' : ''}${setup ? '<p class="b-auth-footer">初始化完成后，平台将关闭此入口。</p>' : `<p class="b-auth-footer">${register ? '已经有账户？' : '还没有账户？'} <button type="button" class="text-button" data-action="switch-auth">${register ? '登录' : '注册'}</button></p>`}</div><small class="b-auth-legal">账户与项目仅对你及获授权的平台管理员可见。</small></section></main>`;
}

function projectCard(project) {
  const edit = `#design/${encodeURIComponent(project.id)}`, details=`#projects/${encodeURIComponent(project.id)}`;
  return `<article class="project-card"><a class="project-preview-button" href="${edit}" aria-label="继续设计 ${esc(project.name)}"><div class="site-thumb">${project.current_version_id?designThumbnail(project.id,project.current_version_id,project.name):`<span class="b-project-monogram">${esc((project.name||'B').slice(0,1))}</span>`}</div></a><div class="project-card-info"><div class="project-title-line"><h3><a href="${edit}">${esc(project.name)}</a></h3><a class="ui-icon-button ui-button--ghost project-more" href="${details}" aria-label="管理 ${esc(project.name)}">${icon('ellipsis')}</a></div><div class="project-meta-line">${badge(project.status)}<span class="meta-separator">·</span><time class="project-updated" datetime="${esc(project.updated_at)}" title="${date(project.updated_at,true)}">${date(project.updated_at)} 更新</time></div><div class="project-card-actions">${project.current_version_id?`<button type="button" class="text-button" data-action="workspace-project-preview" data-project-id="${esc(project.id)}" data-version-id="${esc(project.current_version_id)}" data-name="${esc(project.name)}">设计预览 ${icon('monitor')}</button>`:'<span class="b-muted">等待首次设计</span>'}<a class="text-button design-action" href="${edit}">继续设计 ${icon('arrow-right')}</a></div></div></article>`;
}

function renderHome() {
 const projects=[...rows(state.resource)].sort((a,b)=>new Date(b.updated_at)-new Date(a.updated_at));
 return renderDashboardHome({user:state.user,projects,brand:platformBrand,composerOptions:renderDesignStart(state.user,true),projectCard,direction:getDesignDirection(state.user),prompt:state.workspacePrompt,query:state.workspaceQuery,showTip:!state.workspaceTipDismissed});
}

function filteredProjects() {
  return rows(state.resource).filter((project) => (state.projectFilter === 'all' || project.status === state.projectFilter) && `${project.name} ${project.description || ''}`.toLowerCase().includes(state.query.toLowerCase()));
}

function renderProjects() {
  const projects = rows(state.resource);
  const filtered = filteredProjects();
  return `<section class="s-page">${heading('我的项目', '为每一个网站，留出独立的创作空间。', button(icon('plus') + '新建项目', 'new-project', 'primary'))}<div class="b-project-toolbar"><div class="b-tabs" role="group" aria-label="项目状态">${[['all', '全部项目'], ['draft', '草稿'], ['published', '已发布']].map(([key, title]) => `<button type="button" data-filter="${key}" aria-pressed="${state.projectFilter === key}">${title}</button>`).join('')}</div><label class="b-search">${icon('search')}<span class="b-sr-only">搜索项目</span><input type="search" name="project-search" value="${esc(state.query)}" placeholder="搜索项目" maxlength="160"></label></div><div id="project-results" aria-live="polite">${projects.length ? filtered.length ? `<div class="project-grid workspace-projects-grid">${filtered.map(projectCard).join('')}</div>` : empty('没有找到匹配的项目', '试试其他名称或切换项目状态。', '', 'search') : empty('创建你的第一个项目', '从一个名称、一段描述开始，所有项目会显示在这里。', button(icon('plus') + '新建项目', 'new-project', 'primary'))}</div>${state.resource.nextCursor ? `<div class="b-pagination"><p>已加载 ${projects.length} 个项目，搜索范围为已加载项目。</p>${button('加载更多项目', 'more-projects')}</div>` : ''}</section>`;
}

function renderProject() {
  const project = state.resource.project || state.resource;
  return `<section class="s-page"><a class="b-back" href="#projects">${icon('arrow-left')}返回我的项目</a>${heading(esc(project.name), '管理项目信息，准备你的网站内容。', badge(project.status))}<div class="b-project-detail-grid"><section class="b-card"><div class="b-card-heading"><h2>项目信息</h2><p>修改会保存到你的账户中。</p></div><form data-form="edit-project" data-project-id="${esc(project.id)}">${field('项目名称', 'name', { value: project.name, required: true, maxlength: 120 })}${field('项目描述', 'description', { value: project.description || '', textarea: true, maxlength: 4000, placeholder: '网站的用途、面向的访客，以及你希望展示的内容。' })}${formError}<div class="b-form-actions"><button class="ui-button ui-button--primary" type="submit">保存更改</button></div></form></section><aside class="b-card b-project-facts"><h2>项目概况</h2><dl><div><dt>创建时间</dt><dd>${date(project.created_at, true)}</dd></div><div><dt>最后更新</dt><dd>${date(project.updated_at, true)}</dd></div><div><dt>项目状态</dt><dd>${badge(project.status)}</dd></div></dl><p class="b-muted">项目 ID</p><code class="b-project-id">${esc(project.id)}</code></aside></div><section class="b-section"><div class="b-section-heading"><div><h2>下一步，完成你的网站</h2><p>设计网站、查看历史版本，并连接你的 CMS。</p></div></div><div class="b-next-grid"><div class="b-card">${icon('sparkles')}<h3>AI 网站设计</h3><p>根据项目需求生成并调整网站设计。</p><a class="ui-button ui-button--secondary" href="#design/${encodeURIComponent(project.id)}">打开设计台 ${icon('arrow-right')}</a></div><div class="b-card">${icon('image')}<h3>项目素材</h3><p>上传与管理品牌标志、产品图和网站图片。</p><a class="ui-button ui-button--secondary" href="#media/${encodeURIComponent(project.id)}">管理素材 ${icon('arrow-right')}</a></div><div class="b-card">${icon('globe')}<h3>连接 CMS</h3><p>填写网站名称、域名与管理账户，自动完成网站配置。</p><a class="ui-button ui-button--secondary" href="#hosting?project=${encodeURIComponent(project.id)}">连接网站 ${icon('arrow-right')}</a></div></div></section></section>`;
}

function renderBilling() {
  const data = state.resource;
  const wallet = data.wallet || {};
  const plan = data.plan;
  const ended = plan?.endsAt && new Date(plan.endsAt) <= new Date();
  const planName = plan ? `${plan.tier === 'pro' ? 'Pro' : plan.tier === 'go' ? 'Go' : esc(plan.tier)} 套餐` : '未订阅套餐';
  return `<section class="s-page">${heading('套餐与账单', '清楚了解你的会员权益、AI 用量与网站托管。')}<div class="b-billing-summary"><section class="b-card b-current-plan"><span class="b-eyebrow">当前套餐</span><h2>${planName}</h2><p>${plan ? `${ended ? '已于' : '有效期至'} ${date(plan.endsAt)}${ended ? '到期' : ''}` : '选择适合你的套餐，开始创作。'}</p><a class="text-button" href="#billing" data-action="scroll-plans">查看套餐 ${icon('arrow-right')}</a></section><section class="b-card b-wallet"><span class="b-eyebrow">可用 AI 额度</span>${data.walletState === 'unavailable' ? '<p role="alert">暂时无法读取余额，请刷新重试。</p>' : ''}<strong class="b-balance">${money(wallet.availableMicros)}</strong><p>请求预留 ${money(wallet.heldMicros)} <span>· 实际用量结算后释放未使用额度</span></p><p>会员暂停额度 ${money(wallet.pausedMicros)}</p><div class="b-wallet-buckets"><div><span>会员额度</span><strong>${money(wallet.subscriptionMicros)}</strong></div><div><span>充值余额</span><strong>${money(wallet.topupMicros)}</strong></div><div><span>赠送额度</span><strong>${money(wallet.giftMicros)}</strong></div></div></section></div><section class="b-card b-topup"><div><h2>额外 AI 用量</h2><p>${data.canTopup ? '会员有效期内可充值，最低 $5。每 $10 获得 $6.50 的 AI 额度。' : '仅有效付费会员可以充值。会员到期后，历史充值余额仍可继续用于 AI 设计。'}</p></div><button type="button" class="ui-button ui-button--secondary" data-action="payment-topup" ${data.canTopup && data.paymentReady ? '' : 'disabled'}>${data.canTopup ? data.paymentReady ? '追加 AI 用量' : '充值暂未开放' : plan?.source === 'gift' ? '需付费会员' : plan?.source === 'paid' ? '充值暂不可用' : '需有效会员'}</button></section>${!data.paymentReady ? notice('购买与续费暂未开放', '支付服务配置完成后，可在这里购买套餐、充值 AI 用量或续费网站托管。', 'credit-card') : ''}<section class="b-section" id="plans"><div class="b-section-heading"><div><h2>选择适合你的创作方式</h2><p>会员额度按月发放；额外充值余额单独保留。</p></div></div><div class="b-plan-grid">${(data.plans || []).map((item) => `<article class="b-plan-card${plan?.tier === item.tier && !ended ? ' is-current' : ''}"><div class="b-plan-title"><h3>${esc(item.name)}</h3>${plan?.tier === item.tier && !ended ? '<span class="b-badge">当前套餐</span>' : ''}</div><p class="b-plan-price">${price(item.priceCents)}<span>/ 月</span></p><ul><li>${icon('check')}每月 ${money(item.creditMicros)} AI 额度</li><li>${icon('check')}包含 ${esc(item.includedSites)} 个网站托管</li><li>${icon('check')}会员有效期内可追加 AI 用量</li><li>${icon('check')}充值余额到期后仍可使用</li></ul><button type="button" class="ui-button ui-button--${item.tier === 'pro' ? 'primary' : 'secondary'}" data-action="payment-subscribe" data-tier="${esc(item.tier)}" ${data.paymentReady ? '' : 'disabled'}>${data.paymentReady ? '订阅 ' + esc(item.name) : '购买暂未开放'}</button></article>`).join('')}<article class="b-plan-card b-hosting-plan"><div class="b-plan-title"><h3>独立 CMS 托管</h3></div><p class="b-plan-price">${price(data.hostingAnnualPriceCents ?? 3000)}<span>/ 网站 / 年</span></p><ul><li>${icon('check')}月租结束后继续托管网站</li><li>${icon('check')}与 AI 会员权益独立计算</li><li>${icon('check')}不包含 AI 额度与充值权限</li></ul><button type="button" class="ui-button ui-button--secondary" data-action="scroll-hosting" ${data.paymentReady ? '' : 'disabled'}>${data.paymentReady ? '选择网站续费' : '续费暂未开放'}</button></article></div></section>${renderAgreements(data.agreements || [])}<section class="b-section" id="billing-hosting"><div class="b-section-heading"><div><h2>网站托管</h2><p>会员到期后，需独立续费以继续提供托管服务。</p></div></div>${renderHosting(data.hosting || [])}</section><section class="b-section"><div class="b-section-heading"><div><h2>订单记录</h2><p>已创建的订单会显示在这里。</p></div></div>${renderOrders(data.orders || [])}</section><div class="b-billing-rules"><p>${icon('shield-check')}所有 AI 请求均先核验并预留额度，余额不足时停止请求。</p><p>会员月度额度到期失效；充值余额保留。网站托管与 AI 余额分别管理。</p></div></section>`;
}

function renderHosting(items) {
  return renderBillingHosting(items,state.resource.paymentReady);
}

function renderOrders(items) {
  if (!items.length) return '<div class="b-inline-empty">还没有订单记录。未完成支付的订单不会增加账户权益。</div>';
  return `<p class="b-operations-scroll-hint">左右滑动查看完整订单与付款操作。</p><div class="b-table-wrap"><table class="b-table"><thead><tr><th>订单</th><th>金额</th><th>状态</th><th>创建时间</th><th>操作</th></tr></thead><tbody>${items.map((item) => `<tr><td><strong>${esc(item.description || ({subscription: '会员订阅', topup: 'AI 额度充值', hosting: '年度网站托管'}[item.kind]) || item.type || item.kind || '订单')}</strong><small>${esc(item.id)}</small></td><td>${price(item.amountCents ?? item.amount_cents)}</td><td>${badge(item.status || item.state)}</td><td>${date(item.created_at || item.createdAt)}</td><td>${renderOrderActions(item)}</td></tr>`).join('')}</tbody></table></div>`;
}

function renderSettings() {
  const profile = state.resource.user || state.resource;
  return `<section class="s-page">${heading('账户设置', '管理你的个人资料与账户信息。')}<section class="b-card b-settings-row"><div class="b-card-heading"><h2>个人资料</h2><p>你的称呼会显示在工作空间中。</p></div><form data-form="profile">${field('你的称呼', 'name', { value: profile.name || state.user.name, required: true, maxlength: 80, autocomplete: 'name' })}${field('邮箱地址', 'email', { value: profile.email || state.user.email, type: 'email', readonly: true, hint: '邮箱用于登录与账户识别。' })}${formError}<div class="b-form-actions"><button type="submit" class="ui-button ui-button--primary">保存资料</button></div></form></section><section class="b-card b-settings-row"><div class="b-card-heading"><h2>账户身份</h2><p>账户权限由平台统一管理。</p></div><div class="b-account-details"><dl><div><dt>身份</dt><dd>${esc(roleNames[state.user.role] || state.user.role)}</dd></div><div><dt>账户 ID</dt><dd><code>${esc(state.user.id)}</code></dd></div></dl></div></section><section class="b-card b-settings-row"><div class="b-card-heading"><h2>登录状态</h2><p>在共享设备上使用后，请及时退出。</p></div><div>${button(icon('arrow-left') + '退出当前账户', 'logout')}</div></section>${renderSecuritySettings({ user: profile, sessions: state.resource.securitySessions })}</section>`;
}

function integrationRows(integrations) {
  if (!integrations.length) return '<div class="b-inline-empty">服务配置状态尚未返回。</div>';
  return `<div class="b-integration-list">${integrations.map((item) => `<div>${icon(item.type === 'ai' ? 'sparkles' : item.type === 'payment' ? 'credit-card' : 'server')}<div><strong>${esc(item.name || item.type || item.id || '服务')}</strong><p>${esc(item.message || item.description || (item.configured ? '服务已配置' : '请完成服务配置'))}</p></div><span class="b-badge">${esc(item.status || (item.configured ? '已配置' : '待配置'))}</span></div>`).join('')}</div>`;
}

function renderAdmin() {
  const data = state.resource;
  const metrics = [['注册用户', data.users, 'shield-check'], ['项目总数', data.projects, 'folder'], ['有效订阅', data.activeSubscriptions, 'credit-card'], ['待结算 AI 请求', data.openReservations, 'clock']];
  return `<section class="s-page">${heading('运营概览', '查看平台当前运行情况与服务配置状态。', button(icon('rotate-ccw') + '刷新', 'retry'))}<div class="b-metrics">${metrics.map(([label, value, glyph]) => `<article class="b-card b-metric"><span>${icon(glyph)}${label}</span><strong>${typeof value === 'number' ? value.toLocaleString('zh-CN') : '—'}</strong></article>`).join('')}</div><section class="b-section"><div class="b-section-heading"><div><h2>服务连接</h2><p>生产服务以后台实际配置与检查结果为准。</p></div>${isAdmin() ? `<a class="text-button" href="#admin/integrations">管理服务 ${icon('arrow-right')}</a>` : ''}</div><div class="b-card">${integrationRows(data.integrations || [])}</div></section>${renderBudgetAlertSummary(data.budgetReviews)}${renderMaintenance(data.maintenance, state.user)}<section class="b-section"><div class="b-section-heading"><h2>运营管理</h2></div><div class="b-next-grid"><a class="b-card b-navigation-card" href="#admin/users">${icon('shield-check')}<h3>会员管理</h3><p>查询账户与会员状态。</p><span>打开会员列表 ${icon('arrow-right')}</span></a>${state.user.role !== 'support' ? `<a class="b-card b-navigation-card" href="#admin/content">${icon('file-text')}<h3>内容管理</h3><p>营销页面与博客内容。</p><span>查看内容管理 ${icon('arrow-right')}</span></a>` : ''}</div></section></section>`;
}

function renderUsers() {
  const users = rows(state.resource);
  return `<section class="s-page">${heading('会员管理', '会员账户保留完整记录，重要变更需要审计。', button(icon('rotate-ccw') + '刷新', 'retry'))}${notice('保留会员与操作记录', '可在会员详情中限制或恢复账户权限；会员计时单独管理。每次变更均记录原因，会员账户不提供直接增加或删除操作。', 'shield-check')}${users.length ? `<div class="b-table-wrap b-section"><table class="b-table"><thead><tr><th>用户</th><th>角色</th><th>账户状态</th><th>注册时间</th><th>操作</th></tr></thead><tbody>${users.map((user) => `<tr><td><strong>${esc(user.name || '未设置称呼')}</strong><small>${esc(user.email)}</small></td><td>${esc(roleNames[user.role] || user.role)}</td><td>${badge(user.status === 'active' ? '正常' : user.status)}</td><td>${date(user.created_at)}</td><td><a class="ui-button ui-button--secondary" href="#admin/users/${encodeURIComponent(user.id)}">查看详情</a></td></tr>`).join('')}</tbody></table></div>` : empty('还没有用户记录', '新注册的账户将在这里显示。', '', 'shield-check')}</section>`;
}

function renderCurrent() {
  if (!state.user) return renderAuth();
  if (state.loading) return renderLoading();
  if (state.error) return renderError(state.error);
  const renderers = { home: renderHome, inspiration: () => renderWorkspaceInspiration(getDesignDirection(state.user)), projects: renderProjects, hosting: () => renderHostingList(state.resource), billing: renderBilling, settings: renderSettings, notifications: () => renderNotifications(state.resource), admin: renderAdmin, 'admin/users': () => renderOperationsPage(state.resource, state.user), 'admin/catalog': () => renderOperationsPage(state.resource, state.user), 'admin/orders': () => renderOperationsPage(state.resource, state.user), 'admin/usage': () => renderOperationsPage(state.resource, state.user), 'admin/audit': () => renderOperationsPage(state.resource, state.user), 'admin/liabilities': () => renderOperationsPage(state.resource, state.user), 'admin/settings': () => renderPlatformSettings(state.resource), 'admin/integrations': () => renderAdminIntegrations(state.resource, state.user), 'admin/hosting': () => renderHostingOperations(state.resource), 'admin/hosting-pools': () => renderHostingPools(state.resource, state.user), 'admin/budget-reviews': () => renderBudgetReviews(state.resource, state.user), 'admin/budgets': () => renderBudgetPage(state.resource, state.user), 'admin/payment-cases': () => renderPaymentCases(state.resource, state.user), 'admin/content': () => renderAdminContent(state.resource) };
  const render = renderers[state.route] || (/^admin\/payment-cases\/[^/]+$/.test(state.route) ? () => renderPaymentCase(state.resource, state.user) : /^media\/[^/]+$/.test(state.route) ? () => renderMediaPage(state.resource, state.user) : /^design\/[^/]+$/.test(state.route) ? () => renderDesigner(state.resource, state.user) : /^hosting\/[^/]+$/.test(state.route) ? () => renderHostingDetail(state.resource) : /^admin\/users\/[^/]+$/.test(state.route) ? () => renderOperationsPage(state.resource, state.user) : /^projects\/[^/]+$/.test(state.route) ? renderProject : () => `<section class="s-page">${empty('页面不存在', '请从导航中打开需要的页面。', linkButton('返回工作台', '#home', 'primary'), 'circle-question-mark')}</section>`);
  renderShell(render());
  if (/^design\/[^/]+$/.test(state.route)) mountDesigner(adminContext());
}

async function loadRoute() {
  stopDesignPolling();
  if (!state.user) {
    if (['#login', '#register'].includes(location.hash)) state.authMode = location.hash === '#register' ? 'register' : 'login';
    return renderAuth();
  }
  closeModal();
  closeWorkspaceAccount();
  if (mobileNav.open) mobileNav.close();
  state.route = routeFromHash();
  state.resource = null;
  state.error = null;
  state.loading = true;
  const epoch = ++routeEpoch;
  routeController?.abort();
  routeController = new AbortController();
  const options = { signal: routeController.signal };
  const workspaceReads = !state.route.startsWith('admin') ? Promise.allSettled([
    state.route==='billing'?Promise.resolve(null):api('/billing/summary',options),
    ['home','projects'].includes(state.route)?Promise.resolve(null):api('/projects',options)
  ]) : null;
  renderCurrent();
  try {
    if (state.route.startsWith('admin') && !canOperate()) throw new ApiError('你的账户没有平台管理权限。', 'FORBIDDEN', 403);
    let result = {};
    if (state.route === 'home' || state.route === 'projects') result = await api('/projects', options);
    else if (/^projects\/[^/]+$/.test(state.route)) result = await api(`/projects/${encodeURIComponent(decodeURIComponent(state.route.split('/')[1]))}`, options);
    else if (/^design\/[^/]+$/.test(state.route)) result = await loadDesignResource(decodeURIComponent(state.route.split('/')[1]), state.user, options);
    else if (/^media\/[^/]+$/.test(state.route)) result = await loadMediaResource(decodeURIComponent(state.route.split('/')[1]), state.user, options);
    else if (state.route === 'hosting') result = await api('/hosting/sites', options);
    else if (/^hosting\/[^/]+$/.test(state.route)) {
      result = await api(`/hosting/sites/${encodeURIComponent(decodeURIComponent(state.route.split('/')[1]))}`, options);
      result.publishing = await loadPublishingData(result, options);
    }
    else if (state.route === 'notifications') result = await api('/notifications', options);
    else if (state.route === 'billing') result = await api('/billing/summary', options);
    else if (state.route === 'settings') {
      const reads = await Promise.allSettled([api('/profile', options), api('/account/sessions', options)]);
      const failed = reads.find(item => item.status === 'rejected');
      if (failed) throw failed.reason;
      result = { ...reads[0].value, securitySessions: reads[1].value };
    }
    else if (state.route === 'admin') {
      const reads = await Promise.allSettled([api('/admin/overview', options), isAdmin() ? api('/admin/maintenance', options) : Promise.resolve(null), isAdmin() ? loadBudgetReviews(options) : Promise.resolve(null)]);
      const failed = reads.find(item => item.status === 'rejected');
      if (failed) throw failed.reason;
      result = { ...reads[0].value, maintenance: reads[1].value, budgetReviews: reads[2].value };
    }
    else if (state.route === 'admin/hosting-pools') result = await loadHostingPools(options);
    else if (state.route === 'admin/hosting') result = await api('/hosting-management/sites' + (location.hash.includes('?') ? '?' + location.hash.split('?')[1] : ''), options);
    else if (state.route === 'admin/settings') { result = await loadSettingsResource(options); if (result.active?.brandName && result.active?.logoUrl) platformBrand = result.active; }
    else if (state.route === 'admin/integrations') result = await api('/admin/integrations', options);
    else if (state.route === 'admin/payment-cases') result = await loadPaymentCases(options);
    else if (/^admin\/payment-cases\/[^/]+$/.test(state.route)) result = await loadPaymentCase(decodeURIComponent(state.route.split('/')[2]), options);
    else if (state.route === 'admin/budgets') result = await loadBudgetResource(options);
    else if (state.route === 'admin/budget-reviews') result = await loadBudgetReviews(options);
    else if (state.route === 'admin/content') result = await loadContentResource(options);
    else if (/^admin\/users\/[^/]+$/.test(state.route)) result = await loadOperationsResource('member', options, decodeURIComponent(state.route.split('/')[2]));
    else if (state.route === 'admin/users') result = await loadOperationsResource('members', options);
    else if (/^admin\/(catalog|orders|usage|audit|liabilities)$/.test(state.route)) result = await loadOperationsResource(state.route.split('/')[1], options);
    if (epoch !== routeEpoch || !state.user) return;
    if(workspaceReads){const extra=await workspaceReads;if(epoch!==routeEpoch||!state.user)return;state.workspaceBilling=state.route==='billing'?result:extra[0].status==='fulfilled'?extra[0].value:null;state.workspaceProjects=['home','projects'].includes(state.route)?result:extra[1].status==='fulfilled'?extra[1].value:null;}
    state.resource = result;
  } catch (error) {
    if (error.name === 'AbortError' || epoch !== routeEpoch || !state.user) return;
    state.error = error;
  }
  if (epoch !== routeEpoch || !state.user) return;
  state.loading = false;
  renderCurrent();
}

function showModal(html, opener = null) {
  closeWorkspaceAccount();
  modal.classList.remove('direction-modal','workspace-preview-modal');
  updateUiViewport();
  if (!modal.open) lastModalFocus = opener?.isConnected ? opener : document.activeElement;
  if (mobileNav.open) mobileNav.close();
  modal.innerHTML = html;
  const title = modal.querySelector('h2');
  if (title) { title.id = 'modal-title'; modal.setAttribute('aria-labelledby', 'modal-title'); }
  modal.showModal();
  enhanceTables(modal);
  modal.querySelector('input,textarea,select')?.focus();
}

function signOutLocal() {
  state.user = null; state.resource = null; state.workspaceProjects=null;state.workspaceBilling=null;state.workspacePrompt='';state.workspaceQuery='';state.workspaceTipDismissed=false;accountTokenPage = null; state.authMode = 'login';
  ++routeEpoch; routeController?.abort(); stopDesignPolling(); setCsrfToken('');
  closeModal(); if (mobileNav.open) mobileNav.close();
  history.replaceState(null, '', '/#home'); renderAuth();
}

let conversationRefresh = 0;
async function refreshConversation() {
  const sequence = ++conversationRefresh, epoch = routeEpoch, userId = state.user?.id;
  const signal = routeController?.signal;
  const refreshBalance = async () => {
    let billing;
    try { billing = await api('/billing/summary', { signal }); }
    catch { billing = null; }
    if (sequence !== conversationRefresh || epoch !== routeEpoch || state.user?.id !== userId) return;
    state.workspaceBilling = billing;
    const usage = document.querySelector('.header-usage');
    if (!usage) return;
    const header = document.createElement('template');
    header.innerHTML = renderWorkspaceHeader({route:state.route, title:routeTitle(), billing});
    const next = header.content.querySelector('.header-usage');
    usage.setAttribute('aria-label', next.getAttribute('aria-label'));
    usage.title = next.title;
    if (usage.innerHTML !== next.innerHTML) usage.replaceChildren(...next.childNodes);
  };
  await Promise.all([refreshDesignerConversation(adminContext(), signal), refreshBalance()]);
}
const adminContext = (opener = null) => ({ state, showModal: html => showModal(html, opener), closeModal, reload: loadRoute, refreshConversation, notify: toast, navigate, signOutLocal, render: renderCurrent });

function openProjectDialog(description = '', startOptions = null) {
  closeWorkspaceAccount();
  modal.classList.remove('direction-modal','workspace-preview-modal');
  projectStart = startOptions;
  lastModalFocus = document.activeElement;
  if (mobileNav.open) mobileNav.close();
  modal.innerHTML = `<div class="b-modal-header"><div><h2 id="modal-title">新建项目</h2><p>先记下网站的名称和想法。</p></div><button type="button" class="ui-button ui-icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('x')}</button></div><form class="b-modal-body" data-form="create-project">${field('项目名称', 'name', { required: true, maxlength: 120, placeholder: '例如：我的品牌官网' })}${field('项目描述', 'description', { value: description, textarea: true, maxlength: 4000, placeholder: '希望制作什么网站？主要展示哪些内容？' })}${formError}<div class="b-form-actions">${button('取消', 'close-modal')}<button type="submit" class="ui-button ui-button--primary">创建项目 ${icon('arrow-right')}</button></div></form>`;
  modal.showModal();
  modal.querySelector('input[name="name"]')?.focus();
}

function closeModal() {
  if (modal.open) modal.close();
}

async function start() {
  if (['#login', '#register'].includes(location.hash)) state.authMode = location.hash === '#register' ? 'register' : 'login';
  if (accountTokenPage) {
    document.title = `${accountTokenPage.kind === 'reset-password' ? '重置密码' : '验证邮箱'} · ${platformBrand.brandName}`;
    app.innerHTML = `<main id="main-content" class="b-token-page">${brand()}${renderAccountTokenPage(accountTokenPage.kind, accountTokenPage.token)}</main>`;
    return;
  }
  ++routeEpoch;
  routeController?.abort();
  setCsrfToken('');
  state.user = null;
  app.innerHTML = `<main id="main-content" class="b-startup" aria-busy="true">${brand()}<p>正在连接你的工作台…</p></main>`;
  try {
    const [session, branding] = await Promise.all([api('/session'), api('/branding').catch(() => null)]);
    if (branding?.brandName && branding?.logoUrl) platformBrand = branding;
    state.user = session.user;
    setCsrfToken(session.csrfToken);
    if (state.user) { state.bootstrapRequired = false; await loadRoute(); }
    else { const bootstrap = await api('/bootstrap'); state.bootstrapRequired = bootstrap.required === true; state.trustedOwnerEmail = typeof bootstrap.trustedOwnerEmail === 'string' ? bootstrap.trustedOwnerEmail : ''; state.bootstrapConfigured = !!state.trustedOwnerEmail || bootstrap.configured !== false; renderAuth(); }
  } catch (error) { renderError(error, true); }
}

async function refreshSession() {
  const session = await api('/session');
  if (!session.user) throw new ApiError('登录状态未建立，请重新登录。', 'SESSION_MISSING');
  state.user = session.user;
  state.bootstrapRequired = false;
  setCsrfToken(session.csrfToken);
}

async function submitForm(form) {
  const action = form.dataset.form;
  const isDesignChat = action === 'design-conversation-message';
  if (form.dataset.submitting === 'true') return;
  const values = Object.fromEntries(new FormData(form));
  if (action === 'quick-project') { openProjectDialog(values.description?.trim() || '', captureDesignStart(form, state.user)); return; }
  const submit = form.querySelector('button[type="submit"]');
  const errorNode = form.querySelector('[data-form-error]');
  const originalContent = submit?.innerHTML;
  form.dataset.submitting = 'true';
  form.setAttribute('aria-busy', 'true');
  if (submit) {
    submit.disabled = true;
    if (isDesignChat) {
      submit.innerHTML = icon('loader-circle');
      submit.setAttribute('aria-label', '正在发送设计消息');
    } else submit.textContent = '正在提交…';
  }
  if (errorNode) { errorNode.hidden = true; errorNode.textContent = ''; }
  try {
    if (action.startsWith('settings-')) {
      await submitSettingsForm(action, form, values, adminContext());
    } else if (action === 'budgetreview-save') {
      await submitBudgetReview(form, values, adminContext());
    } else if (action.startsWith('operations-')) {
      await submitOperationsForm(action, form, values, adminContext());
    } else if (action.startsWith('case-')) {
      await submitCaseForm(action, form, values, adminContext());
    } else if (action.startsWith('budget-')) {
      await submitBudgetForm(action, form, values, adminContext());
    } else if (action.startsWith('media-')) {
      await submitMediaForm(action, form, values, adminContext());
    } else if (action.startsWith('publishing-')) {
      await submitPublishingForm(action, form, values, adminContext());
    } else if (action.startsWith('payment-')) {
      await submitPaymentForm(action, form, values, adminContext());
    } else if (action.startsWith('security-')) {
      await submitSecurityForm(action, form, values, adminContext());
    } else if (action.startsWith('design-')) {
      await submitDesignForm(action, form, values, adminContext());
    } else if (action.startsWith('membership-')) {
      await submitMembershipForm(action, form, values, adminContext());
    } else if (action.startsWith('hosting-')) {
      await submitHostingForm(action, form, values, adminContext());
    } else if (action.startsWith('functional-')) {
      await submitFunctionalForm(action, form, values, adminContext());
    } else if (action === 'pool-save' || action === 'pool-retention-review') {
      await submitPoolForm(form, values, adminContext());
    } else if (action.startsWith('admin-')) {
      await submitAdminForm(action, form, values, adminContext());
    } else if (['bootstrap', 'register', 'login'].includes(action)) {
      const body = { email: values.email.trim(), password: values.password };
      if (action !== 'login') body.name = values.name.trim();
      if (action === 'bootstrap' && values.token) body.token = values.token;
      await api(action === 'bootstrap' ? '/bootstrap' : `/auth/${action}`, { method: 'POST', body });
      await refreshSession();
      if (action === 'bootstrap') location.hash = 'admin';
      await loadRoute();
      toast(action === 'bootstrap' ? '平台所有者已创建' : action === 'register' ? '账户已创建' : '欢迎回来');
    } else if (action === 'create-project') {
      let project;
      if (form.dataset.createdProjectId) project = await api(`/projects/${encodeURIComponent(form.dataset.createdProjectId)}`);
      else {
        const result = await api('/projects', { method: 'POST', body: { name: values.name.trim(), description: values.description.trim() } });
        project = result.project || result;
        if (!project.id) throw new ApiError('项目已提交，但服务未返回项目 ID。请刷新项目列表确认。', 'INVALID_PROJECT_RESPONSE');
        form.dataset.createdProjectId = project.id;
      }
      const nextRoute = projectStart ? await finishDesignStart(project, state.user, projectStart) : `projects/${encodeURIComponent(project.id)}`;
      projectStart = null; closeModal(); navigate(nextRoute);
      toast('项目已创建');
    } else if (action === 'edit-project') {
      await api(`/projects/${encodeURIComponent(form.dataset.projectId)}`, { method: 'PATCH', body: { name: values.name.trim(), description: values.description.trim() } });
      await loadRoute();
      toast('项目更改已保存');
    } else if (action === 'profile') {
      await api('/profile', { method: 'PATCH', body: { name: values.name.trim() } });
      await refreshSession();
      await loadRoute();
      toast('个人资料已保存');
    }
  } catch (error) {
    if (errorNode?.isConnected) { errorNode.textContent = error.message; errorNode.hidden = false; }
    else toast(error.message || '操作未完成，请重试。');
  } finally {
    if (form.isConnected) {
      form.dataset.submitting = 'false';
      form.removeAttribute('aria-busy');
      if (isDesignChat) syncConversationComposer(adminContext());
      else if (submit) { submit.disabled = false; submit.innerHTML = form.dataset.pendingRequest === 'true' ? '查询原请求' : originalContent; }
    }
  }
}

document.addEventListener('submit', (event) => {
  const form = event.target.closest('form[data-form]');
  if (!form) return;
  event.preventDefault();
  submitForm(form);
});

document.addEventListener('click', async (event) => {
  const trigger = event.target.closest('[data-action], [data-filter]');
  if (!trigger) return;
  if (trigger.disabled) return;
  event.preventDefault();
  if (trigger.dataset.filter) { state.projectFilter = trigger.dataset.filter; renderCurrent(); return; }
  const action = trigger.dataset.action;
  if(action?.startsWith('workspace-') || ['choose-style','explore-direction','set-style','set-direction-option','reset-direction','apply-direction'].includes(action)) {
    try { await handleWorkspaceAction(action,trigger,{...adminContext(trigger),brand:platformBrand,projectCard,canOperate:canOperate(),sidebar,renderAccount:renderWorkspaceAccount,getDirection:()=>getDesignDirection(state.user),setDirection:value=>setDesignDirection(state.user,value),examples:dashboardInspirations}); } catch(error){toast(error.message||'操作暂未完成');}
    return;
  }
  if (action?.startsWith('settings-')) {
    try { await handleSettingsAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action === 'budgetreview-new') {
    try { openBudgetReview(trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('start-')) {
    if(state.route!=='home'){history.replaceState(null,'','#home');await loadRoute();}
    trigger.disabled = true;
    try { await handleDesignStartAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    finally { if (trigger.isConnected) trigger.disabled = false; }
    return;
  }
  if (action === 'maintenance-run') {
    try { await runMaintenance(trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('case-')) {
    try { await handleCaseAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('budget-')) {
    try { await handleBudgetAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('operations-')) {
    try { await handleOperationsAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('media-')) {
    trigger.disabled = true;
    try { await handleMediaAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    finally { if (trigger.isConnected) trigger.disabled = false; }
    return;
  }
  if (action?.startsWith('publishing-')) {
    try { await handlePublishingAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('payment-')) {
    try { await handlePaymentAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('security-')) {
    trigger.disabled = true;
    try { await handleSecurityAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    finally { if (trigger.isConnected) trigger.disabled = false; }
    return;
  }
  if (action?.startsWith('design-')) {
    const viewControl = action === 'design-conversation-toggle-preview' || action === 'design-visual-tab' ||
      action === 'design-conversation-fold' || action === 'design-conversation-earlier';
    if (!viewControl) trigger.disabled = true;
    try { await handleDesignAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    finally { if (!viewControl && trigger.isConnected) trigger.disabled = false; }
    return;
  }
  if (action?.startsWith('membership-')) {
    try { await handleMembershipAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('hosting-')) {
    try { await handleHostingAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action === 'notification-read') {
    try { await readNotification(trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('functional-')) {
    try { await handleFunctionalAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('pool-')) {
    try { await handlePoolAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action?.startsWith('admin-')) {
    try { await handleAdminAction(action, trigger, adminContext(trigger)); } catch (error) { toast(error.message); }
    return;
  }
  if (action === 'restart') return start();
  if (action === 'retry') return loadRoute();
  if (action === 'switch-auth') { state.authMode = state.authMode === 'login' ? 'register' : 'login'; history.replaceState(null, '', `/#${state.authMode}`); return renderAuth(); }
  if (action === 'new-project') return openProjectDialog();
  if (action === 'more-projects') {
    const cursor = state.resource?.nextCursor;
    if (!cursor || state.route !== 'projects') return;
    const epoch = routeEpoch;
    trigger.disabled = true;
    trigger.textContent = '正在加载…';
    try {
      const next = await api(`/projects?cursor=${encodeURIComponent(cursor)}`, { signal: routeController.signal });
      if (routeEpoch !== epoch || !state.user) return;
      const seen = new Set(rows(state.resource).map(project => project.id));
      state.resource = { ...next, items: [...rows(state.resource), ...rows(next).filter(project => !seen.has(project.id))] };
      state.workspaceProjects = state.resource;
      renderCurrent();
    } catch (error) { if (error.name !== 'AbortError') toast(error.message); if (trigger.isConnected) { trigger.disabled = false; trigger.textContent = '重新加载更多'; } }
    return;
  }
  if (action === 'close-modal') return closeModal();
  if (action === 'open-nav') { closeWorkspaceAccount(); mobileNav.innerHTML = sidebar(true); mobileNav.showModal(); return; }
  if (action === 'close-nav') return mobileNav.close();
  if (action === 'toggle-sidebar') {
    state.collapsed = !state.collapsed;
    try { localStorage.setItem('benos-ui-preferences-v1', JSON.stringify({ collapsed: state.collapsed })); } catch { /* Optional preference. */ }
    renderCurrent();
    return;
  }
  if (action === 'scroll-hosting') return document.querySelector('#billing-hosting')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  if (action === 'scroll-plans') return document.querySelector('#plans')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  if (action === 'logout') {
    closeWorkspaceAccount();
    state.workspaceBilling=null;state.workspaceProjects=null;state.workspacePrompt='';state.workspaceQuery='';state.workspaceTipDismissed=false;
    trigger.disabled = true;
    try {
      await api('/auth/logout', { method: 'POST', body: {} });
      state.user = null;
      state.resource = null;
      ++routeEpoch;
      routeController?.abort();
      setCsrfToken('');
      closeModal();
      if (mobileNav.open) mobileNav.close();
      state.authMode = 'login';
      renderAuth('你已安全退出。');
    } catch (error) { toast(error.message); if (trigger.isConnected) trigger.disabled = false; }
  }
});

document.addEventListener('change', event => {
  if (state.user && state.route === 'home') changeDesignStart(event.target, adminContext());
  if (state.route.startsWith('design/') && state.resource) handleDesignChange(event.target, adminContext());
  if (event.target.name === 'kind' && event.target.closest('form[data-form="admin-integration"]')) updateIntegrationFields(event.target.form);
  if (event.target.name === 'kind' && event.target.closest('form[data-form="admin-content"]')) updateContentFields(event.target.form, state.resource?.references);
  if (event.target.name === 'caseStateFilter') navigate('admin/payment-cases?state=' + encodeURIComponent(event.target.value));
  if (['contentKindFilter', 'contentStateFilter'].includes(event.target.name)) navigateContentFilter(adminContext());
});

document.addEventListener('input', (event) => {
  if(event.target.id==='project-idea')state.workspacePrompt=event.target.value;
  if(event.target.name==='workspace-project-search'){
    state.workspaceQuery=event.target.value;
    const list=document.querySelector('#project-grid');
    if(list)list.innerHTML=renderDashboardRecentProjects({projects:rows(state.resource),query:state.workspaceQuery,projectCard});
  }

  updateTopupPreview(event.target);
  if (state.route.startsWith('design/') && state.resource) rememberDesignDraft(event.target, adminContext());
  if (event.target.name !== 'project-search') return;
  state.query = event.target.value;
  const list = document.querySelector('#project-results');
  const projects = filteredProjects();
  if (list) list.innerHTML = projects.length ? `<div class="project-grid workspace-projects-grid">${projects.map(projectCard).join('')}</div>` : empty('没有找到匹配的项目', '试试其他名称或切换项目状态。', '', 'search');
});

modal.addEventListener('close', () => { if (modal.open) return; modal.replaceChildren(); if (lastModalFocus?.isConnected) lastModalFocus.focus(); });
modal.addEventListener('click', (event) => { if (event.target === modal && !modal.querySelector('[data-submitting="true"]')) { const bounds = modal.getBoundingClientRect(); if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) closeModal(); } });
modal.addEventListener('cancel', (event) => { if (modal.querySelector('[data-submitting="true"]')) event.preventDefault(); });
document.addEventListener('keydown', event => {
  if(state.user&&!state.route.startsWith('admin')&&!modal.open&&!event.isComposing&&(event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){const search=document.querySelector('[data-action=workspace-search]');if(search){event.preventDefault();search.click();}return;}
  if(event.target.id==='project-idea'&&event.key==='Enter'&&(event.ctrlKey||event.metaKey)&&!event.isComposing){event.preventDefault();event.target.form?.requestSubmit();return;}
  if (event.key !== 'Tab' || event.isComposing || event.defaultPrevented) return;
  const dialog = modal.open ? modal : mobileNav.open ? mobileNav : null;
  if (!dialog) return;
  const focusable = [...dialog.querySelectorAll('a[href],button,input,select,textarea,summary,[tabindex]')].filter(node => !node.disabled && node.tabIndex >= 0 && node.getClientRects().length && getComputedStyle(node).visibility !== 'hidden');
  const first = focusable[0], last = focusable.at(-1), current = document.activeElement;
  if (!first) { event.preventDefault(); dialog.setAttribute('tabindex', '-1'); dialog.focus(); return; }
  if (event.shiftKey && (current === first || !dialog.contains(current))) { event.preventDefault(); last.focus(); }
  else if (!event.shiftKey && (current === last || !dialog.contains(current))) { event.preventDefault(); first.focus(); }
});
mobileNav.addEventListener('click', (event) => { if (event.target.closest('a[href]')) mobileNav.close(); });
window.addEventListener('hashchange', loadRoute);
window.addEventListener('benos:session-expired', () => {
  if (!state.user) return;
  state.user = null;
  state.resource = null;
  ++routeEpoch;
  routeController?.abort();
  setCsrfToken('');
  closeModal();
  if (mobileNav.open) mobileNav.close();
  renderAuth('登录已过期，请重新登录后继续。');
});

start();
