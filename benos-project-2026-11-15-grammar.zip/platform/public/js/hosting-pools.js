import { api } from './api.js';
import { escapeHtml as e } from './icons.js';
const date=value=>value?new Date(value).toLocaleString('zh-CN'):'尚未核对';
const field=(label,name,value,type='text')=>`<label class="b-field"><span>${label}</span><input name="${name}" type="${type}" value="${e(String(value??''))}" required ${type==='number'?'min="1" max="100000" step="1"':'maxlength="80"'}></label>`;
const button=(text,action,id='',disabled=false)=>`<button type="button" class="ui-button ui-button--secondary" data-action="pool-${action}" data-pool-id="${e(id)}" ${disabled?'disabled':''}>${text}</button>`;
export async function loadHostingPools(options){
 const [pools,configs,retention]=await Promise.all([api('/admin/hosting-pools',options),api('/admin/integrations',options),api('/admin/hosting-retention',options)]);
 return {...pools,retention,configs:configs.items.filter(item=>item.kind==='hosting'&&item.publicConfig?.adapter==='hostinger-hpanel'&&item.status==='active'&&item.testStatus==='passed')};
}
function renderRetention(data,user){
 const items=data?.items||[],days=data?.minimumDays||30;
 return `<section class="b-section b-card"><div class="b-section-heading"><div><h2>暂停网站保留复核</h2><p>网站暂停后至少保留 ${days} 天。到期进入人工复核，不自动删除网站、文件或数据库，也不释放托管名额。</p></div></div>${items.length?`<div class="b-table-wrap"><table class="b-table"><thead><tr><th>网站 / 所属用户</th><th>最低保留日期</th><th>复核状态</th><th>操作</th></tr></thead><tbody>${items.map(row=>{const due=Date.parse(row.review_after)<=Date.now();return `<tr><td><strong>${e(row.name)}</strong><small>${e(row.domain)}</small><small>${e(row.email)}</small></td><td>${e(date(row.review_after))}<small>暂停于 ${e(date(row.suspended_at))}</small></td><td>${row.reviewed_at?'已复核，继续保留':due?'保留期已满，待复核':'保留期内'}${row.reviewed_at?`<small>${e(date(row.reviewed_at))}</small><small>${e(row.review_reason||'')}</small>`:''}</td><td><button type="button" class="ui-button ui-button--secondary" data-action="pool-retention-review" data-retention-id="${e(row.id)}" ${user.role!=='owner'||!due||row.reviewed_at?'disabled':''}>复核并继续保留</button></td></tr>`;}).join('')}</tbody></table></div>`:'<p class="b-muted">暂无需要保留复核的暂停网站。</p>'}</section>`;
}
export function renderHostingPools(data,user){
 const owner=user.role==='owner';
 return `<section class="s-page"><div class="s-page-heading"><div><h1>托管连接与容量</h1><p>A 账户满额后，新网站按优先级分配到 B；已有网站继续使用原连接。</p></div>${button('添加托管连接','new','',!owner)}</div><div class="b-notice"><div><strong>网站和数据库名额同时预占</strong><p>开通中、结果待核对和已暂停的网站继续占用名额。外部资源也计入占用；清单超过 15 分钟未核对或核对失败时停止新分配。上限请依据所购主机套餐填写。</p></div></div><div class="b-table-actions"><a class="ui-button ui-button--secondary" href="#admin/integrations">管理连接密钥与配置版本</a></div>${data.items.length?`<div class="b-table-wrap"><table class="b-table"><thead><tr><th>连接 / 优先级</th><th>网站名额</th><th>数据库名额</th><th>分配与核对</th><th>操作</th></tr></thead><tbody>${data.items.map(p=>`<tr><td><strong>${e(p.name)}</strong><small class="b-muted">${e(p.account_username)} · 订单 ${e(p.hosting_order_id)}</small><small>优先级 ${e(p.priority)}（数值越小越优先）</small></td><td>${p.external_sites+p.allocated} / ${p.max_sites}<small>平台 ${p.allocated}，其他 ${p.external_sites}</small><small>开通待完成 ${p.pending}</small></td><td>${p.external_databases+p.allocated} / ${p.max_databases}<small>可分配 ${p.available} 个网站</small></td><td><span class="b-badge">${p.state==='accepting'?'接收新网站':'停止新分配'}</span><small>${p.inventoryFresh?'清单有效':'需要核对清单'}</small><small>${e(date(p.observed_at))}</small>${p.sync_error?'<small>上次核对未完成</small>':''}</td><td><div class="b-table-actions">${button('配置','edit',p.id,!owner)}${button('核对清单','sync',p.id,!owner)}${button('所属网站','sites',p.id)}</div></td></tr>`).join('')}</tbody></table></div>`:'<div class="b-empty"><h2>尚未添加托管连接</h2><p>先在服务配置中保存、验证并启用 Hostinger 配置，再登记账号容量。</p></div>'}${renderRetention(data.retention,user)}</section>`;
}
export async function handlePoolAction(action,trigger,context){
 if(!action.startsWith('pool-'))return false;
 if(action==='pool-retention-review'){
  const item=context.state.resource.retention?.items.find(row=>row.id===trigger.dataset.retentionId);
  if(!item||context.state.user.role!=='owner'||Date.parse(item.review_after)>Date.now()||item.reviewed_at)throw Error('当前记录尚不能复核，请刷新状态。');
  context.showModal(`<div class="b-modal-header"><div><h2>复核并继续保留</h2><p>${e(item.name)} · ${e(item.domain)}</p></div><button type="button" class="ui-button" data-action="close-modal" aria-label="关闭">×</button></div><form class="b-modal-body" data-form="pool-retention-review" data-retention-id="${e(item.id)}"><p>最低保留日期：${e(date(item.review_after))}。本次仅登记继续保留；网站仍占用原托管名额，不删除文件或数据库。</p><label class="b-field"><span>复核原因</span><textarea name="reason" minlength="3" maxlength="1000" required></textarea></label><p class="b-form-error" data-form-error role="alert" hidden></p><div class="b-form-actions"><button type="button" class="ui-button" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">确认继续保留</button></div></form>`);return true;
 }
 const pool=context.state.resource.items.find(row=>row.id===trigger.dataset.poolId);
 if(action==='pool-sync'){
  trigger.disabled=true;try{await api(`/admin/hosting-pools/${encodeURIComponent(pool.id)}/sync`,{method:'POST',body:{}});await context.reload();context.notify('托管资源清单已核对');}finally{if(trigger.isConnected)trigger.disabled=false;}return true;
 }
 if(action==='pool-sites'){
  const result=await api(`/admin/hosting-pools/${encodeURIComponent(pool.id)}/sites`);
  context.showModal(`<div class="b-modal-header"><div><h2>${e(pool.name)} · 所属网站</h2><p>显示本平台分配的网站，其他占用通过资源清单核对。</p></div><button type="button" class="ui-button" data-action="close-modal" aria-label="关闭">×</button></div><div class="b-table-wrap"><table class="b-table"><thead><tr><th>网站</th><th>所属用户</th><th>状态</th></tr></thead><tbody>${result.items.map(s=>`<tr><td>${e(s.name)}<small>${e(s.domain)}</small></td><td>${e(s.email)}</td><td>${e(s.state)}<small>${e(s.job_state)}</small></td></tr>`).join('')||'<tr><td colspan="3">暂无分配记录</td></tr>'}</tbody></table></div>`);return true;
 }
 const item=pool||{},configs=context.state.resource.configs.filter(c=>!pool||(c.publicConfig.accountUsername===pool.account_username&&c.publicConfig.hostingOrderId===pool.hosting_order_id));
 if(!configs.length)throw Error('请先在服务配置中验证并启用对应 Hostinger 连接。');
 context.showModal(`<div class="b-modal-header"><div><h2>${pool?'配置托管连接':'添加托管连接'}</h2><p>不同账号分别登记；密钥版本变更只影响后续分配。</p></div><button type="button" class="ui-button" data-action="close-modal" aria-label="关闭">×</button></div><form class="b-modal-body" data-form="pool-save" data-pool-id="${e(item.id||'')}" data-revision="${item.revision||0}">${field('连接名称','name',item.name||'')}
 <label class="b-field"><span>已验证的配置版本</span><select name="configId">${configs.map(c=>`<option value="${e(c.id)}" ${c.id===item.config_version_id?'selected':''}>${e(c.name)} · v${c.version} · ${e(c.publicConfig.accountUsername)}</option>`).join('')}</select></label>
 <div class="b-form-grid">${field('网站名额上限','maxSites',item.max_sites||100,'number')}${field('数据库名额上限','maxDatabases',item.max_databases||100,'number')}</div><label class="b-field"><span>分配优先级（0 最优先）</span><input type="number" name="priority" min="0" max="10000" step="1" value="${item.priority??100}" required></label><label class="b-field"><span>新网站分配</span><select name="state"><option value="draining" ${item.state!=='accepting'?'selected':''}>停止新分配，保留已有网站</option>${pool?`<option value="accepting" ${item.state==='accepting'?'selected':''}>接收新网站</option>`:''}</select><small>新连接或更换密钥后，保存并核对清单，再开启新分配。</small></label><label class="b-field"><span>操作原因</span><textarea name="reason" minlength="3" maxlength="500" required></textarea></label><p class="b-form-error" data-form-error hidden></p><div class="b-form-actions"><button type="button" class="ui-button" data-action="close-modal">取消</button><button type="submit" class="ui-button ui-button--primary">确认保存</button></div></form>`);return true;
}
export async function submitPoolForm(form,values,context){
 if(form.dataset.form==='pool-retention-review'){
  const result=await api('/admin/hosting-retention/'+encodeURIComponent(form.dataset.retentionId)+'/review',{method:'POST',body:{decision:'retain',reason:values.reason.trim()}});
  if(result.reviewed!==true||result.decision!=='retain'||result.deleted!==false)throw Error('复核结果未确认，请刷新后核对。');
  context.closeModal();await context.reload();context.notify('已登记继续保留，托管名额保持占用');return;
 }
 const body={name:values.name.trim(),configId:values.configId,maxSites:Number(values.maxSites),maxDatabases:Number(values.maxDatabases),priority:Number(values.priority),state:values.state,reason:values.reason.trim()};
 if(form.dataset.poolId)body.revision=Number(form.dataset.revision);
 await api('/admin/hosting-pools'+(form.dataset.poolId?'/'+encodeURIComponent(form.dataset.poolId):''),{method:form.dataset.poolId?'PATCH':'POST',body});
 context.closeModal();await context.reload();context.notify('托管连接配置已保存');
}
