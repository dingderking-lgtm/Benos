# 网站管理与原生预览

网站详情提供已签名验证的公开网址与 `/admin` 入口。尚未完成域名/HTTPS/独立 CMS 身份验证时不提供已就绪入口。托管暂停不会删除网址或网站数据，入口会显示真实服务暂停页。

## 单站管理暂停

平台 owner 可填写原因明确暂停或恢复单站。它是独立的站点管理操作：明确暂停该站时包括该站的年付托管服务；会员冻结仍只影响随会员提供的托管，不能隐式暂停独立年付。暂停不暂停收费账期、不自动退款、不删除数据、不释放资源。恢复要求重新核对有效权益和签名租约。CMS 尚未回执时保留 uncertain，不能仅依据本地按钮显示恢复成功。

持久管理标志纳入定时租约同步，定时维护不会自动撤销单站管理暂停。发布接口立即拒绝有管理暂停标志的站点。实际 CMS 生效以签名租约为准；无法连接的暂停最多受先前六小时租约剩余时间约束。普通用户无暂停/恢复接口权限。后台动作保留原因、操作者和幂等请求，不修改历史付款和托管权益记录。

## 域名与必要记录

用户可申请更换域名，平台先预留域名并给出 `_benos-verification` TXT。未验证前不调用主机变更。Web/Cloud hPanel 的官方接口支持同站 parked domain 别名；本实现将新域名绑定到原物理站点，保留原域名，不另建站点、数据库或管理账户，不调用 Agency 产品的改域名接口。

平台在 POST 别名前保存意图，丢失响应后先 GET 核对同一账号、原父域名及目标域名，不盲目重复开户。成功别名、公开 DNS、HTTPS 和同一 CMS 的签名健康响应均通过后，签名通知 CMS 使用原生 SiteAddress 原子修改 app_url，再更新平台连接。原域名及其 DNS 应继续保留，避免破坏别名。恢复未知状态时重复原始变更只会核对同一目标。原生 CMS 常规后台的站点根地址修改已要求走平台流程。

本实现不默认取得 DNS 写权限，不修改邮件、MX、第三方验证或用户域名记录。后台 owner 可以为每个托管连接配置从该账户实际核对的 A/AAAA 目标，必须注明核对来源；这些是人工确认的连接配置，保存不代表域名已解析或 HTTPS 成功。前端据此显示白标必要记录。缺少目标时，新域名给出指向原域名的 CNAME 提示；根域需 DNS 服务商支持扁平化，或由平台核对 A 目标，不推测服务器 IP。首次开站缺少解析目标时仍等待配置。

定时维护每轮轮转核对五条待完成域名任务；用户可手动重新核对。已尝试但供应商尚未列出的别名保持待核对，由平台排查原请求结果。没有真实 Hostinger 凭据的本地 fixture 只证明协议与恢复逻辑，不证明目标账户允许别名、证书安装或 DNS 修改。

官方 HTTP 合同依据：[Hosting Domains](https://github.com/hostinger/api-php-sdk/blob/main/docs/Api/HostingDomainsApi.md)、[Hosting SSL](https://github.com/hostinger/api-php-sdk/blob/main/docs/Api/HostingSSLApi.md)。供应商接口固定为官方 origin。

## CMS 原生预览

目标为受管 AACMS 1.9.21；平台传递同一 manifest 原文、私有素材真实字节和页面 key，返回 CMS 版本及该 manifest 的 SHA256。PHP 使用原生 SitePackageService 检查器、原生导入器引用重写和 Renderer::pageHtml；博客归档、文章与作者由原生 BlogRenderer 生成。运行前后数据库事务回滚，不发布设计、不保存草稿、不创建询盘或改变客户业务内容。自增 ID 可能留下空号；受管预览通过限定钩子跳过公开 CSS 缓存写入，样式以内嵌原字节提供。私有传输与预览产物在各自临时目录保存，客户业务表行和公开文件保持不变。

预览明确使用 manifest 示例数据：既有客户文章、作者资料、表单、字段与系统设置在本次事务视图中隔离；无文章/作者时显示标示为示例的文章与编辑部。预览不能作为“客户现有内容与确认稿逐像素一致”的证明。既有 CMS 的文章和手工草稿继续按发布规则保留。每份真实设计仍需原生导入、编辑、发布及响应式验收。

平台仅允许同用户同项目已连接的 CMS 提供该项目原生预览。目标尚未连接时返回 NATIVE_PREVIEW_NOT_CONNECTED，不把静态设计预览标成原生验证。受签名的 preview 操作独立于托管租约，因此月租到期后保留的充值仍能用于设计预览；公开网站、后台写入和发布仍受租约限制。

原生清洗会移除模板脚本与事件属性，返回清洗变化摘要。V2 仅允许三个固定 CMS 交互脚本的 SHA256，移除表单提交脚本；CSP 禁止网络调用、表单提交与外部脚本，iframe 只用 sandbox allow-scripts，禁止 allow-same-origin。预览图片使用本预览专属的临时授权地址，不依赖隔离 iframe 的登录 cookie；取消、到期、账户限制或项目归档后拒绝读取。PDF 不内嵌、不取得图片授权。

V2 支持 ZIP 74 MiB（含目录开销）、清单 10 MiB、素材累计 64 MiB。上传 CMS 和回取产物按最多 1 MiB 分块推进；中断后保持原任务、原步骤和签名身份，后台只能继续准备预览，不能自动采用或发布。每位用户同时最多保留 4 份未清理任务。旧版小包预览接口保留原 6 MiB 素材、8 MiB HTML 边界；目标 CMS 未声明 V2 能力时明确要求升级。

平台核对 CMS 实际处理后的图片字节：哈希和大小完全相同才可引用原素材；重编码 PNG/JPEG/WebP 和清洗 SVG 回传并缓存实际副本，动画 GIF 只有核对相同后才复用。单个派生产物最多 16 MiB、SVG 1 MiB，派生图片合计最多 96 MiB，HTML 最多 16 MiB；含当前拼装分块的临时缓存最多 128 MiB。用户素材上传上限仍为 12 MiB，并未扩大为 16 MiB。

CMS 内部产物保留最多 6 小时，供长任务中转；预览完成时才开始最多 30 分钟的用户可访问期。平台任务总期限为 24 小时，缓存完成后清理远端产物。平台不把临时授权 URL、完整 HTML 或供应商密钥写入浏览器持久存储。浏览器关闭不等于取消任务；明确取消后立即停止对外读取，后台再清理私有暂存文件。

任务接口为 `POST /api/design/projects/:project/native-preview-jobs`，以及 `GET /api/design/native-preview-jobs/:id`、`POST /:id/continue`、`POST /:id/cancel`。协议见 `cms-connector/PREVIEW-V2-PROTOCOL.txt`，验收证据见 `docs/VERIFICATION.md` 与 `docs/CAPACITY-UI-VERIFICATION.md`。

接口：`GET /api/hosting-management/sites/:id`，owner 的 `GET /sites`、`POST /sites/:id/pause|resume`，站主的 `POST /sites/:id/domain-changes` 与 `POST /sites/:id/domain-changes/:changeId/reconcile`。owner 的 `GET /dns-targets`、`PUT /pools/:id/dns-targets` 管理必要解析目标。不存在普通删站、删库或删历史记录接口。
