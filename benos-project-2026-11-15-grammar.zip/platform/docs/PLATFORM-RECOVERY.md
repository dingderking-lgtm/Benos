# Benos 平台离线备份与恢复

这个工具处理 **平台 D1 数据与 R2 私有对象副本**。它不连接 Cloudflare，不导出线上数据库，不下载线上 bucket，不修改正式绑定，不重放付款、邮件、AI 或 CMS 任务。它与 `cms-connector` 的单站 MySQL 备份不同。

要求 Node.js **24.10 或更新版本**，使用内置 SQLite 授权器；当前验证环境为 24.12.0。先按发行包锁文件执行 `npm ci`，共享模板预检使用项目已有的 parse5 HTML 解析器。此 Node 要求仅针对离线运维工具。

## 先取得一致的输入

1. 记录正式代码/迁移版本及平台绑定，在受控环境保管 `ENCRYPTION_KEY`。数据库里的供应商配置、邮件负载、开站密码与 CMS 连接密文离开原主密钥就无法解密。主密钥不能放进备份目录、命令参数、终端输出或聊天。
2. 启用平台 `RECOVERY_MODE=true`，停止新流量、回调消费和 scheduled 处理。**环境切换不会终止已在途请求。** 等待正在调用供应商、处理付款、邮件、开站、发布及租约同步的任务完成或进入可核对状态，记录不确定任务。不要为“清理状态”释放预占或重建任务。
3. 取得两次独立 D1 导出并核对 schema、逐表行数与内容摘要一致；在其间取得完整 R2 对象清单与对象字节，再核对两次清单一致。仍有变化就继续排查写入来源，不能把 `--quiesced` 当成自动停机证明。
4. 使用当前 Cloudflare 官方工具导出 SQL，例如 `npx wrangler d1 export benos-db --remote --output=database.sql`。D1 的 `DB.dump()` 仅支持旧 alpha 数据库，不能给当前生产 D1 假设这个接口可用。Sites 托管底层账户权限另行确认，不能假设能运行该命令。[D1 导入导出](https://developers.cloudflare.com/d1/best-practices/import-export-data/)、[D1 dump 限制](https://developers.cloudflare.com/d1/worker-api/d1-database/#dump)。
5. R2 副本目录必须按真实对象键组织，例如 `r2/private/users/.../original.png`、`r2/private/users/{用户}/projects/{项目}/manifests/{对象ID}/{SHA256}.json`、`r2/private/image-jobs/.../response.json`、`r2/private/cms-releases/...zip`。需要遍历完整分页，不能只备份数据库当前引用的素材；清单或图片响应可能已保存而数据库确认尚未完成。R2 list 应按 `truncated/cursor` 继续，下载后计算实际字节 SHA256。[R2 API](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/#r2objects)。

工具不会从在线 Wrangler 的 `.wrangler` 原始文件中猜测绑定。SQLite 输入必须是静默且已 checkpoint 的独立文件；非空 `-wal` 或 `-journal` 会被拒绝。SQL 输入上限 256 MiB，超过时先用可信 SQLite 工具导入一个独立离线库，再交本工具。SQL 导入禁止 ATTACH、虚拟表、扩展加载及文件读写函数，不允许向其他路径写入。

## 创建、验证和恢复

在 Benos 工程根目录运行。以下路径只是示例，目标父目录须已存在，目标目录本身必须不存在：

```powershell
node scripts/platform-recovery.mjs backup --database D:/BenosBackups/input/database.sql --objects D:/BenosBackups/input/r2 --metadata D:/BenosBackups/input/r2-metadata.json --output D:/BenosBackups/snapshot-001 --quiesced
node scripts/platform-recovery.mjs verify --bundle D:/BenosBackups/snapshot-001
node scripts/platform-recovery.mjs restore --bundle D:/BenosBackups/snapshot-001 --output D:/BenosRestore/rehearsal-001
```

`ENCRYPTION_KEY` 必须已经由受控环境注入。工具只读取它来验证现存 AES-GCM 密文和签署/核验备份清单，不输出密钥，也不将密钥写进目录。任何现存密文不能解密都会阻止备份；错误密钥或被修改的备份清单会阻止恢复。备份包含个人信息及加密运行配置，应放在受限、加密的存储设备，不得放进公开目录或源码交付包。

`--metadata` 可选。文件格式为 `{ "真实对象键": { "httpMetadata": {...}, "customMetadata": {...} } }`，提供时必须覆盖全部对象。省略时，工具只能根据扩展名重建内容类型、`private, no-store` 与实际 SHA256；清单明确记录 `reconstructed-private-defaults`，**不宣称完整保留原 R2 元数据**。恢复输出 `r2-metadata.json`，上传到隔离 bucket 时必须同时应用。对象 ETag/version/上传时间由 R2 重建，不是内容摘要。

备份产物是一个受签名清单约束的目录包：`database.sqlite`、`objects/<SHA256>.bin` 和 `manifest.json`。相同字节对象仅存一份，清单保留每个原键。符号链接、硬链接、不安全路径、大小写冲突、清单外文件会被拒绝。最大 100,000 个对象。

恢复产物是全新目录，包含 `database.sqlite`、可导入 D1 的 `database.sql`、按原键展开的 `r2/`、元数据、审计报告和 `RECOVERY-MODE-REQUIRED.txt`。不覆盖已有空目录，也不覆盖已有文件。进程中断可能留下不完整的新目录，必须核对报告与完整清单；不能把部分复制当作恢复成功。

## 实际核验内容

- SQLite 完整性、外键、schema 摘要与每张表的确定性行摘要，整数以 BigInt 读取，避免金额舍入。
- 预占拆分总额、用户归属、每个额度批次的已消费/持有额度、供应商池资金入账减已确认扣减、供应商消费及预占、人工冲销净额。运营测试预算的 held/settled 也纳入同一供应商池，并独立核对预算和事件记录；未确认预占原样保留，不自动返还。
- 项目当前/已发布版本必须属于本项目；历史版本和候选草稿的完整模板结构有效，候选拥有者、原版本与采用后的版本必须属于同一项目，采用内容摘要与原版本关系必须一致；设计资源须匹配同项目素材的 SHA256、字节数和扩展名。
- 旧版 `manifest_json` 内联清单继续读取；`manifest_object_id` 非空时必须指向 `ready` 的 `design_manifest_objects`，其拥有者、项目、对象 ID、私有路径、完整字节 SHA256 和大小必须一致。`versions.content_hash` 比较完整 R2 清单的摘要，不是 D1 小索引摘要。版本和候选的小索引必须与对象行的 `index_json` 完全相同；工具从实际 JSON 重新计算素材列表及网站、页面、模板摘要，拒绝缺漏或过期索引。
- 每个已登记的 `ready` 清单对象都必须存在，包括尚未被版本引用的对象。原子导入在最终提交前失败时，可留下尚未被任何版本或候选引用的 ready 对象；这些对象仍须通过真实字节、SHA256、大小、模板结构和小索引核验，但允许其素材尚未入库。一旦被任何版本或候选引用，素材归属、记录和对象必须完整，不能借孤立对象规则绕过。无引用的 `staging`、`purging`、`purged` 记录允许对象暂缺；已有字节仍核对大小、SHA256、模板与索引。任何非 `ready` 状态均不可被设计版本或候选引用。恢复保留这些原状态和清理记录，不重试上传、不重新执行清理，也不把它们改成可用版本。
- 所有 ready/deleted 项目素材和营销内容素材、图片原始响应、配置引用的 CMS 发行包必须存在且匹配已记录摘要与大小；营销草稿/发布快照中的封面 ID 必须仍指向已保存的素材记录。未完成 staging 记录允许尚无对象，已存在的 staging 对象仍核对摘要，保留原状态。
- 现有配置、站点连接、开站意图、引导密钥和邮件负载按原上下文解密验证；不输出解密结果。未知密文列上下文会明确拒绝，需更新对应版本的运维工具。
- 分块模板上传和原生预览持久任务保留原状态、原租约与进度。工具核对拥有者/项目/网站、版本或候选来源、固定私有路径、每块大小与连续顺序、已确认字节数、实际对象 SHA256。仍在使用的已确认分块及完整产物不能缺失；确认清理后的记录允许暂存字节已删除，若仍存在则继续核验。恢复不会自动续传、创建预览、采用设计或重发 CMS 操作。

备份包格式仍为 `benos-platform-recovery` v1，审计结果原字段保持不变。旧包不需要新增对象表或迁移回填才可离线验证；新表存在时执行上述额外关联校验。离线恢复不会自动升级旧数据库，代码和迁移版本仍须与原快照对应。`tests/platform-recovery.test.ts` 保留旧内联、真实 SQLite/SQL 往返和命令行验证，并加入大清单对象、候选关联、损坏对象、越权路径、索引失配及清理记录的专项检查。

这证明副本内部一致，不证明外部付款/供应商余额/CMS 线上状态与快照一致。无凭据测试使用独立临时数据库和本地对象文件，不连接生产 D1/R2。生产导出、远端导入和切换仍需目标账户验收。

2026-11-07 的恢复专项为 **16/16**，失败/跳过均为 0，执行记录见 `qa/platform-manifest-recovery-tests.log`。大清单由实际存储函数写入独立 SQLite 与模拟 R2 后，再导出对象字节交给恢复 CLI；包含恰好 **10,485,760 字节（10 MiB）** 的上限清单。这个计数包含原有恢复回归，不应再与此前 9/10/14/15 项阶段结果相加。

随后加入分块上传及原生预览恢复，三个测试文件当时合计 **18/18** 通过（16.45 秒）。验证已确认但尚未完成的 1 MiB 分块能在 SQLite/对象恢复后保持原进度；缺块、损坏字节和虚构进度会拒绝备份；已清理记录可恢复。此阶段结果包含上述 16 项，不另外相加。新存储的 ETag 不能沿用旧值，见下面的独立重绑定步骤；真实目标环境仍须核对条件读取，不能直接解除维护模式。

## v19 编辑数据的恢复边界

0041 的小投影缓存核对原版本或候选身份、完整源摘要、字节数和缓存摘要；按版本 ID 恢复的收据核对请求摘要、原版本、父版本和结果版本。恢复保留当前 head，不根据旧收据再执行一次历史恢复。

0042 的 AI 编辑工作区核对拥有者、原版本、范围、剥离 HTML/CSS 后的原蓝图、每个文件的原始/当前私有对象、修订及素材引用。活动工作区的 ready 对象必须存在并与 SHA256/大小一致。文件中的中间 HTML、CSS 可以尚未完成，不能拿最终整站验收规则拒绝这类备份。工作区清理后的文件、蓝图及校验缓存允许缺失；完整 AI response/tool 回执仍必须保留，校对已完成步骤的 call_id 与工具名，摘要不能代替原回执。未知结果、尚未落盘的 staging 意图可以继续保持原状态，原费用预占不自动释放。

0043 的高级 JSON 编辑核对源版本、每个分块/片段的归属、精确偏移、已确认上传进度、片段字节数及操作修订。编辑中可以存在无效 JSON，甚至空片段；它仍是私有编辑副本，不能变成公开素材或已保存网站。活动 ready 对象缺失、摘要错误或虚构进度会阻止恢复。已取消、过期、失败或已保存任务的清理墓碑允许临时对象已删除；任何仍存在的字节继续核对。保存结果必须指向本项目的真实历史版本，清理编辑缓存不删除该版本。0044 的派发权限触发器原样保留，不因恢复重新派发已经关闭的工作区任务。

## 新私有存储的 ETag 重绑定

R2 的 ETag 是供应商给出的不透明对象标识，不能用 SHA256 或本地文件时间自行计算。模板上传、原生预览和 JSON 编辑的条件读取会使用持久化 ETag；对象重传到新 bucket 后，旧 ETag 可能使正确字节也被拒绝读取。

先保持 `RECOVERY_MODE=true`，把恢复目录的所有对象和元数据上传到新的私有存储。通过目标账户受控工具重新读取每个对象的真实 ETag、大小，并下载或以可信字节流核对 SHA256，形成以下清单。清单必须完整覆盖恢复目录 `r2/` 中全部对象；工具不代替远端核对，不猜测 ETag，不联网。

```json
{
  "format": "benos-restored-etags",
  "version": 1,
  "objects": [
    {"key": "private/实际对象键", "size": 123, "sha256": "64位实际字节摘要", "etag": "目标存储实际返回的ETag"}
  ]
}
```

```powershell
node scripts/platform-recovery.mjs rebind-etags --restored D:/BenosRestore/rehearsal-001 --etags D:/BenosRestore/target-etags.json --output D:/BenosRestore/rehearsal-001-rebound
```

命令只写一个**全新离线目录**，原恢复目录保持不变。它重新校验库、对象和密文，再在副本事务中仅重绑定实际依赖 ETag 的五类记录：`manifest_edit_objects`、`package_upload_chunks`、`package_upload_entries`、`native_preview_chunks`、`native_preview_artifacts`。对应不可变触发器仅在副本事务内暂时移除，更新后按原 SQL 恢复；schema 必须相同，除这些 ETag 列外逐表数据摘要必须不变。缺失对象、清单不完整、SHA256/大小不符、错误主密钥或已存在的目标目录均拒绝。已经清理且无对象的墓碑不凭空生成 ETag。

输出包含新的 `database.sqlite`/`database.sql`、原对象与元数据、`target-etags.json`、保留恢复模式的标记和重绑定报告。报告明确 `remoteProviderVerified: false`，因为远端清单的真实性由目标账户核验步骤负责。**应将重绑定后的 SQL 导入新的空 D1**，然后用正式读取路径验证；不能导入旧 SQL 后直接解除恢复模式。若再次搬运对象而 ETag 改变，应重新采集清单并生成另一个新副本。

本轮恢复专项涵盖旧数据回归和上述新编辑链。`qa/platform-v19-recovery-tests.log` 记录实际执行结果；测试以有付款、已结算消费、未知预占、设计版本及私有素材的独立 SQLite/R2 字节夹具证明恢复，再让正式编辑读取函数验证“旧 ETag 失败、重绑定后成功”。模板上传/原生预览分块也验证重绑定与触发器恢复。它没有执行真实 Cloudflare 导出、上传、远端导入或账户切换。

## 受控切换

先将 SQL 导入**新的独立空 D1**，对象上传到**新的隔离私有 bucket**，用相同代码/迁移和原主密钥在 `RECOVERY_MODE=true` 下核对。保留原数据库、原 bucket、原代码与旧快照，不覆盖线上库演练。导入后再次检查外键、逐表计数/摘要与对象字节，不能仅凭 SQL 命令退出码判成功。

清点未确认 AI 费用、付款/退款、CMS 已执行操作、邮件投递和所有租约。以原 idempotency key/provider identity 对账，完成前不恢复自动任务。恢复旧数据库无法撤销已经发生的外部扣费，禁止自动释放旧预占或重发未知邮件。账号会话需要按事件风险处理；仅更换 `SESSION_SECRET` 不会自动使现有数据库会话失效。

确认副本与外部状态后由平台运营者进行独立绑定切换，再明确解除恢复模式。工具不提供自动上线或恢复模式解除命令。
