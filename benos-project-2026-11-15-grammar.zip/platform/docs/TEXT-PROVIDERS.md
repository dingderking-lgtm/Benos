# 文本 AI 提供方接入与计费合同

核验日期：2026-11-13。以下是本地已实现的协议与安全边界；没有使用真实密钥调用收费接口。实际账户权限、余额、限流、账单以及真实生成质量，需要管理员在独立配置版本上完成只读验证、确认费用上限的小额功能测试与账单核对后启用。

## 已审核配置

价格单位为 **USD / 1,000,000 tokens**。数据库金额采用整数 micro-USD：1 USD = 1,000,000 micros；`inputMicrosPerMillion` 等配置字段表示每百万 token 的 micro-USD，不能直接填人民币或表格里的小数 USD。

|provider|model|baseUrl|protocol|上下文|应用输出上限|普通输入 / 缓存读 / 输出|参考图片|
|---|---|---|---|---:|---:|---|---|
|openai|gpt-6.1-sol|https://api.openai.com/v1|responses|1,050,000|128,000|2 / 0.1 / 10|支持|
|openai|gpt-6-sol|https://api.openai.com/v1|responses|1,050,000|128,000|2 / 0.2 / 10|保留应用原有限制，暂不开放|
|deepseek|deepseek-flash|https://api.deepseek.com|responses|1,048,576|384,000|0.3 / 0.006 / 1.2（峰值）|支持|
|deepseek|deepseek-v4-pro|https://api.deepseek.com|responses|1,048,576|384,000|1.32 / 0.044 / 3.96（峰值）|不支持|
|moonshot|kimi-k3|https://api.moonshot.ai/v1|chat-completions|1,048,576|131,072|3 / 0.3 / 15|支持|

配置的 `maxOutputTokens` 可以低于表格上限，最小 16。Kimi 官方建议多步工具任务保留至少 16,000 输出 token，包含推理与正文；低于此值仍受硬限制保护，但更容易耗尽输出而不能完成方案。模型名、地址、协议、上下文、价格、缓存期限和 provider 必须一起匹配审核版本；审核前不能通过“兼容 OpenAI”绕过账本限制。

|提供方|billingProfile|cacheTtl|缓存写入规则|
|---|---|---|---|
|OpenAI|openai-gpt6-standard-2026-11-07|30m / 12h|30m 为输入价 1.25 倍，12h 为 2.5 倍；长输入超过 272,000 时输入/缓存费用翻倍，输出为 1.5 倍|
|DeepSeek|deepseek-v4-standard-2026-11-13|automatic|不套用 OpenAI 缓存写入字段；根据实际命中输入与未命中输入结算|
|Kimi 国际站|moonshot-k3-standard-2026-11-13|5m / 1h|5m 写入 3 USD/M、1h 写入 6 USD/M；写入、缓存读、普通输入是互斥分区|

Kimi 目前仅接入国际站 USD 账户，`api.moonshot.cn` 不在本计费合同内。不能复用国际站价格，也不能自动切换账户或币种。官方已经提供 K3.1 Pro，但本次公开资料未确认其 1h 缓存写入价；缓存期限可能沿用已有条目，不能仅凭请求 5m 就忽略 1h 风险，因此该模型暂未批准进入真实派发。取得完整官方计费证据后应增加独立审核版本及边界测试。

## 选择、持久化与资金

- 每个配置使用自己的加密凭据与 `providerPoolId`；资金池应按真实提供方账户分别登记。多个 text 提供方可同时启用，选择 `configId` 后不会自动切到另一家。
- `GET /api/ai/options` 返回可选配置及是否支持参考图，不返回地址、密钥或资金池信息。发送消息、工作流报价和创建支持可选 `configId`；旧客户端未选择时使用 `created_at DESC, id DESC` 的稳定默认值。
- 工作流保存 `config_version_id`、`provider_id` 和完整审核后的 `pricing_json` 快照。相同 `requestKey` 改变 `configId` 或内容会返回幂等冲突；已存在请求即使配置后来停用仍返回原记录，不重新收费派发。
- 派发前在同一账本事务中预占用户可用额和对应供应商资金池；任务总预算、每步预算和输出 token 硬限制同时生效。逐轮结算，再允许下一轮。人工对账不能令原请求重新发出。
- 预占采用完整上下文的最坏已核验费率，包含最大输出，而不是根据字符数猜 token。Kimi 即使选择 5m 也按已核验的 1h 写入上限预占。该方式有意保守，会比实际小请求费用高。
- 当 `maxOutputTokens=10000` 时，单轮上限示例：GPT-6.1 Sol/30m 为 5,400,000 micros；DeepSeek Flash 为 326,573 micros；Kimi K3 为 6,441,456 micros。实际结算依据供应商完整用量，不按预占金额直接收费。

## 各家收据与未知费用

`text-provider-adapter.ts` 仅将输出转换到现有设计引擎结构，保留供应商原始 `usage`。`ai-billing.ts` 分开验证三家字段，使用 BigInt 分子计算，最后一次向上取整到 micro-USD。

**OpenAI Responses** 保留原应用合同：`input_tokens`、`output_tokens`、`input_tokens_details.cached_tokens`、`cache_write_tokens` 及 30m/12h 分项。长期缓存、长上下文、输出推理 token 和未知计费字段都会核验。

**DeepSeek Responses** 使用 `input_tokens`、`output_tokens`、`total_tokens`、`input_tokens_details.cached_tokens` 及可选 `output_tokens_details.reasoning_tokens`。供应商 Search/Fetch 等收费工具未开放，出现非零 `server_tool_use` 保留预算待对账。峰值为 UTC 工作日 01:00–04:00、06:00–10:00，排除中国公共假期；全部周末仍按低谷，低谷为峰值价格的一半。

DeepSeek 的官方文档未明确跨切换窗口的费用归属。本系统用服务端记录的请求开始/读取完成时间，加入 5 秒时钟容差，检查整个窗口处于同一费率段；跨窗口不猜费用。2026、2027 年假期有已核验日历；之后年份必须先更新审核，派发前即拒绝未知年度，已派发但无法确认的用量保留预占。服务端记录的 `_benosMetering` 覆盖模型同名字段，不能信任供应商 JSON 中自带的时间证据。

**Kimi Chat Completions** 使用 `prompt_tokens`、`completion_tokens`、`total_tokens`、`prompt_tokens_details.cached_tokens`、`cache_write_tokens`，可选顶层 `cached_tokens` 必须一致。发生缓存写入时，必须读取 `Msh-Usage-Cache-Write-Tokens-5m` 和 `Msh-Usage-Cache-Write-Tokens-1h` 响应头，分项合计必须等于写入 token。请求的 TTL 不是实际写入 TTL 的证据。

已收到的结构化响应在费用校验前持久化；大设计通过已有私有对象存储保存完整收据。用量字段缺失、模型不符、跨峰谷、缓存头缺失、HTTP/网络中断等都不会被记作免费，也不会自动重试原 HTTP 请求。账本保留用户与供应商的预占，管理员根据外部账单和响应 ID 人工核对。新的未知计费字段必须先更新审核逻辑，不能悄悄忽略。

## 流式、对话与参考图

- `stream: true` 支持供应商 SSE，缺省为非流式。OpenAI/DeepSeek 等待终态 `response.completed/incomplete/failed` 的完整响应；Kimi 聚合文本和工具参数，要求最终 usage 块与 `[DONE]`。仅有 delta 不执行工具、不结算，也不会把中断当成功。
- 服务端按字节限制读取，异常会取消流。工作流默认 JSON 上限 600,000 字节；旧整站生成可显式使用 3 MiB；流上限为对应 JSON 上限的 4 倍。前端仍使用现有任务状态与历史接口，支持供应商流协议不代表浏览器逐 token 展示。
- Kimi 多轮工具调用需要回传 `reasoning_content` 和原工具 ID。这些保存在私有收据/历史中，公开对话只读取经过清洗的 assistant 正文和已成功完成的方案摘要，源码、内部工具及推理不进入聊天正文。
- DeepSeek 可能返回并行函数调用，服务端按返回顺序执行已允许的本地工具，最多 8 个；`finish` 必须最后执行，且只能在当前修改通过结构/素材/范围检查后创建候选。产生候选不自动采用或发布；只有用户显式采用才改变当前设计版本。
- 支持图片的配置传递已校验且属于用户项目的实际图片 bytes/base64。最多 3 张、总字节 6 MiB，沿用媒体验证；不发送外部任意图片 URL。DeepSeek Flash 和 Kimi 的官方视觉文档都将图像计入输入 token，因此由完整上下文预占覆盖。明确不支持的模型在预占和 HTTP 前返回可解释错误，不能丢掉图片继续生成。

## 本地验收与上线步骤

测试均注入本地 HTTP 响应和内存数据库，未写入主库，未花费真实资金。

```powershell
cd platform
npm run check
npx tsx --test tests/text-providers.test.ts tests/text-provider-workflow.test.ts tests/ai-billing.test.ts tests/ai-workflow.test.ts tests/ai-workflow-large.test.ts tests/integration-tests.test.ts tests/ai.test.ts
```

新增测试覆盖审核地址/价格、用量隔离、峰谷日历、未知费用、Kimi TTL 响应头、流式中断、字节限制、私有思维历史、参考图、独立资金池、并发仅派发一次、候选显式采用和运营测试。已有大设计、对话保留、账本与幂等测试应持续回归。

上线时分别建立三家配置与资金池，以真实充值凭证登记可用资金；先只读验证，再用所有者授权的运营预算执行小额功能测试。Kimi 测试输出上限是 1024（保留推理空间），其余为 16；报价返回实际上限。功能测试只消耗运营与供应商额度，不扣用户钱包。核对供应商账单/缓存 TTL/时段后激活相应版本；没有真实成功且费用已结算的能力证据不能激活。运行新迁移并确认备份恢复、任务调度、余额提醒后再开放用户使用。

## 官方来源

- [OpenAI GPT-6.1 Sol 模型合同](https://developers.openai.com/api/docs/models/gpt-6.1-sol)、[GPT-6 Sol](https://developers.openai.com/api/docs/models/gpt-6-sol)、[缓存计费](https://developers.openai.com/api/docs/guides/prompt-caching)。
- [DeepSeek 模型与峰谷价格](https://api-docs.deepseek.com/quick_start/pricing/)、[Responses 支持范围](https://api-docs.deepseek.com/guides/responses_api/)、[Responses 字段](https://api-docs.deepseek.com/api/create-response/)、[视觉输入及 token](https://api-docs.deepseek.com/guides/vision/)。
- [Kimi 国际站模型价格](https://platform.kimi.ai/docs/pricing/chat)、[Chat 协议](https://platform.kimi.ai/docs/api/chat)、[缓存 TTL 与响应头](https://platform.kimi.ai/docs/guide/context-caching)、[视觉用量](https://platform.kimi.ai/docs/guide/use-kimi-vision-model)、[思维历史与输出预算](https://platform.kimi.ai/docs/guide/use-thinking-models)。
- [中国政府 2026 节假日安排](https://www.gov.cn/zhengce/zhengceku/202511/content_7047091.htm)、[2027 节假日安排](https://www.gov.cn/zhengce/content/202611/content_7085101.htm)。

这些是截至核验日期的审核输入；模型、价格、token 上限或协议改变时，需要新配置版本和回归验证，不能把本地通过表述为真实账户调用已验收。
