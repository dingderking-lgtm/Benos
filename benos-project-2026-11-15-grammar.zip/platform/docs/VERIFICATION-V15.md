# 历史版本 15 验证快照

以下是旧版证据，当前结果见 VERIFICATION.md。

# Benos 验证记录

记录日期：2026-11-07。本文依据已保存的日志和浏览器报告整理，本次整理没有重新运行测试。

文内 `qa/` 与 `benos-site/outputs/` 链接指原工作区证据，运行数据和完整 QA 目录不进入源码发行包。包内提供 `ACCEPTANCE-EVIDENCE.json` 作为无账户凭据的结果摘要；测试源码随包保留，可在隔离环境重跑。

当前结论：最终全量286/286通过，Sites v15已成功发布并完成16项实际HTTP检查；本轮本地、模拟合同和发布证据分层列于下文。正式商户、OpenAI、邮件送达和 Hostinger 实际开站仍需外部验收。本地通过、模拟供应商响应或 Sites 发布成功均不能代表这些外部服务已上线。

## 统计口径

- 后端全量以最新一次完整运行计数。旧运行、专项运行和其中的 PHP/MySQL 检查不再累加。
- 浏览器报告按文件列出通过数，检查对象和视口有交叉，不汇总成去重后的“总功能数”。
- 真实本地接口与模拟 HTTP 合同分表记录。后者验证界面分支、请求格式和状态处理，不证明真实付款、退款、付费 AI 或主机操作。
- `pageErrors: []` 表示该次运行未捕获浏览器脚本异常。QA 账户、令牌和测试业务数据不复制到交付包或线上数据库。

## 后端与本地 CMS

| 验证层 | 最新结果 | 证据与范围 |
| --- | --- | --- |
| 最终平台全量 | **286 / 286 通过**；失败 0、跳过 0；39,632.6117 ms | [final-platform-operations-tests.log](../qa/final-platform-operations-tests.log)。包含 13 项托管池测试（含公平轮转）、通知恢复和营销素材恢复，覆盖原业务及本轮内容、托管容量、运营收费测试、提醒/保留期等；外部供应商使用测试夹具。 |
| TypeScript | 最终 `npm run check` 通过 | 不额外计入业务测试数。 |
| 前端语法 | 最终前端 JS 语法检查通过 | 与浏览器行为检查分别记录。 |
| 真实 PHP/MySQL 桥接 | 已包含于最终 286 项，未跳过 | `real PHP bridge...` 用例实际运行约 35,497.0101 ms。使用本地 PHP、隔离 MySQL 和原生 CMS 安装，覆盖签名/重放、应答丢失恢复、密码保留、站点隔离、发布、草稿保护、取消准备、回滚和备份恢复。 |

[final-platform-tests.log](../qa/final-platform-tests.log) 的 **231 / 231** 对应上次 v14 交付；[cms-final-tests.log](../qa/cms-final-tests.log) 的 **230 / 230** 是更早运行。最终 286 项、旧 231/230 项、此前阶段运行、专项 12 项和内含的 PHP/MySQL 用例均不相加。标签 schema-only 升级兼容包含在 `tests/content-management.test.ts`，具体迁移说明见 [CONTENT-MANAGEMENT.txt](CONTENT-MANAGEMENT.txt)。

本地 CMS 验证不替代 Hostinger 的 Apache/LiteSpeed 路由、PHP 扩展、SSL、数据库权限、真实 hPanel/TUS 传输与托管租约长期执行检查。

## 真实本地浏览器与接口

使用 `http://127.0.0.1:4190`、真实应用 API 和本地持久化数据。以下是开发期间各模块留下的报告，不代表最终版本重新运行过一份包含所有行的统一浏览器套件。

| 报告 | 通过 | 范围与边界 |
| --- | ---: | --- |
| [frontend-browser-results.json](../qa/frontend-browser-results.json) | 41 | 初始化/登录、注册、项目保存与刷新持久化、用户权限、未付费充值门槛、主要页面布局。 |
| [frontend-admin-results.json](../qa/frontend-admin-results.json) | 24 | 权限限制/解除、内容发布/回收站、密钥不回显、未验证配置不能启用；报告注明部分操作先于后续配置 schema 变更。 |
| [frontend-membership-hosting-results.json](../qa/frontend-membership-hosting-results.json) | 9 | 本地赠送完整权益、冻结/解冻补时、赠送不解锁充值、四项开站请求；无主机配置时保持等待输入。 |
| [frontend-design-results.json](../qa/frontend-design-results.json) | 11 | 手动版本、预览、恢复后保留历史；当时 AI 未配置。后续预占提示以最新 quote 检查为准。 |
| [frontend-security-results.json](../qa/frontend-security-results.json) | 13 | 改密、会话撤销、令牌确认与错误状态；无邮件配置时不假称发送。报告注明找回密码不可用断言来自前一轮实际运行。 |
| [frontend-media-publishing-results.json](../qa/frontend-media-publishing-results.json) | 14 | 真实私有图片上传/读取/软删/恢复，匿名拒绝，项目绑定，未连接 CMS 禁止发布；未操作真实 Hostinger。 |
| [frontend-latest-live-results.json](../qa/frontend-latest-live-results.json) | 6 | 无虚构平台资金、维护空状态、未配置 AI 的 quote 禁用状态及设计台布局。 |
| [frontend-content-marketing-results.json](../qa/frontend-content-marketing-results.json) | 16 | 分类/文章/FAQ/导航/横幅真实发布、SSR SEO/封面/noindex、草稿快照、引用保护、删除后 404；新增公开 QA 内容已全部移入回收站。 |
| [preview-media-live-results.json](../qa/preview-media-live-results.json) | 11 | 图片字节校验、历史引用不可删除、私有预览、导航保留会话/版本、CSP 与匿名拒绝。 |
| [frontend-financial-live-results.json](../qa/frontend-financial-live-results.json) | 7 | 上次发布前只读检查支付审核/预算/内容页面与手机布局，以及不存在权益记录的真实 404；无财务写入。 |

本轮新增真实报告（与上表保留的历史模块报告分开列出）：

| 报告 | 通过 | 范围与边界 |
| --- | ---: | --- |
| [frontend-content-management-live-results.json](../qa/frontend-content-management-live-results.json) | 12 | 标签及文章关联、营销素材真实上传、鉴权保存草稿预览、发布后匿名读取/撤下撤权、服务端筛选、批量部分失败和引用保护，1440/390/320 布局；测试内容与素材已软删除清理。 |
| [frontend-operations-readonly-live-results.json](../qa/frontend-operations-readonly-live-results.json) | 8 | 真实托管池、服务配置、运营预算、通知、保留期 GET 及对应页面；除登录外仅只读，不写配置/通知/预算，不调用供应商。 |

## 浏览器模拟 HTTP 合同

这些报告拦截浏览器 API 请求并返回模拟数据。界面真实运行，但没有执行渠道退款、扣款/取消续费、供应商充值/减额、收费生成或外部 CMS 发布。

| 报告 | 通过 | 主要覆盖 |
| --- | ---: | --- |
| [frontend-payment-contract-results.json](../qa/frontend-payment-contract-results.json) | 10 | 整数金额、65% 用量、受信支付跳转、幂等重试、订单回查、续费/托管/订阅确认。 |
| [frontend-operational-contract-results.json](../qa/frontend-operational-contract-results.json) | 17 | 入资确认、费用核对、发布审阅/未知/回滚、类型化配置、可信 owner 初始化。为此前专项结果，后续新增表单另有报告。 |
| [frontend-quote-maintenance-contract-results.json](../qa/frontend-quote-maintenance-contract-results.json) | 7 | 精确最高预占、余额不足禁用、维护 queued/部分失败不冒充成功。 |
| [frontend-financial-contract-results.json](../qa/frontend-financial-contract-results.json) | 23 | 退款/争议默认记录、人工限制、额度冲销/恢复、安全减额、图像费用、预约赠送、$5 充值不足 $5.40 预占提示、历史审核迁入、客服权限。 |
| [frontend-entitlements-contract-results.json](../qa/frontend-entitlements-contract-results.json) | 12 | 显式续费选择、扣款确认、取消未知时权益保留、原操作重试、原期限恢复、冻结与角色隔离。 |
| [frontend-publish-discard-contract-results.json](../qa/frontend-publish-discard-contract-results.json) | 3 | CMS 确认尚未导入并取消后才显示成功；202 返回 published/uncertain 时按真实状态展示。 |
| [frontend-cms-upload-contract-results.json](../qa/frontend-cms-upload-contract-results.json) | 7 | ZIP/48 MiB 限制、失败保留手填、verified/SHA/大小匹配、原始上传与 CSRF、不缓存文件、不自动保存或启用。 |

本轮新增模拟合同报告：

| 报告 | 通过 | 主要覆盖 |
| --- | ---: | --- |
| [frontend-hosting-pools-contract-results.json](../qa/frontend-hosting-pools-contract-results.json) | 10 | 连接验证筛选、默认停止分配、容量/修订、清单失败状态、已有暂停网站、角色与 1440/390/320 弹窗布局。 |
| [frontend-functional-notifications-contract-results.json](../qa/frontend-functional-notifications-contract-results.json) | 14 | 显式收费确认、精确预占、运营上限不等于入资、幂等重试/未知费用、人工核对不冒充能力通过、图片测试关闭、通知转义/读失败保留未读及手机布局。 |
| [frontend-retention-contract-results.json](../qa/frontend-retention-contract-results.json) | 11 | 保留期/角色门槛、复核失败保留原状态、成功仅登记继续保留并保持容量占用、用户日期与白标提示、1440/390/320 布局。 |

以上五份本轮浏览器报告均 `pageErrors: []`，没有真实付费 API、Hostinger 建站/删除或供应商入资。

## 实际视口

用户仪表盘与运营表单主要覆盖 **320、390、1440 CSS 像素**；模板验收另覆盖五档宽度及断点附近，不混作同一份报告。

| 真实渲染报告 | 通过 | 页面和宽度 |
| --- | ---: | --- |
| [responsive-preview-final-results.json](../qa/responsive-preview-final-results.json) | 23 | 真实鉴权平台预览的首页与联系页各 11 档，再加真实项目缩略图。宽度：320、390、759、760、761、768、1024、1199、1200、1201、1440。缩略图使用真实私有设计，禁止脚本与点击。 |
| [cms-native-responsive-results.json](../qa/cms-native-responsive-results.json) | 81 | 从实际发行包、过期租约备份、空 MySQL 库 CLI 恢复并签名续期后的原生 CMS；首页、联系页、代表性文章页各 27 档。宽度：300、301、320、358、359、360、390、419、420、421、759、760、761、766、767、768、1022、1023、1024、1025、1150、1151、1152、1199、1200、1201、1440。 |

原生文章封面使用 `object-fit: cover`，报告明确记录 `ratioIntact: false`：图片未拉伸，但边缘会裁切。不能将这 81 项写成全部图片“完整比例无裁切”。平台及 CMS 检查使用代表性模板和桌面 Chromium 视口模拟，不代表所有未来用户模板或真实 iPhone/Android 硬件已通过验收。

历史营销检查为 1440/390/320 × 1000，手机截图 390 × 844；财务与权益为 1440 × 1000、390/320 × 950。截图包括 `qa/marketing-desktop.png`、`qa/marketing-mobile.png`、`qa/design-current-desktop.png`、`qa/preview-media-mobile.png` 及本轮 `qa/hosting-pool-modal-320.png`、`qa/functional-modal-mobile.png`。部分截图含已清理的本地 QA 内容，不是生产预置内容。

## 本轮受管 CMS r4 发行包

证据：[cms-release-r4-verification.json](../qa/cms-release-r4-verification.json)。这是文件完整性与 PHP 语法验证，不是上传或 Hostinger 安装成功证明。

| 项目 | 结果 |
| --- | --- |
| 发行包 | `cms-connector/benos-cms-1.9.21-managed-20261107-r4.zip` |
| 核对文件 | **1,082** |
| 改动 PHP 语法检查 | **25** |
| 大小 | **34,563,930 字节** |
| SHA256 | `cfc403fa9d1c67aef7a141ac1899a477801ff87602dc4b4eeb03bcd8f2e024c5` |

r4 新增受管 CLI 整站恢复入口，在全新发行目录与独立空库恢复，原租约过期不阻断离线恢复；恢复后仍暂停，签名续期后再核对外部状态。租户不可下载含运行密钥的完整备份，通用核心升级不能覆盖受管控制。操作说明见 [CMS-DISASTER-RECOVERY.md](CMS-DISASTER-RECOVERY.md)。最后恢复修正已纳入最终286项全量检查。

以下 r3 上传是历史独立证据，不能把 r4 校验结果与 r3 上传成功拼接成 r4 已经上传。

## 历史 r3 真实 CMS 发行包上传

已用本地 owner、同源 Origin 与 CSRF 经 `/api/admin/cms-releases/upload` 实际上传到本地私有 R2。证据：[cms-release-local-upload-results.json](../qa/cms-release-local-upload-results.json)。

| 项目 | 结果 |
| --- | --- |
| 发行包 | `cms-connector/benos-cms-1.9.21-managed-20261107-r3.zip` |
| 大小 | **34,559,689 字节** |
| SHA256 | `5e192fd5c883d62285523557aa948fac2339345b8b95d423362bfcd250558719` |
| 响应 | HTTP **201**，`verified: true`，SHA256 和字节数与本地一致 |
| 对象键 | `private/cms-releases/5e192fd5c883d62285523557aa948fac2339345b8b95d423362bfcd250558719.zip` |
| 耗时 | 0.58 秒；本次本地运行未出现内存错误 |

只写本地私有存储，没有保存/启用配置、没有连接 Hostinger；这不是 Sites 线上 Worker 内存与真实 R2 上传验收。

## Sites 版本 15 发布验收

本轮 **Sites 版本 15** 已成功发布。站点保持仅所有者访问，真实外部服务仍待安全配置和验证，不表示已正式收款上线。

| 发布信息 | 已确认值 |
| --- | --- |
| 站点 | https://aistudio-design-preview-1106.typeverify.chatgpt.site |
| 版本 | **15** |
| Commit | `b143015bf652329ccda958afee0bf63fce7d41dd` |
| Deployment | `appgdep_6aee182190748191aa268ac9a402f0ab` |
| 环境修订 | 1，保持不变 |
| 访问范围 | 仅所有者 |
| 发布证据 | [sites-operations-publication.json](../qa/sites-operations-publication.json) |
| 线上 HTTP 证据 | [live-http-verification.json](../../benos-site/outputs/live-http-verification.json) |

**16 项实际 HTTP 检查全部符合预期**：`/api/health` 200 且 ready，`/api/session` 200；`/`、`/home`、`/blog`、`/faq` 均 200 并包含 Benos；营销 CSS、favicon、找回密码页面及新增 `hosting-pools.js`、`integration-tests.js`、`notifications.js` 均 200；未登录访问管理概览、托管池、保留期和通知接口均返回 401。`/home` 保持 `noindex`。401 表示未登录访问被拒绝，不是接口故障，也不证明登录后的所有业务已在生产执行。

最终便携 Wrangler dry-run 构建通过，大小 **1457.39 KiB / gzip 271.49 KiB**，证据：[portable-operations-build.log](../qa/portable-operations-build.log)。这项构建与 Sites 发布分别记录。

精确生成的 Sites `0000_benos_core.sql`、`0001_benos_business.sql`、`0002_benos_operations.sql` 已在隔离 SQLite 顺序运行，完整性为 `ok`、外键错误 0，托管触发器 3；证据：[hosted-migration-final-results.json](../qa/hosted-migration-final-results.json)。该测试使用实际生成文件，但不是线上 D1 全库完整性扫描。线上概览已见 `hosting_pools`、`content_media`、`operations_budgets` 和 `integration_function_tests` 等新增表；工具返回 50 个名称，仅代表该次返回量，不推断数据库总表数。

Sites 标签迁移采用兼容原六类型 CHECK 的 schema-only 适配，保留既有迁移，不复制测试用户或业务数据。历史 v14 发布标识和当时的 HTTP 快照保存在 [ACCEPTANCE-EVIDENCE.json](ACCEPTANCE-EVIDENCE.json) 的 `historicalSites` 中；新版已覆盖的 `live-http-verification.json` 只用于 v15。

首次使用：以当前 Sites 所有者身份打开站点 `/`。首次初始化会预填并锁定邮箱，用户自行填写称呼和至少 12 个字符的密码，再进入管理后台。无需由代理创建或发送密码。已有 owner 的环境使用已有登录流程，不重复初始化。

Sites 自动维护调度仍未验证。有 scheduled 导出或 cron 配置不等于实际按时执行；手动 queued 不等于任务完成。线上 HTTP 通过也不能替代长期调度、真实支付、AI、邮件或 Hostinger 验收。

## 尚未通过的商业外部验收

| 项目 | 当前边界 |
| --- | --- |
| Hostinger | 未在真实 hPanel 账户完成建站/建库/TUS 安装、域名/HTTPS、托管暂停/恢复；本地安装不能替代真机证据。 |
| 支付/退款 | 未验证真实付款、回调、续费、取消、退款或拒付；人工审核/权益调整不等于执行渠道退款。 |
| OpenAI 文本 | 未执行真实付费生成与真实账单核对；未默认登记计划中的 $100 充值。预占/结算为本地验证。 |
| 图片生成 | **生产派发关闭**，单次费用硬上限合同尚未核验；配置保存、图片上传和模拟生成不等于收费生图可用。 |
| 邮件 | 未核验真实发件域名与收件箱送达；本地令牌/队列与错误分支不代表邮件发送成功。 |
| 维护调度 | Sites 自动调度未验；须观察真实执行时间、结果，以及邮件/开站/托管租约持续处理。 |
| 正式部署/恢复 | 正式 Cloudflare 账户/域名、生产 D1/R2 备份恢复演练、真实移动设备尚未验收；搜索收录默认关闭。 |

配置和实际验证完成后再依据证据更新状态，不能因按钮可用或部署 ready 将未验项目改为通过。
