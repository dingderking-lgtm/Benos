# 完整容量上传与发布准备专项验收

日期：2026-11-07。以下分层记录互不相加为“全量测试”。测试使用本地隔离账户、D1 与私有 R2，保留已有数据；没有调用外部付费 AI、支付或真实 Hostinger。

| 验证层 | 结果 | 证据 |
| --- | --- | --- |
| 独立 CMS 传输/发布边界测试 | 10/10，失败/跳过 0 | `qa/cms-transfers-review-tests.log`、`tests/cms-transfers-review.test.ts` |
| 恢复工具完整专项 | 16/16，失败/跳过 0 | `qa/platform-manifest-recovery-tests.log`、`tests/platform-recovery.test.ts` |
| 浏览器 HTTP fixture | 24/24、浏览器错误 0 | `qa/package-upload-ui-results.json` |
| 真实本地上传/采用/浏览器导出 | 11/11、浏览器错误 0 | `qa/package-upload-live-results.json` |
| 大版本实际页面渲染 | 4/4、浏览器错误 0 | `qa/package-upload-preview-results.json` |

Chromium 与 WebKit 在 Windows 上运行。手机视口 390px、桌面视口 1440px，不代表实体手机或 Mac 实机验收。新增弹窗检查页面无横向溢出、44px 触控按钮及手机输入字号；截图保存在上述报告同目录。TypeScript 与变更前端模块语法检查通过。

## 用户可完成的流程

“导入模板”使用服务端持久上传任务，ZIP 最大 74 MiB，清单最大 10 MiB、素材合计最大 64 MiB；仍须通过格式、引用和安全校验。每次仅读取和上传一个 1 MiB 分块。进度只使用服务端确认的字节数和已校验条目数。

浏览器只持久保存上传 ID、稳定请求编号、文件元信息和待核对步骤，不保存文件字节。关闭页面会停止继续发送文件；完整上传后的校验可以由后台推进。刷新后重新选原文件时，先逐块比较已确认的 SHA256；同文件名、同大小但内容不同会被拒绝。丢失响应会查询并继续原任务；没有自动更换请求编号。

完成导入产生待采用候选，项目当前版本仍为空。用户打开候选、明确采用后才保存版本；该操作不发布到 CMS。取消上传只在服务端确认后显示取消，不把未知结果当成功。

真实大包为 `qa/large-native-template-fixture-v2.zip`：**77,076,927 字节、74 块、10 个服务器步骤、8 个条目**。WebKit 实际执行暂停、刷新、重选文件续传、候选预览、采用和浏览器导出。导出 ZIP 与输入 ZIP 的整个文件 SHA256 相同：

```
e6c98f5e18392e4d5d617790d3df13fe68bc57ecb1647e891096c89bb36b3d4b
```

Chromium 小包也完成相同的导入、候选、采用和导出链；其美化 JSON 在导出时归一化了空白，JSON 内容一致，不能宣称该小包原始 ZIP 字节完全相同。大包的内容是容量压力夹具，不是交付的设计样板；其页面不引用已附带的图片，所以大版本渲染报告仅证明实际 HTML/标题渲染，不把附件存在当作图片显示证据。

## 发布准备与恢复边界

发布页面显示 CMS 已确认接收的字节数，传输阶段可请求取消准备，并明确“后台继续准备，仍需最终影响确认”。只有返回真实 `prepared` 且具有影响清单和 review hash 才提供确认发布。未知取消结果继续显示待核对。

独立服务端测试验证：等待 R2 期间的撤权、连接密钥轮换和租约接管会阻止下一次发送；远端已关闭状态转为本地终态；已被远端发布记录占用的包不能取消；取消确认丢失后查询原记录恢复；过期的未占用封包不能继续冒充可用包。已有签名远端准备记录的原始占用关系可在封包 TTL 后继续恢复准备，仍不会自动 commit。

恢复工具对所有 ready 大清单检查真实字节、SHA256、大小、归属、路径、结构和 D1 小索引。原子导入未完成时产生的无引用 ready 对象允许其素材尚未入库；一旦被任何版本或候选引用，素材记录与对象必须完整。孤立对象的损坏字节仍会被拒绝。

HTTP fixture 的模拟故障证据不代表真实 CMS 接入。真实 Hostinger、线上调度、付费 API、收款和邮件仍属于独立接入验收范围。

## 持久化原生预览与真实图片授权验收

本轮原生预览按任务持久保存，显示 CMS 已确认传输量、产物接收量与阶段。浏览器暂停或关闭不会伪称取消后台任务；重新打开继续原任务与原步骤。未知结果保留原编号，不自动创建重复任务。只有真实 ready 才展示预览；版本、候选或页面切换后，旧任务结果不会覆盖新选择。预览不自动采用设计、不发布网站，也不调用付费 AI。

| 验证层 | 结果 | 证据 |
| --- | --- | --- |
| 原生预览前端状态单元测试 | 8/8 | `tests/design-native-ui.test.ts`、`qa/design-native-job-ui-tests.log` |
| 原生任务浏览器 HTTP 合同夹具 | 24/24，浏览器错误 0 | `qa/native-preview-job-ui-results.json` |
| 实际 workerd → 签名 PHP/MySQL → 私有 R2 → 浏览器图片链 | 32/32，浏览器错误 0 | `qa/native-preview-live-browser-results.json` |
| 两份近 74 MiB 原生任务真实容量链 | 2 份任务完成；分别为首页与联系页 | `qa/native-preview-worker-results.json` |

这几层证据分别记录，不累加到平台全量测试数。HTTP 合同夹具验证丢响应、原步骤重试、暂停、刷新恢复、切换来源、迟到结果、取消和焦点；它不是真实 CMS 接入证明。真实浏览器链通过普通鉴权素材上传和显式手动版本建立小图片集，再由界面创建持久原生任务；没有预先写入 ready 行，也没有模拟媒体、任务或 HTML 响应。

真实图片链验证 PNG、JPEG、WebP、GIF、SVG：Chromium 与 Windows WebKit 在 390px/1440px 中实际显示 CMS 产物，图片保持原比例，页面无横向溢出。原生 iframe 使用 `sandbox="allow-scripts"`，没有 `allow-same-origin`，浏览器内部 origin 为 `null`。平台 HTML 仍要求登录；匿名请求返回 401。原生样例输出不包含隔离 CMS 中预设的客户文章哨兵内容。截图为 `qa/native-live-{chromium,webkit}-images-{390,1440}.png`，完整界面截图另有 `gallery` 同名组。

受限图片授权链接实际返回 200，取回字节 SHA256 与其限定资源摘要一致，使用 `private, no-store`。缺少授权或篡改授权返回 403；隔离 QA 账户限制及项目归档后，原链接返回 403；实际 UI/API 取消后，图片及登录用户的预览 HTML 返回 410。到期边界通过将真实 ready 任务在隔离 QA 数据库中暂时标为 expired，验证原链接返回 410 后恢复状态；未修改不可变到期字段，也未声称等待了 30 分钟自然到期，真实 TTL 的时间条件由后端控制时钟测试覆盖。账户和项目的临时 QA 状态均已恢复。

两份 77,076,927 字节输入任务经过实际本地 workerd/D1/R2 和真实 PHP/MySQL 签名协议。CMS 的 256 MiB 暂存准入限制导致第二任务等待，界面保留原任务并提示稍后继续；两份产物阶段使用两参与者同步点并发接收，最终均 ready，未自动采用或发布。该结果不等于任意并发数或 isolate 内存峰值证明。

本地 QA 入口仅把指定 HTTPS 测试域的三个连接器路径映射到固定 loopback PHP，保留生产 HTTPS 验证与真实 HMAC；生产源码没有 localhost 放行。WebKit 运行在 APP_ORIGIN 一致的隔离 4281 端口，未放宽 CSP。证据不包含图片授权 query/token、密码或会话。Windows WebKit 不代表实体 Mac/iPhone；真实 Hostinger、线上定时调度、付费 API、支付及邮件仍须独立配置与验收。


## v19 大模板编辑与布局补充

| 验收组 | 结果 | 报告 |
| --- | --- | --- |
| 大模板样式与版本历史 | 9 项，页面错误 0 | `qa/large-editing-ui-results.json` |
| 分段编辑与真实换图 | 8 项，页面错误 0 | `qa/large-editing-advanced-results.json` |
| 真实 JSON 上传与双引擎布局 | 22 项，页面错误 0 | `qa/large-json-upload-ui-results.json` |
| 丢回执与错误 JSON 修复 | 5 项，页面错误 0 | `qa/json-repair-ui-results.json` |
| 大量区块与安全选择层 | 17 项，页面错误 0 | `qa/large-node-editor-ui-results.json` |
| 手机触控选择 | 3 项，页面错误 0 | `qa/large-selection-touch-results.json` |
| 大清单 AI 只读界面 | 9 项，页面错误 0 | `qa/large-ai-fixture-ui-results.json` |
| 200% 放大后实际选区 | 6 项，页面错误 0 | `qa/large-selection-zoom-results.json` |

分段弹窗两引擎覆盖 360、390、768、1024、1280、1440、1920 CSS 像素和 CSS 200% 放大；其他组按报告列出的宽度与操作验收，不能外推为所有页面每个组合均已重跑。全后台布局沿用 `ADMIN-UI-ACCEPTANCE.md` 的全模块基线。Windows WebKit、CSS zoom 与触控仿真不等于实体 Mac/iPhone/iPad、浏览器原生工具栏缩放或真实系统软键盘。


实际保存、预算和恢复规则见 `LARGE-DESIGN-EDITING.md`，当前全量与发布结果见 `VERIFICATION.md`。本组不与 v18 或全量测试重复累计。
