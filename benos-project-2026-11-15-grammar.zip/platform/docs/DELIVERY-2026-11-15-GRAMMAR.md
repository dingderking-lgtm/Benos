# 本轮交付说明 · 版式语法引擎与配色系统（2026-11-15）

本文记录本轮做了什么、证据在哪里、怎么验证，以及还没做的事。验收命令都能在本地直接跑。

## 一、这一轮解决的问题

| # | 问题 | 结果 |
|---|---|---|
| 1 | AI 设计「拼区块」不够稳定，也不像顶级设计师的作品 | 新增第三套生成引擎：**版式语法（bnl-0）**。模型写「品牌系统 + 区段树」，平台校验后编译成页面，不再拼现成区块 |
| 2 | 生成的区块背景出现随意的绿、粉、黑 | 新增**配色引擎**：13 个行业 × 3 个方向 = 39 套平台配色，模型只能选「行业 + 方向」，**无权写 HEX** |
| 3 | 报「与设计服务的连接中断」 | 根因是 DeepSeek 思考模式拒绝 `tool_choice: "required"`（provider 原话 `Thinking mode does not support this tool_choice`）。DeepSeek 分支改为 `auto` |
| 4 | 生成的新站没有 AI 配图 | 图位可声明「待生成」；提交里按页面/区段/第几张描述画面，平台用既有配图管线生成并回填 `src`，登记包内 `assets[]`，失败即整轮退回重写 |
| 5 | 运营侧看不到、也批准不了语法引擎 | 运营后台新增「语法引擎」页（`#/admin/design-grammar`）：身份摘要、批准状态与记录、品牌可选范围、当场编译预览 |

## 二、新增与修改的代码

**语法引擎（新目录）** `platform/src/design-system/grammar/`
- `brand.ts` 品牌系统校验与 10 色推导（对比度强制）
- `compile.ts` 校验 + 编译：页面片段、站点级与页面级两段 CSS、图片帧、表单槽、待生成图位
- `site.ts` 多页面装配（同一品牌、页间链接、页面作用域类名）
- `manifest.ts` 输出完整 AACMS 站点包（页头/页脚/每页模板 + CMS 导航 + 站点级 `global_css`，可选博客外壳），内部用平台自己的 `validateSiteManifest` 自检
- `palettes.ts` **配色引擎**：13 行业 × 3 方向，输出颜色角色、50–950 梯度、浅/深两套表面层级、语义色、按钮状态色，并做对比度自检
- `frames.ts` 图片帧（槽尺寸、是否可裁、定高/自适应）
- `bind.ts` 把生成的图片写回对应 `<img>`（有 src 则替换，没有则插入）
- `spec.ts` 模型读到的语法说明（实验 SPEC + 产品补充：整站、表单、图标、配色、图片）
- `exemplars.ts` 母版套件所出自的 ARPKM 首页，作为每次测试都编译的范例
- `generation.ts` 冻结计划、工具定义、提交校验、修复简报
- `identity.ts` + `source-identity.json` 语法身份（编译器 + 说明 + 范例三者摘要）

**接线与审批**
- `platform/src/lib/grammar-workflow.ts` 用语法引擎跑通工作流：工具、编译、配图、字节冻结
- `platform/src/lib/grammar-approvals.ts`、`migrations/0071_design_grammar_approvals.sql` 审批台账
- `platform/src/lib/engine-access.ts` 引擎选择（默认关闭、只对 owner 生效）
- `platform/src/modules/design-grammar.ts` owner 工作台路由：`spec` / `compile` / `preview` / `site`（含 `production: true`）/ `approvals` / `approve`
- `platform/src/modules/ai-workflow.ts` 新增 `site-grammar-1` 引擎的 8 处分支
- `platform/src/modules/text-provider-adapter.ts` DeepSeek `tool_choice` 修正
- `platform/src/modules/design-preview.ts` 画布白名单加入新引擎
- `UI模板/frontend/components/admin/pages/design-grammar/`、`UI模板/frontend/lib/design-grammar.ts` 运营后台页面
- `scripts/design-grammar-identity.mjs`、`package.json` 的 `check`/`test` 增加语法身份校验

## 三、验收证据

```bash
cd platform && npm run check      # v2 身份 + 语法身份 + 类型检查
cd platform && npm test           # 1506 项：1492 通过，14 项为既有基线（PDF 3 / 恢复 3 / 图库 CSP 1 / 既有站点编辑 6 / vehicle-showcase 1）
cd UI模板    && npm test           # 609 项全绿
```

- 语法与配色相关测试 41 项全绿：`tests/design-grammar*.test.ts`、`tests/design-palettes.test.ts`、`tests/engine-access.test.ts`、`tests/workflow-site-grammar.test.ts`
- 真机验收（本地预览实例、真实 DeepSeek + image 模型）：
  - 两页机加工站：`succeeded`，1 步 35 秒，花费约 $0.0054
  - 带配图版本：requested 4 / bound 4；另一轮 requested 5 / bound 4，失败一张（provider 抖动）后已改为整轮退回重写
  - 渲染核对：`<img src="/api/media/assets/media_…/content">` 真实地址，浏览器里图片正常加载
- 视觉证据（工作目录，不进发布包）`.ui-work/grammar-wiring/`：`generated/`（真实生成站点截图）、`palettes/sheet.png`（六种行业配色对照）、`admin-grammar-*.png`（运营后台页面）

## 四、使用方式

1. **开关**：`settings` 的 `ai.generation-policy.v1.newSiteEngine` —— `compose-v2`（默认，老引擎）或 `syntax-1`（版式语法）。打开后**只对 owner 账号生效**。
2. **审批**：运营后台「语法引擎」→「批准当前语法」。改过编译器/说明/范例后身份摘要变化，必须重新批准，否则正式出包会被拒绝（409 `GRAMMAR_NOT_APPROVED`）。
3. **回滚**：把 `newSiteEngine` 改回 `compose-v2` 即刻回到原引擎，数据无需迁移。
4. **配图**：语法引擎按图位计费生成；一轮内任何一张失败会让模型重写，不会发出破图。

## 五、还没做的

- 语法站点接入实时画布与「选中修改」的实测（白名单已加，未跑端到端用例）
- 博客外壳已能生成（archive/single + `data-aacms="page-content"`），但没有真实文章内容验收
- 看图评审（需要截图服务）、实体 iPhone Safari 复核
- 生产部署：生产 D1 需要执行 `0071_design_grammar_approvals.sql`，并配置生产密钥与域名；本轮未部署
