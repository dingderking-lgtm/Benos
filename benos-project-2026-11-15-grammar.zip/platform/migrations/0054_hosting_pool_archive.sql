-- Archiving a connection only stops new assignments. Existing website and
-- database ownership, credentials, renewal and publication history are retained.
ALTER TABLE hosting_pools ADD COLUMN archived_at TEXT;
ALTER TABLE hosting_pools ADD COLUMN archived_by TEXT REFERENCES users(id);
ALTER TABLE hosting_pools ADD COLUMN archive_reason TEXT;
CREATE TRIGGER hosting_pool_archive_stops_allocation BEFORE UPDATE ON hosting_pools
 WHEN NEW.archived_at IS NOT NULL AND NEW.state<>'draining'
 BEGIN SELECT RAISE(ABORT,'hosting_pool_archived'); END;
