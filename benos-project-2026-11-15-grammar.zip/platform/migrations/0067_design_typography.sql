CREATE TABLE design_typography_snapshots (
  source_kind TEXT NOT NULL CHECK(source_kind IN ('version','candidate')),
  source_id TEXT NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id),
  project_id TEXT NOT NULL REFERENCES projects(id),
  manifest_hash TEXT NOT NULL,
  profile_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(source_kind,source_id)
);
CREATE INDEX design_typography_project ON design_typography_snapshots(user_id,project_id);
