CREATE TABLE hosting_bootstrap_intents (
 job_id TEXT PRIMARY KEY REFERENCES provisioning_jobs(id),site_id TEXT NOT NULL UNIQUE REFERENCES sites(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 secret_ciphertext TEXT NOT NULL,expires_at INTEGER NOT NULL,
 bootstrap_sha256 TEXT NOT NULL,release_sha256 TEXT NOT NULL,release_size INTEGER NOT NULL,
 bootstrap_checkpoint_json TEXT,release_checkpoint_json TEXT,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
