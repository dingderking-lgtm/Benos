CREATE TABLE platform_brand_versions (
 id TEXT PRIMARY KEY,version INTEGER NOT NULL UNIQUE,configuration_json TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','tested','active','disabled')),
 actor_id TEXT NOT NULL REFERENCES users(id),reason TEXT NOT NULL,created_at TEXT NOT NULL,tested_at TEXT
);
CREATE UNIQUE INDEX one_active_platform_brand ON platform_brand_versions(state) WHERE state='active';
CREATE TRIGGER brand_configuration_immutable BEFORE UPDATE OF configuration_json,version ON platform_brand_versions
 BEGIN SELECT RAISE(ABORT,'brand_configuration_immutable'); END;
CREATE TRIGGER brand_version_no_delete BEFORE DELETE ON platform_brand_versions
 BEGIN SELECT RAISE(ABORT,'brand_version_no_delete'); END;
