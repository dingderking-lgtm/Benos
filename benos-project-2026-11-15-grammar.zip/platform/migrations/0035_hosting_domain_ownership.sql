-- Schema-only upgrades may omit 0029's historical domain backfill.
-- Protect existing sites at claim time, before any provider alias operation.
CREATE TRIGGER hosting_domain_claim_existing_site BEFORE INSERT ON hosting_domains
 WHEN EXISTS(SELECT 1 FROM sites WHERE domain=NEW.domain AND id<>NEW.site_id)
 BEGIN SELECT RAISE(ABORT,'hosting_domain_claimed'); END;

-- A former canonical domain remains attached to its original physical site.
-- Capture both names transactionally when an existing site changes domain.
CREATE TRIGGER hosting_domain_capture_history AFTER UPDATE OF domain ON sites
 BEGIN
  INSERT OR IGNORE INTO hosting_domains(domain,site_id,created_at) VALUES(OLD.domain,OLD.id,OLD.created_at);
  INSERT OR IGNORE INTO hosting_domains(domain,site_id,created_at) VALUES(NEW.domain,NEW.id,NEW.updated_at);
 END;
