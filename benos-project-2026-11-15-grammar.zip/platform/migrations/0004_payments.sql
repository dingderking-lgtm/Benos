-- Immutable checkout pricing and durable payment fulfillment/reconciliation.
ALTER TABLE orders ADD COLUMN config_version_id TEXT REFERENCES integration_configs(id);
ALTER TABLE orders ADD COLUMN checkout_url TEXT;
ALTER TABLE orders ADD COLUMN eligible_until TEXT;
ALTER TABLE orders ADD COLUMN fulfilled_at TEXT;
ALTER TABLE orders ADD COLUMN eligibility_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT order_eligibility CHECK(eligibility_ok=1);

CREATE TABLE payment_agreements (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 origin_order_id TEXT NOT NULL UNIQUE REFERENCES orders(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 provider_subscription_id TEXT NOT NULL UNIQUE,
 tier TEXT NOT NULL CHECK(tier IN ('go','pro')),
 state TEXT NOT NULL CHECK(state IN ('active','cancel_scheduled','cancelled','past_due')),
 cancel_requested INTEGER NOT NULL DEFAULT 0 CHECK(cancel_requested IN (0,1)),
 provider_event_at INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX payment_agreements_user ON payment_agreements(user_id,state);
CREATE UNIQUE INDEX one_current_payment_agreement ON payment_agreements(user_id) WHERE state<>'cancelled';

CREATE TABLE payment_fulfillments (
 id TEXT PRIMARY KEY, order_id TEXT NOT NULL UNIQUE REFERENCES orders(id),
 provider_reference TEXT NOT NULL UNIQUE, snapshot_hash TEXT NOT NULL,
 starts_at TEXT NOT NULL, ends_at TEXT,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','completed','review')),
 created_at TEXT NOT NULL, completed_at TEXT
);
CREATE INDEX payment_fulfillments_pending ON payment_fulfillments(state,created_at);
ALTER TABLE payment_events ADD COLUMN config_version_id TEXT REFERENCES integration_configs(id);
ALTER TABLE payment_events ADD COLUMN payload_json TEXT;
ALTER TABLE payment_events ADD COLUMN error_code TEXT;

CREATE TABLE payment_review_cases (
 id TEXT PRIMARY KEY, event_id TEXT NOT NULL UNIQUE, order_id TEXT REFERENCES orders(id),
 reason TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'open' CHECK(state IN ('open','resolved')),
 created_at TEXT NOT NULL, resolved_at TEXT
);
