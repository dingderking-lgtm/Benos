-- Initial CMS installation must wait for DNS and an active certificate.
-- Record the certificate intent before POST so an unknown result is reconciled,
-- never retried as another certificate issuance.
ALTER TABLE hosting_provider_intents ADD COLUMN ssl_setup_attempted INTEGER NOT NULL DEFAULT 0 CHECK(ssl_setup_attempted IN (0,1));
ALTER TABLE hosting_provider_intents ADD COLUMN ssl_status TEXT;
ALTER TABLE hosting_provider_intents ADD COLUMN ssl_checked_at TEXT;
ALTER TABLE hosting_provider_intents ADD COLUMN dns_verified_at TEXT;
ALTER TABLE hosting_provider_intents ADD COLUMN https_ready_at TEXT;
