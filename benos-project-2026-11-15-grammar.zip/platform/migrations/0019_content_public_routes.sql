CREATE UNIQUE INDEX content_published_slug_unique
ON content_entries(kind,json_extract(published_json,'$.slug'))
WHERE state='published' AND published_json IS NOT NULL;
CREATE INDEX content_public_pagination ON content_entries(state,kind,published_at DESC,id DESC);
