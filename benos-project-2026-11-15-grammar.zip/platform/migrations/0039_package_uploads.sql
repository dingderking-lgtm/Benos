-- Durable private ZIP staging. No user media or design becomes visible until
-- one guarded transaction promotes every verified entry and its candidate.
CREATE TABLE package_uploads (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT NOT NULL REFERENCES projects(id),
 request_key TEXT NOT NULL, request_hash TEXT NOT NULL, file_name TEXT NOT NULL,
 total_bytes INTEGER NOT NULL CHECK(total_bytes BETWEEN 22 AND 77594624),
 received_bytes INTEGER NOT NULL DEFAULT 0 CHECK(received_bytes BETWEEN 0 AND total_bytes),
 reserved_bytes INTEGER NOT NULL CHECK(reserved_bytes BETWEEN 0 AND 155189248),
 state TEXT NOT NULL DEFAULT 'uploading' CHECK(state IN ('uploading','processing','ready','failed','cancelled','expired')),
 phase TEXT NOT NULL DEFAULT 'directory' CHECK(phase IN ('directory','manifest','assets','commit','complete')),
 completed_steps INTEGER NOT NULL DEFAULT 0 CHECK(completed_steps>=0),
 directory_json TEXT CHECK(directory_json IS NULL OR json_valid(directory_json)),
 assets_json TEXT CHECK(assets_json IS NULL OR json_valid(assets_json)),
 candidate_id TEXT REFERENCES design_candidates(id), error_code TEXT,
 cleanup_state TEXT NOT NULL DEFAULT 'pending' CHECK(cleanup_state IN ('pending','purging','purged')),
 lease_token TEXT, lease_until_ms INTEGER, expires_at_ms INTEGER NOT NULL,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key), CHECK(state<>'ready' OR candidate_id IS NOT NULL)
);
CREATE INDEX package_uploads_active ON package_uploads(user_id,state,cleanup_state);
CREATE INDEX package_uploads_project ON package_uploads(project_id,state);
CREATE INDEX package_uploads_cleanup ON package_uploads(cleanup_state,expires_at_ms,updated_at);
CREATE TABLE package_upload_chunks (
 upload_id TEXT NOT NULL REFERENCES package_uploads(id), chunk_index INTEGER NOT NULL CHECK(chunk_index BETWEEN 0 AND 73),
 byte_offset INTEGER NOT NULL CHECK(byte_offset=chunk_index*1048576), byte_size INTEGER NOT NULL CHECK(byte_size BETWEEN 1 AND 1048576),
 sha256 TEXT NOT NULL CHECK(length(sha256)=64), object_key TEXT NOT NULL UNIQUE, etag TEXT,
 state TEXT NOT NULL DEFAULT 'staging' CHECK(state IN ('staging','ready')),
 PRIMARY KEY(upload_id,chunk_index)
);
CREATE TABLE package_upload_entries (
 upload_id TEXT NOT NULL REFERENCES package_uploads(id), file_name TEXT NOT NULL,
 media_id TEXT UNIQUE, object_key TEXT NOT NULL UNIQUE, byte_size INTEGER NOT NULL CHECK(byte_size BETWEEN 1 AND 12582912),
 sha256 TEXT, etag TEXT, info_json TEXT CHECK(info_json IS NULL OR json_valid(info_json)),
 state TEXT NOT NULL DEFAULT 'staging' CHECK(state IN ('staging','verified')),
 PRIMARY KEY(upload_id,file_name), CHECK((file_name='manifest.json')=(media_id IS NULL))
);
CREATE TRIGGER package_upload_identity BEFORE UPDATE ON package_uploads WHEN
 NEW.id<>OLD.id OR NEW.user_id<>OLD.user_id OR NEW.project_id<>OLD.project_id OR NEW.request_key<>OLD.request_key OR NEW.request_hash<>OLD.request_hash OR NEW.file_name<>OLD.file_name OR NEW.total_bytes<>OLD.total_bytes OR NEW.expires_at_ms<>OLD.expires_at_ms OR NEW.created_at<>OLD.created_at
BEGIN SELECT RAISE(ABORT,'package_upload_identity_immutable'); END;
CREATE TRIGGER package_chunk_identity BEFORE UPDATE ON package_upload_chunks WHEN
 NEW.upload_id<>OLD.upload_id OR NEW.chunk_index<>OLD.chunk_index OR NEW.byte_offset<>OLD.byte_offset OR NEW.byte_size<>OLD.byte_size OR NEW.sha256<>OLD.sha256 OR NEW.object_key<>OLD.object_key OR (OLD.state='ready' AND (NEW.state<>'ready' OR NEW.etag IS NOT OLD.etag))
BEGIN SELECT RAISE(ABORT,'package_chunk_identity_immutable'); END;
CREATE TRIGGER package_entry_identity BEFORE UPDATE ON package_upload_entries WHEN
 NEW.upload_id<>OLD.upload_id OR NEW.file_name<>OLD.file_name OR NEW.media_id IS NOT OLD.media_id OR NEW.object_key<>OLD.object_key OR NEW.byte_size<>OLD.byte_size OR (OLD.state='verified' AND (NEW.state<>'verified' OR NEW.sha256 IS NOT OLD.sha256 OR NEW.etag IS NOT OLD.etag OR NEW.info_json IS NOT OLD.info_json))
BEGIN SELECT RAISE(ABORT,'package_entry_identity_immutable'); END;
