CREATE TABLE membership_gifts (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), actor_id TEXT NOT NULL REFERENCES users(id),
 tier TEXT NOT NULL CHECK(tier IN ('go','pro')), months INTEGER NOT NULL CHECK(months BETWEEN 1 AND 12),
 request_key TEXT NOT NULL, payload_hash TEXT NOT NULL, reason TEXT NOT NULL,
 starts_at_ms INTEGER NOT NULL, periods_json TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','completed')),
 eligibility_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT membership_gift_eligible CHECK(eligibility_ok=1),
 created_at TEXT NOT NULL, completed_at TEXT, UNIQUE(user_id,request_key)
);
CREATE TABLE membership_freezes (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), actor_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL, payload_hash TEXT NOT NULL, reason TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'pending_billing_change' CHECK(state IN ('pending_billing_change','frozen','pending_unfreeze','completed')),
 requested_at_ms INTEGER NOT NULL, frozen_at_ms INTEGER, unfreeze_requested_at_ms INTEGER, unfrozen_at_ms INTEGER,
 unfreeze_request_key TEXT, unfreeze_payload_hash TEXT, unfreeze_actor_id TEXT REFERENCES users(id), unfreeze_reason TEXT,
 compensated_ms INTEGER NOT NULL DEFAULT 0 CHECK(compensated_ms>=0),
 lease_token TEXT, lease_until_ms INTEGER, error_code TEXT, updated_at TEXT NOT NULL,
 eligibility_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT membership_freeze_eligible CHECK(eligibility_ok=1),
 UNIQUE(user_id,request_key)
);
CREATE UNIQUE INDEX membership_one_open_freeze ON membership_freezes(user_id) WHERE state<>'completed';
ALTER TABLE subscriptions ADD COLUMN membership_frozen_by TEXT REFERENCES membership_freezes(id);
ALTER TABLE credit_grants ADD COLUMN membership_frozen_by TEXT REFERENCES membership_freezes(id);
CREATE TABLE membership_freeze_subscriptions (
 freeze_id TEXT NOT NULL REFERENCES membership_freezes(id), subscription_id TEXT NOT NULL REFERENCES subscriptions(id),
 starts_at TEXT NOT NULL, ends_at TEXT NOT NULL, PRIMARY KEY(freeze_id,subscription_id)
);
CREATE TABLE membership_freeze_grants (
 freeze_id TEXT NOT NULL REFERENCES membership_freezes(id), grant_id TEXT NOT NULL REFERENCES credit_grants(id),
 starts_at_ms INTEGER NOT NULL, expires_at_ms INTEGER NOT NULL, PRIMARY KEY(freeze_id,grant_id)
);
CREATE TABLE membership_billing_changes (
 id TEXT PRIMARY KEY, freeze_id TEXT NOT NULL REFERENCES membership_freezes(id), agreement_id TEXT NOT NULL REFERENCES payment_agreements(id),
 action TEXT NOT NULL CHECK(action IN ('pause','resume')), target_end_ms INTEGER,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','confirmed')),
 error_code TEXT, created_at TEXT NOT NULL, confirmed_at TEXT,
 UNIQUE(freeze_id,agreement_id,action,target_end_ms)
);
