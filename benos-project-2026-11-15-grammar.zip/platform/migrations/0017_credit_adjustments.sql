-- Preserve issued credit and AI consumption separately from support corrections.
ALTER TABLE credit_grants ADD COLUMN reversed_micros INTEGER NOT NULL DEFAULT 0
 CONSTRAINT ledger_grant_reversal_balance CHECK(typeof(reversed_micros)='integer' AND reversed_micros>=0 AND reversed_micros+consumed_micros+reserved_micros<=amount_micros);
ALTER TABLE financial_cases ADD COLUMN credit_adjustment_micros INTEGER NOT NULL DEFAULT 0 CHECK(credit_adjustment_micros>=0);
CREATE TABLE financial_credit_adjustments (
 id TEXT PRIMARY KEY,case_id TEXT NOT NULL REFERENCES financial_cases(id),order_id TEXT NOT NULL REFERENCES orders(id),
 grant_id TEXT NOT NULL REFERENCES credit_grants(id),actor_id TEXT NOT NULL REFERENCES users(id),
 direction TEXT NOT NULL CHECK(direction IN ('reverse','restore')),parent_id TEXT REFERENCES financial_credit_adjustments(id),
 amount_micros INTEGER NOT NULL CHECK(typeof(amount_micros)='integer' AND amount_micros>0),
 request_key TEXT NOT NULL,payload_hash TEXT NOT NULL,attempt_nonce TEXT NOT NULL,
 reason TEXT NOT NULL,evidence TEXT NOT NULL,created_at TEXT NOT NULL,
 UNIQUE(actor_id,request_key),CHECK((direction='reverse' AND parent_id IS NULL) OR (direction='restore' AND parent_id IS NOT NULL))
);
CREATE INDEX credit_adjustments_case ON financial_credit_adjustments(case_id,created_at);
CREATE INDEX credit_adjustments_parent ON financial_credit_adjustments(parent_id);
CREATE TRIGGER financial_credit_adjustments_no_delete BEFORE DELETE ON financial_credit_adjustments BEGIN SELECT RAISE(ABORT,'immutable_credit_adjustment'); END;
CREATE TRIGGER financial_credit_adjustments_no_rewrite BEFORE UPDATE ON financial_credit_adjustments
 WHEN OLD.id<>NEW.id OR OLD.case_id<>NEW.case_id OR OLD.order_id<>NEW.order_id OR OLD.grant_id<>NEW.grant_id OR OLD.actor_id<>NEW.actor_id
 OR OLD.direction<>NEW.direction OR OLD.parent_id IS NOT NEW.parent_id OR OLD.amount_micros<>NEW.amount_micros OR OLD.request_key<>NEW.request_key
 OR OLD.attempt_nonce<>NEW.attempt_nonce OR OLD.reason<>NEW.reason OR OLD.evidence<>NEW.evidence OR OLD.created_at<>NEW.created_at
 BEGIN SELECT RAISE(ABORT,'immutable_credit_adjustment'); END;
