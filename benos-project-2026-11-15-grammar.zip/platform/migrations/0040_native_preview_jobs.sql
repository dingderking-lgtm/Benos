CREATE TABLE native_preview_jobs (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT NOT NULL REFERENCES projects(id), site_id TEXT NOT NULL REFERENCES sites(id),
 version_id TEXT REFERENCES design_versions(id), candidate_id TEXT REFERENCES design_candidates(id),
 request_key TEXT NOT NULL, request_hash TEXT NOT NULL, page_key TEXT NOT NULL,
 connection_hash TEXT NOT NULL, source_json TEXT NOT NULL CHECK(json_valid(source_json)), sources_json TEXT NOT NULL CHECK(json_valid(sources_json)),
 bundle_id TEXT NOT NULL UNIQUE, bundle_metadata_json TEXT NOT NULL CHECK(json_valid(bundle_metadata_json)), bundle_progress_json TEXT,
 state TEXT NOT NULL DEFAULT 'processing' CHECK(state IN ('processing','ready','cancelled','expired','failed')),
 phase TEXT NOT NULL DEFAULT 'transfer' CHECK(phase IN ('transfer','render','artifacts','finalize','complete')),
 completed_steps INTEGER NOT NULL DEFAULT 0 CHECK(completed_steps>=0), render_json TEXT CHECK(render_json IS NULL OR json_valid(render_json)),
 preview_expires_at_ms INTEGER, artifact_expires_at_ms INTEGER, deadline_ms INTEGER NOT NULL, error_code TEXT,
 lease_token TEXT, lease_until_ms INTEGER,
 cleanup_state TEXT NOT NULL DEFAULT 'pending' CHECK(cleanup_state IN ('pending','purging','purged')),
 remote_cleanup_state TEXT NOT NULL DEFAULT 'pending' CHECK(remote_cleanup_state IN ('pending','confirmed')),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key), CHECK((version_id IS NULL)<>(candidate_id IS NULL)), CHECK(state<>'ready' OR (render_json IS NOT NULL AND preview_expires_at_ms IS NOT NULL))
);
CREATE INDEX native_preview_jobs_pending ON native_preview_jobs(state,updated_at);
CREATE INDEX native_preview_jobs_owner ON native_preview_jobs(user_id,project_id,created_at);
CREATE TABLE native_preview_artifacts (
 job_id TEXT NOT NULL REFERENCES native_preview_jobs(id), file TEXT NOT NULL, byte_size INTEGER NOT NULL CHECK(byte_size BETWEEN 1 AND 16777216),
 sha256 TEXT NOT NULL CHECK(length(sha256)=64), mime_type TEXT NOT NULL CHECK(mime_type IN ('text/html','image/svg+xml','image/png','image/jpeg','image/webp','image/gif')),
 object_key TEXT NOT NULL UNIQUE, received_bytes INTEGER NOT NULL DEFAULT 0 CHECK(received_bytes BETWEEN 0 AND byte_size),
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','ready')), etag TEXT,
 PRIMARY KEY(job_id,file), CHECK((file='preview.html' AND mime_type='text/html') OR (file<>'preview.html' AND mime_type<>'text/html' AND (mime_type<>'image/svg+xml' OR byte_size<=1048576)))
);
CREATE TABLE native_preview_chunks (
 job_id TEXT NOT NULL, file TEXT NOT NULL, chunk_index INTEGER NOT NULL CHECK(chunk_index BETWEEN 0 AND 15),
 byte_size INTEGER NOT NULL CHECK(byte_size BETWEEN 1 AND 1048576), sha256 TEXT NOT NULL CHECK(length(sha256)=64), object_key TEXT NOT NULL UNIQUE, etag TEXT,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','ready')), purged_at TEXT, PRIMARY KEY(job_id,file,chunk_index),
 FOREIGN KEY(job_id,file) REFERENCES native_preview_artifacts(job_id,file)
);
CREATE TRIGGER native_preview_job_identity BEFORE UPDATE ON native_preview_jobs WHEN
 NEW.id<>OLD.id OR NEW.user_id<>OLD.user_id OR NEW.project_id<>OLD.project_id OR NEW.site_id<>OLD.site_id OR NEW.version_id IS NOT OLD.version_id OR NEW.candidate_id IS NOT OLD.candidate_id OR NEW.request_key<>OLD.request_key OR NEW.request_hash<>OLD.request_hash OR NEW.page_key<>OLD.page_key OR NEW.connection_hash<>OLD.connection_hash OR NEW.source_json<>OLD.source_json OR NEW.sources_json<>OLD.sources_json OR NEW.bundle_id<>OLD.bundle_id OR NEW.bundle_metadata_json<>OLD.bundle_metadata_json OR NEW.deadline_ms<>OLD.deadline_ms OR NEW.created_at<>OLD.created_at OR (OLD.render_json IS NOT NULL AND NEW.render_json IS NOT OLD.render_json) OR (OLD.preview_expires_at_ms IS NOT NULL AND NEW.preview_expires_at_ms IS NOT OLD.preview_expires_at_ms) OR (OLD.artifact_expires_at_ms IS NOT NULL AND NEW.artifact_expires_at_ms IS NOT OLD.artifact_expires_at_ms)
BEGIN SELECT RAISE(ABORT,'native_preview_job_identity_immutable'); END;
CREATE TRIGGER native_preview_artifact_identity BEFORE UPDATE ON native_preview_artifacts WHEN
 NEW.job_id<>OLD.job_id OR NEW.file<>OLD.file OR NEW.byte_size<>OLD.byte_size OR NEW.sha256<>OLD.sha256 OR NEW.mime_type<>OLD.mime_type OR NEW.object_key<>OLD.object_key OR (OLD.state='ready' AND (NEW.state<>'ready' OR NEW.etag IS NOT OLD.etag))
BEGIN SELECT RAISE(ABORT,'native_preview_artifact_immutable'); END;
CREATE TRIGGER native_preview_chunk_identity BEFORE UPDATE ON native_preview_chunks WHEN
 NEW.job_id<>OLD.job_id OR NEW.file<>OLD.file OR NEW.chunk_index<>OLD.chunk_index OR NEW.byte_size<>OLD.byte_size OR NEW.sha256<>OLD.sha256 OR NEW.object_key<>OLD.object_key OR (OLD.state='ready' AND (NEW.state<>'ready' OR NEW.etag IS NOT OLD.etag))
BEGIN SELECT RAISE(ABORT,'native_preview_chunk_immutable'); END;
