ALTER TABLE orders ADD COLUMN payment_agreement_id TEXT REFERENCES payment_agreements(id);
CREATE TABLE financial_entitlement_operations (
 id TEXT PRIMARY KEY,case_id TEXT NOT NULL REFERENCES financial_cases(id),order_id TEXT NOT NULL REFERENCES orders(id),user_id TEXT NOT NULL REFERENCES users(id),actor_id TEXT NOT NULL REFERENCES users(id),
 direction TEXT NOT NULL CHECK(direction IN ('revoke','restore')),target_kind TEXT NOT NULL CHECK(target_kind IN ('subscription','annual')),target_id TEXT NOT NULL,
 parent_id TEXT REFERENCES financial_entitlement_operations(id),original_state TEXT NOT NULL,
 request_key TEXT NOT NULL,payload_hash TEXT NOT NULL,attempt_nonce TEXT NOT NULL,
 cancel_renewal INTEGER NOT NULL CHECK(cancel_renewal IN (0,1)),renewal_continues_confirmed INTEGER NOT NULL CHECK(renewal_continues_confirmed IN (0,1)),
 state TEXT NOT NULL CHECK(state IN ('pending_billing_change','pending_local_change','completed')),agreement_id TEXT REFERENCES payment_agreements(id),
 reason TEXT NOT NULL,evidence TEXT NOT NULL,error_code TEXT,created_at TEXT NOT NULL,completed_at TEXT,
 UNIQUE(actor_id,request_key),CHECK((direction='revoke' AND parent_id IS NULL) OR (direction='restore' AND parent_id IS NOT NULL))
);
CREATE UNIQUE INDEX one_entitlement_restoration ON financial_entitlement_operations(parent_id) WHERE direction='restore';
CREATE TABLE financial_entitlement_claims (
 target_kind TEXT NOT NULL,target_id TEXT NOT NULL,operation_id TEXT NOT NULL UNIQUE REFERENCES financial_entitlement_operations(id),PRIMARY KEY(target_kind,target_id)
);
ALTER TABLE subscriptions ADD COLUMN financial_revoked_by TEXT REFERENCES financial_entitlement_operations(id);
ALTER TABLE hosting_entitlements ADD COLUMN financial_revoked_by TEXT REFERENCES financial_entitlement_operations(id);
ALTER TABLE credit_grants ADD COLUMN entitlement_revoked_by TEXT REFERENCES financial_entitlement_operations(id);
