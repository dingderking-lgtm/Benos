-- Private advanced JSON buffers. Editing a buffer never changes a design head.
CREATE TABLE manifest_edits (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT NOT NULL REFERENCES projects(id),
 request_key TEXT NOT NULL, request_hash TEXT NOT NULL,
 base_version_id TEXT REFERENCES design_versions(id), source_version_id TEXT REFERENCES design_versions(id),
 mode TEXT NOT NULL CHECK(mode IN ('source','upload')), file_name TEXT NOT NULL,
 source_hash TEXT, input_bytes INTEGER NOT NULL CHECK(input_bytes BETWEEN 1 AND 10485760),
 received_bytes INTEGER NOT NULL DEFAULT 0 CHECK(received_bytes BETWEEN 0 AND input_bytes),
 split_offset INTEGER NOT NULL DEFAULT 0 CHECK(split_offset BETWEEN 0 AND input_bytes),
 total_bytes INTEGER NOT NULL CHECK(total_bytes BETWEEN 0 AND 10485760),
 segment_count INTEGER NOT NULL DEFAULT 0 CHECK(segment_count BETWEEN 0 AND 161),
 revision INTEGER NOT NULL DEFAULT 0 CHECK(revision>=0), completed_steps INTEGER NOT NULL DEFAULT 0 CHECK(completed_steps>=0),
 state TEXT NOT NULL CHECK(state IN ('uploading','preparing','editing','committing','saved','cancelled','expired','failed')),
 result_version_id TEXT REFERENCES design_versions(id), error_code TEXT,
 cleanup_state TEXT NOT NULL DEFAULT 'pending' CHECK(cleanup_state IN ('pending','purging','purged')),
 lease_token TEXT, lease_until_ms INTEGER, expires_at_ms INTEGER NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key), CHECK((mode='source')=(source_version_id IS NOT NULL)),
 CHECK(state<>'saved' OR result_version_id IS NOT NULL)
);
CREATE INDEX manifest_edits_pending ON manifest_edits(state,updated_at);
CREATE INDEX manifest_edits_owner ON manifest_edits(user_id,project_id,cleanup_state);
CREATE TABLE manifest_edit_objects (
 id TEXT PRIMARY KEY, edit_id TEXT NOT NULL REFERENCES manifest_edits(id), object_key TEXT NOT NULL UNIQUE,
 byte_size INTEGER NOT NULL CHECK(byte_size BETWEEN 0 AND 1048576), sha256 TEXT NOT NULL CHECK(length(sha256)=64),
 state TEXT NOT NULL DEFAULT 'staging' CHECK(state IN ('staging','ready')), etag TEXT,
 created_at TEXT NOT NULL, CHECK(state<>'ready' OR etag IS NOT NULL)
);
CREATE INDEX manifest_edit_objects_task ON manifest_edit_objects(edit_id);
CREATE TABLE manifest_edit_chunks (
 edit_id TEXT NOT NULL REFERENCES manifest_edits(id), chunk_index INTEGER NOT NULL CHECK(chunk_index BETWEEN 0 AND 9),
 byte_offset INTEGER NOT NULL CHECK(byte_offset=chunk_index*1048576),
 object_id TEXT NOT NULL UNIQUE REFERENCES manifest_edit_objects(id), PRIMARY KEY(edit_id,chunk_index)
);
CREATE TABLE manifest_edit_segments (
 edit_id TEXT NOT NULL REFERENCES manifest_edits(id), segment_index INTEGER NOT NULL CHECK(segment_index BETWEEN 0 AND 160),
 object_id TEXT NOT NULL REFERENCES manifest_edit_objects(id), PRIMARY KEY(edit_id,segment_index)
);
CREATE TABLE manifest_edit_operations (
 edit_id TEXT NOT NULL REFERENCES manifest_edits(id), request_key TEXT NOT NULL, request_hash TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('patch','commit')), expected_revision INTEGER NOT NULL CHECK(expected_revision>=0),
 segment_index INTEGER, expected_sha256 TEXT, object_id TEXT REFERENCES manifest_edit_objects(id),
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','succeeded','failed')), error_code TEXT,
 result_revision INTEGER, result_version_id TEXT REFERENCES design_versions(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 PRIMARY KEY(edit_id,request_key)
);
CREATE TRIGGER manifest_edit_identity BEFORE UPDATE ON manifest_edits WHEN
 NEW.id<>OLD.id OR NEW.user_id<>OLD.user_id OR NEW.project_id<>OLD.project_id OR NEW.request_key<>OLD.request_key OR NEW.request_hash<>OLD.request_hash OR NEW.base_version_id IS NOT OLD.base_version_id OR NEW.source_version_id IS NOT OLD.source_version_id OR NEW.mode<>OLD.mode OR NEW.file_name<>OLD.file_name OR NEW.source_hash IS NOT OLD.source_hash OR NEW.input_bytes<>OLD.input_bytes OR NEW.expires_at_ms<>OLD.expires_at_ms OR NEW.created_at<>OLD.created_at OR (OLD.result_version_id IS NOT NULL AND NEW.result_version_id IS NOT OLD.result_version_id)
BEGIN SELECT RAISE(ABORT,'manifest_edit_identity_immutable'); END;
CREATE TRIGGER manifest_edit_object_identity BEFORE UPDATE ON manifest_edit_objects WHEN
 NEW.id<>OLD.id OR NEW.edit_id<>OLD.edit_id OR NEW.object_key<>OLD.object_key OR NEW.byte_size<>OLD.byte_size OR NEW.sha256<>OLD.sha256 OR NEW.created_at<>OLD.created_at OR (OLD.state='ready' AND (NEW.state<>'ready' OR NEW.etag IS NOT OLD.etag))
BEGIN SELECT RAISE(ABORT,'manifest_edit_object_immutable'); END;
CREATE TRIGGER manifest_edit_chunk_identity BEFORE UPDATE ON manifest_edit_chunks
BEGIN SELECT RAISE(ABORT,'manifest_edit_chunk_immutable'); END;
CREATE TRIGGER manifest_edit_operation_identity BEFORE UPDATE ON manifest_edit_operations WHEN
 NEW.edit_id<>OLD.edit_id OR NEW.request_key<>OLD.request_key OR NEW.request_hash<>OLD.request_hash OR NEW.kind<>OLD.kind OR NEW.expected_revision<>OLD.expected_revision OR NEW.segment_index IS NOT OLD.segment_index OR NEW.expected_sha256 IS NOT OLD.expected_sha256 OR NEW.object_id IS NOT OLD.object_id OR NEW.created_at<>OLD.created_at OR (OLD.state<>'pending' AND (NEW.state<>OLD.state OR NEW.result_revision IS NOT OLD.result_revision OR NEW.result_version_id IS NOT OLD.result_version_id))
BEGIN SELECT RAISE(ABORT,'manifest_edit_operation_immutable'); END;
