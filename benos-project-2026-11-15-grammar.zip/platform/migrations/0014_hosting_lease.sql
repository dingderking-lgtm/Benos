CREATE TABLE hosting_lease_sync (
 site_id TEXT PRIMARY KEY REFERENCES sites(id),last_issued_at INTEGER NOT NULL DEFAULT 0,
 valid_until INTEGER,hosting_active INTEGER NOT NULL DEFAULT 0 CHECK(hosting_active IN (0,1)),
 publish_allowed INTEGER NOT NULL DEFAULT 0 CHECK(publish_allowed IN (0,1)),
 state TEXT NOT NULL CHECK(state IN ('pending','synced','uncertain')),error_code TEXT,
 last_synced_at TEXT,updated_at TEXT NOT NULL
);
