-- The reservation guard of a design step still refused every step after the task's stored `max_steps` (six), which
-- surfaced to customers as "设计服务暂时繁忙" on step seven. A message-started task runs under the ceiling kept in
-- code (migration 0063 removed the six-step CHECK for the same reason); this guard keeps every other condition —
-- the step being prepared, the owner, the provider, the exact per-step amount and the task's spending limit — and
-- only stops comparing the step number with the old six.
DROP TRIGGER ai_workflow_reservation_budget;
CREATE TRIGGER ai_workflow_reservation_budget BEFORE INSERT ON api_reservations
WHEN EXISTS(SELECT 1 FROM ai_workflow_steps WHERE reservation_id=NEW.id)
BEGIN
 SELECT CASE WHEN NOT EXISTS(
  SELECT 1 FROM ai_workflow_steps s JOIN ai_workflows w ON w.id=s.workflow_id
  WHERE s.reservation_id=NEW.id AND s.state='preparing' AND s.ordinal<=48
   AND w.user_id=NEW.user_id AND w.provider_id=NEW.provider_id
   AND NEW.amount_micros=w.per_step_micros AND w.state='processing'
   AND NEW.amount_micros+COALESCE((SELECT SUM(CASE WHEN r.state IN ('settled','released') THEN r.actual_micros ELSE r.amount_micros END)
    FROM ai_workflow_steps previous JOIN api_reservations r ON r.id=previous.reservation_id WHERE previous.workflow_id=w.id),0)<=w.max_cost_micros
 ) THEN RAISE(ABORT,'workflow_budget_exceeded') END;
END;
