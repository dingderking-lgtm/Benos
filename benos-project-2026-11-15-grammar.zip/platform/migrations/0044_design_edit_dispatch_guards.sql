-- Workspace closure participates in the SAME transaction as reserve/dispatch.
-- Settlements, unknown-cost evidence and confirmed releases remain permitted.
CREATE TRIGGER design_edit_reservation_guard BEFORE INSERT ON api_reservations
WHEN EXISTS(SELECT 1 FROM ai_workflow_steps s JOIN ai_workflows a ON a.id=s.workflow_id WHERE s.reservation_id=NEW.id AND a.workspace_id IS NOT NULL)
BEGIN
 SELECT CASE WHEN NOT EXISTS(
  SELECT 1 FROM ai_workflow_steps s JOIN ai_workflows a ON a.id=s.workflow_id
   JOIN design_edit_workspaces w ON w.id=a.workspace_id JOIN projects p ON p.id=w.project_id
  WHERE s.reservation_id=NEW.id AND w.user_id=NEW.user_id AND a.user_id=w.user_id AND a.project_id=w.project_id
   AND a.state='processing' AND a.lease_until_ms>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)
   AND w.state='ready' AND w.candidate_id IS NULL AND w.expires_at_ms>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)
   AND p.archived_at IS NULL AND p.current_version_id=w.base_version_id
 ) THEN RAISE(ABORT,'edit_workspace_dispatch_denied') END;
END;
CREATE TRIGGER design_edit_dispatch_guard BEFORE UPDATE OF state ON api_reservations
WHEN OLD.state='reserved' AND NEW.state='dispatching' AND EXISTS(SELECT 1 FROM ai_workflow_steps s JOIN ai_workflows a ON a.id=s.workflow_id WHERE s.reservation_id=NEW.id AND a.workspace_id IS NOT NULL)
BEGIN
 SELECT CASE WHEN NOT EXISTS(
  SELECT 1 FROM ai_workflow_steps s JOIN ai_workflows a ON a.id=s.workflow_id
   JOIN design_edit_workspaces w ON w.id=a.workspace_id JOIN projects p ON p.id=w.project_id
  WHERE s.reservation_id=NEW.id AND w.user_id=NEW.user_id AND a.user_id=w.user_id AND a.project_id=w.project_id
   AND a.state='processing' AND a.lease_until_ms>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)
   AND w.state='ready' AND w.candidate_id IS NULL AND w.expires_at_ms>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)
   AND p.archived_at IS NULL AND p.current_version_id=w.base_version_id
 ) THEN RAISE(ABORT,'edit_workspace_dispatch_denied') END;
END;
