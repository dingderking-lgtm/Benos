-- Schema-only compatibility for deployments retaining the original six-kind
-- CHECK. Tags use physical kind=category and a reserved internal @tag/ slug;
-- public/admin API types and slugs remain the logical values in the snapshots.
-- Existing rows require no UPDATE/backfill and keep their original semantics.
ALTER TABLE content_entries ADD COLUMN kind_override TEXT CHECK(kind_override IS NULL OR kind_override='tag');
DROP INDEX IF EXISTS content_published_slug_unique;
DROP INDEX IF EXISTS content_published_slug;
CREATE UNIQUE INDEX content_published_slug_unique
 ON content_entries(COALESCE(kind_override,kind),json_extract(published_json,'$.slug'))
 WHERE state='published' AND published_json IS NOT NULL;
CREATE INDEX content_logical_listing ON content_entries(COALESCE(kind_override,kind),state,updated_at DESC,id DESC);
