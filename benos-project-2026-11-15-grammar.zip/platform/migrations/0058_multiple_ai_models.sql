-- Keep one active version per model while allowing several code/image models
-- from the same provider. Existing configuration IDs and secrets are unchanged.
DROP INDEX one_active_integration_per_kind;
DROP INDEX one_active_text_integration_per_provider;
CREATE UNIQUE INDEX one_active_integration_per_kind ON integration_configs(kind)
 WHERE status='active' AND kind NOT IN ('hosting','text','image');
CREATE UNIQUE INDEX one_active_ai_integration_per_model
 ON integration_configs(kind,provider,json_extract(public_config_json,'$.model'))
 WHERE status='active' AND kind IN ('text','image');
