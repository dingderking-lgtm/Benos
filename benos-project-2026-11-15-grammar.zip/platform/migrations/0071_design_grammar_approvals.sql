-- Grammar (bnl-0) approval ledger. One row per approved grammar identity: the exact compiler bytes,
-- the brand ranges a model may choose from, and the exemplar it is measured against. A build that
-- does not match an approved row cannot compile a production site.
CREATE TABLE design_grammar_approvals (
  grammar_digest TEXT NOT NULL,
  spec_digest TEXT NOT NULL,
  exemplar_digest TEXT NOT NULL,
  brand_ranges_json TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('approved','rejected','draft')),
  reviewer_id TEXT NOT NULL REFERENCES users(id),
  reviewed_at TEXT NOT NULL,
  PRIMARY KEY(grammar_digest, spec_digest, exemplar_digest)
);
CREATE INDEX design_grammar_approvals_state ON design_grammar_approvals(state, reviewed_at DESC);
