-- R4-m4: a domain change whose TXT ownership check passed is never treated as
-- unverified (7-day expiry, customer cancel, displacement by a proven account).
ALTER TABLE hosting_domain_changes ADD COLUMN ownership_verified_at TEXT;
