CREATE TABLE mutation_guards (
 id TEXT PRIMARY KEY,
 permitted INTEGER NOT NULL CONSTRAINT mutation_revision_ok CHECK(permitted=1)
);
