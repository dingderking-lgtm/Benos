CREATE TABLE native_previews (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id),
 project_id TEXT NOT NULL REFERENCES projects(id),
 object_key TEXT NOT NULL UNIQUE,
 html_sha256 TEXT NOT NULL,
 byte_size INTEGER NOT NULL CHECK(byte_size>0 AND byte_size<=8388608),
 metadata_json TEXT NOT NULL,
 created_at TEXT NOT NULL,
 expires_at TEXT NOT NULL
);
CREATE INDEX native_previews_expiry ON native_previews(expires_at);
CREATE INDEX native_previews_owner ON native_previews(user_id,project_id,created_at);
