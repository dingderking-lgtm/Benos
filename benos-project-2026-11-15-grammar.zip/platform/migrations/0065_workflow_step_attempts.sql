-- A design round that was sent to the model but came back without a usage receipt (the stream broke, timed out or
-- was refused) no longer parks the whole task for a manual cost check (owner decision, 2026-11-13). The attempt is
-- closed at once on a metered estimate, the rest of its reservation is returned, and the same round is asked again
-- under a new reservation. The step keeps count of those attempts and of what they cost, so the task's usage still
-- adds up after the step's reservation has been replaced.
ALTER TABLE ai_workflow_steps ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ai_workflow_steps ADD COLUMN retired_micros INTEGER NOT NULL DEFAULT 0;
