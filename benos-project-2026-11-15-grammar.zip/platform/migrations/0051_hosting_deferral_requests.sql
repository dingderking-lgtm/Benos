-- Round-2 money fixes (N1, N2, N7): a durable request to re-check an account's
-- annual hosting years against idle membership-slot capacity. It is written in
-- the same batch as the event that can leave a slot idle (a membership term is
-- created, an unfreeze completes, a pay-first year is anchored at the opening),
-- so a failed or interrupted follow-up is retried by maintenance until it runs.
-- One row per account; from_at keeps the earliest start still to be checked.
CREATE TABLE hosting_deferral_requests (
 user_id TEXT PRIMARY KEY REFERENCES users(id),
 from_at TEXT NOT NULL,
 reason TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1,
 attempts INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE INDEX hosting_deferral_requests_due ON hosting_deferral_requests(updated_at);
