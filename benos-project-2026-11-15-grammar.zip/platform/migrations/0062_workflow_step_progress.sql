-- Live progress of a design step while the model is still writing: a small summary for the conversation
-- (progress_json) and the draft of the files being written for the canvas (progress_draft). Both are display
-- material only and are cleared as soon as the model's answer is stored.
ALTER TABLE ai_workflow_steps ADD COLUMN progress_json TEXT;
ALTER TABLE ai_workflow_steps ADD COLUMN progress_draft TEXT;
