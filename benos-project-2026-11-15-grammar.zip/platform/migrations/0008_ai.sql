CREATE TABLE ai_jobs (
 id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),project_id TEXT NOT NULL REFERENCES projects(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id),request_key TEXT NOT NULL,request_hash TEXT NOT NULL,
 base_version_id TEXT REFERENCES design_versions(id),reservation_id TEXT REFERENCES api_reservations(id),
 state TEXT NOT NULL CHECK(state IN ('preparing','reserved','running','succeeded','failed','uncertain')),
 request_json TEXT NOT NULL,pricing_json TEXT NOT NULL,response_json TEXT,usage_json TEXT,
 provider_response_id TEXT,result_version_id TEXT REFERENCES design_versions(id),error_code TEXT,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(user_id,request_key)
);
CREATE INDEX ai_jobs_user_created ON ai_jobs(user_id,created_at);
