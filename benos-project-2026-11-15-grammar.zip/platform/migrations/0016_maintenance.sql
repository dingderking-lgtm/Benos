CREATE TABLE maintenance_runs (
  name TEXT PRIMARY KEY,
  lease_token TEXT,
  lease_expires_at_ms INTEGER NOT NULL DEFAULT 0,
  last_started_at TEXT,
  last_finished_at TEXT,
  last_result_json TEXT
);
