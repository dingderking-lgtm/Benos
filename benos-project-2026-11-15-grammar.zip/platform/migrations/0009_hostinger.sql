CREATE TABLE hosting_provider_intents (
 job_id TEXT PRIMARY KEY REFERENCES provisioning_jobs(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 site_id TEXT NOT NULL UNIQUE REFERENCES sites(id), domain TEXT NOT NULL UNIQUE,
 account_username TEXT NOT NULL, hosting_order_id INTEGER NOT NULL CHECK(hosting_order_id>0),
 website_create_attempted INTEGER NOT NULL DEFAULT 0 CHECK(website_create_attempted IN (0,1)),
 website_ready INTEGER NOT NULL DEFAULT 0 CHECK(website_ready IN (0,1)),
 database_name TEXT NOT NULL UNIQUE, database_user TEXT NOT NULL UNIQUE, database_secret_ciphertext TEXT NOT NULL,
 database_create_attempted INTEGER NOT NULL DEFAULT 0 CHECK(database_create_attempted IN (0,1)),
 database_ready INTEGER NOT NULL DEFAULT 0 CHECK(database_ready IN (0,1)),
 root_directory TEXT, required_dns_txt TEXT, next_poll_at TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
