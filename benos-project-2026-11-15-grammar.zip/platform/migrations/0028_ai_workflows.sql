-- Schema-only. A workflow is an explicit finite authorization, not an unlimited agent.
CREATE TABLE ai_workflows (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
 project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id) ON DELETE RESTRICT,
 provider_id TEXT NOT NULL,
 request_key TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 base_version_id TEXT REFERENCES design_versions(id) ON DELETE RESTRICT,
 scope_json TEXT NOT NULL,
 requirements_json TEXT NOT NULL,
 pricing_json TEXT NOT NULL,
 reference_images_json TEXT NOT NULL,
 base_manifest_json TEXT,
 manifest_json TEXT NOT NULL,
 validated_hash TEXT,
 max_steps INTEGER NOT NULL CHECK (max_steps BETWEEN 1 AND 6),
 max_cost_micros INTEGER NOT NULL CHECK (typeof(max_cost_micros)='integer' AND max_cost_micros BETWEEN 1 AND 1000000000),
 per_step_micros INTEGER NOT NULL CHECK (typeof(per_step_micros)='integer' AND per_step_micros>0 AND per_step_micros<=max_cost_micros),
 state TEXT NOT NULL DEFAULT 'ready' CHECK (state IN ('ready','processing','succeeded','failed','uncertain','budget_exhausted','steps_exhausted')),
 lease_token TEXT,
 lease_until_ms INTEGER,
 candidate_id TEXT REFERENCES design_candidates(id) ON DELETE RESTRICT,
 error_code TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key)
);
CREATE INDEX ai_workflows_project ON ai_workflows(user_id,project_id,created_at);
CREATE TABLE ai_workflow_steps (
 id TEXT PRIMARY KEY,
 workflow_id TEXT NOT NULL REFERENCES ai_workflows(id) ON DELETE RESTRICT,
 ordinal INTEGER NOT NULL CHECK (ordinal BETWEEN 1 AND 6),
 reservation_id TEXT NOT NULL UNIQUE,
 state TEXT NOT NULL DEFAULT 'preparing' CHECK(state IN ('preparing','dispatching','responded','completed','uncertain','failed')),
 response_json TEXT,
 tool_results_json TEXT,
 error_code TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(workflow_id,ordinal)
);
-- This trigger executes inside ledger.reserve's SAME D1 transaction, alongside
-- user/source and provider guards. Settled actuals and all unknown holds count.
CREATE TRIGGER ai_workflow_reservation_budget BEFORE INSERT ON api_reservations
WHEN EXISTS(SELECT 1 FROM ai_workflow_steps WHERE reservation_id=NEW.id)
BEGIN
 SELECT CASE WHEN NOT EXISTS(
  SELECT 1 FROM ai_workflow_steps s JOIN ai_workflows w ON w.id=s.workflow_id
  WHERE s.reservation_id=NEW.id AND s.state='preparing' AND s.ordinal<=w.max_steps
   AND w.user_id=NEW.user_id AND w.provider_id=NEW.provider_id
   AND NEW.amount_micros=w.per_step_micros AND w.state='processing'
   AND NEW.amount_micros+COALESCE((SELECT SUM(CASE WHEN r.state IN ('settled','released') THEN r.actual_micros ELSE r.amount_micros END)
    FROM ai_workflow_steps previous JOIN api_reservations r ON r.id=previous.reservation_id WHERE previous.workflow_id=w.id),0)<=w.max_cost_micros
 ) THEN RAISE(ABORT,'workflow_budget_exceeded') END;
END;
