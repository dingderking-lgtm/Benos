ALTER TABLE provisioning_jobs ADD COLUMN lease_token TEXT;
CREATE TABLE site_connections (
 id TEXT PRIMARY KEY, site_id TEXT NOT NULL UNIQUE REFERENCES sites(id),
 origin TEXT NOT NULL, key_id TEXT NOT NULL, secret_ciphertext TEXT NOT NULL,
 health_path TEXT NOT NULL DEFAULT '/benos-health.php',
 cms_version TEXT NOT NULL, last_verified_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX provisioning_owner ON provisioning_jobs(user_id,created_at);
