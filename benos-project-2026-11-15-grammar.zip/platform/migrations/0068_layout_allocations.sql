CREATE TABLE design_layout_cursors (
 user_id TEXT PRIMARY KEY REFERENCES users(id),
 sequence INTEGER NOT NULL DEFAULT 0 CHECK(sequence>=0)
);
CREATE TABLE design_layout_allocations (
 workflow_id TEXT PRIMARY KEY REFERENCES ai_workflows(id),
 user_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL,
 sequence INTEGER NOT NULL CHECK(sequence>0),
 source TEXT NOT NULL CHECK(source IN ('automatic','user','reference')),
 combination_hash TEXT NOT NULL,
 primary_media_composition TEXT NOT NULL,
 plan_json TEXT NOT NULL CHECK(json_valid(plan_json)),
 created_at TEXT NOT NULL,
 UNIQUE(user_id,request_key),UNIQUE(user_id,sequence)
);
CREATE INDEX design_layout_recent ON design_layout_allocations(user_id,source,sequence DESC);
CREATE TRIGGER design_layout_compare BEFORE INSERT ON design_layout_allocations BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM design_layout_cursors WHERE user_id=NEW.user_id AND sequence=NEW.sequence-1)
 THEN RAISE(ABORT,'layout_allocation_conflict') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM ai_workflows WHERE id=NEW.workflow_id AND user_id=NEW.user_id AND request_key=NEW.request_key)
 THEN RAISE(ABORT,'layout_allocation_workflow_mismatch') END;
END;
CREATE TRIGGER design_layout_advance AFTER INSERT ON design_layout_allocations BEGIN
 UPDATE design_layout_cursors SET sequence=NEW.sequence WHERE user_id=NEW.user_id;
END;
