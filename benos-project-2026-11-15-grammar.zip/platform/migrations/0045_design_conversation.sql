-- Immutable user intent exists independently of pricing, reservation and dispatch.
CREATE TABLE design_conversation_turns (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT NOT NULL REFERENCES projects(id),
 request_key TEXT NOT NULL, request_hash TEXT NOT NULL, prompt TEXT NOT NULL, style TEXT,
 scope_json TEXT NOT NULL, base_version_id TEXT, reference_ids_json TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'received' CHECK(state IN ('received','linked','failed')),
 workflow_id TEXT UNIQUE REFERENCES ai_workflows(id), error_code TEXT,error_message TEXT,error_status INTEGER,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(user_id,request_key),
 CHECK((state='linked')=(workflow_id IS NOT NULL)),
 CHECK((state='failed')=(error_code IS NOT NULL))
);
CREATE INDEX conversation_project_page ON design_conversation_turns(user_id,project_id,created_at DESC,id DESC);
CREATE INDEX conversation_legacy_job_page ON ai_jobs(user_id,project_id,created_at DESC,id DESC);
ALTER TABLE ai_workflow_steps ADD COLUMN public_reply TEXT;
CREATE TRIGGER conversation_workflow_guard BEFORE INSERT ON ai_workflows
WHEN EXISTS(SELECT 1 FROM design_conversation_turns t WHERE t.user_id=NEW.user_id AND t.request_key=NEW.request_key
 AND (t.state='failed' OR t.project_id<>NEW.project_id OR t.request_hash<>NEW.request_hash))
BEGIN
 SELECT RAISE(ABORT,'conversation_intent_conflict');
END;
CREATE TRIGGER conversation_workflow_link AFTER INSERT ON ai_workflows
BEGIN
 UPDATE design_conversation_turns SET state='linked',workflow_id=NEW.id,updated_at=NEW.created_at
 WHERE user_id=NEW.user_id AND request_key=NEW.request_key AND project_id=NEW.project_id AND request_hash=NEW.request_hash AND state='received';
END;
CREATE TRIGGER conversation_turn_owner BEFORE INSERT ON design_conversation_turns
WHEN NOT EXISTS(SELECT 1 FROM projects p WHERE p.id=NEW.project_id AND p.user_id=NEW.user_id)
 OR EXISTS(SELECT 1 FROM json_each(NEW.reference_ids_json) ref WHERE NOT EXISTS(
 SELECT 1 FROM project_media_inventory m WHERE m.id=ref.value AND m.project_id=NEW.project_id AND m.user_id=NEW.user_id AND m.state='ready'))
BEGIN
 SELECT RAISE(ABORT,'conversation_reference_unavailable');
END;
CREATE VIEW design_conversation_index AS
 SELECT t.id transcript_id,t.user_id,t.project_id,t.created_at,t.request_key,t.prompt,t.style,t.reference_ids_json,
 t.workflow_id,NULL legacy_job_id,t.scope_json,t.base_version_id,coalesce(w.state,t.state) state,coalesce(w.error_code,t.error_code) error_code,
 c.state candidate_state,c.adopted_version_id version_id,w.candidate_id,coalesce(w.updated_at,t.updated_at) updated_at
 FROM design_conversation_turns t LEFT JOIN ai_workflows w ON w.id=t.workflow_id LEFT JOIN design_candidates c ON c.id=w.candidate_id
 UNION ALL SELECT w.id,w.user_id,w.project_id,w.created_at,w.request_key,json_extract(w.requirements_json,'$.request'),json_extract(w.requirements_json,'$.style'),
 (SELECT json_group_array(json_extract(value,'$.id')) FROM json_each(w.reference_images_json)),w.id,NULL,w.scope_json,w.base_version_id,w.state,w.error_code,
 c.state,c.adopted_version_id,w.candidate_id,w.updated_at
 FROM ai_workflows w LEFT JOIN design_candidates c ON c.id=w.candidate_id WHERE NOT EXISTS(SELECT 1 FROM design_conversation_turns t WHERE t.workflow_id=w.id)
 UNION ALL SELECT j.id,j.user_id,j.project_id,j.created_at,j.request_key,
 CASE WHEN json_valid(j.request_json) THEN CASE WHEN json_valid(json_extract(j.request_json,'$.input')) THEN json_extract(json_extract(j.request_json,'$.input'),'$.request') END END,
 NULL,'[]',NULL,j.id,'{"kind":"site"}',j.base_version_id,j.state,j.error_code,NULL,j.result_version_id,NULL,j.updated_at FROM ai_jobs j;
