-- Extend cash currency without changing any historical USD order or entitlement.
-- D1 keeps foreign_keys ON. All existing orders references use NO ACTION;
-- defer checks until the replacement table exists (no cascading child deletes).
PRAGMA defer_foreign_keys=ON;
CREATE TABLE orders_alipay_upgrade (
 id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),
 kind TEXT NOT NULL CHECK(kind IN ('subscription','topup','hosting')),
 plan_tier TEXT CHECK(plan_tier IN ('go','pro')),amount_cents INTEGER NOT NULL CHECK(amount_cents>0),
 credit_micros INTEGER NOT NULL DEFAULT 0 CHECK(credit_micros>=0),currency TEXT NOT NULL DEFAULT 'USD' CHECK(currency IN ('USD','CNY')),
 state TEXT NOT NULL DEFAULT 'created' CHECK(state IN ('created','pending','paid','failed','expired','refunded','review')),
 provider TEXT,checkout_id TEXT UNIQUE,payment_id TEXT UNIQUE,idempotency_key TEXT NOT NULL,payload_hash TEXT NOT NULL,
 hosting_site_id TEXT,created_at TEXT NOT NULL,expires_at TEXT NOT NULL,paid_at TEXT,
 config_version_id TEXT REFERENCES integration_configs(id),checkout_url TEXT,eligible_until TEXT,fulfilled_at TEXT,
 eligibility_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT order_eligibility CHECK(eligibility_ok=1),
 payment_agreement_id TEXT REFERENCES payment_agreements(id),catalog_version_id TEXT,plan_snapshot_json TEXT,
 UNIQUE(user_id,idempotency_key)
);
-- Refill AFTER renaming the empty replacement: inserts against the original
-- parent name resolve SQLite's deferred references, including the cyclic
-- orders.payment_agreement_id <-> payment_agreements.origin_order_id edge.
CREATE TABLE orders_alipay_backup AS SELECT * FROM orders;
DROP TABLE orders;
ALTER TABLE orders_alipay_upgrade RENAME TO orders;
INSERT INTO orders SELECT id,user_id,kind,plan_tier,amount_cents,credit_micros,currency,state,provider,checkout_id,payment_id,idempotency_key,payload_hash,hosting_site_id,created_at,expires_at,paid_at,config_version_id,checkout_url,eligible_until,fulfilled_at,eligibility_ok,payment_agreement_id,catalog_version_id,plan_snapshot_json FROM orders_alipay_backup;
DROP TABLE orders_alipay_backup;
CREATE INDEX orders_user ON orders(user_id,created_at);
CREATE INDEX orders_revenue_time ON orders((CASE WHEN fulfilled_at IS NOT NULL AND fulfilled_at<paid_at THEN fulfilled_at ELSE paid_at END)) WHERE state IN ('paid','refunded') AND paid_at IS NOT NULL;
CREATE TRIGGER order_catalog_snapshot_immutable BEFORE UPDATE OF catalog_version_id,plan_snapshot_json ON orders
WHEN NEW.catalog_version_id IS NOT OLD.catalog_version_id OR NEW.plan_snapshot_json IS NOT OLD.plan_snapshot_json
BEGIN SELECT RAISE(ABORT,'order_catalog_snapshot_immutable'); END;

CREATE TABLE alipay_payments (
 order_id TEXT PRIMARY KEY REFERENCES orders(id),config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 app_id TEXT NOT NULL,seller_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency='CNY'),
 amount_cents INTEGER NOT NULL CHECK(amount_cents>0),checkout_published_at TEXT,
 trade_no TEXT UNIQUE,trade_status TEXT,paid_at TEXT,verified_at TEXT,next_reconcile_at TEXT NOT NULL,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
CREATE TRIGGER alipay_payment_identity_immutable BEFORE UPDATE OF config_version_id,app_id,seller_id,currency,amount_cents ON alipay_payments
WHEN NEW.config_version_id IS NOT OLD.config_version_id OR NEW.app_id IS NOT OLD.app_id OR NEW.seller_id IS NOT OLD.seller_id OR NEW.currency IS NOT OLD.currency OR NEW.amount_cents IS NOT OLD.amount_cents
BEGIN SELECT RAISE(ABORT,'alipay_payment_identity_immutable'); END;
CREATE TABLE alipay_refunds (
 id TEXT PRIMARY KEY,order_id TEXT NOT NULL REFERENCES orders(id),config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 actor_id TEXT NOT NULL REFERENCES users(id),request_key TEXT NOT NULL,payload_hash TEXT NOT NULL,
 trade_no TEXT NOT NULL,amount_cents INTEGER NOT NULL CHECK(amount_cents>0),currency TEXT NOT NULL CHECK(currency='CNY'),
 reason TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('pending','uncertain','succeeded','failed')),
 provider_state TEXT,last_error_code TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,next_reconcile_at TEXT NOT NULL,
 UNIQUE(actor_id,request_key)
);
CREATE INDEX alipay_refunds_pending ON alipay_refunds(state,next_reconcile_at);
CREATE INDEX alipay_payments_pending ON alipay_payments(next_reconcile_at);
