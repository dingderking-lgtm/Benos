-- Independent bnx approval namespace. No defaults, migration from bns, or seed approvals.
CREATE TABLE design_pattern_v2_reviews (
  pattern_id TEXT NOT NULL,
  variant_id TEXT NOT NULL,
  revision INTEGER NOT NULL CHECK(revision > 0),
  preset_id TEXT NOT NULL,
  artifact_hash TEXT NOT NULL,
  source_graph_hash TEXT NOT NULL,
  notice_bundle_hash TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('approved','rejected','draft')),
  reviewer_id TEXT NOT NULL REFERENCES users(id),
  reviewed_at TEXT NOT NULL,
  PRIMARY KEY(pattern_id,variant_id,revision,preset_id,artifact_hash)
);
CREATE TABLE design_pattern_v2_review_requests (
  actor_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  result_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(actor_id,request_key)
);
