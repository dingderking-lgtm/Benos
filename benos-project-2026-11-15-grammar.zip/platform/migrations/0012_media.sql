CREATE TABLE project_media (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id),
 project_id TEXT NOT NULL REFERENCES projects(id),
 request_key TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 object_key TEXT NOT NULL UNIQUE,
 filename TEXT NOT NULL,
 mime_type TEXT NOT NULL CHECK(mime_type IN ('image/png','image/jpeg','image/webp')),
 extension TEXT NOT NULL CHECK(extension IN ('png','jpg','webp')),
 byte_size INTEGER NOT NULL CHECK(byte_size BETWEEN 1 AND 12582912),
 width INTEGER NOT NULL CHECK(width BETWEEN 1 AND 8192),
 height INTEGER NOT NULL CHECK(height BETWEEN 1 AND 8192),
 sha256 TEXT NOT NULL,
 source TEXT NOT NULL CHECK(source IN ('upload','generation')),
 generation_job_id TEXT,
 state TEXT NOT NULL DEFAULT 'staging' CHECK(state IN ('staging','ready','deleted')),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 deleted_at TEXT,
 UNIQUE(user_id,request_key),
 CHECK(width * height <= 16000000)
);
CREATE INDEX media_project_inventory ON project_media(project_id,user_id,state,created_at);
CREATE INDEX media_project_hash ON project_media(project_id,user_id,sha256,byte_size);

CREATE TABLE image_jobs (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id),
 project_id TEXT NOT NULL REFERENCES projects(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 request_key TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 reservation_id TEXT REFERENCES api_reservations(id),
 state TEXT NOT NULL CHECK(state IN ('preparing','reserved','running','succeeded','failed','uncertain','output_pending')),
 request_json TEXT NOT NULL,
 pricing_json TEXT NOT NULL,
 response_json TEXT,
 usage_json TEXT,
 response_object_key TEXT,
 response_sha256 TEXT,
 provider_request_id TEXT,
 result_media_id TEXT REFERENCES project_media(id),
 error_code TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key)
);
CREATE INDEX image_jobs_owner_project ON image_jobs(user_id,project_id,created_at);
