CREATE TABLE orders (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 kind TEXT NOT NULL CHECK(kind IN ('subscription','topup','hosting')),
 plan_tier TEXT CHECK(plan_tier IN ('go','pro')), amount_cents INTEGER NOT NULL CHECK(amount_cents>0),
 credit_micros INTEGER NOT NULL DEFAULT 0 CHECK(credit_micros>=0), currency TEXT NOT NULL DEFAULT 'USD' CHECK(currency='USD'),
 state TEXT NOT NULL DEFAULT 'created' CHECK(state IN ('created','pending','paid','failed','expired','refunded','review')),
 provider TEXT, checkout_id TEXT UNIQUE, payment_id TEXT UNIQUE,
 idempotency_key TEXT NOT NULL, payload_hash TEXT NOT NULL,
 hosting_site_id TEXT, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, paid_at TEXT,
 UNIQUE(user_id,idempotency_key)
);
CREATE INDEX orders_user ON orders(user_id,created_at);
CREATE TABLE payment_events (
 id TEXT PRIMARY KEY, provider TEXT NOT NULL, event_id TEXT NOT NULL,
 order_id TEXT REFERENCES orders(id), event_type TEXT NOT NULL, payload_hash TEXT NOT NULL,
 state TEXT NOT NULL CHECK(state IN ('received','processed','review','rejected')),
 received_at TEXT NOT NULL, processed_at TEXT, UNIQUE(provider,event_id)
);
CREATE TABLE subscriptions (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), tier TEXT NOT NULL CHECK(tier IN ('go','pro')),
 source TEXT NOT NULL CHECK(source IN ('paid','gift')), order_id TEXT UNIQUE REFERENCES orders(id),
 starts_at TEXT NOT NULL, ends_at TEXT NOT NULL CHECK(ends_at>starts_at),
 state TEXT NOT NULL DEFAULT 'active' CHECK(state IN ('active','cancelled','revoked')),
 auto_renew INTEGER NOT NULL DEFAULT 0 CHECK(auto_renew IN (0,1)),
 included_sites INTEGER NOT NULL CHECK(included_sites>=0), credit_micros INTEGER NOT NULL CHECK(credit_micros>=0),
 topup_allowed INTEGER NOT NULL DEFAULT 0 CHECK(topup_allowed IN (0,1)),
 grant_reference_id TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL
);
CREATE INDEX subscriptions_active ON subscriptions(user_id,starts_at,ends_at,state);
CREATE TABLE sites (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT UNIQUE REFERENCES projects(id),
 name TEXT NOT NULL, domain TEXT NOT NULL UNIQUE, cms_admin_email TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','provisioning','awaiting_dns','connected','publishing','active','suspended','error')),
 connection_id TEXT, current_release_id TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX sites_owner ON sites(user_id,state);
CREATE TABLE hosting_entitlements (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), site_id TEXT NOT NULL REFERENCES sites(id),
 source TEXT NOT NULL CHECK(source IN ('subscription','annual','gift')),
 order_id TEXT REFERENCES orders(id), subscription_id TEXT REFERENCES subscriptions(id),
 starts_at TEXT NOT NULL, ends_at TEXT NOT NULL CHECK(ends_at>starts_at),
 state TEXT NOT NULL DEFAULT 'active' CHECK(state IN ('active','revoked')),
 created_at TEXT NOT NULL, UNIQUE(site_id,order_id)
);
CREATE INDEX hosting_valid ON hosting_entitlements(site_id,starts_at,ends_at,state);
CREATE TABLE provisioning_jobs (
 id TEXT PRIMARY KEY, site_id TEXT NOT NULL REFERENCES sites(id), user_id TEXT NOT NULL REFERENCES users(id),
 kind TEXT NOT NULL CHECK(kind IN ('create','connect','publish','suspend','restore')),
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','running','awaiting_input','succeeded','failed','uncertain')),
 step TEXT NOT NULL, idempotency_key TEXT NOT NULL, payload_hash TEXT NOT NULL,
 config_version_id TEXT REFERENCES integration_configs(id),
 secret_ciphertext TEXT, secret_expires_at TEXT, result_json TEXT, error_code TEXT,
 attempt_count INTEGER NOT NULL DEFAULT 0, lease_until TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(user_id,idempotency_key)
);
