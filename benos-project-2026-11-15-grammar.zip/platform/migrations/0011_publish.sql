CREATE TABLE publication_releases (
 id TEXT PRIMARY KEY,site_id TEXT NOT NULL REFERENCES sites(id),user_id TEXT NOT NULL REFERENCES users(id),
 project_id TEXT NOT NULL REFERENCES projects(id),version_id TEXT NOT NULL REFERENCES design_versions(id),
 previous_version_id TEXT REFERENCES design_versions(id),idempotency_key TEXT NOT NULL,payload_hash TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'preparing' CHECK(state IN ('preparing','prepared','committing','published','rolling_back','rolled_back','failed','uncertain')),
 review_hash TEXT,result_json TEXT,error_code TEXT,lease_until TEXT,lease_token TEXT,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(user_id,idempotency_key)
);
CREATE INDEX publication_site ON publication_releases(site_id,created_at);
CREATE UNIQUE INDEX publication_in_progress ON publication_releases(site_id) WHERE state IN ('preparing','prepared','committing','rolling_back','uncertain');
