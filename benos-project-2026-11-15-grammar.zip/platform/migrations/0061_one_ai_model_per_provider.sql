-- Each purpose exposes one model per provider. Keep the most recently enabled
-- configuration when upgrading a database that allowed several model IDs.
UPDATE integration_configs SET status='disabled'
 WHERE status='active' AND kind IN ('text','image') AND id<>(
  SELECT newer.id FROM integration_configs newer
   WHERE newer.kind=integration_configs.kind AND newer.provider=integration_configs.provider
    AND newer.status='active'
   ORDER BY newer.created_at DESC,newer.id DESC LIMIT 1
 );
DROP INDEX one_active_ai_integration_per_model;
CREATE UNIQUE INDEX one_active_ai_integration_per_provider
 ON integration_configs(kind,provider) WHERE status='active' AND kind IN ('text','image');
