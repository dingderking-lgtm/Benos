PRAGMA foreign_keys = ON;

CREATE TABLE users (
 id TEXT PRIMARY KEY, email TEXT NOT NULL COLLATE NOCASE UNIQUE,
 name TEXT NOT NULL CHECK(length(name) BETWEEN 1 AND 80),
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('owner','admin','support','editor','user')),
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','restricted')),
 email_verified_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX one_platform_owner ON users(role) WHERE role='owner';
CREATE TABLE sessions (
 id TEXT PRIMARY KEY, token_hash TEXT NOT NULL UNIQUE,
 user_id TEXT NOT NULL REFERENCES users(id), csrf_token TEXT NOT NULL,
 created_at TEXT NOT NULL, expires_at TEXT NOT NULL, revoked_at TEXT,
 ip_hash TEXT NOT NULL
);
CREATE INDEX sessions_user ON sessions(user_id,expires_at);
CREATE TABLE user_restrictions (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 scope TEXT NOT NULL CHECK(scope IN ('login','ai','topup','publish')),
 reason TEXT NOT NULL, starts_at TEXT NOT NULL, ends_at TEXT,
 revoked_at TEXT, actor_id TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL
);
CREATE INDEX restrictions_active ON user_restrictions(user_id,scope,revoked_at);
CREATE TABLE rate_limits (
 key TEXT PRIMARY KEY, window_start INTEGER NOT NULL, count INTEGER NOT NULL CHECK(count >= 0)
);
CREATE TABLE audit_logs (
 id TEXT PRIMARY KEY, actor_id TEXT, action TEXT NOT NULL, entity_type TEXT NOT NULL,
 entity_id TEXT, details_json TEXT NOT NULL DEFAULT '{}', request_id TEXT, created_at TEXT NOT NULL
);
CREATE INDEX audit_created ON audit_logs(created_at);
CREATE TABLE projects (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 name TEXT NOT NULL CHECK(length(name) BETWEEN 1 AND 120), description TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','modified','archived')),
 direction_json TEXT NOT NULL DEFAULT '{}', current_version_id TEXT, published_version_id TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, archived_at TEXT
);
CREATE INDEX projects_user ON projects(user_id,updated_at);
CREATE TABLE design_versions (
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id),
 parent_id TEXT REFERENCES design_versions(id), version INTEGER NOT NULL,
 source TEXT NOT NULL CHECK(source IN ('manual','ai','import')),
 manifest_json TEXT NOT NULL, content_hash TEXT NOT NULL, created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL, UNIQUE(project_id,version)
);
CREATE TABLE settings (
 key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_by TEXT REFERENCES users(id), updated_at TEXT NOT NULL
);
CREATE TABLE integration_configs (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('text','image','payment','email','hosting','dns')),
 name TEXT NOT NULL, provider TEXT NOT NULL, version INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','tested','active','disabled')),
 public_config_json TEXT NOT NULL, secret_ciphertext TEXT,
 test_status TEXT NOT NULL DEFAULT 'not_tested', tested_at TEXT,
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 UNIQUE(kind,name,version)
);
CREATE UNIQUE INDEX one_active_integration_per_kind ON integration_configs(kind) WHERE status='active';
CREATE TABLE content_entries (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('page','post','faq','navigation','banner','category')),
 slug TEXT NOT NULL, title TEXT NOT NULL, draft_json TEXT NOT NULL,
 published_json TEXT, state TEXT NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','published','unpublished','trashed')),
 revision INTEGER NOT NULL DEFAULT 1, created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, published_at TEXT, deleted_at TEXT,
 UNIQUE(kind,slug)
);
CREATE TABLE content_revisions (
 id TEXT PRIMARY KEY, entry_id TEXT NOT NULL REFERENCES content_entries(id), revision INTEGER NOT NULL,
 content_json TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 UNIQUE(entry_id,revision)
);
