-- DNS records read from the provider are scoped to the exact newly-created
-- website, never copied into a whole hosting pool or another customer's site.
CREATE TABLE hosting_site_dns_targets (
 site_id TEXT PRIMARY KEY REFERENCES sites(id),
 job_id TEXT NOT NULL UNIQUE REFERENCES provisioning_jobs(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 records_json TEXT NOT NULL,
 source_zone TEXT NOT NULL,
 observed_at TEXT NOT NULL
);
