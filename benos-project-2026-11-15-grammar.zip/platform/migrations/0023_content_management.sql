-- Extend the existing table without discarding drafts, publication snapshots,
-- revisions or references. D1 executes a migration within one transaction.
PRAGMA defer_foreign_keys = ON;
CREATE TABLE content_entries_next (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('page','post','faq','navigation','banner','category','tag')),
 slug TEXT NOT NULL, title TEXT NOT NULL, draft_json TEXT NOT NULL,
 published_json TEXT, state TEXT NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','published','unpublished','trashed')),
 revision INTEGER NOT NULL DEFAULT 1, created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, published_at TEXT, deleted_at TEXT,
 UNIQUE(kind,slug)
);
INSERT INTO content_entries_next SELECT * FROM content_entries;
DROP TABLE content_entries;
ALTER TABLE content_entries_next RENAME TO content_entries;
CREATE UNIQUE INDEX content_published_slug ON content_entries(kind,json_extract(published_json,'$.slug')) WHERE state='published' AND published_json IS NOT NULL;
CREATE INDEX content_public_pagination ON content_entries(state,kind,published_at DESC,id DESC);
CREATE INDEX content_admin_pagination ON content_entries(kind,state,updated_at DESC,id DESC);
CREATE TABLE content_media (
 id TEXT PRIMARY KEY, actor_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL, request_hash TEXT NOT NULL, object_key TEXT NOT NULL UNIQUE,
 filename TEXT NOT NULL, mime_type TEXT NOT NULL, extension TEXT NOT NULL,
 byte_size INTEGER NOT NULL CHECK(byte_size>0 AND byte_size<=12582912),
 width INTEGER NOT NULL, height INTEGER NOT NULL, sha256 TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'staging' CHECK(state IN ('staging','ready','deleted')),
 revision INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT,
 UNIQUE(actor_id,request_key)
);
CREATE INDEX content_media_listing ON content_media(state,created_at DESC,id DESC);
PRAGMA defer_foreign_keys = OFF;
