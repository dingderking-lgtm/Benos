CREATE TABLE design_candidates (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT NOT NULL REFERENCES projects(id),
 request_key TEXT NOT NULL, request_hash TEXT NOT NULL, base_version_id TEXT REFERENCES design_versions(id),
 scope_json TEXT NOT NULL, manifest_json TEXT NOT NULL, source TEXT NOT NULL CHECK(source IN ('manual','ai','template')),
 workflow_id TEXT, state TEXT NOT NULL DEFAULT 'draft' CHECK(state IN ('draft','adopted','discarded')),
 adopted_version_id TEXT REFERENCES design_versions(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key)
);
CREATE INDEX design_candidates_project ON design_candidates(project_id,state,created_at);
