-- Preserve all existing raster media and image_jobs foreign keys. Extended
-- template resources have their own constrained store and share one inventory.
CREATE TABLE project_media_extended (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id),
 project_id TEXT NOT NULL REFERENCES projects(id),
 request_key TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 object_key TEXT NOT NULL UNIQUE,
 filename TEXT NOT NULL,
 mime_type TEXT NOT NULL CHECK(mime_type IN ('image/gif','image/svg+xml','application/pdf')),
 extension TEXT NOT NULL CHECK(extension IN ('gif','svg','pdf')),
 byte_size INTEGER NOT NULL CHECK(byte_size BETWEEN 1 AND 12582912),
 width INTEGER NOT NULL CHECK(width BETWEEN 0 AND 8192),
 height INTEGER NOT NULL CHECK(height BETWEEN 0 AND 8192),
 sha256 TEXT NOT NULL,
 source TEXT NOT NULL CHECK(source='upload'),
 generation_job_id TEXT CHECK(generation_job_id IS NULL),
 state TEXT NOT NULL DEFAULT 'staging' CHECK(state IN ('staging','ready','deleted')),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 deleted_at TEXT,
 UNIQUE(user_id,request_key),
 CHECK((extension='pdf' AND mime_type='application/pdf' AND width=0 AND height=0) OR
       (extension='svg' AND mime_type='image/svg+xml' AND byte_size<=1048576 AND width>0 AND height>0) OR
       (extension='gif' AND mime_type='image/gif' AND width>0 AND height>0 AND width*height<=16000000))
);
CREATE INDEX media_extended_project_inventory ON project_media_extended(project_id,user_id,state,created_at);
CREATE INDEX media_extended_project_hash ON project_media_extended(project_id,user_id,sha256,byte_size);
CREATE VIEW project_media_inventory AS SELECT * FROM project_media UNION ALL SELECT * FROM project_media_extended;
CREATE TRIGGER media_extended_identity BEFORE INSERT ON project_media_extended
WHEN EXISTS(SELECT 1 FROM project_media WHERE id=NEW.id OR object_key=NEW.object_key OR (user_id=NEW.user_id AND request_key=NEW.request_key))
BEGIN SELECT RAISE(ABORT,'media_identity_conflict'); END;
CREATE TRIGGER media_raster_identity BEFORE INSERT ON project_media
WHEN EXISTS(SELECT 1 FROM project_media_extended WHERE id=NEW.id OR object_key=NEW.object_key OR (user_id=NEW.user_id AND request_key=NEW.request_key))
BEGIN SELECT RAISE(ABORT,'media_identity_conflict'); END;
