CREATE TABLE provider_balance_reviews (
 id TEXT PRIMARY KEY,
 provider_id TEXT NOT NULL REFERENCES provider_pools(provider_id),
 actor_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 observed_at TEXT NOT NULL,
 actual_balance_micros INTEGER NOT NULL CHECK(actual_balance_micros>=0),
 local_net_micros INTEGER NOT NULL,
 held_micros INTEGER NOT NULL CHECK(held_micros>=0),
 safety_micros INTEGER NOT NULL CHECK(safety_micros>=0),
 difference_micros INTEGER NOT NULL,
 evidence TEXT NOT NULL,
 created_at TEXT NOT NULL,
 UNIQUE(provider_id,request_key)
);
CREATE INDEX provider_balance_review_time ON provider_balance_reviews(created_at,id);
