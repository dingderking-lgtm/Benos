-- A review applies to exact compiled bytes and a single skin. New revisions
-- are draft by absence; there is deliberately no default approval or backfill.
CREATE TABLE design_pattern_reviews (
  pattern_id TEXT NOT NULL,
  variant_id TEXT NOT NULL,
  revision INTEGER NOT NULL,
  compiled_hash TEXT NOT NULL,
  skin_id TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('approved','rejected','draft')),
  actor_id TEXT NOT NULL REFERENCES users(id),
  reviewed_at TEXT NOT NULL,
  PRIMARY KEY(pattern_id,variant_id,revision,compiled_hash,skin_id)
);
CREATE TABLE design_pattern_review_requests (
  actor_id TEXT NOT NULL REFERENCES users(id),
  request_key TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  result_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(actor_id,request_key)
);
