CREATE TABLE hosting_pool_dns_targets (
 pool_id TEXT PRIMARY KEY REFERENCES hosting_pools(id),records_json TEXT NOT NULL,
 actor_id TEXT NOT NULL REFERENCES users(id),reason TEXT NOT NULL,confirmed_at TEXT NOT NULL
);
