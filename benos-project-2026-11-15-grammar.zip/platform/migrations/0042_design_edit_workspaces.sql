-- Additive schema only; existing workflow rows retain their inline adapter.
CREATE TABLE design_edit_workspaces (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
 project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
 base_version_id TEXT NOT NULL REFERENCES design_versions(id) ON DELETE RESTRICT,
 source_hash TEXT NOT NULL,
 request_key TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 scope_json TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'preparing' CHECK(state IN ('preparing','ready','completed','cancelled','purging','purged')),
 revision INTEGER NOT NULL DEFAULT 0 CHECK(revision>=0),
 blueprint_object_id TEXT,
 assets_json TEXT NOT NULL DEFAULT '[]' CHECK(length(CAST(assets_json AS BLOB))<=100000),
 selection_json TEXT,
 validated_revision INTEGER,
 candidate_id TEXT REFERENCES design_candidates(id) ON DELETE RESTRICT,
 lease_token TEXT,
 lease_until_ms INTEGER,
 expires_at_ms INTEGER NOT NULL,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key)
);
CREATE INDEX design_edit_active ON design_edit_workspaces(user_id,project_id,state,updated_at);
CREATE TABLE design_edit_objects (
 id TEXT PRIMARY KEY,
 workspace_id TEXT NOT NULL REFERENCES design_edit_workspaces(id) ON DELETE RESTRICT,
 logical_key TEXT NOT NULL,
 object_key TEXT NOT NULL UNIQUE,
 sha256 TEXT NOT NULL CHECK(length(sha256)=64),
 byte_size INTEGER NOT NULL CHECK(byte_size>=0 AND byte_size<=10485760),
 kind TEXT NOT NULL CHECK(kind IN ('blueprint','file','response','tool','validation')),
 state TEXT NOT NULL DEFAULT 'staging' CHECK(state IN ('staging','ready','purging','purged')),
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(workspace_id,logical_key)
);
CREATE INDEX design_edit_object_cleanup ON design_edit_objects(workspace_id,state,kind);
CREATE TRIGGER design_edit_object_identity BEFORE UPDATE OF workspace_id,logical_key,object_key,sha256,byte_size,kind ON design_edit_objects
BEGIN SELECT RAISE(ABORT,'edit_object_immutable'); END;
CREATE TABLE design_edit_files (
 workspace_id TEXT NOT NULL REFERENCES design_edit_workspaces(id) ON DELETE RESTRICT,
 path TEXT NOT NULL,
 template_id INTEGER,
 field TEXT NOT NULL,
 base_object_id TEXT NOT NULL REFERENCES design_edit_objects(id) ON DELETE RESTRICT,
 current_object_id TEXT NOT NULL REFERENCES design_edit_objects(id) ON DELETE RESTRICT,
 byte_size INTEGER NOT NULL CHECK(byte_size>=0),
 sha256 TEXT NOT NULL,
 writable INTEGER NOT NULL CHECK(writable IN (0,1)),
 PRIMARY KEY(workspace_id,path)
);
CREATE TABLE design_edit_operations (
 workspace_id TEXT NOT NULL REFERENCES design_edit_workspaces(id) ON DELETE RESTRICT,
 request_key TEXT NOT NULL,
 request_hash TEXT NOT NULL,
 expected_revision INTEGER NOT NULL,
 result_revision INTEGER NOT NULL,
 result_json TEXT NOT NULL CHECK(length(CAST(result_json AS BLOB))<=131072),
 created_at TEXT NOT NULL,
 PRIMARY KEY(workspace_id,request_key)
);
CREATE TABLE design_edit_media_refs (
 workspace_id TEXT NOT NULL REFERENCES design_edit_workspaces(id) ON DELETE RESTRICT,
 media_id TEXT NOT NULL,
 sha256 TEXT NOT NULL,
 byte_size INTEGER NOT NULL,
 PRIMARY KEY(workspace_id,media_id)
);
CREATE TRIGGER design_edit_media_ready BEFORE INSERT ON design_edit_media_refs
BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM design_edit_workspaces w JOIN project_media_inventory m ON m.user_id=w.user_id AND m.project_id=w.project_id WHERE w.id=NEW.workspace_id AND w.state IN ('preparing','ready') AND m.id=NEW.media_id AND m.state='ready' AND m.sha256=NEW.sha256 AND m.byte_size=NEW.byte_size)
 THEN RAISE(ABORT,'edit_media_unavailable') END;
END;
ALTER TABLE ai_workflows ADD COLUMN workspace_id TEXT REFERENCES design_edit_workspaces(id) ON DELETE RESTRICT;
ALTER TABLE ai_workflow_steps ADD COLUMN response_object_id TEXT REFERENCES design_edit_objects(id) ON DELETE RESTRICT;
ALTER TABLE ai_workflow_steps ADD COLUMN tool_object_id TEXT REFERENCES design_edit_objects(id) ON DELETE RESTRICT;
CREATE TRIGGER design_edit_source_identity BEFORE UPDATE OF user_id,project_id,base_version_id,source_hash,request_key,request_hash,scope_json,expires_at_ms ON design_edit_workspaces
BEGIN SELECT RAISE(ABORT,'edit_workspace_immutable'); END;
