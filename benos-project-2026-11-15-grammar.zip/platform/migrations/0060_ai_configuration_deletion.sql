-- AI configurations remain addressable by historical jobs and accounting.
ALTER TABLE integration_configs ADD COLUMN deleted_at TEXT;
ALTER TABLE integration_configs ADD COLUMN deleted_by TEXT REFERENCES users(id);
ALTER TABLE integration_configs ADD COLUMN deleted_reason TEXT;
CREATE INDEX ai_jobs_config_state ON ai_jobs(config_version_id,state);
CREATE INDEX image_jobs_config_state ON image_jobs(config_version_id,state);
CREATE INDEX ai_workflows_config_state ON ai_workflows(config_version_id,state);

-- These guards share the deletion transaction, including against racing job
-- inserts. Held accounting blocks deletion even if a job was marked failed.
CREATE TRIGGER integration_ai_delete_guard BEFORE UPDATE OF deleted_at ON integration_configs
WHEN OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL
BEGIN
 SELECT CASE WHEN OLD.kind NOT IN ('text','image') THEN RAISE(ABORT,'config_delete_kind') END;
 SELECT CASE WHEN OLD.status='active' THEN RAISE(ABORT,'config_active') END;
 SELECT CASE WHEN NEW.deleted_by IS NULL OR length(trim(NEW.deleted_reason)) NOT BETWEEN 3 AND 500
   OR NEW.secret_ciphertext IS NOT NULL OR NEW.secret_hint IS NOT NULL THEN RAISE(ABORT,'config_delete_invalid') END;
 SELECT CASE WHEN
  EXISTS(SELECT 1 FROM ai_jobs j LEFT JOIN api_reservations r ON r.id=j.reservation_id WHERE j.config_version_id=OLD.id AND (j.state NOT IN ('succeeded','failed') OR r.state IN ('reserved','dispatching','uncertain')))
  OR EXISTS(SELECT 1 FROM image_jobs j LEFT JOIN api_reservations r ON r.id=j.reservation_id WHERE j.config_version_id=OLD.id AND (j.state NOT IN ('succeeded','failed') OR r.state IN ('reserved','dispatching','uncertain')))
  OR EXISTS(SELECT 1 FROM ai_workflows w WHERE w.config_version_id=OLD.id AND (w.state IN ('ready','processing','uncertain') OR EXISTS(SELECT 1 FROM ai_workflow_steps s LEFT JOIN api_reservations r ON r.id=s.reservation_id WHERE s.workflow_id=w.id AND (s.state NOT IN ('completed','failed') OR r.state IN ('reserved','dispatching','uncertain')))))
  OR EXISTS(SELECT 1 FROM integration_function_tests t WHERE t.config_id=OLD.id AND (t.state IN ('created','reserved','running','uncertain') OR t.accounting_state='held'))
  THEN RAISE(ABORT,'config_in_use') END;
END;
CREATE TRIGGER integration_deleted_immutable BEFORE UPDATE ON integration_configs
WHEN OLD.deleted_at IS NOT NULL
BEGIN SELECT RAISE(ABORT,'config_deleted'); END;
CREATE TRIGGER ai_jobs_live_config BEFORE INSERT ON ai_jobs
WHEN EXISTS(SELECT 1 FROM integration_configs WHERE id=NEW.config_version_id AND deleted_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'config_deleted'); END;
CREATE TRIGGER image_jobs_live_config BEFORE INSERT ON image_jobs
WHEN EXISTS(SELECT 1 FROM integration_configs WHERE id=NEW.config_version_id AND deleted_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'config_deleted'); END;
CREATE TRIGGER ai_workflows_live_config BEFORE INSERT ON ai_workflows
WHEN EXISTS(SELECT 1 FROM integration_configs WHERE id=NEW.config_version_id AND deleted_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'config_deleted'); END;
CREATE TRIGGER ai_workflow_steps_live_config BEFORE INSERT ON ai_workflow_steps
WHEN EXISTS(SELECT 1 FROM ai_workflows w JOIN integration_configs c ON c.id=w.config_version_id WHERE w.id=NEW.workflow_id AND c.deleted_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'config_deleted'); END;
CREATE TRIGGER integration_function_tests_live_config BEFORE INSERT ON integration_function_tests
WHEN EXISTS(SELECT 1 FROM integration_configs WHERE id=NEW.config_id AND deleted_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'config_deleted'); END;
