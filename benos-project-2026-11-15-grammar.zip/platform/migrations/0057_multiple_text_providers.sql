-- A text vendor owns one active credential/model configuration. Vendors can be
-- enabled together; activating a replacement does not disable another vendor.
DROP INDEX one_active_integration_per_kind;
CREATE UNIQUE INDEX one_active_integration_per_kind ON integration_configs(kind)
 WHERE status='active' AND kind NOT IN ('hosting','text');
CREATE UNIQUE INDEX one_active_text_integration_per_provider ON integration_configs(provider)
 WHERE status='active' AND kind='text';
