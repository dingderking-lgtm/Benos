-- Schema-only; built-in commercial defaults are read in code until explicitly
-- replaced. Historical business rows are never rewritten by this migration.
CREATE TABLE billing_catalog_versions (
 id TEXT PRIMARY KEY,
 version INTEGER NOT NULL UNIQUE CHECK(version>0),
 payload_json TEXT NOT NULL,
 payload_hash TEXT NOT NULL,
 request_key TEXT NOT NULL UNIQUE,
 reason TEXT NOT NULL,
 created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL
);
CREATE TABLE billing_catalog_active (
 singleton INTEGER PRIMARY KEY CHECK(singleton=1),
 version_id TEXT NOT NULL REFERENCES billing_catalog_versions(id),
 enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN(0,1)),
 updated_by TEXT NOT NULL REFERENCES users(id),
 updated_at TEXT NOT NULL
);
CREATE TRIGGER billing_catalog_no_update BEFORE UPDATE ON billing_catalog_versions
BEGIN SELECT RAISE(ABORT,'billing_catalog_immutable'); END;
CREATE TRIGGER billing_catalog_no_delete BEFORE DELETE ON billing_catalog_versions
BEGIN SELECT RAISE(ABORT,'billing_catalog_immutable'); END;
ALTER TABLE orders ADD COLUMN catalog_version_id TEXT;
ALTER TABLE orders ADD COLUMN plan_snapshot_json TEXT;
ALTER TABLE membership_gifts ADD COLUMN catalog_version_id TEXT;
ALTER TABLE membership_gifts ADD COLUMN plan_snapshot_json TEXT;
CREATE TRIGGER order_catalog_snapshot_immutable BEFORE UPDATE OF catalog_version_id,plan_snapshot_json ON orders
WHEN NEW.catalog_version_id IS NOT OLD.catalog_version_id OR NEW.plan_snapshot_json IS NOT OLD.plan_snapshot_json
BEGIN SELECT RAISE(ABORT,'order_catalog_snapshot_immutable'); END;
CREATE TRIGGER gift_catalog_snapshot_immutable BEFORE UPDATE OF catalog_version_id,plan_snapshot_json ON membership_gifts
WHEN NEW.catalog_version_id IS NOT OLD.catalog_version_id OR NEW.plan_snapshot_json IS NOT OLD.plan_snapshot_json
BEGIN SELECT RAISE(ABORT,'gift_catalog_snapshot_immutable'); END;
CREATE INDEX users_operations_created ON users(created_at,id);
CREATE INDEX audit_operations_created ON audit_logs(created_at,id);
CREATE INDEX audit_operations_actor ON audit_logs(actor_id,created_at);
CREATE INDEX reservations_operations_completed ON api_reservations(completed_at_ms,id);
