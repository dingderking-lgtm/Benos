CREATE TABLE site_retention_periods (
 id TEXT PRIMARY KEY, site_id TEXT NOT NULL REFERENCES sites(id),
 suspended_at TEXT NOT NULL, review_after TEXT NOT NULL CHECK(review_after>suspended_at),
 restored_at TEXT, reviewed_at TEXT, reviewed_by TEXT REFERENCES users(id), review_reason TEXT,
 created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX site_one_open_retention ON site_retention_periods(site_id) WHERE restored_at IS NULL;
CREATE INDEX site_retention_due ON site_retention_periods(restored_at,review_after);
