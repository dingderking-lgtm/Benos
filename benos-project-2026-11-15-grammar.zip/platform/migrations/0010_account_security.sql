CREATE TABLE account_tokens (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), token_hash TEXT NOT NULL UNIQUE,
 purpose TEXT NOT NULL CHECK(purpose IN ('verify_email','password_reset')),
 email_snapshot TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, used_at TEXT
);
CREATE INDEX account_tokens_user_purpose ON account_tokens(user_id,purpose,expires_at);
CREATE TABLE account_security_operations (
 id TEXT PRIMARY KEY, action TEXT NOT NULL, user_id TEXT REFERENCES users(id),
 valid_ok INTEGER NOT NULL CONSTRAINT account_token_valid CHECK(valid_ok=1), created_at TEXT NOT NULL
);
CREATE TABLE email_outbox (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), token_id TEXT REFERENCES account_tokens(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 purpose TEXT NOT NULL CHECK(purpose IN ('verify_email','password_reset')),
 payload_ciphertext TEXT,
 state TEXT NOT NULL DEFAULT 'queued' CHECK(state IN ('queued','sending','accepted','uncertain','failed','expired')),
 attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0),
 lease_token TEXT, lease_until_ms INTEGER, provider_message_id TEXT, error_code TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, expires_at TEXT NOT NULL
);
CREATE INDEX email_outbox_pending ON email_outbox(state,created_at);
