CREATE TABLE cms_bundle_transfers (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), site_id TEXT NOT NULL REFERENCES sites(id),
 project_id TEXT NOT NULL REFERENCES projects(id), version_id TEXT NOT NULL REFERENCES design_versions(id),
 request_key TEXT NOT NULL, request_hash TEXT NOT NULL, purpose TEXT NOT NULL CHECK(purpose IN ('preview','publish')),
 metadata_json TEXT NOT NULL CHECK(json_valid(metadata_json)), sources_json TEXT NOT NULL CHECK(json_valid(sources_json)),
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','transferring','sealed','expired','discarded')),
 progress_json TEXT, error_code TEXT, lease_token TEXT, lease_until_ms INTEGER,
 expires_at_ms INTEGER NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key)
);
CREATE INDEX cms_bundle_transfer_pending ON cms_bundle_transfers(state,updated_at);
CREATE TRIGGER cms_bundle_transfer_identity BEFORE UPDATE ON cms_bundle_transfers
WHEN NEW.id<>OLD.id OR NEW.user_id<>OLD.user_id OR NEW.site_id<>OLD.site_id OR NEW.project_id<>OLD.project_id OR NEW.version_id<>OLD.version_id OR NEW.request_key<>OLD.request_key OR NEW.request_hash<>OLD.request_hash OR NEW.purpose<>OLD.purpose OR NEW.metadata_json<>OLD.metadata_json OR NEW.sources_json<>OLD.sources_json OR NEW.expires_at_ms<>OLD.expires_at_ms OR NEW.created_at<>OLD.created_at
BEGIN SELECT RAISE(ABORT,'cms_bundle_transfer_immutable'); END;
ALTER TABLE publication_releases ADD COLUMN bundle_transfer_id TEXT REFERENCES cms_bundle_transfers(id);
