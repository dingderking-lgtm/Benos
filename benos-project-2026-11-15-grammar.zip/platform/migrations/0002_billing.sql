-- Benos accounting. Every amount is an integer in micro-US dollars.
-- Runtime writes use D1 batch transactions; CHECK failures roll back the batch.
CREATE TABLE ledger_commands (
  command_key TEXT PRIMARY KEY,
  attempt_nonce TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  kind TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed')),
  created_at_ms INTEGER NOT NULL,
  completed_at_ms INTEGER,
  auth_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT ledger_auth_ok CHECK (auth_ok = 1),
  credit_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT ledger_credit_ok CHECK (credit_ok = 1),
  pool_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT ledger_pool_ok CHECK (pool_ok = 1),
  state_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT ledger_state_ok CHECK (state_ok = 1),
  cost_ok INTEGER NOT NULL DEFAULT 1 CONSTRAINT ledger_cost_ok CHECK (cost_ok = 1)
);

CREATE TABLE credit_grants (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  source TEXT NOT NULL CHECK (source IN ('subscription', 'topup', 'gift')),
  reference_id TEXT NOT NULL,
  amount_micros INTEGER NOT NULL,
  consumed_micros INTEGER NOT NULL DEFAULT 0,
  reserved_micros INTEGER NOT NULL DEFAULT 0,
  starts_at_ms INTEGER NOT NULL,
  expires_at_ms INTEGER,
  spend_priority INTEGER NOT NULL CHECK (spend_priority IN (0, 1, 2, 3)),
  created_at_ms INTEGER NOT NULL,
  UNIQUE (user_id, source, reference_id),
  CONSTRAINT ledger_grant_amount CHECK (
    typeof(amount_micros) = 'integer' AND amount_micros > 0 AND amount_micros <= 9007199254740991
  ),
  CONSTRAINT ledger_grant_balance CHECK (
    typeof(consumed_micros) = 'integer' AND typeof(reserved_micros) = 'integer'
    AND consumed_micros >= 0 AND reserved_micros >= 0
    AND consumed_micros + reserved_micros <= amount_micros
  ),
  CHECK (source <> 'subscription' OR expires_at_ms IS NOT NULL),
  CHECK (source <> 'topup' OR expires_at_ms IS NULL)
);
CREATE INDEX credit_grants_user_spend ON credit_grants(user_id, spend_priority, expires_at_ms, id);

CREATE TABLE provider_pools (
  provider_id TEXT PRIMARY KEY,
  funded_micros INTEGER NOT NULL DEFAULT 0,
  consumed_micros INTEGER NOT NULL DEFAULT 0,
  reserved_micros INTEGER NOT NULL DEFAULT 0,
  safety_micros INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
  updated_at_ms INTEGER NOT NULL,
  CONSTRAINT ledger_pool_balance CHECK (
    typeof(funded_micros) = 'integer' AND typeof(consumed_micros) = 'integer'
    AND typeof(reserved_micros) = 'integer' AND typeof(safety_micros) = 'integer'
    AND funded_micros BETWEEN 0 AND 9007199254740991
    AND consumed_micros >= 0 AND reserved_micros >= 0 AND safety_micros >= 0
    AND funded_micros - consumed_micros - reserved_micros >= safety_micros
  )
);

CREATE TABLE provider_funding (
  id TEXT PRIMARY KEY,
  provider_id TEXT NOT NULL REFERENCES provider_pools(provider_id) ON DELETE RESTRICT,
  reference_id TEXT NOT NULL,
  amount_micros INTEGER NOT NULL CHECK (typeof(amount_micros) = 'integer' AND amount_micros > 0),
  created_at_ms INTEGER NOT NULL,
  UNIQUE (provider_id, reference_id)
);

CREATE TABLE api_reservations (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  provider_id TEXT NOT NULL REFERENCES provider_pools(provider_id) ON DELETE RESTRICT,
  request_key TEXT NOT NULL,
  request_hash TEXT,
  amount_micros INTEGER NOT NULL CHECK (typeof(amount_micros) = 'integer' AND amount_micros > 0),
  actual_micros INTEGER,
  state TEXT NOT NULL DEFAULT 'reserved' CHECK (state IN ('reserved', 'dispatching', 'uncertain', 'settled', 'released')),
  created_at_ms INTEGER NOT NULL,
  dispatched_at_ms INTEGER,
  completed_at_ms INTEGER,
  UNIQUE (user_id, request_key),
  CHECK (actual_micros IS NULL OR (typeof(actual_micros) = 'integer' AND actual_micros BETWEEN 0 AND amount_micros)),
  CHECK ((state IN ('settled', 'released')) = (actual_micros IS NOT NULL))
);
CREATE INDEX api_reservations_user_created ON api_reservations(user_id, created_at_ms);
CREATE INDEX api_reservations_unresolved ON api_reservations(state, created_at_ms);

CREATE TABLE reservation_allocations (
  reservation_id TEXT NOT NULL REFERENCES api_reservations(id) ON DELETE RESTRICT,
  grant_id TEXT NOT NULL REFERENCES credit_grants(id) ON DELETE RESTRICT,
  ordinal INTEGER NOT NULL CHECK (ordinal > 0),
  reserved_micros INTEGER NOT NULL CHECK (typeof(reserved_micros) = 'integer' AND reserved_micros > 0),
  consumed_micros INTEGER NOT NULL DEFAULT 0 CHECK (typeof(consumed_micros) = 'integer' AND consumed_micros >= 0 AND consumed_micros <= reserved_micros),
  PRIMARY KEY (reservation_id, grant_id),
  UNIQUE (reservation_id, ordinal)
);

CREATE TABLE ledger_events (
  id TEXT PRIMARY KEY,
  command_key TEXT NOT NULL UNIQUE REFERENCES ledger_commands(command_key) ON DELETE RESTRICT,
  kind TEXT NOT NULL,
  user_id TEXT REFERENCES users(id) ON DELETE RESTRICT,
  provider_id TEXT,
  resource_id TEXT NOT NULL,
  reference_id TEXT,
  amount_micros INTEGER NOT NULL,
  created_at_ms INTEGER NOT NULL
);
CREATE INDEX ledger_events_user_created ON ledger_events(user_id, created_at_ms);
