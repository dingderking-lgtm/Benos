-- Additive derived UI cache. The immutable 0037 manifest/index format is unchanged.
CREATE TABLE design_editor_projections (
 user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT NOT NULL REFERENCES projects(id),
 source_kind TEXT NOT NULL CHECK(source_kind IN ('version','candidate')), source_id TEXT NOT NULL,
 version_id TEXT REFERENCES design_versions(id), candidate_id TEXT REFERENCES design_candidates(id),
 source_hash TEXT NOT NULL CHECK(length(source_hash)=64), source_bytes INTEGER NOT NULL CHECK(source_bytes BETWEEN 1 AND 10485760),
 projection_version INTEGER NOT NULL CHECK(projection_version=1),
 projection_json TEXT NOT NULL CHECK(json_valid(projection_json) AND length(CAST(projection_json AS BLOB))<=262144),
 projection_hash TEXT NOT NULL CHECK(length(projection_hash)=64), created_at TEXT NOT NULL,
 PRIMARY KEY(user_id,project_id,source_kind,source_id,projection_version),
 CHECK((source_kind='version' AND version_id=source_id AND candidate_id IS NULL) OR (source_kind='candidate' AND candidate_id=source_id AND version_id IS NULL))
);
CREATE TRIGGER design_editor_projection_owner BEFORE INSERT ON design_editor_projections
WHEN NOT EXISTS(SELECT 1 FROM projects p WHERE p.id=NEW.project_id AND p.user_id=NEW.user_id AND p.archived_at IS NULL)
 OR (NEW.source_kind='version' AND NOT EXISTS(SELECT 1 FROM design_versions v WHERE v.id=NEW.version_id AND v.project_id=NEW.project_id AND v.content_hash=NEW.source_hash))
 OR (NEW.source_kind='candidate' AND NOT EXISTS(SELECT 1 FROM design_candidates c WHERE c.id=NEW.candidate_id AND c.project_id=NEW.project_id AND c.user_id=NEW.user_id))
BEGIN SELECT RAISE(ABORT,'editor_projection_identity'); END;

CREATE TABLE design_restore_requests (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT NOT NULL REFERENCES projects(id),
 request_key TEXT NOT NULL, request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 source_version_id TEXT NOT NULL REFERENCES design_versions(id), source_hash TEXT NOT NULL CHECK(length(source_hash)=64),
 expected_current_version_id TEXT REFERENCES design_versions(id), result_version_id TEXT NOT NULL UNIQUE REFERENCES design_versions(id),
 created_at TEXT NOT NULL, UNIQUE(user_id,request_key)
);
CREATE TRIGGER design_restore_identity BEFORE INSERT ON design_restore_requests
WHEN NOT EXISTS(SELECT 1 FROM projects p JOIN design_versions s ON s.id=NEW.source_version_id JOIN design_versions v ON v.id=NEW.result_version_id
 WHERE p.id=NEW.project_id AND p.user_id=NEW.user_id AND s.project_id=p.id AND s.content_hash=NEW.source_hash
 AND v.project_id=p.id AND v.created_by=NEW.user_id AND v.parent_id IS NEW.expected_current_version_id AND v.content_hash=NEW.source_hash)
BEGIN SELECT RAISE(ABORT,'design_restore_identity'); END;
CREATE TRIGGER design_restore_immutable BEFORE UPDATE ON design_restore_requests
BEGIN SELECT RAISE(ABORT,'design_restore_immutable'); END;
