-- Every physical hPanel account/order is represented once across credential versions.
DROP INDEX one_active_integration_per_kind;
CREATE UNIQUE INDEX one_active_integration_per_kind ON integration_configs(kind) WHERE status='active' AND kind<>'hosting';
CREATE TABLE hosting_pools (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, account_username TEXT NOT NULL,
 hosting_order_id INTEGER NOT NULL, config_version_id TEXT NOT NULL REFERENCES integration_configs(id),
 state TEXT NOT NULL DEFAULT 'draining' CHECK(state IN ('accepting','draining')),
 priority INTEGER NOT NULL DEFAULT 100 CHECK(priority BETWEEN 0 AND 10000),
 max_sites INTEGER NOT NULL CHECK(max_sites BETWEEN 1 AND 100000),
 max_databases INTEGER NOT NULL CHECK(max_databases BETWEEN 1 AND 100000),
 external_sites INTEGER NOT NULL DEFAULT 0 CHECK(external_sites>=0),
 external_databases INTEGER NOT NULL DEFAULT 0 CHECK(external_databases>=0),
 observed_at TEXT, sync_error TEXT, inventory_lease_token TEXT, inventory_lease_until_ms INTEGER,
 revision INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(account_username,hosting_order_id)
);
CREATE TABLE hosting_allocations (
 job_id TEXT PRIMARY KEY REFERENCES provisioning_jobs(id),
 site_id TEXT NOT NULL UNIQUE REFERENCES sites(id), pool_id TEXT NOT NULL REFERENCES hosting_pools(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id), created_at TEXT NOT NULL
);
CREATE INDEX hosting_allocations_pool ON hosting_allocations(pool_id,created_at);
CREATE TRIGGER hosting_allocation_immutable BEFORE UPDATE ON hosting_allocations
 BEGIN SELECT RAISE(ABORT,'hosting_allocation_immutable'); END;
CREATE TRIGGER hosting_allocation_no_delete BEFORE DELETE ON hosting_allocations
 BEGIN SELECT RAISE(ABORT,'hosting_allocation_no_delete'); END;
CREATE TRIGGER hosting_pool_capacity BEFORE INSERT ON hosting_allocations
 WHEN NOT EXISTS(SELECT 1 FROM hosting_pools p WHERE p.id=NEW.pool_id
  AND p.external_sites+(SELECT COUNT(*) FROM hosting_allocations WHERE pool_id=p.id)<p.max_sites
  AND p.external_databases+(SELECT COUNT(*) FROM hosting_allocations WHERE pool_id=p.id)<p.max_databases)
 BEGIN SELECT RAISE(ABORT,'hosting_capacity_exceeded'); END;
