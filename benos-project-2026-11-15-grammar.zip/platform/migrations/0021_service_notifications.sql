CREATE TABLE service_notifications (
 id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),target_key TEXT NOT NULL,
 service TEXT NOT NULL CHECK(service IN ('membership','hosting')),site_id TEXT REFERENCES sites(id),
 stage TEXT NOT NULL CHECK(stage IN ('before_7_days','before_1_day','expired')),ends_at TEXT NOT NULL,
 title TEXT NOT NULL,body TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'active' CHECK(state IN ('active','superseded')),
 read_at TEXT,created_at TEXT NOT NULL,UNIQUE(target_key,ends_at,stage)
);
CREATE INDEX service_notices_owner ON service_notifications(user_id,state,created_at);
CREATE TABLE service_notification_outbox (
 id TEXT PRIMARY KEY,notification_id TEXT NOT NULL UNIQUE REFERENCES service_notifications(id),user_id TEXT NOT NULL REFERENCES users(id),
 config_version_id TEXT NOT NULL REFERENCES integration_configs(id),recipient_snapshot TEXT NOT NULL,payload_ciphertext TEXT,
 state TEXT NOT NULL CHECK(state IN ('queued','sending','accepted','uncertain','failed','expired','suppressed')),
 attempts INTEGER NOT NULL DEFAULT 0,first_attempt_ms INTEGER,lease_token TEXT,lease_until_ms INTEGER,
 provider_message_id TEXT,error_code TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,expires_at TEXT NOT NULL
);
CREATE INDEX service_notification_mail_pending ON service_notification_outbox(state,created_at);
CREATE TABLE notification_scan_state (name TEXT PRIMARY KEY,user_cursor TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL);
