CREATE TABLE operations_budgets (
 provider_id TEXT PRIMARY KEY REFERENCES provider_pools(provider_id),limit_micros INTEGER NOT NULL,
 consumed_micros INTEGER NOT NULL DEFAULT 0,reserved_micros INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL,
 CONSTRAINT operations_budget_balance CHECK(typeof(limit_micros)='integer' AND limit_micros BETWEEN 0 AND 100000000000 AND consumed_micros>=0 AND reserved_micros>=0 AND consumed_micros+reserved_micros<=limit_micros)
);
CREATE TABLE integration_function_tests (
 id TEXT PRIMARY KEY,config_id TEXT NOT NULL REFERENCES integration_configs(id),actor_id TEXT NOT NULL REFERENCES users(id),provider_id TEXT NOT NULL REFERENCES provider_pools(provider_id),
 request_key TEXT NOT NULL,payload_hash TEXT NOT NULL,quote_hash TEXT NOT NULL,config_fingerprint TEXT NOT NULL,
 state TEXT NOT NULL CHECK(state IN ('created','reserved','running','passed','failed','uncertain')),
 accounting_state TEXT NOT NULL DEFAULT 'none' CHECK(accounting_state IN ('none','held','settled','released')),
 reserved_micros INTEGER NOT NULL CHECK(reserved_micros>0),actual_micros INTEGER CHECK(actual_micros>=0 AND actual_micros<=reserved_micros),
 reserve_nonce TEXT,settlement_nonce TEXT,request_json TEXT NOT NULL,pricing_json TEXT NOT NULL,response_json TEXT,usage_json TEXT,provider_response_id TEXT,error_code TEXT,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL,completed_at TEXT,UNIQUE(actor_id,request_key),
 CHECK((accounting_state IN ('none','held') AND actual_micros IS NULL) OR (accounting_state IN ('settled','released') AND actual_micros IS NOT NULL))
);
CREATE INDEX functional_tests_config ON integration_function_tests(config_id,created_at);
CREATE TABLE operations_budget_events (
 id TEXT PRIMARY KEY,test_id TEXT NOT NULL REFERENCES integration_function_tests(id),provider_id TEXT NOT NULL REFERENCES provider_pools(provider_id),
 kind TEXT NOT NULL CHECK(kind IN ('reserve','settle','release')),amount_micros INTEGER NOT NULL,created_at TEXT NOT NULL,UNIQUE(test_id,kind)
);
ALTER TABLE integration_configs ADD COLUMN capability_test_id TEXT REFERENCES integration_function_tests(id);
ALTER TABLE integration_configs ADD COLUMN capability_tested_at TEXT;
