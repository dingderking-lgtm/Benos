-- Administrative AI allowance is a gift, never paid revenue or supplier funds.
CREATE TABLE admin_credit_gifts (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id),
 actor_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL,
 payload_hash TEXT NOT NULL,
 amount_micros INTEGER NOT NULL CHECK(typeof(amount_micros)='integer' AND amount_micros BETWEEN 1 AND 100000000000),
 expires_in_days INTEGER CHECK(expires_in_days IS NULL OR (typeof(expires_in_days)='integer' AND expires_in_days BETWEEN 1 AND 366)),
 starts_at_ms INTEGER NOT NULL,
 expires_at_ms INTEGER,
 reason TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','completed')),
 grant_id TEXT UNIQUE REFERENCES credit_grants(id),
 created_at TEXT NOT NULL,
 completed_at TEXT,
 UNIQUE(actor_id,request_key),
 CHECK((expires_in_days IS NULL AND expires_at_ms IS NULL) OR (expires_in_days IS NOT NULL AND expires_at_ms IS NOT NULL AND expires_at_ms=starts_at_ms+expires_in_days*86400000)),
 CHECK((state='pending' AND grant_id IS NULL AND completed_at IS NULL) OR (state='completed' AND grant_id IS NOT NULL AND completed_at IS NOT NULL))
);
CREATE INDEX admin_credit_gifts_user ON admin_credit_gifts(user_id,created_at DESC,id DESC);
CREATE TRIGGER admin_credit_gifts_no_delete BEFORE DELETE ON admin_credit_gifts
 BEGIN SELECT RAISE(ABORT,'immutable_credit_gift'); END;
CREATE TRIGGER admin_credit_gifts_no_rewrite BEFORE UPDATE ON admin_credit_gifts
 WHEN OLD.id<>NEW.id OR OLD.user_id<>NEW.user_id OR OLD.actor_id<>NEW.actor_id
 OR OLD.request_key<>NEW.request_key OR OLD.payload_hash<>NEW.payload_hash
 OR OLD.amount_micros<>NEW.amount_micros OR OLD.expires_in_days IS NOT NEW.expires_in_days
 OR OLD.starts_at_ms<>NEW.starts_at_ms OR OLD.expires_at_ms IS NOT NEW.expires_at_ms
 OR OLD.reason<>NEW.reason OR OLD.created_at<>NEW.created_at
 OR (OLD.state='completed' AND (NEW.state<>OLD.state OR NEW.grant_id IS NOT OLD.grant_id OR NEW.completed_at IS NOT OLD.completed_at))
 BEGIN SELECT RAISE(ABORT,'immutable_credit_gift'); END;
