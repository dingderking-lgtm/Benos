-- Image-only opt-in estimated settlements and append-only true receipt deltas.
-- Original api_reservations / reservation_allocations / settle events are retained.
CREATE TABLE image_estimated_settlements (
 job_id TEXT PRIMARY KEY REFERENCES image_jobs(id),
 reservation_id TEXT NOT NULL UNIQUE REFERENCES api_reservations(id),
 estimated_micros INTEGER NOT NULL CHECK(typeof(estimated_micros)='integer' AND estimated_micros>=0),
 snapshot_json TEXT NOT NULL CHECK(json_valid(snapshot_json)),
 error_code TEXT NOT NULL,
 created_at_ms INTEGER NOT NULL
);
CREATE TRIGGER image_estimate_immutable BEFORE UPDATE ON image_estimated_settlements
BEGIN SELECT RAISE(ABORT,'image estimate is immutable'); END;
CREATE TRIGGER image_estimate_no_delete BEFORE DELETE ON image_estimated_settlements
BEGIN SELECT RAISE(ABORT,'image estimate is immutable'); END;
CREATE TABLE image_cost_corrections (
 job_id TEXT PRIMARY KEY REFERENCES image_estimated_settlements(job_id),
 receipt_sha256 TEXT NOT NULL CHECK(length(receipt_sha256)=64),
 actual_micros INTEGER NOT NULL CHECK(typeof(actual_micros)='integer' AND actual_micros>=0),
 delta_micros INTEGER NOT NULL CHECK(typeof(delta_micros)='integer'),
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','applied')),
 created_at_ms INTEGER NOT NULL,
 applied_at_ms INTEGER,
 CHECK((state='applied')=(applied_at_ms IS NOT NULL))
);
CREATE TRIGGER image_correction_receipt_immutable BEFORE UPDATE ON image_cost_corrections
WHEN NEW.job_id<>OLD.job_id OR NEW.receipt_sha256<>OLD.receipt_sha256 OR NEW.actual_micros<>OLD.actual_micros
 OR NEW.delta_micros<>OLD.delta_micros OR NEW.created_at_ms<>OLD.created_at_ms OR OLD.state='applied'
BEGIN SELECT RAISE(ABORT,'image correction receipt is immutable'); END;
CREATE TRIGGER image_correction_no_delete BEFORE DELETE ON image_cost_corrections
BEGIN SELECT RAISE(ABORT,'image correction receipt is immutable'); END;
CREATE TABLE image_correction_allocations (
 job_id TEXT NOT NULL REFERENCES image_cost_corrections(job_id),
 grant_id TEXT NOT NULL REFERENCES credit_grants(id),
 delta_micros INTEGER NOT NULL CHECK(typeof(delta_micros)='integer' AND delta_micros<>0),
 PRIMARY KEY(job_id,grant_id)
);
CREATE TRIGGER image_correction_allocation_immutable BEFORE UPDATE ON image_correction_allocations
BEGIN SELECT RAISE(ABORT,'image correction allocation is immutable'); END;
CREATE TRIGGER image_correction_allocation_no_delete BEFORE DELETE ON image_correction_allocations
BEGIN SELECT RAISE(ABORT,'image correction allocation is immutable'); END;
