-- Fail migration if historical deposits reused an external receipt across pools.
-- An operator must investigate duplicate receipts; never silently merge money.
CREATE UNIQUE INDEX provider_funding_receipt_global ON provider_funding(reference_id);
CREATE TABLE provider_debits (
 id TEXT PRIMARY KEY, provider_id TEXT NOT NULL REFERENCES provider_pools(provider_id),
 reference_id TEXT NOT NULL UNIQUE, amount_micros INTEGER NOT NULL CHECK(amount_micros>0),
 reason TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES users(id), created_at_ms INTEGER NOT NULL
);
CREATE TABLE financial_cases (
 id TEXT PRIMARY KEY, provider TEXT NOT NULL DEFAULT 'stripe', kind TEXT NOT NULL CHECK(kind IN ('refund','dispute','payment_review')),
 provider_object_id TEXT NOT NULL, config_version_id TEXT REFERENCES integration_configs(id),
 order_id TEXT REFERENCES orders(id), user_id TEXT REFERENCES users(id), payment_intent_id TEXT, charge_id TEXT, invoice_id TEXT,
 provider_state TEXT NOT NULL, amount_cents INTEGER, currency TEXT, reason TEXT,
 review_state TEXT NOT NULL DEFAULT 'open' CHECK(review_state IN ('open','acknowledged')),
 financial_effect_state TEXT NOT NULL DEFAULT 'not_applied' CHECK(financial_effect_state='not_applied'),
 snapshot_json TEXT NOT NULL, snapshot_hash TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1, last_event_created INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(provider,kind,provider_object_id)
);
CREATE INDEX financial_cases_review ON financial_cases(review_state,updated_at);
CREATE TABLE financial_case_events (
 case_id TEXT NOT NULL REFERENCES financial_cases(id), event_id TEXT NOT NULL,
 event_type TEXT NOT NULL, provider_state TEXT NOT NULL, snapshot_json TEXT NOT NULL, created_at TEXT NOT NULL,
 PRIMARY KEY(case_id,event_id)
);
CREATE TABLE financial_case_actions (
 id TEXT PRIMARY KEY, case_id TEXT NOT NULL REFERENCES financial_cases(id), actor_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL, payload_hash TEXT NOT NULL, attempt_nonce TEXT NOT NULL,
 action TEXT NOT NULL CHECK(action IN ('acknowledged','needs_follow_up','restrict','revoke')),
 evidence TEXT NOT NULL, payload_json TEXT NOT NULL, created_at TEXT NOT NULL,
 UNIQUE(actor_id,request_key)
);
CREATE TABLE financial_case_restrictions (
 case_id TEXT NOT NULL REFERENCES financial_cases(id), restriction_id TEXT NOT NULL UNIQUE REFERENCES user_restrictions(id),
 action_id TEXT NOT NULL REFERENCES financial_case_actions(id), PRIMARY KEY(case_id,restriction_id)
);
-- Existing review records are retained in payment_review_cases. The owner-only
-- application import endpoint migrates them with an audit record; no data DML
-- belongs in this schema-only deployment migration.
