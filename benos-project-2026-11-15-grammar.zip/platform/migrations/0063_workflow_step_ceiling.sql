-- A design task started from a message is no longer cut off after six steps (owner decision, 2026-11-13): it runs
-- until it is done or the customer's AI credit runs out, under a high safety ceiling kept in code. The six-step
-- CHECK on the step number cannot be altered in place, so the step table is rebuilt with the same columns and rows.
-- No table refers to it, and nothing is renamed, so the triggers that mention it by name keep working.
CREATE TABLE ai_workflow_steps_copy AS SELECT id,workflow_id,ordinal,reservation_id,state,response_json,tool_results_json,error_code,created_at,updated_at,response_object_id,tool_object_id,public_reply,progress_json,progress_draft FROM ai_workflow_steps;
DROP TABLE ai_workflow_steps;
CREATE TABLE ai_workflow_steps (
 id TEXT PRIMARY KEY,
 workflow_id TEXT NOT NULL REFERENCES ai_workflows(id) ON DELETE RESTRICT,
 ordinal INTEGER NOT NULL CHECK (ordinal BETWEEN 1 AND 48),
 reservation_id TEXT NOT NULL UNIQUE,
 state TEXT NOT NULL DEFAULT 'preparing' CHECK(state IN ('preparing','dispatching','responded','completed','uncertain','failed')),
 response_json TEXT,
 tool_results_json TEXT,
 error_code TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 response_object_id TEXT REFERENCES design_edit_objects(id) ON DELETE RESTRICT,
 tool_object_id TEXT REFERENCES design_edit_objects(id) ON DELETE RESTRICT,
 public_reply TEXT,
 progress_json TEXT,
 progress_draft TEXT,
 UNIQUE(workflow_id,ordinal)
);
INSERT INTO ai_workflow_steps(id,workflow_id,ordinal,reservation_id,state,response_json,tool_results_json,error_code,created_at,updated_at,response_object_id,tool_object_id,public_reply,progress_json,progress_draft)
 SELECT id,workflow_id,ordinal,reservation_id,state,response_json,tool_results_json,error_code,created_at,updated_at,response_object_id,tool_object_id,public_reply,progress_json,progress_draft FROM ai_workflow_steps_copy;
DROP TABLE ai_workflow_steps_copy;
CREATE TRIGGER ai_workflow_steps_live_config BEFORE INSERT ON ai_workflow_steps
WHEN EXISTS(SELECT 1 FROM ai_workflows w JOIN integration_configs c ON c.id=w.config_version_id WHERE w.id=NEW.workflow_id AND c.deleted_at IS NOT NULL)
BEGIN SELECT RAISE(ABORT,'config_deleted'); END;
