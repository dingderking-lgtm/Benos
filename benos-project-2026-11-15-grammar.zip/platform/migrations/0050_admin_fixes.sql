-- P6.B admin fixes.
-- 1. Masked integration identifier (decision D3): the last four printable characters
--    of the primary secret, computed once when a configuration version is created.
--    The full secret stays encrypted in secret_ciphertext and is never returned.
--    Versions created before this migration keep NULL (the UI shows "已配置").
ALTER TABLE integration_configs ADD COLUMN secret_hint TEXT CHECK(secret_hint IS NULL OR length(secret_hint)=4);
-- 2. Revenue series (decision D6): paid orders bucketed by their confirmation time.
--    The expression must stay identical to REVENUE_TIME_SQL in src/modules/admin-operations.ts.
CREATE INDEX orders_revenue_time ON orders((CASE WHEN fulfilled_at IS NOT NULL AND fulfilled_at<paid_at THEN fulfilled_at ELSE paid_at END)) WHERE state IN ('paid','refunded') AND paid_at IS NOT NULL;
