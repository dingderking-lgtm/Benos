-- P4.B: annual hosting periods that must be counted from the site's actual
-- opening (pay-first new site) or actual resumption (suspended site renewed in
-- retention). Payment grants provisional access at fulfilment so provisioning
-- and the lease sync can run; when the site first becomes connected the paid
-- year is re-anchored to that moment (only ever extended, never shortened).
CREATE TABLE hosting_annual_activations (
 order_id TEXT PRIMARY KEY REFERENCES orders(id),
 site_id TEXT NOT NULL REFERENCES sites(id),
 user_id TEXT NOT NULL REFERENCES users(id),
 reason TEXT NOT NULL CHECK(reason IN ('create','resume')),
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','anchored')),
 provisional_starts_at TEXT NOT NULL,
 provisional_ends_at TEXT NOT NULL,
 activated_at TEXT,
 anchored_ends_at TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE INDEX hosting_annual_activations_pending ON hosting_annual_activations(site_id,state);
