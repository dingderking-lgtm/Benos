CREATE TABLE hosting_site_controls (
 site_id TEXT PRIMARY KEY REFERENCES sites(id),paused INTEGER NOT NULL DEFAULT 0 CHECK(paused IN (0,1)),
 reason TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES users(id),revision INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL
);
CREATE TABLE hosting_control_requests (
 id TEXT PRIMARY KEY,site_id TEXT NOT NULL REFERENCES sites(id),actor_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL,payload_hash TEXT NOT NULL,paused INTEGER NOT NULL CHECK(paused IN (0,1)),reason TEXT NOT NULL,created_at TEXT NOT NULL,
 UNIQUE(actor_id,request_key)
);
CREATE TABLE hosting_domains (
 domain TEXT PRIMARY KEY,site_id TEXT NOT NULL REFERENCES sites(id),created_at TEXT NOT NULL
);
INSERT INTO hosting_domains(domain,site_id,created_at) SELECT domain,id,created_at FROM sites;
CREATE TRIGGER hosting_domain_site_insert AFTER INSERT ON sites BEGIN
 INSERT INTO hosting_domains(domain,site_id,created_at) VALUES(NEW.domain,NEW.id,NEW.created_at);
END;
CREATE TRIGGER hosting_domain_site_update BEFORE UPDATE OF domain ON sites
 WHEN EXISTS(SELECT 1 FROM hosting_domains WHERE domain=NEW.domain AND site_id<>NEW.id)
 BEGIN SELECT RAISE(ABORT,'hosting_domain_claimed'); END;
CREATE TABLE hosting_domain_changes (
 id TEXT PRIMARY KEY,site_id TEXT NOT NULL REFERENCES sites(id),user_id TEXT NOT NULL REFERENCES users(id),
 request_key TEXT NOT NULL,payload_hash TEXT NOT NULL,old_domain TEXT NOT NULL,new_domain TEXT NOT NULL,
 challenge TEXT NOT NULL,reason TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'awaiting_ownership',
 provider_attempted INTEGER NOT NULL DEFAULT 0,ssl_attempted INTEGER NOT NULL DEFAULT 0,
 lease_token TEXT,lease_until TEXT,error_code TEXT,dns_json TEXT NOT NULL DEFAULT '[]',created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
 UNIQUE(user_id,request_key)
);
CREATE UNIQUE INDEX one_pending_domain_change ON hosting_domain_changes(site_id) WHERE state<>'succeeded';
CREATE INDEX hosting_domain_change_poll ON hosting_domain_changes(state,updated_at);
