-- Schema-only upgrade. Existing inline manifests remain untouched.
CREATE TABLE design_manifest_objects (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), project_id TEXT NOT NULL REFERENCES projects(id),
 object_key TEXT NOT NULL UNIQUE, sha256 TEXT NOT NULL CHECK(length(sha256)=64),
 byte_size INTEGER NOT NULL CHECK(byte_size BETWEEN 1000001 AND 10485760),
 index_json TEXT NOT NULL CHECK(json_valid(index_json) AND length(CAST(index_json AS BLOB))<=250000),
 state TEXT NOT NULL CHECK(state IN ('staging','ready','purging','purged')),
 lease_token TEXT, lease_until_ms INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX design_manifest_active_digest ON design_manifest_objects(user_id,project_id,sha256) WHERE state<>'purged';
CREATE INDEX design_manifest_expiry ON design_manifest_objects(state,updated_at);
ALTER TABLE design_versions ADD COLUMN manifest_object_id TEXT REFERENCES design_manifest_objects(id);
ALTER TABLE design_versions ADD COLUMN request_key TEXT;
ALTER TABLE design_versions ADD COLUMN request_hash TEXT;
CREATE UNIQUE INDEX design_version_request ON design_versions(created_by,project_id,request_key) WHERE request_key IS NOT NULL;
ALTER TABLE design_candidates ADD COLUMN manifest_object_id TEXT REFERENCES design_manifest_objects(id);
CREATE TRIGGER design_manifest_identity_immutable BEFORE UPDATE ON design_manifest_objects
WHEN NEW.id<>OLD.id OR NEW.user_id<>OLD.user_id OR NEW.project_id<>OLD.project_id OR NEW.object_key<>OLD.object_key OR NEW.sha256<>OLD.sha256 OR NEW.byte_size<>OLD.byte_size OR NEW.index_json<>OLD.index_json OR NEW.created_at<>OLD.created_at
BEGIN SELECT RAISE(ABORT,'design_manifest_immutable'); END;
CREATE TRIGGER design_manifest_referenced_state BEFORE UPDATE OF state ON design_manifest_objects
WHEN NEW.state<>'ready' AND (EXISTS(SELECT 1 FROM design_versions WHERE manifest_object_id=OLD.id) OR EXISTS(SELECT 1 FROM design_candidates WHERE manifest_object_id=OLD.id))
BEGIN SELECT RAISE(ABORT,'design_manifest_referenced'); END;
CREATE TRIGGER design_version_storage_identity BEFORE INSERT ON design_versions
WHEN (NEW.manifest_object_id IS NULL AND json_extract(NEW.manifest_json,'$.format')='benos-manifest-ref')
 OR (NEW.manifest_object_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM design_manifest_objects m WHERE m.id=NEW.manifest_object_id AND m.user_id=NEW.created_by AND m.project_id=NEW.project_id AND m.state='ready' AND m.index_json=NEW.manifest_json AND m.sha256=NEW.content_hash))
BEGIN SELECT RAISE(ABORT,'design_manifest_pointer_invalid'); END;
CREATE TRIGGER design_candidate_storage_identity BEFORE INSERT ON design_candidates
WHEN (NEW.manifest_object_id IS NULL AND json_extract(NEW.manifest_json,'$.format')='benos-manifest-ref')
 OR (NEW.manifest_object_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM design_manifest_objects m WHERE m.id=NEW.manifest_object_id AND m.user_id=NEW.user_id AND m.project_id=NEW.project_id AND m.state='ready' AND m.index_json=NEW.manifest_json))
BEGIN SELECT RAISE(ABORT,'design_manifest_pointer_invalid'); END;
CREATE TRIGGER design_version_content_immutable BEFORE UPDATE OF manifest_json,manifest_object_id,content_hash,project_id,created_by,parent_id,request_key,request_hash ON design_versions
BEGIN SELECT RAISE(ABORT,'design_version_immutable'); END;
CREATE TRIGGER design_candidate_content_immutable BEFORE UPDATE OF manifest_json,manifest_object_id,project_id,user_id,base_version_id,request_key,request_hash ON design_candidates
BEGIN SELECT RAISE(ABORT,'design_candidate_immutable'); END;
