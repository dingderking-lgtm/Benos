<?php
declare(strict_types=1);
// Local release builder; never include this tool in the deployed archive.
if(PHP_SAPI!=='cli'||$argc!==3){fwrite(STDERR,"Usage: php -d extension=zip build-release.php PINNED_SOURCE OUTPUT_ZIP\n");exit(2);}
require_once __DIR__.'/src/Distribution.php';
$source=realpath($argv[1]);$output=$argv[2];
if(!$source||trim(file_get_contents($source.'/VERSION'))!=='1.9.21'||file_exists($output))throw new RuntimeException('Require pinned 1.9.21 source and a new output path.');
if(!hash_equals('fe5e854a9c5da299dc96203db4eff9d88781e5226763fd7269df26bd40b2553d',hash_file('sha256',$source.'/installation-manifest.json')))throw new RuntimeException('Pinned source inventory changed.');
$baseline=json_decode(file_get_contents($source.'/installation-manifest.json'),true,32,JSON_THROW_ON_ERROR)['files_sha256'];
$readPinned=function(string $name)use($source,$baseline):string{if(!isset($baseline[$name])||!is_file($source.'/'.$name)||is_link($source.'/'.$name))throw new RuntimeException('Unlisted source file: '.$name);$bytes=file_get_contents($source.'/'.$name);if(hash_equals($baseline[$name],hash('sha256',$bytes)))return $bytes;
    // This Windows checkout has Git CRLF conversion. Accept only UTF-8 text
    // whose LF-normalized bytes match the pinned upstream inventory exactly.
    $lf=str_replace("\r\n","\n",$bytes);if(!str_contains($bytes,"\0")&&mb_check_encoding($bytes,'UTF-8')&&hash_equals($baseline[$name],hash('sha256',$lf)))return $lf;throw new RuntimeException('Pinned source file changed: '.$name);};
foreach($baseline as $name=>$expected)$readPinned($name);
$zip=new ZipArchive;if($zip->open($output,ZipArchive::CREATE|ZipArchive::EXCL)!==true)throw new RuntimeException('Cannot create release.');$files=[];
$add=function(string $name,string $bytes)use($zip,&$files){if(!preg_match('~^[A-Za-z0-9_.@/-]+$~D',$name)||str_contains($name,'..')||str_starts_with($name,'/')||isset($files[$name]))throw new RuntimeException('Invalid or duplicate release path.');$files[$name]=hash('sha256',$bytes);if(!$zip->addFromString($name,$bytes))throw new RuntimeException('Cannot add release file.');};
$rootRules="RewriteRule ^benos-bootstrap-[a-f0-9]{32}\\.php$ - [L]\nRewriteRule ^benos-release-[a-f0-9]{64}\\.zip$ - [F,L]\nRewriteRule ^benos-(health|connect|bundle)\\.php$ public/benos-$1.php [L]\nRewriteRule ^public/benos-(health|connect|bundle)\\.php$ - [L]";
foreach(['src','database','resources','routes','views','vendor','public','licenses','scripts'] as $directory){
 if(!is_dir($source.'/'.$directory))throw new RuntimeException('Missing source directory.');
 foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source.'/'.$directory,FilesystemIterator::SKIP_DOTS)) as $item){if($item->isLink())throw new RuntimeException('Source symlink denied.');if(!$item->isFile())continue;$name=str_replace('\\','/',substr($item->getPathname(),strlen($source)+1));if(str_starts_with($name,'public/uploads/')||preg_match('~(?:^|/)(?:\.env|\.git|local\.php)(?:$|/)~',$name))continue;$bytes=Benos\Distribution::transform($name,$readPinned($name),['fonts'=>getenv('BENOS_CMS_FONT_OVERLAY')!=='0']);if($name==='public/.htaccess')$bytes=preg_replace('/RewriteEngine On/',"RewriteEngine On\n# Benos authenticated connector routes\nRewriteRule ^benos-(health|connect|bundle)\\.php$ - [L]",$bytes,1);$add($name,$bytes);}
}
foreach(['VERSION','composer.json','composer.lock','THIRD_PARTY_NOTICES.md','config/update-public.key'] as $file)if(is_file($source.'/'.$file))$add($file,$readPinned($file));
foreach(Benos\Distribution::additionalFiles() as $name=>$bytes)$add($name,$bytes);
$add('.htaccess',preg_replace_callback('/RewriteEngine On/',fn()=>"RewriteEngine On\n# Benos authenticated connector routes\n".$rootRules,$readPinned('.htaccess'),1));
foreach(['Protocol'=>'BenosProtocol','NativeInstaller'=>'BenosNativeInstaller','Publisher'=>'BenosPublisher','Entitlement'=>'BenosEntitlement','ManagedRestore'=>'BenosManagedRestore','Management'=>'BenosManagement','Preview'=>'BenosPreview','PreviewBundle'=>'BenosPreviewBundle','AssetPolicy'=>'BenosAssetPolicy','Bundle'=>'BenosBundle'] as $from=>$to)$add('storage/private/'.$to.'.php',file_get_contents(__DIR__.'/src/'.$from.'.php'));
foreach(['health','connect','bundle'] as $entry)$add('public/benos-'.$entry.'.php',file_get_contents(__DIR__.'/site-'.$entry.'.php'));
ksort($files);$manifest=['format'=>'benos-cms-release','version'=>1,'cmsVersion'=>'1.9.21','baselineCommit'=>'2152113a4ef6ac07e119074dfdbf40f79647d109','files'=>$files];
$zip->addFromString('BENOS-RELEASE.json',json_encode($manifest,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));if(!$zip->close())throw new RuntimeException('Release archive failed.');
echo json_encode(['path'=>$output,'sha256'=>hash_file('sha256',$output),'size'=>filesize($output),'files'=>count($files),'cmsVersion'=>'1.9.21'],JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
