<?php
// Copy OUTSIDE the web root, replace every placeholder, chmod 0600, then set
// BENOS_BRIDGE_CONFIG on the server. Never commit a filled-in configuration.
return [
    'basePath'=>'/benos-bridge/v1',
    'stateRoot'=>'/private/benos/bridge-state',
    'sitesRoot'=>'/private/benos/sites',
    'sourceRoot'=>'/private/releases/aacms-1.9.21',
    'encryptionKey'=>'REPLACE_WITH_BASE64_OF_32_RANDOM_BYTES',
    'keys'=>['primary'=>'REPLACE_WITH_AT_LEAST_32_RANDOM_BYTES'],
    // hPanel Web/Cloud mode: official API creates DB/user; no root DB password.
    // A signed deployment can write ONLY this account's exact domain public_html.
    'hpanelAccounts'=>[
        // 'u12345678'=>['domainsRoot'=>'/home/u12345678/domains',
        //              'databaseHost'=>'localhost','databasePort'=>3306],
    ],
    'database'=>[
        'mode'=>'preallocated',
        // Create an independent DB and restricted user through the hosting
        // provider first; bind exact domains here. Missing entries await setup.
        'slots'=>[
            // 'customer.example.com'=>['host'=>'localhost','port'=>3306,
            // 'name'=>'unique_database','user'=>'unique_user','password'=>'...'],
        ],
        // A controlled server with CREATE DATABASE / CREATE USER privileges may
        // use mode=managed, host, port, prefix, provisionerUser,
        // provisionerPassword and userHost. Shared Hostinger permissions vary;
        // do not assume this mode is available on a shared hosting plan.
    ],
    'testMode'=>false,
];
