<?php
declare(strict_types=1);
ini_set('display_errors','0');
use Benos\{Protocol,ProtocolError,Bundle};
$root=dirname(__DIR__);$private=$root.'/storage/private';$identity=null;$nonceLock=null;$runtime=null;
require $private.'/BenosProtocol.php';require $private.'/BenosBundle.php';require $private.'/BenosEntitlement.php';
try{
    $connection=json_decode(file_get_contents($private.'/benos-connection.json'),true,32,JSON_THROW_ON_ERROR);
    if(empty($_SERVER['HTTPS'])||strtolower((string)$_SERVER['HTTPS'])==='off'){if(empty($connection['testMode'])||!in_array($_SERVER['REMOTE_ADDR']??'',['127.0.0.1','::1'],true))throw new ProtocolError('HTTPS_REQUIRED',403);}
    if(($_SERVER['REQUEST_METHOD']??'')!=='POST')throw new ProtocolError('METHOD_DENIED',405);
    $raw=file_get_contents('php://input',false,null,0,Bundle::CHUNK+4105);if($raw===false)throw new ProtocolError('INPUT_INVALID');
    // Publication/backup owns EX. Hold SH before nonce or staging writes so
    // private source files cannot change during its complete-file snapshot.
    // Internal Bundle readers never take this HTTP-only lock again.
    $runtimePath=$root.'/storage/runtime.lock';if(is_link($runtimePath))throw new ProtocolError('BUNDLE_STORAGE_UNSAFE',503);$runtime=fopen($runtimePath,'c');if(!$runtime||!flock($runtime,LOCK_SH|LOCK_NB))throw new ProtocolError('CMS_BUSY',503);
    $nonceFile=$private.'/benos-bundle-nonces.json';$noncePath=$private.'/benos-bundle-nonces.lock';if(is_link($nonceFile)||is_link($noncePath))throw new ProtocolError('BUNDLE_STORAGE_UNSAFE',503);$nonceLock=fopen($noncePath,'c');if(!$nonceLock||!flock($nonceLock,LOCK_EX|LOCK_NB))throw new ProtocolError('BUNDLE_BUSY',503);
    $nonces=is_file($nonceFile)?json_decode(file_get_contents($nonceFile),true):[];
    $identity=Protocol::verify(getallheaders(),'POST',$_SERVER['REQUEST_URI']??'',$raw,[$connection['keyId']=>$connection['signingSecret']],'BENOS-CMS-BUNDLE-V2',function($nonce,$expiry)use(&$nonces,$nonceFile){foreach($nonces as $key=>$expires)if($expires<time())unset($nonces[$key]);if(isset($nonces[$nonce]))throw new ProtocolError('REPLAY_DENIED',409);if(count($nonces)>10000)throw new ProtocolError('RATE_LIMITED',429);$nonces[$nonce]=$expiry;Protocol::writePrivateJson($nonceFile,$nonces);});
    flock($nonceLock,LOCK_UN);fclose($nonceLock);$nonceLock=null;
    if($identity['siteId']!==$connection['siteId'])throw new ProtocolError('FORBIDDEN',403);
    $type=strtolower(trim(explode(';',$_SERVER['CONTENT_TYPE']??'')[0]));$bytes=null;
    if($type==='application/vnd.benos.bundle-v2'){
        if(strlen($raw)<9||substr($raw,0,4)!=='BNB2')throw new ProtocolError('BUNDLE_FRAME_INVALID',422);$size=unpack('N',substr($raw,4,4))[1];if($size<2||$size>4096||strlen($raw)<=8+$size)throw new ProtocolError('BUNDLE_FRAME_INVALID',422);
        $input=json_decode(substr($raw,8,$size),true,16,JSON_THROW_ON_ERROR);if(!is_array($input)||($input['operation']??null)!=='bundle-chunk')throw new ProtocolError('BUNDLE_FRAME_INVALID',422);$bytes=substr($raw,8+$size);
    }elseif($type==='application/json'){
        if(strlen($raw)>16384)throw new ProtocolError('REQUEST_TOO_LARGE',413);$input=json_decode($raw,true,32,JSON_THROW_ON_ERROR);if(!is_array($input)||($input['operation']??null)==='bundle-chunk')throw new ProtocolError('INPUT_INVALID',422);
    }else throw new ProtocolError('CONTENT_TYPE_INVALID',415);
    $bundle=new Bundle($root,$connection,fn()=>Benos\Entitlement::allowed($root,$connection,true));$result=$bundle->dispatch($input,$bytes);$response=Protocol::response($identity,200,$result);
}catch(Throwable $error){$status=$error instanceof ProtocolError?$error->status:503;$code=$error instanceof ProtocolError?$error->errorCode:'BUNDLE_UNAVAILABLE';$response=$identity?Protocol::response($identity,$status,['error'=>['code'=>$code]]):['status'=>$status,'body'=>json_encode(['error'=>['code'=>$code]]),'headers'=>['Content-Type'=>'application/json','Cache-Control'=>'no-store']];}
finally{foreach([$nonceLock,$runtime] as $handle)if(is_resource($handle)){flock($handle,LOCK_UN);fclose($handle);}}
Protocol::emit($response);
