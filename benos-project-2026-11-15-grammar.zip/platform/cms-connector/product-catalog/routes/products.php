<?php
declare(strict_types=1);

use AACMS\Services\ProductService;
use AACMS\Services\FormService;

return static function($app): void {
    $service=static fn()=>new ProductService;
    $render=static function($response,string $name,array $data=[]){
        return html_response($response,view('products/'.$name,$data+['title'=>'产品管理','active'=>'products','stylesheets'=>['/assets/products-admin.css?v='.filemtime(public_path('assets/products-admin.css'))]]));
    };
    $api=static function($response,callable $operation){
        require_permission('products');
        try{return json_response($response,['ok'=>true]+$operation());}
        catch(RuntimeException $error){if(!in_array($error->getCode(),[400,403,404,409,413,422],true))throw $error;return json_response($response,['ok'=>false,'error'=>$error->getMessage()],$error->getCode());}
    };
    $app->get('/admin/products',static function($request,$response)use($service,$render){
        require_permission('products');$s=$service();$query=$request->getQueryParams();
        $filters=[];foreach(['q','status','category'] as $key)$filters[$key]=is_string($query[$key]??null)?mb_substr($query[$key],0,200):'';
        if(!in_array($filters['status'],['all','draft','published','archived'],true))$filters['status']='all';
        $pageNo=max(1,min(100000,(int)(is_scalar($query['page']??1)?($query['page']??1):1)));$perPage=20;
        $result=$s->listing($filters,$perPage,($pageNo-1)*$perPage);
        $last=max(1,(int)ceil($result['total']/$perPage));if($pageNo>$last){$pageNo=$last;$result=$s->listing($filters,$perPage,($pageNo-1)*$perPage);}
        return $render($response,'index',compact('filters','pageNo','perPage','result')+['categories'=>$s->categories()]);
    });
    $app->get('/admin/products/new',static function($request,$response)use($service,$render){
        require_permission('products');$s=$service();$settings=$s->settings();
        $record=['page'=>['id'=>null,'title'=>'','slug'=>'','excerpt'=>'','category'=>'','status'=>'draft'],'product'=>['version'=>'bnp-1','sku'=>'','brand'=>'','mode'=>'inherit','price'=>null,'currency'=>$settings['currency'],'price_unit'=>'','minimum_order'=>1,'gallery'=>[],'specifications'=>[],'description'=>''],'seo'=>[],'version'=>0,'has_unpublished_changes'=>false];
        return $render($response,'editor',compact('record','settings')+['categories'=>$s->categories(),'title'=>'新增产品']);
    });
    $app->map(['GET','POST'],'/admin/products/settings',static function($request,$response)use($service,$render){
        require_permission('products');require_permission('settings');$s=$service();$settings=$s->settings();$error='';$status=200;
        if($request->getMethod()==='POST'){
            try{$settings=$s->saveSettings(input($request));flash('success','产品展示设置已保存。');return redirect($response,'/admin/products/settings');}
            catch(RuntimeException $e){if(!in_array($e->getCode(),[409,422],true))throw $e;$error=$e->getMessage();$status=$e->getCode();foreach(['mode','currency','inquiry_form_key'] as $key){$value=input($request)[$key]??null;if(is_string($value))$settings[$key]=$value;}}
        }
        $forms=[];foreach((new FormService)->listing() as $form)if($form['status']==='published')$forms[]=['key'=>$form['public_key'],'name'=>$form['name']];
        return $render($response,'settings',compact('settings','error','forms')+['title'=>'产品展示设置'])->withStatus($status);
    });
    $app->get('/admin/products/{id:[0-9]+}/edit',static function($request,$response,$args)use($service,$render){
        require_permission('products');$s=$service();$record=$s->get((int)$args['id']);
        if($record['page']['status']==='archived'){flash('warning','请先从回收站恢复产品。');return redirect($response,'/admin/products?status=archived');}
        return $render($response,'editor',compact('record')+['settings'=>$s->settings(),'categories'=>$s->categories(),'title'=>'编辑产品']);
    });
    $app->get('/admin/products/{id:[0-9]+}/history',static function($request,$response,$args)use($service,$render){
        require_permission('products');$s=$service();$record=$s->get((int)$args['id']);
        return $render($response,'history',compact('record')+['revisions'=>$s->history((int)$args['id']),'title'=>'产品版本历史']);
    });
    $app->post('/admin/products/{id:[0-9]+}/restore/{revision:[0-9]+}',static function($request,$response,$args)use($service){
        require_permission('products');$service()->restore((int)$args['id'],(int)$args['revision'],(int)(input($request)['version']??0));
        flash('success','历史版本已恢复为草稿，发布后才会更新公开产品。');return redirect($response,'/admin/products/'.$args['id'].'/edit');
    });
    $app->post('/admin/products/{id:[0-9]+}/action',static function($request,$response,$args)use($service){
        require_permission('products');$data=input($request);$s=$service();$id=(int)$args['id'];$action=$data['action']??'';
        if($action==='duplicate'){$copy=$s->duplicate($id);return redirect($response,'/admin/products/'.$copy['page']['id'].'/edit');}
        if(!in_array($action,['unpublish','archive','restore'],true))throw new RuntimeException('请选择有效的产品操作。',422);
        $s->setStatus($id,$action,(int)($data['version']??0));flash('success',['unpublish'=>'产品已下架，内容保留为草稿。','archive'=>'产品已移入回收站。','restore'=>'产品已恢复为草稿。'][$action]);
        return redirect($response,$action==='restore'?'/admin/products/'.$id.'/edit':'/admin/products'.($action==='archive'?'?status=archived':''));
    });
    $app->get('/admin/api/products/{id:[0-9]+}',static fn($request,$response,$args)=>$api($response,static fn()=>$service()->get((int)$args['id'])));
    $app->post('/admin/api/products',static fn($request,$response)=>$api($response,static fn()=>$service()->save(null,input($request))));
    $app->put('/admin/api/products/{id:[0-9]+}',static fn($request,$response,$args)=>$api($response,static fn()=>$service()->save((int)$args['id'],input($request))));
    $app->post('/admin/api/products/{id:[0-9]+}/publish',static fn($request,$response,$args)=>$api($response,static fn()=>$service()->publish((int)$args['id'],(int)(input($request)['version']??0))));
};
