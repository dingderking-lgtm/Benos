/* Progressive enhancement: image links remain usable when JavaScript is unavailable. */
(() => {
  'use strict';
  // Move the already-initialized native form; cloning would lose its token,
  // submission state and handlers, or create duplicate inquiry submissions.
  const inquiry = document.querySelector('.benos-product #product-inquiry');
  const inquiryTriggers = [...document.querySelectorAll('.benos-product a[href="#product-inquiry"]')];
  if (inquiry && inquiryTriggers.length && typeof HTMLDialogElement !== 'undefined' && typeof HTMLDialogElement.prototype.showModal === 'function') {
    const dialog = document.createElement('dialog');
    dialog.id = 'product-inquiry-dialog';
    dialog.className = 'benos-product benos-product-inquiry-dialog';
    dialog.setAttribute('aria-labelledby', 'product-inquiry-title');
    const english = document.documentElement.lang.toLowerCase().startsWith('en');
    const toolbar = document.createElement('div'); toolbar.className = 'benos-product-inquiry-toolbar';
    const close = document.createElement('button'); close.type = 'button'; close.autofocus = true;
    close.setAttribute('data-aacms-product-inquiry-close', '');
    close.setAttribute('aria-label', english ? 'Close inquiry' : '关闭询盘');
    close.textContent = '×'; toolbar.append(close);
    dialog.append(toolbar, inquiry); document.body.append(dialog);
    let returnFocus = inquiryTriggers[0], outsidePointer = false, scrollLocked = false;
    const outside = event => { const r = dialog.getBoundingClientRect(); return event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom; };
    const open = trigger => {
      if (dialog.open) return;
      returnFocus = trigger;
      dialog.showModal(); dialog.scrollTop = 0;
      scrollLocked = !document.documentElement.classList.contains('benos-product-inquiry-open');
      document.documentElement.classList.add('benos-product-inquiry-open');
      inquiryTriggers.forEach(item => item.setAttribute('aria-expanded', 'true'));
      close.focus({ preventScroll: true });
    };
    inquiryTriggers.forEach(trigger => {
      trigger.setAttribute('role', 'button'); trigger.setAttribute('aria-haspopup', 'dialog');
      trigger.setAttribute('aria-controls', dialog.id); trigger.setAttribute('aria-expanded', 'false');
      trigger.addEventListener('click', event => {
        if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault(); open(trigger);
      });
      trigger.addEventListener('keydown', event => { if (event.key === ' ') { event.preventDefault(); open(trigger); } });
    });
    close.addEventListener('click', () => dialog.close());
    dialog.addEventListener('keydown', event => {
      if (event.key !== 'Tab' || event.ctrlKey || event.altKey || event.metaKey) return;
      const stops = [...dialog.querySelectorAll('a[href],button,input,select,textarea,iframe,[tabindex]')].filter(item =>
        item.tabIndex >= 0 && !item.matches(':disabled') && !item.closest('[hidden],[inert],[aria-hidden="true"]') &&
        item.getClientRects().length > 0 && getComputedStyle(item).visibility !== 'hidden');
      const first = stops[0] || close, last = stops[stops.length - 1] || close;
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      else if (!stops.includes(document.activeElement)) { event.preventDefault(); (event.shiftKey ? last : first).focus(); }
    });
    dialog.addEventListener('pointerdown', event => { outsidePointer = event.target === dialog && outside(event); });
    dialog.addEventListener('click', event => { if (outsidePointer && event.target === dialog && outside(event)) dialog.close(); outsidePointer = false; });
    dialog.addEventListener('close', () => {
      if (scrollLocked) document.documentElement.classList.remove('benos-product-inquiry-open');
      inquiryTriggers.forEach(item => item.setAttribute('aria-expanded', 'false'));
      returnFocus?.focus({ preventScroll: true });
    });
    // Existing bookmarks remain useful, without changing the URL on a button click.
    if (location.hash === '#product-inquiry') open(inquiryTriggers[0]);
    window.addEventListener('hashchange', () => { if (location.hash === '#product-inquiry') open(inquiryTriggers[0]); });
  }
  document.querySelectorAll('[data-aacms-product-gallery]').forEach(gallery => {
    const main = gallery.querySelector('[data-aacms-product-zoom]');
    const image = main?.querySelector('img');
    if (!main || !image) return;
    const thumbs = [...gallery.querySelectorAll('[data-aacms-product-thumb]')];
    thumbs.forEach(thumb => thumb.addEventListener('click', event => {
      if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      const source = thumb.querySelector('img');
      if (!source) return;
      event.preventDefault();
      image.removeAttribute('srcset'); image.removeAttribute('sizes');
      image.src = thumb.href; image.alt = source.alt; main.href = thumb.href;
      thumbs.forEach(item => item === thumb ? item.setAttribute('aria-current', 'true') : item.removeAttribute('aria-current'));
    }));
    let dialog;
    main.addEventListener('click', event => {
      if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || typeof HTMLDialogElement === 'undefined') return;
      event.preventDefault();
      if (!dialog) {
        dialog = document.createElement('dialog'); dialog.className = 'benos-product-zoom';
        const english = document.documentElement.lang.toLowerCase().startsWith('en');
        dialog.setAttribute('aria-label', english ? 'Enlarged product image' : '产品图片大图');
        const close = document.createElement('button'); close.type = 'button'; close.textContent = english ? 'Close' : '关闭';
        close.addEventListener('click', () => dialog.close());
        dialog.append(close, document.createElement('img')); document.body.append(dialog);
        dialog.addEventListener('click', e => { if (e.target === dialog) { const r = dialog.getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close(); } });
        dialog.addEventListener('close', () => main.focus({ preventScroll: true }));
      }
      const enlarged = dialog.querySelector('img'); enlarged.src = image.currentSrc || image.src; enlarged.alt = image.alt;
      if (!dialog.open) dialog.showModal();
    });
  });
})();
