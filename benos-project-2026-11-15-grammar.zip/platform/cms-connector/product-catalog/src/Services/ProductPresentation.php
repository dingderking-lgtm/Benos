<?php
declare(strict_types=1);

namespace AACMS\Services;

use PDO;

/** Public product views use immutable published revisions, never the working page fields. */
final class ProductPresentation
{
    public function __construct(private ?PDO $pdo=null) {}
    private function db():PDO { return $this->pdo??=\db(); }
    private function query(string $sql,array $args=[]):\PDOStatement { $q=$this->db()->prepare($sql);$q->execute($args);return $q; }
    private static function e(mixed $value):string { return htmlspecialchars((string)$value,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
    private static function json(array $value):string { return json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR); }
    private static function text(string $zh,string $en):string { return function_exists('setting')&&str_starts_with(strtolower((string)\setting('site_language','zh-CN')),'en')?$en:$zh; }
    private static function href(array $page):string { return '/'.implode('/',array_map('rawurlencode',explode('/',trim((string)($page['slug']??''),'/')))); }

    /** The optional preview is clearly marked by Renderer; public requests re-read the published snapshot. */
    public function project(array $page,array $revision,bool $preview=false):array
    {
        if(($revision['type']??$page['type']??'')!=='product')return [$page,$revision];
        if(!$preview){
            $published=$this->query("SELECT p.id AS live_page_id,p.status,p.published_at,p.published_revision_id,r.* FROM pages p JOIN page_revisions r ON r.id=p.published_revision_id WHERE p.id=? AND p.status='published' AND r.type='product'",[(int)($page['id']??0)])->fetch(PDO::FETCH_ASSOC);
            if(!$published)throw new \RuntimeException('产品尚未发布或已经下架。',404);
            // A stale draft must not become public merely because its page still has a published revision.
            $publicSlug=$page['slug']??$published['slug'];$revision=$published;$revision['slug']=$publicSlug;$page=array_replace($page,$published,['id'=>(int)$published['live_page_id'],'slug'=>$publicSlug,'updated_at'=>$published['created_at']]);
        }
        $snapshot=array_replace($page,$revision,['id'=>(int)($page['id']??0)]);
        $product=ProductService::publicProduct($snapshot);
        if($product===null){if((Renderer::decode($snapshot['fields']??$snapshot['fields_json']??[])['benos_product']['version']??null)==='bnp-1')throw new \RuntimeException('产品资料无效。',422);return [$page,$revision];}
        $fields=Renderer::decode($revision['fields']??$revision['fields_json']??[]);
        // Generic template field bindings receive the safe projection, never private catalog prices.
        $fields['benos_product']=$product;$revision['fields']=$fields;$revision['fields_json']=self::json($fields);
        $settings=(new ProductService)->settings();
        $related=$this->related($snapshot);
        $revision['document']=['version'=>1,'html'=>$this->detailHtml($snapshot,$product,$related,(string)$settings['inquiry_form_key']),'css'=>'','settings'=>['theme_type'=>'none']];
        $revision['document_json']=self::json($revision['document']);
        $page['_template_type']='none';$page['_benos_product']=true;
        return [$page,$revision];
    }

    /** Inputs here are already public projections; this method is also used by isolated rendering tests. */
    public function detailHtml(array $page,array $product,array $related=[],string $formKey='product-inquiry'):string
    {
        $title=(string)($page['title']??'');$gallery=[];
        foreach($product['gallery']??[] as $image)if(is_array($image)&&is_string($image['src']??null)&&Renderer::safeUrl($image['src']))$gallery[]=['src'=>$image['src'],'alt'=>(string)($image['alt']??$title)];
        if(!$gallery&&!empty($page['featured_image'])&&Renderer::safeUrl((string)$page['featured_image']))$gallery[]=['src'=>$page['featured_image'],'alt'=>$title];
        $html='<article class="benos-product" data-aacms-product="detail"><div class="benos-product-container"><nav class="benos-product-breadcrumb" aria-label="'.self::e(self::text('面包屑导航','Breadcrumb')).'"><a href="/">'.self::text('首页','Home').'</a><span aria-hidden="true">/</span><a href="/products">'.self::text('产品中心','Products').'</a><span aria-hidden="true">/</span><span aria-current="page">'.self::e($title).'</span></nav>';
        $html.='<div class="benos-product-overview'.(!$gallery?' benos-product-without-images':'').'">';
        if($gallery){
            $first=$gallery[0];$html.='<section class="benos-product-gallery" aria-label="'.self::e(self::text('产品图片','Product images')).'" data-aacms-product-gallery="1"><a class="benos-product-main-image" href="'.self::e($first['src']).'" data-aacms-product-zoom="1" aria-label="'.self::e(self::text('放大产品图片','Enlarge product image')).'"><img src="'.self::e($first['src']).'" alt="'.self::e($first['alt']).'" fetchpriority="high"><span class="benos-product-zoom-hint">'.self::text('点击放大','View larger').'</span></a>';
            if(count($gallery)>1){$html.='<nav class="benos-product-thumbnails" aria-label="'.self::e(self::text('选择产品图片','Choose product image')).'">';foreach($gallery as $i=>$image)$html.='<a href="'.self::e($image['src']).'" data-aacms-product-thumb="'.($i+1).'" aria-label="'.self::e(self::text('查看图片 ','View image ').($i+1)).'"'.($i===0?' aria-current="true"':'').'><img src="'.self::e($image['src']).'" alt="'.self::e($image['alt']).'" loading="lazy"></a>';$html.='</nav>';}
            $html.='</section>';
        }
        $html.='<section class="benos-product-summary" aria-labelledby="product-title">';
        if(($page['category']??'')!=='')$html.='<a class="benos-product-category" href="/products?'.self::e(http_build_query(['list_category'=>$page['category']])).'">'.self::e($page['category']).'</a>';
        $html.='<h1 id="product-title">'.self::e($title).'</h1>';
        if(($page['excerpt']??'')!=='')$html.='<p class="benos-product-excerpt">'.nl2br(self::e($page['excerpt']),false).'</p>';
        $html.=self::priceHtml($product);
        $facts=[];foreach(['sku'=>self::text('产品型号','SKU'),'brand'=>self::text('品牌','Brand'),'minimum_order'=>self::text('最小起订量','Minimum order')] as $key=>$label)if(($product[$key]??'')!==''&&($product[$key]??null)!==null&&($key!=='minimum_order'||(int)$product[$key]>0))$facts[]='<dt>'.self::e($label).'</dt><dd>'.self::e($product[$key]).'</dd>';
        if($facts)$html.='<dl class="benos-product-facts">'.implode('',$facts).'</dl>';
        $html.='<a class="benos-product-button" href="#product-inquiry">'.self::text('获取报价','Request a quote').' <span aria-hidden="true">↗</span></a><p class="benos-product-inquiry-note">'.self::text('提交用途、数量或规格需求，我们将按需求与您联系。','Tell us your application, quantity or requirements so we can respond to your inquiry.').'</p></section></div>';
        $description=(string)($product['description']??'');
        if(trim(strip_tags($description))!=='')$html.='<section class="benos-product-section benos-product-description" aria-labelledby="product-description"><h2 id="product-description">'.self::text('产品详情','Product details').'</h2><div class="benos-product-prose">'.PageHiddenContent::sanitizeHtml($description).'</div></section>';
        $specs=$product['specifications']??[];
        if($specs){$html.='<section class="benos-product-section" aria-labelledby="product-specifications"><h2 id="product-specifications">'.self::text('技术规格','Specifications').'</h2><div class="benos-product-table-wrap"><table class="benos-product-specifications"><caption class="benos-product-visually-hidden">'.self::e($title).' '.self::text('技术规格','specifications').'</caption><tbody>';foreach($specs as $spec)$html.='<tr><th scope="row">'.self::e($spec['name']??'').'</th><td>'.nl2br(self::e($spec['value']??''),false).'</td></tr>';$html.='</tbody></table></div></section>';}
        $html.='<section id="product-inquiry" class="benos-product-section benos-product-inquiry" aria-labelledby="product-inquiry-title"><div><span class="benos-product-eyebrow">'.self::text('产品询盘','PRODUCT INQUIRY').'</span><h2 id="product-inquiry-title">'.self::text('获取报价','Request a quote').'</h2><p>'.self::text('正在咨询：','Your inquiry: ').self::e($title).'</p></div><div data-aacms="form" data-form="'.self::e($formKey).'" data-aacms-form="'.self::e($formKey).'"></div></section>';
        if($related){$html.='<section class="benos-product-section" aria-labelledby="product-related"><h2 id="product-related">'.self::text('相关产品','Related products').'</h2><div class="benos-product-cards">';foreach($related as $row)$html.=self::cardHtml($row);$html.='</div></section>';}
        return $html.'</div></article>';
    }

    public static function priceHtml(array $product):string
    {
        if(($product['effective_mode']??'quote')!=='catalog'||!is_string($product['price_text']??null)||$product['price_text']==='')return '';
        return '<p class="benos-product-price">'.self::e($product['price_text']).'</p>';
    }
    public static function listPriceHtml(array $publishedRow):string
    {
        $product=ProductService::publicProduct($publishedRow);return $product?self::priceHtml($product):'';
    }
    public static function cardHtml(array $page):string
    {
        $product=ProductService::publicProduct($page);$href=self::href($page);$src=(string)($product['gallery'][0]['src']??$page['featured_image']??'');
        $html='<article class="benos-product-card">';if($src!==''&&Renderer::safeUrl($src))$html.='<a class="benos-product-card-image" href="'.self::e($href).'" tabindex="-1" aria-hidden="true"><img src="'.self::e($src).'" alt="" loading="lazy"></a>';
        $html.='<div>';if(($page['category']??'')!=='')$html.='<span class="benos-product-eyebrow">'.self::e($page['category']).'</span>';
        $html.='<h3><a href="'.self::e($href).'">'.self::e($page['title']??'').'</a></h3>';
        if(($page['excerpt']??'')!=='')$html.='<p>'.self::e($page['excerpt']).'</p>';
        return $html.($product?self::priceHtml($product):'').'<a class="benos-product-detail-link" href="'.self::e($href).'">'.self::text('查看产品','View product').' <span aria-hidden="true">↗</span></a></div></article>';
    }
    private function related(array $page):array
    {
        $sql="SELECT p.id,p.published_revision_id,r.title,r.slug,r.type,r.category,r.excerpt,r.featured_image,r.fields_json FROM pages p JOIN page_revisions r ON r.id=p.published_revision_id WHERE p.status='published' AND r.type='product' AND p.id<>?";$args=[(int)$page['id']];
        if(($page['category']??'')!==''){$sql.=' AND r.category=?';$args[]=$page['category'];}
        return $this->query($sql.' ORDER BY r.sort_order ASC,p.published_at DESC,p.id DESC LIMIT 4',$args)->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Called only after the ordinary published-page and redirect resolution have found no match. */
    public function dispatch($request,$response,string $slug)
    {
        if($slug!=='products')return null;
        $page=['id'=>0,'title'=>self::text('产品中心','Products'),'slug'=>'products','type'=>'page','_template_type'=>'none','_benos_product_archive'=>true];
        $document=['version'=>1,'html'=>'<section class="benos-product benos-product-archive"><div class="benos-product-container"><header class="benos-product-archive-heading"><span class="benos-product-eyebrow">'.self::text('产品目录','PRODUCT CATALOG').'</span><h1>'.self::e($page['title']).'</h1><p>'.self::text('浏览产品，查看详细规格并提交询盘。','Explore products, compare specifications and send an inquiry.').'</p></header><div data-aacms="page-list" data-type="product" data-limit="12" data-filter="1" data-aacms-pagination="1" data-aacms-columns="3" data-aacms-mobile-columns="1" data-aacms-image-ratio="1/1"></div></div></section>','css'=>'','settings'=>['theme_type'=>'none']];
        $renderer=new Renderer($this->db());
        if($renderer->listRequestStatus($page,$document)!==200)throw new \RuntimeException('产品目录页不存在。',404);
        $target=CrawlQuery::redirectTarget('/products',$request->getUri()->getQuery(),$request->getQueryParams(),$renderer->listQueryParameters($page,$document));
        if($target!==null)return $response->withStatus(301)->withHeader('Location',$target)->withHeader('Cache-Control','public, max-age=60');
        $revision=['document'=>$document,'seo'=>['title'=>$page['title']]];
        $response=\html_response($response,$renderer->pageHtml($page,$revision))->withHeader('Cache-Control','public, max-age=0, must-revalidate');
        if(array_key_exists('list_category',$request->getQueryParams()))$response=$response->withHeader('X-Robots-Tag','noindex, follow');
        return $response;
    }

    public function sitemapEntries():array
    {
        if($this->query("SELECT p.id FROM pages p JOIN page_revisions r ON r.id=p.published_revision_id WHERE p.status='published' AND TRIM(BOTH '/' FROM r.slug)='products' LIMIT 1")->fetchColumn()||$this->query('SELECT id FROM redirects WHERE source=? LIMIT 1',['/products'])->fetchColumn())return [];
        return $this->query("SELECT p.id FROM pages p JOIN page_revisions r ON r.id=p.published_revision_id WHERE p.status='published' AND r.type='product' LIMIT 1")->fetchColumn()?[\url('/products')]:[];
    }

    /** Only trusted published fields enter the immutable inquiry source; posted product/price values are ignored. */
    public static function inquirySource(array $page):?array
    {
        $product=ProductService::publicProduct($page);
        if(!$product||($page['type']??'')!=='product'||(int)($page['published_revision_id']??0)<1)return null;
        return ['id'=>(int)$page['id'],'revision_id'=>(int)$page['published_revision_id'],'sku'=>$product['sku'],'mode'=>$product['effective_mode']];
    }
}
