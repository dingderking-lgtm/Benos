<?php
declare(strict_types=1);
namespace AACMS\Services;

use DOMDocument;
use DOMElement;
use RuntimeException;
use Throwable;

/** Managed catalog data uses the native page draft/revision lifecycle, never a parallel product table. */
final class ProductService
{
    public const VERSION = 'bnp-1';
    public const FIELD = 'benos_product';
    public const SETTING = 'benos_product_settings';
    public const CURRENCIES = ['USD','CNY','EUR','GBP','JPY','AUD','CAD','HKD'];

    public function settings(): array
    {
        $value=\setting(self::SETTING,[]);$value=is_array($value)?$value:[];
        return ['mode'=>in_array($value['mode']??null,['quote','catalog'],true)?$value['mode']:'quote',
            'currency'=>in_array($value['currency']??null,self::CURRENCIES,true)?$value['currency']:'USD',
            'inquiry_form_key'=>is_string($value['inquiry_form_key']??null)&&preg_match('/^[a-z0-9][a-z0-9-]{0,79}$/D',$value['inquiry_form_key'])?$value['inquiry_form_key']:'product-inquiry'];
    }

    public function saveSettings(array $data): array
    {
        $next=array_replace($this->settings(),array_intersect_key($data,array_flip(['mode','currency','inquiry_form_key'])));
        if(!in_array($next['mode'],['quote','catalog'],true)||!in_array($next['currency'],self::CURRENCIES,true)||!is_string($next['inquiry_form_key'])||!preg_match('/^[a-z0-9][a-z0-9-]{0,79}$/D',$next['inquiry_form_key']))throw new RuntimeException('产品展示设置无效。',422);
        if(!\query("SELECT id FROM forms WHERE public_key=? AND status='published' AND active_version_id IS NOT NULL",[$next['inquiry_form_key']])->fetchColumn())throw new RuntimeException('请选择已发布的询价表单。',422);
        if(class_exists('Benos\\Entitlement'))\Benos\Entitlement::assertPublication(BASE_PATH);
        $pdo=\db();$pdo->beginTransaction();
        try{\save_setting(self::SETTING,$next);\audit('product.settings','settings',null,$next);$pdo->commit();}
        catch(Throwable $error){if($pdo->inTransaction())$pdo->rollBack();throw $error;}
        \invalidate_cache();return $next;
    }

    public function listing(array $filters=[],int $limit=25,int $offset=0): array
    {
        $limit=max(1,min(100,$limit));$offset=max(0,$offset);$where=$this->managedSql();$args=[self::VERSION];
        $status=$filters['status']??'all';if(!in_array($status,['all','draft','published','archived'],true))throw new RuntimeException('产品状态筛选无效。',422);
        if($status==='all')$where.=" AND p.status<>'archived'";else{$where.=' AND p.status=?';$args[]=$status;}
        $category=self::text($filters['category']??'',100,'分类');if($category!==''){$where.=' AND p.category=?';$args[]=$category;}
        $search=self::text($filters['q']??'',200,'搜索关键词');if($search!==''){
            $like='%'.strtr($search,['='=>'==','%'=>'=%','_'=>'=_']).'%';
            $where.=" AND (p.title LIKE ? ESCAPE '=' OR p.slug LIKE ? ESCAPE '=' OR (CASE WHEN JSON_VALID(p.fields_json) THEN JSON_UNQUOTE(JSON_EXTRACT(p.fields_json,'$.benos_product.sku')) ELSE '' END) LIKE ? ESCAPE '=')";
            array_push($args,$like,$like,$like);
        }
        $total=(int)\query('SELECT COUNT(*) FROM pages p WHERE '.$where,$args)->fetchColumn();
        $items=[];foreach(\query('SELECT p.* FROM pages p WHERE '.$where.' ORDER BY p.updated_at DESC,p.id DESC LIMIT '.$limit.' OFFSET '.$offset,$args)->fetchAll() as $page)$items[]=$this->payload($page);
        return ['items'=>$items,'total'=>$total];
    }

    public function get(int $id): array {return $this->payload($this->managedPage($id));}

    public function save(?int $id,array $data): array
    {
        $page=$id===null?null:$this->managedPage($id);$fields=$page?\decode_json($page['fields_json']):[];
        if(isset($data['product'])&&!is_array($data['product']))throw new RuntimeException('产品资料格式无效。',422);
        $product=self::normalize(array_replace($page?$fields[self::FIELD]:[],(array)($data['product']??[])),true,$this->settings()['currency']);
        $title=self::text($data['title']??$page['title']??'',255,'产品名称',true);
        $excerpt=self::text($data['excerpt']??$page['excerpt']??'',4000,'产品摘要');
        $slug=self::text($data['slug']??$page['slug']??'',180,'产品网址');
        if($slug===''){$stem=trim(preg_replace('~[^\pL\pN_-]+~u','-',mb_strtolower(mb_substr($title,0,80)))??'','-');$slug='products/'.($stem!==''?$stem:'product').'-'.bin2hex(random_bytes(3));}
        $category=self::text($data['category']??$page['category']??'',100,'分类');
        $seo=$data['seo']??($page?\decode_json($page['seo_json']):[]);if(!is_array($seo))throw new RuntimeException('SEO 设置无效。',422);
        $fields[self::FIELD]=$product;
        $input=['title'=>$title,'slug'=>$slug,'type'=>'product','excerpt'=>$excerpt,'category'=>$category,'featured_image'=>$product['gallery'][0]['src']??'',
            'fields'=>$fields,'seo'=>$seo,'document'=>self::document($title,$excerpt,$product)];
        $service=new PageService;
        if($id===null)$id=$service->create($input);
        else{$input['version']=$data['version']??0;$service->save($id,$input);}
        return $this->get($id);
    }

    public function publish(int $id,int $version): array
    {
        self::validateManagedPage($this->managedPage($id));
        (new PageService)->publish($id,$version);return $this->get($id);
    }

    public function setStatus(int $id,string $action,int $version): array
    {
        $this->managedPage($id);(new PageService)->setStatus($id,$action,$version);return $this->get($id);
    }

    public function history(int $id): array
    {
        $page=$this->managedPage($id);$items=\query('SELECT id,page_id,version,title,slug,type,category,created_at,created_by FROM page_revisions WHERE page_id=? ORDER BY id DESC LIMIT 200',[$id])->fetchAll();
        foreach($items as &$item)$item['currentPublished']=(int)$item['id']===(int)$page['published_revision_id'];return $items;
    }

    /** Restore only a draft, preserving unrelated custom fields and the current live revision. */
    public function restore(int $id,int $revisionId,int $version): array
    {
        $this->managedPage($id);$revision=\query('SELECT * FROM page_revisions WHERE id=? AND page_id=?',[$revisionId,$id])->fetch();
        if(!$revision||!self::rawProduct($revision))throw new RuntimeException('产品历史版本不存在。',404);
        return $this->save($id,['version'=>$version,'title'=>$revision['title'],'slug'=>$revision['slug'],'excerpt'=>$revision['excerpt'],'category'=>$revision['category'],
            'product'=>self::rawProduct($revision),'seo'=>\decode_json($revision['seo_json'])]);
    }

    public function duplicate(int $id): array
    {
        $source=$this->managedPage($id);$fields=\decode_json($source['fields_json']);$product=self::normalize($fields[self::FIELD],true,$this->settings()['currency']);
        $seo=\decode_json($source['seo_json']);unset($seo['canonical']);
        $title=mb_substr($source['title'],0,250).' 副本';$input=['title'=>$title,'slug'=>'products/copy-'.bin2hex(random_bytes(8)),'type'=>'product','category'=>$source['category'],
            'excerpt'=>$source['excerpt'],'featured_image'=>$product['gallery'][0]['src']??'','seo'=>$seo,'fields'=>array_replace($fields,[self::FIELD=>$product]),
            'document'=>self::document($title,$source['excerpt'],$product)];
        return $this->get((new PageService)->create($input));
    }

    public function categories(): array
    {
        return \query("SELECT DISTINCT p.category FROM pages p WHERE ".$this->managedSql()." AND p.status<>'archived' AND p.category<>'' ORDER BY p.category",[self::VERSION])->fetchAll(\PDO::FETCH_COLUMN);
    }

    /** Public callers must supply a published revision, not the mutable pages draft. */
    public static function publicProduct(array $page): ?array
    {
        $raw=self::rawProduct($page);if($raw===null)return null;
        try{$settings=(new self)->settings();$value=self::normalize($raw,true,$settings['currency']);}
        catch(RuntimeException){return null;}
        $value['effective_mode']=$value['mode']==='inherit'?$settings['mode']:$value['mode'];
        if($value['effective_mode']==='quote')$value['price']=null;
        $value['price_text']=$value['price']===null?'':$value['currency'].' '.$value['price'].($value['price_unit']!==''?' / '.$value['price_unit']:'');
        return $value;
    }

    /** Hook this inside PageService's locked publish transaction before changing any live pointers. */
    public static function validateManagedPage(array $page): void
    {
        $fields=\decode_json($page['fields_json']??[]);if(!array_key_exists(self::FIELD,$fields))return;
        if(($page['type']??'')!=='product'||!is_array($fields[self::FIELD])||($fields[self::FIELD]['version']??null)!==self::VERSION)throw new RuntimeException('产品数据版本或页面类型无效。',422);
        $settings=(new self)->settings();$value=self::normalize($fields[self::FIELD],true,$settings['currency']);
        // A generic editor cannot bypass the canonical product validator or inject markup into private fields.
        if($value!=$fields[self::FIELD])throw new RuntimeException('产品资料需在产品管理中规范化后再发布。',422);
        if(($value['mode']==='inherit'?$settings['mode']:$value['mode'])==='catalog'&&$value['price']===null)throw new RuntimeException('展示价格的产品需要填写价格，或改为获取报价模式。',422);
        if(($page['featured_image']??'')!==($value['gallery'][0]['src']??''))throw new RuntimeException('产品封面须与图集首图一致，请在产品管理中保存。',422);
        MediaService::assertDocumentAssets(['product'=>$value]);
    }

    private function managedSql(): string {return "p.type='product' AND (CASE WHEN JSON_VALID(p.fields_json) THEN JSON_UNQUOTE(JSON_EXTRACT(p.fields_json,'$.benos_product.version')) ELSE NULL END)=?";}
    private function managedPage(int $id): array
    {
        $page=(new PageService)->find($id);if(self::rawProduct($page)===null)throw new RuntimeException('产品不存在或不属于此产品目录。',404);return $page;
    }
    private function payload(array $page): array
    {
        $payload=(new PageService)->payload($page);return ['page'=>$payload['page'],'product'=>self::normalize(self::rawProduct($page)??[],true,$this->settings()['currency']),
            'seo'=>$payload['seo'],'version'=>$payload['version'],'has_unpublished_changes'=>(bool)$payload['page']['has_unpublished_changes']];
    }
    private static function rawProduct(array $page): ?array
    {
        $fields=\decode_json($page['fields_json']??[]);$product=$fields[self::FIELD]??null;
        return ($page['type']??'')==='product'&&is_array($product)&&($product['version']??null)===self::VERSION?$product:null;
    }
    private static function text(mixed $value,int $max,string $label,bool $required=false): string
    {
        if(!is_string($value))throw new RuntimeException($label.'须为文字。',422);$value=trim($value);
        if(mb_strlen($value)>$max||($required&&$value==='')||preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/',$value))throw new RuntimeException($label.'长度或内容无效。',422);return $value;
    }
    private static function normalize(array $input,bool $sanitize,string $defaultCurrency): array
    {
        if(isset($input['version'])&&$input['version']!==self::VERSION)throw new RuntimeException('产品数据版本不受支持。',422);
        $mode=$input['mode']??'inherit';$currency=$input['currency']??$defaultCurrency;
        if(!in_array($mode,['inherit','quote','catalog'],true)||!in_array($currency,self::CURRENCIES,true))throw new RuntimeException('价格模式或币种无效。',422);
        $price=$input['price']??null;if($price==='')$price=null;
        if($price!==null&&(!is_string($price)||!preg_match('/^(?:0|[1-9][0-9]{0,11})(?:\.[0-9]{1,4})?$/D',$price)))throw new RuntimeException('价格须为最多 12 位整数、4 位小数的非负十进制金额。',422);
        $minimum=$input['minimum_order']??1;if(filter_var($minimum,FILTER_VALIDATE_INT)===false||(int)$minimum<1||(int)$minimum>1000000000)throw new RuntimeException('起订量须为 1 至 1000000000 的整数。',422);
        $gallery=$input['gallery']??[];$specs=$input['specifications']??[];
        if(!is_array($gallery)||!array_is_list($gallery)||count($gallery)>10||!is_array($specs)||!array_is_list($specs)||count($specs)>24)throw new RuntimeException('图集最多 10 张，参数最多 24 项。',422);
        $images=[];foreach($gallery as $item){if(!is_array($item))throw new RuntimeException('图集格式无效。',422);$src=self::text($item['src']??'',500,'图片路径',true);
            if(!preg_match('~^/uploads/\d{4}/\d{2}/[a-f0-9]{32,64}(?:-(?:320|960))?\.(?:jpe?g|png|webp|gif|svg)$~iD',$src))throw new RuntimeException('请选择本站媒体库图片。',422);
            $images[]=['src'=>$src,'alt'=>self::text($item['alt']??'',500,'图片说明')];}
        $parameters=[];foreach($specs as $item){if(!is_array($item))throw new RuntimeException('产品参数格式无效。',422);$parameters[]=['name'=>self::text($item['name']??'',120,'参数名称',true),'value'=>self::text($item['value']??'',1000,'参数值',true)];}
        $description=self::text($input['description']??'',100000,'产品详情');if($sanitize)$description=self::description($description);
        return ['version'=>self::VERSION,'sku'=>self::text($input['sku']??'',120,'产品型号'),'brand'=>self::text($input['brand']??'',160,'品牌'),'mode'=>$mode,'price'=>$price,'currency'=>$currency,
            'price_unit'=>self::text($input['price_unit']??'',40,'价格单位'),'minimum_order'=>(int)$minimum,'gallery'=>$images,'specifications'=>$parameters,'description'=>$description];
    }

    private static function description(string $html): string
    {
        if($html==='')return '';$html=(new Renderer)->sanitizeHtml($html);
        $allowed='<p><br><strong><b><em><i><u><s><h2><h3><h4><ul><ol><li><blockquote><a><table><thead><tbody><tr><th><td><caption><sup><sub>';
        $html=strip_tags($html,$allowed);$dom=new DOMDocument('1.0','UTF-8');$old=libxml_use_internal_errors(true);
        try{$dom->loadHTML('<?xml encoding="UTF-8"><div id="product-description">'.$html.'</div>',LIBXML_NONET|LIBXML_HTML_NOIMPLIED|LIBXML_HTML_NODEFDTD);
            $root=$dom->getElementById('product-description');if(!$root)return '';
            foreach($root->getElementsByTagName('*') as $element){if(!$element instanceof DOMElement)continue;
                foreach(iterator_to_array($element->attributes) as $attr){$keep=$element->tagName==='a'&&in_array($attr->name,['href','title'],true);if(!$keep)$element->removeAttribute($attr->name);}
                if($element->tagName==='a'&&!Renderer::safeUrl($element->getAttribute('href'),true))$element->removeAttribute('href');
            }
            $out='';foreach($root->childNodes as $node)$out.=$dom->saveHTML($node);return $out;
        }finally{libxml_clear_errors();libxml_use_internal_errors($old);}
    }
    private static function document(string $title,string $excerpt,array $product): array
    {
        $html='<article><h1>'.\e($title).'</h1>'.($excerpt!==''?'<p>'.\e($excerpt).'</p>':'').$product['description'];
        if($product['specifications']){$html.='<dl>';foreach($product['specifications'] as $spec)$html.='<div><dt>'.\e($spec['name']).'</dt><dd>'.\e($spec['value']).'</dd></div>';$html.='</dl>';}
        return ['version'=>1,'html'=>$html.'</article>','css'=>'','settings'=>['theme_type'=>'none']];
    }
}
