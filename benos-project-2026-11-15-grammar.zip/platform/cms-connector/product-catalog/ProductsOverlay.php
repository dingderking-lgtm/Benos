<?php
declare(strict_types=1);
namespace Benos;

/** Exact overlays for the pinned distribution. No customer installation or reference file is edited. */
final class ProductsOverlay
{
    private static function replace(string $source,string $needle,string $replacement,string $hook):string
    {
        $source=str_replace($needle,$replacement,$source,$count);
        if($count!==1)throw new \RuntimeException('Pinned product hook changed: '.$hook.' ('.$count.').');
        return $source;
    }
    public static function transform(string $path,string $source):string
    {
        if(!in_array($path,['src/Services/Renderer.php','src/Services/FormService.php','src/Services/PublicAssets.php','src/Services/Seo.php','routes/public.php'],true))return $source;
        $source=str_replace("\r\n","\n",$source);
        if($path==='src/Services/Renderer.php'){
            $needle="    public function pageHtml(array \$page,array \$revision,bool \$preview=false): string\n    {";
            $source=self::replace($source,$needle,$needle."\n        [\$page,\$revision]=(new ProductPresentation(\$this->database()))->project(\$page,\$revision,\$preview);",'renderer published product projection');
            $needle='SELECT p.id,r.title,r.slug,r.type,r.category,r.excerpt,r.featured_image FROM pages p JOIN page_revisions r ON r.id=p.published_revision_id';
            $source=self::replace($source,$needle,'SELECT p.id,p.published_revision_id,r.title,r.slug,r.type,r.category,r.excerpt,r.featured_image,r.fields_json FROM pages p JOIN page_revisions r ON r.id=p.published_revision_id','list published product fields');
            $needle="            \$html.='<a class=\"aacms-text-link\" href=\"'.self::escape(\$href).'\">'.self::escape(\$button).' '.self::icon('arrow-right').'</a></div></article>';";
            $source=self::replace($source,$needle,"            \$html.=ProductPresentation::listPriceHtml(\$row);\n".$needle,'list safe product price');
            $needle="        \$componentStyles=[];if(\$resources['blog'])\$componentStyles[]='blog-public.css';";
            $source=self::replace($source,$needle,$needle."\n        \$productResources=str_contains(\$main,'benos-product');if(\$productResources)\$componentStyles[]='products-public.css';",'product asset stylesheet');
            $needle="        if(\$resources['formRuntime'])\$html.='<script src=\"'.self::escape(\$this->assetUrl('forms-public.js')).'\" defer></script>';";
            $source=self::replace($source,$needle,$needle."\n        if(\$productResources)\$html.='<script src=\"'.self::escape(\$this->assetUrl('products-public.js')).'\" defer></script>';",'product image runtime');
            $needle="foreach(['src/Services/Renderer.php','src/Services/ArkpmArticleCompatibility.php'";
            $source=self::replace($source,$needle,"foreach(['src/Services/ProductPresentation.php','src/Services/ProductService.php','public/assets/products-public.css','public/assets/products-public.js','src/Services/Renderer.php','src/Services/ArkpmArticleCompatibility.php'",'product cache fingerprint');
        }
        if($path==='src/Services/PublicAssets.php'){
            $source=self::replace($source,"private const STYLES=['site.css','menu-navigation.css'","private const STYLES=['products-public.css','site.css','menu-navigation.css'",'product owned stylesheet allowlist');
        }
        if($path==='src/Services/FormService.php'){
            $needle='SELECT id,title,slug,type FROM pages WHERE id=? AND status=\'published\'';
            $source=self::replace($source,$needle,'SELECT p.id,p.published_revision_id,r.title,r.slug,r.type,r.fields_json FROM pages p JOIN page_revisions r ON r.id=p.published_revision_id WHERE p.id=? AND p.status=\'published\'','inquiry published product snapshot');
            $needle="            \$page=\$page?:[];";
            $source=self::replace($source,$needle,$needle."\n            if(\$grant['page_id']&&!\$page&&\$key===(new ProductService)->settings()['inquiry_form_key'])throw new FormException('产品已下架，请刷新后重新选择产品。',409);",'withdrawn product inquiry');
            $needle="            \$source=['page_title'=>\$page['title']??'','page_url'=>isset(\$page['slug'])?\\url('/'.ltrim(\$page['slug'],'/')):'','utm'=>[]];";
            $source=self::replace($source,$needle,$needle."\n            if((\$productSource=ProductPresentation::inquirySource(\$page))!==null)\$source['product']=\$productSource;",'trusted inquiry source');
        }
        if($path==='routes/public.php'){
            $needle="        if(!\$row){\$blogResponse=\$blogDispatch(\$request,\$response,\$slug);return \$blogResponse??\$errorPage(\$response,404,\$slug);}";
            $replacement="        if(!\$row){\$blogResponse=\$blogDispatch(\$request,\$response,\$slug);if(\$blogResponse!==null)return \$blogResponse;try{\$productResponse=(new \\AACMS\\Services\\ProductPresentation)->dispatch(\$request,\$response,\$slug);}catch(\\RuntimeException \$error){if(\$error->getCode()===404)return \$errorPage(\$response,404,\$slug);throw \$error;}return \$productResponse??\$errorPage(\$response,404,\$slug);}";
            $source=self::replace($source,$needle,$replacement,'fallback products route');
        }
        if($path==='src/Services/Seo.php'){
            $needle="        foreach((new BlogRenderer(\$this->database()))->sitemapEntries() as \$location)\$append(\$location);";
            $source=self::replace($source,$needle,$needle."\n        foreach((new ProductPresentation(\$this->database()))->sitemapEntries() as \$location)\$append(\$location);",'virtual product catalog sitemap');
        }
        return $source;
    }
}
