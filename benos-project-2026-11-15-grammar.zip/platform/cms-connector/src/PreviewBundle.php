<?php
declare(strict_types=1);
namespace Benos;
use AACMS\Services\SitePackageService;

/** Read-only native rendering; artifacts are private, scoped and short-lived. */
final class PreviewBundle {
    private string $base;
    public function __construct(private string $root,private array $connection,private ?int $clock=null){
        $this->base=$root.'/storage/private/benos-previews';
        foreach([$root,$root.'/storage',$root.'/storage/private'] as $path)if(!is_dir($path)||is_link($path))throw new ProtocolError('PREVIEW_STORAGE_UNSAFE',503);
        if(!is_dir($this->base)&&!mkdir($this->base,0700))throw new ProtocolError('PREVIEW_STORAGE_UNAVAILABLE',503);
        if(is_link($this->base))throw new ProtocolError('PREVIEW_STORAGE_UNSAFE',503);
    }
    private function now():int{return $this->clock??time();}
    private function bundles():Bundle{return new Bundle($this->root,$this->connection,fn()=>false,$this->clock);}
    private function dir(string $id):string{if(!preg_match('/^preview_[a-f0-9]{32}$/D',$id))throw new ProtocolError('PREVIEW_ID_INVALID',422);$path=$this->base.'/'.$id;if(is_link($path))throw new ProtocolError('PREVIEW_STORAGE_UNSAFE',503);return $path;}
    private function path(string $id,string $file):string{$path=$this->dir($id).'/'.$file;if(is_link($path))throw new ProtocolError('PREVIEW_STORAGE_UNSAFE',503);return $path;}
    private function read(string $id):array{$path=$this->path($id,'state.json');if(!is_file($path))throw new ProtocolError('PREVIEW_NOT_FOUND',404);if(filesize($path)>131072)throw new ProtocolError('PREVIEW_STATE_INVALID',503);$state=json_decode(file_get_contents($path),true,64,JSON_THROW_ON_ERROR);if(($state['previewId']??null)!==$id||($state['siteId']??null)!==$this->connection['siteId'])throw new ProtocolError('PREVIEW_IDENTITY_INVALID',403);return $state;}
    private function store(array $state):void{Protocol::writePrivateJson($this->path($state['previewId'],'state.json'),$state,'PREVIEW_STATE_UNAVAILABLE');}
    private function view(array $state):array{return array_diff_key($state,array_flip(['reservedBytes','requestHash']));}
    private function releaseBundle(array $state):void{try{$bundle=$this->bundles();$bundle->unpin($state['bundleId'],$state['previewId']);$bundle->dispatch(['operation'=>'bundle-discard','bundleId'=>$state['bundleId']]);}catch(\Throwable){/* Expiry/reconciliation keeps unknown ownership fail-closed. */}}
    private function clearFiles(string $id):void{
        foreach(scandir($this->dir($id))?:[] as $name){if(!preg_match('/^(?:preview\.html|asset-[0-9]{1,2}\.(?:svg|png|jpe?g|webp|gif))(?:\.tmp)?$/D',$name))continue;$path=$this->path($id,$name);if(is_file($path)&&!unlink($path))throw new ProtocolError('PREVIEW_CLEANUP_UNCERTAIN',503);}
    }
    private function sweep():array{
        $active=0;$reserved=0;$count=0;
        foreach(scandir($this->base)?:[] as $id){if(!preg_match('/^preview_[a-f0-9]{32}$/D',$id))continue;$count++;$path=$this->path($id,'state.json');if(!is_file($path))continue;$state=$this->read($id);
            if($state['expiresAt']<=$this->now()&&!in_array($state['state'],['expired','discarded'],true)){$state['state']='expired';unset($state['html'],$state['assets'],$state['sanitizationChanges']);$this->store($state);}
            if(in_array($state['state'],['expired','discarded'],true)){$this->clearFiles($id);$this->releaseBundle($state);if($state['expiresAt']+7*86400<=$this->now()){if(!unlink($path)||!rmdir($this->dir($id)))throw new ProtocolError('PREVIEW_CLEANUP_UNCERTAIN',503);$count--;}continue;}
            $active++;$reserved+=$state['reservedBytes'];
        }return [$active,$reserved,$count];
    }
    private function artifact(string $id,string $name,string $bytes,int $limit):array{
        if(strlen($bytes)<1||strlen($bytes)>$limit)throw new ProtocolError('PREVIEW_ARTIFACT_TOO_LARGE',413);$target=$this->path($id,$name);$temporary=$this->path($id,$name.'.tmp');
        if(file_put_contents($temporary,$bytes,LOCK_EX)!==strlen($bytes)||!chmod($temporary,0600))throw new ProtocolError('PREVIEW_WRITE_UNCERTAIN',503);
        $written=false;for($n=0;$n<6;$n++){if(@rename($temporary,$target)){$written=true;break;}if($n<5)usleep(20000*($n+1));}if(!$written)throw new ProtocolError('PREVIEW_WRITE_UNCERTAIN',503);
        return ['size'=>strlen($bytes),'sha256'=>hash('sha256',$bytes)];
    }
    /** Returns a metadata array or exact raw artifact bytes, never a public URL. */
    public function dispatch(array $input):array|string{
        $lockPath=$this->base.'/lock';if(is_link($lockPath))throw new ProtocolError('PREVIEW_STORAGE_UNSAFE',503);$lock=fopen($lockPath,'c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB)){if(is_resource($lock))fclose($lock);throw new ProtocolError('PREVIEW_BUSY',503);}
        try{
            [$active,$reserved,$count]=$this->sweep();$id=$input['previewId']??null;if(!is_string($id))throw new ProtocolError('PREVIEW_ID_INVALID',422);$this->dir($id);$operation=$input['operation']??'';
            if($operation==='preview-render-bundle')return $this->render($id,$input,$active,$reserved,$count);
            $state=$this->read($id);
            if($operation==='preview-status')return $this->view($state);
            if($operation==='preview-discard'){$state['state']='discarded';unset($state['html'],$state['assets'],$state['sanitizationChanges']);$this->store($state);$this->clearFiles($id);$this->releaseBundle($state);return $this->view($state);}
            if($operation==='preview-artifact-chunk'){
                if($state['state']!=='ready'||$state['expiresAt']<=$this->now())throw new ProtocolError('PREVIEW_NOT_READY',409);
                $file=$input['file']??null;$offset=$input['offset']??null;$length=$input['length']??null;$metadata=null;$name=null;
                if($file==='preview.html'){$metadata=$state['html'];$name='preview.html';}else foreach($state['assets'] as $index=>$asset)if($asset['mode']==='sanitized'&&$asset['file']===$file){$metadata=$asset;$name='asset-'.$index.'.'.pathinfo($file,PATHINFO_EXTENSION);break;}
                if(!$metadata||!is_int($offset)||$offset<0||!is_int($length)||$length<1||$length>1048576||$offset+$length>$metadata['size'])throw new ProtocolError('PREVIEW_ARTIFACT_RANGE_INVALID',422);
                $path=$this->path($id,$name);if(!is_file($path)||filesize($path)!==$metadata['size']||!hash_equals($metadata['sha256'],hash_file('sha256',$path)))throw new ProtocolError('PREVIEW_ARTIFACT_CORRUPT',503);
                $bytes=file_get_contents($path,false,null,$offset,$length);if(!is_string($bytes)||strlen($bytes)!==$length)throw new ProtocolError('PREVIEW_ARTIFACT_CORRUPT',503);return $bytes;
            }throw new ProtocolError('PREVIEW_OPERATION_INVALID',422);
        }finally{flock($lock,LOCK_UN);fclose($lock);}
    }
    private function render(string $id,array $input,int $active,int $reserved,int $count):array{
        $bundle=$input['bundleId']??null;$project=$input['projectId']??null;$version=$input['versionId']??null;$page=$input['pageKey']??null;
        if(!is_string($bundle)||!preg_match('/^bundle_[a-f0-9]{32}$/D',$bundle)||!is_string($project)||!preg_match('/^prj_[a-f0-9]{32}$/D',$project)||!is_string($version)||!preg_match('/^(?:ver|candidate)_[a-f0-9]{32}$/D',$version)||!is_string($page)||!preg_match('/^[a-zA-Z0-9_-]{1,80}$/D',$page)||array_key_exists('manifest',$input)||array_key_exists('manifestJson',$input)||array_key_exists('assets',$input))throw new ProtocolError('PREVIEW_INPUT_INVALID',422);
        $requestHash=hash('sha256',json_encode([$bundle,$project,$version,$page],JSON_THROW_ON_ERROR));
        if(is_file($this->path($id,'state.json'))){$state=$this->read($id);if(!hash_equals($state['requestHash'],$requestHash))throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);if($state['state']!=='preparing')return $this->view($state);}
        else{
            $meta=$this->bundles()->dispatch(['operation'=>'bundle-status','bundleId'=>$bundle]);if($meta['purpose']!=='preview'||$meta['projectId']!==$project||$meta['versionId']!==$version||$meta['state']!=='sealed'||$meta['expired'])throw new ProtocolError('BUNDLE_PREVIEW_BINDING_INVALID',409);
            // 96 MiB native assets + 16 MiB HTML + one bounded write temporary.
            $bytes=128*1048576;if($active>=4||$reserved+$bytes>256*1048576||$count>=1024)throw new ProtocolError('PREVIEW_QUOTA_EXCEEDED',429);
            if(!is_dir($this->dir($id))&&!mkdir($this->dir($id),0700))throw new ProtocolError('PREVIEW_STORAGE_UNAVAILABLE',503);
            $state=['protocol'=>'benos-native-preview-v2','previewId'=>$id,'bundleId'=>$bundle,'siteId'=>$this->connection['siteId'],'projectId'=>$project,'versionId'=>$version,'pageKey'=>$page,'manifestSha256'=>$meta['files'][0]['sha256'],'cmsVersion'=>'1.9.21','state'=>'preparing','expiresAt'=>$this->now()+21600,'reservedBytes'=>$bytes,'requestHash'=>$requestHash,'usesSampleData'=>true,'dataMode'=>'manifest-samples','businessWrites'=>false];$this->store($state);
        }
        $package=$this->bundles()->previewPackage($bundle,$project,$version,$id,$state['expiresAt']);if(!hash_equals($state['manifestSha256'],$package['manifestSha256']))throw new ProtocolError('PREVIEW_IDENTITY_INVALID',409);
        $manifest=(new SitePackageService)->inspect($package['zipPath']);AssetPolicy::manifest($manifest);$assets=[];$artifactBytes=0;
        $result=(new Preview)->renderBundle($manifest,$state['manifestSha256'],$page,$package['files'],function(array $asset,array $safe,int $index)use($id,&$assets,&$artifactBytes){
            $bytes=$safe['bytes'];$digest=hash('sha256',$bytes);$same=hash_equals($asset['sha256'],$digest)&&strlen($bytes)===(int)$asset['size'];
            $mode=$safe['mime']==='application/pdf'?'blocked':($safe['mime']==='image/svg+xml'||!$same?'sanitized':'original');
            if($mode==='sanitized'){$artifactBytes+=strlen($bytes);if($artifactBytes>96*1048576)throw new ProtocolError('PREVIEW_ARTIFACT_TOO_LARGE',413);$this->artifact($id,'asset-'.$index.'.'.pathinfo($asset['file'],PATHINFO_EXTENSION),$bytes,$safe['mime']==='image/svg+xml'?1048576:16*1048576);}
            $assets[]=['file'=>$asset['file'],'sourceSha256'=>$asset['sha256'],'size'=>$mode==='sanitized'?strlen($bytes):(int)$asset['size'],'sha256'=>$mode==='sanitized'?$digest:$asset['sha256'],'mime'=>$safe['mime'],'mode'=>$mode];
            return $mode==='blocked'?null:'/__benos_preview_assets/'.$id.'/'.$index;
        });
        if($state['expiresAt']<=$this->now())throw new ProtocolError('PREVIEW_EXPIRED',409);
        $state['html']=['file'=>'preview.html']+$this->artifact($id,'preview.html',$result['html'],16*1048576);$state['assets']=$assets;$state['sanitizationChanges']=$result['sanitizationChanges'];$state['state']='ready';$this->store($state);
        // All required sanitized data is now durable; original raster resources
        // stay in the platform's scoped private object inventory.
        $this->releaseBundle($state);return $this->view($state);
    }
}
