<?php
declare(strict_types=1);
namespace Benos;

final class ProtocolError extends \RuntimeException {
    public function __construct(public readonly string $errorCode, public readonly int $status=400) { parent::__construct($errorCode); }
}

final class Protocol {
    public static function writePrivateJson(string $path,array $value,string $code='STATE_WRITE_FAILED'):void {
        // Do not unlink the old destination. Readers must see either the previous
        // complete state or the new complete state, including after a failed write.
        if(is_link($path))throw new ProtocolError($code,503);
        $temporary=$path.'.'.bin2hex(random_bytes(8)).'.tmp';$written=false;
        try{
            $bytes=json_encode($value,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
            if(file_put_contents($temporary,$bytes,LOCK_EX)!==strlen($bytes)||!chmod($temporary,0600))throw new ProtocolError($code,503);
            // A Windows scanner/backup reader may briefly hold the replaced file.
            // Bound retry to 300 ms; permanent faults stay explicit and fail closed.
            for($attempt=0;$attempt<6;$attempt++){
                if(@rename($temporary,$path)){$written=true;return;}
                clearstatcache(true,$path);if($attempt<5)usleep(20000*($attempt+1));
            }
            throw new ProtocolError($code,503);
        }finally{if(!$written&&is_file($temporary)&&!is_link($temporary))@unlink($temporary);}
    }
    public static function base64url(string $bytes): string { return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '='); }
    public static function verify(array $headers,string $method,string $target,string $body,array $keys,string $protocol,callable $consumeNonce):array {
        if(strlen($body)>($protocol==='BENOS-CMS-V1'?10*1048576:($protocol==='BENOS-CMS-BUNDLE-V2'?1048576+4104:16384)))throw new ProtocolError('REQUEST_TOO_LARGE',413);
        if(!preg_match('~^/[A-Za-z0-9/_-]+(?:\.php)?$~D',$target)||str_contains($target,'//'))throw new ProtocolError('TARGET_INVALID');
        $headers=array_change_key_case($headers,CASE_LOWER);
        $kid=(string)($headers['x-benos-key-id']??'');$site=(string)($headers['x-benos-site-id']??'');
        $time=(string)($headers['x-benos-timestamp']??'');$nonce=(string)($headers['x-benos-nonce']??'');
        $signature=(string)($headers['x-benos-signature']??'');$idem=(string)($headers['idempotency-key']??'');
        if(!preg_match('/^[A-Za-z0-9_-]{1,80}$/D',$kid)||!isset($keys[$kid])||strlen((string)$keys[$kid])<32)throw new ProtocolError('UNAUTHORIZED',401);
        if(!preg_match('/^(?:platform|site_[a-f0-9]{32})$/D',$site)||!preg_match('/^\d{10,12}$/D',$time)||abs(time()-(int)$time)>120||!preg_match('/^[A-Za-z0-9_-]{22,80}$/D',$nonce))throw new ProtocolError('UNAUTHORIZED',401);
        if($method!=='GET'&&!preg_match('/^[A-Za-z0-9_-]{8,160}$/D',$idem))throw new ProtocolError('IDEMPOTENCY_REQUIRED');
        $canonical=implode("\n",[$protocol,$kid,$site,$time,$nonce,strtoupper($method),$target,hash('sha256',$body),$idem]);
        $expected=self::base64url(hash_hmac('sha256',$canonical,(string)$keys[$kid],true));
        if(!hash_equals($expected,$signature))throw new ProtocolError('UNAUTHORIZED',401);
        $consumeNonce(hash('sha256',$kid.'|'.$nonce),time()+300);
        return ['kid'=>$kid,'siteId'=>$site,'nonce'=>$nonce,'idempotencyKey'=>$idem,'secret'=>(string)$keys[$kid],'protocol'=>$protocol];
    }
    public static function response(array $identity,int $status,array $data):array {
        $body=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);return self::rawResponse($identity,$status,$body,'application/json; charset=utf-8');
    }
    public static function rawResponse(array $identity,int $status,string $body,string $contentType='application/octet-stream'):array {
        $time=(string)time();
        $canonical=implode("\n",[$identity['protocol'].'-RESPONSE',$identity['nonce'],(string)$status,$time,hash('sha256',$body)]);
        return ['status'=>$status,'body'=>$body,'headers'=>['Content-Type'=>$contentType,'Cache-Control'=>'no-store','X-Content-Type-Options'=>'nosniff','X-Benos-Timestamp'=>$time,'X-Benos-Signature'=>self::base64url(hash_hmac('sha256',$canonical,$identity['secret'],true))]];
    }
    public static function emit(array $response):never { http_response_code($response['status']);foreach($response['headers'] as $key=>$value)header($key.': '.$value);echo $response['body'];exit; }
}
