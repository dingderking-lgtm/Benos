<?php
declare(strict_types=1);
namespace {
    // Native Installer uses only these global helpers. Do not load the CMS web
    // bootstrap/session into the privileged bridge or reuse a prior site's DB.
    function storage_path(string $path=''):string { return BASE_PATH.'/storage/'.ltrim($path,'/'); }
    function decode_json(mixed $value):array { if(is_array($value))return $value;try{$decoded=json_decode((string)$value,true,128,JSON_THROW_ON_ERROR);return is_array($decoded)?$decoded:[];}catch(\JsonException){return [];} }
    function json_encode_safe(mixed $value):string { return json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR); }
}
namespace Benos {
    final class NativeInstaller {
        public static function initialize(string $root,array $database,array $input):void {
            if(defined('BASE_PATH')&&BASE_PATH!==$root)throw new ProtocolError('MULTIPLE_SITE_CONTEXTS_DENIED',409);
            if(!defined('BASE_PATH'))define('BASE_PATH',$root);
            require_once $root.'/src/Services/Installer.php';require_once $root.'/src/Services/DatabaseCompatibility.php';
            foreach(['pdo_mysql','mbstring','fileinfo','dom','openssl','sodium','gd','zip','curl'] as $extension)if(!extension_loaded($extension))throw new ProtocolError('CMS_REQUIREMENTS_MISSING',503);
            if(version_compare(PHP_VERSION,'8.4','<'))throw new ProtocolError('CMS_REQUIREMENTS_MISSING',503);
            $pdo=new \PDO('mysql:host='.$database['host'].';port='.$database['port'].';dbname='.$database['name'].';charset=utf8mb4',$database['user'],$database['password'],[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION,\PDO::ATTR_EMULATE_PREPARES=>false]);
            \AACMS\Services\DatabaseCompatibility::assertSupported($pdo);
            // Deliberately do not enable restart_incomplete: unattended retries
            // must not drop any table, including an interrupted native install.
            if($pdo->query('SHOW TABLES')->fetchAll(\PDO::FETCH_COLUMN))throw new ProtocolError('DATABASE_NOT_EMPTY',409);
            \AACMS\Services\Installer::install($pdo,['admin_name'=>'网站管理员','admin_email'=>$input['cmsAdminEmail'],'admin_password'=>$input['cmsAdminPassword']],['installed'=>true,'app_url'=>'https://'.$input['domain'],'app_key'=>bin2hex(random_bytes(32)),'db_host'=>$database['host'],'db_port'=>$database['port'],'db_name'=>$database['name'],'db_user'=>$database['user'],'db_password'=>$database['password'],'environment'=>'production','version'=>trim(file_get_contents($root.'/VERSION'))]);
            $statement=$pdo->prepare('UPDATE settings SET value=? WHERE `key`=?');
            foreach(['site_name'=>$input['name'],'company_name'=>$input['name'],'site_tagline'=>'','site_description'=>'','site_indexing'=>false,'smtp_from_name'=>'Benos','admin_brand_name'=>'Benos','admin_brand_subtitle'=>'WEBSITE STUDIO'] as $key=>$value)$statement->execute([json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$key]);
        }
    }
}
