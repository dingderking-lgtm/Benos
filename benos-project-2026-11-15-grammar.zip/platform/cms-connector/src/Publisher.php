<?php
declare(strict_types=1);
namespace Benos;
use AACMS\Services\{SitePackageService,TemplatePackageService,PageService,Renderer,TemplateService,BackupService,EditorStudioService,ContentEvaluationService,AiBlogService,MediaService,FormService,BlogService,BlogAuthorService};

/** Revision switching only. Never invokes SiteKitService replace or deletes pages. */
final class Publisher {
    private function key(string $id):string {if(!preg_match('/^rel_[a-f0-9]{32}$/D',$id))throw new ProtocolError('RELEASE_INVALID');return 'benos_release_'.$id;}
    private function read(string $id):array {$row=\setting($this->key($id),null);if(!is_array($row))throw new ProtocolError('RELEASE_NOT_FOUND',404);return $row;}
    private function store(array $release):void {if(isset($release['bundleId']))unset($release['manifest'],$release['assets']);\save_setting($this->key($release['id']),$release);}
    private function digest(mixed $value):string{return hash('sha256',\json_encode_safe($value));}
    private function assertCurrentEntitlement():void {$connection=json_decode(file_get_contents(BASE_PATH.'/storage/private/benos-connection.json'),true,32,JSON_THROW_ON_ERROR);if(!Entitlement::allowed(BASE_PATH,$connection,true))throw new ProtocolError('HOSTING_ENTITLEMENT_INACTIVE',403);}
    private function templatePublications(array $ids,bool $compact=false):array {$rows=[];foreach($ids as $id){$row=\query('SELECT id,published_document_json,published_conditions_json,published_version,is_active FROM templates WHERE id=?',[$id])->fetch();$rows[]=$compact?['id'=>(int)$id,'sha256'=>$this->digest($row)]:$row;}return $rows;}
    private function publicResult(array $release):array {return array_intersect_key($release,array_flip(['id','projectId','versionId','state','reviewHash','summary','backup','errorCode']));}
    private function settingsKeys(array $manifest):array {return array_values(array_unique(array_merge(SitePackageService::BRAND_KEYS,SitePackageService::THEME_KEYS,['header_template_id','footer_template_id','home_page_id','navigation_menu_id','navigation','blog_enabled','blog_base_path','blog_title','blog_description','blog_page_size','blog_language','blog_archive_template_id','blog_single_template_id','blog_default_author_id','blog_template_author_id','benos_author_id','benos_managed_forms','benos_managed_pages','benos_project_id','benos_release_head'])));}
    private function authorActivity():array{return \query('SELECT id,is_active FROM blog_authors ORDER BY id')->fetchAll();}
    private function snapshot(array $manifest,bool $compact=false):array {
        $settings=[];foreach($this->settingsKeys($manifest) as $key)$settings[$key]=\query('SELECT value FROM settings WHERE `key`=?',[$key])->fetchColumn();
        $managed=\setting('benos_managed_pages',[]);$pages=[];
        foreach($managed as $key=>$id){$row=\query('SELECT * FROM pages WHERE id=?',[$id])->fetch();if(!$row)throw new ProtocolError('MANAGED_PAGE_MISSING',409);$pages[$key]=$compact?array_intersect_key($row,array_flip(['id','type','status','slug','published_revision_id','published_at']))+['rowSha256'=>$this->digest($row)]:$row;}
        // A newly created manual page can conflict even when managed pages are unchanged.
        $paths=\query('SELECT p.id,p.slug,p.status,p.published_revision_id,r.slug live_slug FROM pages p LEFT JOIN page_revisions r ON r.id=p.published_revision_id ORDER BY p.id')->fetchAll();
        $redirects=\query('SELECT id,source,target,status_code FROM redirects ORDER BY id')->fetchAll();
        $forms=[];foreach(\setting('benos_managed_forms',[]) as $ref=>$fid)$forms[$ref]=\query('SELECT id,status,active_version_id FROM forms WHERE id=?',[$fid])->fetch();
        return ['settings'=>$settings,'pages'=>$pages,'paths'=>$paths,'redirects'=>$redirects,'forms'=>$forms,'authors'=>$this->authorActivity()];
    }
    private function archive(array $manifest,string $suffix,array $assets=[]):string {
        $path=\storage_path('private/benos-'.$suffix.'.zip');$zip=new \ZipArchive;
        if($zip->open($path,\ZipArchive::CREATE|\ZipArchive::OVERWRITE)!==true)throw new ProtocolError('PACKAGE_WRITE_FAILED',503);
        $zip->addFromString('manifest.json',\json_encode_safe($manifest));$seen=[];
        foreach($assets as $asset){if(!is_array($asset)||!preg_match('~^assets/[0-9]{1,2}\.(?:jpe?g|png|webp|gif|svg|pdf)$~D',(string)($asset['file']??''))||isset($seen[$asset['file']]))throw new ProtocolError('ASSET_PATH_INVALID');$bytes=base64_decode((string)($asset['base64']??''),true);if($bytes===false||$bytes==='')throw new ProtocolError('ASSET_BYTES_INVALID');$zip->addFromString($asset['file'],$bytes);$seen[$asset['file']]=true;}
        if(!$zip->close())throw new ProtocolError('PACKAGE_WRITE_FAILED',503);chmod($path,0600);return $path;
    }
    private function bundles():Bundle {$connection=json_decode(file_get_contents(BASE_PATH.'/storage/private/benos-connection.json'),true,32,JSON_THROW_ON_ERROR);return new Bundle(BASE_PATH,$connection,fn()=>Entitlement::allowed(BASE_PATH,$connection,true));}
    private function bundleManifest(array $release,bool $pin=false):array {
        $package=$this->bundles()->publicationPackage($release['bundleId'],$release['projectId'],$release['versionId'],$release['id'],$pin);
        if(isset($release['bundleSha256'])&&(!hash_equals($release['bundleSha256'],$package['zipSha256'])||!hash_equals($release['manifestSha256'],$package['manifestSha256'])))throw new ProtocolError('BUNDLE_PUBLICATION_DIGEST_CHANGED',409);
        $manifest=(new SitePackageService)->inspect($package['zipPath']);AssetPolicy::manifest($manifest);
        foreach($manifest['assets'] as $asset){$path=$package['files'][$asset['file']]??null;if(!$path)throw new ProtocolError('BUNDLE_DIGEST_MISMATCH',422);AssetPolicy::bytes(file_get_contents($path),$asset['file']);}
        return [$manifest,$package];
    }
    private function bundleNativeArchive(array $manifest,array $package,string $id):string {
        $path=\storage_path('private/benos-'.$id.'-native.zip');if(is_link($path))throw new ProtocolError('PACKAGE_WRITE_FAILED',503);$zip=new \ZipArchive;
        if($zip->open($path,\ZipArchive::CREATE|\ZipArchive::OVERWRITE)!==true)throw new ProtocolError('PACKAGE_WRITE_FAILED',503);
        try{$zip->addFromString('manifest.json',\json_encode_safe($manifest));foreach($manifest['assets'] as $asset){$file=$package['files'][$asset['file']]??null;if(!$file||!$zip->addFile($file,$asset['file']))throw new ProtocolError('BUNDLE_DIGEST_MISMATCH',422);}}catch(\Throwable $error){$zip->close();if(is_file($path))unlink($path);throw $error;}
        if(!$zip->close())throw new ProtocolError('PACKAGE_WRITE_FAILED',503);chmod($path,0600);return $path;
    }
    private function releaseBundle(array $release):void {
        if(!isset($release['bundleId']))return;
        // Publication/discard is already durable. Failed cleanup must never
        // convert an acknowledged business commit into a failed publication.
        try{$bundles=$this->bundles();$bundles->unpin($release['bundleId'],$release['id']);$bundles->dispatch(['operation'=>'bundle-discard','bundleId'=>$release['bundleId']]);}catch(\Throwable){/* Remains bounded and available for explicit reconciliation/expiry. */}
    }
    public function dispatch(array $input):array {
        $operation=$input['operation']??'';$id=(string)($input['releaseId']??'');$this->key($id);
        if($operation==='status')return $this->publicResult($this->read($id));
        if($operation==='prepare')return $this->prepare($id,$input);
        if($operation==='commit')return $this->commit($id,(string)($input['reviewHash']??''));
        if($operation==='rollback')return $this->rollback($id);
        if($operation==='discard')return $this->discard($id);
        throw new ProtocolError('OPERATION_INVALID');
    }
    private function discard(string $id):array {
        $release=$this->read($id);
        if(($release['state']??'')==='failed'&&($release['errorCode']??'')==='PUBLICATION_DISCARDED'){$this->releaseBundle($release);return $this->publicResult($release);}
        if(($release['state']??'')!=='prepared')throw new ProtocolError('DISCARD_UNAVAILABLE',409);
        $this->assertCurrentEntitlement();$release['state']='failed';$release['errorCode']='PUBLICATION_DISCARDED';
        // The prepared snapshot has never imported resources or changed live data.
        // Keep the original identity/hash as an idempotent receipt, drop payload bytes.
        unset($release['manifest'],$release['assets'],$release['before']);$this->store($release);$this->releaseBundle($release);return $this->publicResult($release);
    }
    private function prepare(string $id,array $input):array {
        if(array_key_exists('bundleId',$input)){
            if(array_key_exists('manifest',$input)||array_key_exists('assets',$input))throw new ProtocolError('RELEASE_INPUT_INVALID',422);
            return $this->prepareBundle($id,$input);
        }
        $manifest=$input['manifest']??null;$project=(string)($input['projectId']??'');$version=(string)($input['versionId']??'');
        if(!is_array($manifest)||!preg_match('/^prj_[a-f0-9]{32}$/D',$project)||!preg_match('/^ver_[a-f0-9]{32}$/D',$version))throw new ProtocolError('RELEASE_INPUT_INVALID');
        AssetPolicy::manifest($manifest);
        // Native ZIP inspection checks actual transmitted bytes, hashes, MIME,
        // image decoding and reference closure; metadata alone is insufficient.
        $assets=$input['assets']??[];if(!is_array($assets)||!array_is_list($assets)||count($assets)>64)throw new ProtocolError('ASSET_BYTES_INVALID');
        foreach($assets as $asset){$bytes=base64_decode((string)($asset['base64']??''),true);if($bytes===false)throw new ProtocolError('ASSET_BYTES_INVALID');AssetPolicy::bytes($bytes,(string)($asset['file']??''));}
        $existing=\setting($this->key($id),null);$payloadHash=$this->digest([$project,$version,$manifest,$assets]);
        if(is_array($existing)){if(!hash_equals($existing['payloadHash'],$payloadHash))throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);return $this->publicResult($existing);}
        $bound=\setting('benos_project_id','');if($bound!==''&&$bound!==$project)throw new ProtocolError('SITE_PROJECT_CONFLICT',409);
        $path=$this->archive($manifest,$id.'-site',$assets);try{$clean=(new SitePackageService)->inspect($path);}finally{if(is_file($path))unlink($path);}
        $snapshot=$this->snapshot($clean);$managed=\setting('benos_managed_pages',[]);$service=new PageService;$create=0;$update=0;
        foreach($clean['site']['pages'] as $page){$target=$managed[$page['key']]??null;$service->checkSlug($page['slug'],$target?(int)$target:null);if($target){$previous=$snapshot['pages'][$page['key']];if($previous['type']!==$page['type']||$previous['status']==='archived')throw new ProtocolError('MANAGED_PAGE_CONFLICT',409);$live=$previous['published_revision_id']?\query('SELECT slug FROM page_revisions WHERE id=?',[$previous['published_revision_id']])->fetchColumn():$previous['slug'];if($live!==$page['slug'])throw new ProtocolError('PUBLISHED_PATH_CHANGE_REQUIRES_REVIEW',409);if($page['type']!=='article')$update++;}else $create++;}
        if(\query("SELECT id FROM redirects WHERE source='/'")->fetchColumn())throw new ProtocolError('HOME_REDIRECT_CONFLICT',409);
        $release=['id'=>$id,'projectId'=>$project,'versionId'=>$version,'state'=>'prepared','payloadHash'=>$payloadHash,'manifest'=>$clean,'assets'=>$assets,'before'=>$snapshot,'reviewHash'=>$this->digest([$payloadHash,$snapshot]),'summary'=>['createPages'=>$create,'updatePages'=>$update,'preserveArticles'=>(int)\query("SELECT COUNT(*) FROM pages WHERE type='article'")->fetchColumn(),'preserveDrafts'=>true,'replaceGlobalTheme'=>true,'removePages'=>0]];
        $this->store($release);return $this->publicResult($release);
    }
    private function prepareBundle(string $id,array $input):array {
        $bundle=$input['bundleId']??null;$project=$input['projectId']??null;$version=$input['versionId']??null;
        if(!is_string($bundle)||!preg_match('/^bundle_[a-f0-9]{32}$/D',$bundle)||!is_string($project)||!preg_match('/^prj_[a-f0-9]{32}$/D',$project)||!is_string($version)||!preg_match('/^ver_[a-f0-9]{32}$/D',$version))throw new ProtocolError('RELEASE_INPUT_INVALID',422);
        $existing=\setting($this->key($id),null);
        if(is_array($existing)){
            if(($existing['bundleId']??null)!==$bundle||$existing['projectId']!==$project||$existing['versionId']!==$version)throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);
            if($existing['state']!=='preparing')return $this->publicResult($existing);
        }
        $bound=\setting('benos_project_id','');if($bound!==''&&$bound!==$project)throw new ProtocolError('SITE_PROJECT_CONFLICT',409);
        $package=$this->bundles()->publicationPackage($bundle,$project,$version,$id,true);
        $payloadHash=$this->digest([$project,$version,$bundle,$package['zipSha256'],$package['manifestSha256']]);
        if(is_array($existing)&&!hash_equals($existing['payloadHash'],$payloadHash))throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);
        $release=['id'=>$id,'projectId'=>$project,'versionId'=>$version,'transportVersion'=>2,'bundleId'=>$bundle,'bundleSha256'=>$package['zipSha256'],'manifestSha256'=>$package['manifestSha256'],'state'=>'preparing','payloadHash'=>$payloadHash];
        $this->store($release); // Recoverable intent; never persist the large payload.
        try{
            [$clean]=$this->bundleManifest($release);$snapshot=$this->snapshot($clean,true);$managed=\setting('benos_managed_pages',[]);$service=new PageService;$create=0;$update=0;
            foreach($clean['site']['pages'] as $page){$target=$managed[$page['key']]??null;$service->checkSlug($page['slug'],$target?(int)$target:null);if($target){$previous=$snapshot['pages'][$page['key']];if($previous['type']!==$page['type']||$previous['status']==='archived')throw new ProtocolError('MANAGED_PAGE_CONFLICT',409);$live=$previous['published_revision_id']?\query('SELECT slug FROM page_revisions WHERE id=?',[$previous['published_revision_id']])->fetchColumn():$previous['slug'];if($live!==$page['slug'])throw new ProtocolError('PUBLISHED_PATH_CHANGE_REQUIRES_REVIEW',409);if($page['type']!=='article')$update++;}else $create++;}
            if(\query("SELECT id FROM redirects WHERE source='/'")->fetchColumn())throw new ProtocolError('HOME_REDIRECT_CONFLICT',409);
            $release['state']='prepared';$release['before']=$snapshot;$release['reviewHash']=$this->digest([$payloadHash,$snapshot]);$release['summary']=['createPages'=>$create,'updatePages'=>$update,'preserveArticles'=>(int)\query("SELECT COUNT(*) FROM pages WHERE type='article'")->fetchColumn(),'preserveDrafts'=>true,'replaceGlobalTheme'=>true,'removePages'=>0];$this->store($release);return $this->publicResult($release);
        }catch(\Throwable $error){$release['state']='failed';$release['errorCode']=$error instanceof ProtocolError?$error->errorCode:'NATIVE_PREPARATION_FAILED';$this->store($release);throw $error;}
    }
    private function commit(string $id,string $reviewHash):array {
        $release=$this->read($id);if($release['state']==='published'){$this->releaseBundle($release);return $this->publicResult($release);}
        if($release['state']!=='prepared'||!hash_equals($release['reviewHash'],$reviewHash))throw new ProtocolError('REVIEW_REQUIRED',409);
        $compact=isset($release['bundleId']);$package=null;if($compact)[$manifest,$package]=$this->bundleManifest($release);else $manifest=$release['manifest'];
        if(!hash_equals($this->digest($release['before']),$this->digest($this->snapshot($manifest,$compact))))throw new ProtocolError('SITE_CHANGED_REVIEW_REQUIRED',409);
        $backup=(new BackupService)->create(true);$backupPath=\storage_path('backups/'.$backup['filename']);chmod($backupPath,0600);
        if(!hash_equals($backup['checksum'],hash_file('sha256',$backupPath)))throw new ProtocolError('BACKUP_VERIFY_FAILED',503);
        (new BackupService)->inspect($backupPath);$release['backup']=array_intersect_key($backup,array_flip(['id','size','checksum']));
        // Import creates inactive, independent resources. A crash during import
        // leaves a visible uncertain phase; it never repeats that import blindly.
        $release['state']='importing';$this->store($release);
        $managedForms=\setting('benos_managed_forms',[]);$formMap=[];$newForms=[];
        foreach($manifest['site']['forms'] as $definition){$ref=$definition['ref'];
            if(isset($managedForms[$ref])){$form=(new FormService)->get((int)$managedForms[$ref]);if($form['status']!=='published'||!$form['active_version_id'])throw new ProtocolError('MANAGED_FORM_NOT_PUBLISHED',409);}
            else{$key='benos-'.substr(hash('sha256',$id.'|'.$ref),0,32);$form=(new FormService)->save(null,['name'=>$definition['name'],'public_key'=>$key,'definition'=>$definition['definition'],'publish'=>true]);$managedForms[$ref]=(int)$form['id'];$newForms[]=['id'=>(int)$form['id'],'activeVersionId'=>(int)$form['active_version_id']];}
            $formMap[$ref]=$form['public_key'];
        }
        $native=$manifest;$native['format']='aacms-template-package';unset($native['site']);$archive=$compact?$this->bundleNativeArchive($native,$package,$id):$this->archive($native,$id.'-native',$release['assets']??[]);
        try{$import=(new TemplatePackageService)->import($archive,$formMap);}finally{if(is_file($archive))unlink($archive);}
        $templateIds=[];foreach($native['templates'] as $index=>$template)$templateIds[(int)$template['id']]=$import['templates'][$index];
        $release['import']=$import;$release['newForms']=$newForms;$release['state']='imported';$this->store($release);
        $pdo=\db();$pdo->beginTransaction();
        try{
            $service=new PageService;$renderer=new Renderer;$managed=\setting('benos_managed_pages',[]);$afterPages=[];
            $mediaPaths=[];foreach($native['assets'] as $index=>$asset)$mediaPaths[$asset['path']]=(string)\query('SELECT path FROM media WHERE id=?',[$import['media'][$index]])->fetchColumn();
            $replaceAssets=function(mixed $value)use(&$replaceAssets,$mediaPaths):mixed{if(is_array($value)){foreach($value as &$item)$item=$replaceAssets($item);return $value;}return is_string($value)?strtr($value,$mediaPaths):$value;};
            $authorDefinition=$manifest['site']['author']??null;
            if(is_array($authorDefinition)&&!(int)\setting('benos_author_id',0)){
                if(\query('SELECT id FROM blog_authors WHERE slug=?',[$authorDefinition['slug']])->fetchColumn())throw new ProtocolError('AUTHOR_PATH_CONFLICT',409);
                $author=(new BlogAuthorService)->save(null,$replaceAssets($authorDefinition)+['is_active'=>false]);(new BlogAuthorService)->activateForTemplate($manifest['site']['slug'],(int)$author['id']);\save_setting('benos_author_id',(int)$author['id']);
            }
            foreach($manifest['site']['pages'] as $definition){
                $key=$definition['key'];$created=!isset($managed[$key]);$article=$definition['type']==='article';if($article&&!$created)continue; // Editorial content remains CMS-owned after initial seeding.
                $definition=$replaceAssets($definition);$document=\decode_json((new TemplateService)->find($templateIds[$definition['template_id']])['document_json']);$document['settings']['theme_type']='none';$document['settings']['hide_header']=false;$document['settings']['hide_footer']=false;
                $blog=$article?(new BlogService)->normalize(($definition['blog']??[])+['editor_mode'=>'article','author_profile_id'=>(int)\setting('blog_default_author_id',0),'published_at'=>gmdate('Y-m-d H:i:s')]):[];
                $pageId=$created?$service->create(['title'=>$definition['title'],'slug'=>$definition['slug'],'type'=>$definition['type'],'document'=>$document,'seo'=>$definition['seo'],'excerpt'=>$definition['excerpt'],'blog'=>$blog,'featured_image'=>$definition['featured_image']??'']):(int)$managed[$key];
                $page=$service->find($pageId);$page['title']=$definition['title'];$page['slug']=$definition['slug'];$page['excerpt']=$definition['excerpt'];$page['seo_json']=\json_encode_safe($definition['seo']);$clean=$renderer->sanitizeDocument($document);$page['draft_json']=\json_encode_safe($clean);$page['version']=(int)$page['version']+1;
                $renderer->renderDocument($clean,$page);MediaService::assertDocumentAssets(['seo'=>$definition['seo'],'fields'=>\decode_json($page['fields_json'])]);
                foreach(EditorStudioService::issues($clean,'page') as $issue)if($issue['level']==='error')throw new ProtocolError('PAGE_NATIVE_VALIDATION_FAILED',422);
                $evaluation=new ContentEvaluationService;$assessment=$evaluation->assertPublishable($page,$clean,$definition['seo'],(new AiBlogService)->assertPagePublishable($page,$clean)+['entry'=>'publish']);
                $revision=$service->revision($page);
                // Existing draft_json, title, SEO and custom fields are untouched.
                \query("UPDATE pages SET published_revision_id=?,status='published',version=version+1,published_at=COALESCE(published_at,UTC_TIMESTAMP()),updated_at=UTC_TIMESTAMP() WHERE id=?",[$revision,$pageId]);
                if($article)(new BlogService)->syncTerms($pageId,\decode_json($page['blog_json']),'published');
                $evaluation->recordAssessment($pageId,$assessment);$managed[$key]=$pageId;$afterPages[$key]=['id'=>$pageId,'revision'=>$revision,'created'=>$created];
            }
            $site=$manifest['site'];
            foreach($manifest['templates'] as $template){$tid=$templateIds[$template['id']];$row=(new TemplateService)->find($tid);$document=\decode_json($row['document_json']);$document['settings']['template_enabled']=true;$document=$renderer->sanitizeDocument($document);$renderer->renderDocument($document);$conditions=['all'=>in_array($template['type'],['header','footer'],true),'pages'=>[],'exclude_pages'=>[],'types'=>in_array($template['type'],['archive','single'],true)?['article']:[],'categories'=>[]];$active=in_array($template['type'],['header','footer','section','archive','single'],true)?1:0;
                \query('UPDATE templates SET document_json=?,published_document_json=?,conditions_json=?,published_conditions_json=?,published_version=version,is_active=? WHERE id=?',[\json_encode_safe($document),\json_encode_safe($document),\json_encode_safe($conditions),\json_encode_safe($conditions),$active,$tid]);
            }
            foreach(array_merge($site['settings'],$site['theme']) as $key=>$value)\save_setting($key,is_string($value)?strtr($value,$mediaPaths):$value);
            \save_setting('header_template_id',$templateIds[$site['header_template_id']]);\save_setting('footer_template_id',$templateIds[$site['footer_template_id']]);\save_setting('home_page_id',$managed[$site['home']]);
            foreach($native['menus'] as $index=>$menu)if($menu['id']===$site['navigation_menu_id'])\save_setting('navigation_menu_id',$import['menus'][$index]);\save_setting('navigation',[]);
            if(is_array($site['blog']??null)){foreach($site['blog'] as $key=>$value)\save_setting('blog_'.$key,in_array($key,['archive_template_id','single_template_id'],true)?$templateIds[$value]:$value);}
            \save_setting('benos_project_id',$release['projectId']);\save_setting('benos_managed_pages',$managed);\save_setting('benos_managed_forms',$managedForms);\save_setting('benos_release_head',$id);
            $release['state']='published';$release['afterPages']=$afterPages;$release['afterAuthors']=$this->authorActivity();$release['afterTemplates']=$this->templatePublications($import['templates'],$compact);$release['afterSettings']=$this->snapshot($manifest,$compact)['settings'];$this->store($release);$this->assertCurrentEntitlement();$pdo->commit();\invalidate_cache();$this->releaseBundle($release);return $this->publicResult($release);
        }catch(\Throwable $error){if($pdo->inTransaction())$pdo->rollBack();$release['state']='failed';$release['errorCode']=$error instanceof ProtocolError?$error->errorCode:'NATIVE_PUBLICATION_FAILED';$this->store($release);throw $error;}
    }
    private function rollback(string $id):array {
        $release=$this->read($id);$compact=isset($release['bundleId']);if($release['state']==='rolled_back')return $this->publicResult($release);
        if($release['state']!=='published'||\setting('benos_release_head','')!==$id)throw new ProtocolError('ROLLBACK_HEAD_CHANGED',409);
        if($this->snapshot($compact?[]:$release['manifest'],$compact)['settings']!==$release['afterSettings'])throw new ProtocolError('ROLLBACK_SETTINGS_CHANGED',409);
        if($this->templatePublications($release['import']['templates'],$compact)!==$release['afterTemplates'])throw new ProtocolError('ROLLBACK_TEMPLATE_PUBLICATION_CHANGED',409);
        if($this->authorActivity()!==$release['afterAuthors'])throw new ProtocolError('ROLLBACK_AUTHOR_SELECTION_CHANGED',409);
        foreach($release['newForms']??[] as $form){$current=(new FormService)->get($form['id']);if((int)$current['active_version_id']!==$form['activeVersionId']||$current['status']!=='published')throw new ProtocolError('ROLLBACK_FORM_PUBLICATION_CHANGED',409);}
        foreach($release['afterPages'] as $page){$current=(new PageService)->find($page['id']);if((int)$current['published_revision_id']!==$page['revision']||$current['status']!=='published')throw new ProtocolError('ROLLBACK_PUBLICATION_CHANGED',409);}
        $backup=(new BackupService)->create(true);$path=\storage_path('backups/'.$backup['filename']);chmod($path,0600);(new BackupService)->inspect($path);
        $pdo=\db();$pdo->beginTransaction();try{
            foreach($release['afterPages'] as $key=>$page){$before=$release['before']['pages'][$key]??null;\query('UPDATE pages SET published_revision_id=?,status=?,published_at=?,version=version+1,updated_at=UTC_TIMESTAMP() WHERE id=?',[$before['published_revision_id']??null,$before['status']??'draft',$before['published_at']??null,$page['id']]);}
            foreach($release['before']['settings'] as $key=>$raw){if($raw===false)\query('DELETE FROM settings WHERE `key`=?',[$key]);else \query('INSERT INTO settings (`key`,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)',[$key,$raw]);}
            foreach($release['import']['templates'] as $tid)\query('UPDATE templates SET is_active=0 WHERE id=?',[$tid]);
            foreach($release['newForms']??[] as $form)\query("UPDATE forms SET status='archived' WHERE id=?",[$form['id']]);
            $oldAuthors=array_column($release['before']['authors'],'is_active','id');foreach($release['afterAuthors'] as $author)\query('UPDATE blog_authors SET is_active=? WHERE id=?',[$oldAuthors[$author['id']]??0,$author['id']]);
            $release['state']='rolled_back';$this->store($release);$this->assertCurrentEntitlement();$pdo->commit();\invalidate_cache();return $this->publicResult($release);
        }catch(\Throwable $error){if($pdo->inTransaction())$pdo->rollBack();throw $error;}
    }
}
