<?php
declare(strict_types=1);
namespace Benos;

/** Download-only PDF policy shared by managed preview and publication. */
final class AssetPolicy {
    private static function decoded(string $value):string {
        $value=html_entity_decode($value,ENT_QUOTES|ENT_HTML5,'UTF-8');
        $value=preg_replace_callback('/\\\\([0-9a-f]{1,6})\s?|\\\\([^\r\n])/i',static fn($m)=>!empty($m[1])?mb_chr((int)hexdec($m[1]),'UTF-8'):$m[2],$value);
        return rawurldecode($value);
    }
    private static function pdf(string $value):bool {return (bool)preg_match('~data:application/pdf|\.pdf(?:[?#\s,\x22\x27)]|$)~i',self::decoded($value));}
    private static function image(string $value):void {if(self::pdf($value))throw new ProtocolError('PDF_DOWNLOAD_ONLY',422);}
    private static function css(string $value):void {
        $value=self::decoded($value);
        if(preg_match_all('/url\s*\((.*?)\)/is',$value,$matches))foreach($matches[1] as $url)self::image($url);
        if(preg_match('/@import[^;]*\.pdf(?:[?\s\x22\x27)]|$)/i',$value))throw new ProtocolError('PDF_DOWNLOAD_ONLY',422);
    }
    private static function html(string $html):void {
        $dom=new \DOMDocument;@$dom->loadHTML('<?xml encoding="UTF-8">'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);
        foreach($dom->getElementsByTagName('*') as $node){$tag=strtolower($node->nodeName);
            foreach($node->attributes as $attribute){$key=strtolower($attribute->nodeName);$value=$attribute->nodeValue;
                if($key==='style')self::css($value);
                elseif(in_array($key,['src','srcset','poster','background','data','href','xlink:href'],true)&&!($tag==='a'&&$key==='href'))self::image($value);
            }
            if($tag==='style')self::css($node->textContent);
        }
    }
    private static function document(mixed $value,string $key=''):void {
        if(is_array($value)){foreach($value as $name=>$item)self::document($item,(string)$name);return;}
        if(!is_string($value))return;$key=strtolower($key);
        if(preg_match('/url\s*\(/i',self::decoded($value)))self::css($value);
        if($key==='html')self::html($value);
        elseif(in_array($key,['css','customcss','global_css','style'],true))self::css($value);
        elseif(in_array($key,['src','srcset','poster','background','company_logo','favicon','featured_image','avatar','image','image_url','og_image','twitter_image'],true))self::image($value);
    }
    public static function manifest(array $manifest):void {
        foreach($manifest['templates']??[] as $template)self::document($template['document']??[]);
        self::document($manifest['site']??[]);
    }
    public static function bytes(string $bytes,string $file):void {
        if(strtolower(pathinfo($file,PATHINFO_EXTENSION))!=='pdf')return;
        // PDF is never executed or embedded. Reject dictionaries that cannot be
        // inspected without decrypting/expanding a complete PDF interpreter.
        if(!preg_match('/^%PDF-(?:1\.[0-7]|2\.0)[\r\n]/',$bytes)||!preg_match('/%%EOF\s*$/D',substr($bytes,-2048))||preg_match('/<\?(?:php|=)|<%[=@]/i',$bytes)||!preg_match('/\b\d+\s+\d+\s+obj\b/',$bytes)||!str_contains($bytes,'endobj')||!str_contains($bytes,'startxref'))throw new ProtocolError('PDF_UNSAFE',422);
        preg_match_all('~/([^\x00\t\n\f\r ()<>\[\]{}\/%]+)~',$bytes,$names);
        $forbidden=explode(' ','javascript js launch embeddedfile embeddedfiles richmedia openaction aa additionalactions xfa acroform submitform importdata gotor gotoe encrypt objstm');
        foreach($names[1] as $name){$name=strtolower(preg_replace_callback('/#([0-9a-f]{2})/i',static fn($m)=>chr(hexdec($m[1])),$name));if(in_array($name,$forbidden,true))throw new ProtocolError('PDF_UNSAFE',422);}
    }
}
