<?php
declare(strict_types=1);
namespace Benos;
require_once __DIR__.'/Protocol.php';
require_once __DIR__.'/Distribution.php';

/** Privileged deployment bridge. Configuration is server-owned and outside web root. */
final class Bridge {
    private string $stateRoot;private string $sitesRoot;private string $sourceRoot;private string $encryptionKey;
    public function __construct(private array $config) {
        foreach(['stateRoot','sitesRoot','sourceRoot'] as $key){$value=$config[$key]??'';if(!is_string($value)||!is_dir($value)||is_link($value)||!realpath($value))throw new ProtocolError('BRIDGE_NOT_CONFIGURED',503);$this->$key=str_replace('\\','/',realpath($value));}
        if($this->stateRoot===$this->sitesRoot||str_starts_with($this->stateRoot,$this->sourceRoot.'/')||str_starts_with($this->sitesRoot,$this->sourceRoot.'/'))throw new ProtocolError('BRIDGE_DIRECTORIES_INVALID',503);
        $this->encryptionKey=base64_decode((string)($config['encryptionKey']??''),true)?:'';
        if(strlen($this->encryptionKey)!==SODIUM_CRYPTO_SECRETBOX_KEYBYTES)throw new ProtocolError('BRIDGE_NOT_CONFIGURED',503);
    }
    public function dispatch(string $method,string $target,string $body,array $headers):array {
        $lock=fopen($this->stateRoot.'/bridge.lock','c');if(!$lock||!flock($lock,LOCK_EX))throw new ProtocolError('BRIDGE_BUSY',503);
        $identity=null;
        try{
            $nonces=$this->read('nonces');
            $identity=Protocol::verify($headers,$method,$target,$body,$this->config['keys']??[],'BENOS-BRIDGE-V1',function(string $nonce,int $expiry)use(&$nonces){
                foreach($nonces as $key=>$expires)if((int)$expires<time())unset($nonces[$key]);
                if(isset($nonces[$nonce]))throw new ProtocolError('REPLAY_DENIED',409);
                if(count($nonces)>10000)throw new ProtocolError('RATE_LIMITED',429);
                $nonces[$nonce]=$expiry;$this->write('nonces',$nonces);
            });
            $base=rtrim((string)($this->config['basePath']??'/benos-bridge/v1'),'/');
            if($method==='GET'&&$target===$base.'/capabilities'){
                if($identity['siteId']!=='platform')throw new ProtocolError('FORBIDDEN',403);
                return Protocol::response($identity,200,['protocol'=>'benos-bridge-v1','capabilities'=>array_merge(['isolated-cms-initialize','job-reconcile','signed-site-health'],!empty($this->config['hpanelAccounts'])?['hpanel-scoped-install']:[]),'cmsVersion'=>$this->sourceVersion()]);
            }
            if($method==='GET'&&preg_match('~^'.preg_quote($base,'~').'/jobs/(job_[a-f0-9]{32})$~D',$target,$match)){
                $jobs=$this->read('jobs');$job=$jobs[$match[1]]??null;
                if(!$job||$job['siteId']!==$identity['siteId'])throw new ProtocolError('NOT_FOUND',404);
                return Protocol::response($identity,200,$this->publicResult($job));
            }
            if($method!=='POST'||$target!==$base.'/jobs')throw new ProtocolError('NOT_FOUND',404);
            $input=$this->validateInput($body,$identity['siteId']);
            $receipts=$this->read('receipts');$receiptKey=hash('sha256',$identity['siteId'].'|'.$identity['idempotencyKey']);$payloadHash=hash('sha256',$body);
            if(isset($receipts[$receiptKey])){
                if(!hash_equals($receipts[$receiptKey]['payloadHash'],$payloadHash))throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);
                $job=$this->read('jobs')[$receipts[$receiptKey]['jobId']]??null;
                if(!$job)throw new ProtocolError('JOB_RECOVERY_REQUIRED',409);
                return Protocol::response($identity,200,$this->publicResult($job));
            }
            $jobs=$this->read('jobs');$job=$jobs[$input['jobId']]??null;
            $stableHash=hash('sha256',json_encode([$input['siteId'],$input['name'],$input['domain'],$input['cmsAdminEmail'],$input['deployment']??null,isset($input['database'])?[$input['database']['accountUsername'],$input['database']['name'],$input['database']['user']]:null],JSON_THROW_ON_ERROR));
            if($job&&(!hash_equals($job['identityHash'],$stableHash)||$job['siteId']!==$identity['siteId']))throw new ProtocolError('JOB_IDENTITY_CONFLICT',409);
            foreach($jobs as $other)if($other['jobId']!==$input['jobId']&&($other['domain']===$input['domain']||$other['siteId']===$input['siteId']))throw new ProtocolError('SITE_ALREADY_CLAIMED',409);
            if(!$job)$job=['jobId'=>$input['jobId'],'siteId'=>$input['siteId'],'domain'=>$input['domain'],'identityHash'=>$stableHash,'state'=>'awaiting_input','step'=>'prepare_target','cmsInstalled'=>false,'createdAt'=>gmdate('c')];
            $jobs[$job['jobId']]=$job;$this->write('jobs',$jobs);
            $receipts[$receiptKey]=['payloadHash'=>$payloadHash,'jobId'=>$job['jobId'],'createdAt'=>gmdate('c')];$this->write('receipts',$receipts);
            // Password exists only in request memory, never in receipts, jobs or logs.
            if(!$job['cmsInstalled']){
                try{$job=$this->initialize($job,$input);}
                catch(ProtocolError $error){$job['state']='awaiting_input';$job['step']='operator_action';$job['errorCode']=$error->errorCode;}
                catch(\Throwable $error){$job['state']='awaiting_input';$job['step']='reconcile_installation';$job['errorCode']='INSTALLATION_REVIEW_REQUIRED';error_log('Benos install failed ['.get_class($error).']');}
                unset($input['cmsAdminPassword']);$jobs=$this->read('jobs');$jobs[$job['jobId']]=$job;$this->write('jobs',$jobs);
            }
            return Protocol::response($identity,202,$this->publicResult($job));
        }catch(ProtocolError $error){if($identity)return Protocol::response($identity,$error->status,['error'=>['code'=>$error->errorCode]]);throw $error;}
        finally{flock($lock,LOCK_UN);fclose($lock);}
    }
    private function validateInput(string $body,string $siteId):array {
        try{$input=json_decode($body,true,32,JSON_THROW_ON_ERROR);}catch(\JsonException){throw new ProtocolError('INVALID_JSON');}
        $allowed=['schemaVersion','jobId','siteId','name','domain','cmsAdminEmail','cmsAdminPassword','passwordExpiresAt','deployment','database'];
        if(!is_array($input)||array_diff(array_keys($input),$allowed)||($input['schemaVersion']??null)!==1||!preg_match('/^job_[a-f0-9]{32}$/D',(string)($input['jobId']??''))||($input['siteId']??null)!==$siteId||!preg_match('/^site_[a-f0-9]{32}$/D',$siteId))throw new ProtocolError('INPUT_INVALID');
        foreach(['name','domain','cmsAdminEmail','cmsAdminPassword','passwordExpiresAt'] as $key)if(!is_string($input[$key]??null))throw new ProtocolError('INPUT_INVALID');
        if(trim($input['name'])===''||mb_strlen($input['name'])>120||preg_match('/[\x00-\x1f\x7f]/',$input['name']))throw new ProtocolError('INPUT_INVALID');
        $domain=$input['domain'];
        if(strlen($domain)>253||!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{1,62}$/D',$domain)||preg_match('/\.(?:localhost|local|internal|test|invalid)$/D',$domain))throw new ProtocolError('DOMAIN_INVALID');
        if(!filter_var($input['cmsAdminEmail'],FILTER_VALIDATE_EMAIL)||strlen($input['cmsAdminEmail'])>190||strlen($input['cmsAdminPassword'])<12||strlen($input['cmsAdminPassword'])>1024)throw new ProtocolError('INPUT_INVALID');
        $expires=strtotime($input['passwordExpiresAt']);if(!$expires||$expires<time()||$expires>time()+901)throw new ProtocolError('PASSWORD_EXPIRED',409);
        if(isset($input['deployment'])||isset($input['database'])){
            $deployment=$input['deployment']??null;$db=$input['database']??null;
            if(!is_array($deployment)||!is_array($db)||array_diff(array_keys($deployment),['mode','accountUsername','rootDirectory'])||array_diff(array_keys($db),['accountUsername','name','user','password'])||($deployment['mode']??null)!=='hostinger-hpanel'||!preg_match('/^u[0-9]{3,20}$/D',(string)($deployment['accountUsername']??''))||($db['accountUsername']??null)!==$deployment['accountUsername'])throw new ProtocolError('HPANEL_INPUT_INVALID');
            foreach(['name','user'] as $key)if(!is_string($db[$key]??null)||!str_starts_with($db[$key],$deployment['accountUsername'].'_')||!preg_match('/^[a-zA-Z0-9_]{1,32}$/D',$db[$key]))throw new ProtocolError('HPANEL_DATABASE_SCOPE_INVALID');
            if(!is_string($db['password']??null)||strlen($db['password'])<24||strlen($db['password'])>256||!is_string($deployment['rootDirectory']??null))throw new ProtocolError('HPANEL_INPUT_INVALID');
        }
        return $input;
    }
    private function sourceVersion():string {
        $version=is_file($this->sourceRoot.'/VERSION')?trim(file_get_contents($this->sourceRoot.'/VERSION')):'';
        if($version!=='1.9.21')throw new ProtocolError('CMS_BASELINE_UNSUPPORTED',503);return $version;
    }
    private function initialize(array &$job,array $input):array {
        $this->sourceVersion();
        $root=isset($input['deployment'])?$this->hpanelRoot($input):$this->sitesRoot.'/'.$job['siteId'];
        if($this->linkedPath($root))throw new ProtocolError('TARGET_SYMLINK_DENIED',409);
        if(!is_dir($root)){if(!mkdir($root,0750))throw new ProtocolError('TARGET_UNAVAILABLE',503);$this->atomic($root.'/.benos-owner.json',['siteId'=>$job['siteId'],'jobId'=>$job['jobId'],'domain'=>$job['domain']]);}
        elseif(isset($input['deployment'])&&!is_file($root.'/.benos-owner.json')){
            if(array_diff(scandir($root),['.','..']))throw new ProtocolError('TARGET_NOT_EMPTY',409);
            $this->atomic($root.'/.benos-owner.json',['siteId'=>$job['siteId'],'jobId'=>$job['jobId'],'domain'=>$job['domain']]);
        }
        $owner=is_file($root.'/.benos-owner.json')?json_decode(file_get_contents($root.'/.benos-owner.json'),true):null;
        if(!is_array($owner)||$owner['siteId']!==$job['siteId']||$owner['jobId']!==$job['jobId']||$owner['domain']!==$job['domain'])throw new ProtocolError('TARGET_NOT_OWNED',409);
        if(!isset($job['database'])){$database=$this->database($job,$input);$job['database']=$this->seal(json_encode($database,JSON_THROW_ON_ERROR));$this->persistJob($job);}
        $database=json_decode($this->unseal($job['database']),true,32,JSON_THROW_ON_ERROR);
        if(!isset($job['connectionSecret'])){$job['connectionSecret']=$this->seal(Protocol::base64url(random_bytes(32)));$this->persistJob($job);}
        $configFile=$root.'/config/local.php';
        if(is_file($configFile)){
            if(is_link($configFile))throw new ProtocolError('TARGET_SYMLINK_DENIED',409);
            $installed=require $configFile;
            if(!is_array($installed)||empty($installed['installed'])||($installed['db_name']??'')!==$database['name']||($installed['db_user']??'')!==$database['user']||($installed['app_url']??'')!=='https://'.$job['domain'])throw new ProtocolError('EXISTING_INSTALLATION_CONFLICT',409);
            // Never reapply defaults or reset an administrator on a lost response.
        }else{
            if(!isset($input['deployment'])&&!empty($this->config['database']['mode'])&&$this->config['database']['mode']==='managed')$this->createManagedDatabase($job,$database);
            foreach(['src','database','resources','routes','views','vendor','public','scripts'] as $directory)$this->copyTree($this->sourceRoot.'/'.$directory,$root.'/'.$directory,$directory);
            foreach(Distribution::additionalFiles() as $relative=>$bytes)$this->copyAdditionalFile($root,$relative,$bytes);
            foreach(['VERSION','.htaccess'] as $file){if(is_file($this->sourceRoot.'/'.$file))copy($this->sourceRoot.'/'.$file,$root.'/'.$file);}
            if(!is_dir($root.'/config'))mkdir($root.'/config',0750,true);
            if(is_file($this->sourceRoot.'/config/update-public.key'))copy($this->sourceRoot.'/config/update-public.key',$root.'/config/update-public.key');
            require_once __DIR__.'/NativeInstaller.php';NativeInstaller::initialize($root,$database,$input);
        }
        $private=$root.'/storage/private';if(!is_dir($private))mkdir($private,0750,true);
        $keyId='site_'.substr($job['siteId'],5,24);$secret=$this->unseal($job['connectionSecret']);
        $configuration=['siteId'=>$job['siteId'],'keyId'=>$keyId,'signingSecret'=>$secret,'cmsVersion'=>'1.9.21','testMode'=>!empty($this->config['testMode'])];
        $this->atomic($private.'/benos-connection.json',$configuration);
        copy(__DIR__.'/Protocol.php',$private.'/BenosProtocol.php');
        copy(__DIR__.'/Publisher.php',$private.'/BenosPublisher.php');
        copy(__DIR__.'/Entitlement.php',$private.'/BenosEntitlement.php');
        copy(__DIR__.'/NativeInstaller.php',$private.'/BenosNativeInstaller.php');
        copy(__DIR__.'/ManagedRestore.php',$private.'/BenosManagedRestore.php');
        copy(__DIR__.'/Management.php',$private.'/BenosManagement.php');
        copy(__DIR__.'/Preview.php',$private.'/BenosPreview.php');
        copy(__DIR__.'/PreviewBundle.php',$private.'/BenosPreviewBundle.php');
        copy(__DIR__.'/AssetPolicy.php',$private.'/BenosAssetPolicy.php');
        copy(__DIR__.'/Bundle.php',$private.'/BenosBundle.php');
        copy(dirname(__DIR__).'/site-health.php',$root.'/public/benos-health.php');
        copy(dirname(__DIR__).'/site-connect.php',$root.'/public/benos-connect.php');
        copy(dirname(__DIR__).'/site-bundle.php',$root.'/public/benos-bundle.php');
        $this->connectorRouting($root);
        $bootstrap=$root.'/src/bootstrap.php';$text=file_get_contents($bootstrap);
        if(!str_contains($text,'Benos entitlement lease gate')){
            $gate="// Benos entitlement lease gate\nrequire_once dirname(__DIR__).'/storage/private/BenosEntitlement.php';\n\\Benos\\Entitlement::guard(dirname(__DIR__));\n";
            $text=str_replace("declare(strict_types=1);","declare(strict_types=1);\n".$gate,$text);if(file_put_contents($bootstrap,$text,LOCK_EX)===false)throw new ProtocolError('ENTITLEMENT_INSTALL_FAILED',503);
        }
        $job['cmsInstalled']=true;$job['state']='awaiting_input';$job['step']='verify_domain_https';$job['errorCode']='DOMAIN_HTTPS_REQUIRED';$job['cmsVersion']='1.9.21';$job['keyId']=$keyId;
        return $job;
    }
    private function connectorRouting(string $root):void {
        // AACMS intentionally blocks every public PHP file except index.php.
        // Add only the exact authenticated connector entry points; do not
        // weaken the upload, config, storage, or arbitrary-PHP restrictions.
        foreach(['/.htaccess'=>"RewriteRule ^benos-(health|connect|bundle)\\.php$ public/benos-$1.php [L]\nRewriteRule ^public/benos-(health|connect|bundle)\\.php$ - [L]",'/public/.htaccess'=>"RewriteRule ^benos-(health|connect|bundle)\\.php$ - [L]"] as $file=>$rules){
            $path=$root.$file;if(!is_file($path)||is_link($path))throw new ProtocolError('CMS_ROUTING_CONFIGURATION_REQUIRED',503);
            $text=file_get_contents($path);if(str_contains($text,'# Benos authenticated connector routes'))continue;
            if(!str_contains($text,'RewriteEngine On'))throw new ProtocolError('CMS_ROUTING_CONFIGURATION_REQUIRED',503);
            // Apache's $1 belongs to mod_rewrite, not PHP replacement syntax.
            $updated=preg_replace_callback('/RewriteEngine On/',fn()=>"RewriteEngine On\n# Benos authenticated connector routes\n".$rules,$text,1);
            if(file_put_contents($path,$updated,LOCK_EX)===false)throw new ProtocolError('CMS_ROUTING_CONFIGURATION_REQUIRED',503);
        }
    }
    private function hpanelRoot(array $input):string {
        $deployment=$input['deployment'];$account=$this->config['hpanelAccounts'][$deployment['accountUsername']]??null;
        if(!is_array($account)||!is_string($account['domainsRoot']??null)||is_link($account['domainsRoot'])||!realpath($account['domainsRoot']))throw new ProtocolError('HPANEL_ACCOUNT_NOT_REGISTERED',409);
        $base=str_replace('\\','/',realpath($account['domainsRoot']));$expected=$base.'/'.$input['domain'].'/public_html';
        $root=str_replace('\\','/',$deployment['rootDirectory']);
        // The caller cannot widen the account registry. Do not infer another
        // account's prefix, follow symlinks, or adopt existing website files.
        if($root!==$expected||!is_dir(dirname($root))||is_link(dirname($root))||str_replace('\\','/',realpath(dirname($root)))!==$base.'/'.$input['domain'])throw new ProtocolError('HPANEL_DIRECTORY_SCOPE_INVALID',409);
        return $root;
    }
    private function database(array $job,array $input):array {
        $settings=$this->config['database']??[];$mode=$settings['mode']??'preallocated';
        if(isset($input['deployment'])){
            $account=$this->config['hpanelAccounts'][$input['deployment']['accountUsername']]??null;
            if(!is_array($account))throw new ProtocolError('HPANEL_ACCOUNT_NOT_REGISTERED',409);
            $database=['host'=>$account['databaseHost']??'localhost','port'=>$account['databasePort']??3306,'name'=>$input['database']['name'],'user'=>$input['database']['user'],'password'=>$input['database']['password']];
        }elseif($mode==='preallocated'){
            $database=$settings['slots'][$job['domain']]??null;if(!is_array($database))throw new ProtocolError('TARGET_DATABASE_REQUIRED',409);
        }elseif($mode==='managed'){
            $prefix=(string)($settings['prefix']??'benos');if(!preg_match('/^[a-z][a-z0-9_]{0,8}$/D',$prefix))throw new ProtocolError('DATABASE_CONFIGURATION_INVALID',503);
            $suffix=substr(hash('sha256',$job['siteId']),0,20);
            $database=['host'=>$settings['host']??'127.0.0.1','port'=>$settings['port']??3306,'name'=>$prefix.'_'.$suffix,'user'=>$prefix.'_'.$suffix,'password'=>Protocol::base64url(random_bytes(32))];
        }else throw new ProtocolError('DATABASE_CONFIGURATION_INVALID',503);
        foreach(['name','user'] as $key)if(!preg_match('/^[a-zA-Z0-9_]{1,64}$/D',(string)($database[$key]??'')))throw new ProtocolError('DATABASE_CONFIGURATION_INVALID',503);
        if(!is_string($database['host']??null)||str_contains($database['host'],';')||!filter_var($database['port']??null,FILTER_VALIDATE_INT)||$database['port']<1||$database['port']>65535||!is_string($database['password']??null)||strlen($database['password'])<12)throw new ProtocolError('DATABASE_CONFIGURATION_INVALID',503);
        foreach($this->read('jobs') as $other)if($other['siteId']!==$job['siteId']&&isset($other['database'])){
            $otherDb=json_decode($this->unseal($other['database']),true,32,JSON_THROW_ON_ERROR);
            if($otherDb['host']===$database['host']&&(int)$otherDb['port']===(int)$database['port']&&($otherDb['name']===$database['name']||$otherDb['user']===$database['user']))throw new ProtocolError('DATABASE_ALREADY_CLAIMED',409);
        }
        return $database;
    }
    private function createManagedDatabase(array &$job,array $database):void {
        $settings=$this->config['database'];$host=$database['host'];$port=$database['port'];$account=(string)($settings['provisionerUser']??'');$password=(string)($settings['provisionerPassword']??'');
        if($account===''||($password===''&&empty($this->config['testMode'])))throw new ProtocolError('DATABASE_PROVISIONER_REQUIRED',503);
        $pdo=new \PDO("mysql:host=$host;port=$port;charset=utf8mb4",$account,$password,[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION]);
        $userHost=(string)($settings['userHost']??'localhost');if(!preg_match('/^[A-Za-z0-9.:%_-]{1,80}$/D',$userHost))throw new ProtocolError('DATABASE_CONFIGURATION_INVALID',503);
        if(empty($job['databaseAttempted'])){
            $check=$pdo->prepare('SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME=?');$check->execute([$database['name']]);
            $user=$pdo->prepare('SELECT User FROM mysql.user WHERE User=?');$user->execute([$database['user']]);
            if($check->fetchColumn()||$user->fetchColumn())throw new ProtocolError('DATABASE_NOT_OWNED',409);
            $job['databaseAttempted']=true;$this->persistJob($job);
            $pdo->exec('CREATE DATABASE `'.$database['name'].'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
            $pdo->exec('CREATE USER '.$pdo->quote($database['user']).'@'.$pdo->quote($userHost).' IDENTIFIED BY '.$pdo->quote($database['password']));
            $pdo->exec('GRANT ALL PRIVILEGES ON `'.$database['name'].'`.* TO '.$pdo->quote($database['user']).'@'.$pdo->quote($userHost));
        }
        // For an uncertain prior CREATE, authenticate the exact persisted identity.
        // Do not repeat CREATE, rotate a password, DROP a database, or expand grants.
        try{new \PDO("mysql:host=$host;port=$port;dbname=".$database['name'].';charset=utf8mb4',$database['user'],$database['password'],[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION]);}
        catch(\PDOException){throw new ProtocolError('DATABASE_CREATE_RECONCILIATION_REQUIRED',409);}
    }
    private function linkedPath(string $path):bool {
        if(is_link($path))return true;
        if(PHP_OS_FAMILY!=='Windows'||($destination=@readlink($path))===false)return false;
        // Windows PHP can return a normal directory's own path from readlink.
        // Compare lexical absolute paths; realpath would follow the junction.
        $normalize=static fn(string $value)=>strtolower(rtrim(str_replace('\\','/',$value),'/'));
        return $normalize($destination)!==$normalize($path);
    }
    private function copyAdditionalFile(string $root,string $relative,string $bytes):void {
        if($this->linkedPath($root))throw new ProtocolError('TARGET_SYMLINK_DENIED',409);
        if(!preg_match('~^(?:src|routes|views|public)/[A-Za-z0-9_./-]+$~D',$relative)||str_contains($relative,'..'))throw new ProtocolError('SOURCE_OVERLAY_CONFLICT',503);
        $parent=$root;
        foreach(explode('/',dirname($relative)) as $segment){
            $parent.='/'.$segment;if($this->linkedPath($parent))throw new ProtocolError('TARGET_SYMLINK_DENIED',409);
            if(!is_dir($parent)&&!mkdir($parent,0750))throw new ProtocolError('SOURCE_COPY_FAILED',503);
        }
        $target=$root.'/'.$relative;if($this->linkedPath($target))throw new ProtocolError('TARGET_SYMLINK_DENIED',409);
        if(file_exists($target)){
            if(!is_file($target)||!hash_equals(hash('sha256',$bytes),hash_file('sha256',$target)))throw new ProtocolError('SOURCE_OVERLAY_CONFLICT',503);
            return; // Replaying our interrupted installation must accept the identical completed file.
        }
        $temporary=tempnam($parent,'.benos-product-');if($temporary===false)throw new ProtocolError('SOURCE_COPY_FAILED',503);
        try{if(file_put_contents($temporary,$bytes,LOCK_EX)!==strlen($bytes)||!rename($temporary,$target))throw new ProtocolError('SOURCE_COPY_FAILED',503);}
        finally{if(is_file($temporary))unlink($temporary);}
    }
    private function copyTree(string $source,string $target,string $relative):void {
        if(is_link($source)||is_link($target))throw new ProtocolError('TARGET_SYMLINK_DENIED',409);
        if(!is_dir($source))throw new ProtocolError('CMS_DISTRIBUTION_INCOMPLETE',503);
        if(!is_dir($target)&&!mkdir($target,0750,true))throw new ProtocolError('TARGET_UNAVAILABLE',503);
        foreach(new \DirectoryIterator($source) as $entry){
            if($entry->isDot())continue;$name=$entry->getFilename();$path=$relative.'/'.$name;
            if($path==='public/uploads'||$name==='.env'||$name==='.git'||$name==='local.php')continue;
            if($entry->isLink()||is_link($target.'/'.$name))throw new ProtocolError('TARGET_SYMLINK_DENIED',409);
            if($entry->isDir())$this->copyTree($entry->getPathname(),$target.'/'.$name,$path);
            elseif(file_put_contents($target.'/'.$name,Distribution::transform($path,file_get_contents($entry->getPathname())))===false)throw new ProtocolError('CMS_COPY_FAILED',503);
        }
    }
    private function publicResult(array $job):array {
        $result=array_intersect_key($job,array_flip(['jobId','siteId','state','step','cmsInstalled','errorCode','cmsVersion']));
        if(!empty($job['cmsInstalled']))$result['connection']=['origin'=>'https://'.$job['domain'],'keyId'=>$job['keyId'],'healthPath'=>'/benos-health.php','signingSecret'=>$this->unseal($job['connectionSecret'])];
        return $result;
    }
    private function persistJob(array $job):void {$jobs=$this->read('jobs');$jobs[$job['jobId']]=$job;$this->write('jobs',$jobs);}
    private function seal(string $plain):string {$nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);return base64_encode($nonce.sodium_crypto_secretbox($plain,$nonce,$this->encryptionKey));}
    private function unseal(string $cipher):string {$bytes=base64_decode($cipher,true);if(!$bytes)throw new ProtocolError('PRIVATE_STATE_INVALID',503);$plain=sodium_crypto_secretbox_open(substr($bytes,24),substr($bytes,0,24),$this->encryptionKey);if($plain===false)throw new ProtocolError('PRIVATE_STATE_INVALID',503);return $plain;}
    private function read(string $name):array {$path=$this->stateRoot.'/'.$name.'.json';if(is_link($path))throw new ProtocolError('PRIVATE_STATE_INVALID',503);if(!is_file($path))return [];return json_decode(file_get_contents($path),true,64,JSON_THROW_ON_ERROR);}
    private function write(string $name,array $value):void {$this->atomic($this->stateRoot.'/'.$name.'.json',$value);}
    private function atomic(string $path,array $value):void {Protocol::writePrivateJson($path,$value,'PRIVATE_STATE_WRITE_FAILED');}
}
