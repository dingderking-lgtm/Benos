<?php
declare(strict_types=1);
namespace Benos;

/** Transport staging only. Sealed does not mean native-inspected or published. */
final class Bundle {
    public const CHUNK=1048576;
    private const MAX_ZIP=74*1048576;
    private const MAX_RESERVED=256*1048576;
    private const MAX_ACTIVE=4;
    private string $base;
    public function __construct(private string $root,private array $connection,private $publishAllowed,private ?int $clock=null){
        foreach([$root,$root.'/storage',$root.'/storage/private'] as $path)if(!is_dir($path)||is_link($path))throw new ProtocolError('BUNDLE_STORAGE_UNSAFE',503);
        $this->base=$root.'/storage/private/benos-bundles';
        if(!is_dir($this->base)&&!mkdir($this->base,0700))throw new ProtocolError('BUNDLE_STORAGE_UNAVAILABLE',503);
        if(is_link($this->base))throw new ProtocolError('BUNDLE_STORAGE_UNSAFE',503);
    }
    private function now():int {return $this->clock??time();}
    private function identifier(string $id):void {if(!preg_match('/^bundle_[a-f0-9]{32}$/D',$id))throw new ProtocolError('BUNDLE_ID_INVALID',422);}
    private function dir(string $id):string {$this->identifier($id);$path=$this->base.'/'.$id;if(is_link($path))throw new ProtocolError('BUNDLE_STORAGE_UNSAFE',503);return $path;}
    private function path(string $id,string $name):string {$path=$this->dir($id).'/'.$name;if(is_link($path))throw new ProtocolError('BUNDLE_STORAGE_UNSAFE',503);return $path;}
    private function locked(callable $action):mixed {
        $path=$this->base.'/lock';if(is_link($path))throw new ProtocolError('BUNDLE_STORAGE_UNSAFE',503);$handle=fopen($path,'c');
        if(!$handle||!flock($handle,LOCK_EX|LOCK_NB)){if(is_resource($handle))fclose($handle);throw new ProtocolError('BUNDLE_BUSY',503);}
        try{return $action();}finally{flock($handle,LOCK_UN);fclose($handle);}
    }
    private function read(string $id):array {
        $file=$this->path($id,'state.json');if(!is_file($file))throw new ProtocolError('BUNDLE_NOT_FOUND',404);
        if(filesize($file)>65536)throw new ProtocolError('BUNDLE_STATE_INVALID',503);
        $state=json_decode(file_get_contents($file),true,32,JSON_THROW_ON_ERROR);
        if(!is_array($state)||($state['bundleId']??null)!==$id||($state['siteId']??null)!==$this->connection['siteId'])throw new ProtocolError('BUNDLE_IDENTITY_MISMATCH',403);
        return $state;
    }
    private function store(array $state):void {Protocol::writePrivateJson($this->path($state['bundleId'],'state.json'),$state,'BUNDLE_STATE_UNAVAILABLE');}
    private function openFile(string $path,string $mode){if(is_link($path))throw new ProtocolError('BUNDLE_STORAGE_UNSAFE',503);$handle=fopen($path,$mode);if(!$handle)throw new ProtocolError('BUNDLE_STORAGE_UNAVAILABLE',503);return $handle;}
    private function durable($handle):void {if(!fflush($handle)||(function_exists('fsync')&&!fsync($handle)))throw new ProtocolError('BUNDLE_WRITE_UNCERTAIN',503);}
    private function writeAll($handle,string $bytes):void {$at=0;while($at<strlen($bytes)){$n=fwrite($handle,substr($bytes,$at));if($n===false||$n===0)throw new ProtocolError('BUNDLE_WRITE_UNCERTAIN',503);$at+=$n;}}
    private function digestRange(string $path,int $offset,int $size):string {
        $handle=$this->openFile($path,'rb');try{if(fseek($handle,$offset)!==0)throw new ProtocolError('BUNDLE_FILE_INVALID',503);$hash=hash_init('sha256');$left=$size;while($left){$bytes=fread($handle,min(65536,$left));if($bytes===false||$bytes==='')throw new ProtocolError('BUNDLE_FILE_INVALID',503);hash_update($hash,$bytes);$left-=strlen($bytes);}return hash_final($hash);}finally{fclose($handle);}
    }
    /** Recover a persisted write intent after either data or state acknowledgement was lost. */
    private function recover(array &$state):void {
        if($state['state']!=='receiving')return;
        $changed=false;
        foreach($state['files'] as $index=>&$file){$intent=$file['pending']??null;if(!$intent)continue;$path=$this->path($state['bundleId'],'file-'.$index);clearstatcache(true,$path);$size=is_file($path)?filesize($path):0;$end=$intent['offset']+$intent['size'];
            if($size<$intent['offset']||$size>$end)throw new ProtocolError('BUNDLE_FILE_INVALID',503);
            if($size===$end&&hash_equals($intent['sha256'],$this->digestRange($path,$intent['offset'],$intent['size']))){$file['received']=$end;unset($file['pending']);$changed=true;}
            elseif($size>$intent['offset']){$handle=$this->openFile($path,'c+b');try{if(!ftruncate($handle,$intent['offset']))throw new ProtocolError('BUNDLE_WRITE_UNCERTAIN',503);$this->durable($handle);}finally{fclose($handle);}}
        }unset($file);if($changed)$this->store($state);
    }
    private function removePayload(array $state):void {
        foreach(array_keys($state['files']) as $index){$path=$this->path($state['bundleId'],'file-'.$index);if(is_file($path)&&!unlink($path))throw new ProtocolError('BUNDLE_CLEANUP_UNCERTAIN',503);}
        foreach(['package.zip','package.tmp'] as $name){$path=$this->path($state['bundleId'],$name);if(is_file($path)&&!unlink($path))throw new ProtocolError('BUNDLE_CLEANUP_UNCERTAIN',503);}
    }
    private function sweep():array {
        $active=0;$reserved=0;$count=0;
        foreach(scandir($this->base)?:[] as $id){if(!preg_match('/^bundle_[a-f0-9]{32}$/D',$id))continue;$count++;if(!is_file($this->path($id,'state.json')))continue;$state=$this->read($id);
            $changed=false;foreach($state['previewPins']??[] as $reference=>$until)if($until<=$this->now()){$state['pins']=array_values(array_diff($state['pins'],[$reference]));unset($state['previewPins'][$reference]);$changed=true;}if($changed)$this->store($state);
            if($state['expiresAt']<=$this->now()&&empty($state['pins'])&&!in_array($state['state'],['discarded','expired'],true)){$state['state']='expired';$state['closedAt']=$this->now();$this->store($state);}
            if(in_array($state['state'],['discarded','expired'],true)){$this->removePayload($state);if(($state['closedAt']??$state['expiresAt'])+7*86400<=$this->now()){$file=$this->path($id,'state.json');if(!unlink($file)||!rmdir($this->dir($id)))throw new ProtocolError('BUNDLE_CLEANUP_UNCERTAIN',503);$count--;}continue;}
            $active++;$reserved+=$state['reservedBytes'];
        }
        return [$active,$reserved,$count];
    }
    private function view(array $state):array {return ['protocol'=>'benos-bundle-v2','bundleId'=>$state['bundleId'],'siteId'=>$state['siteId'],'purpose'=>$state['purpose'],'projectId'=>$state['projectId'],'versionId'=>$state['versionId'],'state'=>$state['state'],'expiresAt'=>$state['expiresAt'],'expired'=>$state['expiresAt']<=$this->now(),'pinned'=>!empty($state['pins']),'chunkBytes'=>self::CHUNK,'zipBytes'=>$state['zipBytes'],'zipSha256'=>$state['zipSha256']??null,'nativeValidated'=>false,'files'=>array_map(static fn($file)=>array_intersect_key($file,array_flip(['file','size','sha256','received'])),$state['files'])];}
    private function metadata(array $input):array {
        $id=(string)($input['bundleId']??'');$this->identifier($id);$purpose=$input['purpose']??null;$project=$input['projectId']??null;$version=$input['versionId']??null;$expires=$input['expiresAt']??null;
        if(($input['schemaVersion']??null)!==2||!in_array($purpose,['preview','publish'],true)||!is_string($project)||!preg_match('/^prj_[a-f0-9]{32}$/D',$project)||!is_string($version)||!preg_match($purpose==='publish'?'/^ver_[a-f0-9]{32}$/D':'/^(?:ver|candidate)_[a-f0-9]{32}$/D',$version)||!is_int($expires)||$expires<=$this->now()||$expires>$this->now()+86400)throw new ProtocolError('BUNDLE_INPUT_INVALID',422);
        $manifest=$input['manifest']??null;$assets=$input['assets']??null;
        if(!is_array($manifest)||($manifest['file']??null)!=='manifest.json'||!is_array($assets)||!array_is_list($assets)||count($assets)>64)throw new ProtocolError('BUNDLE_INPUT_INVALID',422);
        usort($assets,static fn($a,$b)=>strcmp((string)($a['file']??''),(string)($b['file']??'')));$files=[];$seen=[];$total=0;$media=0;$zip=22;
        foreach([$manifest,...$assets] as $index=>$item){if(!is_array($item))throw new ProtocolError('BUNDLE_FILE_METADATA_INVALID',422);$name=$item['file']??null;$size=$item['size']??null;$sha=$item['sha256']??null;
            if(!is_string($name)||($index===0?$name!=='manifest.json':!preg_match('~^assets/[0-9]{1,2}\.(?:jpe?g|png|webp|gif|svg|pdf)$~D',$name))||isset($seen[$name])||!is_int($size)||$size<1||$size>($index===0?10:(str_ends_with($name,'.svg')?1:12))*1048576||!is_string($sha)||!preg_match('/^[a-f0-9]{64}$/D',$sha))throw new ProtocolError('BUNDLE_FILE_METADATA_INVALID',422);
            $seen[$name]=true;$total+=$size;if($index>0)$media+=$size;$zip+=$size+30+46+2*strlen($name);$files[]=['file'=>$name,'size'=>$size,'sha256'=>$sha,'received'=>0];
        }
        if($media>64*1048576||$total>self::MAX_ZIP||$zip>self::MAX_ZIP)throw new ProtocolError('BUNDLE_TOO_LARGE',413);
        return ['schemaVersion'=>2,'bundleId'=>$id,'siteId'=>$this->connection['siteId'],'purpose'=>$purpose,'projectId'=>$project,'versionId'=>$version,'expiresAt'=>$expires,'zipBytes'=>$zip,'reservedBytes'=>2*$zip,'files'=>$files];
    }
    public function dispatch(array $input,?string $bytes=null):array {return $this->locked(function()use($input,$bytes){
        [$active,$reserved,$count]=$this->sweep();$operation=$input['operation']??'';$id=(string)($input['bundleId']??'');$this->identifier($id);
        if($operation==='bundle-begin'){$metadata=$this->metadata($input);$digest=hash('sha256',json_encode($metadata,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));
            if(is_file($this->path($id,'state.json'))){$state=$this->read($id);if(!hash_equals($state['metadataSha256'],$digest))throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);$this->recover($state);return $this->view($state);}
            if($metadata['purpose']==='publish'&&!($this->publishAllowed)())throw new ProtocolError('HOSTING_ENTITLEMENT_INACTIVE',403);
            if($active>=self::MAX_ACTIVE||$reserved+$metadata['reservedBytes']>self::MAX_RESERVED||$count>=1024)throw new ProtocolError('BUNDLE_QUOTA_EXCEEDED',429);
            $dir=$this->dir($id);if(!is_dir($dir)&&!mkdir($dir,0700))throw new ProtocolError('BUNDLE_STORAGE_UNAVAILABLE',503);
            $state=$metadata+['metadataSha256'=>$digest,'state'=>'receiving','createdAt'=>$this->now(),'pins'=>[]];$this->store($state);return $this->view($state);
        }
        $state=$this->read($id);$this->recover($state);
        if($operation==='bundle-status')return $this->view($state);
        if($operation==='bundle-discard'){if(!empty($state['pins']))throw new ProtocolError('BUNDLE_IN_USE',409);if($state['state']!=='expired'){$state['state']='discarded';$state['closedAt']=$this->now();$this->store($state);}$this->removePayload($state);return $this->view($state);}
        if($state['expiresAt']<=$this->now()||in_array($state['state'],['expired','discarded'],true))throw new ProtocolError('BUNDLE_CLOSED',410);
        if($state['purpose']==='publish'&&!($this->publishAllowed)())throw new ProtocolError('HOSTING_ENTITLEMENT_INACTIVE',403);
        if($operation==='bundle-chunk')return $this->chunk($state,$input,$bytes);
        if($operation==='bundle-seal')return $this->seal($state);
        throw new ProtocolError('BUNDLE_OPERATION_INVALID',422);
    });}
    private function chunk(array $state,array $input,?string $bytes):array {
        $offset=$input['offset']??null;$size=$input['size']??null;$sha=$input['sha256']??null;$name=$input['file']??null;
        if($bytes===null||!is_int($offset)||$offset<0||!is_int($size)||$size<1||$size>self::CHUNK||strlen($bytes)!==$size||!is_string($sha)||!preg_match('/^[a-f0-9]{64}$/D',$sha)||!hash_equals($sha,hash('sha256',$bytes)))throw new ProtocolError('BUNDLE_CHUNK_INVALID',422);
        $index=array_search($name,array_column($state['files'],'file'),true);if($index===false)throw new ProtocolError('BUNDLE_FILE_UNKNOWN',422);$file=&$state['files'][$index];$path=$this->path($state['bundleId'],'file-'.$index);
        if($offset%self::CHUNK!==0||$offset>=$file['size']||$size!==min(self::CHUNK,$file['size']-$offset))throw new ProtocolError('BUNDLE_CHUNK_BOUNDARY_INVALID',422);
        if($offset<$file['received']){if($offset+$size>$file['received']||!hash_equals($sha,$this->digestRange($path,$offset,$size)))throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);return $this->view($state);}
        if($offset!==$file['received'])throw new ProtocolError('BUNDLE_OFFSET_CONFLICT',409);
        if($state['state']!=='receiving')throw new ProtocolError('BUNDLE_CLOSED',410);
        $intent=['offset'=>$offset,'size'=>$size,'sha256'=>$sha];if(isset($file['pending'])&&$file['pending']!==$intent)throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);$file['pending']=$intent;$this->store($state);
        $handle=$this->openFile($path,'c+b');try{clearstatcache(true,$path);if(filesize($path)!==$offset||fseek($handle,$offset)!==0)throw new ProtocolError('BUNDLE_FILE_INVALID',503);$this->writeAll($handle,$bytes);$this->durable($handle);chmod($path,0600);}finally{fclose($handle);}
        $file['received']=$offset+$size;unset($file['pending']);$this->store($state);return $this->view($state);
    }
    private function seal(array $state):array {
        if($state['state']==='sealed'){$path=$this->path($state['bundleId'],'package.zip');if(!is_file($path)||filesize($path)!==$state['zipBytes']||!hash_equals($state['zipSha256'],hash_file('sha256',$path)))throw new ProtocolError('BUNDLE_ARCHIVE_INVALID',503);return $this->view($state);}
        foreach($state['files'] as $index=>$file){$path=$this->path($state['bundleId'],'file-'.$index);if($file['received']!==$file['size']||!is_file($path)||filesize($path)!==$file['size'])throw new ProtocolError('BUNDLE_INCOMPLETE',409);if(!hash_equals($file['sha256'],hash_file('sha256',$path)))throw new ProtocolError('BUNDLE_DIGEST_MISMATCH',422);}
        // The archive rename may have succeeded before its state acknowledgement.
        // Adopt only an exact verified archive; never allocate a third payload copy.
        $target=$this->path($state['bundleId'],'package.zip');
        if(is_file($target)){
            $zip=new \ZipArchive;if(filesize($target)!==$state['zipBytes']||$zip->open($target)!==true)throw new ProtocolError('BUNDLE_ARCHIVE_INVALID',503);
            try{if($zip->numFiles!==count($state['files']))throw new ProtocolError('BUNDLE_ARCHIVE_INVALID',503);foreach($state['files'] as $file){$stat=$zip->statName($file['file']);$stream=$zip->getStream($file['file']);if(!$stat||$stat['size']!==$file['size']||!is_resource($stream))throw new ProtocolError('BUNDLE_ARCHIVE_INVALID',503);try{$hash=hash_init('sha256');hash_update_stream($hash,$stream);if(!hash_equals($file['sha256'],hash_final($hash)))throw new ProtocolError('BUNDLE_ARCHIVE_INVALID',503);}finally{fclose($stream);}}}finally{$zip->close();}
            $state['state']='sealed';$state['zipSha256']=hash_file('sha256',$target);$state['sealedAt']=$this->now();$this->store($state);return $this->view($state);
        }
        $tmp=$this->path($state['bundleId'],'package.tmp');$out=$this->openFile($tmp,'wb');$central='';$offset=0;
        try{foreach($state['files'] as $index=>$file){$path=$this->path($state['bundleId'],'file-'.$index);$name=$file['file'];$size=$file['size'];$crc=(int)hexdec(hash_file('crc32b',$path));
                $header=pack('VvvvvvVVVvv',0x04034b50,20,0x0800,0,0,0x2821,$crc,$size,$size,strlen($name),0).$name;$this->writeAll($out,$header);$in=$this->openFile($path,'rb');try{if(stream_copy_to_stream($in,$out)!==$size)throw new ProtocolError('BUNDLE_WRITE_UNCERTAIN',503);}finally{fclose($in);}
                $central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0x0800,0,0,0x2821,$crc,$size,$size,strlen($name),0,0,0,0,0,$offset).$name;$offset+=strlen($header)+$size;
            }
            $this->writeAll($out,$central.pack('VvvvvVVv',0x06054b50,0,0,count($state['files']),count($state['files']),strlen($central),$offset,0));$this->durable($out);
        }finally{fclose($out);}
        chmod($tmp,0600);clearstatcache(true,$tmp);if(filesize($tmp)!==$state['zipBytes']||filesize($tmp)>self::MAX_ZIP)throw new ProtocolError('BUNDLE_ARCHIVE_INVALID',503);
        if(!rename($tmp,$target))throw new ProtocolError('BUNDLE_WRITE_UNCERTAIN',503);
        $state['state']='sealed';$state['zipSha256']=hash_file('sha256',$target);$state['sealedAt']=$this->now();$this->store($state);return $this->view($state);
    }
    /** Internal Publisher ownership hooks, deliberately absent from the HTTP dispatch. */
    public function previewPackage(string $id,string $project,string $version,string $reference,int $expiresAt):array {return $this->locked(function()use($id,$project,$version,$reference,$expiresAt){
        $this->sweep();$state=$this->read($id);$owned=in_array($reference,$state['pins'],true);
        if(!preg_match('/^preview_[a-f0-9]{32}$/D',$reference)||$state['purpose']!=='preview'||$state['projectId']!==$project||$state['versionId']!==$version)throw new ProtocolError('BUNDLE_PREVIEW_BINDING_INVALID',409);
        if($state['state']!=='sealed'||$expiresAt<=$this->now()||$expiresAt>$this->now()+21600||(!$owned&&$state['expiresAt']<=$this->now())||($owned&&($state['previewPins'][$reference]??null)!==$expiresAt))throw new ProtocolError('BUNDLE_NOT_SEALED',409);
        $archive=$this->path($id,'package.zip');if(!is_file($archive)||filesize($archive)!==$state['zipBytes']||!hash_equals($state['zipSha256'],hash_file('sha256',$archive)))throw new ProtocolError('BUNDLE_ARCHIVE_INVALID',503);
        $files=[];foreach($state['files'] as $index=>$file){$path=$this->path($id,'file-'.$index);if(!is_file($path)||filesize($path)!==$file['size']||!hash_equals($file['sha256'],hash_file('sha256',$path)))throw new ProtocolError('BUNDLE_DIGEST_MISMATCH',422);$files[$file['file']]=$path;}
        if(!$owned){$state['pins'][]=$reference;$state['previewPins'][$reference]=$expiresAt;$this->store($state);}
        return ['zipPath'=>$archive,'zipSha256'=>$state['zipSha256'],'manifestSha256'=>$state['files'][0]['sha256'],'files'=>$files];
    });}
    public function publicationPackage(string $id,string $project,string $version,string $reference,bool $pin=false):array {return $this->locked(function()use($id,$project,$version,$reference,$pin){
        $this->sweep();$state=$this->read($id);$owned=in_array($reference,$state['pins'],true);
        if(!preg_match('/^rel_[a-f0-9]{32}$/D',$reference)||$state['purpose']!=='publish'||$state['projectId']!==$project||$state['versionId']!==$version)throw new ProtocolError('BUNDLE_PUBLICATION_BINDING_INVALID',409);
        if($state['state']!=='sealed'||(!$owned&&(!$pin||$state['expiresAt']<=$this->now())))throw new ProtocolError('BUNDLE_NOT_SEALED',409);
        $archive=$this->path($id,'package.zip');if(!is_file($archive)||filesize($archive)!==$state['zipBytes']||!hash_equals($state['zipSha256'],hash_file('sha256',$archive)))throw new ProtocolError('BUNDLE_ARCHIVE_INVALID',503);
        $files=[];foreach($state['files'] as $index=>$file){$path=$this->path($id,'file-'.$index);if(!is_file($path)||filesize($path)!==$file['size']||!hash_equals($file['sha256'],hash_file('sha256',$path)))throw new ProtocolError('BUNDLE_DIGEST_MISMATCH',422);$files[$file['file']]=$path;}
        if(!$owned){$state['pins'][]=$reference;$this->store($state);}
        return ['bundleId'=>$id,'zipPath'=>$archive,'zipSha256'=>$state['zipSha256'],'manifestSha256'=>$state['files'][0]['sha256'],'files'=>$files];
    });}
    public function pin(string $id,string $reference):array {return $this->locked(function()use($id,$reference){$this->sweep();$state=$this->read($id);if(!preg_match('/^rel_[a-f0-9]{32}$/D',$reference)||$state['state']!=='sealed'||$state['expiresAt']<=$this->now())throw new ProtocolError('BUNDLE_PIN_INVALID',409);if(!in_array($reference,$state['pins'],true))$state['pins'][]=$reference;$this->store($state);return $this->view($state);});}
    public function unpin(string $id,string $reference):void {$this->locked(function()use($id,$reference){$state=$this->read($id);$state['pins']=array_values(array_diff($state['pins'],[$reference]));$this->store($state);});}
}
