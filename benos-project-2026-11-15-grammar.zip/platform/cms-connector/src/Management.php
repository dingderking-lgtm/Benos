<?php
declare(strict_types=1);
namespace Benos;
final class Management {
    public static function domain(array $input,array $connection):array {
        $id=$input['changeId']??'';$origin=$input['origin']??'';$expected=$input['expectedOrigin']??'';
        if(!is_string($id)||!preg_match('/^dom_[a-f0-9]{32}$/D',$id)||!is_string($origin)||!is_string($expected)||!preg_match('~^https://(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{1,62}$~D',$origin))throw new ProtocolError('DOMAIN_INPUT_INVALID');
        $fingerprint=hash('sha256',json_encode([$expected,$origin],JSON_THROW_ON_ERROR));$receipt=\setting('benos_domain_'.$id,null);
        if(is_array($receipt)&&!hash_equals($receipt['fingerprint'],$fingerprint))throw new ProtocolError('IDEMPOTENCY_CONFLICT',409);
        // SiteAddress atomically replaces app_url only and compares the old origin.
        // On a lost response the repeated exact target is a safe no-op.
        \AACMS\Services\SiteAddress::update($origin,$expected);
        \save_setting('benos_domain_'.$id,['fingerprint'=>$fingerprint,'origin'=>$origin]);
        return ['siteId'=>$connection['siteId'],'changeId'=>$id,'origin'=>$origin];
    }
}
