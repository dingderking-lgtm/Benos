<?php
declare(strict_types=1);
namespace Benos;

// Operator-only disaster recovery. It never loads the website bootstrap or a
// PHP configuration taken from an archive. No environment flag can enable HTTP.
final class ManagedRestore {
    private static function check(bool $condition,string $code):void {if(!$condition)throw new \RuntimeException($code);}
    private static function file(string $path):void {self::check(is_file($path)&&!is_link($path),'UNSAFE_FILE');}
    private static function path(string $path):void {
        self::check($path!==''&&!str_contains($path,'\\')&&!str_contains($path,':')&&!preg_match('/[\x00-\x1f\x7f]/',$path),'UNSAFE_PATH');
        foreach(explode('/',$path) as $part)self::check($part!==''&&$part!=='.'&&$part!=='..'&&!preg_match('/[. ]$/',$part)&&!preg_match('/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i',$part),'UNSAFE_PATH');
    }
    // Installer::writeConfig emits a flat scalar array. Parse only that grammar;
    // reject calls, expressions, includes, variables and executable suffixes.
    public static function scalarConfig(string $source):array {
        self::check(strlen($source)<=65536,'CONFIG_TOO_LARGE');$tokens=[];
        foreach(token_get_all($source) as $token){if(is_array($token)&&in_array($token[0],[T_WHITESPACE,T_COMMENT,T_DOC_COMMENT],true))continue;$tokens[]=$token;}
        $at=0;$take=function()use(&$tokens,&$at){return $tokens[$at++]??null;};
        $expect=function($token,$type) {self::check(is_int($type)?is_array($token)&&$token[0]===$type:$token===$type,'UNSAFE_ARCHIVE_CONFIG');};
        $expect($take(),T_OPEN_TAG);$expect($take(),T_RETURN);$open=$take();
        if(is_array($open)&&$open[0]===T_ARRAY){$expect($take(),'(');$close=')';}else{$expect($open,'[');$close=']';}
        $string=function($token):string{self::check(is_array($token)&&$token[0]===T_CONSTANT_ENCAPSED_STRING&&str_starts_with($token[1],"'"),'UNSAFE_ARCHIVE_CONFIG');return preg_replace_callback('/\\\\([\\\\\'])/',fn($match)=>$match[1],substr($token[1],1,-1));};$result=[];
        while(($tokens[$at]??null)!==$close){$name=$string($take());self::check(!array_key_exists($name,$result),'DUPLICATE_CONFIG_KEY');$expect($take(),T_DOUBLE_ARROW);$value=$take();
            if(is_array($value)&&$value[0]===T_CONSTANT_ENCAPSED_STRING)$value=$string($value);
            elseif(is_array($value)&&$value[0]===T_LNUMBER&&preg_match('/^(?:0|[1-9][0-9]*)$/D',$value[1]))$value=(int)$value[1];
            elseif(is_array($value)&&$value[0]===T_STRING&&in_array(strtolower($value[1]),['true','false','null'],true))$value=match(strtolower($value[1])){'true'=>true,'false'=>false,default=>null};
            else throw new \RuntimeException('UNSAFE_ARCHIVE_CONFIG');
            $result[$name]=$value;if(($tokens[$at]??null)===$close)break;$expect($take(),',');
        }
        $expect($take(),$close);$expect($take(),';');self::check($at===count($tokens),'UNSAFE_ARCHIVE_CONFIG');return $result;
    }
    private static function freshRelease(string $root):array {
        self::file($root.'/BENOS-RELEASE.json');$release=json_decode(file_get_contents($root.'/BENOS-RELEASE.json'),true,64,JSON_THROW_ON_ERROR);
        self::check(($release['format']??'')==='benos-cms-release'&&($release['cmsVersion']??'')==='1.9.21'&&is_array($release['files']??null),'RELEASE_INVALID');
        self::check(isset($release['files']['storage/private/BenosManagedRestore.php']),'RECOVERY_RELEASE_REQUIRED');
        $allowed=['BENOS-RELEASE.json'=>true];foreach($release['files'] as $path=>$hash){self::path($path);self::file($root.'/'.$path);self::check(is_string($hash)&&hash_equals($hash,hash_file('sha256',$root.'/'.$path)),'RELEASE_DIGEST_MISMATCH');$allowed[$path]=true;}
        foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root,\FilesystemIterator::SKIP_DOTS)) as $item){self::check(!$item->isLink(),'SYMLINK_DENIED');if(!$item->isFile())continue;$path=str_replace('\\','/',substr($item->getPathname(),strlen($root)+1));self::check(isset($allowed[$path]),'TARGET_NOT_FRESH');}
        return $release;
    }
    private static function archive(string $path,string $expected):array {
        self::file($path);self::check(preg_match('/^[a-f0-9]{64}$/D',$expected)===1&&hash_equals($expected,hash_file('sha256',$path)),'ARCHIVE_DIGEST_MISMATCH');
        $service=new \AACMS\Services\BackupService;$manifest=$service->inspect($path);self::check(($manifest['app_version']??'')==='1.9.21','BACKUP_VERSION_UNSUPPORTED');
        $zip=new \ZipArchive;self::check($zip->open($path)===true,'ARCHIVE_UNREADABLE');try{
            $seen=[];for($i=0;$i<$zip->numFiles;$i++){$entry=$zip->statIndex($i);self::path($entry['name']);$key=strtolower($entry['name']);self::check(!isset($seen[$key]),'CASE_COLLISION');$seen[$key]=true;if($zip->getExternalAttributesIndex($i,$os,$attrs))self::check((($attrs>>16)&0170000)!==0120000,'SYMLINK_DENIED');}
            $config=self::scalarConfig($zip->getFromName('private-config/local.php'));
            $connection=json_decode($zip->getFromName('storage/private/benos-connection.json'),true,32,JSON_THROW_ON_ERROR);
            self::check(is_array($connection)&&preg_match('/^site_[a-f0-9]{32}$/D',$connection['siteId']??'')===1&&is_string($connection['signingSecret']??null)&&strlen($connection['signingSecret'])>=32&&is_string($connection['keyId']??null),'CONNECTION_IDENTITY_MISSING');
            self::check(is_string($config['app_key']??null)&&preg_match('/^[a-f0-9]{64}$/D',$config['app_key'])===1&&($config['installed']??false)===true,'APP_KEY_INVALID');
            return [$manifest,$config,$connection];
        }finally{$zip->close();}
    }
    private static function target(string $file,array $original):array {
        self::file($file);self::check(filesize($file)<=65536,'TARGET_CONFIG_INVALID');$input=json_decode(file_get_contents($file),true,16,JSON_THROW_ON_ERROR);
        self::check(is_array($input)&&!array_diff(array_keys($input),['db_host','db_port','db_name','db_user','db_password','app_url']),'TARGET_CONFIG_INVALID');
        foreach(['db_host','db_name','db_user','db_password'] as $field)self::check(is_string($input[$field]??null),'TARGET_CONFIG_INVALID');
        self::check(preg_match('/^[a-zA-Z0-9_.:-]{1,253}$/D',$input['db_host'])===1&&preg_match('/^[a-zA-Z0-9_]{1,64}$/D',$input['db_name'])===1&&strlen($input['db_user'])>0&&strlen($input['db_user'])<=128,'TARGET_CONFIG_INVALID');
        $input['db_port']=$input['db_port']??3306;self::check(is_int($input['db_port'])&&$input['db_port']>=1&&$input['db_port']<=65535,'TARGET_CONFIG_INVALID');
        self::check(!isset($input['app_url'])||$input['app_url']===$original['app_url'],'DOMAIN_CHANGE_REQUIRES_SEPARATE_REBIND');
        return array_replace($original,$input,['installed'=>true,'environment'=>'production','version'=>'1.9.21']);
    }
    private static function foreignKeys(\PDO $pdo):void {
        $rows=$pdo->query('SELECT TABLE_NAME,COLUMN_NAME,REFERENCED_TABLE_NAME,REFERENCED_COLUMN_NAME,CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME IS NOT NULL ORDER BY TABLE_NAME,CONSTRAINT_NAME,ORDINAL_POSITION')->fetchAll(\PDO::FETCH_ASSOC);$groups=[];
        foreach($rows as $row)$groups[$row['TABLE_NAME'].'.'.$row['CONSTRAINT_NAME']][]=$row;
        $q=function(string $name):string{self::check(preg_match('/^[a-zA-Z0-9_]+$/D',$name)===1,'SCHEMA_IDENTIFIER_INVALID');return '`'.$name.'`';};
        foreach($groups as $group){$joins=[];$present=[];foreach($group as $column){$joins[]='p.'.$q($column['REFERENCED_COLUMN_NAME']).'=c.'.$q($column['COLUMN_NAME']);$present[]='c.'.$q($column['COLUMN_NAME']).' IS NOT NULL';}$sql='SELECT 1 FROM '.$q($group[0]['TABLE_NAME']).' c WHERE '.implode(' AND ',$present).' AND NOT EXISTS(SELECT 1 FROM '.$q($group[0]['REFERENCED_TABLE_NAME']).' p WHERE '.implode(' AND ',$joins).') LIMIT 1';self::check(!$pdo->query($sql)->fetchColumn(),'RESTORED_FOREIGN_KEY_INVALID');}
    }
    public static function run(string $root,array $args):array {
        self::check(PHP_SAPI==='cli','CLI_ONLY');self::check(isset($args['archive'],$args['sha256']),'ARGUMENT_REQUIRED');
        [$manifest,$original,$connection]=self::archive($args['archive'],$args['sha256']);
        if(isset($args['inspect']))return ['verified'=>true,'cmsVersion'=>'1.9.21','tables'=>count($manifest['tables']),'files'=>count($manifest['files']),'siteId'=>$connection['siteId']];
        self::check(isset($args['target-config']),'TARGET_CONFIG_REQUIRED');$release=self::freshRelease($root);$config=self::target($args['target-config'],$original);
        foreach($manifest['files'] as $path=>$hash){
            if(isset($release['files'][$path]))self::check(in_array($path,['storage/private/BenosProtocol.php','storage/private/BenosNativeInstaller.php','storage/private/BenosPublisher.php','storage/private/BenosEntitlement.php','storage/private/BenosManagedRestore.php','storage/private/BenosManagement.php','storage/private/BenosPreview.php','storage/private/BenosPreviewBundle.php','storage/private/BenosAssetPolicy.php','storage/private/BenosBundle.php','public/uploads/.htaccess'],true),'PROTECTED_RELEASE_FILE');
            elseif(preg_match('/\.(?:php[0-9]?|phtml|phar|cgi|pl|py|sh|bat|cmd|exe|dll)$/i',$path)||in_array(basename($path),['.htaccess','.user.ini'],true))throw new \RuntimeException('EXECUTABLE_BACKUP_FILE_DENIED');
        }
        $pdo=new \PDO('mysql:host='.$config['db_host'].';port='.$config['db_port'].';dbname='.$config['db_name'].';charset=utf8mb4',$config['db_user'],$config['db_password'],[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION,\PDO::ATTR_EMULATE_PREPARES=>false]);
        \AACMS\Services\DatabaseCompatibility::assertSupported($pdo);self::check(!$pdo->query('SHOW TABLES')->fetchAll(\PDO::FETCH_COLUMN),'DATABASE_NOT_EMPTY');
        \AACMS\Services\Installer::directories();$stage=$root.'/storage/tmp/recovery-'.bin2hex(random_bytes(12));mkdir($stage,0700);
        // MySQL DDL is not transactional. Failure leaves a quarantined new DB
        // and no config/local.php, never a partially active website.
        $counts=(new \AACMS\Services\BackupService)->restoreInto($args['archive'],$pdo,$stage);self::foreignKeys($pdo);
        foreach($manifest['files'] as $path=>$hash){if(isset($release['files'][$path]))continue;$destination=$root.'/'.$path;self::check(!file_exists($destination)&&!is_link($destination),'TARGET_FILE_EXISTS');if(!is_dir(dirname($destination)))mkdir(dirname($destination),0750,true);self::check(rename($stage.'/'.$path,$destination),'RESOURCE_MOVE_FAILED');@chmod($destination,0600);}
        $lease=['siteId'=>$connection['siteId'],'issuedAt'=>time(),'validUntil'=>time(),'hostingActive'=>false,'publishAllowed'=>false];
        Protocol::writePrivateJson($root.'/storage/private/benos-entitlement.json',['lease'=>$lease,'signature'=>hash_hmac('sha256',json_encode($lease,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),$connection['signingSecret'])],'RECOVERY_LEASE_WRITE_FAILED');
        \AACMS\Services\Installer::writeConfig($config);
        // Only discard the isolated staging data that this invocation created.
        foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($stage,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::CHILD_FIRST) as $item){self::check(!$item->isLink(),'SYMLINK_DENIED');if($item->isDir())rmdir($item->getPathname());else unlink($item->getPathname());}rmdir($stage);
        return ['restored'=>true,'tables'=>count($counts),'rows'=>array_sum($counts),'files'=>count($manifest['files']),'siteId'=>$connection['siteId'],'hostingPaused'=>true,'requiresPlatformLeaseRenewal'=>true];
    }
}
