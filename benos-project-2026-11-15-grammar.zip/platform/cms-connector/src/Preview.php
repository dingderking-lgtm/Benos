<?php
declare(strict_types=1);
namespace Benos;
use AACMS\Services\{SitePackageService,TemplatePackageService,Renderer,PageService,FormService,BlogService,BlogRenderer};

/** Pinned native renderer. Temporary InnoDB rows are always rolled back. */
final class Preview {
    private static array $dimensions=[];
    private static bool $rendering=false;
    public static function isRendering():bool{return self::$rendering;}
    public static function imageDimensions(string $src):?array {return self::$dimensions[(string)parse_url($src,PHP_URL_PATH)]??null;}
    public function render(array $input):array {
        $raw=$input['manifestJson']??null;$pageKey=$input['pageKey']??null;
        if(!is_string($raw)||strlen($raw)>2*1048576||!is_string($pageKey)||!preg_match('/^[a-zA-Z0-9_-]{1,80}$/D',$pageKey))throw new ProtocolError('PREVIEW_INPUT_INVALID');
        $manifest=json_decode($raw,true,128,JSON_THROW_ON_ERROR);$assets=$input['assets']??[];
        if(!is_array($manifest)||!is_array($assets)||!array_is_list($assets)||count($assets)>64)throw new ProtocolError('PREVIEW_INPUT_INVALID');
        AssetPolicy::manifest($manifest);
        $path=\storage_path('private/benos-preview-'.bin2hex(random_bytes(16)).'.zip');$zip=new \ZipArchive;
        if($zip->open($path,\ZipArchive::CREATE|\ZipArchive::EXCL)!==true)throw new ProtocolError('PREVIEW_TEMP_UNAVAILABLE',503);
        $images=[];$seen=[];$total=0;$closed=false;
        try{
            $zip->addFromString('manifest.json',$raw);
            foreach($assets as $asset){$file=$asset['file']??'';$bytes=base64_decode((string)($asset['base64']??''),true);if(!is_string($file)||!preg_match('~^assets/[0-9]{1,2}\.(?:png|jpe?g|webp|gif|svg|pdf)$~D',$file)||isset($seen[$file])||$bytes===false||($total+=strlen($bytes))>6*1048576)throw new ProtocolError('PREVIEW_ASSET_INVALID');$seen[$file]=true;$zip->addFromString($file,$bytes);$images[$file]=$bytes;}
            foreach($images as $file=>$bytes)AssetPolicy::bytes($bytes,$file);
            $zip->close();$closed=true;chmod($path,0600);$manifest=(new SitePackageService)->inspect($path);
        }finally{if(!$closed)$zip->close();if(is_file($path))@unlink($path);}
        return $this->renderNative($manifest,hash('sha256',$raw),$pageKey,static fn($file)=>$images[$file]??null);
    }
    /** Internal, already-inspected bundle path. No authored filesystem paths. */
    public function renderBundle(array $manifest,string $manifestSha,string $pageKey,array $files,callable $mapAsset):array {return $this->renderNative($manifest,$manifestSha,$pageKey,static fn($file)=>isset($files[$file])?file_get_contents($files[$file]):null,$mapAsset);}
    private function renderNative(array $manifest,string $manifestSha,string $pageKey,callable $readAsset,?callable $mapAsset=null):array {
        $pdo=\db();if($pdo->inTransaction())throw new ProtocolError('PREVIEW_TRANSACTION_CONFLICT',503);
        if((int)\query('SELECT COUNT(*) FROM pages')->fetchColumn()>10000)throw new ProtocolError('PREVIEW_SITE_TOO_LARGE',413);
        $renderer=new Renderer;$changes=[];$menuIds=[];$templateIds=[];$formMap=[];$mediaIds=[];$assetUrls=[];$pages=[];$oldGet=$_GET;$_GET=[];$managed=\setting('benos_managed_pages',[]);
        $pdo->beginTransaction();self::$rendering=true;
        try{
            // Sample-only preview: existing customer articles, fields, forms and
            // active templates must not become sample data for another design.
            \query("UPDATE pages SET status='draft'");\query('UPDATE templates SET is_active=0');\query('DELETE FROM blog_page_terms');\query('DELETE FROM settings');
            \save_setting('site_name',$manifest['site']['name']);\save_setting('footer_credit','');
            foreach($manifest['assets'] as $index=>$asset){
                $bytes=$readAsset($asset['file']);if(!is_string($bytes)||!hash_equals($asset['sha256'],hash('sha256',$bytes)))throw new ProtocolError('PREVIEW_ASSET_INVALID');
                // Embed the native validator's sanitized bytes. GIF remains intact
                // (including its frames); SVG never reuses unchecked authored XML.
                $safe=(new SitePackageService)->mediaBytes($bytes,$asset['file']);
                if($mapAsset){AssetPolicy::bytes($bytes,$asset['file']);$mapped=$mapAsset($asset,$safe,$index);if($mapped!==null)$assetUrls[$asset['path']]=$mapped;}
                if($safe['mime']==='application/pdf')continue; // A download resource, never an image/data document in the isolated preview.
                if(!$mapAsset)$assetUrls[$asset['path']]='data:'.$safe['mime'].';base64,'.base64_encode($safe['bytes']);
                if($safe['width']!==null&&$safe['height']!==null)self::$dimensions[$asset['path']]=[$safe['width'],$safe['height']];
            }
            foreach($manifest['menus'] as $menu){\query('INSERT INTO menus(name,items_json,created_at,updated_at) VALUES(?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())',[$menu['name'],\json_encode_safe($menu['items'])]);$menuIds[$menu['id']]=(int)$pdo->lastInsertId();}
            foreach($manifest['site']['forms'] as $definition){$ref=$definition['ref'];
                $key='preview-'.bin2hex(random_bytes(12));$normalized=(new FormService)->normalize($definition['definition']);$json=\json_encode_safe($normalized);
                \query("INSERT INTO forms(name,public_key,status,draft_json,created_at,updated_at) VALUES(?,?,'published',?,UTC_TIMESTAMP(),UTC_TIMESTAMP())",[$definition['name'],$key,$json]);$fid=(int)$pdo->lastInsertId();
                \query('INSERT INTO form_versions(form_id,version,schema_json,created_at) VALUES(?,1,?,UTC_TIMESTAMP())',[$fid,$json]);\query('UPDATE forms SET active_version_id=? WHERE id=?',[(int)$pdo->lastInsertId(),$fid]);$formMap[$ref]=$key;
            }
            foreach($manifest['templates'] as $template){\query('INSERT INTO templates(name,type,document_json,conditions_json,created_at,updated_at) VALUES(?,?,\'{}\',\'{}\',UTC_TIMESTAMP(),UTC_TIMESTAMP())',[$template['name'],$template['type']]);$templateIds[$template['id']]=(int)$pdo->lastInsertId();}
            // Use the pinned importer's actual remapping routine, including nested
            // project attributes and native menu/template/form references.
            $importer=new TemplatePackageService;$rewrite=new \ReflectionMethod($importer,'rewrite');$documents=[];
            foreach($manifest['templates'] as $template){$document=$rewrite->invoke($importer,$template['document'],[],$templateIds,$formMap,$mediaIds,$menuIds);$clean=$renderer->sanitizeDocument($document,false);
                foreach(['html','css','customCss'] as $field)if(($document[$field]??'')!==($clean[$field]??''))$changes[]=['templateId'=>$template['id'],'field'=>$field,'beforeSha256'=>hash('sha256',(string)($document[$field]??'')),'afterSha256'=>hash('sha256',(string)($clean[$field]??''))];
                $clean['settings']['template_enabled']=true;$conditions=['all'=>in_array($template['type'],['header','footer'],true),'pages'=>[],'exclude_pages'=>[],'types'=>in_array($template['type'],['archive','single'],true)?['article']:[],'categories'=>[]];$json=\json_encode_safe($clean);
                \query('UPDATE templates SET document_json=?,published_document_json=?,conditions_json=?,published_conditions_json=?,published_version=version,is_active=? WHERE id=?',[$json,$json,\json_encode_safe($conditions),\json_encode_safe($conditions),in_array($template['type'],['header','footer','section','archive','single'],true)?1:0,$templateIds[$template['id']]]);$documents[$template['id']]=$clean;
            }
            $site=$manifest['site'];foreach(array_merge($site['settings'],$site['theme']) as $key=>$value)\save_setting($key,$value);
            \save_setting('header_template_id',$templateIds[$site['header_template_id']]);\save_setting('footer_template_id',$templateIds[$site['footer_template_id']]);\save_setting('navigation_menu_id',$menuIds[$site['navigation_menu_id']]);\save_setting('navigation',[]);
            if(is_array($site['blog']??null))foreach($site['blog'] as $key=>$value)\save_setting('blog_'.$key,in_array($key,['archive_template_id','single_template_id'],true)?$templateIds[$value]:$value);
            $authorId=(int)\setting('blog_default_author_id',0);$author=$site['author']??null;
            if(!is_array($author)&&is_array($site['blog']??null))$author=['slug'=>'benos-preview-editor','name'=>'示例编辑部','kind'=>'organization','title'=>'示例作者资料','brief'=>'仅用于预览博客作者组件','bio'=>'这是一份预览示例，不代表真实团队资质或客户业务内容。','avatar'=>''];
            \save_setting('blog_default_author_id',0);$authorId=0;
            if(is_array($author)){
                $existing=\query('SELECT id FROM blog_authors WHERE slug=?',[$author['slug']])->fetchColumn();if($existing)\query('UPDATE blog_authors SET slug=? WHERE id=?',['benos-hidden-'.bin2hex(random_bytes(12)),(int)$existing]);
                \query('INSERT INTO blog_authors(slug,name,kind,title,brief,bio,avatar,seo_json,is_active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,1,UTC_TIMESTAMP(),UTC_TIMESTAMP())',[$author['slug'],$author['name'],$author['kind']??'person',$author['title']??'',$author['brief']??'',$author['bio']??'',$author['avatar']??'',\json_encode_safe($author['seo']??[])]);$authorId=(int)$pdo->lastInsertId();\save_setting('blog_default_author_id',$authorId);
            }
            $service=new PageService;
            $definitions=$site['pages'];
            if(is_array($site['blog']??null)&&!array_filter($definitions,static fn($p)=>$p['type']==='article')){
                $documents[0]=['version'=>1,'html'=>'<article><h1>示例文章标题</h1><p>此内容仅用于展示原生文章模板、作者与博客导航，不会保存为网站文章。</p></article>','css'=>'','settings'=>[]];
                $definitions[]=['key'=>'__blog_article','title'=>'示例文章标题','slug'=>'benos-preview-article','type'=>'article','template_id'=>0,'seo'=>['title'=>'示例文章标题'],'excerpt'=>'预览示例内容，实际网站内容由 CMS 管理。'];
            }
            foreach($definitions as $definition){
                $id=(int)($managed[$definition['key']]??0);$page=$id?$service->find($id):null;
                if(!$page&&\query('SELECT id FROM pages WHERE slug=?',[$definition['slug']])->fetchColumn())throw new ProtocolError('PREVIEW_PATH_CONFLICT',409);
                $document=$documents[$definition['template_id']];$document['settings']['theme_type']='none';$document['settings']['hide_header']=false;$document['settings']['hide_footer']=false;
                $blog=$definition['type']==='article'?(new BlogService)->normalize(($definition['blog']??[])+['editor_mode'=>'article','author_profile_id'=>$authorId,'published_at'=>gmdate('Y-m-d H:i:s')]):[];
                if(!$page){\query("INSERT INTO pages(title,slug,type,excerpt,featured_image,status,draft_json,seo_json,fields_json,blog_json,created_at,updated_at) VALUES(?,?,?,?,?,'published',?,?,'{}',?,UTC_TIMESTAMP(),UTC_TIMESTAMP())",[$definition['title'],$definition['slug'],$definition['type'],$definition['excerpt'],$definition['featured_image']??'',\json_encode_safe($document),\json_encode_safe($definition['seo']),\json_encode_safe($blog)]);$id=(int)$pdo->lastInsertId();$page=$service->find($id);}
                $page['title']=$definition['title'];$page['slug']=$definition['slug'];$page['excerpt']=$definition['excerpt'];$page['featured_image']=$definition['featured_image']??'';$page['fields_json']='{}';$page['category']='';$page['blog_json']=\json_encode_safe($blog);$page['draft_json']=\json_encode_safe($document);$page['seo_json']=\json_encode_safe($definition['seo']);$revision=$service->revision($page);
                \query("UPDATE pages SET published_revision_id=?,status='published',published_at=COALESCE(published_at,UTC_TIMESTAMP()) WHERE id=?",[$revision,$id]);$pages[$definition['key']]=$service->find($id);
            }
            \save_setting('home_page_id',$pages[$site['home']]['id']);
            if($pageKey==='__blog_archive')$html=(new BlogRenderer)->archive()['html']??null;
            elseif($pageKey==='__blog_author')$html=is_array($author)?((new BlogRenderer)->author($author['slug'])['html']??null):null;
            else{$page=$pages[$pageKey]??null;if(!$page)throw new ProtocolError('PREVIEW_PAGE_NOT_FOUND',404);$revision=\query('SELECT * FROM page_revisions WHERE id=?',[$page['published_revision_id']])->fetch();$html=$renderer->pageHtml($page,$revision,true);}
            if(!is_string($html))throw new ProtocolError('PREVIEW_PAGE_NOT_FOUND',404);
            $html=$this->embed($html,$assetUrls,$mapAsset!==null);if(strlen($html)>($mapAsset?16:8)*1048576)throw new ProtocolError('PREVIEW_RESPONSE_TOO_LARGE',413);
            return ['cmsVersion'=>'1.9.21','manifestSha256'=>$manifestSha,'pageKey'=>$pageKey,'html'=>$html,'sanitizationChanges'=>$changes,'usesSampleData'=>true,'dataMode'=>'manifest-samples','businessWrites'=>false];
        }finally{if($pdo->inTransaction())$pdo->rollBack();$_GET=$oldGet;self::$dimensions=[];self::$rendering=false;}
    }
    private function embed(string $html,array $assets,bool $externalAssets=false):string {
        $dom=new \DOMDocument;@$dom->loadHTML('<?xml encoding="UTF-8">'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);$xpath=new \DOMXPath($dom);
        foreach(iterator_to_array($xpath->query('//link[@rel="stylesheet"]')) as $node){$names=explode(' ',$node->getAttribute('data-aacms-styles'));$css='';foreach($names as $name){if(!in_array($name,['site.css','menu-navigation.css','blog-public.css','blog-themes.css','forms-public.css','site-icons.css'],true))throw new ProtocolError('PREVIEW_RESOURCE_UNSUPPORTED');$css.=file_get_contents(\public_path('assets/'.$name))."\n";}$style=$dom->createElement('style');$style->appendChild($dom->createTextNode($css));$node->parentNode->replaceChild($style,$node);}
        // HTML DOM serialization entity-escapes non-ASCII script text; preserve
        // pinned script bytes outside serialization, with HTML's LF normalization.
        $nativeScripts=[];$scriptPrefix='BENOS_NATIVE_JS_'.bin2hex(random_bytes(12)).'_';
        foreach(iterator_to_array($xpath->query('//script')) as $node){$path=parse_url($node->getAttribute('src'),PHP_URL_PATH);if(in_array($path,['/assets/site.js','/assets/blog-public.js','/assets/engineering-tools.js'],true)){$key=$scriptPrefix.count($nativeScripts);$nativeScripts[$key]='<script>'.str_replace(["\r\n","\r"],"\n",file_get_contents(\public_path(ltrim($path,'/')))).'</script>';$node->parentNode->replaceChild($dom->createTextNode($key),$node);}else $node->parentNode->removeChild($node);}
        foreach($xpath->query('//form') as $node){$node->removeAttribute('action');$node->setAttribute('data-benos-preview','true');}
        // Browser policy is also enforced by the authenticated platform response.
        $policy=$dom->createElement('meta');$policy->setAttribute('http-equiv','Content-Security-Policy');$policy->setAttribute('content',"default-src 'none'; img-src data:".($externalAssets?' __BENOS_PREVIEW_ASSET_ORIGIN__':'')."; style-src 'unsafe-inline' https://fonts.googleapis.com; script-src 'unsafe-inline'; font-src data: https://fonts.gstatic.com; connect-src 'none'; form-action 'none'; base-uri 'none'");$head=$dom->getElementsByTagName('head')->item(0);$head->insertBefore($policy,$head->firstChild);
        $robots=$dom->createElement('meta');$robots->setAttribute('name','robots');$robots->setAttribute('content','noindex,nofollow');$head->appendChild($robots);
        $out=$dom->saveHTML();
        // Existing editorial images belong to this authenticated target CMS.
        // Resolve only registered public media; never open authored arbitrary paths.
        $total=0;foreach($externalAssets?[]:\query('SELECT path,mime,size FROM media WHERE deleted_at IS NULL')->fetchAll() as $media){$path=$media['path'];if(isset($assets[$path])||!str_contains($out,$path)||!preg_match('~^/uploads/[A-Za-z0-9_/-]+\.(?:png|jpe?g|webp|gif|svg)$~D',$path))continue;$file=\public_path(ltrim($path,'/'));if(is_link($file)||!is_file($file)||($total+=filesize($file))>6*1048576)throw new ProtocolError('PREVIEW_MEDIA_UNAVAILABLE',413);$safe=(new SitePackageService)->mediaBytes(file_get_contents($file),basename($path));$assets[$path]='data:'.$safe['mime'].';base64,'.base64_encode($safe['bytes']);}
        foreach($assets as $path=>$data)$out=str_replace([rtrim((string)\config('app_url'),'/').$path,$path],$data,$out);
        // Fonts/icons are immutable packaged public assets, never arbitrary disk paths.
        $out=preg_replace_callback('~(?:/assets/)?((?:icons|site-icons)/[^\s"\'()<>?#]+\.svg)(?:\?[^\s"\'()<>#]*)?~',static function($m){$path=\public_path('assets/'.$m[1]);if(str_contains($m[1],'..')||is_link($path)||!is_file($path))return $m[0];return 'data:image/svg+xml;base64,'.base64_encode(file_get_contents($path));},$out);
        if($externalAssets){
            // Only immutable packaged data and exact scoped placeholders can
            // cause resource requests. PDF links and authored external URLs are
            // inert in this sample-only document; navigation anchors stay local.
            $scripts=[];$prefix='BENOS_FIXED_SCRIPT_'.bin2hex(random_bytes(12)).'_';$out=preg_replace_callback('~<script\b[^>]*>.*?</script\s*>~is',static function($match)use(&$scripts,$prefix){$key=$prefix.count($scripts);$scripts[$key]=$match[0];return $key;},$out);
            $allowed=static fn($url)=>str_starts_with($url,'data:image/')||preg_match('~^/__benos_preview_assets/preview_[a-f0-9]{32}/[0-9]{1,2}$~D',$url)||str_starts_with($url,'#');
            $out=preg_replace_callback('~\s(src|srcset|poster|href|xlink:href)\s*=\s*(["\'])(.*?)\2~is',static function($m)use($allowed){$value=html_entity_decode($m[3],ENT_QUOTES|ENT_HTML5,'UTF-8');if(strtolower($m[1])!=='srcset')return $allowed($value)?$m[0]:'';foreach(explode(',',$value) as $part){$bits=preg_split('/\s+/',trim($part));if(count($bits)>2||!$allowed($bits[0])||(isset($bits[1])&&!preg_match('/^(?:[1-9][0-9]*w|[0-9]+(?:\.[0-9]+)?x)$/D',$bits[1])))return '';}return $m[0];},$out);
            $out=preg_replace_callback('~url\(\s*(["\']?)(.*?)\1\s*\)~is',static fn($m)=>$allowed(trim($m[2]))?$m[0]:'url("")',$out);
            $out=strtr($out,$scripts);
        }
        return strtr($out,$nativeScripts);
    }
}
