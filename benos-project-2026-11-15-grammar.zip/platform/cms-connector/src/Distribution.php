<?php
declare(strict_types=1);
namespace Benos;

// Exact, fail-closed overlays for the pinned AACMS 1.9.21 distribution only.
// Never run this transform over an existing customer's installation.
final class Distribution {
    /** Source-owned additions share one inventory for ZIP and bridge installs. */
    public static function additionalFiles():array {
        $root=dirname(__DIR__).'/product-catalog';$files=[];
        foreach(['src','routes','views','public'] as $directory){
            if(!is_dir($root.'/'.$directory))throw new \RuntimeException('Product module is incomplete.');
            foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root.'/'.$directory,\FilesystemIterator::SKIP_DOTS)) as $entry){
                if($entry->isLink())throw new \RuntimeException('Product source symlink denied.');
                if(!$entry->isFile())continue;
                $path=str_replace('\\','/',substr($entry->getPathname(),strlen($root)+1));
                if(!preg_match('~^(?:src|routes|views|public)/[A-Za-z0-9_./-]+\.(?:php|css|js)$~D',$path)||str_contains($path,'..'))throw new \RuntimeException('Invalid product source path.');
                $bytes=file_get_contents($entry->getPathname());if($bytes===false)throw new \RuntimeException('Cannot read product source.');$files[$path]=$bytes;
            }
        }
        foreach(['src/Services/ProductService.php','src/Services/ProductPresentation.php','routes/products.php','views/products/index.php','views/products/editor.php','views/products/history.php','views/products/settings.php','public/assets/products-admin.css','public/assets/products-admin.js','public/assets/products-public.css','public/assets/products-public.js'] as $required)if(!isset($files[$required]))throw new \RuntimeException('Product source missing: '.$required);
        ksort($files);return $files;
    }
    public static function transform(string $path,string $source,array $features=[]):string {
        if($path==='scripts/restore.php')return file_get_contents(dirname(__DIR__).'/restore-managed.php');
        if($path==='src/Services/PublicAssets.php'){
            // Native preview embeds these exact styles. Avoid writing public
            // generated cache files while the business transaction is rolled back.
            $needle="    private function bundle(array \$names):?string\n    {";
            $replacement=$needle."\n        if(class_exists('Benos\\\\Preview',false)&&\\Benos\\Preview::isRendering())return null;";
            $source=str_replace($needle,$replacement,str_replace("\r\n","\n",$source),$count);if($count!==1)throw new \RuntimeException('Pinned public asset preview hook changed.');
        }
        if($path==='src/Services/TemplatePackageService.php'){
            // A valid site package permits 64 assets; the native upload API
            // accepts 20 per call. Retain every native validator and the outer
            // importer's cleanup of all earlier successful batches on failure.
            $needle="if(\$files)\$created=(new MediaService)->upload(\$files,\\current_user()['id']??null);";
            $replacement="if(\$files){foreach(array_chunk(\$files,20) as \$benosBatch)\$created=array_merge(\$created,(new MediaService)->upload(\$benosBatch,\\current_user()['id']??null));}";
            $source=str_replace($needle,$replacement,$source,$count);if($count!==1)throw new \RuntimeException('Pinned template media batch hook changed.');
        }
        if($path==='src/Services/Renderer.php'){
            $needle="    private function intrinsicImageSize(string \$src): ?array\n    {";
            $replacement=$needle."\n        if(class_exists('Benos\\\\Preview',false)&&(\$virtual=\\Benos\\Preview::imageDimensions(\$src))!==null)return \$virtual;";
            $source=str_replace($needle,$replacement,str_replace("\r\n","\n",$source),$count);if($count!==1)throw new \RuntimeException('Pinned renderer image metadata hook changed.');
        }
        $publication='\\Benos\\Entitlement::assertPublication(BASE_PATH);';
        $hooks=[
            'src/Services/PageService.php'=>[
                'publish'=>$publication,'setHome'=>$publication,
                'setStatus'=>"if(in_array(\$action,['archive','unpublish'],true))".$publication,
                'deletePermanently'=>$publication,
            ],
            'src/Services/TemplateService.php'=>['publish'=>$publication,'activate'=>$publication,'applyGlobal'=>$publication],
            'src/Services/SiteKitService.php'=>['apply'=>$publication,'rollback'=>$publication],
            'src/Services/FormService.php'=>['save'=>"if(!empty(\$data['publish']))".$publication,'setStatus'=>$publication],
            'src/Services/MenuService.php'=>['create'=>"if(!empty(\$data['use_default']))".$publication,'update'=>$publication,'setDefault'=>$publication,'delete'=>$publication],
            'src/Services/BlogService.php'=>['schedule'=>$publication,'saveSettings'=>$publication,'saveTerm'=>$publication,'deleteTerm'=>$publication,'runDue'=>"if(!\\Benos\\Entitlement::publicationAllowed(BASE_PATH))return ['published'=>0,'failed'=>0,'skipped'=>0,'items'=>[],'paused'=>true];"],
            'src/Services/Updater.php'=>['apply'=>'\\Benos\\Entitlement::denyUnmanagedUpdate();'],
            'src/Services/UpdateRuntime.php'=>['prepare'=>'\\Benos\\Entitlement::denyUnmanagedUpdate();'],
        ];
        foreach($hooks[$path]??[] as $method=>$guard){
            $pattern='~((?:public|protected|private)\s+(?:static\s+)?function\s+'.preg_quote($method,'~').'\s*\([^)]*\)\s*(?::\s*[^\{]+)?\{)~';
            $count=0;$source=preg_replace_callback($pattern,fn($match)=>$match[1]."\n        // Benos managed publication policy\n        ".$guard."\n",$source,-1,$count);
            if($count!==1)throw new \RuntimeException('Pinned distribution hook mismatch: '.$path.'::'.$method);
        }
        if($path==='src/bootstrap.php'){
            $count=0;$gate="\n// Benos entitlement lease gate\nrequire_once dirname(__DIR__).'/storage/private/BenosEntitlement.php';\n\\Benos\\Entitlement::guard(dirname(__DIR__));\n";
            $source=str_replace('declare(strict_types=1);','declare(strict_types=1);'.$gate,$source,$count);
            if($count!==1)throw new \RuntimeException('Pinned bootstrap hook mismatch.');
        }
        if($path==='scripts/update-worker.php'){
            $count=0;$source=str_replace('declare(strict_types=1);',"declare(strict_types=1);\nrequire_once dirname(__DIR__).'/storage/private/BenosEntitlement.php';\n\\Benos\\Entitlement::denyUnmanagedUpdate();",$source,$count);
            if($count!==1)throw new \RuntimeException('Pinned update worker hook mismatch.');
        }
        if($path==='src/ui.php')$source=str_replace("'AACMS'","'Benos'",$source);
        if($path==='views/install.php')$source=str_replace('AACMS','Benos',$source);
        if($path==='views/system-update.php')$source='<section class="module-workspace"><div class="page-header"><h1>网站版本管理</h1></div><section class="card"><div class="card-body"><h2>Benos 托管网站</h2><p>此网站使用平台维护的发行版本。升级需要先完成备份、权限校验及兼容性检查。</p><p>请联系平台管理员处理版本升级；此后台不接受自行上传或安装其他发行包。</p></div></section></section>';
        if($path==='routes/system-updates.php')$source=<<<'PHP'
<?php
return function($app):void {
    $app->get('/admin/system/updates',function($request,$response){require_permission('system');return html_response($response,view('system-update',['title'=>'网站版本管理','active'=>'system-updates']));});
    $app->get('/admin/api/system/updates/status',function($request,$response){require_permission('system');return json_response($response,['managed'=>true,'state'=>'platform_managed','version'=>app_version()])->withHeader('Cache-Control','no-store');});
};
PHP;
        if($path==='views/partials/ai-worker-diagnostics.php'){
            $source=str_replace('Hostinger 执行结果','平台任务执行记录',$source);
            $source=preg_replace('~<details><summary>多站点检查与只读诊断</summary>.*?</details>~s','<p>后台任务由平台维护。若执行记录持续未更新，请联系平台管理员检查任务服务。</p>',$source);
        }
        if($path==='views/system.php'){
            $source=preg_replace('~<a class="button secondary small" href="/admin/system/backups/[^"\r\n]+">下载备份</a>~','<span class="badge">平台私有恢复备份</span>',$source);
            $source=str_replace(['创建和下载整站备份。','文件包含私有数据，请安全保存','数据库升级与恢复使用发布包附带的命令行工具，先完成备份再执行。','正式服务器需设置每分钟执行：<div class="code" style="margin-top:10px">php /你的站点路径/scripts/cron.php</div>'],['创建由平台保管的整站恢复备份。','由平台保管，可用于受控恢复','网站升级与恢复由平台管理员处理。','定时任务由平台统一配置和检查。'],$source);
        }
        if($path==='routes/system.php')$source=str_replace('请下载后妥善保存。','恢复文件已由平台私有保存。',$source);
        // Product management extends the pinned distribution without editing
        // its upstream source or rewriting a customer's existing documents.
        $replace=static function(string $needle,string $replacement,string $label)use(&$source):void{
            $source=str_replace($needle,$replacement,$source,$count);if($count!==1)throw new \RuntimeException('Pinned product hook mismatch: '.$label);
        };
        if($path==='public/index.php')$replace("'settings','forms','site-kits'","'settings','forms','products','site-kits'",'route registry');
        if($path==='src/bootstrap.php')$replace("'editor'=>['pages','design','media','seo','forms']","'editor'=>['pages','products','design','media','seo','forms']",'editor permissions');
        if($path==='routes/pages.php'){
            $managed="\$p['type']==='product'&&(decode_json(\$p['fields_json'])['benos_product']['version']??null)==='bnp-1'";
            $replace("\$p=\$service->find((int)\$args['id']);\$isArticle=","\$p=\$service->find((int)\$args['id']);if(".$managed.")return redirect(\$response,'/admin/products/'.\$p['id'].'/edit');\$isArticle=",'managed product editor redirect');
            $replace("require_permission('pages');return \$editorResult(\$response,fn()=>['ok'=>true]+\$service->save((int)\$args['id'],input(\$request)));","require_permission('pages');\$p=\$service->find((int)\$args['id']);if(".$managed.")throw new RuntimeException('请在产品管理中修改产品资料。',422);return \$editorResult(\$response,fn()=>['ok'=>true]+\$service->save((int)\$args['id'],input(\$request)));",'managed product generic update guard');
        }
        if($path==='views/layout.php'){
            $replace("\$moduleAssets=['media'", "\$moduleAssets=['products'=>['products-admin.css'],'media'",'product styles');
            $replace("['blog','/admin/blog','博客管理','pages']","['products','/admin/products','产品管理','products'],['blog','/admin/blog','博客管理','pages']",'product navigation');
        }
        if($path==='src/ui.php')$replace("    \$paths=[", "    \$paths=[\n        'products'=>'<path d=\"m12 3 9 5v8l-9 5-9-5V8zM3 8l9 5 9-5M12 13v8M7.5 5.5l9 5\"/>',\n", 'product icon');
        if($path==='src/Services/PageService.php'){
            $replace("\$previousFields=\\decode_json(\$p['fields_json']);", "\$previousFields=\\decode_json(\$p['fields_json']);\n                if(isset(\$previousFields[ProductService::FIELD])){if(\$type!=='product')throw new \\RuntimeException('请在产品管理中编辑产品，不能更改为其他内容类型。',422);if(!array_key_exists(ProductService::FIELD,\$fields))\$fields[ProductService::FIELD]=\$previousFields[ProductService::FIELD];}", 'preserve product fields');
            $replace("\$fields=PageHiddenContent::fields(\\decode_json(\$p['fields_json']),\$p['type'],false);", "ProductService::validateManagedPage(\$p);\n                \$fields=PageHiddenContent::fields(\\decode_json(\$p['fields_json']),\$p['type'],false);",'product publication validation');
        }
        require_once dirname(__DIR__).'/product-catalog/ProductsOverlay.php';
        // A product-only release can keep parallel font work outside its verified scope.
        if(($features['fonts']??true)===false)return \Benos\ProductsOverlay::transform($path,$source);
        require_once __DIR__.'/FontsOverlay.php';
        return \Benos\FontsOverlay::transform($path,\Benos\ProductsOverlay::transform($path,$source));
    }
}
