<?php
declare(strict_types=1);
namespace Benos;
final class Entitlement {
    public static function read(string $root,array $connection):?array {
        $path=$root.'/storage/private/benos-entitlement.json';if(!is_file($path)||is_link($path))return null;
        try{$stored=json_decode(file_get_contents($path),true,32,JSON_THROW_ON_ERROR);$lease=$stored['lease']??null;if(!is_array($lease)||!hash_equals(hash_hmac('sha256',json_encode($lease,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),$connection['signingSecret']),(string)($stored['signature']??''))||($lease['siteId']??null)!==$connection['siteId'])return null;return $lease;}catch(\Throwable){return null;}
    }
    public static function apply(string $root,array $connection,array $input):array {
        $issued=$input['issuedAt']??null;$until=$input['validUntil']??null;$active=$input['hostingActive']??null;$publish=$input['publishAllowed']??null;
        if(!is_int($issued)||!is_int($until)||abs(time()-$issued)>120||$until<$issued||$until>$issued+21600||!is_bool($active)||!is_bool($publish)||!$active&&$publish)throw new ProtocolError('ENTITLEMENT_INVALID');
        $lease=['siteId'=>$connection['siteId'],'issuedAt'=>$issued,'validUntil'=>$until,'hostingActive'=>$active,'publishAllowed'=>$publish];$previous=self::read($root,$connection);
        if($previous&&($previous['issuedAt']>$issued||$previous['issuedAt']===$issued&&$previous!==$lease))throw new ProtocolError('ENTITLEMENT_STALE',409);
        $stored=['lease'=>$lease,'signature'=>hash_hmac('sha256',json_encode($lease,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),$connection['signingSecret'])];Protocol::writePrivateJson($root.'/storage/private/benos-entitlement.json',$stored,'ENTITLEMENT_WRITE_FAILED');
        return ['siteId'=>$connection['siteId'],'issuedAt'=>$issued,'validUntil'=>$until,'hostingActive'=>$active,'publishAllowed'=>$publish];
    }
    public static function allowed(string $root,array $connection,bool $publishing=false):bool {$lease=self::read($root,$connection);return $lease&&$lease['hostingActive']===true&&$lease['validUntil']>time()&&(!$publishing||$lease['publishAllowed']===true);}
    public static function assertPublication(string $root):void {
        if(!self::publicationAllowed($root))throw new \RuntimeException('发布权限已暂停；可以继续查看后台并保存草稿。',403);
    }
    public static function publicationAllowed(string $root):bool {$file=$root.'/storage/private/benos-connection.json';$connection=is_file($file)&&!is_link($file)?json_decode(file_get_contents($file),true):null;return is_array($connection)&&self::allowed($root,$connection,true);}
    public static function denyUnmanagedUpdate():never {throw new \RuntimeException('此网站由平台托管，请使用保留托管权限校验的平台发行版本更新。',409);}
    // Fixed 1.9.21 route inventory. Drafts and public form submissions are allowed.
    public static function publicationRequest(string $method,string $uri,array $data=[]):bool {
        if(in_array(strtoupper($method),['GET','HEAD','OPTIONS'],true))return false;
        $path=rawurldecode((string)parse_url($uri,PHP_URL_PATH));
        if(preg_match('~^/admin/(?:pages|blog|products)/[0-9]+/action$~D',$path)||$path==='/admin/blog/bulk')return in_array($data['action']??'', ['publish','home','archive','unpublish'],true);
        if($path==='/admin/products/settings')return true;
        if(preg_match('~^/admin/api/forms(?:/[0-9]+)?$~D',$path))return !empty($data['publish']);
        if($path==='/admin/settings')return !in_array($data['tab']??'general',['mail','security'],true);
        if($path==='/admin/menus')return !empty($data['use_default']);
        foreach([
            '~^/admin/api/(?:pages|blog|templates|products)/[0-9]+/publish$~D',
            '~^/admin/api/blog/[0-9]+/schedule$~D',
            '~^/admin/pages/[0-9]+/delete$~D',
            '~^/admin/templates/[0-9]+/(?:apply-global|activate)$~D',
            '~^/admin/(?:templates/style|design)$~D',
            '~^/admin/site-kits/(?:[0-9]+/apply|deployments/[0-9]+/rollback)$~D',
            '~^/admin/api/forms/[0-9]+/(?:status|restore)$~D',
            '~^/admin/menus/[0-9]+(?:/delete)?$~D',
            '~^/admin/blog/(?:settings|taxonomy(?:/[0-9]+/delete)?)$~D',
            '~^/admin/blog/authors/(?:new|[0-9]+/(?:edit|action)|template/action)$~D',
            '~^/admin/settings/site-address$~D',
            '~^/admin/seo/redirects(?:/[0-9]+/delete)?$~D',
            '~^/admin/(?:api/)?media/[0-9]+(?:/(?:trash|restore|purge))?$~D',
            '~^/admin/seo/ops/[0-9]+/(?:run|resume)$~D',
        ] as $pattern)if(preg_match($pattern,$path))return true;
        return false;
    }
    private static function requestData():array {
        if($_POST)return $_POST;
        $raw=file_get_contents('php://input',false,null,0,12*1048576+1);if(strlen($raw)>12*1048576)return [];
        $data=json_decode($raw,true,128);if(is_array($data))return $data;
        if(str_contains(strtolower($_SERVER['CONTENT_TYPE']??''),'application/x-www-form-urlencoded')){parse_str($raw,$data);return $data;}
        return [];
    }
    public static function guard(string $root):void {
        // The connector has its own signed authorization and must remain able to
        // renew an expired lease. Normal CMS HTTP/CLI entry points fail closed.
        if(defined('BENOS_CONTROLLED_CONNECTOR')&&BENOS_CONTROLLED_CONNECTOR===true)return;
        $file=$root.'/storage/private/benos-connection.json';$connection=is_file($file)?json_decode(file_get_contents($file),true):null;
        if(is_array($connection)&&self::allowed($root,$connection)){
            $path=rawurldecode((string)parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH));$method=strtoupper($_SERVER['REQUEST_METHOD']??'GET');
            if(!in_array($method,['GET','HEAD','OPTIONS'],true)&&$path==='/admin/settings/site-address')self::reject('MANAGED_DOMAIN_REQUIRED','请在平台的网站与域名管理中更换正式网址。',409);
            // Full recovery archives contain platform-owned DB and signing keys.
            // Keep them private; a CMS account must not obtain lease signing keys.
            if(preg_match('~^/admin/system/backups/[0-9]+$~D',$path))self::reject('MANAGED_BACKUP_PRIVATE','完整恢复备份由平台保管，请在平台处理网站恢复。',403);
            if(!in_array($method,['GET','HEAD','OPTIONS'],true)&&preg_match('~^/admin/api/system/updates/(?:source|download|install|setup-worker|retry)$~D',$path))self::reject('MANAGED_UPDATE_REQUIRED','请通过平台管理受管网站的发行版本更新。',409);
            // CLI publication itself is guarded in PageService/TemplateService.
            // SEO operations can also write live settings outside those services.
            $cliMutation=PHP_SAPI==='cli'&&in_array(basename($_SERVER['SCRIPT_FILENAME']??''),['seo-ops-worker.php'],true);
            if(!self::allowed($root,$connection,true)&&($cliMutation||self::publicationRequest($method,$path,self::requestData())))self::reject('PUBLICATION_FROZEN','发布权限已暂停；可以继续查看后台并保存草稿。',403);
            return;
        }
        if(PHP_SAPI==='cli'){fwrite(STDERR,"Hosting entitlement is inactive. Data has been retained.\n");exit(75);}
        http_response_code(503);header('Cache-Control: no-store, max-age=0');header('Retry-After: 300');header('Content-Type: text/html; charset=utf-8');header('X-Robots-Tag: noindex');exit('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>网站服务暂停</title><main style="font:16px system-ui;max-width:560px;margin:15vh auto;padding:24px"><h1>网站服务暂时暂停</h1><p>网站内容已保留，请网站所有者在平台控制台检查托管服务状态。</p></main></html>');
    }
    private static function reject(string $code,string $message,int $status):never {
        if(PHP_SAPI==='cli'){fwrite(STDERR,$code.': '.$message."\n");exit(75);}
        http_response_code($status);header('Cache-Control: no-store');header('Content-Type: application/json; charset=utf-8');exit(json_encode(['error'=>['code'=>$code,'message'=>$message]],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }
}
