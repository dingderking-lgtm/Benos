<?php
declare(strict_types=1);
namespace Benos;
final class FontsOverlay {
    public static function transform(string $path,string $source):string {
        if ($path !== 'src/Services/Renderer.php') return $source;
        $needle = "    public function sanitizeCss(string \$css, bool \$keyframes = false): string\n    {";
        $insert = <<<'FONT_PATCH'
        // Only the platform's explicit font catalog may load a remote stylesheet.
        $fontImports = [];
        $fontFamilies = ['Inter','Roboto','Open+Sans','Lato','Montserrat','Poppins','Roboto+Condensed','Oswald','Raleway','Nunito','Nunito+Sans','Merriweather','Playfair+Display','Lora','PT+Sans','PT+Serif','Ubuntu','Rubik','Work+Sans','Source+Sans+3','Fira+Sans','Noto+Sans','Noto+Serif','DM+Sans','Mulish','Manrope','Quicksand','Karla','Barlow','Roboto+Slab','Noto+Sans+SC','Noto+Serif+SC'];
        $css = preg_replace_callback('~@import url\("https://fonts\.googleapis\.com/css2\?family=([A-Za-z0-9+]+):wght@400;700&display=swap"\);~', static function ($m) use (&$fontImports, $fontFamilies) {
            if (!in_array($m[1], $fontFamilies, true)) { return $m[0]; }
            $fontImports[$m[1]] = $m[0]; return '';
        }, $css) ?? $css;
FONT_PATCH;
        $source = str_replace($needle, $needle . "\n" . $insert, $source, $count);
        if ($count !== 1) throw new \RuntimeException('Pinned font renderer hook changed.');
        $start = strpos($source, $needle);
        $end = strpos($source, '    private function splitOutside', $start);
        $part = substr($source, $start, $end - $start);
        $part = str_replace('return $out;', 'return implode("\n", $fontImports) . $out;', $part, $count);
        if ($count !== 1) throw new \RuntimeException('Pinned font return hook changed.');
        $source = substr($source, 0, $start) . $part . substr($source, $end);
        // @import must precede the native root and container rules as well.
        $start = strpos($source, '    public function globalStyleCss(): string');
        $end = strpos($source, '    public function pageHtml(', $start);
        $part = substr($source, $start, $end - $start);
        $part = str_replace('        return $css;', $insert . "\n" . '        return implode("\n", $fontImports) . $css;', $part, $count);
        if ($count !== 1) throw new \RuntimeException('Pinned global font hook changed.');
        return substr($source, 0, $start) . $part . substr($source, $end);
    }
}
