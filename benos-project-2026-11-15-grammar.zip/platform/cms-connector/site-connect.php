<?php
declare(strict_types=1);
ini_set('display_errors','0');
use Benos\Protocol;use Benos\ProtocolError;
$root=dirname(__DIR__);$private=$root.'/storage/private';$identity=null;$lock=null;$runtime=null;
require $private.'/BenosProtocol.php';
try{
    $connection=json_decode(file_get_contents($private.'/benos-connection.json'),true,32,JSON_THROW_ON_ERROR);
    if(empty($_SERVER['HTTPS'])||strtolower((string)$_SERVER['HTTPS'])==='off'){if(empty($connection['testMode'])||!in_array($_SERVER['REMOTE_ADDR']??'',['127.0.0.1','::1'],true))throw new ProtocolError('HTTPS_REQUIRED',403);}
    if(($_SERVER['REQUEST_METHOD']??'')!=='POST')throw new ProtocolError('METHOD_DENIED',405);
    $raw=file_get_contents('php://input',false,null,0,10*1048576+1);
    // Own the runtime before any private nonce or entitlement mutation, just
    // as backup/publication owns EX and the other HTTP entries own SH.
    $runtimePath=$root.'/storage/runtime.lock';if(is_link($runtimePath))throw new ProtocolError('CMS_RUNTIME_UNSAFE',503);$runtime=fopen($runtimePath,'c');if(!$runtime||!flock($runtime,LOCK_EX|LOCK_NB))throw new ProtocolError('CMS_BUSY',503);
    $lock=fopen($root.'/storage/benos-connect.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new ProtocolError('CONNECTOR_BUSY',503);
    $file=$private.'/benos-connect-nonces.json';$nonces=is_file($file)?json_decode(file_get_contents($file),true):[];
    $identity=Protocol::verify(getallheaders(),'POST',$_SERVER['REQUEST_URI']??'',$raw,[$connection['keyId']=>$connection['signingSecret']],'BENOS-CMS-V1',function($nonce,$expiry)use(&$nonces,$file){foreach($nonces as $key=>$expires)if($expires<time())unset($nonces[$key]);if(isset($nonces[$nonce]))throw new ProtocolError('REPLAY_DENIED',409);if(count($nonces)>10000)throw new ProtocolError('RATE_LIMITED',429);$nonces[$nonce]=$expiry;Protocol::writePrivateJson($file,$nonces);});
    if($identity['siteId']!==$connection['siteId'])throw new ProtocolError('FORBIDDEN',403);
    $input=json_decode($raw,true,128,JSON_THROW_ON_ERROR);if(!is_array($input))throw new ProtocolError('INPUT_INVALID');
    require $private.'/BenosEntitlement.php';
    if(($input['operation']??'')==='entitlement'){$result=Benos\Entitlement::apply($root,$connection,$input);$response=Protocol::response($identity,200,$result);}
    else {
    if(!in_array($input['operation']??'',['status','preview','preview-render-bundle','preview-artifact-chunk','preview-status','preview-discard'],true)&&!Benos\Entitlement::allowed($root,$connection,true))throw new ProtocolError('HOSTING_ENTITLEMENT_INACTIVE',403);
    define('BENOS_CONTROLLED_CONNECTOR',true);require $root.'/src/bootstrap.php';$_SESSION=[];require $private.'/BenosAssetPolicy.php';require $private.'/BenosBundle.php';require $private.'/BenosPublisher.php';
    if(($input['operation']??'')==='change-domain'){require $private.'/BenosManagement.php';$result=Benos\Management::domain($input,$connection);}
    elseif(in_array($input['operation']??'',['preview-render-bundle','preview-artifact-chunk','preview-status','preview-discard'],true)){require $private.'/BenosPreview.php';require $private.'/BenosPreviewBundle.php';$result=(new Benos\PreviewBundle($root,$connection))->dispatch($input);}
    elseif(($input['operation']??'')==='preview'){require $private.'/BenosPreview.php';$result=(new Benos\Preview)->render($input);}
    else $result=(new Benos\Publisher)->dispatch($input);$response=is_string($result)?Protocol::rawResponse($identity,200,$result):Protocol::response($identity,200,$result);
    }
}catch(Throwable $error){$status=$error instanceof ProtocolError?$error->status:((int)$error->getCode()===422?422:503);$code=$error instanceof ProtocolError?$error->errorCode:'CMS_PUBLICATION_UNAVAILABLE';$response=$identity?Protocol::response($identity,$status,['error'=>['code'=>$code]]):['status'=>$status,'body'=>json_encode(['error'=>['code'=>$code]]),'headers'=>['Content-Type'=>'application/json','Cache-Control'=>'no-store']];}
finally{foreach([$lock,$runtime] as $handle)if(is_resource($handle)){flock($handle,LOCK_UN);fclose($handle);}}
Protocol::emit($response);
