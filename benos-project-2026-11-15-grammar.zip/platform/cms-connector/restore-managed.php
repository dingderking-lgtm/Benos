<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
ini_set('display_errors','0');
try{
    define('BASE_PATH',dirname(__DIR__));
    require BASE_PATH.'/vendor/autoload.php';
    require BASE_PATH.'/storage/private/BenosNativeInstaller.php';
    require BASE_PATH.'/storage/private/BenosProtocol.php';
    require BASE_PATH.'/storage/private/BenosManagedRestore.php';
    $args=getopt('',['archive:','sha256:','target-config:','inspect']);
    echo json_encode(\Benos\ManagedRestore::run(BASE_PATH,$args),JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR).PHP_EOL;
}catch(Throwable $error){
    // Never expose DB credentials, the app key, SQL rows or exception traces.
    $code=preg_match('/^[A-Z][A-Z0-9_]{3,80}$/D',$error->getMessage())?$error->getMessage():'RECOVERY_FAILED';
    fwrite(STDERR,json_encode(['restored'=>false,'error'=>$code,'note'=>'No existing site is overwritten. Any new partial database remains quarantined; use a fresh target for retry.']).PHP_EOL);exit(1);
}
