<?php
declare(strict_types=1);
// Copied to a new site's public/benos-health.php by the controlled installer.
$root=dirname(__DIR__);$private=$root.'/storage/private';$identity=null;$runtime=null;$lock=null;
require $private.'/BenosProtocol.php';
use Benos\Protocol;use Benos\ProtocolError;
try{
    if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET')throw new ProtocolError('METHOD_DENIED',405);
    $connection=json_decode(file_get_contents($private.'/benos-connection.json'),true,32,JSON_THROW_ON_ERROR);
    $https=isset($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off';
    if(!$https&&!( !empty($connection['testMode'])&&in_array($_SERVER['REMOTE_ADDR']??'',['127.0.0.1','::1'],true)))throw new ProtocolError('HTTPS_REQUIRED',403);
    // All connector HTTP writes acquire runtime before their nonce lock.
    $runtimePath=$root.'/storage/runtime.lock';if(is_link($runtimePath))throw new ProtocolError('CMS_RUNTIME_UNSAFE',503);$runtime=fopen($runtimePath,'c');if(!$runtime||!flock($runtime,LOCK_SH|LOCK_NB))throw new ProtocolError('CMS_BUSY',503);
    $lock=fopen($private.'/benos-health.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new ProtocolError('BUSY',503);
    try{
        $file=$private.'/benos-health-nonces.json';$nonces=is_file($file)?json_decode(file_get_contents($file),true):[];
        $identity=Protocol::verify(getallheaders(),'GET',$_SERVER['REQUEST_URI']??'','',[$connection['keyId']=>$connection['signingSecret']],'BENOS-CMS-V1',function($nonce,$expires)use(&$nonces,$file){
            foreach($nonces as $key=>$expiry)if($expiry<time())unset($nonces[$key]);
            if(isset($nonces[$nonce]))throw new ProtocolError('REPLAY_DENIED',409);
            if(count($nonces)>10000)throw new ProtocolError('RATE_LIMITED',429);
            $nonces[$nonce]=$expires;Protocol::writePrivateJson($file,$nonces);
        });
    }finally{flock($lock,LOCK_UN);fclose($lock);$lock=null;}
    if($identity['siteId']!==$connection['siteId'])throw new ProtocolError('FORBIDDEN',403);
    $config=require $root.'/config/local.php';if(empty($config['installed']))throw new ProtocolError('CMS_NOT_INSTALLED',503);
    $pdo=new PDO('mysql:host='.$config['db_host'].';port='.$config['db_port'].';dbname='.$config['db_name'].';charset=utf8mb4',$config['db_user'],$config['db_password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    $pdo->query('SELECT version FROM schema_migrations LIMIT 1')->fetchColumn();
    $response=Protocol::response($identity,200,['siteId'=>$connection['siteId'],'installed'=>true,'database'=>'ready','cmsVersion'=>$connection['cmsVersion'],'capabilities'=>['bundleReceiveV2','bundlePublishV2','bundlePreviewV2']]);
}catch(Throwable $error){$status=$error instanceof ProtocolError?$error->status:503;$code=$error instanceof ProtocolError?$error->errorCode:'CMS_HEALTH_UNAVAILABLE';$response=$identity?Protocol::response($identity,$status,['error'=>['code'=>$code]]):['status'=>$status,'body'=>json_encode(['error'=>['code'=>$code]]),'headers'=>['Content-Type'=>'application/json','Cache-Control'=>'no-store']];}
finally{foreach([$lock,$runtime] as $handle)if(is_resource($handle)){flock($handle,LOCK_UN);fclose($handle);}}
Protocol::emit($response);
