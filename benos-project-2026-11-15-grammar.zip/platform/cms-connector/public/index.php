<?php
declare(strict_types=1);
require dirname(__DIR__).'/src/Bridge.php';
use Benos\Bridge;use Benos\Protocol;use Benos\ProtocolError;
try{
    $file=getenv('BENOS_BRIDGE_CONFIG')?:'';
    if(!$file||!is_file($file)||is_link($file))throw new ProtocolError('BRIDGE_NOT_CONFIGURED',503);
    $real=realpath($file);$public=realpath(__DIR__);
    if(!$real||str_starts_with(str_replace('\\','/',$real),str_replace('\\','/',$public).'/'))throw new ProtocolError('PRIVATE_CONFIGURATION_REQUIRED',503);
    $config=require $file;if(!is_array($config))throw new ProtocolError('BRIDGE_NOT_CONFIGURED',503);
    $secure=isset($_SERVER['HTTPS'])&&strtolower((string)$_SERVER['HTTPS'])!=='off';
    $localTest=!empty($config['testMode'])&&in_array($_SERVER['REMOTE_ADDR']??'', ['127.0.0.1','::1'],true);
    if(!$secure&&!$localTest)throw new ProtocolError('HTTPS_REQUIRED',403);
    if((int)($_SERVER['CONTENT_LENGTH']??0)>16384)throw new ProtocolError('REQUEST_TOO_LARGE',413);
    $body=file_get_contents('php://input',false,null,0,16385);$headers=function_exists('getallheaders')?getallheaders():[];
    Protocol::emit((new Bridge($config))->dispatch($_SERVER['REQUEST_METHOD']??'GET',$_SERVER['REQUEST_URI']??'/',(string)$body,$headers));
}catch(ProtocolError $error){http_response_code($error->status);header('Content-Type: application/json');header('Cache-Control: no-store');echo json_encode(['error'=>['code'=>$error->errorCode]]);}
catch(Throwable $error){error_log('Benos bridge request failed ['.get_class($error).']');http_response_code(503);header('Content-Type: application/json');header('Cache-Control: no-store');echo '{"error":{"code":"BRIDGE_UNAVAILABLE"}}';}
