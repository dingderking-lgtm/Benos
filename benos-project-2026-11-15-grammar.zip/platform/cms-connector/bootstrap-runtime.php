<?php
declare(strict_types=1);
// Uploaded only to a newly verified, dedicated hPanel website. The platform
// injects a per-job bootstrap identity; CMS DB/admin passwords arrive in a
// signed HTTPS request and are never embedded in this uploaded program.
ini_set('display_errors','0');
$bootstrap=json_decode(base64_decode('__BENOS_BOOTSTRAP_CONFIG_BASE64__',true),true,32,JSON_THROW_ON_ERROR);
$identity=null;$lock=null;
function benos_bootstrap_error(string $code,int $status=409):never {throw new RuntimeException($code,$status);}
function benos_bootstrap_atomic(string $path,array $data):void {$tmp=$path.'.'.bin2hex(random_bytes(8));if(is_link($path)||file_put_contents($tmp,json_encode($data,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),LOCK_EX)===false)benos_bootstrap_error('BOOTSTRAP_STATE_FAILED',503);chmod($tmp,0600);if(!rename($tmp,$path))benos_bootstrap_error('BOOTSTRAP_STATE_FAILED',503);}
function benos_bootstrap_b64(string $value):string{return rtrim(strtr(base64_encode($value),'+/','-_'),'=');}
function benos_bootstrap_link(string $path):bool {
    if(is_link($path))return true;
    if(!file_exists($path))return false;
    $real=realpath($path);if($real===false)return true;
    $real=preg_replace('~/+~','/',str_replace('\\','/',$real));$path=preg_replace('~/+~','/',str_replace('\\','/',$path));
    // PHP on Windows can report directory junctions as neither is_link nor
    // is_dir. The resolved identity must still equal the exact owned path.
    return PHP_OS_FAMILY==='Windows'?strcasecmp($real,$path)!==0:$real!==$path;
}
function benos_bootstrap_extract(ZipArchive $zip,string $root,string $name,string $sha):void {
    $target=$root.'/'.$name;$parent=dirname($target);$cursor=$root;
    foreach(explode('/',dirname($name)) as $part){if($part==='.')continue;$cursor.='/'.$part;if(benos_bootstrap_link($cursor))benos_bootstrap_error('TARGET_SYMLINK_DENIED');}
    if(benos_bootstrap_link($target))benos_bootstrap_error('TARGET_SYMLINK_DENIED');
    if(is_file($target)){if(!hash_equals($sha,hash_file('sha256',$target)))benos_bootstrap_error('TARGET_FILE_CHANGED');return;}
    if(file_exists($target))benos_bootstrap_error('TARGET_FILE_CHANGED');
    if(!is_dir($parent)&&!mkdir($parent,0750,true))benos_bootstrap_error('TARGET_UNAVAILABLE',503);
    $tmp=$target.'.benos.tmp';
    if(benos_bootstrap_link($tmp)||file_exists($tmp)&&!is_file($tmp))benos_bootstrap_error('TARGET_SYMLINK_DENIED');
    // This runs only after the exact job/site ownership check and under the
    // installation lock. Recover our own interrupted staging write; never
    // replace a destination file or accept bytes outside the release inventory.
    if(is_file($tmp)&&!hash_equals($sha,hash_file('sha256',$tmp))&&!unlink($tmp))benos_bootstrap_error('TARGET_WRITE_FAILED',503);
    if(!is_file($tmp)){
        $stream=$zip->getStream($name);$output=fopen($tmp,'xb');
        if(!$stream||!$output){if(is_resource($stream))fclose($stream);if(is_resource($output))fclose($output);benos_bootstrap_error('TARGET_UNAVAILABLE',503);}
        try{if(stream_copy_to_stream($stream,$output)===false)benos_bootstrap_error('TARGET_WRITE_FAILED',503);}finally{fclose($stream);fclose($output);}
    }
    if(!hash_equals($sha,hash_file('sha256',$tmp))||is_link($target)||file_exists($target)||!rename($tmp,$target))benos_bootstrap_error('TARGET_WRITE_FAILED',503);
    chmod($target,str_starts_with($name,'storage/private/')?0600:0644);
}
try{
    if(($bootstrap['expiresAt']??0)<time())benos_bootstrap_error('BOOTSTRAP_EXPIRED',403);
    $test=!empty($bootstrap['testMode'])&&in_array($_SERVER['REMOTE_ADDR']??'',['127.0.0.1','::1'],true);
    if(!$test&&(empty($_SERVER['HTTPS'])||strtolower((string)$_SERVER['HTTPS'])==='off'))benos_bootstrap_error('HTTPS_REQUIRED',403);
    if(!$test&&strtolower((string)($_SERVER['HTTP_HOST']??''))!==$bootstrap['domain'])benos_bootstrap_error('BOOTSTRAP_DOMAIN_MISMATCH',403);
    if(($_SERVER['REQUEST_METHOD']??'')!=='POST')benos_bootstrap_error('METHOD_DENIED',405);
    $body=file_get_contents('php://input',false,null,0,16385);if(strlen($body)>16384)benos_bootstrap_error('REQUEST_TOO_LARGE',413);
    $headers=array_change_key_case(getallheaders(),CASE_LOWER);$timestamp=(string)($headers['x-benos-timestamp']??'');$nonce=(string)($headers['x-benos-nonce']??'');$idem=(string)($headers['idempotency-key']??'');$path=(string)($_SERVER['REQUEST_URI']??'');
    if(($headers['x-benos-key-id']??'')!==$bootstrap['keyId']||($headers['x-benos-site-id']??'')!==$bootstrap['siteId']||!preg_match('/^\d{10,12}$/D',$timestamp)||abs(time()-(int)$timestamp)>120||!preg_match('/^[A-Za-z0-9_-]{22,80}$/D',$nonce)||!preg_match('/^[A-Za-z0-9_-]{8,160}$/D',$idem)||$path!=='/'.basename(__FILE__))benos_bootstrap_error('UNAUTHORIZED',401);
    $canonical=implode("\n",['BENOS-BRIDGE-V1',$bootstrap['keyId'],$bootstrap['siteId'],$timestamp,$nonce,'POST',$path,hash('sha256',$body),$idem]);
    if(!hash_equals(benos_bootstrap_b64(hash_hmac('sha256',$canonical,$bootstrap['signingSecret'],true)),(string)($headers['x-benos-signature']??'')))benos_bootstrap_error('UNAUTHORIZED',401);
    $identity=['nonce'=>$nonce];$input=json_decode($body,true,32,JSON_THROW_ON_ERROR);
    if(!is_array($input)||($input['jobId']??'')!==$bootstrap['jobId']||($input['siteId']??'')!==$bootstrap['siteId']||($input['domain']??'')!==$bootstrap['domain']||($input['schemaVersion']??null)!==1)benos_bootstrap_error('BOOTSTRAP_IDENTITY_INVALID');
    $finalized=__DIR__.'/storage/private/benos-bootstrap-finalized.json';
    if(is_file($finalized)&&($input['operation']??'')!=='finalize')benos_bootstrap_error('BOOTSTRAP_FINALIZED',410);
    if(($input['operation']??'')==='finalize'){
        $owner=is_file(__DIR__.'/.benos-owner.json')?json_decode(file_get_contents(__DIR__.'/.benos-owner.json'),true):null;
        if(!is_array($owner)||($owner['jobId']??'')!==$bootstrap['jobId']||($owner['siteId']??'')!==$bootstrap['siteId']||!is_file(__DIR__.'/config/local.php')||!is_file(__DIR__.'/storage/private/benos-connection.json'))benos_bootstrap_error('BOOTSTRAP_NOT_INSTALLED');
        benos_bootstrap_atomic($finalized,['jobId'=>$bootstrap['jobId'],'siteId'=>$bootstrap['siteId'],'finalizedAt'=>time()]);$result=['jobId'=>$bootstrap['jobId'],'siteId'=>$bootstrap['siteId'],'finalized'=>true];$status=200;
    }elseif(($input['operation']??'')==='probe'){
        // A signed, nonce-bound read proves the public domain reaches this exact
        // uploaded bootstrap BEFORE any database/admin password is transmitted.
        $result=['jobId'=>$bootstrap['jobId'],'siteId'=>$bootstrap['siteId'],'bootstrapReady'=>true,'releaseSha256'=>$bootstrap['releaseSha256']];$status=200;
        $owner=is_file(__DIR__.'/.benos-owner.json')?json_decode(file_get_contents(__DIR__.'/.benos-owner.json'),true):null;$savedConnection=is_file(__DIR__.'/storage/private/benos-connection.json')?json_decode(file_get_contents(__DIR__.'/storage/private/benos-connection.json'),true):null;
        if(is_array($owner)&&($owner['jobId']??'')===$bootstrap['jobId']&&($owner['siteId']??'')===$bootstrap['siteId']&&is_array($savedConnection)&&($savedConnection['siteId']??'')===$bootstrap['siteId']&&is_file(__DIR__.'/config/local.php')){
            $installed=require __DIR__.'/config/local.php';if(!empty($installed['installed'])&&($installed['app_url']??'')==='https://'.$bootstrap['domain'])$result+=['state'=>'awaiting_input','step'=>'verify_domain_https','cmsInstalled'=>true,'cmsVersion'=>'1.9.21','connection'=>['origin'=>'https://'.$bootstrap['domain'],'keyId'=>$savedConnection['keyId'],'healthPath'=>'/benos-health.php','signingSecret'=>$savedConnection['signingSecret']]];
        }
    }else{
    $db=$input['database']??[];
    foreach(['name','user'] as $key)if(!is_string($db[$key]??null)||!str_starts_with($db[$key],$bootstrap['accountUsername'].'_')||!preg_match('/^[A-Za-z0-9_]{1,32}$/D',$db[$key]))benos_bootstrap_error('DATABASE_SCOPE_INVALID');
    if(!is_string($db['password']??null)||strlen($db['password'])<24||strlen($db['password'])>256||!is_string($input['name']??null)||trim($input['name'])===''||mb_strlen($input['name'])>120||!filter_var($input['cmsAdminEmail']??'',FILTER_VALIDATE_EMAIL)||!is_string($input['cmsAdminPassword']??null)||strlen($input['cmsAdminPassword'])<12||strlen($input['cmsAdminPassword'])>1024)benos_bootstrap_error('BOOTSTRAP_INPUT_INVALID');
    $expiry=strtotime((string)($input['passwordExpiresAt']??''));if(!$expiry||$expiry<time()||$expiry>time()+901)benos_bootstrap_error('PASSWORD_EXPIRED');
    $root=str_replace('\\','/',__DIR__);$ownerFile=$root.'/.benos-owner.json';$owned=is_file($ownerFile)?json_decode(file_get_contents($ownerFile),true):null;
    $fingerprint=hash('sha256',json_encode([$bootstrap['siteId'],$bootstrap['jobId'],$bootstrap['domain'],$input['name'],$input['cmsAdminEmail'],$db['name'],$db['user']],JSON_THROW_ON_ERROR));
    if($owned){if(($owned['identityHash']??'')!==$fingerprint)benos_bootstrap_error('TARGET_NOT_OWNED');}
    else{
        foreach(new DirectoryIterator($root) as $entry)if(!$entry->isDot()&&!in_array($entry->getFilename(),[basename(__FILE__),$bootstrap['releaseFilename']],true))benos_bootstrap_error('TARGET_NOT_EMPTY');
        benos_bootstrap_atomic($ownerFile,['siteId'=>$bootstrap['siteId'],'jobId'=>$bootstrap['jobId'],'domain'=>$bootstrap['domain'],'identityHash'=>$fingerprint]);
    }
    $lock=fopen($root.'/.benos-bootstrap.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))benos_bootstrap_error('BOOTSTRAP_BUSY',503);
    $nonceFile=$root.'/.benos-bootstrap-nonces.json';$nonces=is_file($nonceFile)?json_decode(file_get_contents($nonceFile),true):[];foreach($nonces as $key=>$expiry)if($expiry<time())unset($nonces[$key]);if(isset($nonces[$nonce]))benos_bootstrap_error('REPLAY_DENIED');$nonces[$nonce]=time()+300;benos_bootstrap_atomic($nonceFile,$nonces);
    $configuration=$root.'/config/local.php';
    if(!is_file($configuration)){
        $archive=$root.'/'.$bootstrap['releaseFilename'];if(is_link($archive)||!is_file($archive)||filesize($archive)!==$bootstrap['releaseSize']||!hash_equals($bootstrap['releaseSha256'],hash_file('sha256',$archive)))benos_bootstrap_error('DISTRIBUTION_CHECKSUM_INVALID');
        $zip=new ZipArchive;if($zip->open($archive)!==true)benos_bootstrap_error('DISTRIBUTION_INVALID');
        $manifest=json_decode((string)$zip->getFromName('BENOS-RELEASE.json'),true,32,JSON_THROW_ON_ERROR);
        if(($manifest['format']??'')!=='benos-cms-release'||($manifest['version']??null)!==1||($manifest['cmsVersion']??'')!=='1.9.21'||($manifest['baselineCommit']??'')!=='2152113a4ef6ac07e119074dfdbf40f79647d109'||!is_array($manifest['files']??null))benos_bootstrap_error('DISTRIBUTION_BASELINE_INVALID');
        if($zip->numFiles!==count($manifest['files'])+1||$zip->numFiles>50000)benos_bootstrap_error('DISTRIBUTION_INVENTORY_INVALID');$total=0;$seen=[];
        for($i=0;$i<$zip->numFiles;$i++){$stat=$zip->statIndex($i);$name=$stat['name'];if($name==='BENOS-RELEASE.json')continue;if(!preg_match('~^[A-Za-z0-9_.@/-]+$~D',$name)||str_contains($name,'..')||str_starts_with($name,'/')||isset($seen[$name])||!isset($manifest['files'][$name])||$name==='config/local.php'||preg_match('~(?:^|/)(?:\.env|\.git)(?:$|/)~',$name)||$stat['size']>64*1048576)benos_bootstrap_error('DISTRIBUTION_PATH_INVALID');$seen[$name]=true;$total+=$stat['size'];if($total>800*1048576)benos_bootstrap_error('DISTRIBUTION_TOO_LARGE');if($zip->getExternalAttributesIndex($i,$opsys,$attr)&&(($attr>>16)&0170000)===0120000)benos_bootstrap_error('DISTRIBUTION_SYMLINK_DENIED');$stream=$zip->getStream($name);$hash=hash_init('sha256');hash_update_stream($hash,$stream);fclose($stream);if(!hash_equals((string)$manifest['files'][$name],hash_final($hash)))benos_bootstrap_error('DISTRIBUTION_FILE_INVALID');}
        foreach($manifest['files'] as $name=>$sha)benos_bootstrap_extract($zip,$root,$name,$sha);
        $zip->close();require_once $root.'/storage/private/BenosProtocol.php';require_once $root.'/storage/private/BenosNativeInstaller.php';
        $database=['host'=>$test?($bootstrap['testDatabaseHost']??'127.0.0.1'):'localhost','port'=>$test?($bootstrap['testDatabasePort']??3306):3306,'name'=>$db['name'],'user'=>$db['user'],'password'=>$db['password']];Benos\NativeInstaller::initialize($root,$database,$input);
    }else{$existing=require $configuration;if(empty($existing['installed'])||($existing['db_name']??'')!==$db['name']||($existing['db_user']??'')!==$db['user']||($existing['app_url']??'')!=='https://'.$bootstrap['domain'])benos_bootstrap_error('EXISTING_INSTALLATION_CONFLICT');}
    $siteSecret=benos_bootstrap_b64(hash_hmac('sha256','BENOS-SITE-IDENTITY|'.$bootstrap['siteId'],$bootstrap['signingSecret'],true));$siteKey='site_'.substr($bootstrap['siteId'],5,24);
    benos_bootstrap_atomic($root.'/storage/private/benos-connection.json',['siteId'=>$bootstrap['siteId'],'keyId'=>$siteKey,'signingSecret'=>$siteSecret,'cmsVersion'=>'1.9.21','testMode'=>$test]);
    $result=['jobId'=>$bootstrap['jobId'],'siteId'=>$bootstrap['siteId'],'state'=>'awaiting_input','step'=>'verify_domain_https','cmsInstalled'=>true,'cmsVersion'=>'1.9.21','connection'=>['origin'=>'https://'.$bootstrap['domain'],'keyId'=>$siteKey,'healthPath'=>'/benos-health.php','signingSecret'=>$siteSecret]];$status=200;
    }
}catch(Throwable $error){$status=in_array((int)$error->getCode(),[400,401,403,405,409,410,413,422,503],true)?(int)$error->getCode():503;$code=preg_match('/^[A-Z][A-Z0-9_]{2,80}$/D',$error->getMessage())?$error->getMessage():'BOOTSTRAP_INSTALL_REVIEW_REQUIRED';$result=['error'=>['code'=>$code]];}
finally{if(is_resource($lock)){flock($lock,LOCK_UN);fclose($lock);}}
$raw=json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);http_response_code($status);header('Content-Type: application/json');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
if($identity){$time=(string)time();$canonical=implode("\n",['BENOS-BRIDGE-V1-RESPONSE',$identity['nonce'],(string)$status,$time,hash('sha256',$raw)]);header('X-Benos-Timestamp: '.$time);header('X-Benos-Signature: '.benos_bootstrap_b64(hash_hmac('sha256',$canonical,$bootstrap['signingSecret'],true)));}
echo $raw;
